version = "1.1.6"
name = "艾希,I see !(动画包)"
description = "这是“艾希,I see!”mod 的动画包\nThis mod is a Animation Pack for the mod “艾希,I see!” "
author = "灵衣女王的鬼铠, 咕噜喵"

forumthread = " "

api_version = 10

dst_compatible = true

dont_starve_compatible = false
reign_of_giants_compatible = false

all_clients_require_mod = true 

priority = 2147483646 + 2

icon_atlas = "modicon.xml"
icon = "modicon.tex"

server_filter_tags = {
	"character",
}

