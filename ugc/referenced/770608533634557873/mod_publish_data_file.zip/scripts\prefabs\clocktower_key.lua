local IceyUtil = require("icey_util")
local assets =
{
    Asset("ANIM", "anim/clocktower_key.zip"),
	Asset("IMAGE","images/inventoryimages/clocktower_key.tex"),
	Asset("ATLAS","images/inventoryimages/clocktower_key.xml"),
}

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()
	inst.entity:AddSoundEmitter()
	
    MakeInventoryPhysics(inst)

    inst.AnimState:SetBank("clocktower_key")
    inst.AnimState:SetBuild("clocktower_key")
    inst.AnimState:PlayAnimation("idle")

    inst:AddTag("clocktower_key")
	
    inst.entity:SetPristine()	
    if not TheWorld.ismastersim then
        return inst
    end	  

    inst:AddComponent("inspectable")

    inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "clocktower_key"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/clocktower_key.xml"

    MakeHauntableLaunch(inst)
    return inst
end


return Prefab("clocktower_key", fn,assets)


