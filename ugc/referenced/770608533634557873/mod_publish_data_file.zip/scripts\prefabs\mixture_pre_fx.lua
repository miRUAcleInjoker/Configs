local assets =
{
    Asset("ANIM", "anim/nightmarefuel.zip"),
}

local function OnSoulIn(inst)
	local x,y,z = inst:GetPosition():Get()
	local scale = inst.Transform:GetScale() 
	local rad = scale - math.random()
	local roa = math.random(0,360)
	local fx = SpawnPrefab("sanity_raise")
	local fxscale = 0.75 + math.random()*0.2 + math.random()*-0.3
	rad = math.min(rad,1.5)
	fx.Transform:SetScale(fxscale,fxscale,fxscale)
	fx.Transform:SetPosition(x+rad*math.cos(roa),y,z+rad*math.sin(roa))
	inst.SoundEmitter:PlaySound("dontstarve/sanity/creature2/die")
	
	inst.SoulInTask = inst:DoTaskInTime(math.random()*0.35,OnSoulIn)
end 

local function OnUpdate(inst)
	local scale = inst.Transform:GetScale()
	inst.Transform:SetScale(scale+0.05,scale+0.05,scale+0.05)
	if  scale > 5 then
		if inst.SoulInTask then 
			inst.SoulInTask:Cancel()
		end
		if inst.OnUpdateTask then 
			inst.OnUpdateTask:Cancel()
			inst:DoTaskInTime(2,function()
				local creature = SpawnPrefab("shadow_mixtrues")
				local x,y,z = inst:GetPosition():Get()
				creature.Transform:SetPosition(x,y,z)
				creature.sg:GoToState("taunt")
		
				local player = creature:GetNearestPlayer(true)
				if player ~= nil and creature:IsNear(player, 20) then
					creature.components.combat:SetTarget(player)
				end
	
				local fx = SpawnPrefab("statue_transition_2")
				fx.Transform:SetPosition(x,y,z)
				fx.Transform:SetScale(3,3,3)
			
				local fx2 = SpawnPrefab("blossom_hit_fx_dark_icey")
				fx2.Transform:SetPosition(x,y,z)
				fx2.Transform:SetScale(2,2,2)
	
				inst:Remove()
			end )
		end
	end
end 

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()
	inst.entity:AddSoundEmitter()

    MakeInventoryPhysics(inst)

    inst.AnimState:SetBank("nightmarefuel")
    inst.AnimState:SetBuild("nightmarefuel")
    inst.AnimState:PlayAnimation("idle_loop", true)
    inst.AnimState:SetMultColour(1, 1, 1, 0.5)
	
	inst.Transform:SetScale(0.1,0.1,0.1)

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.SoulInTask = inst:DoTaskInTime(0.25,OnSoulIn)
	inst.OnUpdateTask = inst:DoPeriodicTask(0,OnUpdate)

    

    return inst
end

return Prefab("mixture_pre_fx", fn, assets)
