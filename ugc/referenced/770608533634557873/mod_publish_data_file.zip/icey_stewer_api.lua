local cooking = require("cooking")

local function dospoil(inst, self)
    self.task = nil
    self.targettime = nil
    self.spoiltime = nil

    if self.onspoil ~= nil then
        self.onspoil(inst)
    end
end

local function dostew(inst, self)
    self.task = nil
    self.targettime = nil
    self.spoiltime = nil
    
    if self.ondonecooking ~= nil then
        self.ondonecooking(inst)
    end

    if self.product == self.spoiledproduct then
        if self.onspoil ~= nil then
            self.onspoil(inst)
        end
    elseif self.product ~= nil then
        local prep_perishtime = cooking.GetRecipe(inst.prefab, self.product).perishtime or 0
        if prep_perishtime > 0 then
			local prod_spoil = self.product_spoilage or 1
			self.spoiltime = prep_perishtime * prod_spoil
			self.targettime =  GetTime() + self.spoiltime
			self.task = self.inst:DoTaskInTime(self.spoiltime, dospoil, self)
		end
    end

    self.done = true
end

AddComponentPostInit("stewer",function(self)
	if not self.inst:HasTag("multfoods_cookpot") then 
		return 
	end 
	self.num_to_give_mult = 1 
	
	local old_StartCooking = self.StartCooking
	self.StartCooking = function(self)
		if self.targettime == nil and self.inst.components.container ~= nil then
			self.done = nil
			self.spoiltime = nil

			if self.onstartcooking ~= nil then
				self.onstartcooking(self.inst)
			end

			local ings = {}         
			for k, v in pairs (self.inst.components.container.slots) do
				table.insert(ings, v.prefab)
			end

			local cooktime = 1
			self.product, cooktime = cooking.CalculateRecipe(self.inst.prefab, ings)
			local productperishtime = cooking.GetRecipe(self.inst.prefab, self.product).perishtime or 0

			if productperishtime > 0 then
				local spoilage_total = 0
				local spoilage_n = 0
				for k, v in pairs (self.inst.components.container.slots) do
					if v.components.perishable ~= nil then
						spoilage_n = spoilage_n + 1
						spoilage_total = spoilage_total + v.components.perishable:GetPercent()
					end
				end
				self.product_spoilage = 1
				if spoilage_total > 0 then
					self.product_spoilage = spoilage_total / spoilage_n
					self.product_spoilage = 1 - (1 - self.product_spoilage) * .5
				end
			else
				self.product_spoilage = nil
			end
					
			
			
			-------------�ҳ��䷽ʳ�ȡ��Сֵ�����м��飩
			local min_size = nil  
			for k, v in pairs (self.inst.components.container.slots) do
				if v and v:IsValid() and v.components.stackable then 
					local size = v.components.stackable:StackSize()
					if min_size == nil or size < min_size then 
						min_size = size 
					end
				end
			end
			min_size = min_size or 1 
			self.num_to_give_mult = min_size
			
			cooktime = TUNING.BASE_COOK_TIME * cooktime * min_size
			self.targettime = GetTime() + cooktime
			if self.task ~= nil then
				self.task:Cancel()
			end
			self.task = self.inst:DoTaskInTime(cooktime, dostew, self)
			
			-----------�Ƴ���Ӧ������ʳ��
			for k, v in pairs (self.inst.components.container.slots) do
				for i = 1,min_size do 
					if v and v:IsValid() then  
						if v.components.stackable then 
							v.components.stackable:Get():Remove()
						else
							v:Remove() 
						end 
					end
				end
			end
			
			----------���������ʳ��
			self.inst.components.container:DropEverything()
			self.inst.components.container:Close()
			--self.inst.components.container:DestroyContents()
			self.inst.components.container.canbeopened = false
		end
	end 
	
	local old_Harvest = self.Harvest
	self.Harvest = function(self,harvester)
		if self.done then
			if self.onharvest ~= nil then
				self.onharvest(self.inst)
			end
			
			for i=1,self.num_to_give_mult do 
				if self.product ~= nil then
					local loot = SpawnPrefab(self.product)
					if loot ~= nil then
						local recipe = cooking.GetRecipe(self.inst.prefab, self.product)
						
						if loot.components.stackable then
							local stacksize = recipe and recipe.stacksize or 1
							if stacksize > 1 then
								loot.components.stackable:SetStackSize(stacksize)
							end
						end 
					
						if self.spoiltime ~= nil and loot.components.perishable ~= nil then
							local spoilpercent = self:GetTimeToSpoil() / self.spoiltime
							loot.components.perishable:SetPercent(self.product_spoilage * spoilpercent)
							loot.components.perishable:StartPerishing()
						end
						if harvester ~= nil and harvester.components.inventory ~= nil then
							harvester.components.inventory:GiveItem(loot, nil, self.inst:GetPosition())
						else
							LaunchAt(loot, self.inst, nil, 1, 1)
						end
					end
				end
			end 
			self.product = nil

			if self.task ~= nil then
				self.task:Cancel()
				self.task = nil
			end
			self.targettime = nil
			self.done = nil
			self.spoiltime = nil
			self.product_spoilage = nil
			self.num_to_give_mult = 1  

			if self.inst.components.container ~= nil then      
				self.inst.components.container.canbeopened = true
			end

			return true
		end
	end 
	
	local old_OnSave= self.OnSave
	self.OnSave = function(self)
		local retdata = old_OnSave(self)
		retdata.num_to_give_mult = self.num_to_give_mult
		return retdata 
	end 
	
	local old_OnLoad = self.OnLoad
	self.OnLoad = function(self,data)
		if data.num_to_give_mult then 
			self.num_to_give_mult = data.num_to_give_mult 
		end
		return old_OnLoad(self,data)
	end 
end) 