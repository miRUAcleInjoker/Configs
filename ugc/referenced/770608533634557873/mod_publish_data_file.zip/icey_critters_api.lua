AddComponentPostInit("crittertraits",function(self)
	self.onabandonedfn = nil 
	
	self.SetOnAbandonedFn = function(self,fn)
		self.onabandonedfn = fn 
	end 
	
	self.OnAbandoned = function(self)
		if self.onabandonedfn then 
			self.onabandonedfn(self.inst)
		end
	end 

end)

ACTIONS.ABANDON.priority = 2

local old_ABANDON_fn = ACTIONS.ABANDON.fn
ACTIONS.ABANDON.fn = function(act)
	if act.doer.components.petleash ~= nil then
        if not (act.doer.components.builder ~= nil and act.doer.components.builder.accessible_tech_trees.ORPHANAGE > 0) then
            --we could've been in range but the pet was out of range
            local x, y, z = act.doer.Transform:GetWorldPosition()
            if #TheSim:FindEntities(x, y, z, 10, { "critterlab" }) <= 0 then
                return false
            end
        end
		
		if act.target and act.target:IsValid() and act.target.components.crittertraits then 
			act.target.components.crittertraits:OnAbandoned() 
		end
		return old_ABANDON_fn(act)
    end
	
end 

