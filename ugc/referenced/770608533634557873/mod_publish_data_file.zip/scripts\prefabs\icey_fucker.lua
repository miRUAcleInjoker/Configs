local assets =
{
    Asset("ANIM", "anim/icey_fucker.zip"),
    --Asset("ANIM", "anim/swap_icey_fucker.zip"),
    Asset("ANIM", "anim/diviningrod_fx.zip"),
	Asset("ATLAS", "images/inventoryimages/icey_fucker.xml"),
    Asset("IMAGE", "images/inventoryimages/icey_fucker.tex"),
}

local prefabs =
{
    "dr_hot_loop",
    "dr_warmer_loop",
    "dr_warm_loop_2",
    "dr_warm_loop_1",
}

local TASKS = {
-----------------------------TASK1----------------------------------
	{speech = "咳咳，你好，我是旁白啊~"},
	{speech = "啊？你问我为什么变成手机的样子了！"},
	{speech = "额。。。这个。。。说来话长。。。"},
	{speech = "你知道啊。。。这个作者嘛~~~"},
	{speech = "作者太懒了。。。"},
	{speech = "人家。。人家随随便便网上找了个破手机的图。。。然后说这是旁白"},
	{speech = "我**还能怎么办？是作者把我设计成这个样子的！！！"},
	{speech = "我！堂堂旁白君！居然要蜗居在一个平凡手机的躯壳中"},
	{speech = "这是多大的不幸！！！"},
	{speech = "唉！造化弄人啊。。。。"},
	{speech = "咕~~~~~~~~（肚子咕噜咕噜叫的声音）"},
	{speech = "好饿啊，不想做旁白了。。。"},
	{speech = "不对我这一破手机拿来的胃啊？"},
	{speech = "这不符合射腚啊！"},
	{speech = "咳咳，现在开始进入正题！"},
	{speech = "En Taro Hastur"},
	{speech = "想必您就是大名鼎鼎的艾希执政官了"},
	{speech = "大主教正召集所有神之长子光复艾尔"},
	{speech = "我会帮助你离开这片荒诞的大陆"},
	{speech = "首先还请您跟着箭头走~~~"},
	{speech = "咕噜咕噜咕咕咕路.....（肚皮见底的声音）"},
	{speech = "哦！见鬼！我可没有饱食度的组件啊！为什么我会饿？"},
	{speech = "我想我们最好再天黑之前找点吃的...."},
	{speech = "咕噜咕噜咕咕咕路噜咕噜咕咕咕路~~~~~~~~（肚子饿扁了的声音）"},
	{speech = "愣着干嘛？快去找点吃的啊！"},
	{speech = "什么吃的都行，浆果，萝卜，快快快！！！",testfn = function(inst,owner)
		return owner.components.inventory and
		owner.components.inventory:FindItem(function(item)
			return item.components.edible and 
			(item.components.edible.foodtype == FOODTYPE.BERRY or 
			item.components.edible.foodtype == FOODTYPE.MEAT or 
			item.components.edible.foodtype == FOODTYPE.VEGGIE)
		end) 
	end},

-----------------------------TASK2----------------------------------
	{speech = "啊！你找到吃的了，太棒了~~~"},
	{speech = "不过我突然不饿了"},
	{speech = "所以还是你吃吧~"},
	{speech = "不！我真的不饿！真的！"},
	{speech = "这怎么好意思呢，我不能随便吃嗟来之食啊"},
	{speech = "我可是伟大的旁白啊！"},
	{speech = "我可是宇宙第一的SuperAI啊"},
	{speech = "够了！不要点我了！"},
	{speech = "我！旁白君！身为你的指导者！"},
	{speech = "饿死！死外面！从服务器里炸出去！"},
	{speech = "也不会蹭吃一口软饭！！",testfn = function(inst,owner)
		if  owner.components.inventory then  
			local foods = owner.components.inventory:FindItems(function(item)
				return item.components.edible and 
				(item.components.edible.foodtype == FOODTYPE.BERRY or 
				item.components.edible.foodtype == FOODTYPE.MEAT or 
				item.components.edible.foodtype == FOODTYPE.VEGGIE)
			end)  
			if #foods > 3 then 
				for k,v in pairs(foods) do 
					v:Remove()
				end 
				inst.components.talker:Say("真香！")
				return true
			end
		end
		return false
	end},
	{speech = "真香！"},
-----------------------------TASK3----------------------------------
	{speech = "唉唉唉别哭啊!"},
	{speech = "不就是吃了你几组食物嘛"},
	{speech = "谁叫你在原作里一直不按照箭头走"},
	{speech = "那个....刚刚实在是太饿了~"},
	{speech = "抱歉啊抱歉~~~"},
	{speech = "好吧好吧~别哭了~啊~~"},
	{speech = "要不这样吧！"},
	{speech = "我给你来几句嘤嘤嘤~"},
	{speech = "嘤嘤嘤"},
	{speech = "嘤嘤嘤"},
	{speech = "嘤嘤嘤嘤嘤"},
	{speech = "秘技·八重嘤"},
	{speech = "卐解·千本樱"},
	{speech = "幻嘤剑舞"},
	{speech = "嘤击长空"},
	{speech = "天妒嘤才"},
	{speech = "我是~日食之嘤~~"},
	{speech = "嘤雄所见略同"},
	{speech = "啊啊啊我开玩笑的别一拳一个嘤嘤怪！"},
	{speech = "我把东西赔给你，赔给你还不行嘛~"},
	{speech = "给！拿好了！",testfn = function(inst,owner)
		if  owner.components.inventory then  
			local item1,item2,item3,item4,item5 = SpawnPrefab("gears"),SpawnPrefab("icey_battery"),SpawnPrefab("icey_battery2"),SpawnPrefab("icey_battery3"),SpawnPrefab("icey_battery4")
			item1.Transform:SetPosition(owner:GetPosition():Get())
			item2.Transform:SetPosition(owner:GetPosition():Get())
			item3.Transform:SetPosition(owner:GetPosition():Get())
			item4.Transform:SetPosition(owner:GetPosition():Get())
			item5.Transform:SetPosition(owner:GetPosition():Get())
			owner.components.inventory:GiveItem(item1) 
			owner.components.inventory:GiveItem(item2) 
			owner.components.inventory:GiveItem(item3) 
			owner.components.inventory:GiveItem(item4) 
			owner.components.inventory:GiveItem(item5) 
			return true
		end 
	end},
-----------------------------TASK4----------------------------------
	{speech = "啊，几个个美味的电池加齿轮！这下可以了吧！"},
	{speech = "你问我电池干什么？电池！当然是用来吃啊！"},
	{speech = "不过不仅仅是可以用来吃哦~"},
	{speech = "不同种类的电池有着不同的效果"},
	{speech = "吃下护盾电池会为你补充大量护盾值！"},
	{speech = "高（尻♂）能电池，故名思议，听起来就觉得很饱啦！"},
	{speech = "熔融电池就像汽水，吃下去使人精神饱满！That's ♂ Good"},
	{speech = "而纳米电池则是修复机体的不二人选！"},
	{speech = "当然，以后你可能还会见到更多种类的电池~"},
	{speech = "你可以在左边的【艾希】科技制作栏制作所有的电池~"},
	{speech = "或许你已经发现了~"},
	{speech = "电池的配方里无一例外的包含有“生命精华”"},
	{speech = "你问我精华从哪里来？！"},
	{speech = "我怎么知道？"},
	{speech = "我又不是精华狂魔？！"},
	{speech = "@生物质狂魔阿巴瑟"},
	{speech = "@精华狂魔德哈卡"},
	{speech = "嗯~真的~这需要你在战斗中自行体会~"},
	{speech = "现在，带上10个生命精华来见我！"},
	{speech = "更多的！精华！"},
	{speech = "搞到10个生命精华，才有后话可说！",testfn = function(inst,owner)
		if  owner.components.inventory then  
			if owner.components.inventory:Has("icey_magic",10) then 
				inst.components.talker:Say("干的不错嘛！")
				return true
			end
		end
		return false
	end},
	{speech = "显然，你拥有从死去的敌人身上汲取精华的能力"},
	{speech = "杀死的敌人越强，获得的精华越多"},
	{speech = "如果你烦透了每天打打杀杀~"},
	{speech = "可以在【艾希】制作栏制作分解引擎，用引擎来分解物品，得到精华"},
-----------------------------TASK5----------------------------------
	{speech = "哦，我差点忘了，你有护盾值与等级的射腚哦！"},
	{speech = "请看你左上角的ui，是不是写着 等级  精液（划掉）经验 还有护盾 三个大字？"},
	{speech = "现在，仔细听好了："},
	{speech = "护盾是艾希mod中最重要的一点"},
	{speech = "护盾会为你承担一定伤害，护盾值越高，承受的伤害越多"},
	{speech = "护盾在恶劣温度或者你的饥饿值过低时迅速崩解"},
	{speech = "此外，护盾不是百分百承受伤害的！要注意这点！"},
	{speech = "之前Wegay的人说护盾没用啊有护盾还会掉血啊！"},
	{speech = "对那些人我真想说：你**就不能好好看射腚吗？！"},
	--[[{speech = "现在大家拿到mod都不看射腚"},
	{speech = "“太长不看”是他们的惯用接口"},
	{speech = "殊不知mod的每一个射腚，细节无一不是mod侧滑精心创造的"},
	{speech = "为了验证一个特效的美观程度，Mod侧滑需要重开游戏数遍"},
	{speech = "大家！一定要仔细看射腚啊！"},--]]
	{speech = "咳咳，扯远了....."},
	{speech = "我们到哪了？"},
	{speech = "哦！等级与经验制度！"},
	{speech = "每当你杀死一名敌人，会获得其生命上限/100点的精...."},
	{speech = "....经验..."},
	{speech = "每当你吃东西，工作，采集时~也会获得少量的...."},
	{speech = "....的经验值...."},
	{speech = "而你每升一级需要当前等级X100点的经验值~"},
	{speech = "如你所见，你的初始等级才1级！与伟大的我相比是多么渺小啊~"},
	{speech = "啊哈哈哈哈~~~"},
	{speech = "咳咳~"},
	{speech = "升级会提升你的生命/饥饿与精神上限，这是必然的~"},
	{speech = "但是~~~"},
	{speech = "现在！看你左下角！"},
	{speech = "看到那个“天赋”按钮了吗？快点按下它啊！！"},
	{speech = "啊~这么快就看完天赋表了吗？"},
	{speech = "显而易见~"},
	{speech = "每当你的等级提升1级，就会有一组新的天赋组出现在天赋表中"},
	{speech = "你可以对这些天赋进行任意分配"},
	{speech = "虽然重置天赋的按钮就在天赋表的右上方~~"},
	{speech = "但还请您务必谨慎"},
	{speech = "因为你只能同时选择每组中的一个天赋进行升级......."},
	{speech = "抓紧时间练习吧！等你到了第四级再来见我！",testfn = function(inst,owner)
		if  owner.icey_level and owner.icey_level >= 4 then  
			return true
		end
		return false
	end},
	{speech = "哇塞！这么厉害？！你真的四级了！"},
	{speech = "你是刷了多少蜘蛛啊！"},
	{speech = "我总感觉这不太对劲~"},
	{speech = "你不会开了控制台一击必杀吧？！"},
	{speech = "嘿！我真想说你是个作弊者！"},
	{speech = "但是我好像没有证据....."},
	{speech = "没办法的事~作者的代码水平太差了！"},
	{speech = "算了，管他的！"},
	{speech = "这是奖励！拿好了！",testfn = function(inst,owner)
		if owner.components.inventory then 
			for i = 1,20 do  
				local item = SpawnPrefab("icey_battery")
				item.Transform:SetPosition(owner:GetPosition():Get())
				owner.components.inventory:GiveItem(item)
			end 
			return true
		end
		return false
	end},
-----------------------------TASK6----------------------------------
	{speech = "看样子你已经对基本操作熟练了"},
	{speech = "也用不着我说那个键是闪避，哪个键是必杀技了吧~"},
	{speech = "或者是右键的武器技能。。。"},
	{speech = "那么！"},
	{speech = "热身运动结束了！"},
	{speech = "来搞点大动静吧！"},
	{speech = "下一个目标是......"},
	{speech = "升到满级？"},
	{speech = "不不不这太无聊了~"},
	{speech = "早就有很多玩家投诉说什么~"},
	{speech = "什么~经验加太少啦~什么~一个小时才2级啊"},
	{speech = "虽然作者认为这纯粹是你们在瞎扯淡或者技术差什么的"},
	{speech = "但是~但是~"},
	{speech = "我可是庞白啊~我要对你负责对吧~"},
	{speech = "我不能让你的游戏体验太过糟糕对吧？"},
	{speech = "本身升到4级就很烦了(小声bb)"},
	{speech = "下一个任务，我要你搞到的是！"},
	{speech = "护盾发生器！"},
	{speech = "点开你的艾希制作栏 ！看见没！配方就写在里面！"},
	{speech = "还犹豫着什么呢？快去啊！",testfn = function(inst,owner)
		if  owner.components.inventory then  
			if owner.components.inventory:Has("icey_armor",1) then 
				inst.components.talker:Say("等你很久了！")
				for i = 1,20 do  
					local item = SpawnPrefab("icey_battery")
					item.Transform:SetPosition(owner:GetPosition():Get())
					owner.components.inventory:GiveItem(item)
				end 
				return true
			end
		end
		return false
	end},
-----------------------------TASK7----------------------------------
	{speech = "护盾发生器~啊~护盾发生器~"},
	{speech = "护盾发生器是个好东西啊~"},
	{speech = "首先，作为防具~"},
	{speech = "护盾发生器拥有80%的伤害减免与近似无限的使用耐久！"},
	{speech = "其次，它能在你的护盾急缺时自动帮你使用护盾电池"},
	{speech = "和吃下去是一个效果哦！"},
	{speech = "当然了，为了避免浪费"},
	{speech = "护盾发生器的自动充能仅在非恶劣条件下触发"},
	{speech = "好好使用它吧"},
	{speech = "哦对了~"},
	{speech = "我居然忘记了介绍这个"},
	{speech = "或许你已经自己搞出来了"},
	{speech = "然而我还是要介绍一遍！"},
	{speech = "拿好这些球球，然后投掷出去，看看会发生什么效果~",testfn = function(inst,owner)
		if  owner.components.inventory then  
			for i = 1,5 do  
				local item = SpawnPrefab("icey_ball")
				item.Transform:SetPosition(owner:GetPosition():Get())
				owner.components.inventory:GiveItem(item)
			end 
			return true
		end
		return false
	end},
	{speech = "或者你也可以乖乖的把这些神奇的球球放回箱子里，先听我讲解"},
	{speech = "我在等你的决定",testfn = function(inst,owner)
		if  owner.components.inventory then  
			if not owner.components.inventory:Has("icey_ball",1) then 
				inst.components.talker:Say("明智的决定！")
				return true
			end
		end
		return false
	end},
	{speech = "反组引力球不仅仅是强大的武器，也是高效的回收工具"},
	{speech = "作为武器而言，它的爆炸范围很大，伤害不稳定但是基数高"},
	{speech = "但是最重要的一点是，它能直接将被击中的物体打回最纯粹的状态"},
	{speech = "也就是生命精华"},
	{speech = "而且，使用反组引力球攻击获得的生命精华"},
	{speech = "比常规的战斗获取效率高的多"},
	{speech = "这也是它可以用作回收工具的原因"},
	{speech = "我也不约束你了，拿去爽一下吧！",testfn = function(inst,owner)
		if  owner.components.inventory then  
			for i = 1,5 do  
				local item = SpawnPrefab("icey_ball")
				item.Transform:SetPosition(owner:GetPosition():Get())
				owner.components.inventory:GiveItem(item)
			end 
			return true
		end
		return false
	end},
-----------------------------TASK8----------------------------------
	{speech = "啊，你知道嘛。"},
	{speech = "总是有玩家和我说:艾希是战斗特化型角色"},
	{speech = "那么我一直在思考~"},
	{speech = "作为战斗角色~"},
	{speech = "每天打打杀杀的~"},
	{speech = "是不是忽略了饥荒本有的....农业特性呢？"},
	{speech = "所以....嘿嘿~"},
	{speech = "我搞了个好东西出来~"},
	{speech = "打开你的【艾希】科技制作栏"},
	{speech = "是不是找到一个叫“死神1000型”的东西？"},
	{speech = "想不想搞一个Van♂一♂Van？"},
	{speech = "别看着我~这次我不会送你任何东西了~"},
	{speech = "你上次从我这里拿走了10个反组引力球呢~"},	
	{speech = "快去搞一个“死神1000型”吧！之后我们再接着聊~",testfn = function(inst,owner)
		if  owner.components.inventory then  
			if  owner.components.inventory:Has("icey_reaper",1) then 
				inst.components.talker:Say("Van♂美")
				return true
			end
		end
		return false
	end},
	{speech = "这玩意~看起来就像回旋镖对吧~"},
	{speech = "对！没错！你完全可以用它来打人~"},
	{speech = "但是~"},
	{speech = "你也可以用它来收割作物哦！"},
	{speech = "拿上这个“死神1000型”，对着小草小树枝试一下吧！"},
	{speech = "怎么样！全部被割♂下来了哦！"},
	{speech = "麻麻我再也不用快采这种BT mod了！"},
	{speech = "你问我为什么给一个割草镖取“死神1000型”这种名字？"},
	{speech = "因为对庄稼来说，所有收割者都是死神啊！"},
-----------------------------FINAL----------------------------------
	{speech = "催催催！天天天催剧情！劳资不干了！"}
}


local Speech_OwnerAttack = {
	normal = {
		"艾希朝着敌人冲了过去！",
		"艾希进攻了！", 
		"加入战斗!",
		"坚持不懈!",
		"虽然路途艰辛，但是艾希无所畏惧！", 
		"艾希拿起了她的大♂保♂健",
		"死亡在等着你们",
		"Lok’Tar Ogar!",  
	},
	spider = {
		"“拥抱战斗的荣耀”？你真的不是堂口兄弟吗",
		"想必几只小蜘蛛一定不是艾希的对手",
		"哦吼~~~",
	},
	spider_warrior = {
		"啊！一位劲敌！",
		"艾希应当使用她的极限闪避来对付这种灵活的对手",
	},
	spider_haojie = {
		"这个敌人.....充斥着烈火与死亡的气息！",
		"艾希应当小心",
		"有谁能开下空调吗",
	},
	spider_dragoon = {
		"哦！真是耐揍！",
		"你还要打多少下啊",
		"这种类型的敌人设计出来真是无聊",
	},
	spider_chaser = {
		"我打赌你这次打不着",
		"你打到它了吗？太棒了！",
		"过来！懦夫！",
	},
	spider_xianfeng = {
		"我听说有人命你奔赴战场！",
		"它很快就要光荣了",
		"荣耀的时刻！",
	},
	spider_bomb = {
		"滚滚红尘~~~",
	},
	
	sky_walker = {
		"干死黄旭东！巨像倒立能对空！",
	},
--[[	pigman = {
		"",
	},
	merm = {
		"",
	},--]]
}

local Speech_OwnerAttacked = {
	normal = {
		"艾希居然被击中了！",
		"不应该啊！你的闪避呢？", 
		"哎呦~疼不疼？",
		"回击！回击！",
		"这是个陷阱！",
		"好啦好啦！游戏玩完啦！我要回家！",
		"我们快要完蛋了！",
	},
	spider = {
		"艾希你居然会被小蜘蛛打到？！",
		"怼回去！怼回去！",
		"哇！！！",
	},
	spider_warrior = {
		"撕拉！",
		"我不是提示你用闪避了吗？！",
	},
	spider_haojie = {
		"烫烫！烫烫！",
		"喂！你看你的护盾！",
		"浩劫之焰,堪比龙息！",
	},
	spider_dragoon = {
		"啪叽！",
	},
	spider_chaser = {
		"这种闪来闪去的敌人真是烦人，不是吗？",
		"这家伙不知道闪现技能很占内存吗？",
		"Show yourself !",
	},
	spider_xianfeng = {
		"猛烈的进攻！",
		"你可别光荣了！",
		--"荣耀的时刻！",
	},
	spider_bomb = {
		"离我远点！",
		"你的酸液溅到我的机壳上了！",
		"菲尔普斯山寨防腐蚀机，山寨机，就是牛！",
	},
	
	sky_walker = {
		"夭寿啦！巨像对空啦！",
	},
}

local Speech_OwnerKilled = {
	normal = {
		"漂亮",
		"啊~又一名敌人倒下了", 
		"又一名敌人倒在了艾希身下", 
		"多么悦耳的惨叫声啊~",
		"随风而去吧！小虫子们~",
		"死吧！虫砸！",
		"最后一击！",
		"一拳终结！",
	},
	spider_higher = {
		"艾希毫不犹豫的结果了这只丑八怪",
		--"作者在哪？你这是什么剧情？！",
	},
	sky_walker = {
		"夭寿啦！巨像对空啦！",
	},
}

local Speech_OwnerDeath = {
	--又双叒叕
	"你死了",
	"你又死了",
	"你双死了",
	"你又双死了",
	"你又又双死了",
	"你又双叒死了",
	"你双双叒死了",
	"你又双双叒死了",
	"你又叒叕死了",
	"你又叕叕死了",
	"你双叒叕死了",
	"你又双叒叕死了",
	"我已经记不清了",
}


local function isowner(inst,owner)
	return owner.prefab == "icey" and owner.userid == inst.ownerid
end 


local function ontalk(inst)
	inst.SoundEmitter:PlaySound("dontstarve/common/diviningrod_ping")
	local fx = SpawnPrefab(prefabs[math.random(1,#prefabs)])
	local pos = inst:GetPosition()
	local x,y,z = pos:Get()
	fx.Transform:SetPosition(x,y,z)
end 

local function fuckyou(inst)
	print(inst.ownerid)
	local fuckstr = 
	(math.random(1,100) > 50 and "EXCUSE 喵？！") or
	(math.random(1,100) > 50 and "嘿！你是个冒牌货！") or 
	"把你的脏手从我高贵的机壳上拿开！"
	inst.components.talker.lineduration = 2.5
	inst.components.talker:Say(fuckstr)
end 

local function Ondescribe(inst,owner)
	if not isowner(inst,owner) then 
		fuckyou(inst)
		return "  "
	end 
	inst.components.talker.lineduration = 10
	if inst.task_pos > #inst.tasks then 
		inst.components.talker:Say("催催催！天天天催剧情！劳资不干了！")
	else
		inst.components.talker:Say(inst.tasks[inst.task_pos].speech)
		if inst.task_pos < inst.max_task_pos or inst.tasks[inst.task_pos].testfn == nil or inst.tasks[inst.task_pos].testfn(inst,owner) then 
			if not string.find(inst.tasks[inst.task_pos].speech,'(已阅读)') then 
				inst.tasks[inst.task_pos].speech = inst.tasks[inst.task_pos].speech.."\n(已阅读)"
			end 
			--inst.tasks[inst.task_pos].testfn = function(inst,owner)return true end
			inst.task_pos = inst.task_pos + 1 
		end 
	end
	inst.task_pos = math.min(inst.task_pos,#inst.tasks)
	inst.max_task_pos = math.max(inst.max_task_pos,inst.task_pos)
	return "  "
end

local function OnAttacked(inst)
	local str = (math.random(1,100) > 66 and "我警告你！再打我一次试试看？！") or (math.random(1,100) > 66 and "啊啊啊不要打我这张英俊帅气的脸啊！！") or " 哎呦别打了！疼！"
	inst.components.talker.lineduration = 2.5
	inst.components.talker:Say(str)
	inst.task_pos = inst.task_pos - 1
	if inst.components.health then 
		inst.components.health:SetPercent(1.0)
		inst.components.health:SetAbsorptionAmount(1.0)
	end
	inst.task_pos = math.max(inst.task_pos,1)
	
end 

local function OnDeath(inst)
	local another = SpawnPrefab("icey_fucker")
	local str = (math.random(1,100) > 66 and "傻了吧！爷会复活！") or (math.random(1,100) > 66 and "嘿！我要求取消“宰杀”这个选项！！") or "谁给你的胆子宰杀我？！！"
	another.components.talker.lineduration = 2.5
	another.ownerid = inst.ownerid 
	another.task_pos = inst.task_pos
	another.max_task_pos = inst.max_task_pos
	another.Transform:SetPosition(inst:GetPosition():Get())
	another.components.talker:Say(str)
end 
-------------------------------------------------------------------------------
local function OnOwnerAttack(owner,data)
	local fucker = owner.components.inventory and owner.components.inventory:FindItem(function(item)return item.prefab == "icey_fucker" end)
	local target = data.target
	print("On owner attack",owner,fucker)
	if not fucker or not fucker.timer_cantalk then 
		return 
	end
	local list = Speech_OwnerAttack[target.prefab]
	if not list then
		list = Speech_OwnerAttack["normal"]
	end
	local length = #list
	local str = list[math.random(1,length)]
	fucker.components.talker.lineduration = 2.5
	fucker.components.talker:Say(str)
	
	fucker.timer_cantalk = false
	fucker.components.timer:StartTimer("fucker_talk_events",math.random(3,5))
end 

local function OnOwnerAttacked(owner,data)
	local fucker = owner.components.inventory and owner.components.inventory:FindItem(function(item)return item.prefab == "icey_fucker" end)
	local attacker = data.attacker
	if (owner.components.health and owner.components.health:IsDead()) or owner:HasTag("playerghost") or not attacker then 
		return
	end 
	print("On owner attacked",owner,fucker)
	if not fucker or not fucker.timer_cantalk then 
		return 
	end
	local list = Speech_OwnerAttacked[attacker.prefab]
	if not list then
		list = Speech_OwnerAttack["normal"]
	end
	local length = #list
	local str = list[math.random(1,length)]
	fucker.components.talker.lineduration = 2.5
	fucker.components.talker:Say(str)
	
	fucker.timer_cantalk = false
	fucker.components.timer:StartTimer("fucker_talk_events",math.random(3,5))
end 

local function OnOwnerKilled(owner,data)
	local fucker = owner.components.inventory and owner.components.inventory:FindItem(function(item)return item.prefab == "icey_fucker" end)
	local target = data.victim
	print("On owner Killed",owner,fucker,target)
	if not fucker or not fucker.timer_cantalk or not target then 
		return 
	end
	local list = Speech_OwnerKilled[target.prefab]
	if not list then
		list = Speech_OwnerKilled["normal"]
	end
	local length = #list
	local str = list[math.random(1,length)]
	fucker.components.talker.lineduration = 2.5
	fucker.components.talker:Say(str)
	
	fucker.timer_cantalk = false
	fucker.components.timer:StartTimer("fucker_talk_events",math.random(3,5))
end 

local function OnOwnerDeath(owner)
	local fucker = owner.components.inventory and owner.components.inventory:FindItem(function(item)return item.prefab == "icey_fucker" end)
	print("On owner death",owner,fucker)
	if not fucker or not fucker.timer_cantalk_death then 
		return 
	end
	
	local str = Speech_OwnerDeath[fucker.death_time]
	fucker.components.talker.lineduration = 2.5
	fucker.components.talker:Say(str)
	
	fucker.death_time = fucker.death_time + 1
	fucker.death_time = math.min(fucker.death_time,#Speech_OwnerDeath)
	
	fucker.timer_cantalk_death = false
	fucker.components.timer:StartTimer("fucker_talk_events_death",3)
	
end 
-------------------------------------------------------------------------------------------
local function onpick(inst,owner)
	owner = (owner.components.inventoryitem and owner.components.inventoryitem:GetGrandOwner()) or owner
	if inst.ownerid == nil and owner.userid ~= nil and owner.prefab == "icey" then 
		inst.ownerid = owner.userid
	end 
	if owner.prefab ~= "icey" or (inst.ownerid ~= nil and inst.ownerid ~= owner.userid)  then 
		--inst.ownerid = nil 
		owner:DoTaskInTime(0, function( ... ) 
			if owner.components.inventory then 
				owner.components.inventory:DropItem(inst, true, true)
			end 
		end)
		fuckyou(inst)
		return
	end 
	inst:ListenForEvent("onhitother", OnOwnerAttack,owner)
	inst:ListenForEvent("attacked", OnOwnerAttacked,owner)	
	inst:ListenForEvent("killed", OnOwnerKilled,owner)
	inst:ListenForEvent("death", OnOwnerDeath,owner)
end 

local function ondrop(inst)
	local owner = inst.components.inventoryitem:GetGrandOwner()
	inst:RemoveEventCallback("onhitother", OnOwnerAttack,owner)
	inst:RemoveEventCallback("attacked", OnOwnerAttacked,owner)
	inst:RemoveEventCallback("killed", OnOwnerKilled,owner)
	inst:RemoveEventCallback("death", OnOwnerDeath,owner)
end 

local function OnSave(inst, data)
    data.task_pos = inst.task_pos or nil 
	data.ownerid = inst.ownerid or nil 
	data.max_task_pos = inst.max_task_pos or nil 
	--data.tasks = inst.tasks or TASKS
end

local function OnLoad(inst, data)
	if data then 
		if data.task_pos then 
			inst.task_pos = data.task_pos
		end
		if data.ownerid then 
			inst.ownerid = data.ownerid
		end
		if data.max_task_pos then 
			inst.max_task_pos = data.max_task_pos
		end
--[[		if data.tasks then 
			inst.tasks = data.tasks
		end--]]
		for k,v in pairs(inst.tasks) do 
			if k <= inst.max_task_pos then 
				if not string.find(v.speech,'(已阅读)') then 
					v.speech = v.speech.."\n(已阅读)"
				end 
			end
		end
	end
end

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()        
    inst.entity:AddNetwork()

    MakeInventoryPhysics(inst)

    inst.AnimState:SetBank("icey_fucker")
    inst.AnimState:SetBuild("icey_fucker")
    inst.AnimState:PlayAnimation("idle")
	
    inst:AddTag("icey_fucker")
	inst:AddTag("prey")
	inst:AddTag("smallcreature")
	inst:AddTag("CANT_RESOLVE")

	inst:AddComponent("talker")
    inst.components.talker.fontsize = 35
    inst.components.talker.font = TALKINGFONT
    inst.components.talker.colour = Vector3(0/255, 255/255, 255/255)
    inst.components.talker.offset = Vector3(0, 200, 0)
    inst.components.talker:MakeChatter()
	inst.components.talker.ontalk = ontalk
	
	inst:AddComponent("timer")
	
	inst.tasks = TASKS
	inst.ownerid = nil 
	inst.task_pos = 1
	inst.max_task_pos = 1
	inst.timer_cantalk = true
	inst.timer_cantalk_death = true
	inst.death_time = 1

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

	
    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("   ")
	inst.components.inspectable.descriptionfn = Ondescribe

    inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "icey_fucker"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/icey_fucker.xml"
	
    --inst.components.inspectable.getstatus = describe
	
	inst:AddComponent("health")
	inst.components.health:SetMaxHealth(2500)
	inst.components.health:SetAbsorptionAmount(1.0)

	inst:AddComponent("combat")

    
	


    inst.OnSave = OnSave
    inst.OnLoad = OnLoad
	
	inst:ListenForEvent("attacked", OnAttacked)
	--inst:ListenForEvent("healthdelta", OnAttacked)
	inst:ListenForEvent("death", OnDeath)
	inst:ListenForEvent("onputininventory", onpick)
	inst:ListenForEvent("ondropped", ondrop)
	inst:ListenForEvent("timerdone", function(inst,data)
		local name = data.name
		if name == "fucker_talk_events" then 
			inst.timer_cantalk = true
		elseif name == "fucker_talk_events_death" then 
			inst.timer_cantalk_death = true
		end
	end )
	
	
	MakeHauntableLaunch(inst)
    return inst
end

return Prefab("icey_fucker", fn, assets, prefabs)
