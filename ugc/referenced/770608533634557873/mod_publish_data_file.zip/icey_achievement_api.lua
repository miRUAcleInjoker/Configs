

GLOBAL.TUNING.ICEY_ALL_ACHIEVEMENTS_LIST = {
	--achiname = {title = "",desc = "",current = 0,max = 1,bonus = 1},
	{name = "first_eat",title = "第一口食物",desc = "吃下第一口食物。"},
	{name = "first_killother",title = "第一滴血",desc = "杀死第一个生物。"},
	
	{name = "storm_controled_picked",title = "风暴滋生",desc = "举起残存风暴之力的大剑。"},
	{name = "evil_chesters_welcome",title = "欢迎伙伴！",desc = "感受来自贪欲者的热烈欢迎。"},
	--[[{name = "deerclops_killed",title = "巨鹿的冻志",desc = ""},
	{name = "bearger_killed",title = "蛮熊的开岩",desc = ""},
	{name = "dragonfly_killed",title = "龙蝇的熔击",desc = ""},
	{name = "moose_killed",title = "鹿鸭的烈旋",desc = ""},--]]
	
	{name = "spider_higher_killed",title = "主巢心智",desc = "击败失去自我的主宰。"},
	{name = "pugalisk_killed",title = "暴食的奥义",desc = "杀死吞噬世界的巨型蟒蛇。"},
	{name = "sky_walker_killed",title = "巨像大暴走",desc = "摧毁失控的天罚行者。"},
	{name = "icey_sans_killed",title = "超越",desc = "战胜自己的影子。"},
	{name = "shadow_mixtures_killed",title = "完全形态",desc = "消灭融合的崩坏体。"},
	{name = "moon_giaour_killed",title = "机魂陨落",desc = "摧毁第一台成功的机魂机械。"},
	
	{name = "jade_killed",title = "GTMD青玉德",desc = "击倒鬼畜的青玉巨神。"},
	
	{name = "icey_boarrior_killed",title = "\"薪王\"巨人尤姆",desc = "击败因为传火燃尽心智，徒留躯壳而被利用的巨人。"},
	{name = "tigershark_duke_killed",title = "\"薪王\"虎鲨公爵",desc = "击败失落之海中，不可一世的虎鲨公爵。"},
	{name = "dark_antqueen_killed",title = "\"薪王\"古之人脓",desc = "击败自大门涌出，毁灭远古国度的黑色脓包。"},
	{name = "metal_hulk_merge_killed",title = "\"薪王\"和平行者",desc = "击败沉浸在战斗中，忘却自己为何物的合金装备。"},
	
	{name = "icey_dracula_killed",title = "信息时代的魔王",desc = "击败犹大寄宿的魔王级合金装备。"},
	{name = "death_dragon_killed",title = "托勒密死神",desc = "击败犹大于深渊位面的真祖灵魂。"},
	
	--[[{name = "normal_end",title = "收割循环",desc = "达成结局“驱逐魔王”"},
	{name = "bad_end",title = "篡位者",desc = "达成结局“篡夺王座”。"},
	{name = "true_end",title = "王座废除者",desc = "达成结局“摧毁王座”。"},--]]
}



AddReplicableComponent("icey_achievement_user")

local function OnEat(inst,data)
	inst.components.icey_achievement_user:DoDelta("first_eat",1)
end 

local function OnKilled(inst,data)
	inst.components.icey_achievement_user:DoDelta("first_killother",1)
end

AddPlayerPostInit(function(inst)
	if not TheWorld.ismastersim then
		return inst
	end
	
	inst:AddComponent("icey_achievement_user")
	-------------------------------------------------------
	
	inst:ListenForEvent("oneat",OnEat)
	inst:ListenForEvent("killed",OnKilled)
end)

--ThePlayer.HUD.controls.icey_achievement_ui:Show()
--ThePlayer.HUD.controls.icey_achievement_ui:Hide()
--ThePlayer.HUD.controls.icey_achievement_ui:SetInitData()
local icey_achievement_ui = require("widgets/icey_achievement_ui")
AddClassPostConstruct("widgets/controls", function(self)
	self.icey_achievement_ui = self:AddChild(icey_achievement_ui(self.owner,TUNING.ICEY_ALL_ACHIEVEMENTS_LIST))
end)