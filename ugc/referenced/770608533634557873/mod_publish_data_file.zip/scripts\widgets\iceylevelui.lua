local Widget = require "widgets/widget" --Widget，所有widget的祖先类
local Text = require "widgets/text" --Text类，文本处理
local TextButton = require "widgets/textbutton"
local Image = require "widgets/image"
local ImageButton = require "widgets/imagebutton"
local UIAnim = require "widgets/uianim"
local INTRODUCE = "鼠标放在本控件上\n按空格键调整大小\n鼠标按住拖动位置" 

local IceyUtil = require("icey_util")



local IceyLevelUi = Class(Widget, function(self,owner) 
	
	Widget._ctor(self, "IceyUi") 
	self.owner = owner
	self.scale = 1.07
	
	self:SetPosition(196,620,0)
	self:SetScale(self.scale,self.scale,self.scale)
	
	local width,heigth = TheSim:GetScreenSize()
	
	local function ChangeLevelUi()-----显示/隐藏护盾等级经验值的显示板
		if self.level_text.shown then 
			local text = (TUNING.ICEY_LANGUAGE == "chinese" and "显示" ) or (TUNING.ICEY_LANGUAGE == "english" and "Show" )
			self.hideui_button:SetText(text)
			self.level_text:Hide()
			self.exp_text:Hide()
			self.shield:Hide()
			self.level:Hide()
		else
			local text = (TUNING.ICEY_LANGUAGE == "chinese" and "隐藏" ) or (TUNING.ICEY_LANGUAGE == "english" and "Hide" )
			self.hideui_button:SetText(text)
			self.level_text:Show()
			self.exp_text:Show()
			self.shield:Show()
			self.level:Show() 
		end
	end
	
	-------护盾显示界面的背景
	self.level = self:AddChild(Image("images/level.xml","level.tex"))
	self.level:SetScale(0.6,0.6,0.6)
--[[	self.level:SetHAnchor(1) -- 设置原点x坐标位置，0、1、2分别对应屏幕中、左、右
	self.level:SetVAnchor(1) -- 设置原点y坐标位置，0、1、2分别对应屏幕中、上、下--]]
    --self.level:SetPosition(154,575,0) -- 设置ancientmac widget相对原点的偏移量，70，-50表明向右70，向下50，第三个参数无意义。
	self.level:SetTooltip(INTRODUCE)
	self.level:MoveToBack()
	
	-------等级数值
	self.level_text = self.level:AddChild(Text(BODYTEXTFONT, 42,(TUNING.ICEY_LANGUAGE == "chinese" and "等级:" ) or (TUNING.ICEY_LANGUAGE == "english" and "Level:" ))) --添加一个文本变量，接收Text实例。
	self.level_text:SetColour(0/255,131/255,255/255,1)
    self.level_text:SetPosition(0,48,0) 
	
	-------经验数值
	self.exp_text = self.level:AddChild(Text(BODYTEXTFONT, 42,(TUNING.ICEY_LANGUAGE == "chinese" and "经验:" ) or (TUNING.ICEY_LANGUAGE == "english" and "Exp:" ))) --添加一个文本变量，接收Text实例。
	self.exp_text:SetColour(0/255,131/255,255/255,1)
    self.exp_text:SetPosition(0,0,0) 
	
	-------护盾值数值
	self.shield = self.level:AddChild(Text(BODYTEXTFONT, 42,(TUNING.ICEY_LANGUAGE == "chinese" and "护盾:" ) or (TUNING.ICEY_LANGUAGE == "english" and "Shield:" ))) --添加一个文本变量，接收Text实例。
	self.shield:SetColour(0/255,131/255,255/255,1)
    self.shield:SetPosition(0,-48,0) 
	
--[[	self.hideui_button = self:AddChild(TextButton("hideui_button"))
	self.hideui_button:SetText((TUNING.ICEY_LANGUAGE == "chinese" and "隐藏" ) or (TUNING.ICEY_LANGUAGE == "english" and "Hide" ))
	self.hideui_button:SetColour(0/255,131/255,255/255,1)
	self.hideui_button:SetHAnchor(1) 
	self.hideui_button:SetVAnchor(1) 
    self.hideui_button:SetPosition(30,-20,0) 
	self.hideui_button:SetOnClick(ChangeLevelUi)--]]
	
	self:MoveToBack()
	self:StartUpdating()
	


	IceyUtil.MakeDragableUI(self) 
end)

----------------嘿！下面是我自己的！
function IceyLevelUi:OnUpdate(dt)
	local current = self.owner.replica.icey_shield:GetCurrent()
	local max = self.owner.replica.icey_shield:GetMax()
	local percent = self.owner.replica.icey_shield:GetPercent()
	
	local level = self.owner.replica.icey_level:GetLevel()
	local max_level = self.owner.replica.icey_level:GetMaxLevel()
	local exp = self.owner.replica.icey_level:GetExp()
	local max_exp = self.owner.replica.icey_level:GetMaxExp()
	
	
	local str = ((TUNING.ICEY_LANGUAGE == "chinese" and "护盾值:" ) or (TUNING.ICEY_LANGUAGE == "english" and "Shield:" ))..math.floor(current).."/"..max
	if current <= 0.5 then 
		str = (TUNING.ICEY_LANGUAGE == "chinese" and "警告:护盾告急" ) or (TUNING.ICEY_LANGUAGE == "english" and "Out of Shield" )	
	end
	self.shield:SetString(str)
	self.shield:SetColour((1 - percent)*237/255,(103 * percent + 28)/255,(227 * percent + 28)/255,1)
	self.level_text:SetString(((TUNING.ICEY_LANGUAGE == "chinese" and "等级:" ) or (TUNING.ICEY_LANGUAGE == "english" and "Level:" ))..level)
	if level ~= max_level then 
		self.exp_text:SetString(((TUNING.ICEY_LANGUAGE == "chinese" and "经验:" ) or (TUNING.ICEY_LANGUAGE == "english" and "Exp:" ))..math.floor(exp).."/"..max_exp)
	else 
		self.exp_text:SetString((TUNING.ICEY_LANGUAGE == "chinese" and "等级已到达上限" ) or (TUNING.ICEY_LANGUAGE == "english" and "Exp:Max" ))
	end 
end

return IceyLevelUi 