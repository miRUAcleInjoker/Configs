local IceyUtil = require("icey_util")

local function TickTask(inst)
	local target = inst.components.darksouldebuff.target
	local buffname = inst.components.darksouldebuff.name
	if target and target:IsValid() then 
		if target.components.hunger and inst.hunger_delta_tick then 
			target.components.hunger:DoDelta(inst.hunger_delta_tick,true)
		end
		
		if target.components.health and not target.components.health:IsDead() and inst.health_delta_tick then 
			target.components.health:DoDelta(inst.health_delta_tick,true,buffname,nil,nil,true)
		end
		
		if target.components.sanity and inst.sanity_delta_tick then 
			target.components.sanity:DoDelta(inst.sanity_delta_tick,true)
		end
		
		if target.components.stamina and inst.stamina_delta_tick then 
			target.components.stamina:DoDelta(inst.stamina_delta_tick)
		end
		
		if target.components.focus and inst.focus_delta_tick then 
			target.components.focus:DoDelta(inst.focus_delta_tick)
		end
	end
end 


local function ApplyDebuff(inst,target)
	local buffname = inst.components.darksouldebuff.name
	if target.components.combat then
		target.components.combat.externaldamagemultipliers:SetModifier(inst,inst.damage_multi,buffname)
		target.components.combat.externaldamagetakenmultipliers:SetModifier(inst,inst.damagetaken_multi,buffname)
	end 
			
	if target.components.hunger then
		target.components.hunger.burnratemodifiers:SetModifier(inst,inst.hunger_multi,buffname)
	end 
			
	if target.components.sanity then 
		target.components.sanity.externalmodifiers:SetModifier(inst,inst.sanity_additive,buffname)
	end 
			
	if target.components.locomotor then 
		target.components.locomotor:SetExternalSpeedMultiplier(inst,buffname,inst.speed_multi)
	end 
			
	if target.components.stamina then 
		target.components.stamina.externalrecoverratemultipliers:SetModifier(inst,inst.stamina_recover_multi,buffname)
		target.components.stamina.externalconsumeratemultipliers:SetModifier(inst,inst.stamina_consume_multi,buffname)
	end 
		
	if target.components.focus then 
		target.components.focus.externalmodifiers:SetModifier(inst,inst.focus_additive,buffname)
	end 	

	if buffname == "poison" then 
		inst.buff_fx = target:SpawnChild("poisonbubble")
		
	elseif buffname == "strong_poison" then 
		inst.buff_fx = target:SpawnChild("poisonbubble")
	elseif buffname == "bleeds" then 
		inst.buff_fx = target:SpawnChild("blood_hit_fx_icey")
		inst.buff_fx.AnimState:SetMultColour(196/255,0,0,1)
	end
	
	if inst.ticktask then 
		inst.ticktask:Cancel()
		inst.ticktask = nil 
	end
	inst.ticktask = inst:DoPeriodicTask(0,TickTask)
end 

local function RemoveDebuff(inst,target)
	local buffname = inst.components.darksouldebuff.name
	if target.components.combat then
		target.components.combat.externaldamagemultipliers:RemoveModifier(inst,buffname)
		target.components.combat.externaldamagetakenmultipliers:RemoveModifier(inst,buffname)
	end 
	
	if target.components.hunger then
		target.components.hunger.burnratemodifiers:RemoveModifier(inst,buffname)
	end 
	
	if target.components.sanity then 
		target.components.sanity.externalmodifiers:RemoveModifier(inst,buffname)
	end 
	
	if target.components.locomotor then 
		target.components.locomotor:RemoveExternalSpeedMultiplier(inst,buffname)
	end 
	
	if target.components.stamina then 
		target.components.stamina.externalrecoverratemultipliers:RemoveModifier(inst,buffname)
		target.components.stamina.externalconsumeratemultipliers:RemoveModifier(inst,buffname)
	end 
	
	if target.components.focus then 
		target.components.focus.externalmodifiers:RemoveModifier(inst,buffname)
	end 	
	
	if inst.buff_fx and inst.buff_fx:IsValid() then 
		if inst.buff_fx.KillFX then 
			inst.buff_fx:KillFX()
		else
			inst.buff_fx:Remove() 
		end
	end
	inst.buff_fx = nil 
	
	if buffname == "poison" then 
		
	elseif buffname == "strong_poison" then 

	end
	
	if inst.ticktask then 
		inst.ticktask:Cancel()
		inst.ticktask = nil 
	end
end 

local function OnAttached(inst, target)
    inst.entity:SetParent(target.entity)
	--[[if target.sg then 
		target.sg:GoToState("powerup")
	end --]]
	
    inst:ListenForEvent("death", function()
        inst.components.darksouldebuff:Stop()
    end, target)
	
	--inst.buff_fx = target:SpawnChild("battlestandard_buff_fxs")
	--inst.buff_fx:Play("defend_fx")
end

local function OnDetached(inst, target)
	RemoveDebuff(inst,target)
	inst:Remove()
end


local function OnExtended(inst, target)
	if inst.components.darksouldebuff:IsActivated() then 
		RemoveDebuff(inst,target)
		inst:DoTaskInTime(0,function()
			ApplyDebuff(inst,target)
		end)
	end 
end

local function OnActivated(inst,target)
	inst:DoTaskInTime(0,function()
		ApplyDebuff(inst,target)
	end)
end 

local function OnSave(inst,data)
	--data.buffname = inst.buffname 
	--data.buff_fx = inst.buff_fx
	--data.duration = inst.duration 
	data.damage_multi = inst.damage_multi 
	data.damagetaken_multi = inst.damagetaken_multi 
	data.hunger_multi = inst.hunger_multi 
	data.sanity_additive = inst.sanity_additive 
	data.speed_multi = inst.speed_multi
	data.stamina_recover_multi = inst.stamina_recover_multi 
	data.stamina_consume_multi = inst.stamina_consume_multi 
	data.focus_additive = inst.focus_additive 
	data.health_delta_tick = inst.health_delta_tick 
	data.hunger_delta_tick = inst.hunger_delta_tick 
	data.sanity_delta_tick = inst.sanity_delta_tick 
	data.stamina_delta_tick = inst.stamina_delta_tick 
	data.focus_delta_tick = inst.focus_delta_tick 
	data.keepondespawn = inst.keepondespawn 
	--data.type = inst.type
end 

local function OnLoad(inst,data)
	data = data or {} 
	--[[inst.buffname = data.buffname or inst.prefab 
	--inst.buff_fx = data.buff_fx
	inst.duration = data.duration or 15 
	inst.damage_multi = data.damage_multi or 1
	inst.damagetaken_multi = data.damagetaken_multi or 1
	inst.hunger_multi = data.hunger_multi or 1
	inst.sanity_additive = data.sanity_additive or 0 
	inst.speed_multi = data.speed_multi or 1
	inst.stamina_recover_multi = data.stamina_recover_multi or 1
	inst.stamina_consume_multi = data.stamina_consume_multi or 1
	inst.focus_additive = data.focus_additive or 0
	inst.percent = data.percent or 1
	inst.health_delta_tick = data.health_delta_tick 
	inst.hunger_delta_tick = data.hunger_delta_tick
	inst.sanity_delta_tick = data.sanity_delta_tick 
	inst.type = data.type --]]
	inst:Init(data)
end 


local function DefaultReplicaFn(inst)
	local parent = inst.entity:GetParent() 
	--print(inst,"DefaultReplicaFn",parent,parent.HUD.controls.DarkSoulDebuffList)
	if parent and parent:IsValid() and parent.HUD and parent.HUD.controls and parent.HUD.controls.DarkSoulDebuffList then 
		local name = inst.replica.darksouldebuff:GetName()
		local percent = inst.replica.darksouldebuff:GetPercent()
		local activated = inst.replica.darksouldebuff:IsActivated()
		parent.HUD.controls.DarkSoulDebuffList:AddBuff(name,inst,percent,activated)
	end
end 

local function OnTargetDirty(inst)
	DefaultReplicaFn(inst)
end 

local function OnPercentDirty(inst)
	DefaultReplicaFn(inst)
end 

local function OnActivatedDirty(inst)
	DefaultReplicaFn(inst)
	local parent = inst.entity:GetParent() 
	local buffname = inst.replica.darksouldebuff:GetName()
	local activated = inst.replica.darksouldebuff:IsActivated()
	if activated then 
		if buffname == "poison" then 
			parent:PushEvent("startcorrosivedebuff", inst)
		elseif buffname == "strong_poison" then 
			parent:PushEvent("startcorrosivedebuff", inst)
		end 
	end 	
end 

local function fn(inst)
	local inst = CreateEntity()
	local trans = inst.entity:AddTransform()
	inst.entity:AddNetwork()
	inst.entity:AddAnimState()
	inst.entity:AddSoundEmitter()

	inst:AddTag("CLASSIFIED")
	
	
	
	

	--inst:DoTaskInTime(0,NetInit)
	--inst._activated = net_bool(inst.GUID,"inst._activated","onactivateddirty")
	--inst._type = net_string(inst.GUID,"inst._type","ontypedirty")
	
	--inst:DoPeriodicTask(0,DefaultReplicaFn)
	
	--if TheNet:GetIsClient() then 
	if not TheNet:IsDedicated() then 
		inst:ListenForEvent("ontargetdirty",OnTargetDirty)
		inst:ListenForEvent("onpercentdirty",OnPercentDirty)
		inst:ListenForEvent("onactivateddirty",OnActivatedDirty)
	end 
	
	
	inst.entity:SetPristine()

    if not TheWorld.ismastersim then
		--inst:ListenForEvent("ontypedirty",NetInit)
		--inst:ListenForEvent("ontargetdirty",OnTargetDirty)
		--inst:ListenForEvent("onpercentdirty",OnPercentDirty)
		--inst:ListenForEvent("onactivateddirty",OnActivatedDirty)
        return inst
    end
	
	inst.Init = function(self,data)
		if data then 
			--inst.buffname = data.buffname or inst.prefab 
			inst.buff_fx = data.buff_fx 									--buff��Ч
			inst.damage_multi = data.damage_multi or 1 						--�˺�����
			inst.damagetaken_multi = data.damagetaken_multi or 1			--�ܵ��˺�����
			inst.hunger_multi = data.hunger_multi or 1						--��������
			inst.sanity_additive = data.sanity_additive or 0 				--����ָ��ӳ�
			inst.speed_multi = data.speed_multi or 1						--�ƶ��ٶȼӳ�
			inst.stamina_recover_multi = data.stamina_recover_multi or 1	--����ֵ�ָ�����
			inst.stamina_consume_multi = data.stamina_consume_multi or 1	--����ֵ��������
			inst.focus_additive = data.focus_additive or 0					--רע�ӳ�
			
			inst.health_delta_tick = data.health_delta_tick 				--ÿ֡�����仯
			inst.hunger_delta_tick = data.hunger_delta_tick 				--ÿ֡�����仯
			inst.sanity_delta_tick = data.sanity_delta_tick 				--ÿ֡����仯
			
			inst.stamina_delta_tick = data.stamina_delta_tick 				--ÿ֡�����仯
			inst.focus_delta_tick = data.focus_delta_tick 					--ÿ֡רע�仯
						
			inst.keepondespawn = data.keepondespawn 						--�Ƿ񱣴�
			
			
			--[[inst.type = data.type
			if inst.type then 
				inst._type:set_local(inst.type)
				inst._type:set(inst.type)
			end --]]
		end 
		
		inst.components.darksouldebuff.keepondespawn = inst.keepondespawn
		
		if data.decrease_rate then 
			inst.components.darksouldebuff.decrease_rate = data.decrease_rate --��������(δ����ʱ)
		end 
		
		if data.decrease_rate_activated then 
			inst.components.darksouldebuff.decrease_rate_activated = data.decrease_rate_activated --��������(����ʱ)
		end 

	end 
	
    inst:AddComponent("darksouldebuff")
    inst.components.darksouldebuff:SetAttachedFn(OnAttached)
    inst.components.darksouldebuff:SetDetachedFn(OnDetached)
    inst.components.darksouldebuff:SetExtendedFn(OnExtended)
	inst.components.darksouldebuff:SetActivatedFn(OnActivated)
    --inst.components.darksouldebuff.keepondespawn = true

	
	inst:Init({})
	
	inst.OnSave = OnSave
	inst.OnLoad = OnLoad 
	
	return inst
	
end
--ThePlayer.components.darksouldebuffable:AddDebuff("pyromancy_iron_flesh_debuff", "pyromancy_iron_flesh_debuff")
return Prefab("icey_normal_darksouldebuff", fn)