require "behaviours/follow"
require "behaviours/wander"
require "behaviours/standstill"

local IceyPodBrain = Class(Brain, function(self, inst)
    Brain._ctor(self, inst)
end)

local MIN_FOLLOW = 1
local MAX_FOLLOW = 1
local MED_FOLLOW = 1
local MAX_CHASE_TIME = 6

function IceyPodBrain:OnStart()
    local root = PriorityNode(
    {
        --Follow(self.inst, function() return self.inst.components.follower.leader end, MIN_FOLLOW, MED_FOLLOW, MAX_FOLLOW, true),
        --Wander(self.inst),
		StandStill(self.inst),
    }, .1)

    self.bt = BT(self.inst, root)
end

return IceyPodBrain
