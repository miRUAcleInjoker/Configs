local brain = require "brains/ancientheraldbrain"
--require "stategraphs/SGancientherald"

local assets =
{
    Asset("ANIM", "anim/ancient_spirit.zip"),
}

local prefabs =
{
    
}

local TARGET_DIST = 30

local function PushMusic(inst)
    if ThePlayer == nil then
        inst._playingmusic = false
    elseif ThePlayer:IsNear(inst, inst._playingmusic and 40 or 20) then
        inst._playingmusic = true
        ThePlayer:PushEvent("triggeredevent", { name = "default" })
    elseif inst._playingmusic and not ThePlayer:IsNear(inst, 50) then
        inst._playingmusic = false
    end
end

local function auratestfn(inst,target)
	local histarget = target.components.combat.target
	return target:HasTag("player") or (histarget and histarget:HasTag("tadalin"))
end 

local function CalcSanityAura(inst, observer)
    
    if inst.components.combat.target then
        return -TUNING.SANITYAURA_HUGE/3
    else
        return -TUNING.SANITYAURA_LARGE/3
    end
    
    return 0
end

local function RetargetFn(inst)
    return FindEntity(inst, TARGET_DIST, function(guy)
        return inst.components.combat:CanTarget(guy)
               and not guy:HasTag("prey")
               and not guy:HasTag("smallcreature")
			   and not guy:HasTag("tadalin")
			   and not guy:HasTag("structure")
    end)
end


local function KeepTargetFn(inst, target)
    return inst.components.combat:CanTarget(target)
			   and not target:HasTag("tadalin")
end


local function OnAttacked(inst, data)
	inst.components.combat:SetTarget(data.attacker)
	inst.components.combat:ShareTarget(data.attacker, 30, function(dude)
        return  dude:HasTag("tadalin")
            and not dude.components.health:IsDead()
    end, 10)
end

local function oncollide(inst, other)
    if not other:HasTag("tree") then return end
    
    local v1 = Vector3(inst.Physics:GetVelocity())
    if v1:LengthSq() < 1 then return end

    inst:DoTaskInTime(2*FRAMES, function()
        if other and other.components.workable and other.components.workable.workleft > 0 then
            SpawnPrefab("collapse_small").Transform:SetPosition(other:GetPosition():Get())
            other.components.workable:Destroy(inst)
        end
    end)

end

local function ontimerdone(inst,data)
	local skillname = data.name
	inst[skillname] = true 
end 

local function onskilluse(inst,data)
	local skillname = data.name
	local skillcd = data.cd
	inst[skillname] = false 
	
	inst.components.timer:StartTimer(skillname,skillcd)
end 

local function EnterPhase2Trigger(inst) -------寮€濮嬩娇鐢ㄥザ鏉?
	if inst.phaselevel <= 1 then 
		inst.SummonSkill = true 
		inst.phaselevel = 2
	end 
	inst.components.combat:SetAttackPeriod(3)
end 

local function EnterPhase3Trigger(inst) -------寮€濮嬪彫鍞ゅ湴鐙辩伀
	if inst.phaselevel <= 2 then
		inst.SummonSpikes = true 
		inst.phaselevel = 3
	end 
	inst.components.combat:SetAttackPeriod(2)
end 

local function EnterPhase4Trigger(inst) -------寮€濮嬪彫鍞ゅ個鍎?
	if inst.phaselevel <= 3 then 
		inst.SummonMeteor = true 
		inst.phaselevel = 4
	end 
	inst.components.combat:SetAttackPeriod(2)
end 

local loot = {}

local function fn(Sim)
    
    local inst = CreateEntity()
    local trans = inst.entity:AddTransform()
    local anim = inst.entity:AddAnimState()
    local sound = inst.entity:AddSoundEmitter()
    local shadow = inst.entity:AddDynamicShadow()
	inst.entity:AddNetwork()
    
    local s  = 1.25
    inst.Transform:SetScale(s,s,s)
    -- shadow:SetSize( 6, 3.5 )
    trans:SetSixFaced()

    --MakeCharacterPhysics(inst, 1000, .5)
    --inst.Physics:SetCollisionCallback(oncollide)
	MakeCharacterPhysics(inst, 10, 1.6)
    RemovePhysicsColliders(inst)
    inst.Physics:SetCollisionGroup(COLLISION.SANITY)
    inst.Physics:CollidesWith(COLLISION.WORLD)

    inst:AddTag("epic")
	inst:AddTag("noepicmusic")
    inst:AddTag("monster")
    inst:AddTag("hostile")
    inst:AddTag("ancient")
    inst:AddTag("scarytoprey")
    inst:AddTag("largecreature")
	inst:AddTag("tadalin")

    anim:SetBank("ancient_spirit")
    anim:SetBuild("ancient_spirit")
    anim:PlayAnimation("idle", true)
	
	inst._playingmusic = false
	if not TheNet:IsDedicated() then
        inst:DoPeriodicTask(1, PushMusic,0)
    end
	
	
	inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.SummonSkill = false
	inst.SummonSpikes = false
	inst.SummonMeteor = false
    inst.phaselevel = 1
    ------------------------------------------

    inst:AddComponent("locomotor") -- locomotor must be constructed before the stategraph
    inst.components.locomotor.walkspeed = 4
    inst.components.locomotor.runspeed = 5
    --inst.components.locomotor.directdrive = true
    
    ------------------------------------------
    inst:SetStateGraph("SGancientherald")
    inst:SetBrain(brain)

    ------------------------------------------

    inst:AddComponent("sanityaura")
    inst.components.sanityaura.aurafn = CalcSanityAura


    ------------------
    inst:AddComponent("health")
    inst.components.health:SetMaxHealth(8000)
	inst.components.health.destroytime = 3
    ------------------
    
    inst:AddComponent("combat")
    inst.components.combat:SetDefaultDamage(150)
    inst.components.combat.playerdamagepercent = .5
    inst.components.combat:SetRange(6)
    inst.components.combat:SetAreaDamage(2, 0.8)
    -- inst.components.combat.hiteffectsymbol = "deerclops_body"
    inst.components.combat:SetAttackPeriod(4)
    inst.components.combat:SetRetargetFunction(3, RetargetFn)
    inst.components.combat:SetKeepTargetFunction(KeepTargetFn)
	
	inst:AddComponent("aura")
	inst.components.aura.radius = 6
	inst.components.aura.auraexcludetags = {"INLIMBO","noauradamage","tadalin"}
	inst.components.aura.auratestfn = auratestfn
    
    ------------------------------------------

    inst:AddComponent("lootdropper")
    inst.components.lootdropper:SetLoot(loot)
    
    ------------------------------------------

    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("看，是那位堕落的贤者!")
    ------------------------------------------
	
	inst:AddComponent("timer")
    
	inst:AddComponent("healthtrigger")
	inst.components.healthtrigger:AddTrigger(0.75, EnterPhase2Trigger)
	inst.components.healthtrigger:AddTrigger(0.50, EnterPhase3Trigger)
	inst.components.healthtrigger:AddTrigger(0.25, EnterPhase4Trigger)
	
    inst:ListenForEvent("attacked", OnAttacked)
	inst:ListenForEvent("timerdone", ontimerdone)
	inst:ListenForEvent("use_herald_skill",onskilluse)
    return inst
end

return Prefab( "common/monsters/ancient_herald", fn, assets, prefabs) 
