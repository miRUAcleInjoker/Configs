local assets =
{
    --Asset("ANIM", "anim/nightmarefuel.zip"),
}


local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()
	inst.entity:AddSoundEmitter()

    --MakeInventoryPhysics(inst)

    --inst.AnimState:SetBank("deer_ice_charge")
    --inst.AnimState:SetBuild("deer_ice_charge")
	--inst.AnimState:PlayAnimation("pre")
	--inst.AnimState:PushAnimation("loop",true)
	--inst.AnimState:SetFinalOffset(3)
    --inst.AnimState:SetMultColour(1, 1, 1, 0.5)
	
	--inst.Transform:SetScale(0.1,0.1,0.1)

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	--inst.SoundEmitter:PlaySound("dontstarve/creatures/together/deer/fx/charge_LP","charge_LP")
	
	inst:DoTaskInTime(3,function()
		local pos = inst:GetPosition()
		local prefx = SpawnPrefab("tadalin_meteor")
		prefx.Transform:SetPosition(pos:Get())
	end)
	
	inst:DoTaskInTime(3.5,function()
		local pos = inst:GetPosition()
		local boss = SpawnPrefab("moon_giaour")
		boss.Transform:SetPosition(pos:Get())
		inst:Remove()
		--boss.sg:GoToState("taunt")
	end)
	
	
    return inst
end

return Prefab("moon_giaour_prefx", fn, assets)
