local assets =
{
    Asset("ANIM", "anim/lavaarena_item_pickup_fx.zip"),
}

local INTENSITY = .5
--local FRAMES = 0.01

local function randomizefadein()
    return math.random(1, 31)
end

local function randomizefadeout()
    return math.random(32, 63)
end

local function immediatefadeout()
    return 0
end

local function resolvefaderate(x)
    --immediate fadeout -> 0
    --randomize fadein -> INTENSITY * FRAMES / (3 + math.random() * 2)
    --randomize fadeout -> -INTENSITY * FRAMES / (.75 + math.random())
    return (x == 0 and 0)
        or (x < 32 and INTENSITY * FRAMES / (3 + (x - 1) / 15))
        or INTENSITY * FRAMES / ((32 - x) / 31 - .75)
end

local function updatefade(inst, rate)
    inst._fadeval:set_local(math.clamp(inst._fadeval:value() + rate, 0, INTENSITY))

    --Client light modulation is enabled:
    inst.Light:SetIntensity(inst._fadeval:value())

    if rate == 0 or
        (rate < 0 and inst._fadeval:value() <= 0) or
        (rate > 0 and inst._fadeval:value() >= INTENSITY) then
        inst._fadetask:Cancel()
        inst._fadetask = nil
        if inst._fadeval:value() <= 0 and TheWorld.ismastersim then
            inst:AddTag("NOCLICK")
            inst.Light:Enable(false)
        end
    end
end

local function fadein(inst)
    local ismastersim = TheWorld.ismastersim
    if not ismastersim or resolvefaderate(inst._faderate:value()) <= 0 then
        if ismastersim then
            inst:RemoveTag("NOCLICK")
            inst.Light:Enable(true)
            --inst.AnimState:PlayAnimation("swarm_pre")
            --inst.AnimState:PushAnimation("swarm_loop", true)
            inst._faderate:set(randomizefadein())
        end
        if inst._fadetask ~= nil then
            inst._fadetask:Cancel()
        end
        local rate = resolvefaderate(inst._faderate:value()) * math.clamp(1 - inst._fadeval:value() / INTENSITY, 0, 1)
        inst._fadetask = inst:DoPeriodicTask(FRAMES, updatefade, nil, rate)
        if not ismastersim then
            updatefade(inst, rate)
        end
    end
end

local function fadeout(inst)
    local ismastersim = TheWorld.ismastersim
    if not ismastersim or resolvefaderate(inst._faderate:value()) > 0 then
        if ismastersim then
            --inst.AnimState:PlayAnimation("swarm_pst")
            inst._faderate:set(randomizefadeout())
        end
        if inst._fadetask ~= nil then
            inst._fadetask:Cancel()
        end
        local rate = resolvefaderate(inst._faderate:value()) * math.clamp(inst._fadeval:value() / INTENSITY, 0, 1)
        inst._fadetask = inst:DoPeriodicTask(FRAMES, updatefade, nil, rate)
        if not ismastersim then
            updatefade(inst, rate)
        end
    end
end

local function OnFadeRateDirty(inst)
    local rate = resolvefaderate(inst._faderate:value())
    if rate > 0 then
        fadein(inst)
    elseif rate < 0 then
        fadeout(inst)
    elseif inst._fadetask ~= nil then
        inst._fadetask:Cancel()
        inst._fadetask = nil
        inst._fadeval:set_local(0)

        --Client light modulation is enabled:
        inst.Light:SetIntensity(0)
    end
end

local function updatelight(inst)
	fadein(inst)
end

local function ondropped(inst)
    inst._fadeval:set(0)
    inst._faderate:set_local(immediatefadeout())
    fadein(inst)
    inst:DoTaskInTime(0, updatelight)
end

local function onpickup(inst)
    if inst._fadetask ~= nil then
        inst._fadetask:Cancel()
        inst._fadetask = nil
    end
    inst._fadeval:set_local(0)
    inst._faderate:set(immediatefadeout())
    inst.Light:SetIntensity(0)
    inst.Light:Enable(false)
end


local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
	inst.entity:AddLight()
    inst.entity:AddNetwork()
	
    inst.Light:SetFalloff(1)
    inst.Light:SetIntensity(INTENSITY)
    inst.Light:SetRadius(1)
    inst.Light:SetColour(180/255, 195/255, 150/255)
    inst.Light:SetIntensity(0)
    inst.Light:Enable(false)
    inst.Light:EnableClientModulation(true)
	
	

    inst.AnimState:SetBank("lavaarena_item_pickup_fx")
    inst.AnimState:SetBuild("lavaarena_item_pickup_fx")
    inst.AnimState:SetBloomEffectHandle("shaders/anim.ksh")
    inst.AnimState:SetFinalOffset(1)

    inst:AddTag("DECOR")
    inst:AddTag("NOCLICK")
	inst:AddTag("cattoyairborne")

    inst._fadeval = net_float(inst.GUID, "fireflies._fadeval")
    inst._faderate = net_smallbyte(inst.GUID, "fireflies._faderate", "onfaderatedirty")
    inst._fadetask = nil

    inst:Hide()

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        inst:ListenForEvent("onfaderatedirty", OnFadeRateDirty)
        return inst
    end
	
	inst.colour = 0
	inst.forever = false
	inst.canaddcolour = true
	inst.persists = false 
	
	--inst.SoundEmitter:PlaySound("dontstarve/wilson/equip_item_gold")
	local function ontargetpickedup(target, data)
		target.AnimState:SetAddColour(0,0,0,1)
		target:RemoveEventCallback("onpickup", ontargetpickedup)
		target:RemoveEventCallback("equipped", ontargetpickedup)
		if inst ~= nil then
			inst.AnimState:PlayAnimation("pst")
			inst:ListenForEvent("animover", inst.Remove)
			if inst._timeouttask ~= nil then
				inst._timeouttask:Cancel()
			end
			if inst._colourfadetask ~= nil then
				inst._colourfadetask:Cancel()
			end
			if inst._colourtask ~= nil then
				inst._colourtask:Cancel()
			end
			if inst._followtask ~= nil then
				inst._followtask:Cancel()
			end
			target.lootbeacon = nil
			fadeout(inst)
		end
	end
	inst.SetTarget = function(inst, target)
		inst.target = target
		target.lootbeacon = inst
		inst:Show()
		inst.AnimState:PlayAnimation("pre")
		inst.AnimState:PushAnimation("loop")
		target:ListenForEvent("onpickup", ontargetpickedup)
		target:ListenForEvent("equipped", ontargetpickedup)
		
		inst._followtask = inst:DoPeriodicTask(0, function(inst) 
			if inst.target ~= nil then
				inst.Transform:SetPosition(target:GetPosition():Get())
			else
				inst._followtask:Cancel()
				inst._followtask = nil
			end
		end)
		
		inst._colourtask = inst:DoPeriodicTask(0, function(inst)
			if inst.colour < 0.5 then
				if inst.canaddcolour then
					target.AnimState:SetAddColour(inst.colour, inst.colour, inst.colour,1)
				end 
				inst.colour = inst.colour + 0.05
			else
				inst._colourtask:Cancel()
				inst._colourtask = nil
			end
		end)
		
		if not inst.forever then
			inst._timeouttask = inst:DoTaskInTime(10, function(inst)
				inst.AnimState:PlayAnimation("pst")
				inst._colourfadetask = inst:DoPeriodicTask(0, function(inst)
					if inst.colour > 0 then
						if inst.canaddcolour then
							inst.target.AnimState:SetAddColour(inst.colour, inst.colour, inst.colour,1)
						end 
						inst.colour = inst.colour - 0.05
					else
						inst.target.AnimState:SetAddColour(0,0,0,1)
						inst:Remove()
					end
				end)
			end)
		end 
	end
	
	inst:DoTaskInTime(0,function()
		if not inst.target then 
			inst:Remove()
		end
	end)
	inst:ListenForEvent("onremove", function() if inst.target ~= nil then inst.target.AnimState:SetAddColour(0,0,0,1) end end)
		

	updatelight(inst)
	
    return inst
end

return Prefab("icey_lootbeacon", fn, assets)
