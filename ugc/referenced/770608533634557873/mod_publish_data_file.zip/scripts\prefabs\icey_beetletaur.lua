local assets =
{
    Asset("ANIM", "anim/lavaarena_beetletaur.zip"),
    Asset("ANIM", "anim/lavaarena_beetletaur_basic.zip"),
    Asset("ANIM", "anim/lavaarena_beetletaur_actions.zip"),
    Asset("ANIM", "anim/lavaarena_beetletaur_block.zip"),
    Asset("ANIM", "anim/lavaarena_beetletaur_fx.zip"),
    Asset("ANIM", "anim/lavaarena_beetletaur_break.zip"),
    Asset("ANIM", "anim/healing_flower.zip"),
    Asset("ANIM", "anim/fossilized.zip"),
}

local prefabs =
{
    "fossilizing_fx",
    "beetletaur_fossilized_break_fx_right",
    "beetletaur_fossilized_break_fx_left",
    "beetletaur_fossilized_break_fx_left_alt",
    "beetletaur_fossilized_break_fx_alt",
    "lavaarena_creature_teleport_medium_fx",
}

local brain = require("brains/boarriorbrain")

local function PushMusic(inst)
    if ThePlayer == nil then
        inst._playingmusic = false
    elseif ThePlayer:IsNear(inst, inst._playingmusic and 40 or 20) then
		--print(inst,ThePlayer,"Push the triggeredevent at",GetTime())
        inst._playingmusic = true
        ThePlayer:PushEvent("triggeredevent", { name = "icey_boarrior" ,duration = 3})
    elseif inst._playingmusic and not ThePlayer:IsNear(inst, 50) then
        inst._playingmusic = false
    end
end

local function oncollapse(inst, other)
    if other:IsValid() and other.components.workable ~= nil and other.components.workable:CanBeWorked() then
        SpawnPrefab("collapse_small").Transform:SetPosition(other.Transform:GetWorldPosition())
        other.components.workable:Destroy(inst)
    end
end

local function oncollide(inst, other)
    if other ~= nil and --HasTag implies IsValid
        Vector3(inst.Physics:GetVelocity()):LengthSq() >= 1 then
        inst:DoTaskInTime(2 * FRAMES, oncollapse, other)
    end
end

local function OnNewTarget(inst, data)
    if inst.components.sleeper:IsAsleep() then
        inst.components.sleeper:WakeUp()
    end
end

local function FindPlayerTarget(inst)
	local player, distsq = inst:GetNearestPlayer()
	if player then
		if not inst.components.follower.leader then --Don't attempt to find a target that isn't the leader's target. 
			return not (player:HasTag("notarget") or player:HasTag("LA_mob")) and (player and not player.components.health:IsDead()) and player
		end
	end
end

local function AttemptNewTarget(inst, target)
	local player, distsq = inst:GetNearestPlayer()
    if target ~= nil and inst:IsNear(target, 20) and player then
		return target
	else
		return not (player:HasTag("notarget") or player:HasTag("LA_mob")) and (player and not player.components.health:IsDead()) and player and player
	end
end

local function retargetfn(inst)
    local player, distsq = inst:GetNearestPlayer()
    return (player and not player.components.health:IsDead()) and player or FindEntity(inst, 255, function(guy) return inst.components.combat:CanTarget(guy) and not guy.components.health:IsDead() and inst.components.follower.leader ~= guy end, nil, { "tadalin","wall", "LA_mob", "battlestandard" })
end

local function KeepTarget(inst, target)
    return inst.components.combat:CanTarget(target) and (target.components.health and not target.components.health:IsDead()) and not target:HasTag("tadalin")
end

local function OnAttacked(inst, data)
    local foe = data.attacker or nil
    local target = inst.components.combat.target or nil
    if foe and not foe:HasTag("notarget") and not (inst.aggrotimer and inst.components.combat.lastwasattackedtime <= inst.aggrotimer) then
		inst.aggrotimer = nil
        local hands = foe.components.inventory and foe.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS) or nil
        local thands = target and target.components.inventory and target.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS) or nil
        if target and not foe:HasTag("lessaggro") and not (hands and (hands:HasTag("rangedweapon") or hands:HasTag("blowdart"))) then
            if data.stimuli and data.stimuli == "electric" then
				inst.aggrotimer = GetTime() + 2
                inst.components.combat:SetTarget(foe)
			elseif foe:HasTag("grabaggro") then
				inst.aggrotimer = GetTime() + 2
				inst.components.combat:SetTarget(foe)
			elseif hands and hands:HasTag("hammer") and not target:HasTag("companion") and not (target:HasTag("moreaggro") or foe:HasTag("lessaggro")) and not inst.sg:HasStateTag("attack") then
				--print("OnAttacked melee check PASSED")
				inst.components.combat:SetTarget(foe)
			elseif hands and (hands:HasTag("sharp") or hands:HasTag("pointy") or hands:HasTag("book")) and not (target:HasTag("moreaggro") or foe:HasTag("lessaggro")) and not (thands and thands:HasTag("hammer")) and not inst.sg:HasStateTag("attack") then
				--print("OnAttacked melee check PASSED")
				inst.components.combat:SetTarget(foe)
			elseif not hands and not (target:HasTag("moreaggro") or foe:HasTag("lessaggro")) and not inst.sg:HasStateTag("attack") then	
				inst.components.combat:SetTarget(foe)	
            end 
        elseif target and target:HasTag("moreaggro") and math.random(1, 100) > 90 then
            inst.components.combat:SetTarget(foe)   
        elseif not target then
            inst.components.combat:SetTarget(foe)
        end             
    end
	inst.components.combat:ShareTarget(data.attacker, 30, function(dude)
        return  (dude:HasTag("tadalin"))
            and not dude.components.health:IsDead()
            and dude.components.follower ~= nil
            and dude.components.follower.leader == inst.components.follower.leader
    end, 10)
end

-----------------------------------------------------

local function EnterPhase2Trigger(inst)
	inst.level = 1
	--inst.altattack = true
	inst.sg:GoToState("taunt")
end

local function EnterPhase3Trigger(inst)
	if inst.level < 2 then
		inst.level = 2
		--inst.altattack = true
		--inst.sg.statemem.wants_to_banner = true 
		--inst.sg:GoToState("banner_pre")
	end
end

local function EnterPhase4Trigger(inst)
	inst.level = 3
	inst.components.combat:SetAttackPeriod(3)
end

-------------------------------------------------------

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddDynamicShadow()
    inst.entity:AddNetwork()

    MakeCharacterPhysics(inst, 500, 1.5)

	inst.DynamicShadow:SetSize(5.25, 1.75)
    inst.Transform:SetFourFaced()

    inst:AddTag("hostile")
    inst:AddTag("epic")
    inst:AddTag("LA_mob")
	inst:AddTag("tadalin")
	inst:AddTag("noepicmusic")
	
    --inst:AddTag("fossilizable")

    inst.AnimState:SetBank("beetletaur")
    inst.AnimState:SetBuild("lavaarena_beetletaur")
    inst.AnimState:PlayAnimation("idle_loop", true)
	
	inst.AnimState:AddOverrideBuild("fossilized")
	
	--inst.nameoverride = "boarrior" --So we don't have to make the describe strings.
	
	if TheWorld.components.lavaarenamobtracker ~= nil then
        TheWorld.components.lavaarenamobtracker:StartTracking(inst)
    end
	
	inst._playingmusic = false
	if not TheNet:IsDedicated() then
        inst:DoPeriodicTask(1, PushMusic,0)
    end

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	--inst:AddComponent("fossilizable")
	
	inst.Physics:SetCollisionCallback(oncollide)
	
	

    inst:AddComponent("locomotor") -- locomotor must be constructed before the stategraph
	inst.components.locomotor.walkspeed = 6
    inst.components.locomotor.runspeed = 12
    inst:SetStateGraph("SGicey_beetletaur")

    inst:SetBrain(brain)

    inst:AddComponent("follower")

    inst:AddComponent("health")
    inst.components.health:SetMaxHealth(34000)
	--inst.components.health.nofadeout = true 
	inst.components.health.destroytime = 8

    inst:AddComponent("sanityaura")
    inst.components.sanityaura.aura = -TUNING.SANITYAURA_MED
	
	inst.damagetaken = 0
	inst.altattack = true
	inst.altattack2 = true
	inst.altattack3 = true
	inst.level = 0
	inst.knockback = 20

    inst:AddComponent("combat")
    inst.components.combat:SetDefaultDamage(150)
	inst.components.combat:SetRange(3.5,6)
	inst.components.combat.playerdamagepercent = 1
    inst.components.combat:SetAttackPeriod(3)
    inst.components.combat:SetRetargetFunction(2, retargetfn)
    inst.components.combat:SetKeepTargetFunction(KeepTarget)
	inst.components.combat.battlecryenabled = false
    --inst.components.combat:SetHurtSound("dontstarve/creatures/hound/hurt")
	
	inst:AddComponent("colouradder")
	
	--inst:AddComponent("colourfader")
	
	--[[inst:AddComponent("armorbreak_debuff")
	inst.components.armorbreak_debuff:SetFollowSymbol("head")--]]
	
    inst:AddComponent("lootdropper")
    --inst.components.lootdropper:SetChanceLootTable('hound')

    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("���....")

    inst:AddComponent("sleeper")
	
	inst:AddComponent("debuffable")
	
    MakeHauntablePanic(inst)
	
	MakeMediumBurnableCharacter(inst, "body")

	--inst.StartTrail = StartTrail
	--inst.EndTrail = EndTrail
	--inst.DoTrail = DoTrail
	
	--inst.components.combat.onhitotherfn = OnHitOther
	
	inst:AddComponent("healthtrigger")
	inst.components.healthtrigger:AddTrigger(0.75, EnterPhase2Trigger)
	inst.components.healthtrigger:AddTrigger(0.5, EnterPhase3Trigger)
	inst.components.healthtrigger:AddTrigger(0.25, EnterPhase4Trigger)
		
	--inst.AttemptNewTarget = AttemptNewTarget

	inst:DoTaskInTime(0.5, function(inst)
		local target = FindPlayerTarget(inst) or nil
		inst.components.combat:SetTarget(target)
	end)
    inst:ListenForEvent("attacked", OnAttacked)
    --inst:ListenForEvent("onattackother", OnAttackOther)

    return inst
end

return Prefab("icey_beetletaur", fn, assets, prefabs)