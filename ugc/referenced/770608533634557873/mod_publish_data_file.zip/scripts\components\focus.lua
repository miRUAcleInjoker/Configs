local easing = require("easing")
local SourceModifierList = require("util/sourcemodifierlist")

local function onmax(self, max)
    self.inst.replica.focus:SetMax(max)
end

local function oncurrent(self, current)
    self.inst.replica.focus:SetCurrent(current)
end

--Focus:רע�����������������ͷ�����ս��/����/�������漣

local Focus = Class(function(self, inst)
	self.inst = inst 
	self.max = 200
    self.current = self.max
	
	self.rate = 0
    self.ratescale = RATE_SCALE.NEUTRAL
    self.rate_modifier = 1
    self.dapperness = 0
	self.externalmodifiers = SourceModifierList(self.inst, 0, SourceModifierList.additive)

    self.night_drain_mult = 1
    self.neg_aura_mult = 1
    self.neg_aura_absorb = 0
    self.dapperness_mult = 1
	
	inst:StartUpdatingComponent(self)
end,
nil,
{
	max = onmax,
    current = oncurrent,
})


function Focus:SetMax(max)
	self.max = max
	self:DoDelta(0)
end 

function Focus:SetCurrent(val)
	self.current = val
	self.current = math.max(0,self.current)
	self.current = math.min(self.max,self.current)
end 

function Focus:SetPercent(percent)
	self:SetCurrent(percent*self.max)
end 

function Focus:DoDelta(delta)
	self:SetCurrent(self.current+delta)
end 

function Focus:GetPercent()
	return self.current / self.max
end 

function Focus:OnUpdate(dt)
	if not (self.inst.components.health.invincible or
            self.inst.sg:HasStateTag("sleeping") or --need this now because you are no longer invincible during sleep
            self.inst.is_teleporting or
            (self.ignore and self.redirect == nil)) then
        self:Recalc(dt)
    elseif self.inst.sg:HasStateTag("sleeping") then
		self:DoDelta(2*dt)
	else
        --Always want to update badge
        self:RecalcGhostDrain()

        --Disable arrows
        self.rate = 0
        self.ratescale = RATE_SCALE.NEUTRAL
    end
end

function Focus:RecalcGhostDrain()
    if GetGhostSanityDrain(TheNet:GetServerGameMode()) then
        local num_ghosts = TheWorld.shard.components.shard_players:GetNumGhosts()
        local num_alive = TheWorld.shard.components.shard_players:GetNumAlive()
        local group_resist = num_alive > num_ghosts and 1 - num_ghosts / num_alive or 0

        self.ghost_drain_mult = math.min(num_ghosts, TUNING.MAX_SANITY_GHOST_PLAYER_DRAIN_MULT) * (1 - group_resist * group_resist)
    else
        self.ghost_drain_mult = 0
    end
end

function Focus:Recalc(dt)
    local total_dapperness = self.dapperness
    for k, v in pairs(self.inst.components.inventory.equipslots) do
        if v.components.equippable ~= nil then
			local focus_dapperness = v.components.equippable.focus_dapperness or 0 
            total_dapperness = total_dapperness + focus_dapperness + v.components.equippable:GetDapperness(self.inst)
        end
    end

    total_dapperness = total_dapperness * self.dapperness_mult

    local dapper_delta = total_dapperness * TUNING.SANITY_DAPPERNESS

    local moisture_delta = easing.inSine(self.inst.components.moisture:GetMoisture(), 0, TUNING.MOISTURE_SANITY_PENALTY_MAX, self.inst.components.moisture:GetMaxMoisture())

    local light_delta
    if TheWorld.state.isday then
        light_delta = TUNING.SANITY_DAY_GAIN + (TheWorld:HasTag("cave") and 0.2 or 0.4)
    else
        local lightval = CanEntitySeeInDark(self.inst) and .9 or self.inst.LightWatcher:GetLightValue()
        light_delta =
            (   (lightval > TUNING.SANITY_HIGH_LIGHT and TUNING.SANITY_NIGHT_LIGHT) or
                (lightval < TUNING.SANITY_LOW_LIGHT and TUNING.SANITY_NIGHT_DARK) or
                TUNING.SANITY_NIGHT_MID
            ) * self.night_drain_mult
    end

    local aura_delta = 0
    local x, y, z = self.inst.Transform:GetWorldPosition()
    local ents = TheSim:FindEntities(x, y, z, TUNING.SANITY_EFFECT_RANGE, nil, { "FX", "NOCLICK", "DECOR","INLIMBO" })
    for i, v in ipairs(ents) do 
        if v.components.sanityaura ~= nil and v ~= self.inst then
            local aura_val = v.components.sanityaura:GetAura(self.inst) / math.max(1, self.inst:GetDistanceSqToInst(v))
            aura_delta = aura_delta + (aura_val < 0 and (self.neg_aura_absorb > 0 and self.neg_aura_absorb * -aura_val or aura_val) * self.neg_aura_mult or aura_val)
        end
    end

    local mount = self.inst.components.rider:IsRiding() and self.inst.components.rider:GetMount() or nil
    if mount ~= nil and mount.components.sanityaura ~= nil then
        local aura_val = mount.components.sanityaura:GetAura(self.inst)
        aura_delta = aura_delta + (aura_val < 0 and (self.neg_aura_absorb > 0 and self.neg_aura_absorb * -aura_val or aura_val) * self.neg_aura_mult or aura_val)
    end

    self:RecalcGhostDrain()
    local ghost_delta = TUNING.SANITY_GHOST_PLAYER_DRAIN * self.ghost_drain_mult

    self.rate = dapper_delta + moisture_delta + light_delta + aura_delta + ghost_delta + self.externalmodifiers:Get()

    if self.custom_rate_fn ~= nil then
        self.rate = self.rate + self.custom_rate_fn(self.inst)
    end

    self.rate = self.rate * self.rate_modifier
    self.ratescale =
        (self.rate > .2 and RATE_SCALE.INCREASE_HIGH) or
        (self.rate > .1 and RATE_SCALE.INCREASE_MED) or
        (self.rate > .01 and RATE_SCALE.INCREASE_LOW) or
        (self.rate < -.3 and RATE_SCALE.DECREASE_HIGH) or
        (self.rate < -.1 and RATE_SCALE.DECREASE_MED) or
        (self.rate < -.02 and RATE_SCALE.DECREASE_LOW) or
        RATE_SCALE.NEUTRAL

    --print (string.format("dapper: %2.2f light: %2.2f TOTAL: %2.2f", dapper_delta, light_delta, self.rate*dt))
	
    self:DoDelta(self.rate * dt)
end

function Focus:OnSave()
	return {
		current = self.current 
	}
end

function Focus:OnLoad(data)
	if data then
		self.current = data.current 
	end 
	self:DoDelta(0)
end

Focus.LongUpdate = Focus.OnUpdate

return Focus 