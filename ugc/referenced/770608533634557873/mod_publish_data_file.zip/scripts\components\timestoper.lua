local TimeStoper = Class(function(self, inst)
	self.inst = inst 
	self.stop_components = {"projectile","complexprojectile","playercontroller","ly_projectile"}
	
	self.isTheWorld = false
	self.TheWorldEnts = {} 
	
	self.onsinglestoptime = nil 
	self.onsingleresumetime = nil 
	self.onareastoptime = nil 
	self.ontheworld = nil 
	self.ontest = nil 
end)

local Default_NoTags = {"FX","DECOR", "INLIMBO","NO_TIME_STOP"}

local function EnablePlayerTimestopCC(player,enabled)
	player.player_classified._timestop_cc_enabled:set(enabled)
end 

local function IsUpdatingComponent(target,component)
	if not (target and target:IsValid() and component) then 
		return 
	end 
	if target.updatecomponents then
        for k,cmp in pairs(v.updatecomponents) do
            if k == component  then
                return true
            end
        end
    end
end 

local function ListenForEventOnce(inst, event, fn, source)
    -- Currently, inst2 is the source, but I don't want to make that assumption.
    local function gn(inst2, data)
        inst:RemoveEventCallback(event, gn, source) --as you can see, it removes the event listener even before firing the function
        return fn(inst2, data)
    end
     
    return inst:ListenForEvent(event, gn, source)
end

function TimeStoper:SetOnSingleStopTime(fn)
	self.onsinglestoptime = fn 
end 

function TimeStoper:SetOnSingleResumeTime(fn)
	self.onsingleresumetime = fn 
end 

function TimeStoper:SetOnAreaStopTime(fn)
	self.onareastoptime = fn 
end 

function TimeStoper:SetOnTheWorld(fn)
	self.ontheworld = fn 
end 

function TimeStoper:SetTimeStoperTest(fn)
	self.ontest = fn 
end 

function TimeStoper:SingleStopTime(target,delay,isTheWorld)
	if not (target and target:IsValid())   then 
		return 
	end
	if target.components.health and target.components.health:IsDead() then 
		return 
	end 
	if target.sg and target.sg:HasStateTag("dead") then 
		return 
	end 
	if target:HasTag("time_stopped") then 
		return 
	end 
	if self.ontest and not self.ontest(self.inst,target) then 
		return 
	end 
	local stopped_components = {} 
	for k,v in pairs(self.stop_components) do 
		local component = target.components.v
		if component and IsUpdatingComponent(target,component) then 
			target:StopUpdatingComponent(component)
			table.insert(stopped_components,component)
		end
	end 
	target:AddTag("time_stopped")
	target:StopBrain()
    if target.sg then
        target.sg:Stop()
    end
	if target.Physics then
        target.Physics:SetActive(false)
    end
    if target.AnimState then
        target.AnimState:Pause()
    end
	if self.onsinglestoptime then
		self.onsinglestoptime(self.inst,target,delay,stopped_components,isTheWorld)
	end 
	if delay then 
		target:DoTaskInTime(delay,function()
			self:SingleResumeTime(target,delay,stopped_components)
		end)
	end 
	
	--target:ListenForEvent("death",function()
	if not target:HasTag("timestop_listened") then 
		ListenForEventOnce(target, "death", function()
			if target.prefab ~= "klaus" then 
				target:RemoveTag("timestop_listened")
				self:SingleResumeTime(target,delay,stopped_components)
			end 
		end)
		target:AddTag("timestop_listened")
	end 
	--end)
	
	target.stopped_components = stopped_components
	
	
	if target:HasTag("player") then 
		EnablePlayerTimestopCC(target,true)
	end 
	
	if isTheWorld then 
		table.insert(self.TheWorldEnts,target)
	end
end 

function TimeStoper:SingleResumeTime(target,delay,stopped_components)
	stopped_components = stopped_components or target.stopped_components
	if stopped_components then 
		for k,cmp in pairs(stopped_components) do 
			target:StartUpdatingComponent(cmp)
		end
	end 
	target:RemoveTag("time_stopped")
    if target.AnimState then
        target.AnimState:Resume()
    end
	if target.Physics then
        target.Physics:SetActive(true)
    end
    target:RestartBrain()
    if target.sg then
        target.sg:Start()
    end
	if self.onsingleresumetime then 
		self.onsingleresumetime(self.inst,target,delay,stopped_components)
	end
	
	target.stopped_components = nil 
	
	if target:HasTag("player") then 
		EnablePlayerTimestopCC(target,false)
	end 
end 

function TimeStoper:AreaStopTime(pos,radius,delay,MustTags,NoTags,OneOfTags,isTheWorld,fn)
	pos = pos or self.inst:GetPosition()
	radius = radius or 30
	NoTags = NoTags or {}
	for k,tags in pairs(Default_NoTags) do 
		table.insert(NoTags,tags)
	end 
	
	local x,y,z = pos:Get()
	local ents = TheSim:FindEntities(x,y,z,radius, MustTags,NoTags,OneOfTags)
	
	for k,v in pairs(ents) do 
		if v ~= self.inst and not v:HasTag("time_stopped") and (fn == nil or fn(v)) then 
			self:SingleStopTime(v,delay,isTheWorld)
		end 
	end
	
	if self.onareastoptime then 
		self.onareastoptime(self.inst,pos,radius,delay,isTheWorld)
	end
	

end

function TimeStoper:TheWorld(pos,radius,delay,MustTags,NoTags,OneOfTags,fn)
	if self.isTheWorld then 
		return 
	end 
	pos = pos or self.inst:GetPosition()
	radius = radius or 30 
	delay = delay or 10 
	self.TheWorldTask = self.inst:DoPeriodicTask(0.1,function()
		self:AreaStopTime(pos,radius,nil,MustTags,NoTags,OneOfTags,true,fn)
	end)
	self.isTheWorld = true 
	if self.ontheworld  then 
		self.ontheworld(self.inst,pos,radius,delay)
	end
	self:CancelTheWorld(delay)
end

function TimeStoper:CancelTheWorld(delay)
	self.CancelTheWorldTask = self.inst:DoTaskInTime(delay,function()
		if self.TheWorldTask then
			self.TheWorldTask:Cancel()
			self.TheWorldTask = nil 
		end
		if self.CancelTheWorldTask then
			self.CancelTheWorldTask:Cancel()
			self.CancelTheWorldTask = nil 
		end
		for k,v in pairs(self.TheWorldEnts) do 
			self:SingleResumeTime(v,delay)
		end
		self.TheWorldEnts = {}
		self.isTheWorld = false
		--target.stopped_components = stopped_components
		--self:AreaStopTime(pos,radius,0,MustTags,NoTags,OneOfTags)
	end)
end

return TimeStoper