
local ClockTowerSpawner = Class(function(self, inst)
	self.inst = inst 
	
	self.room_list = {}
end)

local RAD_SIZE = 30

require "prefabs/telebase"

local function getrandomposition()
    local ground = TheWorld
    local centers = {}
    for i, node in ipairs(ground.topology.nodes) do
        if ground.Map:IsPassableAtPoint(node.x, 0, node.y) then
            table.insert(centers, {x = node.x, z = node.y})
        end
    end
    if #centers > 0 then
        local pos = centers[math.random(#centers)]
        return Point(pos.x, 0, pos.z)
    else
        return Point(0,0,0) 
    end
end 

local function ondeploy(pt)
    local map = TheWorld.Map
	local tile = GROUND.CAVE
    local x, y = map:GetTileCoordsAtPoint(pt:Get())
	if x ~= nil and y ~= nil then
        map:SetTile(x, y, tile)
    end

end


function ClockTowerSpawner:GetSuitableSpawnPos()
	return Vector3(1200 + 100 * #self.room_list,0,1200)
end

function ClockTowerSpawner:GetRoomByNum(num)
	for k,v in pairs(self.room_list) do 
		if v.num == num then 
			return v.entity 
		end
	end
end

function ClockTowerSpawner:GetNumByRoom(room)
	for k,v in pairs(self.room_list) do 
		if v.entity == room then 
			return v.num 
		end
	end
end 

function ClockTowerSpawner:Goto(player,num)
	num = num or 1 
	local room = self:GetRoomByNum(num)
	if room and room:IsValid() then 
		local pos = room:GetPosition()
		local newoffset = Vector3(-RAD_SIZE,0,0)
		player.Transform:SetPosition((pos+newoffset):Get())
	end
end 

function ClockTowerSpawner:LinkRoom(oldroom,newroom)
	local oldpos = oldroom:GetPosition()
	local newpos = newroom:GetPosition()
	local oldoffset = Vector3(RAD_SIZE,0,0)
	local newoffset = Vector3(-RAD_SIZE,0,0)
	
	local old_door = SpawnPrefab("clocktower_door")
	old_door.Transform:SetPosition((oldpos+oldoffset):Get())
	
	local new_door = SpawnPrefab("clocktower_door")
	new_door.Transform:SetPosition((newpos+newoffset):Get())
	
	old_door.components.teleporter:Target(new_door)
	new_door.components.teleporter:Target(old_door)
	
	print("[ClockTowerSpawner]:LinkRoom No."..self:GetNumByRoom(oldroom).." and No."..self:GetNumByRoom(newroom),oldroom,newroom)
end 

function ClockTowerSpawner:SpawnRoom(numoverride)
	local pos = self:GetSuitableSpawnPos() 
	local size = 20 
	for i = -size,size do 
		for j = -size,size do 
			local now_spawnpos = pos + Vector3(i,0,j)
			--ondeploy(now_spawnpos)
			if i==0 and j==0 then 
				local basic = SpawnPrefab("clocktower_room_basic")
				local oldnum = #self.room_list
				local newnum = oldnum + 1 
				
				if basic and basic:IsValid() then 
					basic.Transform:SetPosition(now_spawnpos:Get())
					basic:SpawnTraps(numoverride or newnum) 
				end
				
				if newnum == 1 then 
					local enter_door = SpawnPrefab("clocktower_door_enter")
					enter_door.Transform:SetPosition(getrandomposition():Get())
					
					TheNet:Announce("时计塔的大门打开了！")
					
					local out_door = SpawnPrefab("clocktower_door")
					local newoffset = Vector3(-RAD_SIZE,0,0)
					out_door.Transform:SetPosition((now_spawnpos+newoffset):Get())
					
					enter_door.components.teleporter:Target(out_door)
					out_door.components.teleporter:Target(enter_door)
				end
				table.insert(self.room_list,{entity = basic,num = newnum})
				print("[ClockTowerSpawner]:Create New Room No."..newnum,basic)
				
				local former_room = self:GetRoomByNum(oldnum)
				if former_room and former_room:IsValid() then 
					self:LinkRoom(former_room,basic)
				end
				

				
				
			end
			--print("[ClockTowerSpawner]:ondeploy finish")
		end 
	end
	print("[ClockTowerSpawner]:ondeploy all finish")
	
end

function ClockTowerSpawner:OnSave()
	if self.room_list then 
		local data = {}
		local ents = {} 
		for k,v in pairs(self.room_list) do 
			table.insert(data,{GUID = v.entity.GUID,num = v.num}) 
			table.insert(ents,v.entity.GUID) 
		end
		return data,ents
	end 
end

function ClockTowerSpawner:LoadPostPass(newents, savedata)
    if savedata then
		for k,v in pairs(savedata) do 
			table.insert(self.room_list,{entity = newents[v.GUID].entity,num = v.num})
		end 
    end
	self:Debug()
	print("[ClockTowerSpawner]:LoadPostPass finish")
end

function ClockTowerSpawner:Debug()
	for k,v in pairs(self.room_list) do 
		print(v,v.entity,v.num)
	end
end

--TheWorld.components.clocktowerspawner:SpawnRoom()
--TheWorld.components.clocktowerspawner:Debug()

return ClockTowerSpawner