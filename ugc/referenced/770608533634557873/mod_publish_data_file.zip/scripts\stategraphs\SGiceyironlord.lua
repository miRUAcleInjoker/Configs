require("stategraphs/commonstates")
local IceyUtil = require("icey_util") 
local actionhandlers = 
{
    
    ActionHandler(ACTIONS.CHOP,"work"),
	ActionHandler(ACTIONS.DIG,"work"),
	ActionHandler(ACTIONS.HAMMER,"work"),
	ActionHandler(ACTIONS.MINE,"work"),
	
    ActionHandler(ACTIONS.EAT, "eat"),

	ActionHandler(ACTIONS.ATTACK,
        function(inst, action)
			if not (inst.sg:HasStateTag("attack") or inst.components.health:IsDead()) then
				return "attack"
			end 
        end
    ),
	--ActionHandler(ACTIONS.ICEYIRONSHOOT, "shoot"),
}

local function shoot(inst,targetpos)
	local bomb = inst.fullcharge and "icey_ironlord_orb" or "icey_ironlord_orb_small"
	
	
	local orb = SpawnAt(bomb,inst:GetPosition())
	orb.owner = inst
	orb.components.ly_projectile:Throw(inst,targetpos,true,nil,true)
end

local events=
{
    CommonHandlers.OnLocomote(true,false),
    --CommonHandlers.OnAttack(),
    --CommonHandlers.OnAttacked(),
    CommonHandlers.OnDeath(),
	EventHandler("attacked", function(inst,data)
		if inst.components.health ~= nil and not inst.components.health:IsDead() 
        and (not inst.sg:HasStateTag("busy") or
            inst.sg:HasStateTag("caninterrupt") or
            inst.sg:HasStateTag("frozen")) then
			
			if data.damage and data.damage >= 75 then 
				inst.sg:GoToState("hit")
				inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/trails/hide_hit") 
			end 
			inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/hulk_metal_robot/hit")
		end
	end),
    EventHandler("transform_person", function(inst) inst.sg:GoToState("revert") end),
    EventHandler("freeze", 
        function(inst)
            if inst.components.health and inst.components.health:GetPercent() > 0 then
                inst.sg:GoToState("frozen")
            end
        end),    
    EventHandler("beginchargeup", 
        function(inst) 
            if not inst.sg:HasStateTag("busy") then
                inst.sg:GoToState("charge")
            end
        end),
	EventHandler("onsink", function(inst, data)
        if not inst.components.health:IsDead() and not inst.sg:HasStateTag("explode") then
	        inst.sg:GoToState("explode")
        end
    end),    
	
	CommonHandlers.OnHop(),
}

local states=
{
    State {
        name = "idle",
        tags = {"idle", "canrotate"},
        onenter = function(inst, pushanim)
            inst.components.locomotor:StopMoving()
            local anim = "idle_loop"
               
            if pushanim then
                if type(pushanim) == "string" then
                    inst.AnimState:PlayAnimation(pushanim)
                end
                inst.AnimState:PushAnimation(anim, true)
            else
                inst.AnimState:PlayAnimation(anim, true)
            end

            --[[if inst.rightbuttondown then
                inst.sg:GoToState("charge")    
            end--]]
        end,
		
		--[[onupdate = function(inst)
			if inst.rightbuttondown then
                inst.sg:GoToState("charge")    
            end
		end,--]]
        
       events=
        {
            EventHandler("animover", function(inst) 
                inst.sg:GoToState("idle")                                    
            end),
        }, 
    },

    State {
        name = "morph",
        tags = {"busy","morph"},
        onenter = function(inst)
            inst.components.locomotor:StopMoving()
            inst.AnimState:PlayAnimation("morph_idle")
            inst.AnimState:PushAnimation("morph_complete",false)            
        end,
        
        timeline=
        {
            TimeEvent(0*FRAMES, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve_DLC003/music/iron_lord")
            end),
            TimeEvent(15*FRAMES, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve_DLC003/common/crafted/iron_lord/morph")
            end),
            TimeEvent(105*FRAMES, function(inst) 
				ShakeAllCameras(CAMERASHAKE.FULL, 0.7, .03, .5, inst, 40)
            end),
            TimeEvent(152*FRAMES, function(inst) 
                --inst.SoundEmitter:PlaySound("dontstarve_DLC003/music/iron_lord_suit", "ironlord_music")
            end),
        },

        
        onexit = function(inst)
            inst.components.icey_ironlord:BecomeIronLordPost()
        end,

        events=
        {
            EventHandler("animqueueover", function(inst) 
                inst.sg:GoToState("idle")                                    
            end),
        },         
    },

    State{
        name = "revert",
        tags = {"busy"},
        onenter = function(inst)
            inst.Physics:Stop()            
            inst.AnimState:PlayAnimation("death")
            inst.sg:SetTimeout(3)
            --inst.SoundEmitter:PlaySound("dontstarve/characters/woodie/death_beaver")
        end,

        -- timeline =
        -- {
        --     TimeEvent(4*FRAMES, function(inst) inst.SoundEmitter:PlaySoundWithParams ("dontstarve_DLC003/common/crafted/iron_lord/small_explosion", {intesity= .2}) end),
        --     TimeEvent(8*FRAMES, function(inst) inst.SoundEmitter:PlaySoundWithParams("dontstarve_DLC003/common/crafted/iron_lord/small_explosion", {intesity= .4}) end),
        --     TimeEvent(12*FRAMES, function(inst) inst.SoundEmitter:PlaySoundWithParams("dontstarve_DLC003/common/crafted/iron_lord/small_explosion", {intesity= .6}) end),
        --     TimeEvent(19*FRAMES, function(inst) inst.SoundEmitter:PlaySoundWithParams("dontstarve_DLC003/common/crafted/iron_lord/small_explosion", {intesity= 1}) end),
        --     TimeEvent(54*FRAMES, function(inst) inst.SoundEmitter:PlaySoundWithParams("dontstarve_DLC003/common/crafted/iron_lord/explosion") end),
        -- },
        
        ontimeout = function(inst) 
            inst.sg:GoToState("wakeup")
        end
    }, 

    State{
        name = "work",
        tags = {"busy", "working"},
        
        onenter = function(inst)
            inst.Physics:Stop()            
            inst.AnimState:PlayAnimation("power_punch")
            inst.sg.statemem.action = inst:GetBufferedAction()
        end,
        
        timeline=
        {
            TimeEvent(4*FRAMES, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve_DLC003/common/crafted/iron_lord/punch",nil,.5)
            end),
            TimeEvent(6*FRAMES, function(inst) 
				if inst.sg.statemem.action ~= nil then
                    local target = inst.sg.statemem.action.target
                    if target ~= nil and target:IsValid() then
                        if inst.sg.statemem.action.action == ACTIONS.MINE then
                            SpawnPrefab("mining_fx").Transform:SetPosition(target.Transform:GetWorldPosition())
                            inst.SoundEmitter:PlaySound(target:HasTag("frozen") and "dontstarve_DLC001/common/iceboulder_hit" or "dontstarve/wilson/use_pick_rock")
                        elseif inst.sg.statemem.action.action == ACTIONS.HAMMER then
                            inst.sg.statemem.rmb = true
                            inst.SoundEmitter:PlaySound("dontstarve/wilson/hit")
                        elseif inst.sg.statemem.action.action == ACTIONS.DIG then
                            inst.sg.statemem.rmb = target:HasTag("sign")
                            SpawnPrefab("shovel_dirt").Transform:SetPosition(target.Transform:GetWorldPosition())
                        end
                    end
                end
				inst:PerformBufferedAction() 
			end),
			
			TimeEvent(9 * FRAMES, function(inst)
                if inst.sg.statemem.action == nil or
                    inst.sg.statemem.action.action == nil or
                    inst.components.playercontroller == nil then
                    return
                end
                if inst.sg.statemem.rmb then
                    if not inst.components.playercontroller:IsAnyOfControlsPressed(
                            CONTROL_SECONDARY,
                            CONTROL_CONTROLLER_ALTACTION) then
                        return
                    end
                elseif not inst.components.playercontroller:IsAnyOfControlsPressed(
                            CONTROL_PRIMARY,
                            CONTROL_ACTION,
                            CONTROL_CONTROLLER_ACTION) then
                    return
                end
                if inst.sg.statemem.action:IsValid() and
                    inst.sg.statemem.action.target ~= nil and
                    inst.sg.statemem.action.target.components.workable ~= nil and
                    inst.sg.statemem.action.target.components.workable:CanBeWorked() and
                    inst.sg.statemem.action.target.components.workable:GetWorkAction() == inst.sg.statemem.action.action and
                    CanEntitySeeTarget(inst, inst.sg.statemem.action.target) then
                    inst:ClearBufferedAction()
                    inst:PushBufferedAction(inst.sg.statemem.action)
                end
            end),
        },
		
		events=
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end ),
        },        
    },

    State{
        name = "frozen",
        tags = {"busy", "frozen"},
        
        onenter = function(inst)
            inst.components.playercontroller:Enable(false)

            if inst.components.locomotor then
                inst.components.locomotor:StopMoving()
            end
            inst.AnimState:PlayAnimation("frozen")
            inst.SoundEmitter:PlaySound("dontstarve/common/freezecreature")
            inst.AnimState:OverrideSymbol("swap_frozen", "frozen", "frozen")
        end,
        
        onexit = function(inst)
            inst.components.playercontroller:Enable(true)

            inst.AnimState:ClearOverrideSymbol("swap_frozen")
        end,
        
        events=
        {   
            EventHandler("onthaw", function(inst) inst.sg:GoToState("thaw") end ),        
        },
    },

    State{
        name = "charge",
        tags = {"busy", "doing", "waitforbutton","charge"},
        
        onenter = function(inst)            
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("charge_pre")
            inst.AnimState:PushAnimation("charge_grow")
            inst.SoundEmitter:PlaySound("dontstarve_DLC003/common/crafted/iron_lord/charge_up_LP", "chargedup")    
        end,
        onexit = function(inst)
            --inst.rightbuttonup = nil
            inst:ClearBufferedAction()
            --inst.shoot=nil
            --inst.readytoshoot = nil
        end,
        onupdate = function(inst)        
            --[[if inst.rightbuttonup then
                inst.rightbuttonup = nil
                inst.shoot = true                
            end
            if inst.shoot and inst.readytoshoot then
                inst.SoundEmitter:PlaySoundWithParams("dontstarve_DLC003/common/crafted/iron_lord/smallshot", {timeoffset=math.random()})
                inst.SoundEmitter:KillSound("chargedup")
                inst.sg:GoToState("shoot")
            end--]]

            --[[local controller_mode = TheInput:ControllerAttached()
            if controller_mode then
                local reticulepos = Vector3(inst.livingartifact.components.reticule.reticule.Transform:GetWorldPosition())
                inst:ForceFacePoint(reticulepos)        
            else
                local mousepos = TheInput:GetWorldPosition()             
                inst:ForceFacePoint(mousepos)        
            end  --]]
			--inst:ForceFacePoint(inst.components.playercontroller:GetMouseWorldPosition())   
        end,        
        timeline=
        {
            TimeEvent(15*FRAMES, function(inst) inst.readytoshoot = true end),
            TimeEvent(20*FRAMES, function(inst) inst.sg:GoToState("chagefull") end),            
        },        
    },

    State{
        name = "chagefull",
        tags = {"busy", "doing","waitforbutton","charge","chargefull"},
        
        onenter = function(inst)           
            --inst.rightbuttonup = nil 
            inst.components.locomotor:Stop()
            
            inst.AnimState:PlayAnimation("charge_super_pre")
            inst.AnimState:PushAnimation("charge_super_loop",true)
            inst.fullcharge = true

            inst.SoundEmitter:PlaySound("dontstarve_DLC003/common/crafted/iron_lord/electro")
            
        end,        

        onexit = function(inst)
            --inst.rightbuttonup = nil
            inst:ClearBufferedAction()     
            --[[if not inst.shooting then
                inst.fullcharge = nil
            end--]]
            --inst.shoot = nil
            --inst.shooting = nil
            inst.SoundEmitter:KillSound("chargedup")
        end,

        onupdate = function(inst)
            --[[if inst.rightbuttonup then
                inst.rightbuttonup = nil
                inst.shoot = true 
            end

            if inst.shoot and inst.readytoshoot then
                inst.shooting = true
                inst.SoundEmitter:PlaySoundWithParams("dontstarve_DLC003/creatures/boss/hulk_metal_robot/laser",  {intensity = math.random(0.7, 1)})---jason can i use a random number from .7 to 1 instead of a static number (.8)?

                inst.sg:GoToState("shoot")
            end--]]

            --[[local controller_mode = TheInput:ControllerAttached()
            if controller_mode then
                local reticulepos = Vector3(inst.livingartifact.components.reticule.reticule.Transform:GetWorldPosition())
                inst:ForceFacePoint(reticulepos)        
            else
                local mousepos = TheInput:GetWorldPosition()             
                inst:ForceFacePoint(mousepos)        
            end    --]]
			--inst:ForceFacePoint(inst.components.playercontroller:GetMouseWorldPosition())   
			
        end,  
        timeline=
        {
            TimeEvent(5*FRAMES, function(inst) inst.readytoshoot = true end),      
        },  
    },    

    State{
        name = "shoot",
        tags = {"busy"},
        
        onenter = function(inst,targetpos)  
			inst.sg.statemem.targetpos = targetpos 
            inst.components.locomotor:Stop()
            if inst.fullcharge then
                inst.AnimState:PlayAnimation("charge_super_pst")
            else
                inst.AnimState:PlayAnimation("charge_pst")
            end
        end,
        
        timeline=
        {
            TimeEvent(1*FRAMES, function(inst) shoot(inst,inst.sg.statemem.targetpos)  end),   
            TimeEvent(5*FRAMES, function(inst) inst.sg:RemoveStateTag("busy")  end),   
            
        }, 
        
        onexit = function(inst)
            inst.fullcharge = nil   
			inst.sg.statemem.targetpos = nil 
        end,

        events=
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end ),
        },             
    },

    State{
        name = "explode",
        tags = {"busy","explode"},
        
        onenter = function(inst)     
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("suit_destruct")            
        end,
        
        timeline=
        {   ---- death explosion
            TimeEvent(4*FRAMES, function(inst) inst.SoundEmitter:PlaySoundWithParams("dontstarve_DLC003/common/crafted/iron_lord/small_explosion", {intensity= .2}) end),
            TimeEvent(8*FRAMES, function(inst) inst.SoundEmitter:PlaySoundWithParams("dontstarve_DLC003/common/crafted/iron_lord/small_explosion", {intensity= .4}) end),
            TimeEvent(12*FRAMES, function(inst) inst.SoundEmitter:PlaySoundWithParams("dontstarve_DLC003/common/crafted/iron_lord/small_explosion", {intensity= .6}) end),
            TimeEvent(19*FRAMES, function(inst) inst.SoundEmitter:PlaySoundWithParams("dontstarve_DLC003/common/crafted/iron_lord/small_explosion", {intensity= 1}) end),
            TimeEvent(26*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve_DLC003/common/crafted/iron_lord/electro",nil,.5) end),
            TimeEvent(35*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve_DLC003/common/crafted/iron_lord/electro",nil,.5) end),
            TimeEvent(54*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve_DLC003/common/crafted/iron_lord/explosion") end),
            
            TimeEvent(54*FRAMES, function(inst) inst.SoundEmitter:KillSound("ironlord_music") end), --- jason i put the music here and commented out the living_artifact.lua lines                           
            
            TimeEvent(52*FRAMES, function(inst) 
                local explosion = SpawnPrefab("laser_explosion")
                explosion.Transform:SetPosition(inst.Transform:GetWorldPosition())  
				explosion.Transform:SetScale(0.6,0.6,0.6)
                --inst.livingartifact.DoDamage(inst.livingartifact, 5)
            end),
        }, 
        
        onexit = function(inst)
            inst.components.icey_ironlord:Revert() 
			inst.SoundEmitter:KillSound("chargedup")
        end,

        events=
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end ),
        },             
    },  
	
	

}

CommonStates.AddCombatStates(states,
{
    ---- 
    hittimeline =
    {
        -- TimeEvent(0*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve_DLC003/common/crafted/iron_lord/hit") end),
    },
    
    attacktimeline = 
    {
    
        TimeEvent(0*FRAMES, function(inst) 
            inst.SoundEmitter:PlaySound("dontstarve_DLC003/common/crafted/iron_lord/punch_pre") end),
        
        TimeEvent(6*FRAMES, function(inst) inst:PerformBufferedAction() end),
        TimeEvent(7*FRAMES, function(inst) inst.sg:RemoveStateTag("attack") inst.sg:RemoveStateTag("busy") inst.sg:AddStateTag("idle") end),
		TimeEvent(8*FRAMES, function(inst) 
            inst.SoundEmitter:PlaySound("dontstarve_DLC003/common/crafted/iron_lord/punch") end),
 },

    deathtimeline=
    {
    },
},
{attack="power_punch"})

CommonStates.AddRunStates(states,
{
	runtimeline = {
		TimeEvent(0*FRAMES, PlayFootstep ),
		TimeEvent(10*FRAMES, PlayFootstep ),
	},
})

local hop_timelines = 
{
    hop_loop =
    {
        TimeEvent(0, function(inst) 
            inst.SoundEmitter:PlaySound("turnoftides/common/together/boat/jump") 
			inst.SoundEmitter:PlaySoundWithParams("dontstarve_DLC003/common/crafted/iron_lord/smallshot", {timeoffset=math.random()})
        end),
    },   
}

CommonStates.AddFrozenStates(states)
CommonStates.AddHopStates(states, false, {pre = "charge_super_pre", loop = "charge_super_pst", pst = "idle_loop"}, hop_timelines, "turnoftides/common/together/boat/jump_on", "idle")

return StateGraph("SGiceyironlord", states, events, "idle", actionhandlers)