local ItemSlot = require "widgets/itemslot"
local Text = require "widgets/text"
local Image = require "widgets/image"
local Widget = require "widgets/widget"
local UIAnim = require "widgets/uianim"


local HUD_ATLAS = "images/hud.xml"
local TINT_NORMAL = {47/255,47/255,47/255,1}
local TINT_ACTIVATED = {1,1,1,1}



--c_poison(ThePlayer)
local DarkSoulDebuffSlot = Class(Widget, function(self, owner,name,ent,percent,activated)	
	--Widget._ctor(self, "DarkSoulDebuffSlot") 
	ItemSlot._ctor(self, "images/bufficons/"..name..".xml", name..".tex", owner)
	--ItemSlot._ctor(self,"images/battle_focus.xml","battle_focus.tex", owner)
	
    self.owner = owner
	self.name = name
	self.ent = ent
	self.percent = percent
	self.activated = activated 
	
	self.bgimage:SetScale(0.5,0.5)
	
	--self.slot = self:AddChild(ItemSlot(HUD_ATLAS, "inv_slot.tex",owner))
	
	self.label = self:AddChild(Text(NUMBERFONT, 32,"",{1,1,1,1}))
	self.label:SetPosition(0,120)
	self.label:Hide()
	
	self.recharge = self:AddChild(UIAnim())
    self.recharge:GetAnimState():SetBank("recharge_meter")
    self.recharge:GetAnimState():SetBuild("recharge_meter")
	self.recharge:GetAnimState():SetMultColour(1,1,1,0)
	self.recharge:GetAnimState():SetAddColour(47/255,47/255,47/255,0.6)
	self.recharge:SetScale(-1,1)
    self.recharge:SetClickable(false)
		
	self:SetScale(0.85,0.85,0.85)
end)

function DarkSoulDebuffSlot:GetBuffEntity()
	return self.ent 
end 

function DarkSoulDebuffSlot:OnGainFocus()
    self.label:Show()
end

function DarkSoulDebuffSlot:OnLoseFocus()
    self.label:Hide()
end

function DarkSoulDebuffSlot:SetBuff(percent,activated)
	local name = self.name 
	self.percent = percent
	self.activated = activated 
	
	if percent <= 1 and percent >= 0 then 
		self.recharge:GetAnimState():SetPercent("recharge", percent)
		if activated then 
			--self.recharge:GetAnimState():SetAddColour(1,0,0,0.7)
			--self.bgimage:SetTint(unpack(TINT_ACTIVATED))
			--self.recharge:GetAnimState():SetPercent("recharge", percent)
			self.bgimage:SetTexture("images/bufficons/"..name..".xml",name..".tex")
		else
			--self.recharge:GetAnimState():SetAddColour(0,0,0,0)
			--self.bgimage:SetTint(unpack(TINT_NORMAL))
			--self.recharge:GetAnimState():SetPercent("recharge",percent)
			self.bgimage:SetTexture("images/bufficons/"..name.."_gray.xml",name.."_gray.tex")
		end
	end 
	
	local name_str = STRINGS.NAMES[string.upper(name)] or "未知Buff"
	local des_tab = STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper(name)]
	local percent_show = percent * 100
	local des_str = (not des_tab and "一个未知的buff,\n鬼知道他是干嘛的.") or (activated and des_tab.ACTIVATED ) or des_tab.NORMAL
	
	--self.slot:SetLabel(string.format("%s:\n百分比:%.1f%%\n%s",name_str,percent_show,des_str),{ 1, 1, 1, 1 })
	--self:SetTooltip(string.format("%s:\n百分比:%.1f%%\n%s",name_str,percent_show,des_str))
	--self:MoveToBack()
	local time_demain = self.ent.replica.darksouldebuff:GetTimeRemain()
	time_demain = time_demain or "..."
	
	if type(time_demain) == "number" then 
		if time_demain >= 1 then 
			time_demain = math.floor(time_demain)
		else
			time_demain = math.floor(time_demain * 10) / 10
		end 
	end 
	self.label:SetString(string.format("%s:\n剩余时间:%s秒\n%s",name_str,tostring(time_demain),des_str))
end

return DarkSoulDebuffSlot