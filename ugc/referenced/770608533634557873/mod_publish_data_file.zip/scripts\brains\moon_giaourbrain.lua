require "behaviours/wander"
require "behaviours/doaction"
require "behaviours/chaseandattack"
require "behaviours/standstill"
require "behaviours/runaway"
require "behaviours/follow"

local STOP_RUN_DIST = 10
local SEE_PLAYER_DIST = 5
local MAX_WANDER_DIST = 20
local SEE_TARGET_DIST = 6

local MAX_CHASE_DIST = 7
local MAX_CHASE_TIME = 8

local RUN_AWAY_DIST = 10
local STOP_RUN_AWAY_DIST = 12

local function FindHealingCircle(inst)
	return FindEntity(inst,15,nil,{"healingcircle"})
end 

local function FindBattleShip(inst)
	local ship =  FindEntity(inst, 15, function(ship) return ship:HasTag("hyperion_circle") end)
	return ship~= nil
end 

local MoonGiaourBrain = Class(Brain, function(self, inst)
    Brain._ctor(self, inst)
end)

function MoonGiaourBrain:OnStart()

    local root = PriorityNode(
    {
		WhileNode(function() return FindBattleShip(self.inst)  end, "BattleShip",
                ChattyNode(self.inst, "RunAway",
                    RunAway(self.inst, "hyperion_circle", 10, 15))),
		WhileNode( function() return self.inst:ShoudlRunAway() end, "Dodge",
            RunAway(self.inst, function() return (self.inst.RunAwayTarget or self.inst.components.combat.target) end, RUN_AWAY_DIST, STOP_RUN_AWAY_DIST) ),
		Follow(self.inst, function() return FindHealingCircle(self.inst) end, 0, 1, 2, true),
        ChaseAndAttack(self.inst, 30),
		Wander(self.inst),
    }, .2)
    
    self.bt = BT(self.inst, root)
    
end

return MoonGiaourBrain
