local function oncurrenthealth_fake(self,current)
	self.inst.replica.icey_hunter:SetCurrent(current)
end 

local function OnHitOther(inst,data)
	inst.components.icey_hunter:OnHitOther(data.damageresolved)
end 


local function OnHealthDelta(inst,data)
	if inst.components.icey_hunter:GetCurrent() < inst.components.health.currenthealth then 
		inst.components.icey_hunter:ApplyToCurrent() 
	elseif data.amount <= 0 then 
		inst.components.icey_hunter:TrackHealthInDelay(2)
	end
end 

local IceyHunter = Class(function(self, inst)
	self.inst = inst 
	self.currenthealth_fake = 0

	self.inst:DoTaskInTime(0,function()
		self:ApplyToCurrent() 
	end) 
	
	self.inst:ListenForEvent("onhitother",OnHitOther)
	self.inst:ListenForEvent("healthdelta",OnHealthDelta)
end,
nil,
{
	currenthealth_fake = oncurrenthealth_fake,
}
)

function IceyHunter:GetCurrent()
	return self.currenthealth_fake 
end 

function IceyHunter:SetCurrent(val)
	self.currenthealth_fake = val
	self.currenthealth_fake = math.min(self.currenthealth_fake,self.inst.components.health.maxhealth)
	self.currenthealth_fake = math.max(self.currenthealth_fake,0)
end 

function IceyHunter:DoDelta(delta)
	self:SetCurrent(self.currenthealth_fake + delta)
end 

function IceyHunter:ApplyToCurrent()
	self:SetCurrent(self.inst.components.health.currenthealth) 
	self.inst:StopUpdatingComponent(self)
end 

function IceyHunter:InterruptTrack()
	if self.TrackInDelayTask then
		self.TrackInDelayTask:Cancel()
		self.TrackInDelayTask = nil 
	end 
end 

function IceyHunter:TrackHealthInDelay(delay)
	self:InterruptTrack()
	self.inst:StopUpdatingComponent(self)
	self.TrackInDelayTask = self.inst:DoTaskInTime(delay,function()
		self.inst:StartUpdatingComponent(self)
		self:InterruptTrack()
	end)
end

function IceyHunter:OnHitOther(damage)
	if damage then 
		local delta = self.currenthealth_fake - self.inst.components.health.currenthealth
		if delta > 0 then 
			local apply_delta = math.min(damage / 5,delta)
			self.inst.components.health:DoDelta(apply_delta)
		end 
	end 
end 

function IceyHunter:OnUpdate(dt)
	if self.currenthealth_fake > self.inst.components.health.currenthealth then 
		self:DoDelta(-dt*25)
	else
		self:ApplyToCurrent() 
	end
end


return IceyHunter