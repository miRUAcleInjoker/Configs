local assets =---���Ԥ��������Ĳ����ļ�����������ͼ�ȵȣ�
{
Asset("ANIM", "anim/timecrack.zip"),

}


local function fn()
	local inst = CreateEntity()--���������䶼��Ĭ��Ҫ���ӵģ�����Ͳ�������ô����
	local trans = inst.entity:AddTransform()
	local anim = inst.entity:AddAnimState()
	inst.entity:AddNetwork()
	
	inst:AddTag("NO_TIME_STOP")
	inst:AddTag("FX")
	
	anim:SetBank("timecrack")-----ǰ��������ָ��timecrack��ͼƬ�߽�Ͳ��ʣ�����Ч�����ò���ֻ�Ǳ�д��
	anim:SetBuild("timecrack")
	anim:PlayAnimation("pre")
	anim:PushAnimation("loop",true)
	
	anim:SetOrientation(ANIM_ORIENTATION.OnGround)
	
    anim:SetLayer(LAYER_WORLD_BACKGROUND)
    anim:SetSortOrder(3)
	
	
	inst.entity:SetPristine()
    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.persists = false 
	
	--[[local israining = TheWorld.state.israining
	if israining then 
		anim:SetLayer(LAYER_WORLD)
	else 
		anim:SetLayer(LAYER_WORLD_CEILING)
	end --]]
	
	inst.KillFx = function(self)
		self.AnimState:PlayAnimation("pst")
		self:ListenForEvent("animover", self.Remove)
	end
	
	inst:DoTaskInTime(100,inst.Remove)
	
	return inst
end

local function OnRemoveHit(inst)
    if inst.target ~= nil and inst.target:IsValid() then
        if inst.target.components.colouradder == nil then
            if inst.target.components.freezable ~= nil then
                inst.target.components.freezable:UpdateTint()
            else
                inst.target.AnimState:SetAddColour(0, 0, 0, 0)
            end
        end
        if inst.target.components.bloomer == nil then
            inst.target.AnimState:ClearBloomEffectHandle()
        end
    end
end

local function UpdateHit(inst, target)
    if target:IsValid() then
        local oldflash = inst.flash
        inst.flash = math.max(0, inst.flash - .075)
        if inst.flash > 0 then
            local c = math.min(1, inst.flash)
            if target.components.colouradder ~= nil then
                target.components.colouradder:PushColour(inst, c, 0, 0, 0)
            else
                target.AnimState:SetAddColour(c, 0, 0, 0)
            end
            if inst.flash < .3 and oldflash >= .3 then
                if target.components.bloomer ~= nil then
                    target.components.bloomer:PopBloom(inst)
                else
                    target.AnimState:ClearBloomEffectHandle()
                end
            end
            return
        end
    end
    inst:Remove()
end

local function SetTarget(inst, target,delay)
    if inst.inittask ~= nil then
        inst.inittask:Cancel()
        inst.inittask = nil

        inst.target = target
        inst.OnRemoveEntity = OnRemoveHit

        if target.components.bloomer ~= nil then
            target.components.bloomer:PushBloom(inst, "shaders/anim.ksh", -1)
        else
            target.AnimState:SetBloomEffectHandle("shaders/anim.ksh")
        end
        inst.flash = delay + math.random() * .4
        inst:DoPeriodicTask(0, UpdateHit, nil, target)
        UpdateHit(inst, target)
    end
end

local function hitfn()
    local inst = CreateEntity()

    inst:AddTag("CLASSIFIED")
    --[[Non-networked entity]]
    inst.persists = false

    inst.SetTarget = SetTarget
    inst.inittask = inst:DoTaskInTime(0, inst.Remove)

    return inst
end

return Prefab("timecrack", fn, assets),
Prefab("timecrack_hit", hitfn)