local function keepTwoDecimalPlaces(decimal)-----------------------�������뱣����λС���Ĵ���
    decimal = math.floor((decimal * 100)+0.5)*0.01       
    return  decimal 
end

local function setcd(inst,cdname,time,skillname,cansay,istimer)
	if inst.sg:HasStateTag("nointerrupt") or inst.sg:HasStateTag("knockout") or inst.sg:HasStateTag("sleeping") 
	or inst.sg.currentstate == "death"
	 then 
		return false
	end 
	if GetTime() - inst[cdname] < time then 
		if inst.components.talker and cansay then 
			local last = time - (GetTime() - inst[cdname])
			last = keepTwoDecimalPlaces(last)
			inst.components.talker:Say(skillname.."���ܻ���Ҫ"..last.."�����ʹ��")
		end
		return false
	end 
	inst[cdname] = GetTime()
	if inst["_"..cdname] ~= nil then 
		inst["_"..cdname]:set(inst[cdname])
	end
	return true
end 


local function DefaultFaceClient(inst,x,y,z,entity)
	if entity and not (x and y and z)  then 
		x,y,z = entity:GetPosition():Get()
	end
	inst:ForceFacePoint(x,y,z)
end 

local function icey_rightbutton_down(inst,x,y,z,entity)
	if inst.components.icey_ironlord:IsIronLord() and not inst.sg:HasStateTag("explode") then 
		local cancast = setcd(inst,"icey_ironshootcd",0.33,"�������",false)
		if cancast ~= true then
			return 
		end 
		--inst:PushEvent("rightbuttondown")
		DefaultFaceClient(inst,x,y,z,entity)
		inst.components.icey_ironlord:StartCharge() 
	end 
end 

local function icey_rightbutton_loop(inst,x,y,z,entity)
	if inst.components.icey_ironlord:IsIronLord() then 
		DefaultFaceClient(inst,x,y,z,entity)
	end 
end 

local function icey_rightbutton_up(inst,x,y,z,entity)
	if inst.components.icey_ironlord:IsIronLord() and not inst.sg:HasStateTag("explode") then 
		--inst:PushEvent("rightbuttonup")
		DefaultFaceClient(inst,x,y,z,entity)
		inst.components.icey_ironlord:Shoot(Vector3(x,y,z)) 
	end 
end 

if  TheNet:GetIsServer() then 
	AddModRPCHandler("icey","icey_rightbutton_down",icey_rightbutton_down)
	AddModRPCHandler("icey","icey_rightbutton_loop",icey_rightbutton_loop)
	AddModRPCHandler("icey","icey_rightbutton_up",icey_rightbutton_up)
else
	AddModRPCHandler("icey","icey_rightbutton_down",function() end)
	AddModRPCHandler("icey","icey_rightbutton_loop",function() end)
	AddModRPCHandler("icey","icey_rightbutton_up",function() end)
end

AddReplicableComponent("icey_ironlord")

-----------------------------------------------------------------------------------------------------------------
local BEAVER_LMB_ACTIONS =
{
    "CHOP",
    "MINE",
    "DIG",
	"HAMMER",
}

local BEAVER_ACTION_TAGS = {}

for i, v in ipairs(BEAVER_LMB_ACTIONS) do
    table.insert(BEAVER_ACTION_TAGS, v.."_workable")
end

local BEAVER_TARGET_EXCLUDE_TAGS = { "FX", "NOCLICK", "DECOR", "INLIMBO", "catchable", "sign" }

local function CannotExamine(inst)
    return false
end

local BEAVERVISION_COLOURCUBES =
{
    day = "images/colour_cubes/beaver_vision_cc.tex",
    dusk = "images/colour_cubes/beaver_vision_cc.tex",
    night = "images/colour_cubes/beaver_vision_cc.tex",
    full_moon = "images/colour_cubes/beaver_vision_cc.tex",
}

local function IronLordActionString(inst, action)
    return STRINGS.ACTIONS.ATTACK.WHACK
end

local function GetIronLordAction(target)
    for i, v in ipairs(BEAVER_LMB_ACTIONS) do
        if target:HasTag(v.."_workable") then
            return not target:HasTag("sign") and ACTIONS[v] or nil
        end
    end
end

local function IronLordActionButton(inst, force_target)
    if not inst.components.playercontroller:IsDoingOrWorking() then
        if force_target == nil then
            local x, y, z = inst.Transform:GetWorldPosition()
            local ents = TheSim:FindEntities(x, y, z, inst.components.playercontroller.directwalking and 3 or 6, nil, BEAVER_TARGET_EXCLUDE_TAGS, BEAVER_ACTION_TAGS)
            for i, v in ipairs(ents) do
                if v ~= inst and v.entity:IsVisible() and CanEntitySeeTarget(inst, v) then
                    local action = GetIronLordAction(v)
                    if action ~= nil then
                        return BufferedAction(inst, v, action)
                    end
                end
            end
        elseif inst:GetDistanceSqToInst(force_target) <= (inst.components.playercontroller.directwalking and 9 or 36) then
            local action = GetIronLordAction(force_target)
            if action ~= nil then
                return BufferedAction(inst, force_target, action)
            end
        end
    end
end

local function LeftClickPicker(inst, target)
    if target ~= nil and target ~= inst then
        if inst.replica.combat:CanTarget(target) then
            return (not target:HasTag("player") or inst.components.playercontroller:IsControlPressed(CONTROL_FORCE_ATTACK))
                and inst.components.playeractionpicker:SortActionList({ ACTIONS.ATTACK }, target, nil)
                or nil
        end
        for i, v in ipairs(BEAVER_LMB_ACTIONS) do
            if target:HasTag(v.."_workable") then
                return not target:HasTag("sign")
                    and inst.components.playeractionpicker:SortActionList({ ACTIONS[v] }, target, nil)
                    or nil
            end
        end
    end
end

local function RightClickPicker(inst, target)
    if target ~= nil and target ~= inst then
        return (target:HasTag("HAMMER_workable") and
                inst.components.playeractionpicker:SortActionList({ ACTIONS.HAMMER }, target, nil))
            or (target:HasTag("DIG_workable") and
                target:HasTag("sign") and
                inst.components.playeractionpicker:SortActionList({ ACTIONS.DIG }, target, nil))
            or nil
    end
end

local function SetIronLordActions(inst, enable)
    if enable then
        inst.ActionStringOverride = IronLordActionString
        if inst.components.playercontroller ~= nil then
            inst.components.playercontroller.actionbuttonoverride = IronLordActionButton
        end
        if inst.components.playeractionpicker ~= nil then
            inst.components.playeractionpicker.leftclickoverride = LeftClickPicker
            --inst.components.playeractionpicker.rightclickoverride = RightClickPicker
        end
    else
        inst.ActionStringOverride = nil
        if inst.components.playercontroller ~= nil then
            inst.components.playercontroller.actionbuttonoverride = nil
        end
        if inst.components.playeractionpicker ~= nil then
            inst.components.playeractionpicker.leftclickoverride = nil
            --inst.components.playeractionpicker.rightclickoverride = nil
        end
    end
end

local function SetIronLordVision(inst, enable)
    if enable then
        inst.components.playervision:ForceNightVision(true)
        inst.components.playervision:SetCustomCCTable(BEAVERVISION_COLOURCUBES)
    else
        inst.components.playervision:ForceNightVision(false)
        inst.components.playervision:SetCustomCCTable(nil)
    end
end



local function SetIronLordMode(inst, isbeaver)
    if isbeaver then
		inst:DoTaskInTime(152*FRAMES,function()
			if inst:HasTag("iceyironlord") then 
				TheWorld:PushEvent("enabledynamicmusic", false)
				if not TheFocalPoint.SoundEmitter:PlayingSound("ironlordmusic") then
					TheFocalPoint.SoundEmitter:PlaySound("dontstarve_DLC003/music/iron_lord_suit", "ironlordmusic")
				end
			end 
		end) 

        --[[inst.HUD.controls.status:SetIronLordMode(true)
        if inst.HUD.beaverOL ~= nil then
            inst.HUD.beaverOL:Show()
        end--]]
		
		--if inst.HUD.controls.status.iceyironlordbadge then 
			inst.HUD.controls.status.iceyironlordbadge:Show() 
		--end 
		

        if not TheWorld.ismastersim then
            inst.CanExamine = CannotExamine
            SetIronLordActions(inst, true)
            SetIronLordVision(inst, true)
            --[[if inst.components.locomotor ~= nil then
                inst.components.locomotor.runspeed = TUNING.WILSON_RUN_SPEED * 1.1
            end--]]
        end
    else
        TheWorld:PushEvent("enabledynamicmusic", true)
        TheFocalPoint.SoundEmitter:KillSound("ironlordmusic")

        --[[inst.HUD.controls.status:SetIronLordMode(false)
        if inst.HUD.beaverOL ~= nil then
            inst.HUD.beaverOL:Hide()
        end--]]
		
		--if inst.HUD.controls.status.iceyironlordbadge then 
			inst.HUD.controls.status.iceyironlordbadge:Hide() 
		--end 

        if not TheWorld.ismastersim then
            inst.CanExamine = inst.replica.icey_ironlord:IsIronLord() and CannotExamine or nil
            SetIronLordActions(inst, false)
            SetIronLordVision(inst, false)
            --[[if inst.components.locomotor ~= nil then
                inst.components.locomotor.runspeed = TUNING.WILSON_RUN_SPEED
            end--]]
        end
    end
	inst.HUD.controls.iceyironlordui:UpdateState()
end

	

local function OnIronLordModeDirty(inst)
    if inst.HUD ~= nil  then
        SetIronLordMode(inst, inst.replica.icey_ironlord:IsIronLord())
    end
end

local function SetIronLordWorker(inst, enable)
    if enable then
        if inst.components.worker == nil then
            inst:AddComponent("worker")
            inst.components.worker:SetAction(ACTIONS.CHOP, 4)
            inst.components.worker:SetAction(ACTIONS.MINE, 3)
            inst.components.worker:SetAction(ACTIONS.DIG, 3)
            inst.components.worker:SetAction(ACTIONS.HAMMER, 3)
        end
    elseif inst.components.worker ~= nil then
        inst:RemoveComponent("worker")
    end
end


local function onbecamehuman(inst)
    inst.CanExamine = nil
    SetIronLordWorker(inst, false)
    SetIronLordActions(inst, false)
    SetIronLordVision(inst, false)
end

local function onbecameironlord(inst)
    inst.CanExamine = CannotExamine
	SetIronLordWorker(inst, true)
    SetIronLordActions(inst, true)
    SetIronLordVision(inst, true)
end

local function TransformIronLord(inst, isbeaver)
    if isbeaver then
        onbecameironlord(inst)
    else
        onbecamehuman(inst)
    end
end

AddPlayerPostInit(function(inst)

	inst.icey_ironshootcd = 0 
	
	if not inst.components.icey_keyhandler then 
		inst:AddComponent("icey_keyhandler")
	end 
	
	inst.components.icey_keyhandler:AddMouseActionListenerWhileDown(
		MOUSEBUTTON_RIGHT,
		{Namespace = "icey",Action = "icey_rightbutton_down"},
		{Namespace = "icey",Action = "icey_rightbutton_loop"},
		{Namespace = "icey",Action = "icey_rightbutton_up"},
		0,
		{keepfn = DefaultFaceClient}
	)
	
	inst:ListenForEvent("is_ironlorddirty",OnIronLordModeDirty)
	OnIronLordModeDirty(inst)

	if not TheWorld.ismastersim then
		return inst
	end
	
	inst:AddComponent("icey_ironlord")
	inst.components.icey_ironlord:SetOnTransform(TransformIronLord) 
end)

local iceyironlordui = require "widgets/iceyironlordui"
local function inv_redefine(self)
	self.iceyironlordui = self:AddChild(iceyironlordui(self.owner))
end
AddClassPostConstruct("widgets/controls", inv_redefine)
