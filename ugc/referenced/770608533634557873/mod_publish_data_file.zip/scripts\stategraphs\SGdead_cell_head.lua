require("stategraphs/commonstates")

local function DoFoleySounds(inst)

	for k,v in pairs(inst.components.inventory.equipslots) do
		if v.components.inventoryitem and v.components.inventoryitem.foleysound then
			inst.SoundEmitter:PlaySound(v.components.inventoryitem.foleysound)
		end
	end

end

local actionhandlers = 
{
	
}

   
local events=
{
	CommonHandlers.OnLocomote(true, false),

    EventHandler("attacked", function(inst, data)
		--inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/idle")
		if not inst.sg:HasStateTag("busy") and not inst.sg:HasStateTag("icey_skill") then 
			inst.sg:GoToState("hit")
		end 
	end),

    EventHandler("doattack", function(inst,data)

    end),
    
    EventHandler("death", function(inst)
        inst.sg:GoToState("death")
    end),
}

local states= 
{
    State{
        name = "idle",
        tags = {"idle", "canrotate"},
        onenter = function(inst, pushanim)     
            inst.components.locomotor:Stop()
			inst.head.Transform:SetRotation(inst.Transform:GetRotation())
			inst.head.AnimState:PlayAnimation("idle_loop", true)
            inst.sg:SetTimeout(1)
        end,
		
		onupdate = function(inst)
			inst.head.Transform:SetRotation(inst.Transform:GetRotation())
		end,
    },  


    State{
        name = "run_start",
        tags = {"moving", "running", "canrotate"},
        
        onenter = function(inst)
			inst.components.locomotor:RunForward()
			inst.head.Transform:SetRotation(inst.Transform:GetRotation())
            inst.head.AnimState:PlayAnimation("run_bronya_pre")
            inst.sg.mem.foosteps = 0
			
			inst.sg:SetTimeout(0.2)
        end,

        onupdate = function(inst)
			inst.head.Transform:SetRotation(inst.Transform:GetRotation())
            inst.components.locomotor:RunForward()
        end,

        ontimeout = function(inst) inst.sg:GoToState("run") end,        
        
        timeline=
        {
        
            TimeEvent(4*FRAMES, function(inst)
                --inst.SoundEmitter:PlaySound("flyhead/flyhead/intro_slime_move"..math.random(1,3))
            end),
        },        
        
    },

    State{
        
        name = "run",
        tags = {"moving", "running", "canrotate"},
        
        onenter = function(inst) 
            inst.components.locomotor:RunForward()
			inst.head.Transform:SetRotation(inst.Transform:GetRotation())
            inst.head.AnimState:PushAnimation("run_bronya_loop",true)
			inst.SoundEmitter:PlaySound("flyhead/flyhead/intro_slime_move"..math.random(1,3))
			inst.sg:SetTimeout(0.45)
        end,
		
		ontimeout = function(inst) inst.sg:GoToState("run") end,
        
        onupdate = function(inst)
			inst.head.Transform:SetRotation(inst.Transform:GetRotation())
            inst.components.locomotor:RunForward()
        end,

        timeline=
        {
            TimeEvent(7*FRAMES, function(inst)
				inst.sg.mem.foosteps = inst.sg.mem.foosteps + 1
                PlayFootstep(inst, inst.sg.mem.foosteps < 5 and 1 or .6)
                DoFoleySounds(inst)
            end),
            TimeEvent(15*FRAMES, function(inst)
				inst.sg.mem.foosteps = inst.sg.mem.foosteps + 1
                PlayFootstep(inst, inst.sg.mem.foosteps < 5 and 1 or .6)
                DoFoleySounds(inst)
            end),
        },
        
        events=
        {   
            EventHandler("animover", function(inst) inst.sg:GoToState("run") end ),        
        },
        
        
    },
    
    State{
        name = "run_stop",
        tags = {"canrotate", "idle"},
        
        onenter = function(inst) 
            inst.components.locomotor:Stop()
            inst.head.AnimState:PlayAnimation("run_bronya_pst")
			inst.head.Transform:SetRotation(inst.Transform:GetRotation())
			--inst.SoundEmitter:PlaySound("flyhead/flyhead/intro_slime_move"..math.random(1,3))
			inst.sg:GoToState("idle")
        end,
    },    
}

    
return StateGraph("SGdead_cell_head", states, events, "idle", actionhandlers)

