local WeaponRepairer = Class(function(self, inst)
	self.inst = inst
	
	--self.repairpercent = 0
	self.repairvalue = 0 
	self.repairvalue_armor = 0 
	
	inst:AddTag("weaponrepairer")
end)

function WeaponRepairer:RemoveSingle(owner)
	local single = self.inst.components.stackable and self.inst.components.stackable:Get() or self.inst
	if owner and owner.SoundEmitter then 
		owner.SoundEmitter:PlaySound("dontstarve/wilson/equip_item_gold")
	end 
	single:Remove()
end 

function WeaponRepairer:Repair(owner,target)
	if target.components.finiteuses then 
		if target.components.finiteuses:GetPercent() >= 1.0 then 
			if owner and owner.components.talker then
				owner.components.talker:Say("这件装备不需要修理....")
			end
			return 
		end 
		local current = target.components.finiteuses:GetUses()
		target.components.finiteuses:SetUses(current + self.repairvalue)
		if target.components.finiteuses:GetPercent() >= 1.0 then 
			target.components.finiteuses:SetPercent(1.0)
		end 
		
		self:RemoveSingle(owner)
	elseif  target.components.armor then 
		if target.components.armor.indestructible or target.components.armor:GetPercent() >= 1.0  then 
			if owner and owner.components.talker then
				owner.components.talker:Say("这件装备不需要修理....")
			end
			return 
		end
		target.components.armor:SetCondition(target.components.armor.condition+self.repairvalue_armor)
		self:RemoveSingle(owner)
	else
		if owner and owner.components.talker then
			owner.components.talker:Say("我不能修理它....")
		end
	end
end


return WeaponRepairer