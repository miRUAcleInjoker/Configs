
--[[
代码版权所有: 灵衣女王的鬼铠
qq:1426163582
我知道这ui代码写的不好，毕竟我第一次写
但是我懒得改，略略略~
--]]

local Widget = require "widgets/widget" --Widget，所有widget的祖先类
local Text = require "widgets/text" --Text类，文本处理
local TextButton = require "widgets/textbutton"
local Image = require "widgets/image"
local ImageButton = require "widgets/imagebutton"
local UIAnim = require "widgets/uianim"

local button_team = {
	[1] = {"iron_body","foot_star","sky_death","steady"},
	[2] = {"quick_shield","dangerous","blood_steal","shinobi_execution"},
	[3] = {"all_shield","charge","shield_attack","battle_focus"},
	[4] = {"sacrifice","hyperion","death_slaughter","soul_torrent"},
	[5] = {"great_coupling","liangzi_run","shield_crush","newton_grave"},
	[6] = {"wudao_sanity","electricity_shadow","nucler_weapon","battleground_eating"},
	[7] = {"king_card","mult_shadow","hit_ground","iron_hitter"},
	[8] = {"red_reboot","go_hide","shut_down","death_machinegun"},
	[9] = {"fire_keeper","snow_dancer","starve_walker","harvell_coser"},
	[10] = {"exectuer","dark_charge","rude_storm","witch_time"},
}
local skill_name,skill_respect
if TUNING.ICEY_LANGUAGE == "chinese" then 
	skill_name = {
		[1] = {"钢铁身躯","大步流星","死神天降","稳健"},
		[2] = {"快速充能","危机关系","生物质汲取","忍杀"},
		[3] = {"全副武装","冲锋","盾牌猛击","战意聚焦"},
		[4] = {"必杀技·超载融合(冷却时间:5秒)","必杀技·休伯利安号(冷却时间:360秒)","必杀技·死亡进击(冷却时间:12秒)","必杀技·灵魂洪流(冷却时间:20秒)"},
		[5] = {"超能耦合","量子疾步","守备粉碎","牛顿的棺材板"},
		[6] = {"武道分流","化电幻影","融核武装","战场进食"},
		[7] = {"终极王牌","多重影分身","大地震击","护命吐息"},
		[8] = {"红色重启","光学迷彩","处决","死神机炮"},
		[9] = {"消防屏障","霜雪舞者","荒蛮之主","坚如磐石"},
		[10] = {"势不可挡","暗影冲锋","鲁莽风暴","狂野膜法"},
	}
	skill_respect = {
		[1] = {"提高艾希5%的伤害减免。","提高艾希5%的移动速度。","使突围冲击(艾希的武器技能)的威力提高10点。","所有耐力消耗减少10%。"},
		[2] = {"每2秒额外恢复1点护盾值。","受到攻击后，在5秒内提高自己10%的移动速度。内置冷却15秒。","造成高于10点的伤害时，额外恢复0.5点护盾值。","在潜行状态下，对下级敌人造成的伤害增加3倍。"},
		[3] = {"成功极限闪避后，额外恢复10护盾值。","进入战斗时，10秒内提高自己10%的移动速度。内置冷却15秒。","对敌人造成大于等于30的伤害时，有50%的几率额外造成等同于当前护盾值/10点的伤害。","在格挡并弹反敌人之后，恢复7点专注值。"},
		[4] = {"描述:经过短暂的引导后,令艾希进入无法手动停止的过载状态,大幅度提高移动速度与伤害,但是每秒消耗3点生命值.\n当艾希生命值低于10%或死亡时,过载模式会自动解除.","描述:召唤强而有力的休伯利安号横穿战场,向沿途的敌人倾泻炮火与死亡,持续15秒","描述:向目标地点的敌人进行多次华丽的斩杀,并以一次跳劈作为收尾\n对被极限闪避重创的敌人有奇效","被动效果：在艾希闪避反击或者杀死敌人时，敌人的一部分灵魂会被打碎，化作灵魂碎片散布在战场上，持续10秒。\n主动效果：吸收附近所有的灵魂碎片，爆发灵魂洪流，以自身为中心造成大量伤害。"},
		[5] = {"当艾希杀死敌人时，恢复其所有的闪避充能次数。","提高自己的初始移动速度10%。","每次攻击会在10秒内降低目标1%的伤害减免，最多降低到-100%(对巨人族敌人无效)。\n当使用这个技能对生命值上限高于400的敌人造成影响时，会显示护盾破碎特效以方便标识。","辅助机的子弹可以在空中自动拐弯，追踪可能的敌人。"},
		[6] = {"当你的护盾值为满时，溢出的护盾值会为你恢复等量的精神值。","极限闪避触发的影分身攻击会麻痹敌人1秒钟。","增加伤害倍率到1.2倍","在吃下专属食物后，获得等同于精神值回复量的专注值。"},
		[7] = {"每次造成高于20点的伤害后，有50%的几率降低必杀技的冷却技能时间1秒。","极限闪避触发的分身反击会变为2个。","突围冲击(艾希的武器技能)造成的伤害有50%的几率造成三倍伤害。","处决/在潜行状态下杀死敌人时，略微恢复除饥饿值以外的所有属性。"},
		[8] = {"当你死亡时，有30%的几率在原地重生并恢复全部属性值。","成功极限闪避后，在5秒内进入潜行状态，无法被别人发现。内置冷却30秒。","突围冲击(艾希的武器技能)能对生命值小于等于15%的敌人造成巨额伤害。","增加辅助机同时发射的子弹数量，但是过热速度也会增加。"},
		[9] = {"使艾希免疫烈焰与高温伤害。","使艾希免疫冻结与低温伤害。","同时提高艾希对高温，烈焰，冻结与低温的抗性。","大幅度减少因为受到攻击而损失的耐力值。"},
		[10] = {"提高护盾最大值到350点，提高自己的韧性。但是降低自己的生命值上限到20点。在护盾值≥33%时，还可以弹反攻击者。","攻击会造成目标眩晕，使其在3秒内失去行动能力。内置冷却15秒。","提高自己的伤害倍率到1.75倍。但是每次造成伤害都会消耗1点自己的护盾值，若护盾值不足则改为损失3点生命值。","极限闪避成功时会进入膜女时间，将附近的其它实体拉入静止的时空中，持续5秒。内置冷却90秒。"},
	}
elseif TUNING.ICEY_LANGUAGE == "english" then 
	skill_name = {
		[1] = {"Iron Body","Strode","Death from the sky","Steady"},
		[2] = {"Quick Charging","Crisis Relationship","Biomass Steal","Shinobi Execution"},
		[3] = {"Full Combat Gear","Charge","Shield Slam","Battle Focus"},
		[4] = {"Death blow:Overload Fusion","Death blow:Hyperion","Death blow:Death Slaughter","Death blow:Soul Torrent"},
		[5] = {"Great Coupling","Quantum Step","Shield Crush","Newton's Grave"},
		[6] = {"Bushido Shunt","Electricity Shadow","Nucler Weapon","Battleground Devouring"},
		[7] = {"Trump Card","Mult-Shadows","Earth Shock","Breather"},
		[8] = {"Red Reboot","Optical Camouflage","Execution","Gun Gale"},
		[9] = {"Fire Keeper","Snow Dancer","Primal Lord","Harvell's Adorer"},
		[10] = {"Power OverWhelming","Dark Charge","Rash Storm","The World !!!"},
	}
	skill_respect = {
		[1] = {"Increase damage absorption 5%","Increase movespeed 5%","Make Icey's weapon skill deals extra 5 damage.","Decrease the consumerate of stamina 10%"},
		[2] = {"Gain 1 Shield Energy each 2 seconds","Whenever Icey is attacked,increase her movespeed 10% in 5 seconds.CD:15 seconds","Whenever Icey deal damage(larger than 10) to others,gains 0.5 Shield Energy","Deal triple damage to enemy while sneaking"},
		[3] = {"Whenever Icey use Shadow Fighter to knock enemy back,gains 10 Shield Energy","When Icey start to fight,increase her movespeed 15% in 10 seconds.CD:15 seconds","When Icey deal damage(larger than 30) to her target,she has 50% chance dealing extra damage equal to her Shield Energy/10","Gain 7 focus for each parry and hitback"},
		[4] = {"Choose Overload Fusion as your R skill:\n OverLoad Icey's battle system,double her speed and her attack will course mult-damage,but she will lose 3 health per second,until her health is below 10%","Choose Hyperion as your R skill:\nSummon a mightly Battle Cruiser cross the battle field for 15 seconds","Choose Death Slaughter as your R skill:\n Rush into the enemy, attack them one by one,and finish it with a Leap attack","Choose Soul Torrent as your R skill:\nIcey can create soul fragment when she use shadow fighter hit back,and she can use these fragments to deal AOE damage by activiting this skill."},
		[5] = {"Each time Icey kill a enemy,recover all her Shadow Step Nums","Increase movespeed 10%","Each time Icey hits her target,decrease its damage absorption 1% in 10s,unless its damage absorption is lower than -100%(this skill has no effet on Giants)","Wendy's bullet will never follow Newton's law from now,they can chase their enemies automatically"},
		[6] = {"Translate Shield Energy regen into sanity regen when your Shield Energy is full","Shadow Fighter's attack can palsy its target for 1 second","Increase Icey's damagemultiplier to 1.2","While Icey eating foods,gain focus equal to its sanity recovery volume"},
		[7] = {"Each time you deal damage(larger than 20) to your enemy,Icey has 50% chance to decrease the CD of R skill 1 second","Icey can summon 2 Shadow Fighters to knock enemy back","Icey's weapon skill has 50% chance to deal trible damage","Recover sanity,health,stamina and focus when Icey kill an enemy in sneaking"},
		[8] = {"Whenever Icey is killed,she has 30% chance to resurrect and recover her health,sanity and hunger","After summoning Shadow Fighter(s),Icey will become invisible for 5 seconds.","Icey's weapon skill can deal huge damage to a enemy whose health is below 15%","Increase the number of Wendy's bullets"},
		[9] = {"Protect Icey from fire damage and overheating","Protect Icey from freezing and supercooling","Increase the ability of adapting all bad climate environment","Decrease less stamina when Icey is attacked"},
		[10] = {"Increase Max Shield Energy to 350,but decrease Max Health to 20,and you can repelled attacker while your Shield Energy ≥33%","Stun target for 3 seconds if Icey hits it.CD:15 seconds","Increase Icey's damagemultiplier to 1.75。But each time Icey deals damage,she will lose 1 Shield Energy (lose 3 health instead while Shield Energy is below 10%)","When Icey use shadowfighter to hitback,stop the time for 5 seconds.CD:90 seconds"},
	}
end 


local function keepNDecimalPlaces(decimal,n)-----------------------四舍五入保留n位小数的代码
	n = n or 0
	local h = math.pow(10,n)
    decimal = math.floor((decimal * h)+0.5)/h       
    return  decimal 
end

local function getcd(owner,cdname,time)
	local last = (math.max(0,time - (owner.GetTime - owner[cdname])))
	if last <= 0 then 
		last = (TUNING.ICEY_LANGUAGE == "chinese" and "就绪" ) or (TUNING.ICEY_LANGUAGE == "english" and "Ready" )
	else
		last = math.ceil(last)
	end
	return  tostring(last)
end 


local function GetListPos(list,str)
	for i = 1,10 do 
		for k,v in pairs(list[i]) do 
			if v == str then 
				return i,k
			end
		end 
	end
	return 1,1
end 

local function GetName(engilsh,china,str)
	local i,k = GetListPos(engilsh,str)
	return china[i][k]..":\n"..skill_respect[i][k]
end 

local function GetSkillCampony(list,str)
	local level,num = GetListPos(list,str)
	local cps = {}
	for k,v in pairs(list[level]) do
		if v ~= str then 
			table.insert(cps,v)
		end
	end
	return cps
end 

local function OnSkillLevelUp(player,prefab)
	if player then
		player[prefab] = 1
		player["_"..prefab]:set(player[prefab])
		player:apply_skills()
		local fx = SpawnPrefab("statue_transition_2")
		fx.Transform:SetPosition(player:GetPosition():Get())
		print(player,prefab,"on level up !")
		player.SoundEmitter:PlaySound("dontstarve/characters/wx78/levelup")
	end 
end 
AddModRPCHandler("icey_rpc","icey_skill_levelup",OnSkillLevelUp)

local function OnSkillReset(player)
	if player then 
		player:reset_skills()
		local fx = SpawnPrefab("statue_transition_2")
		fx.Transform:SetPosition(player:GetPosition():Get())
		print(player,"Reset All !")
	end
end 
AddModRPCHandler("icey_rpc","icey_skill_reset",OnSkillReset)

local function RemoveItemByName(owner,name,nums)------------------------移除指定数量的指定名字的物品
	owner.components.inventory:ConsumeByName(name,nums)
	print("RemoveItemByName over")
end 
AddModRPCHandler("icey_rpc","icey_remove",RemoveItemByName)

local function RemoveCosts(self,name,nums)
	local player = self.owner
	print(player)

	if player and player.components.inventory and player.components.inventory:Has(name,nums) then 
		RemoveItemByName(player,name,nums)
		return true
	end

	if player and player.replica.inventory and player.replica.inventory:Has(name,nums) then 
		SendModRPCToServer(MOD_RPC["icey_rpc"]["icey_remove"],name,nums)
		return true
	end 
	return false
end 

local function HideOther(self,prefab)
	------------------------------------------------------------------------
	--self[prefab].image:SetTint(0/255,250/255,216/255,1)
	local cps = GetSkillCampony(button_team,prefab)
	for k,v in pairs(cps) do
		self[v]:Disable()
		self[v].image:SetTint(49/255,49/255,49/255,1)
	end
end 

local function ShowAll(self,prefab)
	local cps = GetSkillCampony(button_team,prefab)
	table.insert(cps,prefab)
	for k,v in pairs(cps) do
		self[v]:Enable()
		self[v].image:SetTint(1,1,1,1)
	end
end 

local function CheckAndDone(self,tec_name)
	local player = self.owner
	print(player)
	local says = (TUNING.ICEY_LANGUAGE == "chinese" and "我已经获得了此升级" ) or (TUNING.ICEY_LANGUAGE == "english" and "I have upgraded this skill" )
	if player[tec_name] ==  1 then 
		player.components.talker:Say(says)
		return
	end 
	
	if TheWorld.ismastersim then
		OnSkillLevelUp(player,tec_name)
	else
		SendModRPCToServer(MOD_RPC["icey_rpc"]["icey_skill_levelup"],tec_name)
	end 
	HideOther(self,tec_name)
end 

local function MakeSkillButton(self,button,h,v,pos,scale)
	self[button] = self:AddChild(ImageButton("images/"..button..".xml",button..".tex",button..".tex",button..".tex",button..".tex",button..".tex")) 
	self[button]:SetOnClick(function()
		CheckAndDone(self,button)
	end)
	self[button].ongainfocus = function() 
		local enable = (TUNING.ICEY_LANGUAGE == "chinese" and "\n(不可用:你只能升级一小组技能中的其中一个)" ) or (TUNING.ICEY_LANGUAGE == "english" and "\n(Unavailable:You can only upgrade one of these skills in a team)" )
		if self[button].enabled then  
			self.skill_inspect:SetColour(0/255,131/255,255/255,1)
			self.skill_inspect:SetString(GetName(button_team,skill_name,button))
		else
			self.skill_inspect:SetColour(255/255,43/255,43/255,1)
			self.skill_inspect:SetString(GetName(button_team,skill_name,button)..enable)
		end 
		self.skill_inspect:MoveToFront()
	end
	self[button].onlosefocus = function() 
		local shows = (TUNING.ICEY_LANGUAGE == "chinese" and "移动鼠标到技能图标上来查看技能介绍" ) or (TUNING.ICEY_LANGUAGE == "english" and "To check the description of a skill,you need to put your mouse on its icon" )
		self.skill_inspect:SetColour(0/255,131/255,255/255,1)
		self.skill_inspect:SetString(shows)
	end
	self[button]:SetHAnchor(h) -- 设置原点x坐标位置，0、1、2分别对应屏幕中、左、右
	self[button]:SetVAnchor(v) -- 设置原点y坐标位置，0、1、2分别对应屏幕中、上、下
    self[button]:SetPosition(pos:Get()) -- 设置ancientmac widget相对原点的偏移量，70，-50表明向右70，向下50，第三个参数无意义。
	self[button]:SetScale(scale,scale,scale)
	self[button]:SetFocusScale(1,1,1)
	--self[button]:SetImageFocusColour(0/255,97/255,157/255,0.9)
	self[button]:SetImageNormalColour(1,1,1,1)
	self[button]:Hide()
end 

local function MakeSkillTeam(self,level,h,v,pos)
	local dex = 0
	local ddex = 80
	for i=1,#button_team[level] do
		MakeSkillButton(self,button_team[level][#button_team[level] - i + 1],h,v,Vector3(pos.x,pos.y - dex,pos.z),0.6)
		dex = dex - ddex
	end
end 

local function checkallbuttons(self)
	for i = 1,10 do 
		local flag = 0
		for k,v in pairs(button_team[i]) do 
			if self.owner[v] == 1 then 
				flag = 1
				HideOther(self,v)
				break
			end
		end 
		--[[if flag == 0 then 
			for k,v in pairs(button_team[i]) do 
				ShowAll(self,v)
				break
			end
		end--]]
	end
end 

local scale_set_list = {
	"level_text",
	"exp_text",
	"shield",
	"skill_inspect",
	"skill_main",
	"level",
	"hideui_button",
	"skill_main_call",
	"skill_reset",
	"cd_list",
	"overload_ui",
}

for _,team in pairs(button_team) do 
	for _,skill in pairs(team) do 
		table.insert(scale_set_list,skill) 
	end 
end 

local function SetAllScale(self,scalemult)
	scalemult = scalemult or 1 
	for k,v in pairs(scale_set_list) do 
		if self[v] then 
			local nowscale = self[v]:GetScale()
			local newscale = nowscale*scalemult
			self[v]:SetScale(newscale:Get())
		end
	end
end 

local IceyUi = Class(Widget, function(self,owner) 
	
	Widget._ctor(self, "IceyUi") 
	self.owner = owner
	
	local width,heigth = TheSim:GetScreenSize()
	local pw,ph = width / 1920,heigth / 1000
	--local bgw,bgh = 400 + 340 *math.min(pw,ph),20 * ph
---------------------------------------------------------------------------------------------------

	
	local function skill_main_call()
		if not self.skill_main.shown then 
			self.skill_main:Show()
			self.skill_inspect:Show()
			self.skill_reset:Show()
			local level = self.owner.replica.icey_level:GetLevel()
			for i = 1,level do 
				for k,v in pairs(button_team[i]) do 
					if self[v] then 
						self[v]:Show()
					end
					ShowAll(self,v)
				end
			end
		else
			self.skill_main:Hide()
			self.skill_inspect:Hide()
			self.skill_reset:Hide()
			for i = 1,10 do 
				for k,v in pairs(button_team[i]) do 
					if self[v] then 
						self[v]:Hide()
					end
				end
			end
		end 
		checkallbuttons(self)
	end 
	
	local function reset_button_click()
		local can = RemoveCosts(self,"gears",1)
		if not can then 
			local says = (TUNING.ICEY_LANGUAGE == "chinese" and "我必须消耗身上的1个齿轮来重置技能" ) or (TUNING.ICEY_LANGUAGE == "english" and "I need a gear to reset my skill" )
			self.owner.components.talker:Say(says)
			return 
		end 
		if TheWorld.ismastersim then
			OnSkillReset(self.owner)
		else
			SendModRPCToServer(MOD_RPC["icey_rpc"]["icey_skill_reset"])
		end 
		for i = 1,10 do 
			for k,v in pairs(button_team[i]) do 
				self[v]:Enable()
				self[v].image:SetTint(1,1,1,1)
			end 
		end 
		skill_main_call()
	end 

	
	self.skill_inspect = self:AddChild(Text(BODYTEXTFONT, 30,(TUNING.ICEY_LANGUAGE == "chinese" and "移动鼠标到技能图标上来查看技能介绍" ) or (TUNING.ICEY_LANGUAGE == "english" and "To check the description of a skill,you need to put your mouse on its icon" ))) --添加一个文本变量，接收Text实例。
	self.skill_inspect:SetColour(0/255,131/255,255/255,1)
	self.skill_inspect:SetHAnchor(0) -- 设置原点x坐标位置，0、1、2分别对应屏幕中、左、右
	self.skill_inspect:SetVAnchor(2) -- 设置原点y坐标位置，0、1、2分别对应屏幕中、上、下
    self.skill_inspect:SetPosition(0,130,0) -- 设置ancientmac widget相对原点的偏移量，70，-50表明向右70，向下50，第三个参数无意义。
	self.skill_inspect:Hide()
	
	self.skill_main = self:AddChild(Image("images/main.xml","main.tex"))
	self.skill_main:SetHAnchor(0) -- 设置原点x坐标位置，0、1、2分别对应屏幕中、左、右
	self.skill_main:SetVAnchor(0) -- 设置原点y坐标位置，0、1、2分别对应屏幕中、上、下
    self.skill_main:SetPosition(0,0,0) -- 设置ancientmac widget相对原点的偏移量，70，-50表明向右70，向下50，第三个参数无意义。
	self.skill_main:SetScale(1.1,1.1,1.1)
	self.skill_main:Hide()
	
	for i = 1,10 do 
		MakeSkillTeam(self,i,0,0,Vector3(-450 + 80*i,-130,0))
	end 
	
	self.skill_main_call = self:AddChild(TextButton("tianfu_button"))
	self.skill_main_call:SetText((TUNING.ICEY_LANGUAGE == "chinese" and "天赋" ) or (TUNING.ICEY_LANGUAGE == "english" and "Skills" ))
	self.skill_main_call:SetColour(0/255,131/255,255/255,1)
	self.skill_main_call:SetHAnchor(1) -- 设置原点x坐标位置，0、1、2分别对应屏幕中、左、右
	self.skill_main_call:SetVAnchor(2) -- 设置原点y坐标位置，0、1、2分别对应屏幕中、上、下
    self.skill_main_call:SetPosition(100,90,0) -- 设置ancientmac widget相对原点的偏移量，70，-50表明向右70，向下50，第三个参数无意义。
	self.skill_main_call:SetOnClick(skill_main_call)
	
	self.skill_reset = self:AddChild(TextButton("reset_button"))
	self.skill_reset:SetText((TUNING.ICEY_LANGUAGE == "chinese" and "重置技能(消耗一个齿轮)" ) or (TUNING.ICEY_LANGUAGE == "english" and "Use a gear to reset all skills" ))
	self.skill_reset:SetColour(0/255,131/255,255/255,1)
	self.skill_reset:SetHAnchor(0) -- 设置原点x坐标位置，0、1、2分别对应屏幕中、左、右
	self.skill_reset:SetVAnchor(0) -- 设置原点y坐标位置，0、1、2分别对应屏幕中、上、下
    self.skill_reset:SetPosition(300,300,0) -- 设置ancientmac widget相对原点的偏移量，70，-50表明向右70，向下50，第三个参数无意义。
	self.skill_reset:SetOnClick(reset_button_click)
	self.skill_reset:Hide()
	
	self.cd_list = self:AddChild(Text(BODYTEXTFONT, 30,(TUNING.ICEY_LANGUAGE == "chinese" and "技能列表:" ) or (TUNING.ICEY_LANGUAGE == "english" and "CD List:" ))) --添加一个文本变量，接收Text实例。
	self.cd_list:SetColour(0/255,131/255,255/255,1)
	self.cd_list:SetHAnchor(1) -- 设置原点x坐标位置，0、1、2分别对应屏幕中、左、右
	self.cd_list:SetVAnchor(2) -- 设置原点y坐标位置，0、1、2分别对应屏幕中、上、下
    self.cd_list:SetPosition(750,100,0) -- 设置ancientmac widget相对原点的偏移量，70，-50表明向右70，向下50，第三个参数无意义。
	
	self.overload_ui = self:AddChild(UIAnim()) 
	self.overload_ui:SetScale(0.5,0.5,0.5)
	self.overload_ui:GetAnimState():SetBank("overload_ui")
    self.overload_ui:GetAnimState():SetBuild("overload_ui")
    self.overload_ui:SetClickable(false)
	self.overload_ui:SetHAnchor(0) -- 设置原点x坐标位置，0、1、2分别对应屏幕中、左、右
	self.overload_ui:SetVAnchor(0) -- 设置原点y坐标位置，0、1、2分别对应屏幕中、上、下
    self.overload_ui:SetPosition(0,0,0) -- 设置ancientmac widget相对原点的偏移量，70，-50表明向右70，向下50，第三个参数无意义。
	self.overload_ui:Hide()
	self.overload_ui.oncheckfn = function(flag)
		print("overload_ui flag:"..tostring(flag))
		if (flag == "show") then 
			self.overload_ui:Show()
			self.overload_ui:GetAnimState():PlayAnimation("pre")
			self.overload_ui:GetAnimState():PushAnimation("loop",false)
			self.overload_ui:GetAnimState():PushAnimation("pst",false)
		else
			self.overload_ui:Hide()
		end 
	end
	
	
	--self.level:Hide()
	
	
	--self.skill_main:SetScale(2,2,2)
	--self.skill_main:MoveToFront()	
	
	--self.main:Hide()
	--self:ListenForEvent("icey_level_up",onlevelup,self.owner)
	
	self.skill_main_call = skill_main_call
	self.SetAllScale = SetAllScale

	checkallbuttons(self)
	self:StartUpdating()
end)

function IceyUi:OnUpdate(dt)
	local start = ((TUNING.ICEY_LANGUAGE == "chinese" and "技能列表:" ) or (TUNING.ICEY_LANGUAGE == "english" and "CD List:" ))
	--start = start..((TUNING.ICEY_LANGUAGE == "chinese" and " 迭影步:" ) or (TUNING.ICEY_LANGUAGE == "english" and " Shadow Step:" ))..getcd(self.owner,"icey_misscd",TUNING.ICEY_MISS_CD)
	start = start..((TUNING.ICEY_LANGUAGE == "chinese" and " 闪避充能:" ) or (TUNING.ICEY_LANGUAGE == "english" and " Shadow Step Nums:" ))..self.owner.icey_miss_num.."/"..self.owner.icey_max_miss_num
	if self.owner.hyperion == 1 then 
		start = start..((TUNING.ICEY_LANGUAGE == "chinese" and " 休伯利安号:" ) or (TUNING.ICEY_LANGUAGE == "english" and " Hyperion:" ))..getcd(self.owner,"icey_killcd",TUNING.ICEY_KILL_CD_H)
	end
	if self.owner.death_slaughter == 1 then 
		start = start..((TUNING.ICEY_LANGUAGE == "chinese" and " 死亡进击:" ) or (TUNING.ICEY_LANGUAGE == "english" and " Death Slaughter:" ))..getcd(self.owner,"icey_killcd",TUNING.ICEY_KILL_CD_DS)
	end
	if self.owner.sacrifice == 1 then 
		start = start..((TUNING.ICEY_LANGUAGE == "chinese" and " 超载融合:" ) or (TUNING.ICEY_LANGUAGE == "english" and " Overload Fusion:" ))..getcd(self.owner,"icey_killcd",TUNING.ICEY_KILL_CD_SA)
	end
	if self.owner.soul_torrent == 1 then 
		start = start..((TUNING.ICEY_LANGUAGE == "chinese" and " 灵魂洪流:" ) or (TUNING.ICEY_LANGUAGE == "english" and " Soul Torrent:" ))..getcd(self.owner,"icey_killcd",TUNING.ICEY_KILL_CD_SOUL)
	end
	self.cd_list:SetString(start)
	if self.skill_main.shown then 
		self.cd_list:Hide()
	else 
		self.cd_list:Show()
	end 
	checkallbuttons(self)
	--self.main:MoveToBack()
end 
return IceyUi
