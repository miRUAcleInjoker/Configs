local function DefaultFaceClient(inst,x,y,z,entity)
	if entity and not (x and y and z)  then 
		x,y,z = entity:GetPosition():Get()
	end
	inst:ForceFacePoint(x,y,z)
end 

local function CastVacuumSword(inst,x,y,z,entity)
	if inst.components.icey_vacuum_sword_user and inst.components.icey_vacuum_sword_user:CanDoAttack() 
	and not inst.sg:HasStateTag("attack")
	then 
		local mypos = inst:GetPosition()
		local targetpos = Vector3(x,y,z)
		local vec = (targetpos - mypos):GetNormalized()
		inst.components.icey_vacuum_sword_user:DoAttack(mypos + vec*1.2)
	end
end 

--[[if  TheNet:GetIsServer() then 
	AddModRPCHandler("icey","icey_castvacuumsword",CastVacuumSword)
else
	AddModRPCHandler("icey","icey_castvacuumsword",function() end)
end--]]

AddPlayerPostInit(function(inst)
	--[[if not inst.components.icey_keyhandler then 
		inst:AddComponent("icey_keyhandler")
	end 
	
	inst.components.icey_keyhandler:AddMouseActionListener(MOUSEBUTTON_LEFT,{
		Namespace = "icey",
		Action = "icey_castvacuumsword",
	},false,DefaultFaceClient)--]]
	
	if not TheWorld.ismastersim then
		return inst
	end

	inst:AddComponent("icey_vacuum_sword_user")
	
	

end) 