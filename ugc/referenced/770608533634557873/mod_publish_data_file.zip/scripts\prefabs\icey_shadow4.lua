local assets =
{
    Asset( "ANIM", "anim/icey.zip" ),
}

local function ondescription(inst,owner)
	if owner == inst.owner and owner:HasTag("icey") then 
		local x,y,z = inst:GetPosition():Get()
		local fx = SpawnPrefab("blossom_hit_fx")
		fx.AnimState:SetMultColour(4/255, 231/255, 251/255, 0.7)
		fx.Transform:SetPosition(x,y,z)
		owner.Transform:SetPosition(x,y,z)
		owner:DoTaskInTime(0,function()
			owner.components.talker:ShutUp()
			owner.AnimState:PlayAnimation("atk_pre")
            owner.AnimState:PushAnimation("atk", false)
		end)
		inst:Remove()
	end
	
	return ""
end 

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    --inst.entity:AddDynamicShadow()
	inst.entity:AddPhysics()
    inst.entity:AddNetwork()

    --inst.DynamicShadow:SetSize(1.5, .75)
    inst.Transform:SetFourFaced()

    inst.AnimState:SetBank("wilson") 
	inst.AnimState:SetBuild("icey")
    inst.AnimState:PlayAnimation("idle")
	
    inst.AnimState:Show("ARM_carry")
    inst.AnimState:Hide("ARM_normal")
	
	inst.AnimState:AddOverrideBuild("player_lunge")
    inst.AnimState:AddOverrideBuild("player_attack_leap")
    inst.AnimState:AddOverrideBuild("player_superjump")
    inst.AnimState:AddOverrideBuild("player_multithrust")
    inst.AnimState:AddOverrideBuild("player_parryblock")
	
	inst.Physics:SetMass(1)
    inst.Physics:SetFriction(0)
    inst.Physics:SetDamping(5)
    inst.Physics:SetCollisionGroup(COLLISION.CHARACTERS)
    inst.Physics:ClearCollisionMask()
    inst.Physics:CollidesWith(COLLISION.GROUND)
    inst.Physics:SetCapsule(.5, 1)

    inst:AddTag("scarytoprey")
    inst:AddTag("NOBLOCK")
	inst:AddTag("icey_shadow")


    inst.entity:SetPristine()
	

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.owner = nil 
	
	inst:AddComponent("colouradder")
   
    inst:AddComponent("bloomer")

    inst:AddComponent("inventory")
	
	inst:AddComponent("inspectable")
	inst.components.inspectable.descriptionfn = ondescription
	
	inst.persists = false 

    return inst
end

return Prefab("icey_shadow4", fn, assets)