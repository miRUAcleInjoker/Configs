local IceyUtil = require("icey_util")

local function TickTask(inst)
	local target = inst.components.debuff.target
	if target and target:IsValid() then 
		if target.components.hunger and inst.hunger_delta_tick then 
			target.components.hunger:DoDelta(inst.hunger_delta_tick,true)
		end
		
		if target.components.health and not target.components.health:IsDead() and inst.health_delta_tick then 
			target.components.health:DoDelta(inst.health_delta_tick,true,inst.buffname or inst.prefab,nil,nil,true)
		end
		
		if target.components.sanity and inst.sanity_delta_tick then 
			target.components.sanity:DoDelta(inst.sanity_delta_tick,true)
		end
	end
end 

local function PercentTask(inst)
	if inst.percent < 1 and inst.percent > 0 then 
		inst.percent = inst.percent - 0.0003
		inst.percent = math.max(0,inst.percent)
	else
		if inst.percent_task then 
			inst.percent_task:Cancel()
			inst.percent_task = nil 
		end
		
		if inst.percent < 0 then 
			inst.components.debuff:Stop()
		end
	end
	
	inst._percent:set(inst.percent)
end 

local function ApplyDebuff(inst,target)
	if inst.percent >= 1 then 
		if target.components.combat then
			target.components.combat.externaldamagemultipliers:SetModifier(inst,inst.damage_multi,inst.buffname)
			target.components.combat.externaldamagetakenmultipliers:SetModifier(inst,inst.damagetaken_multi,inst.buffname)
		end 
			
		if target.components.hunger then
			target.components.hunger.burnratemodifiers:SetModifier(inst,inst.hunger_multi,inst.buffname)
		end 
			
		if target.components.sanity then 
			target.components.sanity.externalmodifiers:SetModifier(inst,inst.sanity_additive,inst.buffname)
		end 
			
		if target.components.locomotor then 
			target.components.locomotor:SetExternalSpeedMultiplier(inst,inst.buffname,inst.speed_multi)
		end 
			
		if target.components.stamina then 
			target.components.stamina.externalrecoverratemultipliers:SetModifier(inst,inst.stamina_recover_multi,inst.buffname)
			target.components.stamina.externalconsumeratemultipliers:SetModifier(inst,inst.stamina_consume_multi,inst.buffname)
		end 
		
		if target.components.focus then 
			target.components.focus.externalmodifiers:SetModifier(inst,inst.focus_additive,inst.buffname)
		end 	

		if inst.type == "poison" then 
			inst.buff_fx = target:SpawnChild("poisonbubble")
			
		elseif inst.type == "strong_poison" then 
			inst.buff_fx = target:SpawnChild("poisonbubble")
		end
	
		if inst.ticktask then 
			inst.ticktask:Cancel()
			inst.ticktask = nil 
		end
		inst.ticktask = inst:DoPeriodicTask(0,TickTask)
	end 
end 

local function RemoveDebuff(inst,target)
	if target.components.combat then
		target.components.combat.externaldamagemultipliers:RemoveModifier(inst,inst.buffname)
		target.components.combat.externaldamagetakenmultipliers:RemoveModifier(inst,inst.buffname)
	end 
	
	if target.components.hunger then
		target.components.hunger.burnratemodifiers:RemoveModifier(inst,inst.buffname)
	end 
	
	if target.components.sanity then 
		target.components.sanity.externalmodifiers:RemoveModifier(inst,inst.buffname)
	end 
	
	if target.components.locomotor then 
		target.components.locomotor:RemoveExternalSpeedMultiplier(inst,inst.buffname)
	end 
	
	if target.components.stamina then 
		target.components.stamina.externalrecoverratemultipliers:RemoveModifier(inst,inst.buffname)
		target.components.stamina.externalconsumeratemultipliers:RemoveModifier(inst,inst.buffname)
	end 
	
	if target.components.focus then 
		target.components.focus.externalmodifiers:RemoveModifier(inst,inst.buffname)
	end 	
	
	if inst.buff_fx and inst.buff_fx:IsValid() then 
		if inst.buff_fx.KillFX then 
			inst.buff_fx:KillFX()
		else
			inst.buff_fx:Remove() 
		end
	end
	inst.buff_fx = nil 
	
	if inst.type == "poison" then 
		
	elseif inst.type == "strong_poison" then 

	end
	
	if inst.ticktask then 
		inst.ticktask:Cancel()
		inst.ticktask = nil 
	end
end 

local function OnAttached(inst, target)
    inst.entity:SetParent(target.entity)
	--[[if target.sg then 
		target.sg:GoToState("powerup")
	end --]]
	
	inst:DoTaskInTime(0,function()
		ApplyDebuff(inst,target)
	end)
	
    inst:ListenForEvent("death", function()
        inst.components.debuff:Stop()
    end, target)
	
	--inst.buff_fx = target:SpawnChild("battlestandard_buff_fxs")
	--inst.buff_fx:Play("defend_fx")
end

local function OnDetached(inst, target)
	RemoveDebuff(inst,target)
	inst:Remove()
end

local function OnTimerDone(inst, data)
    if data.name == "startiron" then
        inst.components.debuff:Stop()
    end
end

local function OnExtended(inst, target)
	RemoveDebuff(inst,target)
	inst:DoTaskInTime(0,function()
		ApplyDebuff(inst,target)
	end)
	
	if inst.percent >= 1 then 
		inst.components.timer:StopTimer("startiron")
		inst.components.timer:StartTimer("startiron", inst.duration)
	end 
end

local function OnSave(inst,data)
	data.buffname = inst.buffname 
	--data.buff_fx = inst.buff_fx
	data.duration = inst.duration 
	data.damage_multi = inst.damage_multi 
	data.damagetaken_multi = inst.damagetaken_multi 
	data.hunger_multi = inst.hunger_multi 
	data.sanity_additive = inst.sanity_additive 
	data.speed_multi = inst.speed_multi
	data.stamina_recover_multi = inst.stamina_recover_multi 
	data.stamina_consume_multi = inst.stamina_consume_multi 
	data.focus_additive = inst.focus_additive 
	data.percent = inst.percent 
	data.health_delta_tick = inst.health_delta_tick 
	data.hunger_delta_tick = inst.hunger_delta_tick 
	data.sanity_delta_tick = inst.sanity_delta_tick 
	data.keepondespawn = inst.keepondespawn 
	data.type = inst.type
end 

local function OnLoad(inst,data)
	data = data or {} 
	--[[inst.buffname = data.buffname or inst.prefab 
	--inst.buff_fx = data.buff_fx
	inst.duration = data.duration or 15 
	inst.damage_multi = data.damage_multi or 1
	inst.damagetaken_multi = data.damagetaken_multi or 1
	inst.hunger_multi = data.hunger_multi or 1
	inst.sanity_additive = data.sanity_additive or 0 
	inst.speed_multi = data.speed_multi or 1
	inst.stamina_recover_multi = data.stamina_recover_multi or 1
	inst.stamina_consume_multi = data.stamina_consume_multi or 1
	inst.focus_additive = data.focus_additive or 0
	inst.percent = data.percent or 1
	inst.health_delta_tick = data.health_delta_tick 
	inst.hunger_delta_tick = data.hunger_delta_tick
	inst.sanity_delta_tick = data.sanity_delta_tick 
	inst.type = data.type --]]
	inst:Init(data)
end 

local function NetInit(inst)
	local parent = inst.entity:GetParent()
    if parent ~= nil then
		local net_type = inst._type:value()
		if net_type == "poison" then 
			parent:PushEvent("startcorrosivedebuff", inst)
		elseif net_type == "strong_poison" then 
			parent:PushEvent("startcorrosivedebuff", inst)
		end 
        
    end
end 

local function fn(inst)
	local inst = CreateEntity()
	local trans = inst.entity:AddTransform()
	inst.entity:AddNetwork()
	inst.entity:AddAnimState()
	inst.entity:AddSoundEmitter()

	inst:AddTag("CLASSIFIED")
	
	
	
	

	--inst:DoTaskInTime(0,NetInit)
	inst._percent = net_float(inst.GUID,"inst._percent","onpercentdirty")
	inst._type = net_string(inst.GUID,"inst._type","ontypedirty")
	
	inst.entity:SetPristine()

    if not TheWorld.ismastersim then
		inst:ListenForEvent("ontypedirty",NetInit)
        return inst
    end
	
	inst.duration = 15
	inst.Init = function(self,data)
		if data then 
			inst.buffname = data.buffname or inst.prefab 
			inst.buff_fx = data.buff_fx
			inst.duration = data.duration or 15 
			inst.damage_multi = data.damage_multi or 1
			inst.damagetaken_multi = data.damagetaken_multi or 1
			inst.hunger_multi = data.hunger_multi or 1
			inst.sanity_additive = data.sanity_additive or 0 
			inst.speed_multi = data.speed_multi or 1
			inst.stamina_recover_multi = data.stamina_recover_multi or 1
			inst.stamina_consume_multi = data.stamina_consume_multi or 1
			inst.focus_additive = data.focus_additive or 0
			inst.percent = data.percent or 1
			
			inst.health_delta_tick = data.health_delta_tick 
			inst.hunger_delta_tick = data.hunger_delta_tick 
			inst.sanity_delta_tick = data.sanity_delta_tick 
			
			inst.keepondespawn = data.keepondespawn 
			
			
			inst.type = data.type
			if inst.type then 
				inst._type:set(inst.type)
				inst._type:set_local(inst.type)
			end 
		end 
		
		inst.components.debuff.keepondespawn = inst.keepondespawn
		if inst.percent < 1 then 
			if inst.percent_task then 
				inst.percent_task:Cancel()
				inst.percent_task = nil 
			end
			inst.percent_task = inst:DoPeriodicTask(0,PercentTask)
		end
		
		inst._percent:set(inst.percent)
		
	end 
	
    inst:AddComponent("debuff")
    inst.components.debuff:SetAttachedFn(OnAttached)
    inst.components.debuff:SetDetachedFn(OnDetached)
    inst.components.debuff:SetExtendedFn(OnExtended)
    --inst.components.debuff.keepondespawn = true
	
	
	
    inst:AddComponent("timer")
	inst:DoTaskInTime(0, function() -- in case we want to change duration
		if inst.percent >= 1 then 
			inst.components.timer:StartTimer("startiron", inst.duration)
		end 
	end)
    inst:ListenForEvent("timerdone", OnTimerDone)
	
	inst:Init({})
	
	inst.OnSave = OnSave
	inst.OnLoad = OnLoad 
	
	return inst
	
end
--ThePlayer.components.debuffable:AddDebuff("pyromancy_iron_flesh_debuff", "pyromancy_iron_flesh_debuff")
return Prefab("icey_normal_debuff", fn)