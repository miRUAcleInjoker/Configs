local assets =
{
    Asset("ANIM", "anim/flyhead_stone.zip"),
	Asset("IMAGE","images/inventoryimages/flyhead_stone.tex"),
	Asset("ATLAS","images/inventoryimages/flyhead_stone.xml"),
}

local function OnPutInInventory(inst,owner)
	inst.lastowner = owner
end 

local function OnDropped(inst)
	local owner = inst.lastowner
	if owner and owner:IsValid() then 
		if owner.components.deadcellpassive_flyhead:IsFlyingHead() then 
			owner.components.deadcellpassive_flyhead:StopFlyHead()
		end 
	end
	
	inst.lastowner = nil 
end 

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()

    MakeInventoryPhysics(inst)

    inst.AnimState:SetBank("flyhead_stone")
    inst.AnimState:SetBuild("flyhead_stone")
    inst.AnimState:PlayAnimation("idle")

    inst:AddTag("molebait")

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

	inst.lastowner = nil 

    inst:AddComponent("inspectable")

    inst:AddComponent("inventoryitem")
    inst.components.inventoryitem:SetSinks(true)
	inst.components.inventoryitem.imagename = "flyhead_stone"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/flyhead_stone.xml"

    inst:AddComponent("tradable")
    inst.components.tradable.rocktribute = 3

    inst:AddComponent("bait")

    MakeHauntableLaunch(inst)
	
	inst:ListenForEvent("ondropped",OnDropped)
	inst:ListenForEvent("onputininventory",OnPutInInventory)
	
	inst:DoTaskInTime(0,function()
		inst.lastowner = inst.components.inventoryitem:GetGrandOwner()
	end)

    return inst
end

return Prefab("flyhead_stone", fn, assets)