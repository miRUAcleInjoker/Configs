
local function MakeGasMask(name,dapperness,fueledtime,maxdamage)
    local fname = "hat_"..name
    local symname = name.."hat"
    local prefabname = symname
	local assets=
		{
			Asset("ANIM", "anim/"..fname..".zip"),
			
			Asset("ATLAS", "images/inventoryimages/"..prefabname..".xml"),
			Asset("IMAGE", "images/inventoryimages/"..prefabname..".tex"),
		}
	local function OnOwnerAttacked(owner,data)
		local gasmask = owner.components.inventory:GetEquippedItem(EQUIPSLOTS.HEAD)
		local damage = data.damage or 10
		if gasmask and gasmask:IsValid() then 
			gasmask.current_damage = gasmask.current_damage + damage
			if gasmask.current_damage >= gasmask.max_damage then 
				--SpawnAt("",owner)
				owner.sg:GoToState("toolbroke",gasmask)
				gasmask:Remove() 
			end
		end
	end 
	local function OnEquip(inst, owner,symbol_override) 
		owner.AnimState:OverrideSymbol("swap_hat", fname, symbol_override or "swap_hat")
		owner.AnimState:Show("HAT")
		owner.AnimState:Show("HAIR_HAT")
		owner.AnimState:Hide("HAIR_NOHAT")
		owner.AnimState:Hide("HAIR")

		if owner:HasTag("player") then
			owner.AnimState:Hide("HEAD")
			owner.AnimState:Show("HEAD_HAT")
		end
		
		if inst.components.fueled then
			inst.components.fueled:StartConsuming()        
		end
		
		inst:ListenForEvent("attacked",OnOwnerAttacked,owner)
	end

	local function OnUnequip(inst, owner) 
		owner.AnimState:ClearOverrideSymbol("swap_hat")
		owner.AnimState:Hide("HAT")
		owner.AnimState:Hide("HAIR_HAT")
		owner.AnimState:Show("HAIR_NOHAT")
		owner.AnimState:Show("HAIR")
		if owner:HasTag("player") then
			owner.AnimState:Show("HEAD")
			owner.AnimState:Hide("HEAD_HAT")
		end
		
		if inst.components.fueled then
			inst.components.fueled:StopConsuming()        
		end
		
		inst:RemoveEventCallback("attacked",OnOwnerAttacked,owner)
	end
	
	local function freshfueled(inst)
		if inst.components.fueled then 
			if  inst.components.fueled:IsEmpty() then 
				inst:RemoveTag("anti_radiation")
			else
				inst:AddTag("anti_radiation")
			end 
		end
	end 
	
	local function ontakefuel(inst,data)
		freshfueled(inst)
		if inst.components.equippable:IsEquipped() then 
			if inst.components.fueled then
				inst.components.fueled:StartConsuming()        
			end
		end
	end 
	
	local function OnSave(inst,data)
		data.current_damage = inst.current_damage
		--data. = inst.max_damage
	end 
	
	local function OnLoad(inst,data)
		if data then 
			inst.current_damage = data.current_damage or 0
		end 
	end 
	
	local function fn()
		local inst = CreateEntity()
		inst.entity:AddTransform()
		inst.entity:AddTransform()
		inst.entity:AddAnimState()
		inst.entity:AddSoundEmitter()
		inst.entity:AddNetwork()  --�������Ҳ����� 
		
		MakeInventoryPhysics(inst)	
		inst.AnimState:SetBank(symname)
        inst.AnimState:SetBuild(fname)
        inst.AnimState:PlayAnimation("anim",true)
		
		inst:AddTag("hat")
		inst:AddTag("anti_radiation")
		
		----------------------����Ķ��� ������������Ч
		
		inst.entity:SetPristine()   --���ľ仰 �ŵ����� Ҳ����bank build ��tag֮��ĺ���-��-
		if not TheWorld.ismastersim then
			return inst
		end
		
		inst.current_damage = 0
		inst.max_damage = maxdamage
		
		----------------------�����ֻ������ִ��
		
		inst:AddComponent("tradable")
		
		inst:AddComponent("inspectable")
		inst.components.inspectable:SetDescription("�Ҳ����������ͷ��.....")
		
		inst:AddComponent("waterproofer")
		inst.components.waterproofer:SetEffectiveness(TUNING.WATERPROOFNESS_SMALL)


		inst:AddComponent("inventoryitem")
		inst.components.inventoryitem.imagename = prefabname
		inst.components.inventoryitem.atlasname = "images/inventoryimages/"..prefabname..".xml"
		
		inst:AddComponent("equippable")
		inst.components.equippable.equipslot = EQUIPSLOTS.HEAD 
		inst.components.equippable:SetOnEquip(OnEquip)
		inst.components.equippable:SetOnUnequip(OnUnequip)
		inst.components.equippable.dapperness = dapperness
		
		--[[inst:AddComponent("armor")
		inst.components.armor:InitCondition(350, 0.1)--]]
		
		if fueledtime then
			inst:AddComponent("fueled")
			inst.components.fueled.accepting = true
			inst.components.fueled.fueltype = FUELTYPE.GASMASK
			inst.components.fueled:InitializeFuelLevel(fueledtime) -- TUNING.STRAWHAT_PERISHTIME
			inst.components.fueled:SetDepletedFn(freshfueled)
			
			freshfueled(inst)
			inst:ListenForEvent("percentusedchange",freshfueled)
			inst:ListenForEvent("takefuel",ontakefuel)
			
		end
		
		inst.OnSave = OnSave
		inst.OnLoad = OnLoad
		
		
		MakeHauntableLaunch(inst)  --����ź���ͺ���

		return inst
	end 
	
	return Prefab(prefabname, fn, assets)
end


return MakeGasMask("gas",-TUNING.DAPPERNESS_MED,TUNING.TOTAL_DAY_TIME,125),
	   MakeGasMask("gasmask",-TUNING.DAPPERNESS_MED*3,TUNING.TOTAL_DAY_TIME*2.5,450)

