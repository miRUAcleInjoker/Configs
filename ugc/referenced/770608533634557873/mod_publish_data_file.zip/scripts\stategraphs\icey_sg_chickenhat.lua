local function DoEmoteFX(inst, prefab)
    local fx = SpawnPrefab(prefab) 
    if fx ~= nil then 
        if inst.components.rider:IsRiding() then 
            fx.Transform:SetSixFaced() 
        end 
        fx.entity:SetParent(inst.entity) 
        fx.entity:AddFollower() 
        fx.Follower:FollowSymbol(inst.GUID, "emotefx", 0, 0, 0) 
    end
end

local function DoForcedEmoteSound(inst, soundpath)
    inst.SoundEmitter:PlaySound(soundpath)
end

local function DoEmoteSound(inst, soundoverride, loop)
    --NOTE: loop only applies to soundoverride
    loop = loop and soundoverride ~= nil and "emotesoundloop" or nil
    local soundname = soundoverride or "emote"
    local emotesoundoverride = soundname.."soundoverride"
    if inst[emotesoundoverride] ~= nil then
        inst.SoundEmitter:PlaySound(inst[emotesoundoverride], loop)
    elseif not inst:HasTag("mime") then
        inst.SoundEmitter:PlaySound((inst.talker_path_override or "dontstarve/characters/")..(inst.soundsname or inst.prefab).."/"..soundname, loop)
    end
end

--

local function AddChickenLaughSG(name,anim,force_timeout,talkfn)
	anim = anim or "emote_laugh"
	
	AddStategraphPostInit(name,function(self)
		local old_ontimeout = self.states.idle.ontimeout or function(inst) end 
		local old_onenter = self.states.idle.onenter or function(inst) end 
		self.states.idle.ontimeout = function(inst)
			
			local chicken_man = nil
			local mindistsq = 25
			for i, v in ipairs(AllPlayers) do
				if v ~= inst and not v:HasTag("playerghost") and v.entity:IsVisible() and v.components.inventory:EquipHasTag("hat_icey_chicken") then
					local distsq = v:GetDistanceSqToInst(inst)
					if distsq < mindistsq then
						mindistsq = distsq
						chicken_man = v
					end
				end
			end
			if not (inst.components.combat and inst.components.combat.target) and chicken_man ~= nil then
				return inst.sg:GoToState("laugh_at_chicken", chicken_man)
			else 
				return old_ontimeout(inst)
			end 
		end
		
		if force_timeout then 
			self.states.idle.onenter = function(inst,...)
				local ret =  old_onenter(inst,...)
				inst.sg:SetTimeout(inst.AnimState:GetCurrentAnimationLength() + 2 * FRAMES)
				return ret 
			end 
		end 
	end)
	
	

	AddStategraphState(name, 
		State{
			name = "laugh_at_chicken",
			tags = { "notalking", "busy", "nopredict", "forcedangle" },
			onenter = function(inst,target)
				if target ~= nil then
					inst.sg.statemem.target = target
					inst:ForceFacePoint(target.Transform:GetWorldPosition())
				end
				inst.AnimState:PlayAnimation(anim)
			end,
			timeline =
			{
				TimeEvent(5 * FRAMES, function(inst)
					local mount = inst.components.rider and inst.components.rider:GetMount()
					if mount ~= nil and mount.sounds ~= nil and mount.sounds.grunt ~= nil then
						inst.SoundEmitter:PlaySound(mount.sounds.grunt)
					end
				end),
				TimeEvent(6 * FRAMES, function(inst)
					if inst.sg.statemem.target ~= nil and
						inst.sg.statemem.target:IsValid() and
						inst.sg.statemem.target:IsNear(inst, 6) and
						inst.sg.statemem.target.components.inventory:EquipHasTag("hat_icey_chicken") and
						inst.components.talker ~= nil then
						--DoEmoteFX(inst, "emote_fx")
						local str_mock = STRINGS.LAUGHAT_CHICKEN[inst.prefab:upper()] or STRINGS.LAUGHAT_CHICKEN.GENERIC
						if type(str_mock) == "table" then 
							str_mock = str_mock[math.random(1,#str_mock)]
						end 
						str_mock = string.format(str_mock,inst.sg.statemem.target.name or "")
						inst.components.talker:Say(str_mock)
						if talkfn then 
							talkfn(inst)
						else
							DoEmoteSound(inst)
						end
						
					else
						inst.sg.statemem.notalk = true
					end
				end),
			},
			events =
			{
				EventHandler("animover", function(inst)
					inst.sg:GoToState("idle")
				end),
			},	
		}
	)
end 



AddChickenLaughSG("wilson")
AddChickenLaughSG("pig","idle_happy",true,function(inst)
	if inst:HasTag("pig") and not inst:HasTag("manrabbit") then 
		inst.SoundEmitter:PlaySound("dontstarve/pig/oink")
	end 
end)

