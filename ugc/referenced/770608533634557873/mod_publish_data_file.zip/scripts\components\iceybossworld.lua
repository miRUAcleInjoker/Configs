local IceyBossWorld = Class(function(self, inst)
	self.inst = inst
	self.DefeatedBoss = {}
	--self.attackers = {}
	
	--self.inst:ListenForEvent()
end)

function IceyBossWorld:IsDefeated(name)
	for k,v in pairs(self.DefeatedBoss) do 
		if name == v then 
			return true
		end
	end
	return false 
end 

function IceyBossWorld:Add(name)
	if not name then 
		return 
	end 
	if not self:IsDefeated(name) then 
		table.insert(self.DefeatedBoss,name)
	end 
	self:Debug("Add")
end

function IceyBossWorld:Remove(name)
	local i = 0
	while i <= #self.DefeatedBoss do 
		if self.DefeatedBoss[i] == name then 
			table.remove(self.DefeatedBoss,i)
		else
			i = i + 1
		end
	end 
	self:Debug("Remove")
end

function IceyBossWorld:OnSave()
	return {
		DefeatedBoss = self.DefeatedBoss
	}
end

function IceyBossWorld:OnLoad(data)
	if data then 
		self.DefeatedBoss = data.DefeatedBoss
	end 
	self:Debug("OnLoad")
end 

function IceyBossWorld:Debug(source)
	source = source or "NULL"
	local debugstr = "IceyBossWorld Debug: source:"..source.."  DefeatedBoss:"
	for k,v in pairs(self.DefeatedBoss) do 
		debugstr = debugstr..v.."  "
	end
	print(debugstr)
end

return IceyBossWorld