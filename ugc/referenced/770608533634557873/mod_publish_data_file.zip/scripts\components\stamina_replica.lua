local Stamina = Class(function(self, inst)
	self.inst = inst 
	self._current = net_ushortint(inst.GUID, "stamina._current", "staminadirty")
    self._max = net_ushortint(inst.GUID, "stamina._max", "staminadirty")
end)

function Stamina:SetMax(max)
	self._max:set(max)
end

function Stamina:SetCurrent(current)
	current = math.max(0,current)
	current = math.min(self._max:value(),current)
	self._current:set(current)
end

function Stamina:GetCurrent()
	return self._current:value()
end

function Stamina:GetMax()
	return self._max:value()
end 

function Stamina:GetPercent()
	return self:GetCurrent() / self:GetMax()
end


return Stamina