
local assets = {
    Asset("ANIM", "anim/blowdart_lava2.zip"),
    Asset("ANIM", "anim/swap_blowdart_lava2.zip"),
}

local assets_projectile = {
    Asset("ANIM", "anim/lavaarena_blowdart_attacks.zip"),
}

local prefabs = {
    "moltendarts_projectile",
    "moltendarts_projectile_explosive",
    "reticulelong",
    "reticulelongping",
}

local prefabs_projectile = {
    "weaponsparks_piercing",
}

local prefabs_projectile_explosive = {
    "explosivehit",
}

local FADE_FRAMES = 5

local tails = {
    ["tail_5_2"] = .15,
    ["tail_5_3"] = .15,
    ["tail_5_4"] = .2,
    ["tail_5_5"] = .8,
    ["tail_5_6"] = 1,
    ["tail_5_7"] = 1,
}

local thintails = {
    ["tail_5_8"] = 1,
    ["tail_5_9"] = .5,
}

local function CreateTail(thintail, tail_suffix)
    local inst = CreateEntity()

    inst:AddTag("FX")
    inst:AddTag("NOCLICK")
    --[[Non-networked entity]]
    inst.entity:SetCanSleep(false)
    inst.persists = false

    inst.entity:AddTransform()
    inst.entity:AddAnimState()

    inst.AnimState:SetBank("lavaarena_blowdart_attacks")
    inst.AnimState:SetBuild("lavaarena_blowdart_attacks")
    inst.AnimState:PlayAnimation(weighted_random_choice(thintail and thintails or tails)..tail_suffix)
    inst.AnimState:SetOrientation(ANIM_ORIENTATION.OnGround)
    if not thintail then
        inst.AnimState:SetAddColour(1, 1, 0, 0)
    end

    inst:ListenForEvent("animover", inst.Remove)

    return inst
end

local function OnUpdateProjectileTail(inst, tail_suffix)
    local c = (not inst.entity:IsVisible() and 0) or (inst._fade ~= nil and (FADE_FRAMES - inst._fade:value() + 1) / FADE_FRAMES) or 1
    if c > 0 then
        local tail = CreateTail(inst.thintailcount > 0, tail_suffix)
        tail.Transform:SetPosition(inst.Transform:GetWorldPosition())
        tail.Transform:SetRotation(inst.Transform:GetRotation())
        if c < 1 then
            tail.AnimState:SetTime(c * tail.AnimState:GetCurrentAnimationLength())
        end
        if inst.thintailcount > 0 then
            inst.thintailcount = inst.thintailcount - 1
        end
    end
end

local function OnHit(inst, owner, target, alt)
	if not alt then
		SpawnPrefab("icey_weaponsparks"):SetPiercing(inst, target)
	else
		SpawnPrefab("explosivehit").Transform:SetPosition(inst:GetPosition():Get())
	end
	inst:Remove()
end

local function OnMiss(inst, owner)
	inst:Remove()
end

local function OnHitAlt(inst, owner, target)
	SpawnPrefab("explosivehit").Transform:SetPosition(inst:GetPosition():Get())
	inst:Remove()
end 

local function commonprojectilefn(anim, tail_suffix, alt)
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
	inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()

    MakeInventoryPhysics(inst)
    RemovePhysicsColliders(inst)

    inst.AnimState:SetBank("lavaarena_blowdart_attacks")
    inst.AnimState:SetBuild("lavaarena_blowdart_attacks")
    inst.AnimState:PlayAnimation(anim, true)
    inst.AnimState:SetOrientation(ANIM_ORIENTATION.OnGround)
    inst.AnimState:SetAddColour(1, 1, 0, 0)
    inst.AnimState:SetBloomEffectHandle("shaders/anim.ksh")

    --projectile (from projectile component) added to pristine state for optimization
    inst:AddTag("projectile")

    if not TheNet:IsDedicated() then
        inst.thintailcount = alt and math.random(3, 5) or math.random(2, 4)
        inst:DoPeriodicTask(0, OnUpdateProjectileTail, nil, tail_suffix)
    end

    if alt then
        inst._fade = net_tinybyte(inst.GUID, "blowdart_lava2_projectile_explosive._fade")
    end

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    if not alt then
		inst:AddComponent("projectile")
		inst.components.projectile:SetSpeed(30)
		inst.components.projectile:SetRange(20)
		inst.components.projectile:SetOnHitFn(function(inst, attacker, target) OnHit(inst, inst.components.projectile.owner, target, alt) end)
		inst.components.projectile:SetOnMissFn(inst.Remove)
		inst.components.projectile:SetLaunchOffset(Vector3(0, 1, 0))
	else
		inst:AddComponent("ly_projectile")
		inst.components.ly_projectile.damage = 68
		inst.components.ly_projectile:SetSpeed(30)
		inst.components.ly_projectile:SetRange(30)
		inst.components.ly_projectile:SetOnHitFn(OnHitAlt)
		inst.components.ly_projectile:SetOnMissFn(OnMiss)
		inst.components.ly_projectile:SetLaunchOffset(Vector3(0, 1, 0))
	end
	
	--inst:DoTaskInTime(0, function(inst) inst.SoundEmitter:PlaySound("dontstarve/common/lava_arena/blow_dart") end)

    return inst
end

local function projectilefn()
    return commonprojectilefn("attack_4", "", false)
end

local function projectileexplosivefn()
    return commonprojectilefn("attack_4_large", "_large", true)
end

return Prefab("icey_moltendarts_projectile", projectilefn, assets_projectile, prefabs_projectile),
    Prefab("icey_moltendarts_projectile_explosive", projectileexplosivefn, assets_projectile, prefabs_projectile_explosive)