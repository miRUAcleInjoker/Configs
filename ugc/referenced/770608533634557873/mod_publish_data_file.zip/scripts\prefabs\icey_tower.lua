local assets_tower = {
	Asset("ANIM", "anim/icey_tower.zip"),--------建筑的贴图文件
}

----------------------------------------------------------------------------------------------------------------------

SetSharedLootTable( 'icey_tower',     --------------建筑被破坏后掉落的东西列表
{
    {'crystal_item', 1.00},-----------红宝石？太土了吧！
	{'crystal_item', 0.75},-----------红宝石？太土了吧！
	{'crystal_item', 0.50},-----------红宝石？太土了吧！
})


local function OnAttacked(inst,attacker)
	inst.AnimState:PlayAnimation("hit")
	inst.AnimState:PushAnimation("idle")
	inst.SoundEmitter:PlaySound("dontstarve/wilson/use_pick_rock")
end 

local function OnKilled(inst)----------------------爆炸的一堆特效
	--inst.Transform:SetMultColor()
	local x,y,z = inst:GetPosition():Get()
	local bomb = SpawnPrefab("explode_small")
	local crackle = SpawnPrefab("hammer_mjolnir_crackle")
	local cracklebase = SpawnPrefab("hammer_mjolnir_cracklebase")
	local cracklehit = SpawnPrefab("hammer_mjolnir_cracklehit")
	local cracklehitfx = SpawnPrefab("cracklehitfx")
	
	bomb.Transform:SetScale(3,3,3)

	bomb.Transform:SetPosition(x,y,z)
	crackle.Transform:SetPosition(x,y,z)
	cracklebase.Transform:SetPosition(x,y,z)
	cracklehit.Transform:SetPosition(x,y,z)
	cracklehitfx.Transform:SetPosition(x,y,z)
	
	crackle.AnimState:SetMultColour(73/255, 240/255, 235/255, 0.9)
	cracklebase.AnimState:SetMultColour(73/255, 240/255, 235/255, 1)
	cracklehit.AnimState:SetMultColour(73/255, 240/255, 235/255, 1)
	cracklehitfx.AnimState:SetMultColour(73/255, 240/255, 235/255, 1)
	
	crackle:ListenForEvent("animover", function(inst) inst:Remove() end )
	cracklebase:ListenForEvent("animover", function(inst) inst:Remove() end )
	cracklehit:ListenForEvent("animover", function(inst) inst:Remove() end )
	cracklehitfx:ListenForEvent("animover", function(inst) inst:Remove() end )
	
	inst:Hide()-------------------只是隐藏贴图，以免Remove()造成意外的报错(不知为何水晶塔的死亡动画不能被编译)
	
end

local function PowerBoard(inst,rad,power)
	--print(inst,"onpower board")
    local x,y,z = inst:GetPosition():Get()
    local ents = TheSim:FindEntities(x,y,z,rad,{"icey_power_building"},{"icey_power_board","INLIMBO"})
    for k,v in pairs(ents) do 
        v:PushEvent("powertrans",{fromer = inst,power = power})
    end
end 

local function ShouldAcceptItem(inst, item)
	return item:HasTag("securitycontract")
end
--[[makepigman("pigman_aiurguard",         "pig_royalguard",   nil,  true, nil, nil, "MALE" ),
        makepigman("pigman_aiurguard_2",       "pig_royalguard_2", nil,  true, nil, nil, "MALE" ), 
		makepigman("pigman_aiurguard_3",       "pig_royalguard_3", nil,  true, nil, nil, "MALE" ),
		makepigman("pigman_aiurguard_rich",       "pig_royalguard_rich", nil,  true, nil, nil, "MALE" ),
		makepigman("pigman_aiurguard_rich_2",       "pig_royalguard_rich_2", nil,  true, nil, nil, "MALE" )  --]]
local function OnGetItemFromPlayer(inst, giver, item)
	local offset = FindWalkableOffset(inst:GetPosition(),math.random()*2*PI,5+3*math.random(),12) or Vector3(0,0,0) 
	local fx = SpawnAt("positronbeam_front",inst:GetPosition()+offset-Vector3(0,1,0))
	fx.Transform:SetScale(3,3,3)
	fx.SoundEmitter:PlaySound("dontstarve/common/together/moonbase/beam_level_up")
	fx.SoundEmitter:PlaySound("dontstarve/common/together/moonbase/beam", "beam")
	local pigs = {
		"pigman_aiurguard",
		"pigman_aiurguard_2",
		"pigman_aiurguard_3",
		"pigman_aiurguard_rich",
		"pigman_aiurguard_rich_2",
	}
	local time = 2+math.random()
	fx:DoTaskInTime(time,function()
		local pigprefab = pigs[math.random(1,#pigs)]
		local pig = SpawnAt(pigprefab,fx:GetPosition())
		local spawnfx = SpawnAt("positronpulse",fx:GetPosition())
		spawnfx.Transform:SetScale(1.5,1.5,1.5)
		spawnfx:FinishFX()
		pig.components.spawnfader:FadeIn()
		if giver.components.leader ~= nil  then
			giver:PushEvent("makefriend")
			giver.components.leader:AddFollower(pig)
			pig.components.follower:AddLoyaltyTime(150*TUNING.PIG_LOYALTY_PER_HUNGER)
			pig.components.follower.maxfollowtime = giver:HasTag("polite") 
				and TUNING.PIG_LOYALTY_MAXTIME + TUNING.PIG_LOYALTY_POLITENESS_MAXTIME_BONUS
				or TUNING.PIG_LOYALTY_MAXTIME
		end
		fx.SoundEmitter:KillSound("beam")
		fx:KillFX()
	end)
	
end

local function OnRefuseItem(inst, item)

end

local function towerfn()
	 local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddMiniMapEntity()
	inst.entity:AddLight()
    inst.entity:AddNetwork()

    MakeObstaclePhysics(inst, 1) --------------建筑物理碰撞体积
	local minimap = inst.entity:AddMiniMapEntity() -------------设置小地图标志
	minimap:SetIcon("icey_tower.tex")
	

    inst.AnimState:SetBank("icey_tower")
    inst.AnimState:SetBuild("icey_tower")
    inst.AnimState:PlayAnimation("idle") ----------喜闻乐见的动画设置
	
	inst.AnimState:SetMultColour(141/255,224/255,255/255,1)
	inst.Transform:SetScale(2,2,2)-----------------在这里设置建筑的放大缩小
	
	inst.Light:SetIntensity(0.7)
	inst.Light:SetRadius(5)
	inst.Light:SetFalloff(0.5)
	inst.Light:SetColour(44/255,143/255,255/255)
	inst.Light:Enable(true)
	
	inst:AddTag("icey_tower")
	inst:AddTag("icey_power_board")
	inst:AddTag("icey_power_building")
	inst:AddTag("companion")
	
    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

	inst:AddComponent("health")
    inst.components.health:SetMaxHealth(1000)
	
	inst:AddComponent("combat")

    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("这是我的水晶塔") ------------设置可检查组件
	
	inst:AddComponent("trader")
    inst.components.trader:SetAcceptTest(ShouldAcceptItem)
    inst.components.trader.onaccept = OnGetItemFromPlayer
    inst.components.trader.onrefuse = OnRefuseItem
	
    MakeHauntableWork(inst)
  
	inst:DoPeriodicTask(5,function()
		PowerBoard(inst,15,500)
	end)
	inst:ListenForEvent("attacked", OnAttacked)
	inst:ListenForEvent("death", OnKilled)
	
    return inst
end

return Prefab("icey_tower", towerfn, assets_tower),
MakePlacer("icey_tower_placer", "icey_tower", "icey_tower", "idle",nil,nil,nil,2)