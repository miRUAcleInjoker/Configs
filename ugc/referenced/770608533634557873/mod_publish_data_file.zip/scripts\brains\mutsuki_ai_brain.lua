require "behaviours/wander"
require "behaviours/doaction"
require "behaviours/chaseandattack"
require "behaviours/standstill"


local STOP_RUN_DIST = 10
local SEE_PLAYER_DIST = 5
local MAX_WANDER_DIST = 20
local SEE_TARGET_DIST = 6

local MAX_CHASE_DIST = 7
local MAX_CHASE_TIME = 8

local MIN_FOLLOW = 0
local MAX_FOLLOW = 12
local MED_FOLLOW = 6

local KEEP_WORKING_DIST = 14
local SEE_WORK_DIST = 10

local NO_PICKUP_TAGS = { "INLIMBO", "catchable", "fire", "irreplaceable", "heavy", "outofreach","_container","backpack","chosenicey" }
local DIG_TAGS = { "stump", "grave" }

--���ɼ��Ķ���
local NoPickThing = {
	"worm",
	"flower",
	"flower_evil",
	"cave_fern",
	"flower_cave",
	"flower_cave_double",
	"flower_cave_triple",
	"moonbase",
	"atrium_gate",
	
	"sculptingtable",
}

--������Ķ���
local NoPickUpThing = {
	"abigail_flower",
	"lucy",
	"lantern",
	"birdtrap",
	"trap",
	"trap_teeth",
}

local function ItemIsInList(item, list)
    for k, v in pairs(list) do
        if v == item or k == item then
            return true
        end
    end
end

local function LeaderHasStateTag(inst,tag)
	local leader = inst.components.follower:GetLeader() 
	if leader and leader:IsValid() and leader.sg:HasStateTag(tag) then 
		return true 
	end
end 



local function PickAndPickUpAction(inst)
	local x, y, z = inst.Transform:GetWorldPosition()
    local ents = TheSim:FindEntities(x, y, z, MAX_FOLLOW,nil,NO_PICKUP_TAGS,{ "_inventoryitem", "pickable", "readyforharvest" })
	
	--Look for food on the ground, pick it up
    for i, item in ipairs(ents) do
		if not inst.ShouldPickUp then 
			break 
		end 
        if item.components.inventoryitem ~= nil and
            item.components.inventoryitem.canbepickedup and
			(not ItemIsInList(item.prefab, NoPickUpThing)) and 
            item:IsOnValidGround() then
            return BufferedAction(inst, item, ACTIONS.PICKUP)
        end
    end

    --Look for harvestable items, pick them.
    for i, item in ipairs(ents) do
        if item.components.pickable ~= nil and
            item.components.pickable.caninteractwith and
            item.components.pickable:CanBePicked() and
            (not ItemIsInList(item.prefab, NoPickThing)) then
            return BufferedAction(inst, item, ACTIONS.PICK)
        end
    end

    --Look for crops items, harvest them.
    for i, item in ipairs(ents) do
        if item.components.crop ~= nil and
            item.components.crop:IsReadyForHarvest()  then
            return BufferedAction(inst, item, ACTIONS.HARVEST)
        end
    end
end 

local function HasValidPickWork(inst)
	return PickAndPickUpAction(inst) ~= nil 
end 

local function GetItemToGive(inst)
	local leader = inst.components.follower:GetLeader()
	if leader and leader.components.inventory then
		for k,v in pairs(inst.components.inventory.itemslots) do 
			if v and v:IsValid() and leader.components.inventory:CanAcceptCount(v) > 0 then 
				return v 
			end
		end
	end
end 



local function GiveAction(inst)
	local item = GetItemToGive(inst)
	local leader = inst.components.follower:GetLeader() 
	if item then 	
		return BufferedAction(inst,leader,ACTIONS.GIVE,item)
	end 
end 

local function IsGrowableMaxTree(tree)
	return tree and tree:IsValid() and tree.components.growable
	and (tree.components.growable.stages == nil 
		or tree.components.growable.stage == nil 
		or (
			(tree.prefab == "marbleshrub" and tree.components.growable.stage >= #tree.components.growable.stages)
			or (tree.prefab ~= "marbleshrub" and tree.components.growable.stage == #tree.components.growable.stages-1)
		   ) 
		)
end 

local function ShouldChop(inst)
	if LeaderHasStateTag(inst,"prechop") then 
		inst.ShouldChop = true 
		if inst.StopChopTask then 
			inst.StopChopTask:Cancel()
			inst.StopChopTask = nil 
		end
		inst.StopChopTask = inst:DoTaskInTime(10,function()
			inst.ShouldChop = false
			inst.StopChopTask:Cancel()
			inst.StopChopTask = nil  
		end)
	end
	
	return inst.ShouldChop
end 

local function ShouldMine(inst)
	if LeaderHasStateTag(inst,"premine") then 
		inst.ShouldMine = true 
		if inst.StopMineTask then 
			inst.StopMineTask:Cancel()
			inst.StopMineTask = nil 
		end
		inst.StopMineTask = inst:DoTaskInTime(10,function()
			inst.ShouldMine = false
			inst.StopMineTask:Cancel()
			inst.StopMineTask = nil  
		end)
	end
	
	return inst.ShouldMine
end 

local function HasValidChopMineWork(inst)
	return inst.sg.statemem.target ~= nil  
end 



local function ShouldGive(inst)
	local ret = inst.components.inventory:NumItems() > 0 
		and inst.components.follower:GetLeader() 
		and inst.components.follower:GetLeader():IsValid() 
		and GetItemToGive(inst) ~= nil 
		and not inst.sg:HasStateTag("giving")
		and not inst.sg:HasStateTag("doing")
		and not inst.sg:HasStateTag("emote")
		and GetTime() - inst.LastGiveItemTime >= 15*FRAMES
		and not HasValidPickWork(inst)
		and not HasValidChopMineWork(inst)
		--and not inst.ShouldChop
		--and not inst.ShouldMine 
	--print("ShouldGive",ret)
	return ret
end 

local function ShouldPickAndPickUp(inst)
	return --inst.ShouldPickUp and 
		not inst.components.inventory:IsFull() 
		and HasValidPickWork(inst) 
		and not HasValidChopMineWork(inst)
end 

local function FindEntityToWorkAction(inst, action, addtltags)
    local leader = inst.components.follower:GetLeader() 
    if leader ~= nil then
        --Keep existing target?
        local target = inst.sg.statemem.target
        if target ~= nil and
            target:IsValid() and
            not (target:IsInLimbo() or
                target:HasTag("NOCLICK") or
                target:HasTag("event_trigger")) and
            target.components.workable ~= nil and
            target.components.workable:CanBeWorked() and
            target.components.workable:GetWorkAction() == action 
			
            and not (target.components.burnable ~= nil
                and (target.components.burnable:IsBurning() or
                    target.components.burnable:IsSmoldering())) and
            target.entity:IsVisible() and
            target:IsNear(leader, KEEP_WORKING_DIST) then
                
            if addtltags ~= nil then
                for i, v in ipairs(addtltags) do
                    if target:HasTag(v) then
                        return BufferedAction(inst, target, action)
                    end
                end
            else
                return BufferedAction(inst, target, action)
            end
        end

        --Find new target
        target = FindEntity(leader, SEE_WORK_DIST,
		function(guy)
			return (action == ACTIONS.CHOP --[[and IsGrowableMaxTree(guy)--]]) or
					(action == ACTIONS.MINE and (guy.prefab ~= "marbleshrub" or IsGrowableMaxTree(guy))) or 
					action == ACTIONS.DIG
		end , { action.id.."_workable" }, { "fire", "smolder", "event_trigger", "INLIMBO", "NOCLICK" }, addtltags)
        return target ~= nil and BufferedAction(inst, target, action) or nil
    end
end

local function ShouldStand(inst)
	return inst.components.container and inst.components.container:IsOpen()
end 

local function GetLeaderBoat(inst)
	local leader = inst.components.follower.leader
	return leader and leader:IsValid() and leader:GetCurrentPlatform()
end 

local MutsukiAiBrain = Class(Brain, function(self, inst)
    Brain._ctor(self, inst)
end)

function MutsukiAiBrain:OnStart()

    local root = PriorityNode(
    {	
		
		--Give Item 
		WhileNode(function() return ShouldGive(self.inst)end, "Should Give",
            DoAction(self.inst, GiveAction)),
			
		--pick/ harvest things.
        WhileNode(function() return ShouldPickAndPickUp(self.inst)  end, "Should Pick,Harvest",
            DoAction(self.inst, PickAndPickUpAction)),

		IfNode(function() return ShouldChop(self.inst) 
			  end, "Keep Chopping",
            DoAction(self.inst, function() return FindEntityToWorkAction(self.inst, ACTIONS.CHOP) end)),
			
			
        IfNode(function() return ShouldMine(self.inst) 
			 end, "Keep Mining",
            DoAction(self.inst, function() return FindEntityToWorkAction(self.inst, ACTIONS.MINE) end)),
			
			
		IfNode(function() return not ShouldGive(self.inst)--LeaderHasStateTag(self.inst,"predig") 
			 end, "Keep Digging",
            DoAction(self.inst, function() return FindEntityToWorkAction(self.inst, ACTIONS.DIG, DIG_TAGS) end)),
			
		IfNode(function() return GetLeaderBoat(self.inst) end, "Leader On The Boat",
            Follow(self.inst, function() return GetLeaderBoat(self.inst) end, 0, 3, 4, true)),
		IfNode(function() return not GetLeaderBoat(self.inst) end, "Leader On The Boat",
            Follow(self.inst, function() return self.inst.components.follower.leader end, MIN_FOLLOW, MED_FOLLOW, MAX_FOLLOW, true)),
		
		--Wander(self.inst,function() return self.inst.components.follower.leader and self.inst.components.follower.leader:GetPosition() end, MAX_WANDER_DIST),
    }, .1)
    
    self.bt = BT(self.inst, root)
    
end

return MutsukiAiBrain
