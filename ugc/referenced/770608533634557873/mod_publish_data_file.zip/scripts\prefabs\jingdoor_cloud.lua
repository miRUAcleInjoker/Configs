local assets=
{
	Asset("ANIM", "anim/waterfall_mist_fx.zip"),
}

local function DriverEnable(inst,driver,val)
	if val then 
		driver:AddChild(inst)
		inst.AnimState:SetFinalOffset(-1)
		inst.Transform:SetPosition(0,0.5,0)	
		driver.DriverAnim = inst.DriverAnim
	else
		driver:RemoveChild(inst)
		local pos = Vector3(driver.Transform:GetWorldPosition())
		inst.Transform:SetPosition(pos.x,0,pos.z) 
		driver.DriverAnim = nil 
	end
end 

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
	inst.entity:AddAnimState()
    inst.entity:AddNetwork()

	inst.AnimState:SetBank("waterfall_mist_fx")
	inst.AnimState:SetBuild("waterfall_mist_fx")
	inst.AnimState:PlayAnimation("anim",true)
	
	inst.Transform:SetScale(0.5,0.5,0.5)

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.owner = nil
	inst.DriverEnable = DriverEnable 
	inst.DriverAnim = ""
	
	inst:AddComponent("inspectable")
	inst.components.inspectable.descriptionfn = function(inst,viewer)
		if inst.owner then 
			if inst.owner == viewer then 
				--下去
				inst.owner = nil 
				inst:DriverEnable(viewer,false)
			else
				--啥都不做
			end
		else
			inst.owner = viewer
			inst:DriverEnable(viewer,true)
			--上来
		end
		
		return "啊♂"
	end 


    return inst
end

return Prefab("jingdoor_cloud", fn,assets)