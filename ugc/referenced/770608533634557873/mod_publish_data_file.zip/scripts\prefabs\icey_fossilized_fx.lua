local assets = {
	Asset("ANIM", "anim/lavaarena_snapper_basic.zip"),	
	Asset("ANIM", "anim/fossilized.zip"),	
} 

local function OnBreak(inst)
	inst.SoundEmitter:KillSound("shakeloop")
	inst.SoundEmitter:PlaySound("dontstarve/impacts/lava_arena/fossilized_break")
	--inst.SoundEmitter:PlaySound("dontstarve/common/lava_arena/spell/fossilized")
	--SpawnAt("fossilizing_fx",inst)
	SpawnAt("fossilized_break_fx",inst).AnimState:SetBank("snapper")
	inst:Hide()
	inst:DoTaskInTime(1,inst.Remove)
end 


local function fn()
	local inst = CreateEntity()--���������䶼��Ĭ��Ҫ���ӵģ�����Ͳ�������ô����
	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddSoundEmitter()
	inst.entity:AddNetwork()
	inst.AnimState:SetBank("snapper")-----ǰ��������ָ��icey_kill_fx��ͼƬ�߽�Ͳ��ʣ�����Ч�����ò���ֻ�Ǳ�д��
	inst.AnimState:SetBuild("fossilized")
	inst.AnimState:SetFinalOffset(3) 
	--inst.AnimState:PlayAnimation("fossilized")
	
	inst:AddTag("FX")
	
	inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.Fossilized = function(self)
		self.AnimState:PlayAnimation("fossilized",false)
		self.SoundEmitter:PlaySound("dontstarve/common/lava_arena/fossilized_pre_1")
	end 
	
	inst.Unfossilized = function(self)
		--self.AnimState:PlayAnimation("fossilized_pst",false)
		self.AnimState:PlayAnimation("fossilized_shake",false)
		self.SoundEmitter:PlaySound("dontstarve/common/lava_arena/fossilized_shake_LP", "shakeloop")
		self:ListenForEvent("animover",OnBreak)
	end 
	
	
	return inst
end

return Prefab("icey_fossilized_fx", fn, assets)