local assets=
{
	Asset("ANIM", "anim/blueprint.zip"),
    Asset("ANIM", "anim/blueprint_rare.zip"),
    Asset("INV_IMAGE", "blueprint"),
    Asset("INV_IMAGE", "blueprint_rare"),
	
	Asset( "IMAGE", "images/inventoryimages/gestalt_report.tex" ),
	Asset( "ATLAS", "images/inventoryimages/gestalt_report.xml" ),
}

local function fn()
	local inst = CreateEntity()

	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddNetwork()

	MakeInventoryPhysics(inst)

	inst.AnimState:SetBank("blueprint_rare")
    inst.AnimState:SetBuild("blueprint_rare")
    
	inst.AnimState:PlayAnimation("idle")

	inst.entity:SetPristine()
	if not TheWorld.ismastersim then
		return inst
	end

    MakeHauntableLaunch(inst)

	inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("上面记述着将人类的灵魂剥离的方法。")

	inst:AddComponent("inventoryitem")
	inst.components.inventoryitem:ChangeImageName("blueprint_rare")
	--inst.components.inventoryitem.imagename = "gestalt_report"
	--inst.components.inventoryitem.atlasname = "images/inventoryimages/gestalt_report.xml"

	return inst
end

return Prefab("common/inventory/gestalt_report", fn, assets)
