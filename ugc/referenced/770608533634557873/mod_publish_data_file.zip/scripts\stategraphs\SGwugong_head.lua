require("stategraphs/commonstates")


local actionhandlers = 
{
    --ActionHandler(ACTIONS.GOHOME, "action"),
}

local events=
{
    EventHandler("death", function(inst) inst.sg:GoToState("death") end),
    EventHandler("doattack", function(inst,data) if not inst.components.health:IsDead() and not inst.sg:HasStateTag("busy") then inst.sg:GoToState("attack",data.target) end end),
 
    EventHandler("locomote", 
        function(inst) 
            if not inst.sg:HasStateTag("busy") then
            local is_moving = inst.sg:HasStateTag("moving")
            local wants_to_move = inst.components.locomotor:WantsToMoveForward()
            if not inst.sg:HasStateTag("attack") and is_moving ~= wants_to_move then
                if wants_to_move then
                    inst.sg:GoToState("walk")
                else
                    inst.sg:GoToState("idle")
                end
            end
        end
        end),
    EventHandler("attacked", function(inst)
        if not inst.components.health:IsDead() and not inst.sg:HasStateTag("busy") and not inst.sg:HasStateTag("attack") then
            inst.sg:GoToState("hit")
        end
    end),
}

local states=
{
 
    State{
        
        name = "idle",
        tags = {"idle", "canrotate"},
        onenter = function(inst, playanim)
            inst.Physics:Stop()
			inst.AnimState:PlayAnimation("anim")
            inst.sg:SetTimeout(1*math.random()+.5)
        end,
        
        ontimeout= function(inst)
            if inst.components.locomotor:WantsToMoveForward() then
                inst.sg:GoToState("walk")
            else
                inst.SoundEmitter:PlaySound("dontstarve/frog/grunt", nil, 0.5)
                inst.sg:GoToState("idle")
            end
        end,
    },
      
    
    State{
        name = "walk",
        tags = {"moving", "canrotate"},
        
        onenter = function(inst) 
            inst.Physics:Stop() 
            inst.AnimState:PlayAnimation("anim")
			inst.components.locomotor:WalkForward()
            --inst.AnimState:PushAnimation("jump")
            --inst.AnimState:PushAnimation("jump_pst", false)
        end,
        
        events=
        {
            EventHandler("animqueueover", function (inst) inst.sg:GoToState("idle") end),
        },
    },
    
    State{
        name = "attack",
        tags = {"attack","moving"},
        
        onenter = function(inst, target)
            inst.components.locomotor:Stop()
            inst.components.locomotor:EnableGroundSpeedMultiplier(false)
            inst.components.combat:StartAttack()
			inst.AnimState:PlayAnimation("anim")
			inst.AnimState:SetMultColour(191/255,0/255,0/255,1)
			
           -- inst.AnimState:PlayAnimation("atk_pre")
            --inst.AnimState:PushAnimation("atk", false)
        end,
        
        timeline=
        {
			TimeEvent(8*FRAMES, function(inst) inst.Physics:SetMotorVelOverride(10,0,0) end),
            TimeEvent(10*FRAMES, function(inst) 
				inst.SoundEmitter:PlaySound("dontstarve/frog/attack_spit") 
			end),
            TimeEvent(11*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve/frog/attack_voice") end),
            TimeEvent(15*FRAMES, function(inst) inst.components.combat:DoAttack() end),
			TimeEvent(16*FRAMES,
                function(inst)
                    inst.Physics:ClearMotorVelOverride()
                    inst.components.locomotor:Stop()
					inst.sg:GoToState("idle")
                end),
        },
		
		
		onexit = function(inst)
            inst.components.locomotor:Stop()
            inst.components.locomotor:EnableGroundSpeedMultiplier(true)
            inst.Physics:ClearMotorVelOverride()
			inst.AnimState:SetMultColour(1,1,1,1)
        end,
    },
    
   
    State{
        name = "hit",
        tags = {"busy"},

        onenter = function(inst)
            inst.SoundEmitter:PlaySound("dontstarve/frog/grunt")
            inst.AnimState:PlayAnimation("anim")
            inst.Physics:Stop()
			inst.Physics:SetDamping(2)
        end,

        events =
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end ),
        },
    },

    State{
        name = "death",
        tags = {"busy"},

        onenter = function(inst)
            inst.SoundEmitter:PlaySound("dontstarve/frog/die")
            --inst.AnimState:PlayAnimation("anim")
			inst.AnimState:PlayAnimation("anim")
			inst.AnimState:SetMultColour(0,0,0,1)
            inst.Physics:Stop()
            RemovePhysicsColliders(inst)
            inst.components.lootdropper:DropLoot(inst:GetPosition())
        end,
    },


}

return StateGraph("SGwugong_head", states, events, "idle", actionhandlers)
