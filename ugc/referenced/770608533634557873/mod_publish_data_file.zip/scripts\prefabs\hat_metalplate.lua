local assets =
{ 
    Asset("ANIM", "anim/hat_metalplate.zip"), 

    Asset("ATLAS", "images/inventoryimages/hat_metalplate.xml"),
    Asset("IMAGE", "images/inventoryimages/hat_metalplate.tex"),
}

local function OnEquip(inst, owner) 
    owner.AnimState:OverrideSymbol("swap_hat", "hat_metalplate","swap_hat")
    owner.AnimState:Show("HAT")
    owner.AnimState:Show("HAIR_HAT")
    owner.AnimState:Hide("HAIR_NOHAT")
    owner.AnimState:Hide("HAIR")

    if owner:HasTag("player") then
        owner.AnimState:Hide("HEAD")
        owner.AnimState:Show("HEAD_HAT")
    end
end

local function OnUnequip(inst, owner) 
	owner.AnimState:ClearOverrideSymbol("swap_hat")
    owner.AnimState:Hide("HAT")
    owner.AnimState:Hide("HAIR_HAT")
    owner.AnimState:Show("HAIR_NOHAT")
    owner.AnimState:Show("HAIR")

    if owner:HasTag("player") then
        owner.AnimState:Show("HEAD")
        owner.AnimState:Hide("HEAD_HAT")
    end
end

local function fn()

    local inst = CreateEntity()
	
    inst.entity:AddTransform()
	
    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()  --�������Ҳ����� 
	
    MakeInventoryPhysics(inst)	
	inst.AnimState:SetBank("metalplatehat")
    inst.AnimState:SetBuild("hat_metalplate")
    inst.AnimState:PlayAnimation("anim")
	
	
	----------------------����Ķ��� ������������Ч
	
	inst.entity:SetPristine()   --���ľ仰 �ŵ����� Ҳ����bank build ��tag֮��ĺ���-��-
	if not TheWorld.ismastersim then
        return inst
    end
	
	----------------------�����ֻ������ִ��
	
    inst:AddComponent("inspectable")
	
	inst:AddComponent("waterproofer")
	inst.components.waterproofer:SetEffectiveness(TUNING.WATERPROOFNESS_SMALL)


    inst:AddComponent("inventoryitem")
    inst.components.inventoryitem.imagename = "hat_metalplate"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/hat_metalplate.xml"
	
    inst:AddComponent("equippable")
    inst.components.equippable.equipslot = EQUIPSLOTS.HEAD 
    inst.components.equippable:SetOnEquip(OnEquip)
    inst.components.equippable:SetOnUnequip(OnUnequip)
	--inst.components.equippable.walkspeedmult = 0.95
	inst.components.equippable.stamina_consumerate = 1.25
	inst.components.equippable.stamina_recoverrate = 0.90
	
	inst:AddComponent("armor")
	inst.components.armor:InitCondition(850,0.85)
	
	MakeHauntableLaunch(inst)  --����ź���ͺ���

    return inst
end

return  Prefab("hat_metalplate", fn, assets, prefabs)