AddComponentPostInit("eater",function(self)
	self.checkpreferstoeat = nil 
	
	self.SetCheckPrefersToEat = function(self,fn)
		self.checkpreferstoeat = fn 
	end
	
	local old_PrefersToEat = self.PrefersToEat 
	self.PrefersToEat = function(self,food,...)
		return (self.checkpreferstoeat == nil or self.checkpreferstoeat(self.inst,food)) or old_PrefersToEat(self,food,...)
	end
end)