require "behaviours/wander"
require "behaviours/chaseandattack"
require "behaviours/doaction"
require "behaviours/panic"

local MAX_WANDER_DIST = 20
local START_RUN_DIST = 3
local STOP_RUN_DIST = 5
local MAX_CHASE_TIME = 10
local MAX_CHASE_DIST = 30
local SEE_TARGET_DIST = 20
local SEE_FOOD_DIST = 10
local RUN_AWAY_DIST = 6
local STOP_RUN_AWAY_DIST = 8

local function FindFoodAction(inst)
    local target = FindEntity(inst, SEE_FOOD_DIST, function(item) return inst.components.eater:CanEat(item) end)
    if target then
        return BufferedAction(inst, target, ACTIONS.EAT)
    end
end

local function FuseAction(inst)
	if inst.prefab ~= "icey_sans" then 
		return 
	end
	print("Try FuseAction!")
	if not inst.components.fuseable:GetPartner() then
		local another = FindEntity(inst, 15, function(guy) return guy ~= inst and guy.prefab == "icey_sans" end)
		if another and another:IsValid() then 
			inst.components.fuseable:SetPartner(another)
		end
	end
	
	if inst.components.fuseable:GetPartner() then
		print("Try FuseAction success!")
		return BufferedAction(inst, inst.components.fuseable:GetPartner(), ACTIONS.FUSE, nil, nil, nil, 2)
	end 
end 

local function TargetIsAggressive(inst,target)
    return target and
           target.components.combat and
           target.components.combat.defaultdamage > 30 and
           target.components.combat.target == inst
end

local function FindBattleShip(inst)
	local ship =  FindEntity(inst, 15, function(ship) return ship:HasTag("hyperion_circle") end)
	return ship~= nil
end 

local function FindAttacker(inst)
	local attacker =  FindEntity(inst, 6, function(attacker) return TargetIsAggressive(inst,attacker) end)
	return attacker ~= nil
end 

local InfectedBrain = Class(Brain, function(self, inst)
    Brain._ctor(self, inst)
end)

function InfectedBrain:OnStart()
    --print(self.inst, "InfectedBrain:OnStart")
    local root = PriorityNode(
    {
		ChattyNode(self.inst, "Fuse",
			DoAction(self.inst, function() return FuseAction(self.inst) end, "Fuse", true)),
		WhileNode(function() return FindBattleShip(self.inst)  end, "BattleShip",
                ChattyNode(self.inst, "RunAway",
                    RunAway(self.inst, "hyperion_circle", 10, 15))),
		WhileNode(function() return FindAttacker(self.inst)  end, "AttackerComming",
                ChattyNode(self.inst, "RunAway",
                    RunAway(self.inst, "scarytoprey",6,10))),
		WhileNode(function() return not TargetIsAggressive(self.inst) and self.inst:HasTag("infected") end, "SafeToEat",
            DoAction(self.inst, function() return FindFoodAction(self.inst) end, "EatMeat", true)
        ),
        ChaseAndAttack(self.inst, 15, 25),
        Wander(self.inst, function() return  end, MAX_WANDER_DIST),
    }, .5)

    self.bt = BT(self.inst, root)
end

function InfectedBrain:OnInitializationComplete()
    --self.inst.components.knownlocations:RememberLocation("home", Point(self.inst.Transform:GetWorldPosition()), true)
end

return InfectedBrain
