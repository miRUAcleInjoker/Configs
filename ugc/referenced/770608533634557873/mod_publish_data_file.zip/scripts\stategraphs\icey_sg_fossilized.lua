local function ForceStopHeavyLifting(inst)
    if inst.components.inventory:IsHeavyLifting() then
        inst.components.inventory:DropItem(
            inst.components.inventory:Unequip(EQUIPSLOTS.BODY),
            true,
            true
        )
    end
end
--ThePlayer.sg:GoToState("icey_fossilized",3)

AddStategraphEvent("wilson",
	EventHandler("fossilized", function(inst, data)
		local time = data.time
		if time and not inst.components.health:IsDead() and not inst.sg:HasStateTag("dead") then 
			inst.sg:GoToState("icey_fossilized",time)
		end
	end)
)
AddStategraphEvent("wilson_client",
	EventHandler("fossilized", function(inst, data)
		local time = data.time
		if time and not inst.replica.health:IsDead() and not inst.sg:HasStateTag("dead") then 
			inst.sg:GoToState("icey_fossilized")
		end
	end)
)

AddStategraphState("wilson", 
	State{
        name = "icey_fossilized",
        tags = { "busy","nopredict","nodangle","fossilized", "notalking","NOICEYSKILL"},

        onenter = function(inst,cd)
			cd = cd or 10
			if inst.components.pinnable ~= nil and inst.components.pinnable:IsStuck() then
                inst.components.pinnable:Unstick()
            end
            ForceStopHeavyLifting(inst)
            inst.components.locomotor:Stop()
            inst:ClearBufferedAction()

            inst.AnimState:PlayAnimation("frozen")
            --inst.SoundEmitter:PlaySound("dontstarve/common/freezecreature")
			local fx = inst:SpawnChild("icey_fossilized_fx")
			fx:Fossilized() 
			inst.sg.statemem.fossilized_fx = fx
			
            inst.components.inventory:Hide()
            inst:PushEvent("ms_closepopups")
            if inst.components.playercontroller ~= nil then
                inst.components.playercontroller:EnableMapControls(false)
                inst.components.playercontroller:Enable(false)
            end
			
			if inst.components.combat then 
				inst.components.combat.externaldamagetakenmultipliers:SetModifier(inst,2,"icey_fossilized")
			end
			
			if inst.components.icey_keyhandler then 
				inst.components.icey_keyhandler:SetEnabled(false) 
			end
			
			inst.sg:SetTimeout(cd)
        end,
		
		ontimeout = function(inst)
			inst.sg:GoToState("hit")
		end,

        onexit = function(inst)
            inst.components.inventory:Show()
			if inst.components.playercontroller ~= nil then
                inst.components.playercontroller:EnableMapControls(true)
                inst.components.playercontroller:Enable(true)
            end
			if inst.sg.statemem.fossilized_fx and inst.sg.statemem.fossilized_fx:IsValid() then 
				inst.sg.statemem.fossilized_fx:Unfossilized()
				inst.sg.statemem.fossilized_fx = nil 
			end
			if inst.components.combat then 
				inst.components.combat.externaldamagetakenmultipliers:RemoveModifier(inst,"icey_fossilized")
			end
			
			if inst.components.icey_keyhandler then 
				inst.components.icey_keyhandler:SetEnabled(true) 
			end
        end,
    }
)

AddStategraphState("wilson_client", 
	State{
        name = "icey_fossilized",
        tags = { "busy","nopredict","nodangle","fossilized","notalking","NOICEYSKILL"},

        onenter = function(inst,cd)
			cd = cd or 10
			
			inst.components.locomotor:Stop()
            inst.components.locomotor:Clear()
			
            inst:ClearBufferedAction()

            inst.AnimState:PlayAnimation("frozen")
			inst.sg:SetTimeout(cd)
        end,
		
		ontimeout = function(inst)
			inst.sg:GoToState("hit")
		end,

        onexit = function(inst)

        end,
    }
)
