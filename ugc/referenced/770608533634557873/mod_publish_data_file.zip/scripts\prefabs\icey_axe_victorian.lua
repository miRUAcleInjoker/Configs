local IceyUtil = require("icey_util")
local IceyWeaponSkillUtil = require("icey_weaponskill_util")

local assets =
{
    Asset("ANIM", "anim/icey_axe_victorian.zip"),
    Asset("ANIM", "anim/swap_icey_axe_victorian.zip"),
    Asset("ANIM", "anim/floating_items.zip"),
}

local function onequip(inst, owner)
    owner.AnimState:OverrideSymbol("swap_object", "swap_icey_axe_victorian", "swap_axe")
    owner.AnimState:Show("ARM_carry")
    owner.AnimState:Hide("ARM_normal")
end

local function onunequip(inst, owner)
    owner.AnimState:Hide("ARM_carry")
    owner.AnimState:Show("ARM_normal")
end

local function common_fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()

    MakeInventoryPhysics(inst)

    inst.AnimState:SetBank("axe")
    inst.AnimState:SetBuild("icey_axe_victorian")
    inst.AnimState:PlayAnimation("idle")

    inst:AddTag("sharp")
	inst:AddTag("axe_victorian")

    MakeInventoryFloatable(inst, "small", 0.05, {1.2, 0.75, 1.2})
	
	IceyWeaponSkillUtil.AddAoetargetingClient(inst,"line",{"axe_victorian"},9,function(inst)
		inst.components.aoetargeting:SetAlwaysValid(false)
	end)
	
    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "axe_victorian"
	
    inst:AddComponent("tool")
    inst.components.tool:SetAction(ACTIONS.CHOP, 1)

    inst:AddComponent("finiteuses")
    inst.components.finiteuses:SetMaxUses(125)
    inst.components.finiteuses:SetUses(125)
    inst.components.finiteuses:SetOnFinished(inst.Remove)
    inst.components.finiteuses:SetConsumption(ACTIONS.CHOP, 1)

    inst:AddComponent("weapon")
    inst.components.weapon:SetDamage(28)
	
    inst:AddComponent("inspectable")
	inst.components.inspectable.nameoverride = "axe"

    inst:AddComponent("equippable")
    inst.components.equippable:SetOnEquip(onequip)
    inst.components.equippable:SetOnUnequip(onunequip)
	
	inst.components.floater:SetBankSwapOnFloat(true, -11, {sym_build = "swap_axe"})

    MakeHauntableLaunch(inst)


	IceyWeaponSkillUtil.AddAoetargetingServer(inst,function(inst,doer,pos)
		if IceyUtil.DefaultCostFn(doer,{stamina = 20,focus = 8}) then 
			inst.components.rechargeable:StartRecharge()
			doer:ForceFacePoint(pos:Get())
			doer.Physics:Stop()
			doer.Physics:SetMotorVelOverride(45,0,0)
		else
			doer.sg:GoToState("idle")
		end 
	end,nil,8)
	
    return inst
end



return Prefab("icey_axe_victorian", common_fn, assets)
