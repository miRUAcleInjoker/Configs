local IceyShield = Class(function(self, inst)
    self.inst = inst
    self._current = net_shortint(inst.GUID,"IceyShield._current")
	self._max = net_shortint(inst.GUID,"IceyShield._max")
end)

function IceyShield:SetCurrent(val)
	self._current:set(val)
end

function IceyShield:SetMax(val)
	self._max:set(val)
end

-----------------------------------------------------
function IceyShield:GetCurrent()
	return self._current:value()
end

function IceyShield:GetMax()
	return self._max:value()
end

function IceyShield:GetPercent()
	return self._current:value() / self._max:value()
end


return IceyShield