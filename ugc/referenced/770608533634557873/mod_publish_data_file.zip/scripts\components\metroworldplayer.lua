local function Task(inst)
	if inst.components.metroworldplayer then 
		inst.components.metroworldplayer:Check()
	end 
end 

local function keepTwoDecimalPlaces(decimal)-----------------------四舍五入保留两位小数的代码
    decimal = math.floor((decimal * 100)+0.5)*0.01       
    return  decimal 
end

local MetroWorldPlayer = Class(function(self, inst)
	self.inst = inst 
	
	self.current_sickness = 0
	self.danger_sickness = 75
	self.max_sickness = 100
	
	self.task = inst:DoPeriodicTask(10,Task)
	inst:ListenForEvent("equip",Task)
	inst:ListenForEvent("unequip",Task)
	self.inst:StartUpdatingComponent(self) 
end)

function MetroWorldPlayer:CanRadiation()
	local target = self.inst
	return not (
		(target.components.inventory and target.components.inventory:EquipHasTag("anti_radiation")) 
		or TheWorld:HasTag("cave")
	)
end 

function MetroWorldPlayer:StartRadiation()
	local target = self.inst
	if target.components.health and target.components.debuffable and target.components.debuffable:IsEnabled()
	and not (target.sg and target.sg:HasStateTag("noattack")) then
		target.components.debuffable:AddDebuff("metroworld_radiation_debuff", "metroworld_radiation_debuff")
	end
end

function MetroWorldPlayer:StopRadiation()
	local target = self.inst
	if target.components.debuffable:HasDebuff("metroworld_radiation_debuff") then 
		target.components.debuffable:RemoveDebuff("metroworld_radiation_debuff")
	end
end

function MetroWorldPlayer:Check()
	if self:CanRadiation() then 
		self:StartRadiation()
	else
		self:StopRadiation()
	end
end

function MetroWorldPlayer:IsInSickness()
	return self.current_sickness >= self.danger_sickness
end 

function MetroWorldPlayer:SicknessDoDelta(delta)
	local old_IsInSickness = self:IsInSickness()
	self.current_sickness = self.current_sickness + delta
	self.current_sickness = math.max(0,self.current_sickness)
	self.current_sickness = math.min(self.max_sickness,self.current_sickness)
	local new_IsInSickness = self:IsInSickness()
	
	if new_IsInSickness then 
		if not old_IsInSickness then 
			local x,y,z = self.inst.Transform:GetWorldPosition() 
			local players = TheSim:FindEntities(x,y,z,30,{"player"})
			for k,v in pairs(players) do 
				local number = v:SpawnChild("icey_damage_number")
				number:UpdateDamageNumbers(v,self.inst,"辐射病!",nil, nil,true,{ 72 / 255, 255 / 255, 0 / 255, 1 })
			end  
			--self.inst.components.talker:Say("辐射病!")
		end 
		local sick = (self.current_sickness - self.danger_sickness) / self.max_sickness
		if self.inst.components.locomotor then 
			self.inst.components.locomotor:SetExternalSpeedMultiplier(self.inst, "radiation_sickness",1 - sick)
		end
		if self.inst.components.combat then 
			self.inst.components.combat.externaldamagemultipliers:SetModifier(self.inst,1 - sick, "radiation_sickness")
			self.inst.components.combat.externaldamagetakenmultipliers:SetModifier(self.inst,1 + sick, "radiation_sickness")
		end
		if delta > 0 then 
			if self.inst.components.health then 
				self.inst.components.health:DeltaPenalty(math.min(delta*0.05,0.025))
				self.inst.components.health:DoDelta(0)
			end 
			if self.inst.components.grogginess and self.inst.components.grogginess.grog_amount <= 2 then
                self.inst.components.grogginess:AddGrogginess(math.min(delta*0.5,0.5), 4 + math.random())
			end 
		end 
	else
		if old_IsInSickness then 
			local x,y,z = self.inst.Transform:GetWorldPosition() 
			local players = TheSim:FindEntities(x,y,z,30,{"player"})
			for k,v in pairs(players) do 
				local number = v:SpawnChild("icey_damage_number")
				number:UpdateDamageNumbers(v,self.inst,"辐射病解除!",nil, nil,true,{ 72 / 255, 255 / 255, 0 / 255, 1 })
			end  
			--self.inst.components.talker:Say("辐射病解除!")
		end
		if self.inst.components.locomotor then 
			self.inst.components.locomotor:RemoveExternalSpeedMultiplier(self.inst, "radiation_sickness")
		end
		if self.inst.components.combat then 
			self.inst.components.combat.externaldamagemultipliers:RemoveModifier(self.inst,"radiation_sickness")
			self.inst.components.combat.externaldamagetakenmultipliers:RemoveModifier(self.inst,"radiation_sickness")
		end
	end
end 

function MetroWorldPlayer:OnUpdate(dt)
	if TheWorld:HasTag("cave") then 
		if self:IsInSickness() then 
			self:SicknessDoDelta(-dt/100)
		else
			self:SicknessDoDelta(-dt/10)
		end
	else
		self:SicknessDoDelta(dt/50)
	end 
end

function MetroWorldPlayer:OnSave()
	return {
		current_sickness = self.current_sickness
	}
end

function MetroWorldPlayer:OnLoad(data)
	if data then 
		self.current_sickness = data.current_sickness or 0 
	end
end

function MetroWorldPlayer:Debug()
	local str = "CanRadiation():"..tostring(self:CanRadiation())
	str = str.."\n current_sickness:"..keepTwoDecimalPlaces(self.current_sickness)
	if self.inst.components.talker then 
		self.inst.components.talker:Say(str)
	end 
	
	return str 
end
--ThePlayer.components.metroworldplayer:SicknessDoDelta(-100)
--ThePlayer.components.metroworldplayer:Debug()
--ThePlayer:SpawnChild("icey_damage_number"):UpdateDamageNumbers(ThePlayer,ThePlayer,"辐射病解除!",nil, nil,true,{ 72 / 255, 255 / 255, 0 / 255, 1 })

return MetroWorldPlayer