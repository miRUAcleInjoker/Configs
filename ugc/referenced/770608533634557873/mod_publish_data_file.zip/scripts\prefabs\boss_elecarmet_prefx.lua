local assets =
{
    --Asset("ANIM", "anim/nightmarefuel.zip"),
}

local function SpawnFires(inst)
	local pos = inst:GetPosition()
	inst:StartThread(function()
		for i = 1,5 do 
			for i = 1,5 do 
				local rad = math.random(0.3,3)
				local roa = math.random()*2*math.pi
				local offset = Vector3(rad*math.cos(roa),0,rad*math.sin(roa))
				local nx,ny,nz = (pos+offset):Get()
				local fx = SpawnPrefab("halloween_firepuff_cold_"..tostring(math.random(1,3)))
				local scale = 0.7 + math.random() * 2 
				fx.Transform:SetPosition(nx,ny,nz)
				fx.Transform:SetScale(scale,scale,scale)
			end 
			Sleep(math.random()*0.1)
		end
	end)
end 

local function Update(inst)
	local scale = inst.Transform:GetScale()
	local x,y,z = inst:GetPosition():Get()
	if y <= 5 then 
		inst.Transform:SetPosition(x,y+0.05,z)
	end 
	inst.Transform:SetScale(scale+0.05,scale+0.05,scale+0.05)
	if  scale > 5 then
		if inst.OnUpdateTask then 
			inst.OnUpdateTask:Cancel()
			inst:DoTaskInTime(1.75,function()
				inst.AnimState:PlayAnimation("blast")
			end)
			inst:DoTaskInTime(1.9,function()
				local creature = SpawnPrefab("boss_elecarmet")
				local x,y,z = inst:GetPosition():Get()
				creature.Transform:SetPosition(x,0,z)
				creature.components.spawnfader:FadeIn()
				inst.creature = creature
				local player = creature:GetNearestPlayer(true)
				if player ~= nil and creature:IsNear(player, 20) then
					creature.components.combat:SetTarget(player)
				end
			end)
			inst:DoTaskInTime(2,function()
				if inst.creature and inst.creature:IsValid() then 
					inst.creature:PickSpeechAndSay("spawn")
					inst.creature.sg:GoToState("taunt")
				end 

				inst.SoundEmitter:KillSound("charge_LP")
				inst:Remove()
			end )
		end
	end
end 

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()
	inst.entity:AddSoundEmitter()

    --MakeInventoryPhysics(inst)

    inst.AnimState:SetBank("deer_ice_charge")
    inst.AnimState:SetBuild("deer_ice_charge")
	inst.AnimState:PlayAnimation("pre")
	inst.AnimState:PushAnimation("loop",true)
	--inst.AnimState:SetFinalOffset(3)
    --inst.AnimState:SetMultColour(1, 1, 1, 0.5)
	
	inst.Transform:SetScale(0.1,0.1,0.1)

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.SoundEmitter:PlaySound("dontstarve/creatures/together/deer/fx/charge_LP","charge_LP")
	
	inst:DoTaskInTime(0,SpawnFires)
	inst.OnUpdateTask = inst:DoPeriodicTask(0,Update)
	
    return inst
end

return Prefab("boss_elecarmet_prefx", fn, assets)
