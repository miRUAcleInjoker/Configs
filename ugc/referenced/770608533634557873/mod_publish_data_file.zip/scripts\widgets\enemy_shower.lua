local Widget = require "widgets/widget" --Widget������widget��������
local Text = require "widgets/text" --Text�࣬�ı�����
local TextButton = require "widgets/textbutton"
local Image = require "widgets/image"
local ImageButton = require "widgets/imagebutton"
local UIAnim = require "widgets/uianim"

local IceyUtil = require("icey_util")

local EnemyShower = Class(Widget, function(self,owner) 
	Widget._ctor(self, "EnemyShower") 
	self.owner = owner

	self.EnemyModel = self:AddChild(UIAnim())
	self.EnemyModel.owner = owner
	self.EnemyModel:SetHAnchor(ANCHOR_MIDDLE)
    self.EnemyModel:SetVAnchor(ANCHOR_MIDDLE)
    --self.EnemyModel:SetScaleMode(SCALEMODE_FIXEDSCREEN_NONDYNAMIC)
    self.EnemyModel:SetClickable(false)
	self.EnemyModel:SetScale(0.5,0.5,0.5)
	self.EnemyModel:SetPosition(0,-150)
	--IceyUtil.MakeDragableUI(self.EnemyModel) 
	
	self.BackGround = self:AddChild(ImageButton("images/icey_bg_white.xml","icey_bg_white.tex"))
	self.BackGround:SetHAnchor(ANCHOR_MIDDLE)
    self.BackGround:SetVAnchor(ANCHOR_MIDDLE)
	self.BackGround:SetScale(8,8,8)
	--self.BackGround.image:SetTint(1,1,1,1)
	--self.BackGround:SetOnClick(function() self:Hide() end)
    self.BackGround:SetClickable(false)
	self:Hide()
	
end)
--ThePlayer.HUD.controls.EnemyShower:Change("spider_queen","spider_higher_1","walk_loop",true)
--ThePlayer.HUD.controls.EnemyShower:Change("giant_snake","python_test","head_idle_loop_down",true)
--ThePlayer.HUD.controls.EnemyShower:Change("giant_snake","python_test","atk",true)
--ThePlayer.HUD.controls.EnemyShower.EnemyModel:GetAnimState():SetPercent("atk",0.2)
--ThePlayer.HUD.controls.EnemyShower.EnemyModel:SetFacing(7)
--ThePlayer.HUD.controls.EnemyShower:Hide() 
--ThePlayer.HUD.controls.EnemyShower.EnemyModel:GetAnimState():Pause()
--ThePlayer.HUD.controls.EnemyShower.EnemyModel:GetAnimState():Resume()
--ThePlayer.HUD.controls.EnemyShower.BackGround.image:SetTint(0,0,0,1)
function EnemyShower:Change(bank,build,anim,isloop)
	self:Show()
	self.EnemyModel:GetAnimState():SetBank(bank)
    self.EnemyModel:GetAnimState():SetBuild(build)
	self.EnemyModel:GetAnimState():PlayAnimation(anim,isloop)
	self.EnemyModel:MoveToFront() 
end



return EnemyShower