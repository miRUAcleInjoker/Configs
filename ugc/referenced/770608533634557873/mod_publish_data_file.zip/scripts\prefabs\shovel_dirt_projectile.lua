local IceyUtil = require("icey_util")

local assets =
{
    Asset("ANIM", "anim/winona_catapult_projectile.zip"),
}

local function OnThrown(inst)
    if inst.components.complexprojectile.attacker ~= nil then
        inst.direction:set(inst.components.complexprojectile.attacker.Transform:GetRotation())
        if inst.animent ~= nil then
            inst.animent.Transform:SetRotation(inst.direction:value())
        end
    end
end

local function OnStoneHit(inst, attacker, target)
	local x, y, z = inst.Transform:GetWorldPosition()
	inst.Physics:Stop()
	inst.Physics:Teleport(x, 0, z)
	inst.Transform:SetRotation(inst.direction:value())
    inst.AnimState:PlayAnimation("impact")
    inst:ListenForEvent("animover", inst.Remove)

    inst.hideanim:set(true)
    if inst.animent ~= nil then
        inst.animent:Remove()
        inst.animent = nil
    end
	
	

	local hit = false
	local multi = inst.prefab == "goldenshovel" and 1.5 or 1
	for i, v in ipairs(TheSim:FindEntities(x, y, z, 4, { "_combat" })) do
		if v ~= target and IceyUtil.CanAttack(v,attacker) then
			v.components.combat:GetAttacked(attacker,GetRandomMinMax(20,40) * multi)
			hit = true
		end
	end
			
	if target and IceyUtil.CanAttack(target,attacker) then
		target.components.combat:GetAttacked(attacker,GetRandomMinMax(20,40) * multi)
		hit = true
	end

	inst.SoundEmitter:PlaySound("dontstarve/common/together/catapult/rock_hit", nil, hit and .5 or nil)
		
end
		
local function oncollide(inst,other)
	if inst.components.complexprojectile and not inst.IsCollided and not inst.AnimState:IsCurrentAnimation("impact")
	and IceyUtil.CanAttack(other,inst.components.complexprojectile.attacker) then 
		inst.IsCollided = true 
		inst.components.complexprojectile:Hit(other) 

	end
end 

local function CreateProjectileAnim()
    local inst = CreateEntity()

    inst:AddTag("FX")
    inst:AddTag("NOCLICK")
    --[[Non-networked entity]]
    inst.persists = false

    inst.entity:AddTransform()
    inst.entity:AddAnimState()

    inst.Transform:SetSixFaced()

    inst.AnimState:SetBank("winona_catapult_projectile")
    inst.AnimState:SetBuild("winona_catapult_projectile")
    inst.AnimState:PlayAnimation("air", true)

    return inst
end

local function OnDirectionDirty(inst)
    if inst.animent ~= nil then
        inst.animent.Transform:SetRotation(inst.direction:value())
    end
end

local function OnHideAnimDirty(inst)
    if inst.hideanim:value() and inst.animent ~= nil then
        inst.animent:Remove()
        inst.animent = nil
    end
end

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddPhysics()
    inst.entity:AddNetwork()

    inst.Transform:SetSixFaced()

    inst.AnimState:SetBank("winona_catapult_projectile")
    inst.AnimState:SetBuild("winona_catapult_projectile")
    inst.AnimState:PlayAnimation("empty")
	inst.AnimState:SetMultColour(164/255,97/255,6/255,1)

    MakeCharacterPhysics(inst,1,2)
	--inst.Physics:SetCapsule(2, 1)

    inst:AddTag("NOCLICK")
    inst:AddTag("notarget")

    --projectile (from complexprojectile component) added to pristine state for optimization
    inst:AddTag("projectile")

	inst.direction = net_float(inst.GUID, "shovel_dirt_projectile.direction", "directiondirty")
    inst.hideanim = net_bool(inst.GUID, "shovel_dirt_projectile.hideanim", "hideanimdirty")

    --Dedicated server does not need to spawn the local animation
    if not TheNet:IsDedicated() then
        inst.animent = CreateProjectileAnim()
        inst.animent.entity:SetParent(inst.entity)
		inst.animent.AnimState:SetMultColour(164/255,97/255,6/255,1)
        if not TheWorld.ismastersim then
            inst:ListenForEvent("directiondirty", OnDirectionDirty)
            inst:ListenForEvent("hideanimdirty", OnHideAnimDirty)
        end
    end

    inst:SetPrefabNameOverride("winona_catapult") --for death announce

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.Physics:SetCollisionCallback(oncollide)

    inst:AddComponent("complexprojectile")
    inst.components.complexprojectile:SetHorizontalSpeed(20)
	inst.components.complexprojectile:SetGravity(-60)
	inst.components.complexprojectile:SetLaunchOffset(Vector3(1,0.2, 0))
	inst.components.complexprojectile:SetOnHit(OnStoneHit)
    inst.components.complexprojectile:SetOnLaunch(OnThrown)

    inst.persists = false

    return inst
end

return Prefab("shovel_dirt_projectile", fn, assets)
