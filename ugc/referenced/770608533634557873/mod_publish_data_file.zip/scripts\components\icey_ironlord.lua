local IceyUtil = require("icey_util")

local function onis_ironlord(self,val)
	self.inst.replica.icey_ironlord:SetIsIronLord(val)
end 

local function oncurrent_energy(self,val)
	self.inst.replica.icey_ironlord:SetCurrent(val)
end

local function onmax_energy(self,val)
	self.inst.replica.icey_ironlord:SetMax(val)
end

local IceyIronLord = Class(function(self, inst)
	self.inst = inst 
	self.is_ironlord = false 
	self.current_energy = 0
	self.max_energy = 180
	self.ontransformfn = nil 
	
	inst:ListenForEvent("death",function()
		self:Revert(true) 
	end)
	inst:ListenForEvent("transform_werebeaver",function()
		self:Revert(true) 
	end)
end,
nil,
{
	is_ironlord = onis_ironlord,
	current_energy = oncurrent_energy,
	max_energy = onmax_energy,
})



function IceyIronLord:IsIronLord()
	return self.is_ironlord
end 

function IceyIronLord:SetOnTransform(fn)
	self.ontransformfn = fn 
end 

function IceyIronLord:GetPercent()
	return self.current_energy / self.max_energy 
end 

function IceyIronLord:SetCurrent(val)
	self.current_energy = val
	self.current_energy = math.max(0,self.current_energy)
	self.current_energy = math.min(self.max_energy,self.current_energy)
	
	--if self.current_energy > 0 and not self:IsIronLord() then 
	--	self:BecomeIronLord()
	if self.current_energy <= 0 and self:IsIronLord() then 
		self:Explode()
	end
end 

function IceyIronLord:SetMax(val)
	self.max_energy = val 
end 

function IceyIronLord:DoDelta(delta)
	self:SetCurrent(self.current_energy+delta)
end 

function IceyIronLord:CanBecomeIronLord()
	return not (self.inst.isbeavermode and self.inst.isbeavermode:value()) 
		and not (self.inst.components.rider and self.inst.components.rider:IsRiding())
		and not (self.inst.components.health and self.inst.components.health:IsDead())
		and not (self.inst:HasTag("playerghost"))
	 
end 

--ThePlayer.components.icey_ironlord:DoDelta(180) ThePlayer.components.icey_ironlord:BecomeIronLord() 
--ThePlayer.components.icey_ironlord:Explode() 
function IceyIronLord:BecomeIronLord(instant)
	
	if not self:CanBecomeIronLord() then 
		return 
	end
	self.is_ironlord = true
	self.inst:AddTag("iceyironlord")
	
	
	self.inst.AnimState:AddOverrideBuild("player_living_suit_morph")
	
	self.inst:SetStateGraph("SGiceyironlord")
	
	--self.inst.components.skinner:SetupNonPlayerData()
	--self.inst.components.skinner:ClearAllClothing() 
	
	self.inst.components.skinner:HideAllClothing(self.inst.AnimState)
    --inst.AnimState:SetBank("werebeaver")
    --inst.components.skinner:SetSkinMode("werebeaver_skin")
	
	self.inst.components.playercontroller:Enable(false)
	self.inst.components.inventory:DropEquipped()
	self.inst.components.inventory:Close()
	self.inst.components.health.externalfiredamagemultipliers:SetModifier(self.inst,0,"icey_ironlord")
	self.inst.components.combat.externaldamagemultipliers:SetModifier(self.inst,6.8,"icey_ironlord")
	self.inst.components.combat.externaldamagetakenmultipliers:SetModifier(self.inst,0.1,"icey_ironlord")
	self.inst.components.stamina.externalconsumeratemultipliers:SetModifier(self.inst,0,"icey_ironlord")
	
	self.inst.AnimState:Hide("beard")
	
	self.inst.player_classified.Icey_EnableMovementPrediction:set(false)
	
	if not instant then 
        self.inst.sg:GoToState("morph")
        self.inst:DoTaskInTime(2, function()
			local announce = STRINGS.ANNOUNCE_ICEY_SUITUP[string.upper(self.inst.prefab)] or STRINGS.ANNOUNCE_ICEY_SUITUP.DEFAULT
            self.inst.components.talker:Say(announce)
        end)        
    else 
        self:BecomeIronLordPost()
    end
	if self.ontransformfn then 
		self.ontransformfn(self.inst,self.is_ironlord)
	end
end

function IceyIronLord:BecomeIronLordPost()
	self.inst.AnimState:SetBuild("living_suit_build")
	self.inst.components.playercontroller:Enable(true)	
	self.inst:StartUpdatingComponent(self) 
end 

function IceyIronLord:Explode()
	self.inst.sg:GoToState("explode")
	self.inst:StopUpdatingComponent(self) 
end 

function IceyIronLord:Revert(need_explode)
	if self.is_ironlord then 
		self.is_ironlord = false 
		self.inst:RemoveTag("iceyironlord")
		
		self.inst.AnimState:SetBank("wilson")
		self.inst.AnimState:SetBuild(self.inst.prefab)
		self.inst.AnimState:ClearOverrideBuild("player_living_suit_morph")
		
		
		--self.inst.components.skinner:SetSkinMode("normal_skin")
		
		self.inst:SetStateGraph("SGwilson")
		self.inst.player_classified.Icey_EnableMovementPrediction:set(true)
		self.inst.components.locomotor:Clear()
		self.inst:ClearBufferedAction()
		self.inst.sg:GoToState("idle", "cancel")
		self.inst.components.locomotor:Stop()
		self.inst.components.inventory:Open()
		self.inst.components.health.externalfiredamagemultipliers:RemoveModifier(self.inst,"icey_ironlord")
		self.inst.components.combat.externaldamagemultipliers:RemoveModifier(self.inst,"icey_ironlord")
		self.inst.components.combat.externaldamagetakenmultipliers:RemoveModifier(self.inst,"icey_ironlord")
		self.inst.components.stamina.externalconsumeratemultipliers:RemoveModifier(self.inst,"icey_ironlord")
		
		self.inst.AnimState:Show("beard")
		
		if self.inst.SoundEmitter then 
			self.inst.SoundEmitter:KillAllSounds() 
		end
		
		if need_explode then 
			local explosion = SpawnPrefab("laser_explosion")
			explosion.Transform:SetPosition(self.inst.Transform:GetWorldPosition())  
			explosion.Transform:SetScale(0.6,0.6,0.6)
		end 
		
		if self.ontransformfn then 
			self.ontransformfn(self.inst,self.is_ironlord)
		end
		
		IceyUtil.ReloadSkin(self.inst)
		
		self.inst:StopUpdatingComponent(self) 
	end 
end

function IceyIronLord:StartCharge()
	if not self.inst.sg:HasStateTag("morph") and not self.inst.sg:HasStateTag("charge") then 
		self.inst.sg:GoToState("charge")
	end 
end

function IceyIronLord:Shoot(targetpos)
	--local bomb = self.inst.fullcharge and "icey_ironlord_orb" or "icey_ironlord_orb_small"
	--SpawnAt(bomb,self.inst:GetPosition()).components.ly_projectile:Throw(self.inst,targetpos,true,nil,true)
	if not self.inst.sg:HasStateTag("morph") and not self.inst.sg:HasStateTag("explode") and self.inst.sg:HasStateTag("charge") and self.inst.readytoshoot then 
		if not self.inst.fullcharge then 
			self.inst.SoundEmitter:PlaySoundWithParams("dontstarve_DLC003/common/crafted/iron_lord/smallshot", {timeoffset=math.random()})
			self.inst.SoundEmitter:KillSound("chargedup")
		else
			self.inst.SoundEmitter:PlaySoundWithParams("dontstarve_DLC003/creatures/boss/hulk_metal_robot/laser",  {intensity = math.random(0.7, 1)})
		end 
		self.inst.sg:GoToState("shoot",targetpos)
	end 
end

function IceyIronLord:OnUpdate(dt)
	if self:IsIronLord() then 
		self:DoDelta(-dt)
	end
end

return IceyIronLord