
--[[AddPlayerPostInit(function(player)
	print("icey_darkspirit_api.lua !!!!!") 
	local self = player.replica.combat 
	print("player.replica.combat:",self)
	if not self then 
		return player
	end 
	print("icey_darkspirit_api.lua(client) !!!!!")

	local old_IsValidTarget = self.IsValidTarget
	self.IsValidTarget = function(self,target)
		if target == nil or
			target == self.inst or
			not (target.entity:IsValid() and target.entity:IsVisible()) then
			return false
		end
		
		-------------�����ڷ�PVP����£���������Ȼ���Ա���ͨ��ҹ������߹�����ͨ���
		if (self.inst:HasTag("player") and target:HasTag("player")) 
		and (not self.inst:HasTag("playerghost") and not target:HasTag("playerghost") ) 
		and (self.inst:HasTag("darkspirit") or target:HasTag("darkspirit")) then 
			return true 
		end
		return old_IsValidTarget(self,target)
	end 
	
	--------------������û���κ����ѣ�����ÿ������˽�����Ļ���
	local old_IsAlly = self.IsAlly
	self.IsAlly = function(self,guy)
		return old_IsAlly(self,guy) and not guy:HasTag("darkspirit") and not self.inst:HasTag("darkspirit")
	end 
	
	-------------�����ڷ�PVP����£���������Ȼ���Ա���ͨ��ҹ������߹�����ͨ���
	local old_CanBeAttacked = self.CanBeAttacked
	self.CanBeAttacked = function(self,attacker)
		if  attacker 
		and (self.inst:HasTag("player") and attacker:HasTag("player")) 
		and (not self.inst:HasTag("playerghost") and not attacker:HasTag("playerghost") ) 
		and (attacker:HasTag("darkspirit") or self.inst:HasTag("darkspirit")) then 
			return true 
		end
		
		return old_CanBeAttacked(self,attacker)
	end 
end)--]]
local _G = GLOBAL
local getlocal = _G.debug.getlocal
local getupvalue = _G.debug.getupvalue
local IceyUtil = require("icey_util")

--local GROUND_LOOKUP = table.invert(GROUND)
local function CheckPVP(attacker, target, ignore_weapon)
	if attacker ~= nil and target ~= nil then
		local attacker_pos = attacker.Transform and Vector3(attacker.Transform:GetWorldPosition()) or nil
		local target_pos = target.Transform and Vector3(target.Transform:GetWorldPosition()) or nil
		if attacker_pos and target_pos  then
			return IceyUtil.CanDoDarkSpiritAttackClient(attacker,target)
		else
			print("[Icey,I see:icey_darkspirit_api.lua] ERROR: Couldn't find attacker/target position")
		end
	else
		print("[Icey,I see:icey_darkspirit_api.lua] ERROR: Attacker/target is nil")
	end
	return false
end

--------------һ�´���ı��ԡ�PVP ��Ƥ��mod���ǳ�����ĸ�л��λ����!!!!!!!!
_G.getmetatable(_G.TheNet).__index["GetPVPEnabled"] = function()
	
	-- find them local variables from calling function
	local a = 1
	local local_table = {}
	while a < 20 do
		local name, value = getlocal(2, a)
		if name == nil then break end
		local_table[name] = value
		a = a + 1
	end
	
	local attacker = nil
	local target = nil
	local ingore_weapon = false
	if a > 1 then			
		-- feedplayer, act.target, act.doer
		if local_table.act and local_table.act.doer and local_table.act.target then
			attacker = local_table.act.doer 
			target = local_table.act.target
			ingore_weapon = true
		-- edible, doer, target
		-- CanCast, doer, target	
		-- spellcaster, doer, target
		elseif local_table.doer and local_table.target then
			attacker = local_table.doer
			target = local_table.target
			if local_table.inst and (local_table.inst:HasTag("badfood") or local_table.inst:HasTag("spoiled")) then
				ingore_weapon = true
			end
		-- panflute onheard, musician, inst
		elseif local_table.musician and local_table.inst and SLEEP then
			attacker = local_table.musician
			target = local_table.inst
			ingore_weapon = true
		-- tornado destroystuff, inst, v
		elseif local_table.inst and local_table.v then
			attacker = local_table.inst
			target = local_table.v
		elseif local_table.self and local_table.self.inst then
			-- IsValidTarget, target, self.inst
			if local_table.target then
				attacker = local_table.self.inst
				target = local_table.target
			-- IsAlly, guy, guy.replica.follower, follower:GetLeader(), self.inst
			elseif local_table.guy then
				attacker = local_table.self.inst
				target = local_table.leader or local_table.guy.replica.follower and local_table.guy.replica.follower:GetLeader()
			-- CanBeAttacked, self.inst, attacker
			elseif local_table.attacker then
				attacker = local_table.attacker
				target = local_table.self.inst
			end
		end
	else
		print("[Icey,I see:icey_darkspirit_api.lua] ERROR: Debug call failed to find locals")
	end
	return CheckPVP(attacker, target, ingore_weapon)
end



