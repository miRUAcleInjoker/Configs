
local assets_crusher = {
	Asset("ANIM", "anim/zerg_crusher.zip"),--------建筑的贴图文件
}

-----------------------------------------------------------------------------------------------------------------------

local function onhammered_crusher(inst, worker)
    inst.components.lootdropper:DropLoot()
    local fx = SpawnPrefab("collapse_small")
    fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
    fx:SetMaterial("metal")
    inst:Remove()
end

local function onhit_crusher(inst, worker)
    inst.AnimState:PlayAnimation("hit")
    inst.AnimState:PushAnimation("idle", false)
end

local function dozap_crusher(inst)
    if inst.zaptask ~= nil then
        inst.zaptask:Cancel()
    end

    inst.SoundEmitter:PlaySound("dontstarve/common/lightningrod")
	local fx = SpawnPrefab("lightning_rod_fx")
    fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
	--fx.Transform:SetAddColour(161/255,26/255,13/255,1)

    inst.zaptask = inst:DoTaskInTime(math.random(7, 15), dozap_crusher)
end

local function discharge_crusher(inst)
	if inst.zaptask ~= nil then
        inst.zaptask:Cancel()
        inst.zaptask = nil
    end
end 

--------------减速---------------------

local function onRemove(inst)
    for i,slowedinst in pairs( inst.slowed_objects ) do
        i.slowing_objects[inst] = nil      
    end
end

local function updateslowdowners(inst)
    local ground = TheWorld
    local x,y,z = inst:GetPosition():Get()
    local slowdowns = TheSim:FindEntities(x,y,z, 20, {"_combat"},nil,{"monster","hostile","epic","tadalin"})
	for k,v in pairs(slowdowns) do
		if v:IsValid() and v.components.locomotor then 
			v.components.locomotor:PushTempGroundSpeedMultiplier(TUNING.DEER_ICE_SPEED_PENALTY)
		end 
	end 
end

local function turnon(inst)
	dozap_crusher(inst)
	if inst.slow_task == nil then
		inst.slow_task = inst:DoPeriodicTask(1/30,function(inst) updateslowdowners(inst) end)
	end 
	inst.Light:Enable(true)
end 

local function turnoff(inst)
	discharge_crusher(inst)
	if inst.slow_task ~= nil then
		inst.slow_task:Cancel()
		onRemove(inst)
		inst.slow_task = nil 
	end
	inst.Light:Enable(false)
end 

local function CheckPower(inst,data)
	local power = data.power
	inst.building_power = inst.building_power + power
	inst.building_power = math.max(0,inst.building_power)
	inst.building_power = math.min(inst.max_building_power,inst.building_power)
	if inst.building_power > 0 and not inst.IsOn then 
		print(inst,"Turn on!")
        turnon(inst)
		inst.IsOn = true
    elseif inst.building_power <= 0 and inst.IsOn then
		print(inst,"Turn off!")
        turnoff(inst)
		inst.IsOn = false
    end 
end 

local function onbuilt_crusher(inst)
    inst.AnimState:PlayAnimation("place")
    inst.AnimState:PushAnimation("idle")
    inst.SoundEmitter:PlaySound("dontstarve/common/lightning_rod_craft")
end

local function OnSave_crusher(inst,data)
	data.building_power = inst.building_power
	--data.IsOn = inst.IsOn
end 

local function OnLoad_crusher(inst,data)
	if data then 
		if data.building_power then 
			inst.building_power = data.building_power
		end
		--[[if data.IsOn then 
			inst.IsOn = data.IsOn
		end--]]
		CheckPower(inst,{fromer = inst,power = 0})
	end
end 

local function crusherfn()
	 local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()
	inst.entity:AddLight()

	MakeObstaclePhysics(inst, .5)
	
    inst.AnimState:SetBank("zerg_crusher")
    inst.AnimState:SetBuild("zerg_crusher")
    inst.AnimState:PlayAnimation("idle") ----------喜闻乐见的动画设置
	
	local minimap = inst.entity:AddMiniMapEntity() -------------设置小地图标志
	minimap:SetIcon("zerg_crusher.tex")
	
	inst.Transform:SetScale(1.5,1.5,1.5)
	
	inst.Light:Enable(false)
    inst.Light:SetRadius(3)
    inst.Light:SetFalloff(1)
    inst.Light:SetIntensity(.5)
    inst.Light:SetColour(161/255,26/255,13/255)
		
	inst:AddTag("icey_power_use")
	inst:AddTag("icey_power_building")
	inst:AddTag("structure")

    inst.entity:SetPristine()
	
	
    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.IsOn = false
	inst.building_power = 0
	inst.max_building_power = 500
	inst.slowed_objects = {}

    inst:AddComponent("inspectable")
	inst.components.inspectable.descriptionfn = function(inst,doer)
		return (inst.IsOn and "阻挡可怕的敌人" ) or "它需要充电了!"
	end
	
	
	inst:AddComponent("lootdropper")
	
	inst:AddComponent("workable")
    inst.components.workable:SetWorkAction(ACTIONS.HAMMER)
    inst.components.workable:SetWorkLeft(3)
	inst.components.workable:SetOnFinishCallback(onhammered_crusher)
    inst.components.workable:SetOnWorkCallback(onhit_crusher)
	
    MakeHauntableWork(inst)--------------被作祟时的函数，这里是空的
    MakeSnowCovered(inst)--------------建筑物积雪时的函数，这里是空的
	
	inst.OnLoad = OnLoad_crusher
	inst.OnSave = OnSave_crusher
	inst.OnRemoveEntity = onRemove
	
	inst:DoPeriodicTask(1,function()
		inst:PushEvent("powertrans",{former = inst,power = -10})
	end)
	inst:ListenForEvent("powertrans",CheckPower)
	inst:ListenForEvent("onbuilt", onbuilt_crusher)
    return inst
end

return Prefab("zerg_crusher", crusherfn, assets_crusher),
MakePlacer("zerg_crusher_placer", "zerg_crusher", "zerg_crusher", "idle")