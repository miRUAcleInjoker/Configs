local TadalinUtil = require("tadalin_util")
local easing = require("easing")


--------���������������¯mod�������д
--------���������Ǳ�ʾ��ߵľ���
local assets =
{
    --Asset("ANIM", "anim/lavaarena_trails_basic.zip"),
	Asset("ANIM", "anim/lavaarena_beetletaur.zip"),
	Asset("ANIM", "anim/lavaarena_beetletaur_fx.zip"),
	Asset("ANIM", "anim/lavaarena_beetletaur_break.zip"),
	Asset("ANIM", "anim/lavaarena_beetletaur_basic.zip"),
	Asset("ANIM", "anim/lavaarena_beetletaur_block.zip"),
	Asset("ANIM", "anim/lavaarena_beetletaur_actions.zip"),
	
	Asset("SOUNDPACKAGE", "sound/icey_dracula.fev"),
    Asset("SOUND", "sound/icey_dracula.fsb"),
}

local prefabs =
{

}

------------------------------
--ToDo List--
------------------------------
--Adjust speed and hit/attack range of Boarilla to ensure you need speedboosts to dodge incoming punchs.
--Make small adjustments to CalcJumpSpeed in the SG to better mimic the slam ingame.
-----------------------------

local brain = require("brains/icey_draculabrain")

SetSharedLootTable( 'icey_dracula',
{
    --{'monstermeat', 1.000},
})

local REPEL_RADIUS = 5
local REPEL_RADIUS_SQ = REPEL_RADIUS * REPEL_RADIUS

local WAKE_TO_FOLLOW_DISTANCE = 8
local SLEEP_NEAR_HOME_DISTANCE = 10
local SHARE_TARGET_DIST = 30
local HOME_TELEPORT_DIST = 30

local NO_TAGS = { "FX", "NOCLICK", "DECOR", "INLIMBO" }


local function ClearRecentlyCharged(inst, other)
    inst.recentlycharged[other] = nil
end

local function OnDestroyOther(inst, other)
    if other:IsValid() and
        other.components.workable ~= nil and
        other.components.workable:CanBeWorked() and
        other.components.workable.action ~= ACTIONS.DIG and
        other.components.workable.action ~= ACTIONS.NET and
        not inst.recentlycharged[other] then
        SpawnPrefab("collapse_small").Transform:SetPosition(other.Transform:GetWorldPosition())
        other.components.workable:Destroy(inst)
        if other:IsValid() and other.components.workable ~= nil and other.components.workable:CanBeWorked() then
            inst.recentlycharged[other] = true
            inst:DoTaskInTime(3, ClearRecentlyCharged, other)
        end
    end
end

local function OnCollide(inst, other)
    if other ~= nil and
        other:IsValid() and
        other.components.workable ~= nil and
        other.components.workable:CanBeWorked() and
        other.components.workable.action ~= ACTIONS.DIG and
        other.components.workable.action ~= ACTIONS.NET and
        not inst.recentlycharged[other] then
        inst:DoTaskInTime(2 * FRAMES, OnDestroyOther, other)
    end
end

local function OnHitOther(inst, other) --knockback
	if inst.sg:HasStateTag("slamming") then
		if other.sg and other.sg.sg.events.knockback then
			other:PushEvent("knockback", {knocker = inst, radius = 5})
		else
		--this stuff below is mostly left here for creatures in basegame. For modders that are reading this, use the knockback event above.
		if other ~= nil and not (other:HasTag("epic") or other:HasTag("largecreature")) then
		
			if other:IsValid() and other.entity:IsVisible() and not (other.components.health ~= nil and other.components.health:IsDead()) then
				if other.components.combat ~= nil then
					--other.components.combat:GetAttacked(inst, 10)
					if other.Physics ~= nil then
						local x, y, z = inst.Transform:GetWorldPosition()
						local distsq = other:GetDistanceSqToPoint(x, 0, z)
						--if distsq < REPEL_RADIUS_SQ then
							if distsq > 0 then
								other:ForceFacePoint(x, 0, z)
							end
							local k = .5 * distsq / REPEL_RADIUS_SQ - 1
							other.speed = 60 * k
							other.dspeed = 2
							other.Physics:ClearMotorVelOverride()
							other.Physics:Stop()
						
							if other.components.inventory and other.components.inventory:ArmorHasTag("heavyarmor") or other:HasTag("heavybody") then 
							--Leo: Need to change this to check for bodyslot for these tags.
							other:DoTaskInTime(0.1, function(inst) 
								other.Physics:SetMotorVelOverride(-2, 0, 0) 
							end)
							else
								other:DoTaskInTime(0, function(inst) 
									other.Physics:SetMotorVelOverride(-2, 0, 0) 
								end)
							end
								other:DoTaskInTime(0.4, function(inst) 
								other.Physics:ClearMotorVelOverride()
								other.Physics:Stop()
							end)
						end
					end
				end
			end
		end
	end
end
-------------------------------------------------
--------------------------------------------------------------------------

local function OnCameraFocusDirty(inst)
    if inst._camerafocus:value() then
        if inst:HasTag("NOCLICK") then
            --death
            TheFocalPoint.components.focalpoint:StartFocusSource(inst, nil, nil, 6, 22, 3)
        else
            --pose
            TheFocalPoint.components.focalpoint:StartFocusSource(inst, nil, nil, 60, 60, 3)
            TheCamera:SetDistance(30)
            TheCamera:SetControllable(false)
        end
    else
        TheFocalPoint.components.focalpoint:StopFocusSource(inst)
        TheCamera:SetControllable(true)
    end
end

local function EnableCameraFocus(inst, enable)
    if enable ~= inst._camerafocus:value() then
        inst._camerafocus:set(enable)
        if not TheNet:IsDedicated() then
            OnCameraFocusDirty(inst)
        end
    end
end

--------------------------------------------------------------------------

local function CreateFlower()
    local inst = CreateEntity()

    inst:AddTag("FX")
    inst:AddTag("NOCLICK")
    --[[Non-networked entity]]
    inst.entity:SetCanSleep(false)
    inst.persists = false

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()

    MakeInventoryPhysics(inst)

    inst.AnimState:SetBank("healing_flower")
    inst.AnimState:SetBuild("healing_flower")
    inst.AnimState:PlayAnimation("idle")
    inst.AnimState:Hide("shadow")

    return inst
end

local function OnFlowerHitGround(flower)
    flower.AnimState:Show("shadow")
    flower.SoundEmitter:PlaySound("dontstarve/movement/bodyfall_dirt", nil, .35)
end

local function CheckPose(flower, inst)
    if not (inst:IsValid() and inst.AnimState:IsCurrentAnimation("end_pose_loop")) then
        ErodeAway(flower, 1)
    end
end

local function OnSpawnFlower(inst)
    local flower = CreateFlower()
    local x, y, z = inst.Transform:GetWorldPosition()
    local vec = TheCamera:GetRightVec()
    flower.Physics:Teleport(x, 7, z)
    flower.Physics:SetVel(vec.x * 5, 20, vec.z * 5)
    flower:DoTaskInTime(1.23, OnFlowerHitGround)
    flower:DoPeriodicTask(.5, CheckPose, nil, inst)
end

--------------------------------------------------------------------------

-------------------------------------------------

local function FindPlayerTarget(inst)
	local player, distsq = inst:GetNearestPlayer()
	if player then
		if not inst.components.follower.leader then --Don't attempt to find a target that isn't the leader's target. 
			return not (player:HasTag("notarget") or player:HasTag("LA_mob")) and (player and not player.components.health:IsDead()) and player
		end
	end
end

local function AttemptNewTarget(inst, target)
	local player, distsq = inst:GetNearestPlayer()
    if target ~= nil and inst:IsNear(target, 20) and player then
		return target
	else
		return not (player:HasTag("notarget") or player:HasTag("LA_mob")) and (player and not player.components.health:IsDead()) and player and player
	end
end

local function OnDroppedTarget(inst)
	local playertargets = {}
	local pos = inst:GetPosition()
	local ents = TheSim:FindEntities(pos.x,0,pos.z, 50, nil, {"playerghost", "ghost", "battlestandard", "LA_mob" , "INLIMBO" }, {"player"} ) or {}
	for i, v in ipairs(ents) do
		if v and v.components.health and not v.components.health:IsDead() and not (inst.lasttarget and inst.lasttarget == v) then
			table.insert(playertargets, v)		
		end	
	end
	if not inst:HasTag("brainwashed") then
		--I assume first one in the table is the closest
		if #playertargets > 0 then
			inst.components.combat:SetTarget(playertargets[1])
		--Leo: This elseif check is just to make the mob not stop and continue on, making it look like the forge.
		elseif inst.lasttarget and inst.lasttarget.components and inst.lasttarget.components.health and not inst.lasttarget.components.health:IsDead() then
			inst.components.combat:SetTarget(inst.lasttarget)
		end
	end
end

local function OnNewTarget(inst, data)
	--inst.last_attack_landed = GetTime() + 8
	if data and data.target then
		inst.lasttarget = inst.components.combat.target
		
	end
end

local function RetargetFn(inst)
    local player, distsq = inst:GetNearestPlayer()
	if inst:HasTag("brainwashed") then
		return FindEntity(inst, 50, function(guy) return inst.components.combat:CanTarget(guy) and not guy.components.health:IsDead() end, nil, { "wall", "player", "companion", "brainwashed" })
	else
		return FindEntity(inst, 50, function(guy) return inst.components.combat:CanTarget(guy) and not guy.components.health:IsDead() and not (inst.lastarget and inst.lasttarget == guy) end, nil, { "wall", "LA_mob", "battlestandard" })
	end	
end

local function KeepTarget(inst, target)
	if inst:HasTag("brainwashed") then
		return inst.components.combat:CanTarget(target) and (target.components.health and not target.components.health:IsDead()) and not target:HasTag("player") and not target:HasTag("companion")
	else
		return inst.components.combat:CanTarget(target) and (target.components.health and not target.components.health:IsDead()) and not target:HasTag("LAmob") --inst:IsNear(target, 5)
	end
end

local function OnAttacked(inst, data)
	--[[if data and data.attacker and not data.attacker:HasTag("notarget") and not (inst.aggrotimer and inst.components.combat.lastwasattackedtime <= inst.aggrotimer) then	
		if inst:HasTag("brainwashed") and not (data.attacker:HasTag("player") or data.attacker:HasTag("companion")) then
			inst.components.combat:SetTarget(data.attacker)
		elseif data.attacker:HasTag("brainwashed") and not inst:HasTag("brainwashed") then
			inst.components.combat:SetTarget(data.attacker)
		else
			local player, distsq = inst:GetNearestPlayer()	
			if player and player.components.health and not player.components.health:IsDead() and player == data.attacker then
				if inst.components.combat.target and not (data.attacker:HasTag("lessaggro") or inst:IsNear(inst.components.combat.target, 2.5)) then
					inst.components.combat:SetTarget(data.attacker)
				elseif not inst.components.combat.target then
					inst.components.combat:SetTarget(data.attacker)
				end		
			end
		end	
	end--]]
	--[[if inst.components.health:GetPercent() < 0.5 then 
		inst.damage_solved = inst.damage_solved + data.damage
		
		if inst.damage_solved > 150 then 
			if inst.sg:HasStateTag("") then 
				
			end
			inst:PushEvent("entershield")
			inst.damage_solved = 0
		end 
	end--]]
end
-----------

local function OnAttackOther(inst, data)
    --inst.components.combat:ShareTarget(data.attacker, SHARE_TARGET_DIST, function(dude) return dude:HasTag("LA_mob") and dude.components.combat and not dude.components.combat.target and not dude.components.health:IsDead() end, 30)
end

local function EnterPhase1Trigger(inst)
    --don't remove this yet.
	inst:CancelAllFade() 
	--inst:EnableEyeFlame(true) 
	inst.sg:GoToState("idle")
	inst.SoundEmitter:PlaySound("icey_dracula/dracula/enter_phase2")
end

local function ShieldCheck(inst)
	if not inst.isguarding and inst.components.health:GetPercent() < 0.5 and (inst.components.combat.laststartattacktime + 8) < GetTime() then
		inst:PushEvent("entershield")
	end
end

----------------------------------------------------------------------------------------------------

local function UpdatePing(inst, s0, s1, t0, duration, multcolour, addcolour)
    if next(multcolour) == nil then
        multcolour[1], multcolour[2], multcolour[3], multcolour[4] = inst.AnimState:GetMultColour()
    end
    if next(addcolour) == nil then
        addcolour[1], addcolour[2], addcolour[3], addcolour[4] = inst.AnimState:GetAddColour()
    end
    local t = GetTime() - t0
    local k = 1 - math.max(0, t - 0.1) / duration
    k = 1 - k * k
    local s = Lerp(s0, s1, k)
    local c = Lerp(1, 0, k)
    inst.Transform:SetScale(s, s, s)
    inst.AnimState:SetMultColour(c * multcolour[1], c * multcolour[2], c * multcolour[3], c * multcolour[4])

    k = math.min(0.3, t) / 0.3
    c = math.max(0, 1 - k * k)
    inst.AnimState:SetAddColour(c * addcolour[1], c * addcolour[2], c * addcolour[3], c * addcolour[4])
end

local function UpdatePingIn(inst, s0, s1, t0, duration, multcolour, addcolour,endfn)
	
    if next(multcolour) == nil then
        multcolour[1], multcolour[2], multcolour[3], multcolour[4] = inst.AnimState:GetMultColour()
    end
    if next(addcolour) == nil then
        addcolour[1], addcolour[2], addcolour[3], addcolour[4] = inst.AnimState:GetAddColour()
    end
    local t = GetTime() - t0
    local k = 1 - math.max(0, t - 0.1) / duration
    k = 1 - k * k
    local s = Lerp(s1, s0, k)
    local c = Lerp(0, 1, k)
    inst.Transform:SetScale(s, s, s)
    inst.AnimState:SetMultColour(c * multcolour[1], c * multcolour[2], c * multcolour[3], c * multcolour[4])

    k = math.min(0.3, t) / 0.3
    c = math.max(1 - k * k,0)
    inst.AnimState:SetAddColour(c * addcolour[1], c * addcolour[2], c * addcolour[3], c * addcolour[4])
	
	inst:Show()
end

local function FadeOut(inst,duration,startscale,adds)
	if inst.fadetask then 
		inst.fadetask:Cancel()
		inst.fadetask = nil 
	end
	duration = duration or 2 
	startscale = startscale or 1
	adds = adds or 0.1 
	
	inst.fadetask = inst:DoPeriodicTask(0, UpdatePing, nil, startscale, startscale + adds, GetTime(),duration, {}, {})
	inst:DoTaskInTime(duration,inst.Hide) 
end 

local function FadeIn(inst,duration,startscale,adds)
	if inst.fadetask then 
		inst.fadetask:Cancel()
		inst.fadetask = nil 
	end
	inst.Transform:SetScale(1, 1, 1)
	inst.AnimState:SetMultColour(1,1,1,1)
	inst.AnimState:SetAddColour(0,0,0,0)
	duration = duration or 0.75 
	startscale = startscale or 1
	adds = adds or 0
	--inst.components.spawnfader:FadeIn() 
	inst:DoTaskInTime(duration,function()
		if inst.fadetask then 
			inst.fadetask:Cancel()
			inst.fadetask = nil 
		end
		inst.Transform:SetScale(1, 1, 1)
		inst.AnimState:SetMultColour(1,1,1,1)
		inst.AnimState:SetAddColour(0,0,0,0)
	end)
	inst.fadetask = inst:DoPeriodicTask(0, UpdatePingIn, nil, startscale,startscale+adds, GetTime(),duration, {}, {})
end 

local function CancelAllFade(inst)
	if inst.fadetask then 
		inst.fadetask:Cancel()
		inst.fadetask = nil 
	end
	inst.Transform:SetScale(1, 1, 1)
	inst.AnimState:SetMultColour(1,1,1,1)
	inst.AnimState:SetAddColour(0,0,0,0)
end 

local function SpawnTeleportFx(inst,offset,scale,delay)
	offset = offset or Vector3(0,-1,0)
	scale = scale or 4
	delay = delay or 2.5
	local fx = SpawnAt("positronbeam_front",inst:GetPosition()+offset)
	fx.Transform:SetScale(scale,scale,scale)
	fx:DoTaskInTime(delay,fx.KillFX)
	
	return fx
end 

local function PlayBattleCrySound(inst)
	local sounds = {
		"en",
		"ha",
		"hen",
	}
	inst.SoundEmitter:PlaySound("icey_dracula/dracula/"..sounds[math.random(1,#sounds)])
end 
--c_findnext("icey_dracula"):EnableSummonBats(true)
local function EnableSummonBats(inst,enable)
	local startroa = math.random()*2*PI
	local radius = 12
	if inst.SummonBatsTask then 
		inst.SummonBatsTask:Cancel()
		inst.SummonBatsTask = nil 
	end 
	
	if enable then 
		inst.SummonBatsTask = inst:DoPeriodicTask(0.33,function()
			startroa = startroa + PI / 25
			for i = startroa,startroa + PI * 5 / 3,PI / 3 do 
				local offset = Vector3(radius*math.cos(i),0,radius*math.sin(i))
				local bat = SpawnAt("bat",inst:GetPosition())
				TadalinUtil.MakeNormalTadalin(bat) 
				TadalinUtil.ClearAllLoots(bat) 
				MakeInventoryPhysics(bat)
				RemovePhysicsColliders(bat)
				if not bat.components.ly_projectile then
					bat:AddComponent("ly_projectile")
				end
				bat.components.ly_projectile.damage = 15 + math.random()*10
				bat.components.ly_projectile:SetRange(15)
				bat.components.ly_projectile:SetSpeed(12)
				bat.components.ly_projectile:SetOnThrownFn(function()
					bat:StopBrain()
					bat.SoundEmitter:PlaySound("dontstarve/creatures/bat/bite")
				end)
				bat.components.ly_projectile:SetOnHitFn(function()
					bat.components.health:Kill()
					if bat.ProjectileTask then 
						bat.ProjectileTask:Cancel()
						bat.ProjectileTask = nil 
					end
					local fx = SpawnPrefab("impact")
					fx.Transform:SetPosition(bat:GetPosition():Get())
					fx:FacePoint(inst.Transform:GetWorldPosition())
				end)
				bat.components.ly_projectile:SetOnMissFn(function()
					bat.components.health:Kill()
					if bat.ProjectileTask then 
						bat.ProjectileTask:Cancel()
						bat.ProjectileTask = nil 
					end
				end)
				bat.components.ly_projectile:SetCanHit(function(project,owner,target)
					return TadalinUtil.CanAttack(target) 
				end)
				bat:DoTaskInTime(0,function()
					bat.components.ly_projectile:Throw(inst,inst:GetPosition()+offset,true)
					bat.ProjectileTask = bat:DoPeriodicTask(0,function()
						bat.Physics:SetMotorVel(12,0,0)
					end)
				end)
				
			end
		end) 
	end 
end 

local function NumHoundsToSpawn(inst)
    local numHounds = 4

    local pt = Vector3(inst.Transform:GetWorldPosition())
    local ents = TheSim:FindEntities(pt.x, pt.y, pt.z, TUNING.WARG_NEARBY_PLAYERS_DIST, {"player"}, {"playerghost"})
    for i,player in ipairs(ents) do
        local playerAge = player.components.age:GetAgeInDays()
        local addHounds = math.clamp(Lerp(1, 4, playerAge/100), 1, 4)
        numHounds = numHounds + addHounds
    end
    local numFollowers = inst.components.leader:CountFollowers()
    local num = math.min(numFollowers+numHounds/2, numHounds) -- only spawn half the hounds per howl
    num = (math.log(num)/0.4)+1 -- 0.4 is approx log(1.5)

    num = RoundToNearest(num, 1)

    return num - numFollowers
end

local function SpawnHound(inst)
    local hounded = TheWorld.components.hounded
    if hounded ~= nil then
        local num = inst:NumHoundsToSpawn()
		inst:StartThread(function()
			for i = 1, num do
				local pt = inst:GetPosition()
				local offset = FindWalkableOffset(pt,math.random()*2*PI,7+5*math.random(),12)
				local hound = SpawnAt("hound",pt+offset)
				SpawnAt("statue_transition",pt+offset)
				SpawnAt("statue_transition_2",pt+offset)
				--local hound = hounded:SummonSpawn(pt)
				hound.components.follower:SetLeader(inst)
				--hound.sg:GoToState("mutated_spawn")
				TadalinUtil.MakeNormalTadalin(hound)
				TadalinUtil.ClearAllLoots(hound) 
				Sleep(0.2)
			end
		end)
    end
end

local function OnStunned(inst)
	if inst.components.health:GetPercent() < 0.5 then 
		inst:PushEvent("entershield")
	end
end 

local function OnStunFinished(inst)
	if inst.components.health:GetPercent() < 0.5 then 
		inst:PushEvent("exitshield")
	end 
end 


local function UpdateRepel(inst, x, z, creatures,rad)
    for i = #creatures, 1, -1 do
        local v = creatures[i]
        if not (v.inst:IsValid() and v.inst.entity:IsVisible()) then
            table.remove(creatures, i)
        elseif v.speed == nil then
            local distsq = v.inst:GetDistanceSqToPoint(x, 0, z)
            if distsq < rad * rad then
                if distsq > 0 then
                    v.inst:ForceFacePoint(x, 0, z)
                end
                local k = .5 * distsq / (rad * rad) - 1
                v.speed = 25 * k
                v.dspeed = 2
				if v.inst.Physics then 
					v.inst.Physics:SetMotorVelOverride(v.speed, 0, 0)
				end 
            end
        else
            v.speed = v.speed + v.dspeed
            if v.speed < 0 then
                local x1, y1, z1 = v.inst.Transform:GetWorldPosition()
                if x1 ~= x or z1 ~= z then
                    v.inst:ForceFacePoint(x, 0, z)
                end
                v.dspeed = v.dspeed + .25
				if v.inst.Physics then 
					v.inst.Physics:SetMotorVelOverride(v.speed, 0, 0)
				end 
            else
				if v.inst.Physics then 
					v.inst.Physics:ClearMotorVelOverride()
					v.inst.Physics:Stop()
				end 
                table.remove(creatures, i)
            end
        end
    end
end

local function TimeoutRepel(inst, creatures, task)
    task:Cancel()

    for i, v in ipairs(creatures) do
        if v.speed ~= nil and v.inst.Physics ~= nil then
            v.inst.Physics:ClearMotorVelOverride()
            v.inst.Physics:Stop()
        end
    end
end

local function KnockBack(inst,attacker,rad)
	if attacker:IsNear(inst,rad) then 
		local x,y,z = attacker:GetPosition():Get()
		if attacker.components.combat then 
			attacker.components.combat:GetAttacked(inst,math.random(1,10))
		end 
		if attacker:HasTag("player") then 
			attacker:PushEvent("repelled", { repeller = inst, radius = rad })
		else 
			local creatures = {}
			if attacker.Physics then 
				table.insert(creatures,{inst = attacker})
			end 
			if #creatures > 0 then
				inst:DoTaskInTime(10 * FRAMES, TimeoutRepel, creatures,
					inst:DoPeriodicTask(0, UpdateRepel, nil, x, z, creatures,rad)
				)
			end
		end 
	end 
end 

local function DoKnockBack(inst,rad)
	local x,y,z = inst:GetPosition():Get()
	rad = rad or 5
	for k,v in pairs(TheSim:FindEntities(x,y,z,rad,{"_combat"})) do 
		if TadalinUtil.CanAttack(v) then 
			KnockBack(inst,v,rad)
		end 
	end 
	ShakeAllCameras(CAMERASHAKE.FULL, .35, .02, 1, inst, 40)
end 

local function EnableEyeFlame(inst,enable)
	if inst.EyeFlame and inst.EyeFlame:IsValid() then 
		inst.EyeFlame:Remove()
	end
	inst.EyeFlame = nil 
	
	if enable then 
		local eye = SpawnPrefab("metal_hulk_eyeflame")
		eye.entity:SetParent(inst.entity)
		eye.entity:AddFollower()
		eye.Follower:FollowSymbol(inst.GUID, "head", 0,-15, 0)
		
		inst.EyeFlame = eye 
	end
end 
----------------------------------------------------------------------------------------------------

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddDynamicShadow()
    inst.entity:AddNetwork()

    inst.DynamicShadow:SetSize(4.5, 2.25)
    inst.Transform:SetFourFaced()
    inst.Transform:SetScale(1.05, 1.05, 1.05)

    inst:SetPhysicsRadiusOverride(1.75)
    MakeCharacterPhysics(inst, 500, inst.physicsradiusoverride)

    inst.AnimState:SetBank("beetletaur")
    inst.AnimState:SetBuild("lavaarena_beetletaur")
    inst.AnimState:PlayAnimation("idle_loop", true)

    inst.AnimState:AddOverrideBuild("fossilized")

    inst:AddTag("LA_mob")
    inst:AddTag("monster")
    inst:AddTag("hostile")
    inst:AddTag("largecreature")
    inst:AddTag("epic")
	inst:AddTag("judas")
	
	
	TadalinUtil.AddEpicBGM(inst,"judas")

    --fossilizable (from fossilizable component) added to pristine state for optimization
    --inst:AddTag("fossilizable")

    inst._bufftype = net_tinybyte(inst.GUID, "beetletaur._bufftype", "bufftypedirty")
    inst._camerafocus = net_bool(inst.GUID, "beetletaur._camerafocus", "camerafocusdirty")

    inst._spawnflower = net_event(inst.GUID, "beetletaur._spawnflower")
    inst:ListenForEvent("beetletaur._spawnflower", OnSpawnFlower)


    --inst:AddComponent("spawnfader")
	
	--inst.nameoverride = "beetletaur" --So we don't have to make the describe strings.
	
	if TheWorld.components.lavaarenamobtracker ~= nil then
        TheWorld.components.lavaarenamobtracker:StartTracking(inst)
    end

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
		inst:ListenForEvent("camerafocusdirty", OnCameraFocusDirty)
        return inst
    end
	
	--inst.damage_solved = 0
	inst.last_summon_time = 0
	inst.PoseFocus = EnableCameraFocus
	inst.FadeOut = FadeOut
	inst.FadeIn = FadeIn
	inst.CancelAllFade = CancelAllFade 
	inst.SpawnTeleportFx = SpawnTeleportFx 
	inst.PlayBattleCrySound = PlayBattleCrySound 
	inst.EnableSummonBats = EnableSummonBats
	inst.NumHoundsToSpawn = NumHoundsToSpawn
	inst.SpawnHound = SpawnHound
	inst.DoKnockBack = DoKnockBack 
	inst.EnableEyeFlame = EnableEyeFlame 
	--inst:AddComponent("fossilizable")

    inst:AddComponent("locomotor") -- locomotor must be constructed before the stategraph
	inst.components.locomotor.walkspeed = 4
    inst.components.locomotor.runspeed = 10
    inst:SetStateGraph("SGicey_dracula")
	
	inst.sg.mem.radius = inst.physicsradiusoverride

    inst:SetBrain(brain)

    inst:AddComponent("follower")
	inst:AddComponent("leader")
	
	inst:AddComponent("bloomer")
	inst:AddComponent("colouradder")
	
	--inst:AddComponent("colourfader")

    inst:AddComponent("health")
    inst.components.health:SetMaxHealth(2222)
	inst.components.health.destroytime = 7
	--[[if TheWorld.components.lavaarenaevent:GetCurrentRound() == #TheWorld.components.lavaarenaevent.rounds_data then
		inst.EnableCameraFocus = EnableCameraFocus
		inst.components.health.nofadeout = true
	else
		inst.components.health.destroytime = 7
	end--]]
	
    --inst:AddComponent("sanityaura")
    --inst.components.sanityaura.aura = -TUNING.SANITYAURA_MED
	
	inst.altattack = true
	inst.is_enraged = false
	inst.currentcombo = 0
	inst.maxpunches = 1
	inst.shieldtime_end = true

	inst:ListenForEvent("healthdelta", function(inst)
		local health = inst.components.health:GetPercent()
		if health > 0.9 then
			inst.maxpunches = 1
		elseif health >  0.7 and health <= 0.9 then
			inst.maxpunches = 2
		elseif health > 0.5 and health <= 0.7 then
			inst.maxpunches = 5
		elseif health > 0.25 and health <= 0.5 then
			inst.maxpunches = 7
		elseif health <= 0.25 then
			inst.maxpunches = 8
		end	
	
	end)
	
	inst.recentlycharged = {}
    inst.Physics:SetCollisionCallback(OnCollide)
	
	--inst:DoTaskInTime(TUNING.FORGE.SWINECLOPS.SHEILD_CD, function(inst) inst.canshield = true end)
	--inst:DoTaskInTime(0, GetVariation)
	
	
	
	inst:AddComponent("healthtrigger")
	inst.components.healthtrigger:AddTrigger(0.5, EnterPhase1Trigger) 

    inst:AddComponent("combat")
	inst.components.combat.playerdamagepercent = 0.5
	inst.components.combat:SetRange(3,3)
	--inst.components.combat:SetAreaDamage(5, 1)
    inst.components.combat:SetDefaultDamage(150)
    inst.components.combat:SetAttackPeriod(2)
    inst.components.combat:SetRetargetFunction(1, RetargetFn)
    inst.components.combat:SetKeepTargetFunction(KeepTarget)
	inst.components.combat.battlecryenabled = false
	local old_GetAttacked = inst.components.combat.GetAttacked
	inst.components.combat.GetAttacked = function(self,attacker,damage,...)
		if inst.components.health then 
			if inst.components.health:GetPercent() >= 0.75 then --0.75--1
			
			elseif inst.components.health:GetPercent() >= 0.5 then --0.5--0.75
				damage = math.min(damage,30)
			elseif inst.components.health:GetPercent() >= 0.25 then --0.25--0.5
				damage = math.min(damage,25)
			else --0--0.25
				damage = math.min(damage,12)
			end
			
			if inst.components.health:GetPercent() < 0.75 then 
				if damage <= 5 then 
					damage = 0
				else
					inst:DoKnockBack() 
				end 
				local fx = inst:SpawnChild("icey_shield")
				fx.Transform:SetScale(2,2,2)
				fx.AnimState:SetMultColour(0,0,0,0.8)
				fx.AnimState:SetFinalOffset(2) 
			end 
			
			
		end
		
		return old_GetAttacked(self,attacker,damage,...)
	end 
	--inst.components.combat:SetDamageType(DAMAGETYPES.PHYSICAL)
	
	--inst:DoTaskInTime(5, function(inst) inst:PushEvent("entershield") end)
	
	--inst:AddComponent("armorbreak_debuff")
	--inst.components.armorbreak_debuff:SetFollowSymbol("head")
	
	inst:AddComponent("stunnable")
	inst.components.stunnable.stun_threshold = 100
    inst.components.stunnable.stun_period = 12
    inst.components.stunnable.stun_duration = 8
    inst.components.stunnable.stun_resist = 0
    inst.components.stunnable.stun_cooldown = 15
	
	 --[[DRAGONFLY_STUN = 1250,
        DRAGONFLY_STUN_PERIOD = 5,
        DRAGONFLY_STUN_DURATION = 10,
        DRAGONFLY_STUN_COOLDOWN = 60,
        DRAGONFLY_STUN_RESIST = 250,--]]
	
    inst:AddComponent("lootdropper")
    inst.components.lootdropper:SetChanceLootTable('icey_dracula')

    inst:AddComponent("inspectable")

    inst:AddComponent("sleeper")
	
	inst:AddComponent("debuffable")
	inst:AddComponent("knownlocations")
	
	inst.components.combat.onhitotherfn = OnHitOther
	
    MakeHauntablePanic(inst)
	
	--MakeMediumBurnableCharacter(inst, "body")
	
	
	
	
	--inst:DoPeriodicTask(1, ShieldCheck)
	
    inst:ListenForEvent("attacked", OnAttacked)
	inst:ListenForEvent("newcombattarget", OnNewTarget)
	inst:ListenForEvent("droppedtarget", OnDroppedTarget)
	inst:ListenForEvent("stunned", OnStunned)
	inst:ListenForEvent("stun_finished", OnStunFinished)
    --inst:ListenForEvent("onattackother", OnAttackOther)
	inst:DoTaskInTime(0.5, function(inst)
		local target = FindPlayerTarget(inst) or nil
		inst.components.combat:SetTarget(target)
		
	end)
	
	TadalinUtil.MakeNormalTadalin(inst) 

    return inst
end

local function OnTick(inst, target)
	inst.AnimState:PlayAnimation(inst.type == "defense" and "defend_fx" or "attack_fx3")
end

local function OnAttached(inst, target)
    inst.entity:SetParent(target.entity)
	--inst.tickcount = 0
    inst.task = inst:DoPeriodicTask(5, OnTick, nil, target)
	
	inst.AnimState:PlayAnimation(inst.type == "defense" and "defend_fx_pre" or "attack_fx3_pre")
	
	if target.components.combat then
		if inst.type and inst.type == "defense" then
			--target.components.combat:AddDamageBuff("icey_dracula_defensebuff", 0.5, true)
			target.components.combat.externaldamagetakenmultipliers:SetModifier(inst,0.5,"icey_dracula_defensebuff")
		else
			--target.components.combat:AddDamageBuff("icey_dracula_attackbuff", 1.5, false)
			target.components.combat.externaldamagemultipliers:SetModifier(inst,1.5,"icey_dracula_defensebuff")
		end
	end
	
    inst:ListenForEvent("death", function()
        --inst.components.debuff:Stop()
    end, target)
end

local function OnDetached(inst, target)
	if target.components.combat then
		if inst.type and inst.type == "defense" then
			target.components.combat.externaldamagetakenmultipliers:RemoveModifier(inst,"icey_dracula_defensebuff")
		else
			target.components.combat.externaldamagemultipliers:RemoveModifier(inst,"icey_dracula_defensebuff")
		end
	end
	
	inst:Remove()
end

local function OnTimerDone(inst, data)
    if data.name == "icey_draculabuffover" then
        inst.components.debuff:Stop()
    end
end

local function OnExtended(inst, target)

	inst.AnimState:PlayAnimation(inst.type == "defense" and "defend_fx_pre" or "attack_fx3_pre")
	
	if inst.task then
		inst.task:Cancel()	
		inst.task = nil
	end	
	inst.task = inst:DoPeriodicTask(5, OnTick, nil, target)
end

local function fx_fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()

    inst.AnimState:SetBank("beetletaur_break")
    inst.AnimState:SetBuild("lavaarena_beetletaur_break")
    inst.AnimState:PlayAnimation("anim", false)

    inst:AddTag("DECOR") --"FX" will catch mouseover
    inst:AddTag("NOCLICK")
	
	inst:ListenForEvent("animover", inst.Remove)

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.persists = false 

    return inst
end

--too lazy to make a proper function for these right now. Will fix before proper release.

local function dot_fn()
	local inst = CreateEntity()
	
	inst.entity:AddNetwork()
	inst.entity:AddSoundEmitter()
	inst.entity:AddTransform()
    inst.entity:AddAnimState()

	inst:AddTag("CLASSIFIED")
	inst:AddTag("DECOR") --"FX" will catch mouseover
    inst:AddTag("NOCLICK")
	
	

    inst.AnimState:SetBank("lavaarena_beetletaur_fx")
    inst.AnimState:SetBuild("lavaarena_beetletaur_fx")
    inst.AnimState:SetOrientation(ANIM_ORIENTATION.OnGround)
    inst.AnimState:SetLayer(LAYER_BACKGROUND)
    inst.AnimState:SetSortOrder(3)
	
	inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.type = "defense"
	
    inst:AddComponent("debuff")
    inst.components.debuff:SetAttachedFn(OnAttached)
    inst.components.debuff:SetDetachedFn(OnDetached)
    inst.components.debuff:SetExtendedFn(OnExtended)
	
	--inst.nameoverride = "rhinobuff" --So we don't have to make the describe strings.
	
	return inst
	
end

local function dot2_fn()
	local inst = CreateEntity()
	
	inst.entity:AddNetwork()
	inst.entity:AddSoundEmitter()
	inst.entity:AddTransform()
    inst.entity:AddAnimState()

	inst:AddTag("CLASSIFIED")
	inst:AddTag("DECOR") --"FX" will catch mouseover
    inst:AddTag("NOCLICK")
	
	

    inst.AnimState:SetBank("lavaarena_beetletaur_fx")
    inst.AnimState:SetBuild("lavaarena_beetletaur_fx")
    inst.AnimState:SetOrientation(ANIM_ORIENTATION.OnGround)
    inst.AnimState:SetLayer(LAYER_BACKGROUND)
    inst.AnimState:SetSortOrder(3)
	
	inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.type = "attack"
	
    inst:AddComponent("debuff")
    inst.components.debuff:SetAttachedFn(OnAttached)
    inst.components.debuff:SetDetachedFn(OnDetached)
    inst.components.debuff:SetExtendedFn(OnExtended)
	
	--inst.nameoverride = "rhinobuff" --So we don't have to make the describe strings.
	
	return inst
	
end

--[[local function teleportfxfn()
	
end--]]


return Prefab("icey_dracula", fn, assets, prefabs),
Prefab("icey_dracula_defensebuff", dot_fn),
Prefab("icey_dracula_attackbuff", dot2_fn),
Prefab("icey_dracula_break_fx", fx_fn)