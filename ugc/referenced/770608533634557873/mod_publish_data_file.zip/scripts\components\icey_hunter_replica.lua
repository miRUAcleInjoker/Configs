local IceyHunter = Class(function(self, inst)
	self.inst = inst 
	self._current = net_ushortint(inst.GUID, "icey_hunter._current", "icey_hunter_current_dirty")
end)


function IceyHunter:SetCurrent(current)
	self._current:set(current)
end

function IceyHunter:GetCurrent()
	return self._current:value()
end

return IceyHunter