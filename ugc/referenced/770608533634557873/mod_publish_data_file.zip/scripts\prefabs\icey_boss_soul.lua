

local function MakeSoul(bossname,colour,scale)
	local prefabname = bossname.."_soul"
	scale = scale or 0.8 
	local assets = {
		Asset("ANIM", "anim/wortox_soul_ball.zip"),
		Asset("ANIM", "anim/icey_boss_soul.zip"),
		Asset("IMAGE","images/inventoryimages/"..prefabname..".tex"),
		Asset("ATLAS","images/inventoryimages/"..prefabname..".xml"),
		Asset("SCRIPT", "scripts/prefabs/wortox_soul_common.lua"),
	}
	local function fn()
		local inst = CreateEntity()

		inst.entity:AddTransform()
		inst.entity:AddAnimState()
		inst.entity:AddSoundEmitter()
		inst.entity:AddNetwork()

		MakeInventoryPhysics(inst)
		RemovePhysicsColliders(inst)

		inst.AnimState:SetBank("icey_boss_soul")
		inst.AnimState:SetBuild("icey_boss_soul")
		inst.AnimState:PlayAnimation("idle_pre")
		inst.AnimState:PushAnimation("idle_loop", true)
		inst.AnimState:SetScale(scale,scale)
		inst.AnimState:SetMultColour(colour[1],colour[2],colour[3],colour[4])
		
		inst:AddTag("icey_boss_soul")

		inst.entity:SetPristine()

		if not TheWorld.ismastersim then
			return inst
		end

		inst:AddComponent("inventoryitem")
		inst.components.inventoryitem.imagename = prefabname
		inst.components.inventoryitem.atlasname = "images/inventoryimages/"..prefabname..".xml"

		inst:AddComponent("inspectable")
		inst.components.inspectable.nameoverride = "wortox_soul"
		
		inst:AddComponent("soul")

		return inst
	end 
	
	local bossname = STRINGS.NAMES[string.upper(bossname)] or "强大"
	STRINGS.NAMES[string.upper(prefabname)] = bossname.."的灵魂" 
	return Prefab(prefabname,fn,assets)
end

----------------------------------------------------------------------------------------

local SCALE = .8
local SPEED = 10

local function CreateTail()
    local inst = CreateEntity()

    inst:AddTag("FX")
    inst:AddTag("NOCLICK")
    --[[Non-networked entity]]
    inst.entity:SetCanSleep(false)
    inst.persists = false

    inst.entity:AddTransform()
    inst.entity:AddAnimState()

    MakeInventoryPhysics(inst)
    inst.Physics:ClearCollisionMask()

    inst.AnimState:SetBank("wortox_soul_ball")
    inst.AnimState:SetBuild("icey_boss_soul")
    inst.AnimState:PlayAnimation("disappear",false)
    inst.AnimState:SetScale(SCALE, SCALE)
    inst.AnimState:SetFinalOffset(-1)

    inst:ListenForEvent("animover", inst.Remove)
	inst:DoTaskInTime(0.533,inst.Remove)

    return inst
end

local function OnUpdateProjectileTail(inst)--, dt)
    local x, y, z = inst.Transform:GetWorldPosition()
    for tail, _ in pairs(inst._tails) do
        tail:ForceFacePoint(x, y, z)
    end
    if inst.entity:IsVisible() then
        local tail = CreateTail()
        local rot = inst.Transform:GetRotation()
        tail.Transform:SetRotation(rot)
		tail.AnimState:SetMultColour(inst.AnimState:GetMultColour())
        rot = rot * DEGREES
        local offsangle = math.random() * 2 * PI
        local offsradius = (math.random() * .2 + .2) * SCALE
        local hoffset = math.cos(offsangle) * offsradius
        local voffset = math.sin(offsangle) * offsradius
        tail.Transform:SetPosition(x + math.sin(rot) * hoffset, y + voffset, z + math.cos(rot) * hoffset)
        tail.Physics:SetMotorVel(SPEED * (.2 + math.random() * .3), 0, 0)
        inst._tails[tail] = true
        inst:ListenForEvent("onremove", function(tail) inst._tails[tail] = nil end, tail)
        tail:ListenForEvent("onremove", function(inst)
            tail.Transform:SetRotation(tail.Transform:GetRotation() + math.random() * 30 - 15)
        end, inst)
    end
end

local function OnHit(inst, attacker, target)
    if target ~= nil then
        local fx = SpawnPrefab("soul_projectile_soulin")
        fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
		fx.AnimState:SetMultColour(inst.AnimState:GetMultColour())
        fx:Setup(target)
    end
    inst:Remove()
end

local function OnHasTailDirty(inst)
    if inst._hastail:value() and inst._tails == nil then
        inst._tails = {}
        if inst.components.updatelooper == nil then
            inst:AddComponent("updatelooper")
        end
        inst.components.updatelooper:AddOnUpdateFn(OnUpdateProjectileTail)
    end
end

local function OnThrown(inst)
    inst.AnimState:Hide("blob")
	inst.AnimState:Hide("tail")
    inst._hastail:set(true)
    if not TheNet:IsDedicated() then
        OnHasTailDirty(inst)
    end
end



local TINT = { r = 154 / 255, g = 23 / 255, b = 19 / 255 }

local function PushColour(inst, addval, multval)
    if inst.components.highlight == nil then
        inst.AnimState:SetHighlightColour(TINT.r * addval, TINT.g * addval, TINT.b * addval, 0)
        inst.AnimState:OverrideMultColour(multval, multval, multval, 1)
    else
        inst.AnimState:OverrideMultColour()
    end
end

local function PopColour(inst)
    if inst.components.highlight == nil then
        inst.AnimState:SetHighlightColour()
    end
    inst.AnimState:OverrideMultColour()
end

local function OnUpdateTargetTint(inst)--, dt)
    if inst._tinttarget:IsValid() then
        local curframe = inst.AnimState:GetCurrentAnimationTime() / FRAMES
        if curframe < 15 then
            local k = curframe / 15
            k = k * k
            PushColour(inst._tinttarget, 1 - k, k)
        else
            inst.components.updatelooper:RemoveOnUpdateFn(OnUpdateTargetTint)
            inst.OnRemoveEntity = nil
            PopColour(inst._tinttarget)
        end
    else
        inst.components.updatelooper:RemoveOnUpdateFn(OnUpdateTargetTint)
        inst.OnRemoveEntity = nil
    end
end

local function OnRemoveEntity(inst)
    if inst._tinttarget:IsValid() then
        PopColour(inst._tinttarget)
    end
end

local function OnTargetDirty(inst)
    if inst._target:value() ~= nil and inst._tinttarget == nil then
        if inst.components.updatelooper == nil then
            inst:AddComponent("updatelooper")
        end
        inst.components.updatelooper:AddOnUpdateFn(OnUpdateTargetTint)
        inst._tinttarget = inst._target:value()
        inst.OnRemoveEntity = OnRemoveEntity
    end
end

local function Setup(inst, target)
    inst.SoundEmitter:PlaySound("dontstarve/characters/wortox/soul/spawn", nil, .5)
    inst._target:set(target)
    if not TheNet:IsDedicated() then
        OnTargetDirty(inst)
    end
end

local function projectilefn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()

    MakeInventoryPhysics(inst)
    RemovePhysicsColliders(inst)

    inst.AnimState:SetBank("icey_boss_soul")
    inst.AnimState:SetBuild("icey_boss_soul")
    inst.AnimState:PlayAnimation("idle_pre")
	inst.AnimState:PushAnimation("idle_loop", true)
    inst.AnimState:SetScale(SCALE, SCALE)
    inst.AnimState:SetFinalOffset(-1)

    --projectile (from projectile component) added to pristine state for optimization
    inst:AddTag("projectile")
	--inst:AddTag("soul_projectile")

    inst._target = net_entity(inst.GUID, "wortox_soul._target", "targetdirty")
    inst._hastail = net_bool(inst.GUID, "wortox_soul._hastail", "hastaildirty")

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        inst:ListenForEvent("targetdirty", OnTargetDirty)
        inst:ListenForEvent("hastaildirty", OnHasTailDirty)

        return inst
    end

    

    inst:AddComponent("weapon")
    inst.components.weapon:SetDamage(0)

    inst:AddComponent("projectile")
    inst.components.projectile:SetSpeed(SPEED)
    inst.components.projectile:SetHitDist(.5)
    inst.components.projectile:SetOnThrownFn(OnThrown)
    inst.components.projectile:SetOnHitFn(OnHit)
    inst.components.projectile:SetOnMissFn(inst.Remove)

    inst.persists = false
    inst.Setup = Setup

    return inst
end

---------------------------------------------------------------------------
local function PushColour(inst, addval, multval)
	local r,g,b,a = inst.AnimState:GetMultColour()
	local TINT = {r=r,g=g,b=b,a=a}
    if inst.components.highlight == nil then
        inst.AnimState:SetHighlightColour(TINT.r * addval, TINT.g * addval, TINT.b * addval, 0)
        inst.AnimState:OverrideMultColour(multval, multval, multval, 1)
    else
        inst.AnimState:OverrideMultColour()
    end
end

local function PopColour(inst)
    if inst.components.highlight == nil then
        inst.AnimState:SetHighlightColour()
    end
    inst.AnimState:OverrideMultColour()
end

local function OnUpdateTargetTint(inst)--, dt)
    if inst._tinttarget:IsValid() then
        local curframe = inst.AnimState:GetCurrentAnimationTime() / FRAMES
        if curframe < 10 then
            local k = curframe / 10
            k = k * k
            PushColour(inst._tinttarget, (1 - k) * .7, k * .7 + .3)
        else
            inst.components.updatelooper:RemoveOnUpdateFn(OnUpdateTargetTint)
            inst.OnRemoveEntity = nil
            PopColour(inst._tinttarget)
        end
    else
        inst.components.updatelooper:RemoveOnUpdateFn(OnUpdateTargetTint)
        inst.OnRemoveEntity = nil
    end
end

local function OnRemoveEntity(inst)
    if inst._tinttarget:IsValid() then
        PopColour(inst._tinttarget)
    end
end

local function OnTargetDirty(inst)
    if inst._target:value() ~= nil and inst._tinttarget == nil then
        if inst.components.updatelooper == nil then
            inst:AddComponent("updatelooper")
        end
        inst.components.updatelooper:AddOnUpdateFn(OnUpdateTargetTint)
        inst._tinttarget = inst._target:value()
        inst.OnRemoveEntity = OnRemoveEntity
    end
end

local function Setup(inst, target)
    inst._target:set(target)
    if not TheNet:IsDedicated() then
        OnTargetDirty(inst)
    end
    if target.SoundEmitter ~= nil then
        target.SoundEmitter:PlaySound("dontstarve/characters/wortox/soul/spawn", nil, .5)
    end
end

local function soulinfn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()

    inst.AnimState:SetBank("wortox_soul_ball")
    inst.AnimState:SetBuild("icey_boss_soul")
    inst.AnimState:PlayAnimation("idle_pst")
    inst.AnimState:SetTime(6 * FRAMES)
    inst.AnimState:SetScale(0.8, 0.8)
    inst.AnimState:SetFinalOffset(-1)

    inst:AddTag("FX")

    inst._target = net_entity(inst.GUID, "icey_boss_soul._target", "targetdirty")
	
	--inst.TINT = {} 

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        inst:ListenForEvent("targetdirty", OnTargetDirty)

        return inst
    end

    inst:ListenForEvent("animover", inst.Remove)
    inst.persists = false
    inst.Setup = Setup

    return inst
end

return MakeSoul("spider_higher",{182/255,0/255,0/255,1}),
MakeSoul("pugalisk",{94/255,0/255,182/255,1}),
MakeSoul("sky_walker",{255/255,0/255,0/255,1}),
MakeSoul("icey_sans",{0/255,0/255,159/255,1}),
MakeSoul("shadow_mixtrues",{0/255,0/255,0/255,1}),
MakeSoul("moon_giaour",{228/255,166/255,0/255,1}),

MakeSoul("icey_boarrior",{93/255,0/255,0/255,1}),
MakeSoul("tigershark_duke",{0/255,187/255,241/255,1}),
MakeSoul("dark_antqueen",{0/255,0/255,0/255,1}),
MakeSoul("ancient_herald",{0/255,0/255,0/255,1}),
MakeSoul("metal_hulk_merge",{204/255,130/255,0/255,1}),

MakeSoul("boss_elecarmet",{35/255,255/255,245/255,1}),
MakeSoul("jade",{25/255,176/255,0/255,1}),
MakeSoul("death_dragon",{10/255,0/255,120/255,1}),

Prefab("soul_projectile",projectilefn),
Prefab("soul_projectile_soulin",soulinfn)
--c_spawn("soul_projectile").components.projectile:Throw(ThePlayer,ThePlayer)
--c_spawn("soul_projectile").AnimState:SetMultColour(182/255,0/255,0/255,1)
--c_findnext("soul_projectile").AnimState:SetMultColour(182/255,0/255,0/255,1)
--c_findnext("soul_projectile").components.projectile:Throw(ThePlayer,ThePlayer)