local assets = {
	Asset("ANIM", "anim/find_alert.zip"),
}

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
	inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()    
	inst.entity:AddNetwork()

    inst:AddTag("FX")
	inst:AddTag("NOCLICK")
	
	inst.AnimState:SetBank("find_alert")
    inst.AnimState:SetBuild("find_alert")
    inst.AnimState:PlayAnimation("anim")
	
	inst.AnimState:SetBloomEffectHandle("shaders/anim.ksh")
	inst.AnimState:SetLightOverride(1)

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst.persists = false
	
	inst:DoTaskInTime(0,function()
		inst.SoundEmitter:PlaySound("icey_sfx/metal_gear/alert")
	end)
	inst:DoTaskInTime(1,inst.Hide)
	inst:DoTaskInTime(2,inst.Remove)

    return inst
end

return Prefab("metal_gear_alert", fn,assets)