local IceyUtil = require("icey_util")
local IceyWeaponSkillUtil = require("icey_weaponskill_util")

local DAMAGE_HAS_BULLET = 68
local RANGE_HAS_BULLET = 12

local DAMAGE_NO_BULLET = 15
local RANGE_NO_BULLET = 0

--c_findnext("handgun_albert").components.finiteuses:SetPercent(1)
local function OnProjectileLaunch(inst,attacker, target)
	--inst.components.finiteuses:Use(1)
end 

local function CheckBullet(inst)
	local use = inst.components.finiteuses:GetUses()
	if use <= 0 then 
		
		inst:AddTag("gun_without_bullet")
		inst.components.weapon:SetDamage(DAMAGE_NO_BULLET)	
		inst.components.weapon:SetRange(RANGE_NO_BULLET)
		inst.components.weapon:SetProjectile(nil)
	else
		inst:RemoveTag("gun_without_bullet")
		inst.components.weapon:SetDamage(DAMAGE_HAS_BULLET)	
		inst.components.weapon:SetRange(RANGE_HAS_BULLET)
		inst.components.weapon:SetProjectile("icey_darts_projectile")
	end
end 

local function clientfn(inst)
	IceyWeaponSkillUtil.AddAoetargetingClient(inst,"line",{"handgun_albert"},12)
end

local function serverfn(inst)
	inst.components.weapon.attackwear = 0
	inst.components.weapon:SetOnProjectileLaunch(OnProjectileLaunch)
	
	inst.components.finiteuses:SetOnFinished(nil)
	
	IceyWeaponSkillUtil.AddAoetargetingServer(inst,function(inst,doer,pos)
		if inst.components.finiteuses:GetUses() > 0 and IceyUtil.DefaultCostFn(doer,{focus = 5}) then 
			inst.components.rechargeable:StartRecharge()
			--inst.components.finiteuses:Use(3)
			
			local projectile = SpawnAt("icey_moltendarts_projectile_explosive",doer:GetPosition())
			projectile.components.ly_projectile.damage = 128
			projectile.components.ly_projectile:SetCanHit(function(proj,owner,target)
				return IceyUtil.CanAttack(target,owner)
			end)
			projectile:ListenForEvent("lyprojectilehit",function(proj,data)
				local target = data.target
				if target and target:IsValid() then 
					if not target.components.darksouldebuffable then 
						target:AddComponent("darksouldebuffable") 
					end 
			
					target.components.darksouldebuffable:AddDebuff("handgun_albert_noregenbuff", "handgun_albert_noregenbuff") 
				end 
			end)
			projectile.components.ly_projectile:Throw(doer, pos,true)
		end 
	end,nil,1)
	
	CheckBullet(inst)
	inst:ListenForEvent("percentusedchange",CheckBullet)
end

local DATA = {
	prefabname = "handgun_albert",
	--assets = assets,
	tags = {"iceygun","hand_gun"},
	bank = "handgun_albert",
	build = "handgun_albert",
	anim = "idle",
	--swapanims = {"swap_handgun_albert","swap_handgun_albert"},
	damage = 68,
	ranges = 12,
	maxuse = 12,
	clientfn = clientfn,
	serverfn = serverfn,
}


return IceyUtil.CreateNormalWeapon(DATA)