-----------���´���������������¯mod������
-----------�ڴ˱�ʾ��ߵľ��⣡

local DEFAULT_COLOUR = { 255 / 255, 80 / 255, 40 / 255, 1 }
local DAMAGE_TYPE_COLOURS = {
	physical = { 210 / 255, 105 / 255, 30 / 255, 1 },
	magical = { 255 / 255, 0 / 255, 255 / 255, 1 },
}
local STIMULI_COLOURS = {
	electric = { 255 / 255, 255 / 255, 0 / 255, 1 },
	explosive = { 255 / 255, 69 / 255, 0 / 255, 1 },
}

local function PushDamageNumber(player, target, damage, damage_type, stimuli, large, colour)
	local font_size = 32
	damage = tostring(damage)
    if player and player.HUD and player.playercolour ~= colour then
		player.HUD:ShowPopupNumber(damage, large and font_size*1.5 or font_size, target:GetPosition(), 40,  colour, large)
	end
end

--ThePlayer.HUD:ShowPopupNumber(50, 45, ThePlayer:GetPosition(), 40,  { 255 / 255, 0 / 255, 255 / 255, 1 }, true)

local function OnDamageDirty(inst)
    if inst.target:value() ~= nil then
        local player = inst.entity:GetParent()
        if player ~= nil and player.HUD ~= nil then
			local colour = {inst.colour_r:value(),inst.colour_g:value(),inst.colour_b:value(),inst.colour_a:value()}
            PushDamageNumber(player, inst.target:value(), inst.damage:value(), inst.damage_type:value(), inst.stimuli:value(), inst.large:value(),colour)
        end
    end
end

local function master_postinit(inst)
	inst.UpdateDamageNumbers = function(self, player, target, damage, damage_type, stimuli, large,colour)
		damage = tostring(damage)
		if player == ThePlayer then
			self.PushDamageNumber(player, target, damage, damage_type, stimuli, large,colour)
		else
			self.target:set_local(target)
			self.damage:set_local(damage)
			self.damage_type:set_local(damage_type or "none")
			self.stimuli:set_local(stimuli or "none")
			self.large:set_local(large)
			self.colour_r:set_local(colour[1])
			self.colour_g:set_local(colour[2])
			self.colour_b:set_local(colour[3])
			self.colour_a:set_local(colour[4])
		end
	end
	
	inst:DoTaskInTime(0.1, inst.Remove)
end

local function fn()
    local inst = CreateEntity()

    inst.entity:AddNetwork()

    inst.target = net_entity(inst.GUID, "damage_number.target")
    --inst.damage = net_shortint(inst.GUID, "damage_number.damage")
	inst.damage = net_string(inst.GUID, "damage_number.damage")
	inst.damage_type = net_string(inst.GUID, "damage_number.damage_type")
	inst.stimuli = net_string(inst.GUID, "damage_number.stimuli")
    inst.large = net_bool(inst.GUID, "damage_number.large", "damagedirty")
	inst.colour_r = net_float(inst.GUID, "damage_number.colour_r")
	inst.colour_g = net_float(inst.GUID, "damage_number.colour_g")
	inst.colour_b = net_float(inst.GUID, "damage_number.colour_b")
	inst.colour_a = net_float(inst.GUID, "damage_number.colour_a")
	--inst.colour = net_table(inst.GUID, "damage_number.colour", "damagedirty")

    inst:AddTag("CLASSIFIED")

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        inst:ListenForEvent("damagedirty", OnDamageDirty)
        return inst
    end

    inst.PushDamageNumber = PushDamageNumber
	master_postinit(inst)

    return inst
end

return Prefab("icey_damage_number", fn)