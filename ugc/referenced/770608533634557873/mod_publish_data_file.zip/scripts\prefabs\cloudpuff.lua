local assets =
{
	Asset( "ANIM", "anim/cloud_puff_soft.zip" )
}

local function fn(Sim)
	local inst = CreateEntity()
	local trans = inst.entity:AddTransform()
    inst.entity:AddAnimState()
	inst.entity:AddNetwork()
	

    inst.AnimState:SetBuild( "cloud_puff_soft" )
    inst.AnimState:SetBank( "splash_clouds_drop" )
    inst.AnimState:PlayAnimation( "idle_sink" )

	inst:AddTag( "FX" )
	inst:AddTag( "NOCLICK" )
	
	inst.entity:SetPristine()	
	
    if not TheWorld.ismastersim then
        return inst
    end	  
	
	inst.persists = false
	
	inst:ListenForEvent( "animover",inst.Remove)


    return inst
end

return Prefab( "cloudpuff", fn, assets )
