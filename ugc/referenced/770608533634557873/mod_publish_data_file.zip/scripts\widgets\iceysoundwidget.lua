local Widget = require "widgets/widget" 
local Text = require "widgets/text" --Text类，文本处理
local TextButton = require "widgets/textbutton"
local Image = require "widgets/image"
local ImageButton = require "widgets/imagebutton"

local cv_list = {
	NULL = {count = 1,chinese = "莫有CV",english = "None"},
	nana = {count = 2,chinese = "天琦奈奈",english = "Nana"},
	ryoko = {count = 3,chinese = "天琦凉子",english = "Ryoko"},
	yuki = {count = 4,chinese = "东云幽纪",english = "Yuki"},
}



local function GetCvName(owner)
	local now_cv = owner.icey_soundname
	return cv_list[now_cv][TUNING.ICEY_LANGUAGE]
end 

local function GetCvPos(owner)
	for k,v in pairs(cv_list) do 
		if owner.icey_soundname == k then 
			return v.count
		end
	end
end 

local function SetCvByPos(owner,pos)
	local newname = "NULL"
	for k,v in pairs(cv_list) do 
		if v.count == pos then 
			newname = k
		end
	end
	owner.icey_soundname = newname
	owner._icey_soundname:set(newname)
	print("SetCvByPos:",newname,pos)
end 
AddModRPCHandler("icey_rpc","icey_cv_set",SetCvByPos)

local function ChangeCv(self)
	print("oldcv:",GetCvName(self.owner),GetCvPos(self.owner))
	local pos = GetCvPos(self.owner) + 1 
	if pos > 4 then 
		pos = 1
	end
	if TheWorld.ismastersim then
		SetCvByPos(self.owner,pos)
	else
		SendModRPCToServer(MOD_RPC["icey_rpc"]["icey_cv_set"],pos)
	end 
	self.soundMainCall:SetText("当前CV:"..GetCvName(self.owner))
end 

local IceySoundWidget = Class(Widget, function(self, owner)
	Widget._ctor(self, "IceySoundWidget") 
    self.owner = owner
	--self.pos = GetCvPos(owner)
	
	local function on_soundMainCall_clicked()
		ChangeCv(self)
	end
	
	self.soundMainCall = self:AddChild(TextButton("soundMainCall"))
	self.soundMainCall:SetText("当前CV:"..GetCvName(self.owner))
	self.soundMainCall:SetColour(0/255,131/255,255/255,1)
	self.soundMainCall:SetHAnchor(1) -- 设置原点x坐标位置，0、1、2分别对应屏幕中、左、右
	self.soundMainCall:SetVAnchor(2) -- 设置原点y坐标位置，0、1、2分别对应屏幕中、上、下
    self.soundMainCall:SetPosition(100,55,0) -- 设置ancientmac widget相对原点的偏移量，70，-50表明向右70，向下50，第三个参数无意义。
	self.soundMainCall:SetOnClick(on_soundMainCall_clicked)
	
	self:StartUpdating()
end)

function IceySoundWidget:OnUpdate()
	self.soundMainCall:SetText("当前CV:"..GetCvName(self.owner))
end

return IceySoundWidget
