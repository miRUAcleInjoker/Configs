local DarkSoulDebuffable = Class(function(self, inst)
    self.inst = inst
    self._debuffs = {}
end)

function DarkSoulDebuffable:AddDebuff(name,buff_ent,percent,activated)
	
	if not self._debuffs[name] then 
		print("DarkSoulDebuffableReplica:AddDebuff",name,buff_ent,percent,activated)
		self._debuffs[name] = {
			["percent"] = net_float(buff_ent.GUID, "DarkSoulDebuffable.debuffs."..name..".percent"),
			["activated"] = net_bool(buff_ent.GUID, "DarkSoulDebuffable.debuffs."..name..".activated"),
		}
	end 
	self._debuffs[name]["percent"]:set(percent)
	self._debuffs[name]["activated"]:set(activated)
end

function DarkSoulDebuffable:RemoveDebuff(name)
	print("DarkSoulDebuffableReplica:RemoveDebuff",name)
	self._debuffs[name] = nil 
end

function DarkSoulDebuffable:GetVal(name)
	if self._debuffs[name] then 
		return self._debuffs[name]["percent"]:value(),self._debuffs[name]["activated"]:value()
	end
end

function DarkSoulDebuffable:GetList()
	local list = {}
	for name,v in pairs(self._debuffs) do 
		local p,a = self:GetVal(name)
		list[name] = {
			["percent"] = p,
			["activated"] = a,
		}
	end
	
	return list
end 

function DarkSoulDebuffable:ClearAll()
	self._debuffs = {}
end


return DarkSoulDebuffable 