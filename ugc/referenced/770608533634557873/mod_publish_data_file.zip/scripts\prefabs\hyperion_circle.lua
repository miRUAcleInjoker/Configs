local IceyUtil = require("icey_util")
local assets =
{
	Asset("ANIM", "anim/hyperion_circle.zip"),
    --Asset("ANIM", "anim/reticuleaoebase.zip"),
}

local prefabs = 
{
	"explode_small",
	"lava_explode",
	"hyperion_laser",
	"hyperion_dahe",
}

local assets_laser =---这个预设物包含的材质文件（动画，贴图等等）
{
Asset("ANIM", "anim/hyperion_laser.zip"),

}

local assets_explode =
{
    Asset("ANIM", "anim/lava_explode.zip"),
}

local bomb = 
{
	[1] = {name = "hyperion_laser",damage = 50,time = 0.15,aoe = 0},
	[2] = {name = "hyperion_dahe",damage = 200,time = 0.2,aoe = 1},
}


local hyperion_speech = {
	--jumpin = {1},
	begin = {1,7,12,17},
	chat = {2,3,9,10,11,14,18,20,21,22,24,25,27,29,30,33,37},
	leave = {13},
	--jumpout = {1},
}


local PAD_DURATION = .1
local SCALE = 1.5*1.5
local FLASH_TIME = .3
local volvolvol = 10

local function GetSoundPathNameByNum(num)
	local numadd = ""
	if num <= 9 then 
		numadd = "00"
	elseif num <=99 then 
		numadd = "0"
	end
	return "hyperion_new/hyperion_new/zUnit_HeroHyperion_Horner_"..numadd..tostring(num)
end 

local function GetSound(inst,type)
	local soundnum = math.random(1,#hyperion_speech[type])
	if inst.soundnum and inst.soundnum == soundnum then 
		return GetSound(inst,type)
	end
	inst.soundnum = soundnum
	return GetSoundPathNameByNum(hyperion_speech[type][soundnum]) or ""
end 

local function canattack(v,inst) ------------多重保险：判定目标是否真的可以被攻击，可以被伤害
	return IceyUtil.CanAttack(v,inst)
end  


local function booming(inst)
	local x,y,z = inst:GetPosition():Get()
	local ents = TheSim:FindEntities(x, y, z, 10, {"_combat"},TUNING.ICEY_NO_TAGS)
	local tries = 0
	if inst.owner == nil then 
		return
	end 
	for k,v in pairs(ents) do
		local num = 1
		if canattack(v,inst.owner) then ----------------------------------发现可以攻击的目标
			if v:HasTag("largecreature") then
				inst:DoTaskInTime(0.3,inst.Physics:Stop())
			end
			if math.random(0,100) > 90 then 
				num = 2
			end 
			tries = tries + 1
			local fx = bomb[num].name
			local damage = bomb[num].damage
			local time = bomb[num].time
			local aoe = bomb[num].aoe
			
			damage = damage * (inst.owner.components.combat.damagemultiplier or 1)
			
			inst:DoTaskInTime(math.random(0,15)/10,function()
				if canattack(v,inst.owner) then ------------------------------------开火的时候再检查一次
					local pos = v:GetPosition()
					inst.SoundEmitter:PlaySound("dontstarve/tentacle/smalltentacle_emerge")	
					local attackfx = SpawnPrefab(fx)
					attackfx.Transform:SetPosition(pos:Get())
					attackfx:SetTargetAndOwner(v,inst.owner)
					attackfx:SetDamage(damage)
					attackfx:SetTimeDelay(time) 
				end 
			end)
			
			if tries >= 5 then --------------一次性最多锁定5个目标
				break
			end
		end
	end
	--print("休伯利安号这次同时攻击了:"..tries.."个目标")
end 


local function UpdatePing(inst, s0, s1, t0, duration, multcolour, addcolour)
    if next(multcolour) == nil then
        multcolour[1], multcolour[2], multcolour[3], multcolour[4] = inst.AnimState:GetMultColour()
    end
    if next(addcolour) == nil then
        addcolour[1], addcolour[2], addcolour[3], addcolour[4] = inst.AnimState:GetAddColour()
    end
    local t = GetTime() - t0
    local k = 1 - math.max(0, t - PAD_DURATION) / duration
    k = 1 - k * k
    local s = Lerp(s0, s1, k)
    local c = Lerp(1, 0, k)
    inst.Transform:SetScale(s, s, s)
    inst.AnimState:SetMultColour(c * multcolour[1], c * multcolour[2], c * multcolour[3], c * multcolour[4])

    k = math.min(FLASH_TIME, t) / FLASH_TIME
    c = math.max(0, 1 - k * k)
    inst.AnimState:SetAddColour(c * addcolour[1], c * addcolour[2], c * addcolour[3], c * addcolour[4])
end

local function flashing(inst,mod)
	if mod == "begin"  then 
		--inst.SoundEmitter:PlaySound("ly_battleship/ly_battleship/Battlecruiser_Ready00")
		inst.SoundEmitter:PlaySound("hyperion_new/hyperion_new/Nova_HyperionJumpIn_Far_0"..tostring(math.random(1,3)),"jumpin",nil,true)
		--inst.SoundEmitter:SetVolume("ready",volvolvol)
	elseif mod == "over" then 
		--[[local num = math.random(0,14)
		if num <= 9 then 
			num = "0"..num
		end 
		local endsound = "Battlecruiser_Pissed"..num
		inst.SoundEmitter:PlaySound("ly_battleship/ly_battleship/"..endsound,"pissed")
		inst.SoundEmitter:SetVolume("pissed",volvolvol)--]]
		
		inst.SoundEmitter:KillSound("flying")
		--TheWorld.SoundEmitter:PlaySound("dontstarve/common/throne/thronedisappear")	
		inst:DoPeriodicTask(0, UpdatePing, nil, 1, 1.05, GetTime(), 0.5, {}, {})
	end
end 

local function chatting(inst)
	if not inst.canchat then 
		return
	end 
	--[[local num = math.random(1,12)
		if num <= 9 then 
			num = "0"..num
		end 
	local soundname = "Battlecruiser_Yes"..num
	inst.SoundEmitter:PlaySound("ly_battleship/ly_battleship/"..soundname)--]]
	--inst.SoundEmitter:SetVolume("yes",volvolvol)
	inst.SoundEmitter:PlaySound(GetSound(inst,"chat"))
end 

local function findowner(inst)
	if inst.owner_id ~= 0 and inst.owner == nil then 
		for k,v in pairs(AllPlayers) do 
			if v.userid == inst.owner_id then 
				inst.owner = v 
				break
			end
		end
	end
end 

local function onsave(inst,data)
	data.owner_id = inst.owner_id or nil
end 

local function onload(inst,data)
	if data and data.owner_id ~= nil then 
		inst.owner_id = data.owner_id 
	end 
	findowner(inst)
	--inst.components.ly_projectile:Throw(inst,mouse,false)
end 

local function init(inst)
    if inst.icon == nil and not inst:HasTag("burnt") then
        inst.icon = SpawnPrefab("globalmapicon")
        inst.icon.MiniMapEntity:SetIsFogRevealer(true)
        inst.icon:TrackEntity(inst)
    end
end

local function fn()
	local inst = CreateEntity()--以下这三句都是默认要添加的，这里就不解释那么多了
	local trans = inst.entity:AddTransform()
	local anim = inst.entity:AddAnimState()
	inst.entity:SetCanSleep(false)
    inst.persists = false
	inst.entity:AddSoundEmitter()
	inst.entity:AddNetwork()
	inst.entity:AddMiniMapEntity()
	inst.entity:AddLight()
	
	inst.MiniMapEntity:SetCanUseCache(false)
	inst.MiniMapEntity:SetDrawOverFogOfWar(true)
	
	anim:SetBank("hyperion_circle")-----前面两句是指定hyperion_circle的图片边界和材质，在特效中作用不大，只是必写。
	anim:SetBuild("hyperion_circle")
	--anim:PlayAnimation("hyperion_circle1")
	inst:Hide()
	
    MakeInventoryPhysics(inst)
    RemovePhysicsColliders(inst)
	
	--inst.Transform:SetSixFaced()
	
	anim:SetOrientation(ANIM_ORIENTATION.OnGround)
	
    anim:SetLayer(LAYER_WORLD_BACKGROUND)
    anim:SetSortOrder(3)
    anim:SetScale(2, 2)
	
	inst:AddTag("projectile")
	inst:AddTag("hyperion_circle")
	
	inst.Light:SetIntensity(0.7)
	inst.Light:SetRadius(8)
	inst.Light:SetFalloff(0.5)
	inst.Light:SetColour(44/255,143/255,255/255)
	inst.Light:Enable(false)

	
	inst.entity:SetPristine()
	
	if not TheWorld.ismastersim then
		return inst
	end
	
	inst.owner_id = 0
	inst.owner = nil
	inst.canchat = true
	inst.canattack = false
	inst.OnSave = onsave
	inst.OnLoad = onload
	
	
	
	inst:AddComponent("ly_projectile")
    inst.components.ly_projectile:SetSpeed(2)
	inst.components.ly_projectile:SetRange(500)
	
	inst:AddComponent("maprevealer")
	inst:DoTaskInTime(0, init)
	
	---------------------------------------------------------------------------
	inst:DoTaskInTime(0.1,function()flashing(inst,"begin")end)-------播放折跃进入音效
	inst:DoTaskInTime(1,function()----显示动画
		inst:Show()
		inst.canattack = true
		anim:PlayAnimation("hyperion_circle1")
		inst.Light:Enable(true)
		inst.SoundEmitter:PlaySound(GetSound(inst,"begin"),nil,nil,true)
		ShakeAllCameras(CAMERASHAKE.VERTICAL, .7, .015, .8, inst, 20)
		inst:DoPeriodicTask(0.5,function() if inst.canattack then booming(inst) end end)--------------------开始攻击!
	end)
	inst:DoTaskInTime(1.5,function()
		inst.SoundEmitter:PlaySound("dontstarve/common/throne/thronemagic","flying",nil,true)
		inst:DoPeriodicTask(2.5,function()chatting(inst)end )	------现在才能开始聊天
	end)
	inst:DoTaskInTime(16,function()  inst.canchat = false inst.canattack = false end)
	inst:DoTaskInTime(16.5,function() 
		inst.SoundEmitter:PlaySound("hyperion_new/hyperion_new/Nova_HyperionJumpOut_Far_0"..tostring(math.random(1,3)),"jumpout",nil,true) 
	end)
	inst:DoTaskInTime(17.5,function()
		inst.Light:Enable(false)
		ShakeAllCameras(CAMERASHAKE.VERTICAL, .7, .015, .8, inst, 20)
		flashing(inst,"over")
	end)------消失动画
	inst:DoTaskInTime(18,function()    inst:Hide()end)
	inst:DoTaskInTime(23,function()  inst:Remove()end)
	return inst
end

--------------------------------------------------------------------------

local function build_bombing(name,dahe,ass,isaoe)
	local function DoAttack(inst)
		if inst.attacked then 
			inst:Remove() 
			return 
		end 
		if inst.AnimState:AnimDone() then 
			if dahe then
				inst:AoeAttack()
			else
				inst:Attack()
			end
			inst.attacked = true
			inst:Remove() 
		end 
	end 
	local function fn()
		local inst = CreateEntity()--以下这三句都是默认要添加的，这里就不解释那么多了
		local trans = inst.entity:AddTransform()
		local anim = inst.entity:AddAnimState()
		local sed = inst.entity:AddSoundEmitter()
		local num = math.random(1,3)
		if dahe then
			num = 4
		end 
		inst:AddTag("hyperion_laser")
		inst.entity:AddNetwork()
		anim:SetBank("hyperion_laser")-----前面两句是指定hyperion_laser的图片边界和材质，在特效中作用不大，只是必写。
		anim:SetBuild("hyperion_laser")
		anim:PlayAnimation("hyperion_laser"..num)
		sed:PlaySound("dontstarve/common/destroy_metal")
		
		inst.entity:SetPristine()
		
		if not TheWorld.ismastersim then
			return inst
		end
		
		inst.attacked = false
		inst.target = nil 
		inst.owner = nil 
		inst.damage = 20
		inst.timedelay = nil 
		
		
		inst.SetTargetAndOwner = function(self,target,owner)
			self.target = target
			self.owner = owner
		end 
		
		inst.SetDamage = function(self,damage)
			self.damage = damage 
		end 
		
		inst.SetTimeDelay = function(self,time)
			self.timedelay = time 
			self:DoTaskInTime(time,DoAttack)
		end 
		
		inst.Attack = function(self,target,damage)
			target = target or self.target
			damage = damage or self.damage
			if canattack(target,self.owner) then ---------------------------命中目标的时候再检查一次
				target.components.combat:GetAttacked(self.owner,damage)
				local hitfx = SpawnPrefab("explode_small")
				hitfx.Transform:SetPosition(target:GetPosition():Get())
				hitfx.Transform:SetScale(0.8,0.8,0.8)
			end 
		end 
		
		inst.AoeAttack = function(self,pos,damage)
			pos = pos or inst:GetPosition()
			damage = damage or self.damage
			local range = TheSim:FindEntities(pos.x, pos.y, pos.z,3,{"_combat"},TUNING.ICEY_NO_TAGS)
			for i,z in pairs(range) do 
				if canattack(z,self.owner) then ------------------大和炮aoe的时候依然检查一次
					z.components.combat:GetAttacked(self.owner,damage)
				end 
			end
			local hitfx = SpawnPrefab("lava_explode")
			hitfx.Transform:SetPosition(pos:Get())
			hitfx.Transform:SetScale(1.5,1.5,1.5)
		end 
		
		inst:ListenForEvent("animover",DoAttack)
		
		return inst
	end
	return Prefab(name, fn, ass)
end 


local function fn_explode()
    local inst = CreateEntity()
    inst.entity:AddTransform()
    inst:AddTag("FX")

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
	inst.entity:AddNetwork()
	
    inst.AnimState:SetBank("explode")
    inst.AnimState:SetBuild("lava_explode")
    inst.AnimState:PlayAnimation("small_firecrackers")
    inst.AnimState:SetBloomEffectHandle("shaders/anim.ksh")
    inst.AnimState:SetLightOverride(1)
    inst.AnimState:SetFinalOffset(1)

    inst.SoundEmitter:PlaySound("dontstarve/common/blackpowder_explo")
    inst.entity:SetCanSleep(false)
    inst.persists = false
    inst:ListenForEvent("animover", inst.Remove)
	return inst
end

   

return Prefab("hyperion_circle", fn, assets,prefabs),
	Prefab("lava_explode", fn_explode, assets_explode),
	build_bombing("hyperion_laser",false,assets_laser),
	build_bombing("hyperion_dahe",true,assets_laser)