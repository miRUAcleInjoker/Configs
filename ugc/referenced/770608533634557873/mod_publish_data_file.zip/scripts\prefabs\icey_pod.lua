local assets_blue =
{
    Asset("ANIM", "anim/icey_pod.zip"),
}



local function common_blue()
    local inst = CreateEntity()
    
    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
	inst.entity:AddLight()
    inst.entity:AddDynamicShadow()
    inst.entity:AddNetwork()
	
	--inst.DynamicShadow:SetSize(1.5, 1)

	MakeCharacterPhysics(inst, 1, .003)
	
	inst:AddTag("icey_pod")

	inst.Transform:SetEightFaced()
	--inst.Transform: SetScale(2,2,2)
	
	inst.AnimState:SetBank("icey_pod")
	inst.AnimState:SetBuild("icey_pod")
	inst.AnimState:PlayAnimation("idle",true)
	
	inst.Light:SetIntensity(0.7)
	inst.Light:SetRadius(0.33)
	inst.Light:SetFalloff(0.5)
	inst.Light:SetColour(44/255,143/255,255/255)
	inst.Light:Enable(false)
	
	inst.entity:SetPristine()
	
	inst.ownerid = nil
	inst.soundcd = 0

    if not TheWorld.ismastersim then
        return inst
    end

	inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("你是来监视我的吗?")

	return inst
end

return Prefab("icey_pod", common_blue, assets_blue)
