local assets = 
{
	Asset("ANIM", "anim/worm_bait.zip"),
    --Asset("ANIM", "anim/icey_armor_swap.zip"), 

    Asset("ATLAS", "images/inventoryimages/worm_bait.xml"),
    Asset("IMAGE", "images/inventoryimages/worm_bait.tex"),
}

local function CanSummon(inst)
	local turf = TheWorld.Map:GetTileAtPoint(inst:GetPosition():Get())
	return turf == GROUND.MARSH and not inst:IsInLimbo() and (TheWorld.state.phase == "night" or TheWorld.state.phase == "dusk")
end 

local function OnStartCheck(inst)
	if inst.CheckToSummonTask then 
		inst.CheckToSummonTask:Cancel()
		inst.CheckToSummonTask = nil 
	end 
	inst.CheckToSummonTask = inst:DoPeriodicTask(5,function()
		if CanSummon(inst) then 
			local x,y,z = inst:GetPosition():Get()
			local pug = SpawnPrefab("pugalisk")
			pug.Transform:SetPosition(x,y,z)
			pug.sg:GoToState("emerge_taunt")
			pug.wantstotaunt = false 
			inst.CheckToSummonTask:Cancel()
			inst.CheckToSummonTask = nil 
			TheNet:Announce("世界吞噬者苏醒了")
			inst:Remove()  
		end
	end)
end 

local function OnStopCheck(inst)
	if inst.CheckToSummonTask then 
		inst.CheckToSummonTask:Cancel()
		inst.CheckToSummonTask = nil 
	end 
end 

local function OnDrop(inst)
	OnStartCheck(inst)
end 

local function OnPick(inst)
	OnStopCheck(inst)
end 

local function fn()
	local inst = CreateEntity()
	local trans = inst.entity:AddTransform()
	local anim = inst.entity:AddAnimState()
	inst.entity:AddSoundEmitter()
	inst.entity:AddNetwork()

    MakeInventoryPhysics(inst)

    anim:SetBank("worm_bait")
    anim:SetBuild("worm_bait")
    anim:PlayAnimation("idle",false)
	
	trans:SetScale(1.5,1.5,1.5)
	
	inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end	
	
	inst.CheckToSummonTask = nil 

    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("满足一条大家伙的胃口")
	
    inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "worm_bait"
	inst.components.inventoryitem.atlasname = "images/inventoryimages/worm_bait.xml"
	
	inst.components.inventoryitem:SetOnDroppedFn(OnDrop)
	inst.components.inventoryitem:SetOnPickupFn(OnPick)


	return inst
end

return Prefab("common/inventory/worm_bait", fn, assets)
