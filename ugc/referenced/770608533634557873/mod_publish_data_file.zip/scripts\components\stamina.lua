local easing = require("easing")
local SourceModifierList = require("util/sourcemodifierlist")

local function onmax(self, max)
    self.inst.replica.stamina:SetMax(max)
end

local function oncurrent(self, current)
    self.inst.replica.stamina:SetCurrent(current)
end

local function AttackExtraMultFn(inst)
	if inst.components.inventory and inst.components.inventory:EquipHasTag("hat_icey_chicken") then 
		return 0,0
	end 
	local extramult_consume,extramult_pausetime = 1,1
	local Combat = inst.components.combat
	local weapon = Combat:GetWeapon()
	local player_multdamage = (Combat.damagemultiplier or 1) * Combat.externaldamagemultipliers:Get()
	if weapon then 
		if weapon:HasTag("vacuum_sword") then 
			return 0,0
		end
	end
	extramult_consume = player_multdamage * extramult_consume
	
	return extramult_consume,extramult_pausetime
end 

local ActionConsumeList = {
	[ACTIONS.ATTACK] = {consume = 3.2,pausetime = 2,extramultfn = AttackExtraMultFn},
	[ACTIONS.PICK] = {consume = 7,pausetime = 0.3},
	[ACTIONS.PICKUP] = {consume = 3,pausetime = 0.3},
	[ACTIONS.MINE] = {consume = 7,pausetime = 0.5},
	[ACTIONS.HAMMER] = {consume = 5,pausetime = 0.5},
	[ACTIONS.DIG] = {consume = 6,pausetime = 1.0},
	[ACTIONS.CHOP] = {consume = 3,pausetime = 0.5},
}

local function OnPerformAction(inst,data)
	local self = inst.components.stamina
	local bufferedaction = data.action
	if bufferedaction and bufferedaction.action and ActionConsumeList[bufferedaction.action] then 
		local extramultfn = ActionConsumeList[bufferedaction.action].extramultfn or function() return 1,1 end
		local consume = ActionConsumeList[bufferedaction.action].consume or 0
		local pausetime = ActionConsumeList[bufferedaction.action].pausetime or 0
		local extramult_consume,extramult_pausetime = extramultfn(inst)
		extramult_consume = extramult_consume or 1
		extramult_pausetime = extramult_pausetime or 1
		
		if pausetime > 0 then 
			self:Pause(pausetime*extramult_pausetime)
		end 
		self:DoDelta(-consume*extramult_consume*self:CalcConsumeRate())
	end
end 

--Stamina:����������

local Stamina = Class(function(self, inst)
	self.inst = inst 
	self.max = 200
    self.current = self.max
	
	--self.ActionConsumes = {} 
	
	self.recoverrate = 1 
	self.externalrecoverratemultipliers = SourceModifierList(self.inst) 
	self.consumerate = 1
	self.externalconsumeratemultipliers = SourceModifierList(self.inst) 
	
	self.pausetime = 3
	self.canrecover = nil 
	self.paused = false 
	
	inst:StartUpdatingComponent(self)
	inst:ListenForEvent("performaction",OnPerformAction)
end,
nil,
{
	max = onmax,
    current = oncurrent,
})

function Stamina:SetCanRecoverFn(fn)
	self.canrecover = fn 
end 

function Stamina:SetMax(max)
	self.max = max
	self:DoDelta(0)
end 

function Stamina:SetCurrent(val)
	self.current = val
	self.current = math.max(0,self.current)
	self.current = math.min(self.max,self.current)
end 

function Stamina:SetPercent(percent)
	self:SetCurrent(percent*self.max)
end 

function Stamina:DoDelta(delta)
	self:SetCurrent(self.current+delta)
end 

--ThePlayer.components.stamina:SetPercent(0)
function Stamina:GetPercent()
	return self.current / self.max
end 

function Stamina:CalcRecoverRate()
	return self.recoverrate * self.externalrecoverratemultipliers:Get() 
end 

function Stamina:CalcConsumeRate()
	return self.consumerate * self.externalconsumeratemultipliers:Get() 
end 

local function RestartRecover(inst)
	local self = inst.components.stamina
	self:Restart()
end 

local function TimeRemainingInTask(taskinfo)
    local timeleft = (taskinfo.start + taskinfo.time) - GetTime()
	timeleft = math.max(0,timeleft)
	return timeleft
end 

function Stamina:Pause(delaytime)
	self.paused = true 
	delaytime = delaytime or self.pausetime
	local remaintime = nil 
	if self.recovertask then 
		self.recovertask:Cancel()
	end
	if self.recovertaskinfo then 
		remaintime = TimeRemainingInTask(self.recovertaskinfo)
	end
	
	if remaintime and remaintime > delaytime then  
		delaytime = remaintime 
	end
	self.recovertask = nil 
	self.recovertask = self.inst:DoTaskInTime(delaytime,RestartRecover)
	self.recovertaskinfo = self.inst:GetTaskInfo(delaytime)
end 

function Stamina:Restart()
	if self.recovertask then 
		self.recovertask:Cancel()
	end
	self.recovertask = nil 
	self.recovertaskinfo = nil 
	self.paused = false  
end 

function Stamina:OnUpdate(dt)
	local player = self.inst
	if player.sg and player.sg:HasStateTag("moving") 
	and (player.components.rider == nil or not player.components.rider:IsRiding())  then 
		local isrunning = player.components.locomotor.isrunning
		local speed = isrunning and player.components.locomotor:GetRunSpeed() or player.components.locomotor:GetWalkSpeed()
		local heavy_mult = player.components.inventory:IsHeavyLifting() and 25 or 1
		
		local total_stamina_consumerate = 1 
		for k, v in pairs(self.inst.components.inventory.equipslots) do
			if v.components.equippable and v.components.equippable.stamina_consumerate then
				total_stamina_consumerate = total_stamina_consumerate * v.components.equippable.stamina_consumerate
			end
		end 
		local delta = -dt*speed*0.4*heavy_mult*total_stamina_consumerate*self:CalcConsumeRate()
		self:DoDelta(delta)
	elseif player.sg and player.sg:HasStateTag("attack")  then 
	
	else
		if not self.paused and (self.canrecover == nil or self.canrecover(player)) then 
			local heavy_mult = player.components.inventory:IsHeavyLifting() and 1/20 or 1
			local total_stamina_recoverrate = 1 
			for k, v in pairs(self.inst.components.inventory.equipslots) do
				if v.components.equippable and v.components.equippable.stamina_recoverrate then
					total_stamina_recoverrate = total_stamina_recoverrate * v.components.equippable.stamina_recoverrate
				end
			end 
			self:DoDelta(dt*35*heavy_mult*total_stamina_recoverrate*self:CalcRecoverRate())
		end
	end
	
	if self:GetPercent() <= 0.5 then 
		player.components.locomotor:SetExternalSpeedMultiplier(player,"low_stamina",0.5+self:GetPercent())
	else
		player.components.locomotor:RemoveExternalSpeedMultiplier(player,"low_stamina")
	end
	
	if self:GetPercent() <= 0.2 then 
		player.components.combat.externaldamagemultipliers:SetModifier(player,0.8+self:GetPercent(),"low_stamina")
	else
		player.components.combat.externaldamagemultipliers:RemoveModifier(player,"low_stamina")
	end 
	
	if self:GetPercent() <= 0.2 then 
		player:AddTag("groggy")
	else
		--if player.components.grogginess == nil or not player.components.grogginess:HasGrogginess() then 
		local ext = player.components.locomotor:GetExternalSpeedMultiplier(player,"grogginess")
		if not ext or ext >= 1 then 
			player:RemoveTag("groggy")
		end 
	end
end

function Stamina:OnSave()
	return {
		current = self.current 
	}
end

function Stamina:OnLoad(data)
	if data then
		self.current = data.current 
	end 
	self:DoDelta(0)
end

Stamina.LongUpdate = Stamina.OnUpdate

return Stamina 