local ReflectLaserUser = Class(function(self, inst)
	self.inst = inst
	self.laser_prefab = "ice_projectile"
	self.delta_distance = 0.25
	self.max_distance = 40
	self.start_offset = 1
	
	self.onstartshoot = nil 
	self.onexpand = nil 
	self.onclearpoint = nil 
	
	self.last_reflect_num = 0 
	self.points = {}
end)

function ReflectLaserUser:AddPoint(pos,vec,is_reflect)
	local point = SpawnAt(self.laser_prefab,pos)
	point.persists = false
	point:AddTag("laser_point")
	table.insert(self.points,{ent = point,pos = pos,vec = vec,is_reflect = is_reflect})
	return point
end 

function ReflectLaserUser:ClearAllPoints(force)
	
	
	
	if self.onclearpoint and not force then 
		self.onclearpoint(self.inst,self.points)
	else
		for k,v in pairs(self.points) do 
			if v.ent:IsValid() then 
				v.ent:Remove()
			end 
		end
		
		self.points = {} 
		self.last_reflect_num = 0 
		self.inst:StopUpdatingComponent(self) 
	end 
end 


function ReflectLaserUser:Shoot(vec)
	self:ClearAllPoints(true)
	vec = vec or (TheInput:GetWorldPosition() - self.inst:GetPosition())
	local normal_vec = vec:GetNormalized()
	self:AddPoint(self.inst:GetPosition() + normal_vec * self.start_offset,vec)
	--[[while #self.points * self.delta_distance < self.max_distance do 
		self:Expand()
	end --]]
	if self.onstartshoot then 
		self.onstartshoot(self.inst,vec)
	end
	self.inst:StartUpdatingComponent(self) 
end

function ReflectLaserUser:Expand()
	local now_ent = self.points[#self.points].ent
	local now_vec = self.points[#self.points].vec
	local now_pos = self.points[#self.points].pos
	
	local is_reflect = false 
	local next_vec = now_vec
	local next_pos = now_pos + now_vec:GetNormalized() * self.delta_distance
	
	if #self.points > 1 then 
		local last_ent = self.points[#self.points-1].ent
		local last_vec = self.points[#self.points-1].vec
		local last_pos = self.points[#self.points-1].pos
		
		
		if #self.points - self.last_reflect_num >= 10 then 
			local obstacles = TheSim:FindEntities(now_pos.x,now_pos.y,now_pos.z,5,{},{"_combat","INLIMBO","FX","icey_pod","laser_point"})
			for k,v in pairs(obstacles) do 
				if v ~= self.inst then 
					local v_pos = v:GetPosition()
					local rad = v:GetPhysicsRadius(0)
					local dist = math.sqrt(distsq(now_pos.x,now_pos.z,v_pos.x,v_pos.z))
					if dist <= rad then 
						local vec_I = now_vec
						local vec_N = (now_pos - v_pos):GetNormalized()
						local vec_R = vec_I - vec_N * 2 * (vec_I:Dot(vec_N))
						
						self.last_reflect_num = #self.points
						is_reflect = true 
						next_pos = now_pos + vec_R:GetNormalized() * self.delta_distance
						next_vec = vec_R
						break 
					end
				end 
			end
		end 
	end 
	
	if self.onexpand then 
		self.onexpand(self.inst,next_pos,next_vec,is_reflect)
	end
	
	self:AddPoint(next_pos,next_vec,is_reflect)
end

function ReflectLaserUser:OnUpdate(dt)
	if #self.points * self.delta_distance < self.max_distance then 
		self:Expand()
		self:Expand()
		self:Expand()
		self:Expand()
		self:Expand()
	else
		self.inst:DoTaskInTime(1,function()
			self:ClearAllPoints()
		end)
		self.inst:StopUpdatingComponent(self) 
	end 
end

return ReflectLaserUser
