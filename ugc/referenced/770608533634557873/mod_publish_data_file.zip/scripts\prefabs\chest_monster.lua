local brain = require "brains/chestmonsterbrain"
local TadalinUtil = require("tadalin_util")


local assets =
{
	Asset("ANIM", "anim/ds_tallbird_basic.zip"),
    Asset("ANIM", "anim/chest_monster.zip"),
	
	--Asset("ANIM", "anim/chest_monster.zip"),
    Asset("SOUND", "sound/tallbird.fsb"),
}

local container_items = {
	--{item = {footballhat = 1,spear = 1,armorwood = 1},weight = 2},
	--{item = {wathgrithrhat = 1,spear_wathgrithr = 1,armorwood = 1},weight = 1.5},
	{item = {dragonslayer_trident = 1,gold_dust_repair = 10},weight = 1.5},
	{item = {dark_halberd = 1,gold_dust_repair = 10},weight = 1.5},
	{item = {nightmarefuel = 10,nightsword = 2,armor_sanity = 2},weight = 1},
	{item = {gears = 5,bluegem = 8,goldnugget = 5},weight = 0.5},
	{item = {minotaurhorn = 3,deerclops_eyeball = 3,bearger_fur = 2},weight = 0.3},
	{item = {ruinshat = 1,ruins_bat = 1,armorruins = 1},weight = 0.25},
	{item = {shroom_skin = 2,red_mushroomhat_blueprint = 1,green_mushroomhat_blueprint = 1},weight = 0.25},
	{item = {shroom_skin = 2,blue_mushroomhat_blueprint = 1,mushroom_light2_blueprint = 1},weight = 0.25},
}

SetSharedLootTable( 'chest_monster',
{
    {'boards',           1.00},
    {'boards',           1.00},
	{'meat',             1.00},
	{'meat',             1.00},
	{'meat',             1.00},
	{'chest_monster_hat',0.25},
})

local function Retarget(inst)
	if  not inst.components.sleeper:IsAsleep()  then  
		return TadalinUtil.NormalRetarget(inst)
	end
end

local function KeepTarget(inst, target)
    return TadalinUtil.NormalKeepTarget(inst,target)
end

local function CanGiveItem(inst)
	return inst.components.container:IsEmpty() and not inst.HasGivedItem
end 

local function GiveItems(inst)
	local pos = inst:GetPosition()
	local all_weight = 0
	for k,v in pairs(container_items) do 
		all_weight = all_weight + v.weight
	end
	local random = math.random()*all_weight
	for k,v in pairs(container_items) do 
		random = random - v.weight
		if random <= 0 then 
			for name,num in pairs(v.item) do 
				for i = 1,num do 
					local loot = SpawnPrefab(name)
					loot.Transform:SetPosition(pos:Get())
					inst.components.container:GiveItem(loot)
				end 
			end
			break
		end
	end
	inst.HasGivedItem = true 
end 


local function OnBecomeChest(inst)
	inst.Transform:SetNoFaced()

	inst.components.container.canbeopened = true 
	inst:AddTag("notarget")
	inst:AddTag("fake_chest")
	inst.nameoverride = "minotaurchest"
	inst.components.combat:SetDefaultDamage(0)
	inst.components.health:SetMaxHealth(0.0000001)
	inst.components.health:SetMinHealth(0.0000001)
	inst.components.inspectable:SetDescription(nil)
	
	
	
	--inst.components.floater:SetVerticalOffset(0.45)
	inst.components.floater:SetSize("med")
	
	--inst.components.icey_swimmer:SetFloatParams(Vector3(0.45, 1.0,0.5):Get())
end 

local function OnBecomeTallbird(inst)
	inst.Transform:SetFourFaced()

	inst.components.container.canbeopened = false 
	inst:RemoveTag("notarget")
	inst:RemoveTag("fake_chest")
	inst.nameoverride = nil
	inst.components.combat:SetDefaultDamage(TUNING.TALLBIRD_DAMAGE*2)
	inst.components.health:SetMaxHealth(TUNING.TALLBIRD_HEALTH*2)
	inst.components.health:SetMinHealth(0)
	inst.components.inspectable:SetDescription("它站起来了！！")
	
	--inst.components.floater:SetVerticalOffset(1)
	inst.components.floater:SetSize("large")
	if inst.components.icey_swimmer:IsSwimming() then 
		SpawnAt("splash_sink",inst:GetPosition()).Transform:SetScale(2,2,2)
	end
	--
	--inst.components.icey_swimmer:SetFloatParams(Vector3(0.25, 1.0,0.5):Get())
end 

local function displaynamefn(inst)
	return
        STRINGS.NAMES[
            (inst:HasTag("fake_chest") and string.upper("minotaurchest")) or
            "CHEST_MONSTER"
        ]
end 

local function onopen(inst,data)
	local doer = data.doer
	local spawnpos = doer:GetPosition()
    inst.SoundEmitter:PlaySound("dontstarve/wilson/chest_open")
	
	inst.components.combat:SetTarget(doer)
	inst:DoTaskInTime(0,function()
		inst.components.combat:SetDefaultDamage(TUNING.TALLBIRD_DAMAGE*3)
	end)
	inst.components.container.canbeopened = false 
	inst.components.sleeper:WakeUp()
	
	local fx = SpawnPrefab("dark_halberd_fx")
	fx.Transform:SetScale(1.5,1.5,1.5)
	fx.Transform:SetPosition(spawnpos:Get()) 
	local trail = SpawnPrefab("damp_trail")
	trail.Transform:SetPosition(spawnpos:Get()) 
	trail:SetVariation(math.random(1,7),0.8,1.5+math.random())
	if doer.components.grogginess then 
		doer.components.grogginess:AddGrogginess(10,5)
	end 
	--inst:DoTaskInTime(0.3,function()
	inst.components.container:Close()
	--end)
end 

local function onclose(inst)

end

local function OnAwake(inst)
	OnBecomeTallbird(inst)
end 

local function OnSleep(inst)
	OnBecomeChest(inst)
end 

local function ShouldSleep(inst)
    return  inst.components.combat.target == nil
end

local function ShouldWake(inst)
    return inst.components.combat.target ~= nil
end

local function OnAttacked(inst, data)
	return TadalinUtil.OnAttacked(inst,data)
end

local function OnDeath(inst)
	inst.components.container:DropEverything()
end 

local function OnSave(inst,data)
	data.HasGivedItem = inst.HasGivedItem
end 

local function OnLoad(inst,data)
	if data then 
		inst.HasGivedItem = data.HasGivedItem
	end 
end 


local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddLightWatcher()
    inst.entity:AddDynamicShadow()
    inst.entity:AddNetwork()

    MakeGiantCharacterPhysics(inst, 1000, .5)

    inst.DynamicShadow:SetSize(2.75, 1)
    inst.Transform:SetScale(1.5, 1.5, 1.5)
    inst.Transform:SetFourFaced()

    ----------
    inst:AddTag("tallbird")
    inst:AddTag("animal")
    inst:AddTag("largecreature")
	inst:AddTag("tadalin")
	inst:AddTag("NO_ICEY_SWIMMER_JUMP")
	

    inst.AnimState:SetBank("tallbird")
    inst.AnimState:SetBuild("chest_monster")
    inst.AnimState:PlayAnimation("idle")
    inst.AnimState:Hide("eyeball")
	inst.AnimState:Hide("eyelash")
	inst.AnimState:Hide("eyewhite")
	inst.AnimState:Hide("beakfull")
	
	inst.nameoverride = "minotaurchest"
	inst.displaynamefn = displaynamefn  --Handles the changing names.
	
	TadalinUtil.MakeSwimableCreature(inst,"med",0.45,Vector3(0.45, 1.0,0.5))
	--inst.components.icey_swimmer:SetOnStartSwim()
	

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst._last_attacker = nil
    inst._last_attacked_time = nil
	
	
	inst.HasGivedItem = false 

    inst:AddComponent("locomotor") -- locomotor must be constructed before the stategraph
    inst.components.locomotor.walkspeed = 7
	inst.components.locomotor.pathcaps = { allowocean = true }

    inst:SetStateGraph("SGchest_monster")

    inst:AddComponent("lootdropper")
    inst.components.lootdropper:SetChanceLootTable("chest_monster")

    ------------------
    inst:AddComponent("health")
    inst.components.health:SetMaxHealth(TUNING.TALLBIRD_HEALTH*2)
	
    inst:AddComponent("container")
	inst.components.container.canbeopened = false 
    inst.components.container:WidgetSetup("dragonflychest")
    inst.components.container.onopenfn = onopen
    inst.components.container.onclosefn = onclose

    ------------------

    inst:AddComponent("combat")
    inst.components.combat.hiteffectsymbol = "head"
    inst.components.combat:SetDefaultDamage(TUNING.TALLBIRD_DAMAGE*2)
    inst.components.combat:SetAttackPeriod(TUNING.TALLBIRD_ATTACK_PERIOD/2)
    inst.components.combat:SetRetargetFunction(3, Retarget)
    inst.components.combat:SetKeepTargetFunction(KeepTarget)
    inst.components.combat:SetRange(TUNING.TALLBIRD_ATTACK_RANGE)

    MakeLargeBurnableCharacter(inst, "head")
    MakeLargeFreezableCharacter(inst, "head")
    MakeHauntablePanic(inst)
    ------------------

    inst:AddComponent("knownlocations")

    inst:AddComponent("leader")

    ------------------

    inst:AddComponent("eater")
    inst.components.eater:SetDiet({ FOODGROUP.OMNI }, { FOODGROUP.OMNI })

    ------------------
    inst:AddComponent("sleeper")
    inst.components.sleeper:SetResistance(3)
    inst.components.sleeper.testperiod = GetRandomWithVariance(6, 2)
    inst.components.sleeper:SetSleepTest(ShouldSleep)
    inst.components.sleeper:SetWakeTest(ShouldWake)
    ------------------

    inst:AddComponent("inspectable")
	--[[inst.components.inspectable.description = function(inst,viewer)
		return inst.nameoverride == nil and "它站起来了！！！" or nil 
	end--]]
    ------------------

    inst:SetBrain(brain)
	
	inst.OnSave = OnSave
	inst.OnLoad = OnLoad

    inst:ListenForEvent("attacked", OnAttacked)
	inst:ListenForEvent("onwakeup",OnAwake)
	inst:ListenForEvent("gotosleep",OnSleep)
	inst:ListenForEvent("death",OnDeath)
	
	inst.components.sleeper:GoToSleep()
	inst.sg:GoToState("sleep")
	
	inst:DoTaskInTime(1,function()
		if CanGiveItem(inst) then 
			GiveItems(inst) 
		end
	end)

    return inst
end

return Prefab("chest_monster", fn, assets)