local assets_happy_target = {
	Asset("ANIM", "anim/happy_target.zip"),
}

------------------------------------------------------------------------------------

local function turnon_happy_target(inst)
	inst.AnimState:PlayAnimation("attune_off")
	inst.AnimState:PushAnimation("happy",true)
	inst.Light:Enable(true)
	if not inst.SoundEmitter:PlayingSound("happy") then 
		inst.SoundEmitter:PlaySound("icey_bgms_remaster/bgms/emil_happy","happy")
	end
	if inst.HappyTauntTask ~= nil then 
		inst.HappyTauntTask:Cancel()
		inst.HappyTauntTask = nil 
	end
	inst.HappyTauntTask = inst:DoPeriodicTask(3,function()
		 
		local fx = SpawnPrefab("emote_fx")
		local x,y,z = inst:GetPosition():Get()
		local ents = TheSim:FindEntities(x,y,z,15, {"_combat"},{"icey_power_building"})
		fx.entity:AddFollower()
        fx.Follower:FollowSymbol(inst.GUID, "ww_head", 0, -200, 0)
		for k,v in pairs(ents) do 
			if v and v:IsValid() and  v.components.combat and  v.components.combat.defaultdamage > 0 then 
				v.components.combat:SuggestTarget(inst)
			end 
		end
	end)
end 

local function turnoff_happy_target(inst)
	inst.AnimState:PlayAnimation("place")
	inst.AnimState:PushAnimation("idle")
	inst.Light:Enable(false)
	inst.SoundEmitter:KillSound("happy")
	if inst.HappyTauntTask ~= nil then 
		inst.HappyTauntTask:Cancel()
		inst.HappyTauntTask = nil 
	end
end 

local function CheckPower_happy_target(inst,data)
	local power = data.power
	inst.building_power = inst.building_power + power
	inst.building_power = math.max(0,inst.building_power)
	inst.building_power = math.min(inst.max_building_power,inst.building_power)
	if inst.components.machine:IsOn() then 
		if inst.building_power > 0 and not inst.IsOn then 
			print(inst,"Turn on!")
			turnon_happy_target(inst)
			inst.IsOn = true
		elseif inst.building_power <= 0 and inst.IsOn then
			print(inst,"Turn off!")
			turnoff_happy_target(inst)
			inst.IsOn = false
		end 
	end 
end

local function OnSave_happy_target(inst,data)
	data.building_power = inst.building_power
	--data.IsOn = inst.IsOn
end 

local function OnLoad_happy_target(inst,data)
	if data then 
		if data.building_power then 
			inst.building_power = data.building_power
		end
		--[[if data.IsOn then 
			inst.IsOn = data.IsOn
		end--]]
		CheckPower_happy_target(inst,{fromer = inst,power = 0})
	end
end 

local function onhammered_happy_target(inst)
	inst.components.lootdropper:DropLoot()
    local fx = SpawnPrefab("collapse_small")
    fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
    fx:SetMaterial("metal")
    inst:Remove()
end 

local function onbuilt_happy_target(inst)
    inst.AnimState:PlayAnimation("place")
    inst.AnimState:PushAnimation("idle")
    inst.SoundEmitter:PlaySound("dontstarve/common/lightning_rod_craft")
	inst.components.machine:TurnOn()
end

local function happy_target_fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()
	inst.entity:AddLight()

    MakeObstaclePhysics(inst, .3)

    inst.AnimState:SetBank("happy_target")
    inst.AnimState:SetBuild("happy_target")
    inst.AnimState:PlayAnimation("idle")
	
	local minimap = inst.entity:AddMiniMapEntity() -------------设置小地图标志
	minimap:SetIcon("happy_target.tex")
	
	inst:AddTag("icey_power_use")
	inst:AddTag("icey_power_building")
	--inst:AddTag("structure")
	inst:AddTag("companion")

    MakeSnowCoveredPristine(inst)


	inst.Light:Enable(false)
    inst.Light:SetRadius(2.5)
    inst.Light:SetFalloff(1)
    inst.Light:SetIntensity(.5)
    inst.Light:SetColour(141/255,224/255,255/255)
	
    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end


	inst.IsOn = false
	inst.building_power = 0
	inst.max_building_power = 500
	
	
    inst:AddComponent("inspectable")
	inst.components.inspectable.descriptionfn = function(inst,doer)
		return (inst.building_power > 0 and "看起来吵吵的~" ) or "它需要充电了!"
	end

    inst:AddComponent("combat")
 
    inst:AddComponent("health")
    inst.components.health:SetMaxHealth(1000)
    --inst.components.health:StartRegen(100,0.5)
	
	inst:AddComponent("machine")
    inst.components.machine.turnonfn = function() 
		inst:PushEvent("powertrans",{former = inst,power = 0})
	end 
    inst.components.machine.turnofffn = function() 
		turnoff_happy_target(inst)
		inst.IsOn = false
	end
	inst.components.machine.cooldowntime = 0.3
	
	inst.OnLoad = OnLoad_happy_target
	inst.OnSave = OnSave_happy_target
	
	inst:AddComponent("lootdropper")
	
	inst:AddComponent("workable")
    inst.components.workable:SetWorkAction(ACTIONS.HAMMER)
    inst.components.workable:SetWorkLeft(3)
	inst.components.workable:SetOnFinishCallback(onhammered_happy_target)
	
	
	inst:DoPeriodicTask(1,function()
		inst:PushEvent("powertrans",{former = inst,power = -10})
		if inst.components.health:IsHurt() and inst.building_power >= 10 then 
			inst:PushEvent("powertrans",{former = inst,power = -10})
			inst.components.health:DoDelta(50)
		end
	end)
	inst:ListenForEvent("powertrans",CheckPower_happy_target)
	inst:ListenForEvent("onbuilt", onbuilt_happy_target)

    return inst
end
---------------------------------------------------------------------------------------------------
return Prefab("happy_target", happy_target_fn, assets_happy_target),
MakePlacer("happy_target_placer", "happy_target", "happy_target", "idle")