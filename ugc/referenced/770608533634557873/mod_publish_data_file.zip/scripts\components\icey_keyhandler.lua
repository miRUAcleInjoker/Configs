--[[local function ignore( self )
	self.ignore_ = not self.ignore_
end--]]

local function IsHUDScreen(inst) 
	local defaultscreen = false 
	if TheFrontEnd:GetActiveScreen() and TheFrontEnd:GetActiveScreen().name  and type(TheFrontEnd:GetActiveScreen().name) == "string"  and TheFrontEnd:GetActiveScreen().name == "HUD" then 
		defaultscreen = true 
	end 
	return defaultscreen 
end  

local Icey_KeyHandler = Class(function(self, inst)
	self.inst = inst
	self.paused = false
	self.ignore_ = false
	self.enabled = true 
	self.ticktime = 0
	--self.ignore_event = net_event(self.inst.GUID, "ignore")
	self.handler = TheInput:AddKeyHandler(function(key, down) self:OnRawKey(key, down) end )
	self.mousehandler = TheInput:AddMouseButtonHandler(function(button, down, x, y) 
		self:OnMouseButton(button,down,x,y)
	end )
	
	--[[self.inst:ListenForEvent( "gamepaused", function(inst, paused) self.paused = paused end )
	self.inst:ListenForEvent( "ignore", function(inst)
		ignore( inst.components.icey_keyhandler )
	end)--]]
end)

local function check(my)
	local com = "否\n"
	local isdead = "否\n"
	local pghost = "否\n"
	local ghost = "否\n"
	if my.components.health ~= nil then 
		com = "是\n"
	end
	if my.components.health ~= nil and my.components.health:IsDead() then
		isdead = "是\n"
	end
	if my:HasTag("playerghost") then 
		pghost = "是\n"
	end
	if my:HasTag("ghost") then 
		ghost = "是\n"
	end
	local str = "人物:  "..my.prefab.."  玩家名字:  "..my.name.."\n是否有health组件:  "..com.."是否isdead():  "..isdead.."是否有playerghost标签:  "..pghost.."是否有ghost标签:  "..ghost
	print(str)
	return str
end 

--[[function Icey_KeyHandler:StartIgnoring()
	self.ignore_event:push()
end

function Icey_KeyHandler:StopIgnoring()
	self.ignore_event:push()
end--]]

function Icey_KeyHandler:SetEnabled(enable)
	self.enabled = enable
end 

function Icey_KeyHandler:MayCastSkill()
	return self.enabled and IsHUDScreen(self.inst) and not self.inst:HasTag("time_stopped")
end 

function Icey_KeyHandler:SetTickTime(time)
	self.ticktime = time or self.ticktime or 0 
end 

function Icey_KeyHandler:OnRawKey(key, down)
	local player = ThePlayer
	if player ~= nil then
  		if (key and not down) and not self.paused and not self.ignore_ then
      			player:PushEvent("keyup", {inst = self.inst, player = player, key = key})
		elseif key and down and not self.paused and not self.ignore_ then
      			player:PushEvent("keydown", {inst = self.inst, player = player, key = key})
		end
  	end
end

function Icey_KeyHandler:OnMouseButton(button,down,x,y)
	local player = ThePlayer
	if player ~= nil then
		if (button and not down) and not self.paused and not self.ignore_ then
      		player:PushEvent("mousebuttonup", {inst = self.inst, player = player, button = button})
		elseif button and down and not self.paused and not self.ignore_ then
      		player:PushEvent("mousebuttondown", {inst = self.inst, player = player, button = button})
		end
  	end
end

function Icey_KeyHandler:RpcAndMaster(Rpc,clientfn)
	local x,y,z = ( TheInput:GetWorldPosition() or Vector3(0,0,0) ):Get()
	local entity = TheInput:GetWorldEntityUnderMouse()
	local Namespace = Rpc.Namespace
	local Action = Rpc.Action
	if clientfn then 
		clientfn(self.inst,x,y,z,entity)
	end 
	if TheWorld.ismastersim then
		local masterfn = MOD_RPC_HANDLERS[Namespace][MOD_RPC[Namespace][Action].id]
		masterfn(self.inst,x,y,z,entity)
	else
		SendModRPCToServer( MOD_RPC[Namespace][Action], x,y,z,entity)
	end
end 

function Icey_KeyHandler:StartTrackingWhileDown(Rpc,keepfn)
	--self:StopTrackingWhileDown()
	--print("Icey_KeyHandler:StartTracking")
	if not self.inst.IceyKeyHandlerTickTask then 
		self.inst.IceyKeyHandlerTickTask = self.inst:DoTaskInTime(self.ticktime,function()
			self:RpcAndMaster(Rpc,keepfn)
			self:StopTrackingWhileDown()
			self:StartTrackingWhileDown(Rpc,keepfn)
			--print("Icey_KeyHandler:Tracking")
		end )
	end 
	--[[self.inst.IceyKeyHandlerTickTask = self.inst:DoPeriodicTask(self.ticktime,function()
		self:RpcAndMaster(Rpc)
		--self:StartTrackingWhileDown(Rpc)
		--print("Icey_KeyHandler:Tracking")
	end )--]]
end 

function Icey_KeyHandler:StopTrackingWhileDown(Rpc,outfn)
	if self.inst.IceyKeyHandlerTickTask then 
		self.inst.IceyKeyHandlerTickTask:Cancel()
	end 
	self.inst.IceyKeyHandlerTickTask = nil 
	if Rpc then 
		self:RpcAndMaster(Rpc,outfn)
		--print("Icey_KeyHandler:StopTracking")
	end 
end 




function Icey_KeyHandler:AddActionListenerWhileDown(Key,EnterRpc,KeepRpc,OutRpc,TickTime,clientfns)
	local enterfn = clientfns and clientfns.enterfn or nil 
	local keepfn = clientfns and clientfns.keepfn or nil 
	local outfn = clientfns and clientfns.outfn or nil 
	self.inst:ListenForEvent("keydown", function(inst, data)
		if data.inst == ThePlayer then
			if data.key == Key then
					----按键的前提条件
				--if IsHUDScreen(self.inst)  and 
				if self:MayCastSkill() and 
					not ThePlayer:HasTag("playerghost") 
					and not ThePlayer:HasTag("incar") 
					--and not ThePlayer.sg:HasStateTag("NOICEYSKILL") 
					and not (ThePlayer.components.health and ThePlayer.components.health:IsDead())
					then
						if EnterRpc then 
							self:RpcAndMaster(EnterRpc,enterfn)
						end 
						if KeepRpc then 
							self:SetTickTime(TickTime)
							self:StartTrackingWhileDown(KeepRpc,keepfn)
						end 
				else
					--local str = check(ThePlayer)	
				end
			end
		end	
	end)
	
	self.inst:ListenForEvent("keyup", function(inst, data)
		if data.inst == ThePlayer then
			if data.key == Key then
				self:StopTrackingWhileDown(OutRpc,outfn)
			end
		end	
	end)
end 

function Icey_KeyHandler:AddActionListener(Key,Rpc,isdown,clientfn)
	local keyevent = isdown and "keydown" or "keyup"
	local buttonevent = isdown and "mousebuttondown" or "mousebuttonup"
	
	self.inst:ListenForEvent(keyevent, function(inst, data)
		if data.inst == ThePlayer then
			if data.key == Key then
				----按键的前提条件
				if self:MayCastSkill()  and not ThePlayer:HasTag("playerghost") and not ThePlayer:HasTag("incar") 
				and not (ThePlayer.components.health and ThePlayer.components.health:IsDead()) then
					self:RpcAndMaster(Rpc,clientfn)
				else
					local str = check(ThePlayer)
				end
			end
		end	
	end)
	
	

end

function Icey_KeyHandler:AddMouseActionListener(button,Rpc,isdown,clientfn)
	local buttonevent = isdown and "mousebuttondown" or "mousebuttonup"
	
	self.inst:ListenForEvent(buttonevent, function(inst, data)
		if data.inst == ThePlayer then
			if data.button == button then
				if self:MayCastSkill()  and not ThePlayer:HasTag("playerghost") and not ThePlayer:HasTag("incar") 
				and not (ThePlayer.components.health and ThePlayer.components.health:IsDead()) then
					self:RpcAndMaster(Rpc,clientfn)
				else
					local str = check(ThePlayer)
				end
			end
		end	
	end)
end

function Icey_KeyHandler:AddMouseActionListenerWhileDown(button,EnterRpc,KeepRpc,OutRpc,TickTime,clientfns)
	
	local enterfn = clientfns and clientfns.enterfn or nil 
	local keepfn = clientfns and clientfns.keepfn or nil 
	local outfn = clientfns and clientfns.outfn or nil 
	self.inst:ListenForEvent("mousebuttondown", function(inst, data)
		if data.inst == ThePlayer then
			if data.button == button then
					----按键的前提条件
				if self:MayCastSkill()  and 
					not ThePlayer:HasTag("playerghost") 
					and not ThePlayer:HasTag("incar") 
					--and not ThePlayer.sg:HasStateTag("NOICEYSKILL") 
					and not (ThePlayer.components.health and ThePlayer.components.health:IsDead())
					then
						if EnterRpc then 
							self:RpcAndMaster(EnterRpc,enterfn)
						end 
						if KeepRpc then 
							self:SetTickTime(TickTime)
							self:StartTrackingWhileDown(KeepRpc,keepfn)
						end 
				else
					--local str = check(ThePlayer)	
				end
			end
		end	
	end)
	
	self.inst:ListenForEvent("mousebuttonup", function(inst, data)
		if data.inst == ThePlayer then
			if data.button == button then
				self:StopTrackingWhileDown(OutRpc,outfn)
			end
		end	
	end)
end 



return Icey_KeyHandler