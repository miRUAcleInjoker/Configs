local assets =
{ 
    Asset("ANIM", "anim/machine_badge.zip"),
    --Asset("ANIM", "anim/machine_badge_swap.zip"), 

    Asset("ATLAS", "images/inventoryimages/machine_badge.xml"),
    Asset("IMAGE", "images/inventoryimages/machine_badge.tex"),
}

local function OnAttacked(owner,data)
	local damage = data.damage
	local attacker = data.attacker
	local delta = damage 
	if owner.components.combat.redirectdamagefn then 
		return 
	end 
	if owner.components.sanity then 
		if  owner.components.sanity.current >= delta then
		
		else
			local healthdelta = delta - owner.components.sanity.current
			owner.components.health:DoDelta(-healthdelta,nil,(attacker and attacker.prefab or nil),nil,nil,true)
		end
		owner.components.sanity:DoDelta(-delta)
	end
end 


local function OnEquip(inst, owner) 
	if owner:HasTag("icey") then 
		inst:ListenForEvent("attacked",OnAttacked,owner)
	end 
end

local function OnUnequip(inst, owner) 
	if owner:HasTag("icey") then 
		inst:RemoveEventCallback("attacked",OnAttacked,owner)
	end 
end

local function fn()

    local inst = CreateEntity()
    local trans = inst.entity:AddTransform()
	
    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()  --这个联机也必须加 
	
    MakeInventoryPhysics(inst)
	inst.entity:AddMiniMapEntity()
	
    inst:AddTag("armor")
	inst:AddTag("heavyarmor")
	inst:AddTag("hide_percentage")
	
	inst.AnimState:SetBank("machine_badge")
    inst.AnimState:SetBuild("machine_badge")
    inst.AnimState:PlayAnimation("idle")
	
	
	----------------------上面的东西 对主副机都有效
	
	inst.entity:SetPristine()   --这四句话 放到这里 也就是bank build 和tag之类的后面-。-
	if not TheWorld.ismastersim then
        return inst
    end
	
	----------------------下面的只对主机执行
	inst:AddComponent("chosenicey")
	
    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("隶属于勇者的徽章")
	
	inst:AddComponent("waterproofer")
	inst.components.waterproofer:SetEffectiveness(TUNING.WATERPROOFNESS_SMALL)


    inst:AddComponent("inventoryitem")
    inst.components.inventoryitem.imagename = "machine_badge"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/machine_badge.xml"
	
	inst:AddComponent("armor")
    inst.components.armor:InitIndestructible(0.90)
	
    inst:AddComponent("equippable")
    inst.components.equippable.equipslot = EQUIPSLOTS.NECK or EQUIPSLOTS.BODY
    inst.components.equippable:SetOnEquip(OnEquip)
    inst.components.equippable:SetOnUnequip(OnUnequip)
	inst.components.equippable.dapperness = TUNING.DAPPERNESS_MED
	
	MakeHauntableLaunch(inst)  --这个放后面就好了

    return inst
end

return  Prefab("common/inventory/machine_badge", fn, assets, prefabs)