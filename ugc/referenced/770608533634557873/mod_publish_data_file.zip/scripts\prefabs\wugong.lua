local headbrain = require "brains/wugongheadbrain"
local bodybrain = require "brains/wugongbodybrain"

local function headretargetfn(inst)
    if not inst.components.health:IsDead() then
        return FindEntity(inst,50, function(guy) 
            if not guy.components.health:IsDead() then
                return guy.components.inventory ~= nil
            end
        end,
        {"_combat","_health"} -- see entityreplica.lua
        )
    end
end


local function SpawnEyes(inst,offset)
	local x,y,z = inst:GetPosition():Get()
	local eye = SpawnPrefab("deerclops_eyeball")
	eye.Transform:SetPosition(offset:Get())
	eye.entity:SetParent(inst.entity)  
	eye:AddTag("FX")
    eye:AddTag("NOCLICK")   
	--eye.Physics:ClearCollisionMask()
	--RemovePhysicsColliders(eye)
	eye.Physics:SetActive(false)
	if eye.components.inventoryitem then 
		eye:RemoveComponent("inventoryitem")
	end
	if eye.components.edible then 
		eye:RemoveComponent("edible")
	end
	eye.persists = false
	eye:ListenForEvent("death",function()
		local fx = SpawnPrefab("explode_firecrackers")
		fx.Transform:SetScale(4,4,4)
		fx.Transform:SetPosition(eye.Transform:GetWorldPosition())
		eye:Remove()
	end,inst)
	return eye
end 

local function BecomeNewHead(inst)
	inst:AddTag("wugong_head")
	inst:RemoveTag("wugong_body")
	inst.LeftEye = SpawnEyes(inst,Vector3(0,0.33,-0.3))
	inst.RightEye = SpawnEyes(inst,Vector3(0,0.33,0.3))
	inst.PreBody = nil 
	inst:SetBrain(headbrain)
	inst.brain:Start()
	inst.components.combat:SetDefaultDamage(20)
    inst.components.combat:SetAttackPeriod(3)
    inst.components.combat:SetRetargetFunction(3, headretargetfn)
	inst.components.combat:SetRange(2,2.5)
end 

local function SpawnBody(inst)
	local x,y,z = inst:GetPosition():Get()
	local body = SpawnPrefab("wugong_body")
	body.Transform:SetPosition(x,y,z)
	body.persists = false
	if body.components.follower then 
		body.components.follower:SetLeader(inst)
	end
	body:ListenForEvent("attacked",function(me,data)
		local host = body:GetHost()
		if host and host:IsValid() and not host.components.health:IsDead() and host.components.combat then 
			host.components.combat:SuggestTarget(data.attacker)
		end
	end)
	body:ListenForEvent("death",function()
		local fx = SpawnPrefab("explode_firecrackers")
		local mx,my,mz = body:GetPosition():Get()
		fx.Transform:SetScale(4,4,4)
		fx.Transform:SetPosition(mx,my,mz)
		
		
		--local newhead = SpawnPrefab("explode_firecrackers")
		--body:Remove()
		--body.components.health:Kill()
		BecomeNewHead(body)
	end,inst)
	--body.brain:ReStart()
	return body
end 



local function SpawnManyBody(inst,num)
	num = num or 1
	local pre = inst
	for i=1,num do 
		local body = SpawnBody(pre)
		body.PreBody = pre
		pre.PstBody = body
		
		pre = body 
	end
end 

local function GetHost(inst)
	local pre = inst.PreBody
	if pre then 
		if  pre:HasTag("wugong_head") then 
			return pre
		else
			return pre:GetHost()
		end
	else
		return  
	end
end 

local function onattacked(inst,data)
	if inst:HasTag("wugong_head") then
		inst.components.combat:SetTarget(data.attacker)
	end 
    inst.components.combat:ShareTarget(data.attacker, 100, function(dude)
        return dude:HasTag("wugong_head")
            and not dude.components.health:IsDead()
    end, 10)
end 

local hats = {
	"straw",
	"top",
	"beefalo",
	"feather",
	"bee",
	"miner",
	"spider",
	"football",
	"earmuffs",
	"winter",
	"bush",
	"flower",
	"walrus",
	"slurtle",
	"ruins",
	"mole",
	"wathgrithr",
	"ice",
	"rain",
	"catcoon",
	"watermelon",
	"eyebrella",
	"red_mushroom",
	"green_mushroom",
	"blue_mushroom",
	"hive",
	"dragonhead",
	"dragonbody",
	"dragontail",
	"desert",
	"goggles",
	"skeleton",
}

local function ChangeHat(inst,name)
	name = name or hats[math.random(1,#hats)]
	local fname = "hat_"..name
    local symname = name.."hat"
    local prefabname = symname
	
	inst.AnimState:SetBank(symname)
    inst.AnimState:SetBuild(fname)
    inst.AnimState:PlayAnimation("anim")
end 

local function headfn()
	local inst = CreateEntity()
    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddDynamicShadow()
    inst.entity:AddNetwork()
	
	--MakeObstaclePhysics(inst, 0.15)
	--MakeGiantCharacterPhysics(inst, 10, .05)
	MakeInventoryPhysics(inst)
	
    inst.DynamicShadow:SetSize(1.5, 0.75)
    --inst.Transform:SetFourFaced()

   
    inst.AnimState:SetBank("beefalohat")
    inst.AnimState:SetBuild("hat_beefalo")
    inst.AnimState:PlayAnimation("anim")
	
	inst:AddTag("wugong_head")


    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("�ҵ�ñ�ӳɾ���!")
	
	inst:AddComponent("locomotor") -- locomotor must be constructed before the stategraph
    inst.components.locomotor.walkspeed = 5
    inst.components.locomotor.runspeed = 5
	
	inst:SetStateGraph("SGwugong_head")

    inst:SetBrain(headbrain)
	
	inst:AddComponent("health")
    inst.components.health:SetMaxHealth(1000)

    inst:AddComponent("combat")
    inst.components.combat:SetDefaultDamage(20)
    inst.components.combat:SetAttackPeriod(0.5)
    inst.components.combat:SetRetargetFunction(1, headretargetfn)
	inst.components.combat:SetRange(2,2.5)
	
	inst:AddComponent("knownlocations")
	inst:AddComponent("lootdropper")
	inst.components.lootdropper:SetLoot({"beefalohat"})
	
	inst:AddComponent("leader")
	
	inst.LeftEye = SpawnEyes(inst,Vector3(0,0.33,-0.3))
	inst.RightEye = SpawnEyes(inst,Vector3(0,0.33,0.3))
	
	inst:DoTaskInTime(0,function()
		SpawnManyBody(inst,50)
	end)
	
	--inst.MaxBodyNum = 2
	inst.PreBody = nil 
	inst.PstBody = nil 
	
	inst.GetHost = GetHost
	
	
	
	--inst.OnSave = OnSave
	--inst.OnLoad = OnLoad
	inst:ListenForEvent("attacked",onattacked)
	
    return inst
end

local function bodyfn()
	local inst = CreateEntity()
    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddDynamicShadow()
    inst.entity:AddNetwork()
	
	--MakeCharacterPhysics(inst, 1, .03)
	--MakeGhostPhysics(inst, .05, .05)
	MakeInventoryPhysics(inst)

    inst.DynamicShadow:SetSize(1.5, .75)
    --inst.Transform:SetFourFaced()

   
    inst.AnimState:SetBank("beefalohat")
    inst.AnimState:SetBuild("hat_beefalo")
    inst.AnimState:PlayAnimation("anim")
	
	inst:AddTag("wugong_body")


    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("�ҵ�ñ�ӳɾ���!")
	
	inst:AddComponent("locomotor") -- locomotor must be constructed before the stategraph
    inst.components.locomotor.walkspeed = 5
    inst.components.locomotor.runspeed = 5
	
	inst:SetStateGraph("SGwugong_head")
	inst:SetBrain(bodybrain)
	
	inst:AddComponent("health")
    inst.components.health:SetMaxHealth(1000)

    inst:AddComponent("combat")
    inst.components.combat:SetDefaultDamage(0)
	inst.components.combat:SetTarget(nil)
	
	inst:AddComponent("knownlocations")
	inst:AddComponent("lootdropper")
	inst.components.lootdropper:SetLoot({"beefalohat"})
	
	inst:AddComponent("follower")
	--inst.components.follower
	
	inst:AddComponent("leader")
	
	inst.PreBody = nil 
	inst.PstBody = nil 
	
	inst.GetHost = GetHost
	
	--ChangeHat(inst)
	inst:ListenForEvent("attacked",onattacked)
	
	return inst
end

return Prefab("wugong", headfn),
Prefab("wugong_body", bodyfn)