local TadalinUtil = require("tadalin_util")

local brain = require "brains/jackbrain"

local assets =
{
    --Asset("ANIM", "anim/icey_blade.zip"),
	Asset("SOUNDPACKAGE", "sound/jack.fev"),
    Asset("SOUND", "sound/jack.fsb"),
	
	Asset("ANIM", "anim/sword_buster.zip"),
	Asset("ANIM", "anim/swap_trusty_shooter.zip"),
	Asset("ANIM", "anim/player_actions_roll.zip"),
}

local function CanStartBGM(inst)
	return not inst:HasTag("enter_show")
end 

local function ClearWeapon(inst)
	inst.AnimState:ClearOverrideSymbol("swap_object")
    inst.AnimState:Hide("ARM_carry")
    inst.AnimState:Show("ARM_normal")
end 

local function EquipSword(inst)
	inst.AnimState:OverrideSymbol("swap_object", "sword_buster", "sword_buster")
	inst.AnimState:Show("ARM_carry")
	inst.AnimState:Hide("ARM_normal")
end 

local function EquipHandgun(inst)
	inst.AnimState:OverrideSymbol("swap_object", "swap_trusty_shooter", "swap_trusty_shooter")
	inst.AnimState:Show("ARM_carry")
	inst.AnimState:Hide("ARM_normal")
end 


local TimeStopAddColour = {34/255,0/255,57/255,1}
local TimeStopMultColour = {124/255,0/255,255/255,1}

local function OnSingleStopTime(inst,target,delay,stopped_components,isTheWorld)
	if target and target:IsValid() and not target:HasTag("shadow") then 
		
	end
end 

local function OnSingleResumeTime(inst,target,delay,stopped_components)
	if target and target:IsValid() and not target:HasTag("shadow") then 

	end
end 

local function OnTheWorld(inst,pos,radius,delay)
	local scale = radius / 10 + 1
	--[[local timecrack = SpawnPrefab("timecrack")
	timecrack.AnimState:SetAddColour(unpack(TimeStopAddColour))
	timecrack.Transform:SetScale(scale,scale,scale)
	timecrack.Transform:SetPosition(pos:Get())
	timecrack:DoTaskInTime(delay,timecrack.KillFx)--]]
	
	if inst.SoundEmitter then 
		inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/enemy/metal_robot/smash")
	end 
	--[[local fx = SpawnPrefab("laser_ring")
	local ring_scale = radius / 40 + 0.75
	fx:AddTag("NO_TIME_STOP")
	fx.Transform:SetPosition(pos:Get())
	fx.Transform:SetScale(ring_scale,ring_scale,ring_scale)--]]
	ShakeAllCameras(CAMERASHAKE.FULL, .35, .02, 1, inst, 40)
end 

local function TimeStoperTest(inst,target)
	return not target:HasTag("tadalin") 
end 


local function fn(Sim)
	local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddDynamicShadow()
    inst.entity:AddLightWatcher()
    inst.entity:AddNetwork()

    MakeCharacterPhysics(inst, 50, .5)

    inst.DynamicShadow:SetSize(1.5, .75)
    inst.Transform:SetFourFaced()
	
	inst.AnimState:SetBank("wilson") 
	inst.AnimState:SetBuild("wilson")
    inst.AnimState:PlayAnimation("idle", true)	
	
	inst.AnimState:AddOverrideBuild("player_lunge")
    inst.AnimState:AddOverrideBuild("player_attack_leap")
    inst.AnimState:AddOverrideBuild("player_superjump")
    inst.AnimState:AddOverrideBuild("player_multithrust")
    inst.AnimState:AddOverrideBuild("player_parryblock")
	inst.AnimState:AddOverrideBuild("player_pistol")
	inst.AnimState:AddOverrideBuild("player_actions_speargun")
	inst.AnimState:AddOverrideBuild("player_mount_actions_speargun")
	inst.AnimState:AddOverrideBuild("player_actions_roll")
	
	
	inst:AddTag("character")
    inst:AddTag("scarytoprey")  
	inst:AddTag("hostile")
	inst:AddTag("tadalin")
	inst:AddTag("monster")
	inst:AddTag("epic")
	inst:AddTag("noepicmusic")
	inst:AddTag("NO_TIME_STOP")
	
	TadalinUtil.AddEpicBGM(inst,"jack",CanStartBGM)

	
	inst.entity:SetPristine()
    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.last_laugh_time = GetTime() + 5 
	inst.last_combat_leap_start_time = GetTime() + 5 
	inst.last_dash_attack_time = GetTime() + 5 
	inst.last_combat_superjump_start_time = GetTime() + 5 
	inst.last_attack_cricle_time = GetTime()
	inst.EquipSword = EquipSword
	inst.EquipHandgun = EquipHandgun
	
    inst:AddComponent("knownlocations")
	inst:AddComponent("bloomer")
    inst:AddComponent("colouradder")
	inst:AddComponent("timer")

	
	
	inst:AddComponent("locomotor") -- locomotor must be constructed before the stategraph
    inst.components.locomotor.walkspeed = 5
    inst.components.locomotor.runspeed = 7
	
	inst:AddComponent("health")
	inst.components.health:SetMaxHealth(2000)
	
	inst:AddComponent("combat")
    inst.components.combat.defaultdamage = 34
	inst.components.combat:SetRange(15,2)
    inst.components.combat:SetAreaDamage(3,0.6)
	inst.components.combat:SetAttackPeriod(3)
    --inst.components.combat:SetRetargetFunction(3, Retarget)
	--inst.components.combat:SetKeepTargetFunction(KeepTarget)


	inst:AddComponent("inspectable")
	
	inst:AddComponent("timestoper")
	inst.components.timestoper:SetOnSingleStopTime(OnSingleStopTime)
	inst.components.timestoper:SetOnSingleResumeTime(OnSingleResumeTime)
	inst.components.timestoper:SetOnTheWorld(OnTheWorld)
	inst.components.timestoper:SetTimeStoperTest(TimeStoperTest)

	
	inst:SetBrain(brain)
	inst:SetStateGraph("SGjack")
	
	TadalinUtil.MakeNormalTadalin(inst)

	EquipHandgun(inst)
	return inst
end
-----------------------------------------------------------------
--[[local PAD_DURATION = .01
local FLASH_TIME = .3

local function UpdatePing(inst, s0, s1, t0, duration, multcolour, addcolour)
    if next(multcolour) == nil then
        multcolour[1], multcolour[2], multcolour[3], multcolour[4] = inst.AnimState:GetMultColour()
    end
    if next(addcolour) == nil then
        addcolour[1], addcolour[2], addcolour[3], addcolour[4] = inst.AnimState:GetAddColour()
    end
    local t = GetTime() - t0
    local k = 1 - math.max(0, t - PAD_DURATION) / duration
    k = 1 - k * k
    local s = Lerp(s0, s1, k)
    local c = Lerp(1, 0, k)
    inst.Transform:SetScale(s, s, s)
    inst.AnimState:SetMultColour(c * multcolour[1], c * multcolour[2], c * multcolour[3], c * multcolour[4])

    k = math.min(FLASH_TIME, t) / FLASH_TIME
    c = math.max(0, 1 - k * k)
    inst.AnimState:SetAddColour(c * addcolour[1], c * addcolour[2], c * addcolour[3], c * addcolour[4])
end

local function FadeOut(inst,startscale,adds)
	if inst.fadetask then 
		inst.fadetask:Cancel()
		inst.fadetask = nil 
	end
	startscale = startscale or 1
	adds = adds or 0.25 
	inst.fadetask = inst:DoPeriodicTask(0, UpdatePing, nil, startscale, startscale + adds, GetTime(), 0.3, {}, {})
	inst:DoTaskInTime(0.3,inst.Remove) 
end --]]


local function FadeOut(inst)
	inst:DoPeriodicTask(0,function()
		local multcolour = {}
		local addcolour = {}
		local delt_scale = 0.01
		local delt_multicolour = 0.02
		multcolour[1], multcolour[2], multcolour[3], multcolour[4] = inst.AnimState:GetMultColour()
		addcolour[1], addcolour[2], addcolour[3], addcolour[4] = inst.AnimState:GetAddColour()
		if multcolour[4] <= 0 then 
			inst:Remove()
		end
		local scale = inst.Transform:GetScale()
		inst.Transform:SetScale(scale + delt_scale,scale + delt_scale,scale + delt_scale)
		
		inst.AnimState:SetMultColour(multcolour[1], multcolour[2], multcolour[3], multcolour[4] - delt_multicolour)
		 
	end)
end 

local function shadowfn()
	local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()
	
	inst.Transform:SetFourFaced()
	
	inst.AnimState:SetBank("wilson") 
	inst.AnimState:SetBuild("wilson")
    inst.AnimState:PlayAnimation("atk_leap_lag")	
	
	inst.AnimState:SetMultColour(1,0,0,0.3)
	
	inst.entity:SetPristine()
    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.persists = false 
	
	inst.FadeOut = FadeOut
	EquipHandgun(inst)
	return inst
end

return Prefab("jack", fn, assets),
Prefab("jack_shadow", shadowfn, assets)