local assets = 
{
	icey_battery = {
		Asset( "ANIM", "anim/icey_battery.zip" ),
		Asset( "ATLAS", "images/inventoryimages/icey_battery.xml" ),
	},
	--[[icey_battery2 = {
		Asset( "ANIM", "anim/icey_battery2.zip" ),
		Asset( "ATLAS", "images/inventoryimages/icey_battery2.xml" ),
	},
	icey_battery3 = {
		Asset( "ANIM", "anim/icey_battery3.zip" ),
		Asset( "ATLAS", "images/inventoryimages/icey_battery3.xml" ),
	},
	icey_battery4 = {
		Asset( "ANIM", "anim/icey_battery4.zip" ),
		Asset( "ATLAS", "images/inventoryimages/icey_battery4.xml" ),
	},--]]
	icey_magic = {
		Asset("ANIM", "anim/deer_ice_charge.zip"),
		Asset( "ATLAS", "images/inventoryimages/icey_magic.xml" ),
	},
}




local function fn_common(name,Description,val,food_type,stack,can_Perish,PerishTime,scale,OnEatenFn)
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()

    MakeInventoryPhysics(inst)
	

    inst.AnimState:SetBank(name)
    inst.AnimState:SetBuild(name)
    inst.AnimState:PlayAnimation("idle")
	inst.Transform:SetScale(scale,scale,scale)
	
	inst:AddTag("edible_"..FOODTYPE.ICEY_BATTERY)

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription(Description)

    inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.atlasname = "images/inventoryimages/"..name..".xml"
	inst.components.inventoryitem.imagename = name
	
	
	
	inst:AddComponent("edible")
	inst.components.edible.healthvalue = val.health
    inst.components.edible.hungervalue = val.hunger
    inst.components.edible.sanityvalue = val.sanity
	inst.components.edible.foodtype = FOODTYPE.ICEY_BATTERY
	inst.components.edible.foodtype = food_type
	inst.components.edible:SetOnEatenFn(OnEatenFn)
	
	inst:AddComponent("stackable")
	inst.components.stackable.maxsize = stack
	
	if can_Perish then 
		inst:AddComponent("perishable")
		inst.components.perishable:SetPerishTime(PerishTime * TUNING.TOTAL_DAY_TIME)
		inst.components.perishable:StartPerishing()
		inst.components.perishable.onperishreplacement = "spoiled_food"
	end 


    return inst
end

local function fn_magic()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
	inst.entity:AddLight()
    inst.entity:AddNetwork()

    MakeInventoryPhysics(inst)
	

    inst.AnimState:SetBank("deer_ice_charge")
    inst.AnimState:SetBuild("deer_ice_charge")

	
	inst.Light:SetIntensity(0.7)
	inst.Light:SetRadius(0.8)
	inst.Light:SetFalloff(0.5)
	inst.Light:SetColour(44/255,143/255,255/255)
	inst.Light:Enable(true)
	
	inst:AddTag("edible_"..FOODTYPE.ICEY_BATTERY)

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst:DoTaskInTime(math.random(0,100) / 100,function()
		inst.AnimState:PlayAnimation("pre")
		inst.AnimState:PushAnimation("loop",true)
		inst.Transform:SetScale(0.5,0.5,0.5)
	end)
	
    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("奇怪的生物精华")

    inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.atlasname = "images/inventoryimages/icey_magic.xml"
	inst.components.inventoryitem.imagename = "icey_magic"
	
	
	
	inst:AddComponent("edible")
	inst.components.edible.healthvalue = 1
    inst.components.edible.hungervalue = 1
    inst.components.edible.sanityvalue =1
	inst.components.edible.foodtype = FOODTYPE.ICEY_BATTERY
	
	inst:AddComponent("stackable")
	inst.components.stackable.maxsize = TUNING.STACK_SIZE_SMALLITEM

    return inst
end

local function fn_battery()
	local val_battery = 
	{
		health = 10,
		hunger = 10,
		sanity = 10,
	}
	local function OnEatenFn_battery(inst,eater)
		if eater.components.icey_shield then 
			eater.components.icey_shield:DoDelta(25)
		end
	end
	return  fn_common("icey_battery","美味的...电池?",val_battery,FOODTYPE.ICEY_BATTERY,TUNING.STACK_SIZE_MEDITEM,false,356,1,OnEatenFn_battery)
end

--[[local function fn_battery2()
	local val_battery = 
	{
		health = 5,
		hunger = 40,
		sanity = 8,
	}
	local function OnEatenFn_battery2(inst,eater)
		if eater.prefab == "icey"  then 
			if eater.shieldfn then 
				eater.shieldfn(eater,3)
			end
		end
	end
	return  fn_common("icey_battery2","美味的...电池?",val_battery,FOODTYPE.ICEY_BATTERY,TUNING.STACK_SIZE_MEDITEM,false,356,1,OnEatenFn_battery2)
end

local function fn_battery3()
	local val_battery = 
	{
		health = 5,
		hunger = 25,
		sanity = 25,
	}
	local function OnEatenFn_battery3(inst,eater)
		if eater.prefab == "icey"  then 
			if eater.shieldfn then 
				eater.shieldfn(eater,7)
			end
		end
	end
	return  fn_common("icey_battery3","美味的...电池?",val_battery,FOODTYPE.ICEY_BATTERY,TUNING.STACK_SIZE_MEDITEM,false,356,1,OnEatenFn_battery3)
end

local function fn_battery4()
	local val_battery = 
	{
		health = 25,
		hunger = 20,
		sanity = 7,
	}
	local function OnEatenFn_battery4(inst,eater)
		if eater.prefab == "icey"  then 
			if eater.shieldfn then 
				eater.shieldfn(eater,5)
			end
		end
	end
	return  fn_common("icey_battery4","美味的...电池?",val_battery,FOODTYPE.ICEY_BATTERY,TUNING.STACK_SIZE_MEDITEM,false,356,1,OnEatenFn_battery4)
end--]]

return Prefab("icey_battery", fn_battery, assets.icey_battery),
--[[Prefab("icey_battery2", fn_battery2, assets.icey_battery2),
Prefab("icey_battery3", fn_battery3, assets.icey_battery3),
Prefab("icey_battery4", fn_battery4, assets.icey_battery4),--]]
Prefab("icey_magic", fn_magic, assets.icey_magic)



