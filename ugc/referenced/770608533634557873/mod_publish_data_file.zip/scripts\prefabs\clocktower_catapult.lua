local TadalinUtil = require("tadalin_util")
require("prefabutil")

local assets =
{
    Asset("ANIM", "anim/winona_catapult.zip"),
    Asset("ANIM", "anim/winona_catapult_placement.zip"),
    Asset("ANIM", "anim/winona_battery_placement.zip"),
}

local prefabs =
{
    "winona_catapult_projectile",
    "winona_battery_sparks",
    "collapse_small",
}

local brain = require("brains/winonacatapultbrain")

local KEEP_TARGET_BUFFER_DISTANCE = 5

local function OnPhase(inst)
	local phase = TheWorld.state.phase	
	if phase ~= "day" then 
		inst.components.combat:SetTarget(nil) 
	end
end 

local function RetargetFn(inst)
	local phase = TheWorld.state.phase	
	local target = TadalinUtil.NormalRetarget(inst,35)
	return (phase == "day" and target and target:HasTag("player") and not target:HasTag("clocktowerworks")) and target or nil 
end

local function ShouldKeepTarget(inst, target)
    return target ~= nil
        and target:IsValid()
        and target.components.health ~= nil
        and not target.components.health:IsDead()
		and inst:IsNear(target,35)
end



local function OnAttacked(inst, data)
	--[[if data.attacker and not data.attacker:HasTag("catapult") then 
		inst.components.combat:SetTarget(data.attacker)
	end--]]
end

local function OnWorked(inst, worker, workleft, numworks)
    inst.components.workable:SetWorkLeft(4)
    inst.components.combat:GetAttacked(worker, numworks * TUNING.WINONA_CATAPULT_HEALTH / 4, worker.components.inventory ~= nil and worker.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS) or nil)
end

local function OnWorkedBurnt(inst)
    inst.components.lootdropper:DropLoot()
    local fx = SpawnPrefab("collapse_small")
    fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
    fx:SetMaterial("wood")
    inst:Remove()
end

local function OnDeath(inst)
    if inst._inittask ~= nil then
        inst._inittask:Cancel()
        inst._inittask = nil
    end
    --inst.components.circuitnode:Disconnect()
    inst.components.workable:SetWorkable(false)
    if inst.components.burnable ~= nil then
        if inst.components.burnable:IsBurning() then
            inst.components.burnable:Extinguish()
        end
        inst.components.burnable.canlight = false
    end
    inst.Physics:SetActive(false)
    inst.components.lootdropper:DropLoot()
    local fx = SpawnPrefab("collapse_small")
    fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
    fx:SetMaterial("none")
end

local function OnBurnt(inst)
    DefaultBurntStructureFn(inst)

    inst:SetBrain(nil)
    inst:ClearStateGraph()

    inst:RemoveEventCallback("attacked", OnAttacked)
    inst:RemoveEventCallback("death", OnDeath)

    inst.components.workable:SetOnWorkCallback(nil)
    inst.components.workable:SetOnFinishCallback(OnWorkedBurnt)

    if inst._inittask ~= nil then
        inst._inittask:Cancel()
        inst._inittask = nil
    end
    --inst.components.circuitnode:Disconnect()

    inst:RemoveComponent("health")
    inst:RemoveComponent("combat")

    inst:AddTag("notarget") -- just in case???
end

local function OnBuilt(inst)--, data)
    if inst._inittask ~= nil then
        inst._inittask:Cancel()
        inst._inittask = nil
    end
    --inst.components.circuitnode:Disconnect()
    inst.sg:GoToState("place")
end

--------------------------------------------------------------------------

local function OnHealthDelta(inst)
    if inst.components.health:IsHurt() then
        inst.components.health:StartRegen(TUNING.WINONA_CATAPULT_HEALTH_REGEN, TUNING.WINONA_CATAPULT_HEALTH_REGEN_PERIOD)
    else
        inst.components.health:StopRegen()
    end
end

local function OnSave(inst, data)
    if inst.components.burnable ~= nil and inst.components.burnable:IsBurning() or inst:HasTag("burnt") then
        data.burnt = true
    else
        data.power = inst._powertask ~= nil and math.ceil(GetTaskRemaining(inst._powertask) * 1000) or nil
    end
end

local function OnLoad(inst, data)
    if inst._inittask ~= nil then
        inst._inittask:Cancel()
        inst._inittask = nil
    end
    if data ~= nil and data.burnt then
        inst.components.burnable.onburnt(inst)
    else
        if data ~= nil and data.power ~= nil then
            inst:AddBatteryPower(math.max(2 * FRAMES, data.power / 1000))
            if inst.sg:HasStateTag("idle") then
                inst.sg:GoToState("idle", true) --loading = true
            end
        end
        --Enable connections, but leave the initial connection to batteries' OnPostLoad
        --inst.components.circuitnode:ConnectTo(nil)
        OnHealthDelta(inst)
    end
end

local function OnInit(inst)
    inst._inittask = nil
    --inst.components.circuitnode:ConnectTo("engineeringbattery")
end



local function GetStatus(inst)
    return (inst:HasTag("burnt") and "BURNT")
        or (inst.components.burnable ~= nil and inst.components.burnable:IsBurning() and "BURNING")
        or (inst._powertask == nil and "OFF")
        or nil
end

local function PowerOff(inst)
    inst._powertask = nil
    inst:SetBrain(nil)
    inst.components.combat:SetTarget(nil)
    inst:PushEvent("togglepower", { ison = false })
end

local function AddBatteryPower(inst, power)
    local remaining = inst._powertask ~= nil and GetTaskRemaining(inst._powertask) or 0
    if power > remaining then
        local doturnon = false
        if inst._powertask ~= nil then
            inst._powertask:Cancel()
        else
            doturnon = true
        end
        inst._powertask = inst:DoTaskInTime(power, PowerOff)
        if doturnon then
            inst:SetBrain(brain)
            if not inst:IsAsleep() then
                inst:RestartBrain()
            end
            inst:PushEvent("togglepower", { ison = true })
        end
    end
end

local function IsPowered(inst)
    return true
end

local function OnUpdateSparks(inst)
    if inst._flash > 0 then
        local k = inst._flash * inst._flash
        inst.components.colouradder:PushColour("wiresparks", .3 * k, .3 * k, 0, 0)
        inst._flash = inst._flash - .15
    else
        inst.components.colouradder:PopColour("wiresparks")
        inst._flash = nil
        inst.components.updatelooper:RemoveOnUpdateFn(OnUpdateSparks)
    end
end

local function DoWireSparks(inst)
    inst.SoundEmitter:PlaySound("dontstarve/common/together/spot_light/electricity", nil, .5)
    SpawnPrefab("winona_battery_sparks").entity:AddFollower():FollowSymbol(inst.GUID, "wire", 0, 0, 0)
    if inst.components.updatelooper ~= nil then
        if inst._flash == nil then
            inst.components.updatelooper:AddOnUpdateFn(OnUpdateSparks)
        end
        inst._flash = 1
        OnUpdateSparks(inst)
    end
end


local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddMiniMapEntity()
    inst.entity:AddNetwork()

    MakeObstaclePhysics(inst, .5)

    inst.Transform:SetSixFaced()

    --inst:AddTag("companion")
    inst:AddTag("noauradamage")
	inst:AddTag("clocktowerworks")
	inst:AddTag("NODARKCHARGE")
    --inst:AddTag("engineering")
    inst:AddTag("catapult")
    inst:AddTag("structure")

    inst.AnimState:SetBank("winona_catapult")
    inst.AnimState:SetBuild("winona_catapult")
    inst.AnimState:PlayAnimation("idle_off")
    --This will remove mouseover as well (rather than just :Hide("wire"))
    inst.AnimState:OverrideSymbol("wire", "winona_catapult", "dummy")

    inst.MiniMapEntity:SetIcon("winona_catapult.png")

    --Dedicated server does not need deployhelper


    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst._state = 1

    inst:AddComponent("inspectable")
    inst.components.inspectable.getstatus = GetStatus

    inst:AddComponent("updatelooper")
    inst:AddComponent("colouradder")

    inst:AddComponent("health")
    inst.components.health:SetMaxHealth(TUNING.WINONA_CATAPULT_HEALTH)

    inst:AddComponent("combat")
    inst.components.combat:SetDefaultDamage(TUNING.WINONA_CATAPULT_DAMAGE)
    inst.components.combat:SetRange(35)
    inst.components.combat:SetAttackPeriod(TUNING.WINONA_CATAPULT_ATTACK_PERIOD)
    inst.components.combat:SetRetargetFunction(1, RetargetFn)
    inst.components.combat:SetKeepTargetFunction(ShouldKeepTarget)

    inst:AddComponent("lootdropper")
    inst:AddComponent("workable")
    inst.components.workable:SetWorkAction(ACTIONS.HAMMER)
    inst.components.workable:SetWorkLeft(4)
    inst.components.workable:SetOnWorkCallback(OnWorked)

    inst:AddComponent("savedrotation")

    --inst:AddComponent("circuitnode")
    --inst.components.circuitnode:SetRange(TUNING.WINONA_BATTERY_RANGE)
    --inst.components.circuitnode:SetOnConnectFn(OnConnectCircuit)
    --inst.components.circuitnode:SetOnDisconnectFn(OnDisconnectCircuit)
	inst:DoTaskInTime(0,OnPhase)
    inst:ListenForEvent("onbuilt", OnBuilt)
    inst:ListenForEvent("attacked", OnAttacked)
    inst:ListenForEvent("death", OnDeath)
    inst:ListenForEvent("healthdelta", OnHealthDelta)
	inst:WatchWorldState("phase",OnPhase)
	
	inst:SetBrain(brain)
    if not inst:IsAsleep() then
        inst:RestartBrain()
    end
    inst:PushEvent("togglepower", { ison = true })

    MakeHauntableWork(inst)
    MakeMediumBurnable(inst, nil, nil, true)
    MakeMediumPropagator(inst)
    inst.components.burnable:SetOnBurntFn(OnBurnt)

    inst.OnSave = OnSave
    inst.OnLoad = OnLoad
    inst.AddBatteryPower = AddBatteryPower
    inst.IsPowered = IsPowered

    inst:SetStateGraph("SGclocktower_catapult")
    --inst:SetBrain(brain)

    inst._wired = nil
    inst._flash = nil
    inst._inittask = inst:DoTaskInTime(0, OnInit)

    return inst
end


return Prefab("clocktower_catapult", fn, assets, prefabs)
