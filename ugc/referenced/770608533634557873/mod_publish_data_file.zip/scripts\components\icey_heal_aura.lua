

local IceyHealAura = Class(function(self, inst)
	self.inst = inst
	self.range = 4.1
	self.duration = 12
	self.heal_rate = 1

	self.cache = {}
	self.current_time = 0
	self.attack_cooldown = 2.5 -- somewhere between 2-3 seconds based on original forge, maybe add a random?
	self.sleep_duration = 2    -- is refreshed every tick, so this is really the duration mobs sleep after the heal end
	self.sleep_interrupt_cooldown = 5
	
	self.canbesleep = nil 

	self.inst:DoTaskInTime(0, inst.StartUpdatingComponent, self)
	self.onunfossilize = function(ent) self:OnUnfossilize(ent) end
	self.onwakeupstat = function(ent) self:OnWakeUpStat(ent) end
end)

local function IsDebuffable(ent)
	return ent.components.debuffable and ent.components.debuffable:IsEnabled()
end

local function IsEntityAlive(ent)
	return ent.components.health and not ent.components.health:IsDead()
end

local function IsPlayerOrAlly(ent)
	return ent:HasTag("player") or ent:HasTag("companion")
end

-- to prevent skipping states with epic mobs unfossilizing and mobs in bunkered or attack states from being slept
local function IsIgnoreState(ent)
	return ent.sg and ent.sg:HasStateTag("hiding") or ent.sg.HasStateTag("attack") or ((ent:HasTag("epic") and ent.sg:HasStateTag("caninterrupt")))
end

function IceyHealAura:SetCanSleep(fn)
	self.canbesleep = fn 
end 

-- we don't want the mob falling asleep while we are attacking them or attacked too recently
function IceyHealAura:IsRecentlyAttacked(ent)
	return self.current_time - ent.components.combat.lastwasattackedtime < self.attack_cooldown
end

function IceyHealAura:AddMobSleep(ent)
	if ent.components.sleeper and not self:IsRecentlyAttacked(ent) and not IsIgnoreState(ent) then
		ent.components.sleeper:AddSleepiness(10, self.sleep_duration)
		if not ent.stat_sleep_start then
			ent.stat_sleep_start = self.current_time
			-- Update numcc stat
			if self.caster and TheWorld and TheWorld.components.stat_tracker then
				TheWorld.components.stat_tracker:AdjustStat("numcc", self.caster, 1)
			end
		end
	end
end

function IceyHealAura:OnUpdate(dt)
	self.current_time = GetTime()
	local x, _, z = self.inst.Transform:GetWorldPosition()
	local ents = TheSim:FindEntities(x, 0, z, self.range, nil, {"fossilized", "battlestandard"})
	for _, ent in pairs(ents) do
		if not self.cache[ent] and IsEntityAlive(ent) then
			self.cache[ent] = true
			self:OnEntEnter(ent)
		end
	end
	for ent in pairs(self.cache) do
		local pos = ent:GetPosition()
		if not IsEntityAlive(ent) or distsq(pos.x, pos.z, x, z) > self.range * self.range then
			self:OnEntLeave(ent)
		end
		if self.cache[ent] and not self.canbesleep(ent) then
			self:AddMobSleep(ent)
		end
	end
end

-- this will prevent boarrior and boarilla from sleeping instantly after you fossilize
-- them inside of a heal if they were previously asleep
-- this also fixes a bug where they would not sleep again after being awakened with fossilization
function IceyHealAura:OnUnfossilize(ent)
	if self.current_time - ent.components.sleeper.lasttransitiontime < self.sleep_interrupt_cooldown then
		ent.components.sleeper:WakeUp() -- fixes a delay from brain activating late
		ent.components.combat.lastwasattackedtime = self.current_time
	end
end

-- Update cctime stat
function IceyHealAura:OnWakeUpStat(ent)
	if ent.stat_sleep_start and self.caster and TheWorld and TheWorld.components.stat_tracker then
		TheWorld.components.stat_tracker:AdjustStat("cctime", self.caster, self.current_time - ent.stat_sleep_start)
		ent.stat_sleep_start = nil
	end
end

function IceyHealAura:OnEntEnter(ent)
	ent:AddTag("_isinheals") --for targeting and shield behaviours
	if ent.components.colourfader then
		ent.components.colourfader:StartFade({0, 0.3, 0.1}, .35)
	end
	if self.canbesleep(ent) and IsDebuffable(ent) then
		local debuffable = ent.components.debuffable
		debuffable:AddDebuff("healingcircle_regenbuff", "healingcircle_regenbuff")
		debuffable.debuffs["healingcircle_regenbuff"].inst.heal_value = self.heal_rate * debuffable.debuffs["healingcircle_regenbuff"].inst.tick_rate
		debuffable.debuffs["healingcircle_regenbuff"].inst.caster = self.caster
		if debuffable:HasDebuff("scorpeon_dot") then
			debuffable:RemoveDebuff("scorpeon_dot")
		end
	elseif ent.components.sleeper and not self.canbesleep(ent) then
		if ent:HasTag("epic") then
			ent:ListenForEvent("unfossilize", self.onunfossilize)
		end
		ent:ListenForEvent("onwakeup", self.onwakeupstat)
	end
end

function IceyHealAura:OnEntLeave(ent)
	if not self.cache[ent] then
		print("ERROR: Tried to remove non-exsisting ent!")
		return
	end
	if ent:HasTag("_isinheals") then
		ent:RemoveTag("_isinheals")
	end
	if ent.components.colourfader then
		ent.components.colourfader:StartFade({0, 0, 0}, .35)
	end
	if IsDebuffable(ent) and ent.components.debuffable:HasDebuff("healingcircle_regenbuff") then
		ent.components.debuffable:RemoveDebuff("healingcircle_regenbuff")
	elseif not self.canbesleep(ent) then
		if ent:HasTag("epic") then
			ent:RemoveEventCallback("unfossilize", self.onunfossilize)
		end
		ent:RemoveEventCallback("onwakeup", self.onwakeupstat)
	end
	self.cache[ent] = nil
end

function IceyHealAura:Stop()
	self.inst:StopUpdatingComponent(self)
	for ent in pairs(self.cache) do
		self:OnEntLeave(ent)
		if not self.canbesleep(ent) then
			ent:DoTaskInTime(self.sleep_duration, function()
				if ent.components.sleeper then
					self:OnWakeUpStat(ent)
					ent.components.sleeper:WakeUp() -- might fix infinite sleep
				end
			end)
		end
	end
end

IceyHealAura.OnRemoveEntity = IceyHealAura.Stop
IceyHealAura.OnRemoveFromEntity = IceyHealAura.Stop

return IceyHealAura
