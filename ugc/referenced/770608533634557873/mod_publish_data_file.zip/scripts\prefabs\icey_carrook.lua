local clockwork_common = require "prefabs/clockwork_common"
local RuinsRespawner = require "prefabs/ruinsrespawner"

local assets =
{
	Asset("ANIM", "anim/rook.zip"),
    Asset("ANIM", "anim/icey_carrook.zip"),
	--Asset("ANIM", "anim/rook_build.zip"),
    --Asset("ANIM", "anim/rook_nightmare.zip"),
    Asset("SOUND", "sound/chess.fsb"),
    Asset("SCRIPT", "scripts/prefabs/clockwork_common.lua"),
    Asset("SCRIPT", "scripts/prefabs/ruinsrespawner.lua"),
}

local prefabs =
{
    "gears",
    "collapse_small",
}

local prefabs_nightmare =
{
    "gears",
    "thulecite_pieces",
    "nightmarefuel",
    "collapse_small",
    "rook_nightmare_ruinsrespawner_inst",
}

local brain = require "brains/rookbrain"

SetSharedLootTable('icey_carrook',
{
    --{'gears',  1.0},
    --{'gears',  1.0},
})

local function ShouldSleep(inst)
    return not inst.IsOn
end

local function ShouldWake(inst)
    return inst.IsOn
end

local function ClearRecentlyCharged(inst, other)
    inst.recentlycharged[other] = nil
end

local function onothercollide(inst, other)
    if not other:IsValid() or inst.recentlycharged[other] then
        return
    elseif other:HasTag("smashable") and other.components.health ~= nil then
        --other.Physics:SetCollides(false)
        other.components.health:Kill()
    elseif other.components.workable ~= nil
        and other.components.workable:CanBeWorked()
        and other.components.workable.action ~= ACTIONS.NET then
        SpawnPrefab("collapse_small").Transform:SetPosition(other.Transform:GetWorldPosition())
        other.components.workable:Destroy(inst)
        if other:IsValid() and other.components.workable ~= nil and other.components.workable:CanBeWorked() then
            inst.recentlycharged[other] = true
            inst:DoTaskInTime(1, ClearRecentlyCharged, other)
        end
    elseif other.components.health ~= nil and not other.components.health:IsDead() then
        inst.recentlycharged[other] = true
        inst:DoTaskInTime(1, ClearRecentlyCharged, other)
        inst.SoundEmitter:PlaySound("dontstarve/creatures/rook/explo")
        inst.components.combat:DoAttack(other, inst.weapon)
    end
	inst:PushEvent("powertrans",{former = inst,power = -5})
end

local function oncollide(inst, other)
    if not (other ~= nil and other:IsValid() and inst:IsValid())
        or inst.recentlycharged[other]
        or other:HasTag("incar")
		or other:HasTag("companion")
		or other:HasTag("icey_power_building")
		--or not inst.sg.HasStateTag("running")
        or Vector3(inst.Physics:GetVelocity()):LengthSq() < 42 
		then
        return
    end
    ShakeAllCameras(CAMERASHAKE.SIDE, .5, .05, .1, inst, 40)
    inst:DoTaskInTime(2 * FRAMES, onothercollide, other)
end

local function CreateWeapon(inst)
    local weapon = CreateEntity()
    --[[Non-networked entity]]
    weapon.entity:AddTransform()
    weapon:AddComponent("weapon")
    weapon.components.weapon:SetDamage(75)
    weapon.components.weapon:SetRange(2)
    weapon:AddComponent("inventoryitem")
    weapon.persists = false
    weapon.components.inventoryitem:SetOnDroppedFn(weapon.Remove)
    weapon:AddComponent("equippable")
    inst.components.inventory:GiveItem(weapon)
    inst.weapon = weapon
end


local function GetPlayerNum(inst)
	local count = 0
	for k,v in pairs(inst.players) do 
		count = count + 1
	end
	return count 
end 

local function CanGetInCar(inst,player)
	return inst and player and inst:IsValid() and player:IsValid() and inst.IsOn
		and math.sqrt(player:GetDistanceSqToInst(inst)) <= 3
		and inst.components.health and player.components.health and 
		not inst.components.health:IsDead() and not player.components.health:IsDead() and not player:HasTag("playerghost")
		and not player:HasTag("incar") and GetPlayerNum(inst) < 5
end 

local function IsMyRider(inst,player)
	for k,v in pairs(inst.players) do 
		if v == player and player:HasTag("incar") then 
			return true
		end
	end
	return false
end 

local function GetDriver(inst)
	for k,v in pairs(inst.players) do 
		if v and v:IsValid() and v:HasTag("cardriver") then 
			return v
		end
	end
	return nil 
end 



local onplayerdeath


local function OnPlayerIn(inst,player)
	table.insert(inst.players,player)
	player:AddTag("incar")
	--player.components.health:SetInvincible(true)
	
	player:Hide()
    player.DynamicShadow:Enable(false)
	player.Physics:ClearCollisionMask()
	player.Physics:CollidesWith(COLLISION.WORLD)
	
	player.icey_car = inst 
	player.TrackCarTask = player:DoPeriodicTask(0.1,function()
		local x,y,z = inst:GetPosition():Get()
		player.Transform:SetPosition(x,y,z)
		--player:Hide()
	end)
	--ThePlayer.components.playercontroller.locomotor = c_findnext("dead_cell_head_marker").components.locomotor
	if not GetDriver(inst) then 
		player.components.playercontroller.locomotor = inst.components.locomotor
		player:AddTag("cardriver")
		if player.player_classified.Icey_EnableMovementPrediction then 
			print("Icey_EnableMovementPrediction set false")
			player.player_classified.Icey_EnableMovementPrediction:set(false)
		end
		inst.sg:GoToState("taunt")
	end 
	inst.Light:Enable(true)
	inst:ListenForEvent("death",onplayerdeath,player)
end 

local function OnPlayerOut(inst,player)
	for k,v in pairs(inst.players) do 
		if v == player then 
			inst:DoTaskInTime(0,function()
				table.remove(inst.players,k)
			end)
		end
	end 
	if player:HasTag("cardriver") then 
		for k,v in pairs(inst.players) do 
			if IsMyRider(inst,v) and v.components.playercontroller then 
				v.components.playercontroller.locomotor = inst.components.locomotor
				v:AddTag("cardriver")
				if v.player_classified.Icey_EnableMovementPrediction then 
					print("Icey_EnableMovementPrediction set false")
					v.player_classified.Icey_EnableMovementPrediction:set(false)
				end
				break
			end
		end 
	end 
	player:RemoveTag("incar")
	player:RemoveTag("cardriver")
	--player.components.health:SetInvincible(false)
	
	player:Show()
    player.DynamicShadow:Enable(true)
	ChangeToCharacterPhysics(player)
	
	player.icey_car = nil 
	if player.TrackCarTask then 
		player.TrackCarTask:Cancel()
		player.TrackCarTask = nil 
	end
	player.Transform:SetPosition(inst:GetPosition():Get())
	if player.components.playercontroller then 
		player.components.playercontroller.locomotor = player.components.locomotor
	end 
	if player.player_classified.Icey_EnableMovementPrediction then 
		print("Icey_EnableMovementPrediction set true")
		player.player_classified.Icey_EnableMovementPrediction:set(true)
	end
	inst:RemoveEventCallback("death",onplayerdeath,player)
	print("OnPlayerOut",player)
end 

onplayerdeath = function(player)
	OnPlayerOut(player.icey_car,player)
end 

local function descriptionfn(inst,player)
	if not inst.IsOn then 
		return "它需要充电了！"
	end 
	if CanGetInCar(inst,player) then 
		OnPlayerIn(inst,player)
		return "上车！"
	elseif IsMyRider(inst,player) then 
		OnPlayerOut(inst,player)
		return "下车！"
	else 
		return "我还没上车呢！"
	end
	
end 

local function ReleaseAll(inst)
	print(inst,"ReleaseAll!")
	for k,v in pairs(inst.players) do 
		print("try to release",v)
		if v  and v:HasTag("incar") then 
			OnPlayerOut(inst,v)
		end
	end
end 

local function CheckList(inst)
	for k,v in pairs(inst.players) do 
		print("CheckList:",v)
	end
end 

local function ondeath(inst)
	ReleaseAll(inst)
end 




local function turnon(inst)
	inst.Light:Enable(true)
	inst.components.sleeper:WakeUp()
end 

local function turnoff(inst)
	ReleaseAll(inst)
	inst.Light:Enable(false)
	inst.components.sleeper:GoToSleep()
end 

local STRING_NAME = STRINGS.NAMES[string.upper("icey_carrook")]

local function CheckPower(inst,data)
	local power = data.power
	inst.building_power = inst.building_power + power
	inst.building_power = math.max(0,inst.building_power)
	inst.building_power = math.min(inst.max_building_power,inst.building_power)
	if inst.building_power > 0 and not inst.IsOn then 
		print(inst,"Turn on!")
        turnon(inst)
		inst.IsOn = true
    elseif inst.building_power <= 0 and inst.IsOn then
		print(inst,"Turn off!")
        turnoff(inst)
		inst.IsOn = false
    end 
	if inst.components.named then 
		local nowPower = math.floor(inst.building_power)
		local maxPower = inst.max_building_power
		local str = ((TUNING.ICEY_LANGUAGE == "chinese" and "\n电能:") or (TUNING.ICEY_LANGUAGE == "english" and "\nPower:"))
			..nowPower.."/"..maxPower
		if nowPower <= 0 then 
			str = (TUNING.ICEY_LANGUAGE == "chinese" and "(电能不足)") or (TUNING.ICEY_LANGUAGE == "english" and "(Low Power)")
		end
		inst.components.named:SetName(tostring(STRING_NAME)..str)
	end
	inst:AddTag("companion")
end 

local function oneat(inst,food)
	if food and food:IsValid() then 
		local gain_power = (food.components.edible:GetHunger() + food.components.edible:GetSanity()) * 4 
		inst:PushEvent("powertrans",{former = inst,power = gain_power})
	end 
end 

local function ShouldAcceptItem(inst, item)
   return item and item:IsValid() and item.components.edible and inst.components.eater:CanEat(item)
end

local function OnGetItemFromPlayer(inst, giver, item)
	if item and item:IsValid() and inst.components.eater:CanEat(item) then 
		inst.components.eater:Eat(item)
	end
end

local function OnRefuseItem(inst, item)
	if inst.sg then 
		if not inst.components.sleeper:IsAsleep() then 
			inst.sg:GoToState("taunt")
		else
			inst.components.sleeper:WakeUp()
		end 
	end
end

local function onsave(inst, data)
	data.building_power  = inst.building_power
end

local function onload(inst, data)
	if data ~= nil and data.building_power  then 
		inst.building_power = data.building_power
		CheckPower(inst,{fromer = inst,power = 0})
	end
end

local function common_fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddDynamicShadow()
	inst.entity:AddLight()
    inst.entity:AddNetwork()

    MakeCharacterPhysics(inst, 50, 1.5)

    inst.DynamicShadow:SetSize(3, 1.25)
    inst.Transform:SetFourFaced()
    inst.Transform:SetScale(0.66, 0.66, 0.66)

    inst.AnimState:SetBank("rook")
    inst.AnimState:SetBuild("icey_carrook")

	inst:AddTag("_named")
    inst:AddTag("chess")
	inst:AddTag("companion")
    inst:AddTag("rook")
	inst:AddTag("icey_carrook")
	inst:AddTag("icey_power_use")
	inst:AddTag("icey_power_building")

	inst.Light:SetIntensity(0.5)
	inst.Light:SetRadius(1.5)
	inst.Light:SetFalloff(0.5)
    inst.Light:SetColour(255 / 255, 255 / 255, 236 / 255)
    inst.Light:Enable(false)
	
	inst.recentlycharged = {}
	inst.players = {}
	
	inst.OnPlayerIn = OnPlayerIn
	inst.OnPlayerOut = OnPlayerOut
	inst.CanGetInCar = CanGetInCar
	inst.IsMyRider  = IsMyRider
	inst.OnClickFn = descriptionfn
	inst.CheckList = CheckList

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.IsOn = true
	inst.building_power = 0
	inst.max_building_power = 3000
	

    inst.kind = ""
    inst.soundpath = "dontstarve/creatures/rook/"
    inst.effortsound = "dontstarve/creatures/rook/steam"
	inst.OnSave = onsave
	inst.OnLoad = onload

    inst.Physics:SetCollisionCallback(oncollide)
	
	inst:AddComponent("named")

    inst:AddComponent("lootdropper")
	inst.components.lootdropper:SetChanceLootTable('icey_carrook')

    inst:AddComponent("locomotor")
    inst.components.locomotor.walkspeed = TUNING.ROOK_WALK_SPEED * 1.25
    inst.components.locomotor.runspeed =  TUNING.ROOK_RUN_SPEED * 1.25

    inst:SetStateGraph("SGcarrook")

    inst:AddComponent("sleeper")
    inst.components.sleeper:SetWakeTest(ShouldWake)
    inst.components.sleeper:SetSleepTest(ShouldSleep)
    inst.components.sleeper:SetResistance(3)
	
	inst:AddComponent("eater")
	inst.components.eater:SetOnEatFn(oneat)
	inst.components.eater:SetDiet({FOODTYPE.ICEY_BATTERY, FOODTYPE.ICEY_BATTERY})
	
	inst:AddComponent("trader")
    inst.components.trader:SetAcceptTest(ShouldAcceptItem)
    inst.components.trader.onaccept = OnGetItemFromPlayer
    inst.components.trader.onrefuse = OnRefuseItem
    inst.components.trader.deleteitemonaccept = false
	
	local old_AbleToAccept = inst.components.trader.AbleToAccept
	inst.components.trader.AbleToAccept = function(self,item,giver,...)
		if self.inst.components.sleeper and self.inst.components.sleeper:IsAsleep() and not inst.IsOn then 
			return true 
		end
		return old_AbleToAccept(self,item,giver,...)
	end 

    inst:AddComponent("health")
    inst:AddComponent("combat")
    inst.components.combat.hiteffectsymbol = "spring"


    inst.components.health:SetMaxHealth(TUNING.ROOK_HEALTH)
    inst.components.combat:SetDefaultDamage(TUNING.ROOK_DAMAGE)
    inst.components.combat:SetAttackPeriod(0.1)
    --inst.components.combat.playerdamagepercent = 2

    inst:AddComponent("follower")

    inst:AddComponent("inventory")

    inst:AddComponent("inspectable")
	inst.components.inspectable.descriptionfn = descriptionfn
	
    --MakeHauntablePanic(inst)
	

	

    MakeMediumBurnableCharacter(inst, "spring")
    MakeMediumFreezableCharacter(inst, "spring")

    CreateWeapon(inst)
	inst:PushEvent("powertrans",{former = inst,power = 0})
	inst:DoPeriodicTask(1,function()
		inst:PushEvent("powertrans",{former = inst,power = -10})
		if inst.building_power > 10 and inst.components.health:IsHurt() then 
			inst:PushEvent("powertrans",{former = inst,power = -10})
			inst.components.health:DoDelta(5)
		end
	end)
	inst:ListenForEvent("powertrans",CheckPower)
	inst:ListenForEvent("death",ondeath)
	inst:ListenForEvent("onremove",ondeath)
    return inst
end

return Prefab("icey_carrook", common_fn, assets, prefabs),
MakePlacer("icey_carrook_placer", "rook", "icey_carrook", "idle",nil,nil,nil,0.66)
