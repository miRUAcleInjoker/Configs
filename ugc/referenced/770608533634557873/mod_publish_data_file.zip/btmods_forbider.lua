GLOBAL.TUNING.BT_MOD_ENABLED = false 

local BtModsId = {
	STEAM = {
		"workshop-1200745268",--快速采集
		"workshop-850518166", --1秒5捡
		"workshop-785295023", --超级墙DST
		"workshop-463621557", --999 Item Stack叠加数量999
		"workshop-1540284567",--More Stack size
		"workshop-831523966", --999 Stack Size
		"workshop-831657598", --Stacks Size
		"workshop-372033333", --63 Stacks
		"workshop-1603734696", --Stack size Changer
		"workshop-398109522",  --Major Stack size
		"workshop-374550642", --Increased Stack size
		"workshop-661253977", --灵魂携带物品 - Don't Drop Everything
		"workshop-1499637833", --Don't Drop Everything Tweaked
		"workshop-569043634", --Campfire Respawn
		"workshop-1314390361",--Fire resurrection
		"workshop-676297854",--Fire resurrection
		"workshop-1113081094", --合集
		"workshop-786556008", --45 Inventory Slots
		"workshop-604761020", --矿石耐挖
		"workshop-626893945", --自定义修改
		"workshop-632338441", --自定义修改2改
		"workshop-462372013", --Always fresh
		"workshop-1247040097", --西米冰箱（保鲜，腐烂缓慢，反鲜）Ximi icebox (preservative, slow rotting, anti fresh)
		"workshop-679278004", --Large Magic Icebox
		"workshop-1242907291", --Icebox Perish Settings (Global Update)
		
		"workshop-1084023218", --DST综合成就系统 V2
		"workshop-1069888871", --DST综合成就系统
		"workshop-1226903961", --DST A3.2.7 (杀戮成就？)
		
		"workshop-1095971442", --cy_store
		
	},
	WG = {
		"workshop-2199027653598513768",--快速工作
		"workshop-2199027653598517474",--快速制作快速采收等
		"workshop-2199027653598513730",--快速烹饪
		"workshop-2199027653598512195",--快速砍树
		"workshop-2199027653598519491",--快速采集植物
		"workshop-2199027653598512554",--一键砍树，挖矿
		"workshop-100010039",--超级墙DST(停更)
		"workshop-2199027653598512823",--超级墙DST
		"workshop-2199027653598512231",--装备工具等可叠加
		"workshop-100010063",--叠加上限99
		"workshop-2199027653598517475",--农作物秒长加五倍收获
		"workshop-100010018",--死亡不掉落
		"workshop-2199027653598513751",--篝火复活（新）
		"workshop-2199027653598520219",--篝火火堆复活 中文版
		"workshop-100010043",--复活火堆
		"workshop-2199027653598518180",--加强背包
		"workshop-2199027653598511307",--45格背包
		"workshop-2199027653598513845",--45格-物品栏可放背包
		"workshop-2199027653598516877",--挖矿掉落宝石
		"workshop-2199027653598514225",--持久挖矿升级版
		"workshop-2199027653598516235",--DST持久挖矿
		"workshop-2199027653598517339",--持久挖矿 升级版
		"workshop-100010020",--持久挖矿
		"workshop-100010071",--保鲜背包
		"workshop-100010033",--永不腐烂的冰箱
		"workshop-2199027653598515009",--冰箱保反鲜（可设置）
		
		"workshop-2199027653598515294",--DST综合成就系统 V2
		"workshop-2199027653598516722",--DST 成就系统 V3.0.6
		"workshop-2199027653598516759",--【DST】成就系统V3.0.7
		"workshop-2199027653598516914",--DST成就系统V3.0.9
		"workshop-2199027653598517318",--成就系统DST A3.1.2
		
		"workshop-2199027653598519701",--Cy的黑店
		"workshop-2199027653598515413",--Cy的黑店 完善版 全新界面
		
	},
	
	ALL = {} 
}

for k,v in pairs(BtModsId.STEAM) do 
	table.insert(BtModsId.ALL,v)
end 

for k,v in pairs(BtModsId.WG) do 
	table.insert(BtModsId.ALL,v)
end 

local BtModsName = {
	--"超级墙",
	--"快速采集",
	--"篝火复活",
}

local ERRORSTRING = {
	CHINESE = {
		TIP = "\n[艾希Mods提示您]:\n由于侦测到服务器开启了变态mod,所以本mod已经自行崩溃.\n",
		TIP2 = "若您想要坚持玩下去,请关闭艾希Mods的DLC,或者关闭以下变态mods:\n",
		MODINFO = "Mod名称: %s   Mod文件夹: %s \n",
		ASKQQ = "\n如有其他疑问,请咨询作者QQ:1426163582\n",
		GOODBYE = "非常感谢您的配合与理解,我祝您身体健康,再见!\n",
	},
	ENGLISH = {
		TIP = "\n[Icey Mods Warning]:\nIt seems you have enabled some mod(s) which are too OP,So Icey Mods has crashed itself.\n",
		TIP2 = "If you want to continue playing,Please disable Icey Mod's DLC or disable the following OP mods:\n",
		MODINFO = "Mod Name: %s   Mod Path Name: %s \n",
		ASKQQ = "\nIf you have any questions,Please contact me By QQ:1426163582\n",
		GOODBYE = "Thank you for your understanding and cooperation,I hope you can enjoy your DST,Good Bye!\n",
	},
}

local function GetPlayGround()
	return (PLATFORM and PLATFORM == "WIN32_STEAM" and "STEAM") 
	or (TheSim.RAILGetPlatform and (TheSim:RAILGetPlatform() == "TGP" or TheSim:RAILGetPlatform() == "WG") and "WG")
	or "ALL"
end 
	
local function CheckModName(mod_name)
	local playground = GetPlayGround()
	for k,v in pairs(BtModsId[playground]) do 
		if v == mod_name then 
			return true 
		end
	end
end 

local function CheckModinfoName(modinfo_name)
	if  modinfo_name then 
		for k,v in pairs(BtModsName) do 
			if v == modinfo_name then 
				return true 
			end
		end
	end 

end 

local function IsBtMod(mod_name,modinfo_name)
	return CheckModName(mod_name) or CheckModinfoName(modinfo_name)
end 

local function ExecuteBtMods(senderror)
	print("[btmods_forbider] Start Check Mods")
	local EnabledBtMods = {}

	--mod_name是存放mod的文件夹名字，例如 workshop-1200745268
	--modinfo是mod的具体信息，具体引用有 modinfo.name,modinfo.version,modinfo.api_version
	for k, mod_name in ipairs(ModManager:GetEnabledServerModNames()) do 
		local modinfo = KnownModIndex:GetModInfo(mod_name)
		local modinfo_name = modinfo and modinfo.name
		
		--print("检查Mods",mod_name,modinfo)
		if IsBtMod(mod_name,modinfo_name) then 
			table.insert(EnabledBtMods,{mod_name = mod_name,modinfo_name = modinfo_name})
		end 
	end
	
	local LANGUAGE = string.upper(TUNING.ICEY_LANGUAGE)

	if #EnabledBtMods > 0 then 
		TUNING.BT_MOD_ENABLED = true 
		if senderror then 
			local errormessage = ERRORSTRING[LANGUAGE].TIP
			errormessage = errormessage..ERRORSTRING[LANGUAGE].TIP2
			
			for k,v in pairs(EnabledBtMods) do 
				local mod_name = v.mod_name
				local modinfo_name = v.modinfo_name 
				local modstring = string.format(ERRORSTRING[LANGUAGE].MODINFO,modinfo_name,mod_name)
				
				errormessage = errormessage..modstring
			end
			
			
			errormessage = errormessage..ERRORSTRING[LANGUAGE].ASKQQ
			errormessage = errormessage..ERRORSTRING[LANGUAGE].GOODBYE
			
			assert(nil,errormessage)
		else
		
		end 
	end 
	print("[btmods_forbider] Check Mods Over")
end 

local function ShouldSendError()
	--开启了艾希的DLC后严令禁止btmods
	return TUNING.ICEY_DLCS ~= "none"
end 

--ExecuteBtMods(ShouldSendError())
AddPlayerPostInit(function(inst)
	inst:DoTaskInTime(1,function()
		ExecuteBtMods(ShouldSendError())
	end)
	
	if not TheWorld.ismastersim then
		return inst
	end
end)
	
	
	
	
	
	
	
	