local icey_preparedfoods = require("preparedfoods_icey")

local function MakeFood(data)--MakeFood(name, str,scale,foodtype, health, hunger, sanity,shield,perishtime,description,oneatfn,extrafn) 
	print("MakeFood:",data)
	for k,v in pairs(data) do 
		print(k,v)
	end 
	print("MakeFoodPrintFinish")
	local assets = { 
		Asset("ANIM", "anim/cook_pot_food_icey.zip"),     
		Asset("ATLAS", "images/inventoryimages/"..data.name..".xml"), 
	}  
	local prefabs =  { "spoiled_food", }  
	local function fn(Sim) 
		local inst = CreateEntity() 
		inst.entity:AddTransform() 
		inst.entity:AddAnimState() 
		--inst.entity:AddDynamicShadow() 
		
		--inst.DynamicShadow:SetSize(1.3, .6) 
		
		if TheSim:GetGameID() =="DST" then 
			inst.entity:AddNetwork() 
		end  
		
		MakeInventoryPhysics(inst) 
		MakeSmallBurnable(inst) 
		MakeSmallPropagator(inst)  
		
		inst.AnimState:SetBank("cook_pot_food_icey") 
		inst.AnimState:SetBuild("cook_pot_food_icey") 
		inst.AnimState:PlayAnimation(data.name,true)  
		inst.Transform:SetScale(data.scale,data.scale,data.scale)
		
		inst:AddTag("preparedfood") 
		inst:AddTag("edible_"..data.foodtype)
		 
		if TheSim:GetGameID()=="DST" then 
			if not TheWorld.ismastersim then 
				return inst 
			end  
			inst.entity:SetPristine() 
		end 
		
		inst:AddComponent("edible") 
		inst.components.edible.foodtype = data.foodtype or FOODTYPE.GENERIC
		inst.components.edible.healthvalue = data.health or 0
		inst.components.edible.hungervalue = data.hunger or 0
		inst.components.edible.sanityvalue = data.sanity or 0
        inst.components.edible.temperaturedelta = data.temperature or 0
        inst.components.edible.temperatureduration = data.temperatureduration or 0
        inst.components.edible.nochill = data.nochill or nil
        inst.components.edible.spice = data.spice
		inst.components.edible:SetOnEatenFn(data.oneatfn)
		
		
		inst:AddComponent("inspectable") 
		inst.components.inspectable:SetDescription(data.description or "")
		
		inst:AddComponent("bait")
		inst:AddComponent("tradable")  
		
		inst:AddComponent("inventoryitem") 
		inst.components.inventoryitem.atlasname = "images/inventoryimages/"..data.name..".xml"  
		
		inst:AddComponent("stackable") 
		inst.components.stackable.maxsize = TUNING.STACK_SIZE_SMALLITEM  
		
		if data.perishtime ~= nil then 
			inst:AddComponent("perishable") 
			inst.components.perishable:SetPerishTime(data.perishtime) 
			inst.components.perishable:StartPerishing() 
			inst.components.perishable.onperishreplacement = "spoiled_food" 
		end  
		
		inst:ListenForEvent("oneaten",function(self,data_oneaten)
			local eater = data_oneaten.eater
			if eater.components.icey_shield and data.shield then 
				eater.components.icey_shield:DoDelta(data.shield)
			end
		end)
		
		if data.extrafn then 
			data.extrafn(inst) 
		end
		
		return inst 
	end  
	STRINGS.NAMES[string.upper(data.name)] = data.str 
	return Prefab(data.name, fn, assets, prefabs) 
end 

local foods = {}
for k,v in pairs(icey_preparedfoods) do 
	table.insert(foods,MakeFood(v))
	if v.othercookpots then 
		for _,cookpot in pairs(v.othercookpots) do 
			AddCookerRecipe(cookpot,v)
		end
	else
		AddCookerRecipe("icey_cookpot",v)
	end
	
end

return unpack(foods)

