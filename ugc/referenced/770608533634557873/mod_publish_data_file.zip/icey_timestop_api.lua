local cc = resolvefilepath('images/colour_cubes/icey_theworld_cc.tex')
local TIMESTOP_CC = {day = cc, dusk = cc, night = cc, full_moon = cc,}

local function playervisionpostinit(self)
    local old_add = self.SetCustomCCTable
    function self:SetCustomCCTable(t) 
		if self.inst:HasTag("time_stopped") then
			return 
		end
        old_add(self, t)
    end

    function self:StartIceyTimeStopCC()
        self.old_cc_memory = self.overridecctable
        self.overridecctable = TIMESTOP_CC
        self:UpdateCCTable()
    end

    function self:StopIceyTimeStopCC()
        self.overridecctable = self.old_cc_memory
        self:UpdateCCTable()
    end
end
AddComponentPostInit('playervision', playervisionpostinit)



AddPrefabPostInit("player_classified",function(inst)
	inst._timestop_cc_enabled = net_bool(inst.GUID, 'inst._timestop_cc_enabled','timestop_cc_enabled_dirty')
	inst._timestop_cc_enabled:set(false)
	
	inst:ListenForEvent("timestop_cc_enabled_dirty",function()
		local player = inst._parent
		if player then 
			if inst._timestop_cc_enabled:value() then 
				player.components.playervision:StartIceyTimeStopCC()
			else
				player.components.playervision:StopIceyTimeStopCC()
			end
		end
	end)
end)

--[[function ErodeAway(inst, erode_time)
    local time_to_erode = erode_time or 1
    local tick_time = TheSim:GetTickTime()

    if inst.DynamicShadow ~= nil then
        inst.DynamicShadow:Enable(false)
    end

    inst:StartThread(function()
        local ticks = 0
        while ticks * tick_time < time_to_erode do
            local erode_amount = ticks * tick_time / time_to_erode
            inst.AnimState:SetErosionParams(erode_amount, 0.1, 1.0)
            ticks = ticks + 1
            Yield()
        end
        inst:Remove()
    end)
end--]]

--[[local old_ErodeAway = GLOBAL.ErodeAway
GLOBAL.ErodeAway = function(inst,erode_time,...)
	if inst:HasTag("time_stopped") then 

	else
		return old_ErodeAway(inst,erode_time,...)
	end 
end --]]
