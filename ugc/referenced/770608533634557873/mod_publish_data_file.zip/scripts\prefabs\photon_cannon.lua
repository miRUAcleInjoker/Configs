require "prefabutil"

local assets =
{
    Asset("ANIM", "anim/photon_cannon.zip"),
    Asset("ANIM", "anim/photon_cannon_object.zip"),
	--Asset("MINIMAP_IMAGE", "photon_cannon"),
	Asset("IMAGE","images/inventoryimages/photon_cannon_item.tex"),
	Asset("ATLAS","images/inventoryimages/photon_cannon_item.xml")
}

local prefabs =
{
    "eye_charge",
    "eyeturret_base",
}

local brain = require "brains/eyeturretbrain"

local MAX_LIGHT_FRAME = 24

local function OnUpdateLight(inst, dframes)
    local frame = inst._lightframe:value() + dframes
    if frame >= MAX_LIGHT_FRAME then
        inst._lightframe:set_local(MAX_LIGHT_FRAME)
        inst._lighttask:Cancel()
        inst._lighttask = nil
    else
        inst._lightframe:set_local(frame)
    end

    if frame <= 20 then
        local k = frame / 20
        --radius:    0   -> 3.5
        --intensity: .65 -> .9
        --falloff:   .7  -> .9
        inst.Light:SetRadius(3.5 * k)
        inst.Light:SetIntensity(.9 * k + .65 * (1 - k))
        inst.Light:SetFalloff(.9 * k + .7 * (1 - k))
    else
        local k = (frame - 20) / (MAX_LIGHT_FRAME - 20)
        --radius:    3.5 -> 0
        --intensity: .9  -> .65
        --falloff:   .9  -> .7
        inst.Light:SetRadius(3.5 * (1 - k))
        inst.Light:SetIntensity(.65 * k + .9 * (1 - k))
        inst.Light:SetFalloff(.7 * k + .9 * (1 - k))
    end

    if TheWorld.ismastersim then
        inst.Light:Enable(frame < MAX_LIGHT_FRAME)
    end
end

local function OnLightDirty(inst)
    if inst._lighttask == nil then
        inst._lighttask = inst:DoPeriodicTask(FRAMES, OnUpdateLight, nil, 1)
    end
    OnUpdateLight(inst, 0)
end

local function triggerlight(inst)
    inst._lightframe:set(0)
    OnLightDirty(inst)
end

local function retargetfn(inst)
    local playertargets = {}
    for i, v in ipairs(AllPlayers) do
        if v.components.combat.target ~= nil then
            playertargets[v.components.combat.target] = true
        end
    end

    return FindEntity(inst, 20,
        function(guy)
            return inst.components.combat:CanTarget(guy)
                and (playertargets[guy] or
                    (guy.components.combat.target ~= nil))
        end,
        { "_combat"}, --see entityreplica.lua
        { "INLIMBO", "player","companion"}
    )
end

local function shouldKeepTarget(inst, target)
    return target ~= nil
        and target:IsValid()
        and target.components.health ~= nil
        and not target.components.health:IsDead()
        and inst:IsNear(target, 20)
		and not target:HasTag("companion")
end

local function ShareTargetFn(dude)
    return dude:HasTag("eyeturret")
end

local function OnHitOther(inst,data)
	inst:PushEvent("powertrans",{former = inst,power = -10})
end 

local function OnAttacked(inst, data)
    local attacker = data ~= nil and data.attacker or nil
    if attacker ~= nil and not attacker:HasTag("player") then
        inst.components.combat:SetTarget(attacker)
        inst.components.combat:ShareTarget(attacker, 15, ShareTargetFn, 10)
    end
end

local function OnKilled(inst)----------------------爆炸的一堆特效
	--inst.Transform:SetMultColor()
	local x,y,z = inst:GetPosition():Get()
	local bomb = SpawnPrefab("explode_small")
	local crackle = SpawnPrefab("hammer_mjolnir_crackle")
	local cracklebase = SpawnPrefab("hammer_mjolnir_cracklebase")
	local cracklehit = SpawnPrefab("hammer_mjolnir_cracklehit")
	local cracklehitfx = SpawnPrefab("cracklehitfx")
	
	bomb.Transform:SetScale(3,3,3)

	bomb.Transform:SetPosition(x,y,z)
	crackle.Transform:SetPosition(x,y,z)
	cracklebase.Transform:SetPosition(x,y,z)
	cracklehit.Transform:SetPosition(x,y,z)
	cracklehitfx.Transform:SetPosition(x,y,z)
	
	crackle.AnimState:SetMultColour(73/255, 240/255, 235/255, 0.9)
	cracklebase.AnimState:SetMultColour(73/255, 240/255, 235/255, 1)
	cracklehit.AnimState:SetMultColour(73/255, 240/255, 235/255, 1)
	cracklehitfx.AnimState:SetMultColour(73/255, 240/255, 235/255, 1)
	
	crackle:ListenForEvent("animover", function(inst) inst:Remove() end )
	cracklebase:ListenForEvent("animover", function(inst) inst:Remove() end )
	cracklehit:ListenForEvent("animover", function(inst) inst:Remove() end )
	cracklehitfx:ListenForEvent("animover", function(inst) inst:Remove() end )
	
	inst:Hide()-------------------只是隐藏贴图，以免Remove()造成意外的报错(不知为何水晶塔的死亡动画不能被编译)
	
end

local function EquipWeapon(inst)
    if inst.components.inventory and not inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS) then
        local weapon = CreateEntity()
        --[[Non-networked entity]]
        weapon.entity:AddTransform()
        weapon:AddComponent("weapon")
        weapon.components.weapon:SetDamage(inst.components.combat.defaultdamage)
        weapon.components.weapon:SetRange(inst.components.combat.attackrange, inst.components.combat.attackrange+4)
        weapon.components.weapon:SetProjectile("bishop_charge")
        weapon:AddComponent("inventoryitem")
        weapon.persists = false
        weapon.components.inventoryitem:SetOnDroppedFn(weapon.Remove)
        weapon:AddComponent("equippable")
        
        inst.components.inventory:Equip(weapon)
    end
end

local function ondeploy(inst, pt, deployer)
    local turret = SpawnPrefab("photon_cannon")
    if turret ~= nil then
        turret.Physics:SetCollides(false)
        turret.Physics:Teleport(pt.x, 0, pt.z)
        turret.Physics:SetCollides(true)
        turret:syncanim("place")
        turret:syncanimpush("idle_loop", true)
        turret.SoundEmitter:PlaySound("dontstarve/common/place_structure_stone")
        inst:Remove()
    end
end

local function syncanim(inst, animname, loop)
    inst.AnimState:PlayAnimation(animname, loop)
    inst.base.AnimState:PlayAnimation(animname, loop)
end

local function syncanimpush(inst, animname, loop)
    inst.AnimState:PushAnimation(animname, loop)
    inst.base.AnimState:PushAnimation(animname, loop)
end

local function itemfn()
    local inst = CreateEntity()
   
    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()

    MakeInventoryPhysics(inst)

    inst.AnimState:SetBank("photon_cannon_object")
    inst.AnimState:SetBuild("photon_cannon_object")
    inst.AnimState:PlayAnimation("idle")

    inst:AddTag("eyeturret")

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst:AddComponent("inspectable")
    inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "photon_cannon_item"
	inst.components.inventoryitem.atlasname = "images/inventoryimages/photon_cannon_item.xml"

    MakeHauntableLaunch(inst)

    --Tag to make proper sound effects play on hit.
    inst:AddTag("largecreature")

    inst:AddComponent("deployable")
    inst.components.deployable.ondeploy = ondeploy
    inst.components.deployable:SetDeployMode(DEPLOYMODE.WALL)
    --inst.components.deployable:SetDeploySpacing(DEPLOYSPACING.NONE)
    
    return inst
end
-----------------------------------------------------------------------

local function turnon(inst)
	inst:DoTaskInTime(0,function()
		if inst.brain then 
			inst.brain:Start()
		end 
		inst.Light:Enable(true)
	end )
end 

local function turnoff(inst)
	inst:DoTaskInTime(0,function()
		if inst.brain then 
			inst.brain:Stop()
		end 
		inst.Light:Enable(false)
	end)
end 

local function CheckPower(inst,data)
	local power = data.power
	inst.building_power = inst.building_power + power
	inst.building_power = math.max(0,inst.building_power)
	inst.building_power = math.min(inst.max_building_power,inst.building_power)
	if inst.building_power > 0 and not inst.IsOn then 
		print(inst,"Turn on!")
		turnon(inst)
		inst.IsOn = true
	elseif inst.building_power <= 0 and inst.IsOn then
		print(inst,"Turn off!")
		turnoff(inst)
		inst.IsOn = false
	end 

end

local function OnSave(inst,data)
	data.building_power = inst.building_power
	--data.IsOn = inst.IsOn
end 

local function OnLoad(inst,data)
	if data then 
		if data.building_power then 
			inst.building_power = data.building_power
		end
		--[[if data.IsOn then 
			inst.IsOn = data.IsOn
		end--]]
		
	end
end 
-----------------------------------------------------------------------


local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddMiniMapEntity()
    inst.entity:AddLight()
    inst.entity:AddNetwork()

    MakeObstaclePhysics(inst, 1)

    inst.Transform:SetFourFaced()

    inst.MiniMapEntity:SetIcon("photon_cannon.png")

    inst:AddTag("eyeturret")
	inst:AddTag("icey_power_use")
	inst:AddTag("icey_power_building")
    inst:AddTag("companion")

    inst.AnimState:SetBank("photon_cannon")
    inst.AnimState:SetBuild("photon_cannon")
    inst.AnimState:PlayAnimation("idle_loop")
	
	--inst.AnimState:SetMultColour(0/255,125/255,204/255,1)

    inst.Light:SetRadius(0)
    inst.Light:SetIntensity(.65)
    inst.Light:SetFalloff(.7)
    inst.Light:SetColour(251/255, 234/255, 234/255)
    inst.Light:Enable(false)
    inst.Light:EnableClientModulation(true)

    inst._lightframe = net_smallbyte(inst.GUID, "eyeturret._lightframe", "lightdirty")
    inst._lighttask = nil

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        inst:ListenForEvent("lightdirty", OnLightDirty)

        return inst
    end
	
	inst.IsOn = true
	inst.building_power = 0
	inst.max_building_power = 500
	
    inst:AddComponent("inspectable")
	inst.components.inspectable.descriptionfn = function(inst,doer)
		return (inst.IsOn and "Boom~弹幕发动~" ) or "它需要充电了!"
	end

    inst.base = SpawnPrefab("photon_cannon_base")
    inst.base.entity:SetParent(inst.entity)

    inst.syncanim = syncanim
    inst.syncanimpush = syncanimpush

    inst:AddComponent("health")
    inst.components.health:SetMaxHealth(250)
    --inst.components.health:StartRegen(TUNING.EYETURRET_REGEN, 1)

    inst:AddComponent("combat")
    inst.components.combat:SetRange(TUNING.EYETURRET_RANGE)
    inst.components.combat:SetDefaultDamage(20)
    inst.components.combat:SetAttackPeriod(0)
    inst.components.combat:SetRetargetFunction(0, retargetfn)
    inst.components.combat:SetKeepTargetFunction(shouldKeepTarget)

    inst.triggerlight = triggerlight

    MakeLargeFreezableCharacter(inst)

    MakeHauntableFreeze(inst)

    inst:AddComponent("inventory")
    inst:DoTaskInTime(1, EquipWeapon)


   
    inst:AddComponent("lootdropper")

	inst:ListenForEvent("onhitother", OnHitOther)
    inst:ListenForEvent("attacked", OnAttacked)
	inst:ListenForEvent("death", OnKilled)
	inst:ListenForEvent("powertrans",CheckPower)
	
	
	inst:DoPeriodicTask(1,function()
		inst:PushEvent("powertrans",{former = inst,power = -10})
		if inst.components.health:IsHurt() and inst.building_power >= 10 then 
			inst:PushEvent("powertrans",{former = inst,power = -10})
			inst.components.health:DoDelta(10)
		end
	end)
	
    inst:SetStateGraph("SGeyeturret")
    inst:SetBrain(brain)
	
	inst.OnSave = OnSave
	inst.OnLoad = OnLoad

    return inst
end

local baseassets =
{
    Asset("ANIM", "anim/photon_cannon_base.zip"),
}

local function basefn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()

    inst.AnimState:SetBank("photon_cannon_base")
    inst.AnimState:SetBuild("photon_cannon_base")
    inst.AnimState:PlayAnimation("idle_loop")

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    return inst
end

return Prefab("photon_cannon", fn, assets, prefabs),
    Prefab("photon_cannon_item", itemfn, assets, prefabs),
    MakePlacer("photon_cannon_item_placer", "photon_cannon", "photon_cannon", "idle_place"),
    Prefab("photon_cannon_base", basefn, baseassets)
