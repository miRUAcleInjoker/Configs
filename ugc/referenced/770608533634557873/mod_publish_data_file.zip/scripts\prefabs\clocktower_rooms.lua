local assets =
{
    Asset("ANIM", "anim/oasis_tile.zip"),
	Asset("ANIM", "anim/clocktower_room_basic.zip"),
    Asset("ANIM", "anim/splash.zip"),
    Asset("MINIMAP_IMAGE", "oasis"),
}

local function HideRain(inst,rad)
	rad = rad or inst.FAKEGROUND_RADIUS
	local x,y,z = inst.Transform:GetWorldPosition()
	for k,v in pairs(TheSim:FindEntities(x,y,z,rad,{"FX"})) do 
		if v and v.prefab and (v.prefab == "rain" or v.prefab == "raindrop") then 
			v:Hide() 
		end
	end
end 

local function SpawnClockCreatures(inst)
	local pos = inst:GetPosition()
	local rad = inst.FAKEGROUND_RADIUS - 2 
	for roation = 0,2*math.pi, 2*math.pi/12 do 
		for i = 1,2 + math.random()*2 do 
			local randrad = math.random() * rad
			local randoffset = Vector3(randrad*math.cos(roation),0,randrad*math.sin(roation))
			SpawnAt(math.random() <= 0.6 and "knight" or math.random() <= 0.6 and "bishop" or "rook",pos+randoffset)
		end
	end
	for i = -25,25,5 do 
		local lineoffset = Vector3(i,0,-4)
		local lineoffset2 = Vector3(i,0,4)
		local statuename = math.random() <= 0.5 and "statue_marble_muse" or math.random() <= 0.5 and "statue_marble_pawn" or "statue_marble"
		SpawnAt(statuename,pos+lineoffset)
		SpawnAt(statuename,pos+lineoffset2)
	end
	
end 

local function SpawnSpiderKingdom(inst)
	local pos = inst:GetPosition()
	local rad = inst.FAKEGROUND_RADIUS - 2 
	for roation = 0,2*math.pi, 2*math.pi/12 do 
		local offset = Vector3(rad*math.cos(roation),0,rad*math.sin(roation))
		SpawnAt("spiderden_3",pos+offset)
		for i = 1,3 + math.random()*3 do 
			local randrad = math.random() * rad
			local randoffset = Vector3(randrad*math.cos(roation),0,randrad*math.sin(roation))
			SpawnAt(math.random() <= 0.6 and "spider" or "spider_warrior",pos+randoffset)
		end
		
	end
end 

local function SpawnTentacles(inst)
	local pos = inst:GetPosition()
	local rad = inst.FAKEGROUND_RADIUS - 2 
	for roation = 0,2*math.pi, 2*math.pi/12 do 
		local offset = Vector3(rad*math.cos(roation),0,rad*math.sin(roation))
		SpawnAt("tentacle",pos+offset)
		for i = 1,8 + math.random()*10 do 
			local randrad = math.random() * rad
			local randoffset = Vector3(randrad*math.cos(roation),0,randrad*math.sin(roation))
			SpawnAt(math.random() <= 0.6 and "beemine_maxwell" or "tentacle",pos+randoffset)
		end
	end
	for roation = 0,2*math.pi, 2*math.pi/24 do 
		local offset = Vector3(rad*math.cos(roation),0,rad*math.sin(roation))
		SpawnAt("tentacle",pos+offset)
		for i = 1,8 do 
			local randrad = math.random() * rad
			local randoffset = Vector3(randrad*math.cos(roation),0,randrad*math.sin(roation))
			SpawnAt(math.random() <= 0.6 and "beemine_maxwell" or "tentacle",pos+randoffset)
		end
	end
	for i = -30,30 do 
		local lineoffset = Vector3(i,0,2 - 4*math.random())
		SpawnAt("tentacle",pos+lineoffset)
	end
end 

local statue_ruins = {
	"ruins_statue_head",
	"ruins_statue_head_nogem",
	"ruins_statue_mage",
	"ruins_statue_mage_nogem",
}

local function SpawnManySpearTraps(inst)
	local pos = inst:GetPosition()
	local pertime = 1
	local catapultpos = {
		Vector3(-3,0,-3),
		Vector3(-3,0,3),
		Vector3(3,0,-3),
		Vector3(3,0,3),
	}
	--local statuename = statue_ruins[math.random(1,#statue_ruins)]
	SpawnAt("clocktower_spotlight",pos)
	
	for k,v in pairs(catapultpos) do 
		SpawnAt("clocktower_catapult",pos+v)
	end 
	
	for roation = 0,2*math.pi, 2*math.pi/24 do 
		if roation ~= 0 then 
			for rad = 3,inst.FAKEGROUND_RADIUS-2,2 do 
				local offset = Vector3(rad*math.cos(roation),0,rad*math.sin(roation))
				local trap = SpawnAt("clocktower_spear_trap",pos+offset)
				trap:SetTime(1,1,pertime,true)
			end 
			pertime = pertime + 1
		end 
	end
	inst.NoLight = true 
	inst.NoMiss = true
end 

local function SpawnMaxwellTraps(inst,offset)
	offset = offset or Vector3(30,0,0)
	--local offset2 = Vector3(-30,0,0)
	local pos = inst:GetPosition()
	for i = -3,3,0.5 do 
		for j = -3,3,0.5 do 
			local grassoffset = Vector3(i,0,j)
			if math.random() <= 0.3 then 
				SpawnAt(math.random() <= 0.6 and "grass" or "sapling",pos+grassoffset+offset)
			end 
			if math.random() <= 0.2 then 
				local num = math.random() <= 0.2 and 5 or 1
				for i = 1,num do 
					SpawnAt("trap_teeth_maxwell",pos+grassoffset+offset)
				end 
			end
		end
	end
end 

local TrapFunctions = {
	main = {
		SpawnSpiderKingdom,
		SpawnTentacles,
		SpawnClockCreatures,
		SpawnManySpearTraps,
	},
	small = {
		SpawnMaxwellTraps,
	}
} 

local function SpawnTraps(inst,num)
	local Main = TrapFunctions.main[num] or TrapFunctions.main[math.random(1,#TrapFunctions.main)]
	Main(inst)
	--TrapFunctions.small[math.random(1,#TrapFunctions.small)](inst)
end 

local function MakeWall(inst,rad,hide)
	local x,y,z = inst:GetPosition():Get() 
	for roation = 0,2*math.pi,0.025 do
		local wall = SpawnPrefab("clocktower_wall")
		wall.Transform:SetPosition(x+rad*math.cos(roation),y,z+rad*math.sin(roation))
		wall.persists = false 
		table.insert(inst.Walls,wall) 
		if hide then 
			wall:Hide() 
		end
		--wall:ListenForEvent("onremove",wall.Remove,inst)
	end 
end 

local function OnRoomRemove(inst)
	for k,v in pairs(inst.Walls) do 
		if v and v:IsValid() then 
			v:Remove() 
		end
	end
end 

local function OnPhase(inst)
	local day = TheWorld.state.phase	
	if day == "night" and not inst.NoLight  then 
		inst.Light:Enable(true)
	else
		inst.Light:Enable(false)
	end 
end 

local function OnSave(inst,data)
	data.NoLight = inst.NoLight
	data.NoMiss =  inst.NoMiss
end 

local function OnLoad(inst,data)
	if data then 
		inst.NoLight = data.NoLight 
		inst.NoMiss = data.NoMiss
	end
	if inst.Light then 
		OnPhase(inst)
	end 
end 

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddMiniMapEntity()
    inst.entity:AddNetwork()
	inst.entity:AddLight()
	inst.Transform:SetScale(4.6,4.6,4.6)
	
	

    MakeObstaclePhysics(inst, 0)
	RemovePhysicsColliders(inst)

    inst.AnimState:SetBuild("clocktower_room_basic")
    inst.AnimState:SetBank("clocktower_room_basic")
    inst.AnimState:PlayAnimation("idle"..math.random(1,2), true)
    inst.AnimState:SetOrientation(ANIM_ORIENTATION.OnGround)
    inst.AnimState:SetLayer(LAYER_BACKGROUND)
    inst.AnimState:SetSortOrder(2)
	--inst.AnimState:SetLightOverride(1)

    inst:AddTag("antlion_sinkhole_blocker")
    inst:AddTag("birdblocker")
	inst:AddTag("FAKEGROUND")
	inst:AddTag("NOCLICK")

    --inst:SetDeployExtraSpacing(14.4)
	
	inst.FAKEGROUND_RADIUS = 35 
	inst.areaname = "clocktower"
	
	inst.Light:SetIntensity(.75)
    inst.Light:SetColour(252 / 255, 204 / 255, 0 / 255)
    inst.Light:SetFalloff(.6)
    inst.Light:SetRadius(inst.FAKEGROUND_RADIUS)
    inst.Light:Enable(false)


    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.NoMiss = false 
	inst.NoLight = false 
	inst.Walls = {} 
	inst.SpawnTraps = SpawnTraps 
	inst.TrapFunctions = TrapFunctions 
	
	inst.OnSave = OnSave
	inst.OnLoad = OnLoad
	
	
	--inst.Physics:SetCylinder(14.4, 1.0)
	inst:DoTaskInTime(0,function()
		MakeWall(inst,35)
		--SpawnTraps(inst) 
	end ) 
	--inst:DoPeriodicTask(0,HideRain)
	
	OnPhase(inst)
	inst:ListenForEvent("onremove",OnRoomRemove)
	inst:WatchWorldState("phase",OnPhase)


    return inst
end

local function wall_fn()
	local inst = CreateEntity()
	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddNetwork()

	MakeObstaclePhysics(inst, 1)
	inst.Physics:SetDontRemoveOnSleep(true)
	inst.Physics:SetActive(true)
	--inst.AnimState:SetLightOverride(1)
	
	inst:AddTag("wall")
    inst:AddTag("noauradamage")
    inst:AddTag("nointerpolate")
	
    inst.AnimState:SetBank("wall")
    inst.AnimState:SetBuild("wall_ruins")
    inst.AnimState:PlayAnimation("fullA")
	inst.Transform:SetScale(1,1,1)
	
	inst.entity:SetPristine()
	
	if not TheWorld.ismastersim then
		return inst
	end
	
	
			
	return inst
end
-----------------------------------------------


local function OnDoneTeleporting(inst, obj)
    if inst.closetask ~= nil then
        inst.closetask:Cancel()
    end
    inst.closetask = inst:DoTaskInTime(1.5, function()
        if not (inst.components.teleporter:IsBusy() or
                inst.components.playerprox:IsPlayerClose()) then
            --inst.sg:GoToState("closing")
        end
    end)

    if obj ~= nil and obj:HasTag("player") then
        --obj:DoTaskInTime(1, obj.PushEvent, "wormholespit") -- for wisecracker
		obj:CheckAreaBgm() 
    end
	
	
end

local function OnActivate(inst, doer)
    if doer:HasTag("player") then
        ProfileStatsSet("wormhole_used", true)
        AwardPlayerAchievement("wormhole_used", doer)

        local other = inst.components.teleporter.targetTeleporter
        if other ~= nil then
            DeleteCloseEntsWithTag("WORM_DANGER", other, 15)
        end

        if doer.components.talker ~= nil then
            doer.components.talker:ShutUp()
        end

        --Sounds are triggered in player's stategraph
    elseif inst.SoundEmitter ~= nil then
        inst.SoundEmitter:PlaySound("dontstarve/common/teleportworm/swallow")
    end
end

local function OnActivateByOther(inst, source, doer)
    --[[if not inst.sg:HasStateTag("open") then
        inst.sg:GoToState("opening")
    end--]]
end

local function onnear(inst)
    --[[if inst.components.teleporter:IsActive() and not inst.sg:HasStateTag("open") then
        inst.sg:GoToState("opening")
    end--]]
end

local function onfar(inst)
    --[[if not inst.components.teleporter:IsBusy() and inst.sg:HasStateTag("open") then
        inst.sg:GoToState("closing")
    end--]]
end

local function onaccept(inst, giver, item)
    inst.components.inventory:DropItem(item)
    inst.components.teleporter:Activate(item)
end

local function StartTravelSound(inst, doer)
    --inst.SoundEmitter:PlaySound("dontstarve/common/teleportworm/swallow")
    --doer:PushEvent("wormholetravel", WORMHOLETYPE.WORM) --Event for playing local travel sound
end

local function door_fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddMiniMapEntity()
    inst.entity:AddNetwork()

    inst.entity:AddPhysics() -- no collision, this is just for buffered actions
    inst.Physics:ClearCollisionMask()
    inst.Physics:SetSphere(1)
	--inst.AnimState:SetLightOverride(1)

    inst.MiniMapEntity:SetIcon("wormhole.png")

	inst.AnimState:SetBank("portal_dst")
    inst.AnimState:SetBuild("portal_stone")
    inst.AnimState:PlayAnimation("idle_loop", true)
    --inst.AnimState:SetLayer(LAYER_BACKGROUND)
    --inst.AnimState:SetSortOrder(3)

    --trader, alltrader (from trader component) added to pristine state for optimization
    inst:AddTag("trader")
    inst:AddTag("alltrader")

    inst:AddTag("antlion_sinkhole_blocker")
	
	inst.nameoverride = "clocktower_door"

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    --inst:SetStateGraph("SGwormhole")

    inst:AddComponent("inspectable")
	--inst.components.inspectable.nameoverride = "clocktower_door"


    inst:AddComponent("playerprox")
    inst.components.playerprox:SetDist(4, 5)
    inst.components.playerprox.onnear = onnear
    inst.components.playerprox.onfar = onfar

    inst:AddComponent("teleporter")
    inst.components.teleporter.onActivate = OnActivate
    inst.components.teleporter.onActivateByOther = OnActivateByOther
    inst.components.teleporter.offset = 0
    inst:ListenForEvent("starttravelsound", StartTravelSound) -- triggered by player stategraph
    inst:ListenForEvent("doneteleporting", OnDoneTeleporting)

    inst:AddComponent("inventory")

    inst:AddComponent("trader")
    inst.components.trader.acceptnontradable = true
    inst.components.trader.onaccept = onaccept
    inst.components.trader.deleteitemonaccept = false

    return inst
end

local function final_roomfn()
	local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()
	

    MakeObstaclePhysics(inst, 0)
	RemovePhysicsColliders(inst)
	inst.AnimState:SetBuild("clocktower_room_basic")
    inst.AnimState:SetBank("clocktower_room_basic")
    inst.AnimState:PlayAnimation("idle"..math.random(1,2), true)
    inst.AnimState:SetOrientation(ANIM_ORIENTATION.OnGround)
    inst.AnimState:SetLayer(LAYER_BACKGROUND)
    inst.AnimState:SetSortOrder(2)
	inst.AnimState:SetMultColour(0,0,0,1)
	--inst.AnimState:SetLightOverride(1)
	
	inst.Transform:SetScale(8,8,8)

	--inst.AnimState:SetLightOverride(1)

    inst:AddTag("antlion_sinkhole_blocker")
    inst:AddTag("birdblocker")
	inst:AddTag("FAKEGROUND")
	inst:AddTag("NOCLICK")

    --inst:SetDeployExtraSpacing(14.4)
	
	inst.FAKEGROUND_RADIUS = 12 
	--inst.areaname = "clocktower"
	
	inst:AddTag("CAMERAFOCUS")


    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.NoMiss = false 
	inst.NoLight = false 
	inst.Walls = {} 
	

	inst.OnSave = OnSave
	inst.OnLoad = OnLoad
	
	inst.SpawnBoss = function(self)
		self:DoTaskInTime(0,function()
			SpawnAt("death_dragon",self:GetPosition()).sg:GoToState("enter")
		end) 
	end
	
	
	--inst.Physics:SetCylinder(14.4, 1.0)
	inst:DoTaskInTime(0,function()
		MakeWall(inst,12,true)
		--SpawnTraps(inst) 
	end ) 
	--inst:DoPeriodicTask(0,HideRain)
	
	inst:ListenForEvent("onremove",OnRoomRemove)

    return inst
end

return Prefab("clocktower_room_basic",fn,assets),
Prefab("clocktower_wall", wall_fn),
Prefab("clocktower_door", door_fn, assets),
Prefab("clocktower_door_enter", door_fn, assets),
Prefab("clocktower_room_final",final_roomfn)
--Prefab("clocktower_room_final_black",blackfn)
--c_findnext("clocktower_room_final"):SpawnBoss()