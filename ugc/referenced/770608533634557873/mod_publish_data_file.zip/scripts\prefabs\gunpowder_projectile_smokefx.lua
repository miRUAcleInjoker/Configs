
--local SMOKE_TEXTURE = "fx/sparkle.tex"

local ADD_SHADER = "shaders/vfx_particle.ksh"

local SMOKE_TEXTURE = resolvefilepath("fx/smoke.tex") 
local COLOUR_ENVELOPE_SMOKE_NAME = "gunpowder_projectile_smokefx_colourenvelope"
local SCALE_ENVELOPE_SMOKE_NAME = "gunpowder_projectile_smokefx_scaleenvelope"

local FIRE_TEXTURE = resolvefilepath("fx/snow.tex") 
local FIRE_COLOUR_ENVELOPE_SMOKE_NAME = "gunpowder_projectile_firefx_colourenvelope"
local FIRE_SCALE_ENVELOPE_SMOKE_NAME = "gunpowder_projectile_firefx_scaleenvelope"

local assets =
{
    Asset("IMAGE", SMOKE_TEXTURE),
	Asset("IMAGE", FIRE_TEXTURE),
    Asset("SHADER", ADD_SHADER),
}

--------------------------------------------------------------------------

local function IntColour(r, g, b, a)
    return { r / 255, g / 255, b / 255, a / 255 }
end

local function InitEnvelope()
    EnvelopeManager:AddColourEnvelope(COLOUR_ENVELOPE_SMOKE_NAME, {
		{ 0,    IntColour(250, 250, 250, 250) },
		{ .2,   IntColour(255, 255, 255, 210) },
        { .3,   IntColour(255, 255, 255, 170) },
        { .55,  IntColour(250, 250, 250, 130) },
		{ .7,  IntColour(250, 250, 250, 90) },
        { 1,    IntColour(250, 250, 250, 10) },
	})

    local sparkle_max_scale = 0.75
    EnvelopeManager:AddVector2Envelope(
        SCALE_ENVELOPE_SMOKE_NAME,
        {
            { 0,    { sparkle_max_scale, sparkle_max_scale} },
			{ .3,  { sparkle_max_scale * .9, sparkle_max_scale * .9} },
            { .55,  { sparkle_max_scale * .6, sparkle_max_scale * .6} },
			{ 1,    { sparkle_max_scale * .4, sparkle_max_scale * .4} },
        }
    )
	
	EnvelopeManager:AddColourEnvelope(FIRE_COLOUR_ENVELOPE_SMOKE_NAME, {
        { 0,    IntColour(200, 85, 60, 25) },
        { .2,   IntColour(230, 140, 90, 200) },
        { .3,   IntColour(255, 90, 70, 255) },
        { .6,   IntColour(255, 90, 70, 255) },
        { .9,   IntColour(255, 90, 70, 230) },
        { 1,    IntColour(255, 70, 70, 0) },
	})

    local ember_max_scale = 2
    EnvelopeManager:AddVector2Envelope(
        FIRE_SCALE_ENVELOPE_SMOKE_NAME,
        {
            { 0,    { ember_max_scale, ember_max_scale } },
            { 1,    { ember_max_scale, ember_max_scale } },
        }
    )

    InitEnvelope = nil
    IntColour = nil
end

--------------------------------------------------------------------------
local MAX_LIFETIME = 0.45
local LIGHTNING_MAX_LIFETIME = 0.33
local function emit_sparkle_fn(effect, sphere_emitter)
    --local vx, vy, vz = .012 * UnitRand(), 0, .012 * UnitRand()
    --local lifetime = MAX_LIFETIME * (.7 + UnitRand() * .3)
    --local px, py, pz = sphere_emitter()

    
    --local uv_offset = math.random(0, 3) * .25
    
	
	local vx, vy, vz = .01 * UnitRand(), 0, .01 * UnitRand()
    local lifetime = MAX_LIFETIME * (.9 + UnitRand() * .1)
    local px, py, pz = sphere_emitter()
    local uv_offset = math.random(0, 3) * .25
	
	local angle = math.random() * 360    
	local ang_vel = (UnitRand() - 1) * 5

    --[[effect:AddRotatingParticleUV(
        0,
        lifetime,           -- lifetime
        px, py, pz,         -- position
        vx, vy, vz,         -- velocity
        angle, ang_vel,     -- angle, angular_velocity
        uv_offset, 0        -- uv offset
    )--]]
	
	effect:AddParticleUV(
        1,
        lifetime,           -- lifetime
        px, py, pz,         -- position
        vx, vy, vz,         -- velocity
        uv_offset, 0        -- uv offset
    )
end

local function emit_lightning_fn(effect, sphere_emitter)
    local vx, vy, vz = .01 * UnitRand(), .05, .01 * UnitRand()
    local lifetime = LIGHTNING_MAX_LIFETIME * (.9 + UnitRand() * .1)
    local px, py, pz = sphere_emitter()
    local uv_offset = math.random(0, 3) * .25

    effect:AddParticleUV(
        0,
        lifetime,           -- lifetime
        px, py, pz,         -- position
        vx, vy, vz,         -- velocity
        uv_offset, 0        -- uv offset
    )      
end

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddNetwork()

    inst:AddTag("FX")

    --Dedicated server does not need to spawn local particle fx
    if InitEnvelope ~= nil and not TheNet:IsDedicated() then
        InitEnvelope()
    end

    local effect = inst.entity:AddVFXEffect()
    effect:InitEmitters(2)

    --SPARKLE
    --[[effect:SetRenderResources(0, SMOKE_TEXTURE, ADD_SHADER)
    effect:SetRotationStatus(0, true)
    effect:SetUVFrameSize(0, .25, 1)
    effect:SetMaxNumParticles(0, 256)
    effect:SetMaxLifetime(0, MAX_LIFETIME)
    effect:SetColourEnvelope(0, COLOUR_ENVELOPE_SMOKE_NAME)
    effect:SetScaleEnvelope(0, SCALE_ENVELOPE_SMOKE_NAME)
    effect:SetBlendMode(0, BLENDMODE.Additive)
    effect:EnableBloomPass(0, true)
    effect:SetSortOrder(0, 0)
    effect:SetSortOffset(0, 2)--]]
	
	--lightning
	effect:SetRenderResources(0, FIRE_TEXTURE, ADD_SHADER)--设置源，参数：序号，贴图，渲染程序名
    effect:SetMaxNumParticles(0, 64)--设置颗粒最大数，即粒子效果同时出现的最大数
    effect:SetMaxLifetime(0, LIGHTNING_MAX_LIFETIME)--粒子持续时间
    effect:SetColourEnvelope(0, FIRE_COLOUR_ENVELOPE_SMOKE_NAME)--设置调色效果
    effect:SetScaleEnvelope(0, FIRE_SCALE_ENVELOPE_SMOKE_NAME)--设置缩放效果
    effect:SetBlendMode(0, BLENDMODE.Additive)--设置混合形�?
    effect:EnableBloomPass(0, true)--设置辉光
    effect:SetUVFrameSize(0, .25, 1)--
    effect:SetSortOrder(0, 0)
    effect:SetSortOffset(0, 0)
	effect:SetFollowEmitter(0, true)
	
	--normal
	effect:SetRenderResources(1, SMOKE_TEXTURE, ADD_SHADER)
    effect:SetMaxNumParticles(1, 256)
    effect:SetMaxLifetime(1, MAX_LIFETIME)
    effect:SetColourEnvelope(1, COLOUR_ENVELOPE_SMOKE_NAME)
    effect:SetScaleEnvelope(1, SCALE_ENVELOPE_SMOKE_NAME)
    effect:SetBlendMode(1, BLENDMODE.Additive)
    effect:EnableBloomPass(1, true)
    effect:SetUVFrameSize(1, .25, 1)
    effect:SetSortOrder(1, 1)
    effect:SetSortOffset(1, 0)
	effect:SetFollowEmitter(1, false)
	
	

    -----------------------------------------------------

    local tick_time = TheSim:GetTickTime()

    local sparkle_desired_pps_low = 5
    local sparkle_desired_pps_high = 50
    local low_per_tick = sparkle_desired_pps_low * tick_time
    local high_per_tick = sparkle_desired_pps_high * tick_time
    local num_to_emit = 0
	
	local lightning_num_to_emit = 0

    local sphere_emitter = CreateSphereEmitter(.025)
    inst.last_pos = inst:GetPosition()

    EmitterManager:AddEmitter(inst, nil, function()
        local dist_moved = inst:GetPosition() - inst.last_pos
        local move = dist_moved:Length()
        move = math.clamp(move*6, 0, 1)

        local per_tick = Lerp(low_per_tick, high_per_tick, move)

        inst.last_pos = inst:GetPosition()
                
        num_to_emit = num_to_emit + per_tick * math.random() * 3
        while num_to_emit > 1 do
            emit_sparkle_fn(effect, sphere_emitter)
            num_to_emit = num_to_emit - 1
        end
		
		lightning_num_to_emit = lightning_num_to_emit + per_tick * math.random() * 3
        while lightning_num_to_emit > 1 do
            emit_lightning_fn(effect, sphere_emitter)
            lightning_num_to_emit = lightning_num_to_emit - 1
        end
    end)
	
	inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.persists = false

    return inst
end

return Prefab("gunpowder_projectile_smokefx", fn, assets)
