local INTENSITY = .75

local easing = require("easing")
local IceyUtil = require("icey_util") 

local assets =
{
    Asset("ANIM", "anim/metal_hulk_build.zip"),
	Asset("ANIM", "anim/metal_hulk_basic.zip"),
    Asset("ANIM", "anim/metal_hulk_attacks.zip"),
    Asset("ANIM", "anim/metal_hulk_actions.zip"),
    Asset("ANIM", "anim/metal_hulk_barrier.zip"),
    Asset("ANIM", "anim/metal_hulk_explode.zip"),    
    Asset("ANIM", "anim/metal_hulk_bomb.zip"),    
    Asset("ANIM", "anim/metal_hulk_projectile.zip"),    

    Asset("ANIM", "anim/laser_explode_sm.zip"),  
    Asset("ANIM", "anim/smoke_aoe.zip"),
    Asset("ANIM", "anim/laser_explosion.zip"),
    --Asset("ANIM", "anim/ground_chunks_breaking.zip"),
    Asset("ANIM", "anim/ground_chunks_breaking_brown.zip"),

    --Asset("SOUND", "sound/bearger.fsb"),
}

local function canattack(inst,owner,target) ------------���ر��գ��ж�Ŀ���Ƿ���Ŀ��Ա����������Ա��˺�
	return IceyUtil.CanAttack(target,owner)
end  


local function SetLightValue(inst, val1, val2, time)
    inst.components.fader:StopAll()
    if val1 and val2 and time then
        inst.Light:Enable(true)
        inst.components.fader:Fade(val1, val2, time, function(v) inst.Light:SetIntensity(v) end)
    else    
        inst.Light:Enable(false)
    end
end

local function setfires(inst,x,y,z, rad)
    for i, v in ipairs(TheSim:FindEntities(x, 0, z, rad, nil, { "laser", "DECOR", "INLIMBO","player" })) do 
        if v.components.burnable then
            v.components.burnable:Ignite()
        end
    end
end

local function applydamagetoent(inst,ent, targets, rad, hit)
    local x, y, z = inst.Transform:GetWorldPosition()
    if hit then 
        targets = {}
    end    
    if not rad then 
        rad = 0
    end
    local v = ent
    if not targets[v] and v:IsValid() and not v:IsInLimbo() and not (v.components.health ~= nil and v.components.health:IsDead()) and not v:HasTag("laser_immune") then            
        local vradius = 0
        if v.Physics then
            vradius = v.Physics:GetRadius()
        end

        local range = rad + vradius
        if hit or v:GetDistanceSqToPoint(Vector3(x, y, z)) < range * range then
            local isworkable = false
            if v.components.workable ~= nil then
                local work_action = v.components.workable:GetWorkAction()
                --V2C: nil action for campfires
                isworkable =
                    (   work_action == nil and v:HasTag("campfire")    ) or
                    
                        (   work_action == ACTIONS.CHOP or
                            work_action == ACTIONS.HAMMER or
                            work_action == ACTIONS.MINE or   
                            work_action == ACTIONS.DIG or
                            work_action == ACTIONS.BLANK
                        )
            end
            if isworkable then
                targets[v] = true
                v:DoTaskInTime(0.6, function() 
                    if v.components.workable then
                        v.components.workable:Destroy(inst) 
                        local vx,vy,vz = v.Transform:GetWorldPosition()
                        v:DoTaskInTime(0.3, function() setfires(inst,vx,vy,vz,1) end)
                    end
                 end)
                if v:IsValid() and v:HasTag("stump") then
                   -- v:Remove()
                end
            elseif v.components.pickable ~= nil
                and v.components.pickable:CanBePicked()
                and not v:HasTag("intense") then
                targets[v] = true
                local num = v.components.pickable.numtoharvest or 1
                local product = v.components.pickable.product
                local x1, y1, z1 = v.Transform:GetWorldPosition()
                v.components.pickable:Pick(inst) -- only calling this to trigger callbacks on the object
                if product ~= nil and num > 0 then
                    for i = 1, num do
                        local loot = SpawnPrefab(product)
                        loot.Transform:SetPosition(x1, 0, z1)
                        targets[loot] = true
                    end
                end

            elseif v.components.health then   
				if (inst.owner  and inst.components.ly_projectile.canhit(inst,inst.owner,v)) then 
					v.components.combat:GetAttacked(inst.owner,inst.components.combat.defaultdamage)    
				end                                 
                if v:IsValid() then
                    if not v.components.health or not v.components.health:IsDead() then
                        if v.components.freezable ~= nil then
                            if v.components.freezable:IsFrozen() then
                                v.components.freezable:Unfreeze()
                            elseif v.components.freezable.coldness > 0 then
                                v.components.freezable:AddColdness(-2)
                            end
                        end
                        if v.components.temperature ~= nil then
                            local maxtemp = math.min(v.components.temperature:GetMax(), 10)
                            local curtemp = v.components.temperature:GetCurrent()
                            if maxtemp > curtemp then
                                v.components.temperature:DoDelta(math.min(10, maxtemp - curtemp))
                            end
                        end
                    end
                end                   
            end
            if v:IsValid() and v.AnimState then
                SpawnPrefab("deerclops_laserhit"):SetTarget(v)
            end
        end
    end 
    return targets   
end

local function DoDamage(inst, rad, startang, endang, spawnburns)
    local targets = {}
    local x, y, z = inst.Transform:GetWorldPosition()
    local angle = nil
    if startang and endang then
        startang = startang + 90
        endang = endang + 90
        
        local down = TheCamera:GetDownVec()             
        angle = math.atan2(down.z, down.x)/DEGREES
    end

    setfires(inst,x,y,z, rad)
    for i, v in ipairs(TheSim:FindEntities(x, 0, z, rad, nil, { "laser", "DECOR", "INLIMBO" })) do  --  { "_combat", "pickable", "campfire", "CHOP_workable", "HAMMER_workable", "MINE_workable", "DIG_workable" }
        local dodamage = true
        if startang and endang then
            local dir = inst:GetAngleToPoint(Vector3(v.Transform:GetWorldPosition())) 

            local dif = angle - dir         
            while dif > 450 do
                dif = dif - 360 
            end
            while dif < 90 do
                dif = dif + 360
            end                       
            if dif < startang or dif > endang then                
                dodamage = nil
            end
        end
        if dodamage  then
            targets = applydamagetoent(inst,v, targets, rad)
        end
    end
end

local function OnHitOrb(inst) 
	ShakeAllCameras(CAMERASHAKE.FULL, 0.8, .03, .5, inst, 30)
	inst.AnimState:PlayAnimation("impact")  
	inst.Physics:Stop() 
	inst:ListenForEvent("animover", function() 
		if inst.AnimState:IsCurrentAnimation("impact") then
		   inst:Remove()
		end
	end)
	SpawnPrefab("laser_ring").Transform:SetPosition(inst.Transform:GetWorldPosition())  
	local fx = SpawnPrefab("laser_explode_sm")
	fx.Transform:SetPosition(inst.Transform:GetWorldPosition())   
	fx.Transform:SetScale(2,2,2)
	inst:DoTaskInTime(0.3,function() DoDamage(inst, 3.5) end)
	inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/hulk_metal_robot/smash_2")   
end

local function OnHitOrbSmall(inst,other) 
	ShakeAllCameras(CAMERASHAKE.FULL, 0.7, .03, .5, inst, 30)
	inst.AnimState:PlayAnimation("impact")  
	inst.Physics:Stop() 
	inst:ListenForEvent("animover", function() 
		if inst.AnimState:IsCurrentAnimation("impact") then
		   inst:Remove()
		end
	end)
	local ring = SpawnPrefab("laser_explosion")
	ring.Transform:SetPosition(inst.Transform:GetWorldPosition()) 
	inst:DoTaskInTime(0.3,function() DoDamage(inst, 2) end)    
	ring.Transform:SetScale(0.5,0.5,0.5)
	inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/hulk_metal_robot/smash_2")    
		
end


local function OnOtherCollide(inst,other)
	if not inst.AOEHitted and other.components.workable ~= nil
        and other.components.workable:CanBeWorked()
        and other.components.workable.action ~= ACTIONS.NET then
		OnHitOrb(inst) 
		inst.AOEHitted = true 
	end 
end 

local function OnOtherCollideSmall(inst,other)
	if not inst.AOEHitted and other.components.workable ~= nil
        and other.components.workable:CanBeWorked()
        and other.components.workable.action ~= ACTIONS.NET then
		OnHitOrbSmall(inst) 
		inst.AOEHitted = true 
	end 
end 

local function orbfn(Sim)
    local inst = CreateEntity()
	
    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
	inst.entity:AddNetwork()
	inst.entity:AddLight()    

    MakeInventoryPhysics(inst, 75, 0.5)
	RemovePhysicsColliders(inst)
	
	inst.Physics:SetCollisionGroup(COLLISION.CHARACTERS)
    inst.Physics:ClearCollisionMask()
    inst.Physics:CollidesWith(COLLISION.OBSTACLES)
    inst.Physics:CollidesWith(COLLISION.SMALLOBSTACLES)
	inst.Physics:CollidesWith(COLLISION.SMALLOBSTACLES)
	inst.Physics:CollidesWith(COLLISION.CHARACTERS)
    inst.Physics:CollidesWith(COLLISION.GIANTS)
	
    inst.Light:SetIntensity(.6)
    inst.Light:SetRadius(3)
    inst.Light:SetFalloff(1)
    inst.Light:SetColour(1, 0.3, 0.3)
    inst.Light:Enable(true)

    inst.AnimState:SetBank("metal_hulk_projectile")
    inst.AnimState:SetBuild("metal_hulk_projectile")
    inst.AnimState:PlayAnimation("spin_loop", true)

    inst:AddTag("ancient_hulk_orb")
	
	inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst.persists = false
	
	inst.Physics:SetCollisionCallback(OnOtherCollide)

    inst:AddComponent("fader")
	
	inst:AddComponent("combat")
    inst.components.combat:SetDefaultDamage(75)
	
	inst:AddComponent("ly_projectile")
	inst.components.ly_projectile.damage = 100
    inst.components.ly_projectile:SetSpeed(50)
    inst.components.ly_projectile:SetOnHitFn(OnHitOrb)
    inst.components.ly_projectile:SetOnMissFn(inst.Remove)
	inst.components.ly_projectile:SetHitDist(1.5)
	inst.components.ly_projectile:SetCanHit(canattack)

    inst.SetLightValue = SetLightValue

    return inst
end

local function orbsmallfn(Sim)
    local inst = CreateEntity()
	
    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
	inst.entity:AddNetwork()
	inst.entity:AddLight()   

    MakeInventoryPhysics(inst, 1, 0.5)
	RemovePhysicsColliders(inst)
	
	inst.Physics:SetCollisionGroup(COLLISION.CHARACTERS)
    inst.Physics:ClearCollisionMask()
    inst.Physics:CollidesWith(COLLISION.OBSTACLES)
    inst.Physics:CollidesWith(COLLISION.SMALLOBSTACLES)
	inst.Physics:CollidesWith(COLLISION.CHARACTERS)
    inst.Physics:CollidesWith(COLLISION.GIANTS)
	
	 
    inst.Light:SetIntensity(.6)
    inst.Light:SetRadius(3)
    inst.Light:SetFalloff(1)
    inst.Light:SetColour(1, 0.3, 0.3)
    inst.Light:Enable(true)
    
    inst.AnimState:SetBank("metal_hulk_projectile")
    inst.AnimState:SetBuild("metal_hulk_projectile")
    inst.AnimState:PlayAnimation("spin_loop", true)    

    inst.Transform:SetScale(0.5,0.5,0.5)
	
	inst:AddTag("smallorb")
	
	inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst.persists = false
	
	inst.Physics:SetCollisionCallback(OnOtherCollideSmall)


    inst:DoTaskInTime(2,function() inst:Remove() end)

    inst:AddComponent("fader")
	
	inst:AddComponent("combat")
    inst.components.combat:SetDefaultDamage(25)
	
	inst:AddComponent("ly_projectile")
	inst.components.ly_projectile.damage = 50
    inst.components.ly_projectile:SetSpeed(50)
    inst.components.ly_projectile:SetOnHitFn(OnHitOrbSmall)
    inst.components.ly_projectile:SetOnMissFn(inst.Remove)
	inst.components.ly_projectile:SetHitDist(1.5)
	inst.components.ly_projectile:SetCanHit(canattack)

    inst.SetLightValue = SetLightValue

    return inst
end

return Prefab( "icey_ironlord_orb", orbfn, assets),
Prefab( "icey_ironlord_orb_small", orbsmallfn, assets)