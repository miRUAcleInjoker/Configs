require "prefabutil"

local tent_assets =
{
    Asset("ANIM", "anim/icey_tent.zip"),
	
}



-----------------------------------------------------------------------
--For regular tents

local function PlaySleepLoopSoundTask(inst, stopfn)
    inst.SoundEmitter:PlaySound("dontstarve/common/tent_sleep")
end

local function stopsleepsound(inst)
    if inst.sleep_tasks ~= nil then
        for i, v in ipairs(inst.sleep_tasks) do
            v:Cancel()
        end
        inst.sleep_tasks = nil
    end
end

local function startsleepsound(inst, len)
    stopsleepsound(inst)
    inst.sleep_tasks =
    {
        inst:DoPeriodicTask(len, PlaySleepLoopSoundTask, 33 * FRAMES),
        inst:DoPeriodicTask(len, PlaySleepLoopSoundTask, 47 * FRAMES),
    }
end

-----------------------------------------------------------------------



local function BadAwake(sleeper)
	if not sleeper then 
		return
	end 
	if sleeper.components.health then 
		sleeper:StartUpdatingComponent("health")
		sleeper.components.health:SetPercent(0.05)
	end
	if sleeper.components.sanity then 
		sleeper:StartUpdatingComponent("sanity")
		sleeper.components.sanity:SetPercent(0.05)
	end
	if sleeper.components.hunger then 
		sleeper.components.hunger:Resume()
		sleeper.components.hunger:SetPercent(0.05)
	end
	if  sleeper.components.grogginess then 
		sleeper.components.grogginess:AddGrogginess(0.5, 15 + math.random()*5)
	end 
	sleeper:DoTaskInTime(5,function()
		if sleeper.components.talker then 
			sleeper.components.talker:Say("唔,身体.....好难受")
		end 
	end)
end 


local function onhammered(inst, worker)
	if inst.components.sleepingbag ~= nil and inst.components.sleepingbag.sleeper ~= nil then
        BadAwake(inst.components.sleepingbag.sleeper)
		inst.components.sleepingbag:DoWakeUp()
    end
    inst.components.lootdropper:DropLoot()
    local fx = SpawnPrefab("collapse_big")
    fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
    fx:SetMaterial("wood")
    inst:Remove()
end

local function onhit(inst, worker)
    if not inst:HasTag("burnt") then
        stopsleepsound(inst)
    end
    
end

local function onfinishedsound(inst)
    inst.SoundEmitter:PlaySound("dontstarve/common/tent_dis_twirl")
end


local function onbuilt_tent(inst)
    inst.AnimState:PlayAnimation("idle", true)
    inst.SoundEmitter:PlaySound("dontstarve/common/tent_craft")
end

local function onbuilt_siestahut(inst)
    inst.AnimState:PlayAnimation("idle", true)
    inst.SoundEmitter:PlaySound("dontstarve/common/lean_to_craft")
end


local function OnPlayerAttacked(sleeper)
	print("A Player in icey_tent is Attacked ! It must be a bad wake ")
	local inst = sleeper.sleepingbag
	BadAwake(sleeper)
	inst.components.sleepingbag:DoWakeUp()
end 

local function onwake(inst, sleeper, nostatechange)
 
    if not nostatechange then
        if sleeper.sg:HasStateTag("tent") then
            sleeper.sg.statemem.iswaking = true
        end
        sleeper.sg:GoToState("wakeup")
    end

    if inst.sleep_anim ~= nil then
        inst.AnimState:PushAnimation("idle", true)
        stopsleepsound(inst)
    end
	if sleeper.components.health then 
		sleeper:StartUpdatingComponent("health")
	end
	if sleeper.components.sanity then 
		sleeper:StartUpdatingComponent("sanity")
	end
	if sleeper.components.hunger then 
		sleeper.components.hunger:Resume()
	end
	if sleeper.components.temperature then 
		sleeper:StartUpdatingComponent("temperature")
	end
	inst.AnimState:ClearOverrideSymbol("swap_frozen")
	sleeper.SoundEmitter:PlaySound("dontstarve/common/freezecreature")
	if inst.onsleep_fx ~= nil then 
		inst.onsleep_fx:KillFX()
		inst.onsleep_fx = nil 
	end
    --inst.components.finiteuses:Use()
	inst:RemoveEventCallback("attacked",OnPlayerAttacked,sleeper)
end



local function onsleep(inst, sleeper)
    if inst.sleep_anim ~= nil then
        inst.AnimState:PlayAnimation(inst.sleep_anim, true)
        startsleepsound(inst, inst.AnimState:GetCurrentAnimationLength())
    end
	if sleeper.components.health then 
		sleeper.components.health:StopRegen()
		sleeper:StopUpdatingComponent("health")
	end
	if sleeper.components.sanity then 
		sleeper:StopUpdatingComponent("sanity")
	end
	if sleeper.components.hunger then 
		sleeper.components.hunger:Pause()
	end
	if sleeper.components.temperature then 
		sleeper.components.temperature:SetTemperature(20)
		sleeper:StopUpdatingComponent("temperature")
	end
	sleeper:DoTaskInTime(0,function()
		sleeper:Show()
		sleeper.AnimState:OverrideSymbol("swap_frozen", "frozen", "frozen")
		sleeper.AnimState:PlayAnimation("frozen",true)
		sleeper.SoundEmitter:PlaySound("dontstarve/common/freezecreature")
		if inst.onsleep_fx == nil then 
			inst.onsleep_fx = SpawnPrefab("deer_ice_fx")
			inst.onsleep_fx.entity:SetParent(inst.entity)
			inst.onsleep_fx.Transform:SetPosition(0,0,0)
		end 
	end)
	inst:ListenForEvent("attacked",OnPlayerAttacked,sleeper)
end

local function OnPhaseChange(inst,phase)
	inst.sleep_phase = phase
	if phase == "day" then 
		inst:AddTag("siestahut")
	else	
		inst:RemoveTag("siestahut")
	end
	print(inst.sleep_phase)
end 


local function turnon(inst)
	if not inst.components.sleepingbag then 
		inst:AddTag("tent")
		inst:AddTag("siestahut")
		inst:AddComponent("sleepingbag")
		inst.components.sleepingbag.onsleep = onsleep
		inst.components.sleepingbag.onwake = onwake
		--convert wetness delta to drying rate
		inst.components.sleepingbag.dryingrate = math.max(0, -TUNING.SLEEP_WETNESS_PER_TICK / TUNING.SLEEP_TICK_PERIOD)
	end 
	OnPhaseChange(inst,TheWorld.state.phase)
	inst.Light:Enable(true)
	if inst.turnon_fx == nil then 
		inst.turnon_fx = SpawnPrefab("deer_ice_flakes")
		inst.turnon_fx.entity:SetParent(inst.entity)
		inst.turnon_fx.Transform:SetPosition(0,0,0)
		inst.turnon_fx.Transform:SetScale(0.6,0.6,0.6)
	end 
end 

local function turnoff(inst)
	if  inst.components.sleepingbag then 
		inst:RemoveTag("tent")
		inst:RemoveTag("siestahut")
		BadAwake(inst.components.sleepingbag.sleeper)
		inst.components.sleepingbag:DoWakeUp()
		
		inst:RemoveComponent("sleepingbag")
	end 
	OnPhaseChange(inst,TheWorld.state.phase)
	inst.Light:Enable(false)
	if inst.turnon_fx ~= nil then 
		inst.turnon_fx:KillFX()
		inst.turnon_fx = nil 
	end 
end 

local function CheckPower(inst,data)
	local power = data.power
	inst.building_power = inst.building_power + power
	inst.building_power = math.max(0,inst.building_power)
	inst.building_power = math.min(inst.max_building_power,inst.building_power)
	if inst.building_power > 0 and not inst.IsOn then 
		print(inst,"Turn on!")
        turnon(inst)
		inst.IsOn = true
    elseif inst.building_power <= 0 and inst.IsOn then
		print(inst,"Turn off!")
        turnoff(inst)
		inst.IsOn = false
    end 
end 

local function onsave(inst, data)
	data.building_power  = inst.building_power
end

local function onload(inst, data)
	if data ~= nil and data.building_power  then 
		inst.building_power = data.building_power
		CheckPower(inst,{fromer = inst,power = 0})
	end
end

local function common_fn(bank, build, icon, tag, onbuiltfn)
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddMiniMapEntity()
	inst.entity:AddLight()
    inst.entity:AddNetwork()

    inst:AddTag("tent")
	inst:AddTag("siestahut")
    --inst:AddTag("structure")
    if tag ~= nil then
        inst:AddTag(tag)
    end

    inst.AnimState:SetBank(bank)
    inst.AnimState:SetBuild(build)
    inst.AnimState:PlayAnimation("idle", true)

    inst.MiniMapEntity:SetIcon(icon)

    MakeSnowCoveredPristine(inst)

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst:AddComponent("inspectable")

    inst:AddComponent("lootdropper")
    inst:AddComponent("workable")
    inst.components.workable:SetWorkAction(ACTIONS.HAMMER)
    inst.components.workable:SetWorkLeft(4)
    inst.components.workable:SetOnFinishCallback(onhammered)
    inst.components.workable:SetOnWorkCallback(onhit)

    --[[inst:AddComponent("finiteuses")
    inst.components.finiteuses:SetOnFinished(onfinished)--]]

    --[[inst:AddComponent("sleepingbag")
    inst.components.sleepingbag.onsleep = onsleep
    inst.components.sleepingbag.onwake = onwake
    --convert wetness delta to drying rate
    inst.components.sleepingbag.dryingrate = math.max(0, -TUNING.SLEEP_WETNESS_PER_TICK / TUNING.SLEEP_TICK_PERIOD)--]]

    MakeSnowCovered(inst)
    inst:ListenForEvent("onbuilt", onbuiltfn)

    MakeMediumPropagator(inst)

    inst.OnSave = onsave 
    inst.OnLoad = onload

    MakeHauntableWork(inst)

    return inst
end

local function tent()
    local inst = common_fn("icey_tent", "icey_tent", "icey_tent.tex", nil, onbuilt_tent)
	
	inst:AddTag("icey_power_use")
	inst:AddTag("icey_power_building")
	--nst:AddTag("structure")
	inst:AddTag("companion")
	
	inst.Light:Enable(false)
    inst.Light:SetRadius(2)
    inst.Light:SetFalloff(1)
    inst.Light:SetIntensity(.5)
    inst.Light:SetColour(5/255,168/255,203/255)
	
	--inst.AnimState:SetOrientation(ANIM_ORIENTATION.OnGround)
	
    inst.AnimState:SetLayer(LAYER_BACKGROUND)
    inst.AnimState:SetSortOrder(3)

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.IsOn = false
	inst.building_power = 0
	inst.max_building_power = 500

    inst.sleep_phase = "night"
    inst.sleep_anim = "idle"
    inst.hunger_tick = 0
    --inst.is_cooling = false
	
	inst:AddComponent("health")
	inst.components.health:SetMaxHealth(250)
	
	inst:AddComponent("combat")
	inst.components.combat.hurtsound = "dontstarve/common/place_structure_stone"
	
	inst.components.inspectable.descriptionfn = function(inst,doer)
		return (inst.IsOn and "冷藏...自己?" ) or "它需要充电了!"
	end
	
	inst:PushEvent("powertrans",{former = inst,power = 0})
	inst:DoPeriodicTask(1,function()
		inst:PushEvent("powertrans",{former = inst,power = -10})
		if inst.building_power > 10 and inst.components.health:IsHurt() then 
			inst:PushEvent("powertrans",{former = inst,power = -10})
			inst.components.health:DoDelta(5)
		end
	end)
	inst:ListenForEvent("powertrans",CheckPower)

	OnPhaseChange(inst,TheWorld.state.phase)
   --[[ inst.components.finiteuses:SetMaxUses(TUNING.TENT_USES)
    inst.components.finiteuses:SetUses(TUNING.TENT_USES)--]]
	inst:WatchWorldState("phase", OnPhaseChange)
	inst:ListenForEvent("death",onhammered)
    return inst
end



return Prefab("icey_tent", tent, tent_assets),
    MakePlacer("icey_tent_placer", "icey_tent", "icey_tent", "idle")
  