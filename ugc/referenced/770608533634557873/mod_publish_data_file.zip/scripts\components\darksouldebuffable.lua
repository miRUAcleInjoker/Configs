local function onenable(self, enable)
    if enable then
        self.inst:AddTag("darksouldebuffable")
    else
        self.inst:RemoveTag("darksouldebuffable")
    end
end

local DarkSoulDebuffable = Class(function(self, inst)
    self.inst = inst
    self.enable = true
    self.followsymbol = ""
    self.followoffset = Vector3(0, 0, 0)
    self.debuffs = {}

    --V2C: Recommended to explicitly add tag to prefab pristine state
    --inst:AddTag("DarkSoulDebuffable")
	
	self.inst:StartUpdatingComponent(self)
end,
nil,
{
    enable = onenable,
})

function DarkSoulDebuffable:IsEnabled()
    return self.enable
end

function DarkSoulDebuffable:Enable(enable)
    self.enable = enable
    if not enable then
        local k = next(self.debuffs)
        while k ~= nil do
            self:RemoveDebuff(k)
            k = next(self.debuffs)
        end
    end
end

function DarkSoulDebuffable:RemoveOnDespawn()
    local toremove = {}
    for k, v in pairs(self.debuffs) do
        if not (v.inst.components.darksouldebuff ~= nil and v.inst.components.darksouldebuff.keepondespawn) then
            table.insert(toremove, k)
        end
    end
    for i, v in ipairs(toremove) do
        self:RemoveDebuff(v)
    end
end

function DarkSoulDebuffable:SetFollowSymbol(symbol, x, y, z)
    self.followsymbol = symbol
    self.followoffset.x = x
    self.followoffset.y = y
    self.followoffset.z = z
    for k, v in pairs(self.debuffs) do
        if v.inst.components.darksouldebuff ~= nil then
            v.inst.components.darksouldebuff:AttachTo(k, self.inst, symbol, self.followoffset)
        end
    end
end

function DarkSoulDebuffable:HasDebuff(name)
    return self.debuffs[name] ~= nil
end

function DarkSoulDebuffable:GetDebuff(name)
    local debuff = self.debuffs[name]
    return debuff ~= nil and debuff.inst or nil
end

local function RegisterDebuff(self, name, ent)
    if ent.components.darksouldebuff ~= nil then
        self.debuffs[name] =
        {
            inst = ent,
            onremove = function() self.debuffs[name] = nil end,
        }
        self.inst:ListenForEvent("onremove", self.debuffs[name].onremove, ent)
        ent.persists = false
        ent.components.darksouldebuff:AttachTo(name, self.inst, self.followsymbol, self.followoffset)
    else
        ent:Remove()
    end
end

function DarkSoulDebuffable:AddDebuff(name, prefab,percent)
    if self.enable then
		percent = percent or 1 
		if self.debuffs[name] == nil then
			local ent = SpawnPrefab(prefab)
			ent.components.darksouldebuff.percent = percent
			if ent ~= nil then
				RegisterDebuff(self, name, ent)
			end
		else
			self.debuffs[name].inst.components.darksouldebuff:Extend(percent,self.followsymbol, self.followoffset)
		end
		
		--[[local ent_buff = self.debuffs[name].inst
		local activated = ent_buff.components.darksouldebuff:IsActivated()--]]
	
		--self:AddDebuffReplica(name,ent_buff,percent,activated)
    end
	
end

function DarkSoulDebuffable:RemoveDebuff(name)
    local debuff = self.debuffs[name]
    if debuff ~= nil then
        self.debuffs[name] = nil
        self.inst:RemoveEventCallback("onremove", debuff.onremove, debuff.inst)
        if debuff.inst.components.darksouldebuff ~= nil then
            debuff.inst.components.darksouldebuff:OnDetach()
        else
            debuff.inst:Remove()
        end
		--self:RemoveDebuffReplica(name)
    end
end

function DarkSoulDebuffable:OnSave()
    if next(self.debuffs) == nil then
        return
    end

    local data = {}
    for k, v in pairs(self.debuffs) do
        local saved--[[, refs]] = v.inst:GetSaveRecord()
        data[k] = saved
    end
    return { debuffs = data }
end

function DarkSoulDebuffable:OnLoad(data)
    if data ~= nil and data.debuffs ~= nil then
        for k, v in pairs(data.debuffs) do
            if self.debuffs[k] == nil then
                local ent = SpawnSaveRecord(v)
                if ent ~= nil then
                    RegisterDebuff(self, k, ent)
					if ent.components.darksouldebuff:IsActivated() then 
						ent.components.darksouldebuff:Activated(self.followsymbol, self.followoffset)
					end
                end
            end
        end
    end
end


--[[ self.debuffs[name] =
        {
            inst = ent,
            onremove = function() self.debuffs[name] = nil end,
        }--]]
--[[function DarkSoulDebuffable:CopyForReplica(cleardirty)
	local replica = self.inst.replica.darksouldebuffable
	
	if cleardirty then 
		replica:ClearAll()
	end 
	
	
	for name,v in pairs(self.debuffs) do 
		local ent = v.inst
		local prefabname = ent.prefab
		local percent = ent.components.darksouldebuff:GetPercent()
		local activated = ent.components.darksouldebuff:IsActivated()
		--replica:AddDebuff(name,percent,activated)
		self:AddDebuffReplica(name,ent,percent,activated)
	end
end 

function DarkSoulDebuffable:AddDebuffReplica(name,ent_buff,percent,activated)
	--print("DarkSoulDebuffable:AddDebuffReplica")
	self.inst.replica.darksouldebuffable:AddDebuff(name,ent_buff,percent,activated)
end 

function DarkSoulDebuffable:RemoveDebuffReplica(name)
	--print("DarkSoulDebuffable:RemoveDebuffReplica")
	self.inst.replica.darksouldebuffable:RemoveDebuff(name)
end --]]


function DarkSoulDebuffable:OnUpdate()
	--self:CopyForReplica()
end 


function DarkSoulDebuffable:GetDebugString()
	local str = "Num Buffs: " .. tostring(GetTableSize(self.debuffs))
	
    for k, v in pairs(self.debuffs) do
		str = str .. "\n  " .. tostring(v.inst.prefab)
	end
		
	return str
end

return DarkSoulDebuffable
