require "prefabutil"

local assets =
{
    Asset("ANIM", "anim/pighouse_blood.zip"),
    Asset("SOUND", "sound/pig.fsb"),
}

local ly_people = 
{
	"wilson",
	"wathgrithr",
	"wendy",
	"wes",
	"waxwell",
	"webber",
	"wolfgang",
	"wickerbottom",
	"willow",
	"winona",
	"woodie",
	"wx78",
}

local function SpawnInfecteds(inst)
	local x,y,z = inst:GetPosition():Get()
	local ents = TheSim:FindEntities(x,y,z,20,{"_combat","infected"})
	local people = TheSim:FindEntities(x,y,z,50,{"_combat","player"})
	if #ents > 5 or #people <= 0 then 
		return
	end 
	local infected = SpawnPrefab(ly_people[math.random(1,#ly_people)].."_infected")
	infected.Transform:SetPosition(x,y,z)
	return infected
end

local function onhammered(inst, worker)
    inst.components.lootdropper:DropLoot()
    local fx = SpawnPrefab("collapse_big")
    fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
    fx:SetMaterial("wood")
    inst:Remove()
end

local function onhit(inst, worker)
    inst.AnimState:PlayAnimation(inst.hitanim)
	inst.AnimState:PushAnimation(inst.idleanim)
	local day = TheWorld.state.phase
	if TheWorld:HasTag("cave") then 
		day = "dusk"
	end
	if day == "dusk" or day == "night" then 
		inst.components.childspawner:StartSpawning()
		for i = 1,math.random(0,3) do 
			local protecter = SpawnInfecteds(inst)
			if protecter and protecter.components.combat then 
				protecter.components.combat:SetTarget(worker)
			end
		end 
	end
end

local function onsave(inst, data)
  
end

local function onload(inst, data)
   
end

local function beat(inst)
    inst.SoundEmitter:PlaySound("dontstarve/ghost/bloodpump")
    inst.beattask = inst:DoTaskInTime(0.5, beat)
end

 

local function OnChange(inst)
	local day = TheWorld.state.phase
	if TheWorld:HasTag("cave") then 
		day = "dusk"
	end
	if day == "dusk" or day == "night" then 
		inst:DoTaskInTime(math.random(30,60),function()
			if TheWorld:HasTag("cave") or TheWorld.state.phase == "dusk" or TheWorld.state.phase == "night" then 
				inst.components.childspawner:StartSpawning()
			end 
		end)
		if inst.extra_spawne_task == nil then 
			inst.extra_spawne_task = inst:DoPeriodicTask(math.random()*2 + 5,function()SpawnInfecteds(inst)end)
		end 
	else
		inst.components.childspawner:StopSpawning()
		if inst.extra_spawne_task ~= nil then
			inst.extra_spawne_task:Cancel()
			inst.extra_spawne_task = nil 
		end 
	end
end 

local function common(bank,build,anim,hitanim,beatfn)
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddLight()
    inst.entity:AddSoundEmitter()
    inst.entity:AddMiniMapEntity()
    inst.entity:AddNetwork()
    inst.entity:AddLightWatcher()

    MakeObstaclePhysics(inst, 1)

    inst.MiniMapEntity:SetIcon("pighouse_blood.png")
--{anim="level1", sound="dontstarve/common/campfire", radius=2, intensity=.75, falloff=.33, colour = {197/255,197/255,170/255}},

    inst.AnimState:SetBank(bank)
    inst.AnimState:SetBuild(build)
    inst.AnimState:PlayAnimation(anim, true)
	
    inst:AddTag("structure")
	inst:AddTag("tadalin")
	
    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst:AddComponent("lootdropper")
    inst:AddComponent("workable")
    inst.components.workable:SetWorkAction(ACTIONS.HAMMER)
    inst.components.workable:SetWorkLeft(10)
    inst.components.workable:SetOnFinishCallback(onhammered)
    inst.components.workable:SetOnWorkCallback(onhit)

    inst:AddComponent("childspawner")
    inst.components.childspawner.childname = "pigman_infected"
    inst.components.childspawner:SetRegenPeriod(360)
    inst.components.childspawner:SetSpawnPeriod(60)
    inst.components.childspawner:SetMaxChildren(1)
    inst.components.childspawner:StopSpawning()---------------先不开始执行

    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("天呐,它们对这屋子做了什么？！")
	
	if beatfn then 
		beatfn(inst)
	end
	
	inst.idleanim = anim or "idle"
	inst.hitanim = hitanim or "hit"
    inst.OnSave = onsave 
    inst.OnLoad = onload
	
	OnChange(inst)
	inst:WatchWorldState("startday", OnChange)
	inst:WatchWorldState("startdusk", OnChange)

    return inst
end

local function fn_pig()
    local inst = common("pighouse_blood","pighouse_blood","idle","hit",beat)

    return inst
end

local function fn_merm()
    local inst = common("pighouse_blood","pighouse_blood","idle_merm","hit_merm",beat)

    return inst
end

return Prefab("pighouse_blood", fn_pig, assets),
Prefab("mermhouse_blood", fn_merm, assets)
