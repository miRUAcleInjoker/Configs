local IceyUtil = require("icey_util")

local brain = require("brains/dantalion_brain")

local assets=
{
	Asset("ANIM", "anim/book_maxwell.zip"),
	Asset("ANIM", "anim/ancient_spirit.zip"),
    Asset("SOUND", "sound/together.fsb"),
}

local function OnRemove(pet)
	local x,y,z = pet.Transform:GetWorldPosition()
	local soul = SpawnAt("dark_antqueen_soul",Vector3(x,y,z))
end 

local function commonfn(Sim)
	local inst = CreateEntity()
	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddSoundEmitter()
	inst.entity:AddNetwork()
	
	MakeInventoryPhysics(inst)
	RemovePhysicsColliders(inst)
	
	inst.Transform:SetSixFaced()
	
	inst.AnimState:SetBank("ancient_spirit")
	inst.AnimState:SetBuild("ancient_spirit")
	inst.AnimState:PlayAnimation("idle",true)
	
	inst.AnimState:SetFinalOffset(-1)
	
	inst.Transform:SetScale(0.35,0.35,0.35)
	inst.AnimState:HideSymbol("spirit_tail")
	inst.AnimState:HideSymbol("spirit_part")
	inst.AnimState:HideSymbol("spirit_black")
	--


	inst:AddTag("companion")
	inst:AddTag("critter")
	inst:AddTag("notraptrigger")
    inst:AddTag("noauradamage")
    inst:AddTag("small_livestock")
    inst:AddTag("NOBLOCK")
	
	inst.entity:SetPristine()
    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.LastSongTime = 0
	
	inst.CanSong = function(inst)
		local leader = inst.components.follower and inst.components.follower.leader
		return (GetTime() - inst.LastSongTime >= 25) and leader and leader:IsValid() 
			and (leader.components.health == nil or not (leader:HasTag("playerghost") or leader.components.health:IsDead())) 
	end 
	
	inst.DoSong = function(inst,target)
		local leader = inst.components.follower and inst.components.follower.leader
		target = target or leader
		
		if target then 
			--[[if not target.components.debuffable then 
				target:AddComponent("debuffable")
			end 
	
			target.components.debuffable:AddDebuff("buff_dantalion", "buff_electricattack")
			local buff = target.components.debuffable:GetDebuff("buff_dantalion")
			buff:DoTaskInTime(0,function()
				buff.components.timer:StopTimer("buffover")
				buff.components.timer:StartTimer("buffover", 15)
			end)--]]
			
			if not target.components.darksouldebuffable then 
				target:AddComponent("darksouldebuffable")
			end 
	
			target.components.darksouldebuffable:AddDebuff("dantalion_atkbuff", "dantalion_atkbuff")
			
			--dantalion_atkbuff
			inst.LastSongTime = GetTime()
		end
	end 

	
	inst:AddComponent("age")
    inst:AddComponent("knownlocations")
	inst:AddComponent("bloomer")
    inst:AddComponent("colouradder")
	inst:AddComponent("timer")
	
	inst:AddComponent("crittertraits")
	inst.components.crittertraits:SetOnAbandonedFn(OnRemove)
	local old_OnPet = inst.components.crittertraits.OnPet
	inst.components.crittertraits.OnPet = function(self,petter)
		self.inst:PushEvent("pre_critter_onpet")
		if self.inst.sg:HasStateTag("sleeping") 
		or not ( 
			self.inst.sg:HasStateTag("busy") 
			or self.inst.sg:HasStateTag("working")
			or (self.inst:GetBufferedAction() and self.inst:GetBufferedAction():IsValid())
		) then 
			old_OnPet(self,petter)
		end 
	end 
	
	
	inst:AddComponent("locomotor") -- locomotor must be constructed before the stategraph
    inst.components.locomotor.walkspeed = 10
    inst.components.locomotor.runspeed = 10
	inst.components.locomotor:EnableGroundSpeedMultiplier(false)
    inst.components.locomotor:SetTriggersCreep(false)
    inst.components.locomotor.softstop = true
    inst.components.locomotor.pathcaps = { allowocean = true }
	
	inst:AddComponent("follower")
    inst.components.follower:KeepLeaderOnAttacked()
    inst.components.follower.keepdeadleader = true
	inst.components.follower.keepleaderduringminigame = true
	
	inst:AddComponent("combat")
    inst.components.combat.defaultdamage = 68
	inst.components.combat:SetRange(15,15)
	inst.components.combat:SetAttackPeriod(4)
    --inst.components.combat:SetRetargetFunction(3, Retarget)
	--inst.components.combat:SetKeepTargetFunction(KeepTarget)
	inst.components.combat:EnableAreaDamage(false) 

	inst:AddComponent("inspectable")

	inst:SetStateGraph("SGwaxwelljournal_dantalion")
	inst:SetBrain(brain)
	
	--inst.book = SpawnPrefab("waxwelljournal_dantalion_book")
	--inst.book.entity:AddFollower()
    --inst.book.Follower:FollowSymbol(inst.GUID, "spirit_black", 0, 300, 0)
	inst.book = inst:SpawnChild("waxwelljournal_dantalion_book")
	inst.book.Transform:SetScale(3.3,3.3,3.3)
	--
	--inst.book.Transform:SetPosition(0,1,0)
	--inst.book.Transform:SetScale(3.3,3.3,3.3)

	IceyUtil.MakeIceyAlly(inst) 
	
	return inst
end
-------------------------------------------------------------------------------
local function BookFn()
	local inst = CreateEntity()
	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddSoundEmitter()
	inst.entity:AddNetwork()
	
	MakeInventoryPhysics(inst)
	RemovePhysicsColliders(inst)
	
	
	
	inst.AnimState:SetBank("book_maxwell")
	inst.AnimState:SetBuild("book_maxwell")
	inst.AnimState:PlayAnimation("proximity_loop",true)
	
	
	
	inst.AnimState:HideSymbol("shadow")
	
	inst:AddTag("NOCLICK")
    inst:AddTag("NOBLOCK")
	
	inst.entity:SetPristine()
    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.persists = false 
	
	inst.DoSleepAnim = function(inst)
		inst.AnimState:PlayAnimation("proximity_pst")
	end 
	
	inst.DoSleepingAnim = function(inst)
		inst.AnimState:PlayAnimation("idle",true)
	end 
	
	inst.DoWakeAnim = function(inst)
		inst.AnimState:PlayAnimation("proximity_pre")
	end 
	
	
	return inst
end 

-------------------------------------------------------------------------------
local function builder_onbuilt(inst, builder)
    local theta = math.random() * 2 * PI
    local pt = builder:GetPosition()
    local radius = 1
    local offset = FindWalkableOffset(pt, theta, radius, 6, true)
    if offset ~= nil then
        pt.x = pt.x + offset.x
        pt.z = pt.z + offset.z
    end
    builder.components.petleash:SpawnPetAt(pt.x, 0, pt.z, inst.pettype, inst.linked_skinname)
    inst:Remove()
end

local function MakeBuilder(prefab)
    local function fn()
        local inst = CreateEntity()

        inst.entity:AddTransform()

        inst:AddTag("CLASSIFIED")

        --[[Non-networked entity]]
        inst.persists = false

        --Auto-remove if not spawned by builder
        inst:DoTaskInTime(0, inst.Remove)

        if not TheWorld.ismastersim then
            return inst
        end

        inst.pettype = prefab
        inst.OnBuiltFn = builder_onbuilt

        return inst
    end

    return Prefab(prefab.."_builder", fn, nil, { prefab })
end
-------------------------------------------------------------------------------

return Prefab( "waxwelljournal_dantalion", commonfn, assets),
Prefab( "waxwelljournal_dantalion_book", BookFn, assets),
MakeBuilder("waxwelljournal_dantalion")
