local assets =
{ 
    Asset("ANIM", "anim/icey_armor2.zip"),
    --Asset("ANIM", "anim/icey_armor_swap.zip"), 

    Asset("ATLAS", "images/inventoryimages/icey_armor2.xml"),
    Asset("IMAGE", "images/inventoryimages/icey_armor2.tex"),
}

local SHADOW_ATTACK_CD = 10 

local function SpawnShadowsAttack(attacker,target)
	if attacker.components.combat:CanAttack(target) then 
		local weapon = attacker.components.combat:GetWeapon()
		local damage = weapon and weapon.components.weapon.damage or 10
			
		local fulldamage = damage * math.random(7,12)
		local newnums = math.random(4,6)
		local newdamage = fulldamage / newnums
		local roa_little = math.random()*2*math.pi
			
		local sleeptime = math.min(0.1,0.4/newnums)
		local rad = 4.5
		attacker:StartThread(function()
			for roa = roa_little,2*math.pi + roa_little,2*math.pi/newnums  do
				local pos = target:GetPosition()
				local offset = Vector3(math.cos(roa)*rad,0,math.sin(roa)*rad)
				local shadow = SpawnPrefab("icey_shadow3")
				shadow:SetPosition(pos,offset)
				shadow:SetDamage(newdamage)
				shadow:SetTarget(target)
				shadow:Init(attacker)
				local nx,nv,nz = (pos+offset):Get()
				--print("multhit! roa =",roa,"nx,ny,nz =",nx,nv,nz)
				Sleep(sleeptime)
			end
		end)
	end
end 

local function onhitother(inst,data)
	local target = data.target
	local damage = data.damage or 0
	local armor = inst.components.inventory and inst.components.inventory:GetEquippedItem(EQUIPSLOTS.BODY)
	if not armor or armor.prefab ~= "icey_armor2" then 
		return 
	end 
	armor.AttackDamages = armor.AttackDamages + damage
	if armor.AttackDamages >= 1500 and GetTime() - armor.LastShadowAttackTime >= SHADOW_ATTACK_CD
	and target and target:IsValid() then 
		SpawnShadowsAttack(inst,target)
		armor.AttackDamages = 0
		armor.LastShadowAttackTime = GetTime()
	end 
end 

local function OnEquip(inst, owner) 
	if owner:HasTag("icey") then 
		inst:ListenForEvent("onhitother",onhitother,owner)
	end 
end

local function OnUnequip(inst, owner) 
	inst.AttackDamages = 0
	if owner:HasTag("icey") then 
		inst:RemoveEventCallback("onhitother",onhitother,owner)
	end 
end

local function fn()

    local inst = CreateEntity()
    local trans = inst.entity:AddTransform()
	
    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()  --这个联机也必须加 
	
    MakeInventoryPhysics(inst)
	inst.entity:AddMiniMapEntity()
	
    inst:AddTag("armor")
	inst:AddTag("hide_percentage")
	
	inst.AnimState:SetBank("icey_armor2")
    inst.AnimState:SetBuild("icey_armor2")
    inst.AnimState:PlayAnimation("idle")
	
	inst.Transform:SetScale(0.6,0.6,0.6)
	
	
	----------------------上面的东西 对主副机都有效
	
	inst.entity:SetPristine()   --这四句话 放到这里 也就是bank build 和tag之类的后面-。-
	if not TheWorld.ismastersim then
        return inst
    end
	
	inst.LastShadowAttackTime = GetTime() 
	inst.AttackDamages = 0
	
	----------------------下面的只对主机执行
	inst:AddComponent("chosenicey")
	
    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("影分身！瞬！")
	
	inst:AddComponent("waterproofer")
	inst.components.waterproofer:SetEffectiveness(TUNING.WATERPROOFNESS_SMALL)


    inst:AddComponent("inventoryitem")
    inst.components.inventoryitem.imagename = "icey_armor2"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/icey_armor2.xml"
	
	inst:AddComponent("armor")
    inst.components.armor:InitIndestructible(0.50)
	
    inst:AddComponent("equippable")
    inst.components.equippable.equipslot = EQUIPSLOTS.BODY
    inst.components.equippable:SetOnEquip(OnEquip)
    inst.components.equippable:SetOnUnequip(OnUnequip)
	
	MakeHauntableLaunch(inst)  --这个放后面就好了
	
    return inst
end

return  Prefab("common/inventory/icey_armor2", fn, assets, prefabs)