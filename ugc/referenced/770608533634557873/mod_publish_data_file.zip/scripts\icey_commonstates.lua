local function SGAttackOnEnterServer(inst,cooldown,anims,is_creature,target_override)
	if not is_creature then 
		local buffaction = inst:GetBufferedAction()
		local target = buffaction ~= nil and buffaction.target or nil
		local equip = inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
		inst.components.combat:SetTarget(target)
		inst.components.combat:StartAttack()
		inst.components.locomotor:Stop()
		
		if target ~= nil then
			inst.components.combat:BattleCry()
			if target:IsValid() then
				inst:FacePoint(target:GetPosition())
				inst.sg.statemem.attacktarget = target
			end
		end
		inst.sg.statemem.weapon = equip
	else
		if inst.components.locomotor ~= nil then
            inst.components.locomotor:StopMoving()
        end
		inst.components.combat:StartAttack()
		
		if target_override:IsValid() then
			inst:FacePoint(target_override:GetPosition())
			inst.sg.statemem.target = target_override
		end
	end 
	
	--"attack"
	--[[anims = {
		--animname = {ispush,iscycle},
		attack = {false,false},
	}--]]
	
	if anims then 
		if type(anims) == "string" then 
			inst.AnimState:PlayAnimation(anims)
		elseif type(anims) == "table" then 
			for animname,v in pairs(anims) do 
				local ispush,iscycle = v[1],v[2]
				if ispush then 
					inst.AnimState:PushAnimation(animname,iscycle)
				else
					inst.AnimState:PlayAnimation(animname,iscycle)
				end
			end
		end
	end 
	
	
	
	if cooldown and cooldown > 0 then
        inst.sg:SetTimeout(cooldown)
    end
end

local function SGAttackOnEnterClient(inst,cooldown,anims)
    if inst.replica.combat ~= nil then
        inst.replica.combat:StartAttack()
    end
    inst.components.locomotor:Stop()
    local equip = inst.replica.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
	
	local buffaction = inst:GetBufferedAction()
    if buffaction ~= nil then
        inst:PerformPreviewBufferedAction()

        if buffaction.target ~= nil and buffaction.target:IsValid() then
            inst:FacePoint(buffaction.target:GetPosition())
            inst.sg.statemem.attacktarget = buffaction.target
        end
    end
	
	if anims then 
		if type(anims) == "string" then 
			inst.AnimState:PlayAnimation(anims)
		elseif type(anims) == "table" then 
			for animname,v in pairs(anims) do 
				local ispush,iscycle = v[1],v[2]
				if ispush then 
					inst.AnimState:PushAnimation(animname,iscycle)
				else
					inst.AnimState:PlayAnimation(animname,iscycle)
				end
			end
		end
	end 
	
	inst.sg.statemem.weapon = equip

    if cooldown and cooldown > 0 then
        inst.sg:SetTimeout(cooldown)
    end
end


return {
	SGAttackOnEnterServer = SGAttackOnEnterServer,
	SGAttackOnEnterClient = SGAttackOnEnterClient,
}