
--[[local tasks = GLOBAL.require("map/tasks")
local constants = GLOBAL.require("constants")--]]
local dlc = GetModConfigData("icey_dlcs")
local g=GLOBAL
local AddTask=g.AddTask
local AddRoom=g.AddRoom
local LOCKS=g.LOCKS
local KEYS=g.KEYS
local GROUND=g.GROUND
local NODE_INTERNAL_CONNECTION_TYPE = g.NODE_INTERNAL_CONNECTION_TYPE
local require = g.require
local blockersets = require("map/blockersets")
local StaticLayout = require("map/static_layout")
local Layouts = GLOBAL.require("map/layouts").Layouts

Layouts["reeds_flup"] = StaticLayout.Get("tiled/reeds_flup")


AddRoom("jade_room", {
    colour={r=.1,g=.8,b=.1,a=.50},
    value = GROUND.FOREST,
    contents =  {
        countprefabs = {
			jade = 1,
			evergreen = 25,
        },
        distributepercent = 0.5,
    },
})

AddRoom("flytrap_room", {
    colour={r=.1,g=.8,b=.1,a=.50},
    value = GROUND.FOREST,
    contents =  {
        countprefabs = {
			adult_flytrap = math.random(2,4),
			mean_flytrap = math.random(5,7),
			--evergreen_sparse = math.random(40,50),
			--evergreen = math.random(35,39),
			livingtree = 1,
        },
		distributeprefabs= {
            fireflies = 0.2,
			rock1 = 0.05,
			grass = .05,
			sapling=.8,
			twiggytree = 0.8,
			ground_twigs = 0.06,						                    
			molehill=.3,
			berrybush=.03,
			berrybush_juicy = 0.015,
			red_mushroom = .03,
			green_mushroom = .02,
			trees = {weight = 6, prefabs = {"evergreen", "evergreen_sparse"}}
		},
        distributepercent = 0.5,
    },
	
})


AddRoom("spider_higher_room", {
    colour={r=.1,g=.8,b=.1,a=.50},
    value = GROUND.MARSH,
    contents =  {
        countprefabs = {
			spider_higher = 1,
			tadalin_tower = function() return math.random(1,3) end ,
			pighouse_blood = function() return math.random(1,4) end ,
        },
        distributepercent = 0.5,
    },
})

AddRoom("blood_room", {
    colour={r=.1,g=.8,b=.1,a=.50},
    value = GROUND.MARSH,
    contents =  {
        countprefabs = {
            pighouse_blood = function() return math.random(1,2) end ,
			mermhouse_blood = function() return math.random(1,2) end ,
			pighead = function() return math.random(1,4) end ,
			skeleton = function() return math.random(2,5) end ,
			houndbone = function() return math.random(1,7) end ,
        },
        distributepercent = 0.7,
        distributeprefabs= {
            rock1=0.004,
            rock2=0.004,
            evergreen=4.5,
            fireflies=0.1,
            blue_mushroom = .025,
            green_mushroom = .005,
            red_mushroom = .005,
        },
    },
})

AddRoom("crystal_mine", {
	locks={LOCKS.TIER1},
	keys_given={KEYS.ROCKS, KEYS.GOLD,KEYS.TIER2},
    value = GROUND.ROCKY,
    contents =  {
        countprefabs = {
			rock1        = function() return math.random(1,5) end, 
			rock2        = function() return math.random(1,5) end, 
            rock_crystal = function() return math.random(5,10) end, 
			crystal_item = function() return math.random(0,10) end, 
        },
    },
	room_bg=GROUND.ROCKY,
	background_room="BGRocky",
	colour={r=1,g=1,b=0,a=1}
})
					
					

AddRoom("pog_and_beefalo", {
    value = GROUND.SAVANNA,
	contents =  {
		distributepercent = .05,
		distributeprefabs= {
			grass = .01,
			pog = 0.02,
			beefalo = 0.02,
		},
		countprefabs = {
			pogherd = 1,
			beefalo = 3,
		},
	},		
	room_bg=GROUND.SAVANNA,
	colour={r=.45,g=.5,b=.85,a=.50},
})

AddRoom("battleground_ribs", {
	colour={r=1.0,g=1.0,b=1.0,a=0.3},
	value = GROUND.DESERT_DIRT,
	contents =  {
		distributepercent = .22, -- .22, --.26
		distributeprefabs = {		
			marsh_tree = 0.1,
			marsh_bush = 0.25,
			flower = 0.7,
			scorchedground = 0.5,
			charcoal = 0.5,
			iron = 1,
			deciduoustree_burnt = 1,
			evergreen_burnt = 1,
			knight = 0.25,
			rook = 0.1,
			bishop = 0.2,
		},
		countprefabs = {
			ancient_robot_ribs = 1,
		},
	}
})

AddRoom("battleground_claw", {
	colour={r=1.0,g=1.0,b=1.0,a=0.3},
	value = GROUND.DESERT_DIRT,
	contents =  {
		distributepercent = .22, -- .22, --.26
		distributeprefabs = {		
			marsh_tree = 0.1,
			marsh_bush = 0.25,
			flower = 0.7,
			scorchedground = 0.5,
			charcoal = 0.5,
			iron = 1,
			deciduoustree_burnt = 1,
			evergreen_burnt = 1,
			knight = 0.25,
			rook = 0.1,
			bishop = 0.2,
		},
		countprefabs = {
			ancient_robot_claw = 1,
		},
	}
})

AddRoom("battleground_leg", {
	colour={r=1.0,g=1.0,b=1.0,a=0.3},
	value = GROUND.DESERT_DIRT,
	contents =  {
		distributepercent = .22, -- .22, --.26
		distributeprefabs = {		
			marsh_tree = 0.1,
			marsh_bush = 0.25,
			flower = 0.7,
			scorchedground = 0.5,
			charcoal = 0.5,
			iron = 1,
			deciduoustree_burnt = 1,
			evergreen_burnt = 1,
			knight = 0.25,
			rook = 0.1,
			bishop = 0.2,
		},
		countprefabs = {
			ancient_robot_leg = 1,
		},
	}
})

AddRoom("battleground_head", {
	colour={r=1.0,g=1.0,b=1.0,a=0.3},
	value = GROUND.DESERT_DIRT,
	contents =  {
		distributepercent = .22, -- .22, --.26
		distributeprefabs = {		
			marsh_tree = 0.1,
			marsh_bush = 0.25,
			flower = 0.7,
			scorchedground = 0.5,
			charcoal = 0.5,
			iron = 1,
			deciduoustree_burnt = 1,
			evergreen_burnt = 1,
			knight = 0.25,
			rook = 0.1,
			bishop = 0.2,
		},
		countprefabs = {
			ancient_robot_head = 1,
		},
	}
})

AddRoom("FlupMarsh", {
	colour={r=.6,g=.2,b=.8,a=.50},
	value = GROUND.MARSH,
	tags = {"ExitPiece", "Chester_Eyebone"},
	contents =  {
		countstaticlayouts={
			["MushroomRingMedium"] = function()  
				if math.random(0,1000) > 985 then 
					return 1 
				end
				return 0 
			end,
			
			["WeaponBoon"] = function()  
				return math.random(0,1000) >= 750 and 1 or 0 
			end,
			
			["Level2GrassBoon"] = function()  
				return math.random(0,1000) >= 750 and 1 or 0 
			end,
			
			["Level2TwigsBoon"] = function()  
				return math.random(0,1000) >= 750 and 1 or 0 
			end,
			
			["MiscBoon"] = function()  
				return math.random(0,1000) >= 800 and 1 or 0 
			end,
			
			["Level4Boon"] = function()  
				return math.random(0,1000) >= 900 and 1 or 0 
			end,
			
			["Level2WoodBoon"] = function()  
				return math.random(0,1000) >= 850 and 1 or 0 
			end,
			
			["reeds_flup"] = function()  
				if math.random(0,1000) > 850 then 
					return 1 
				end
				return 0 
			end,
		},
		distributepercent = .25,
		distributeprefabs=
			{
				sapling=0.0001,
				twiggytree = 0.0001,
				ground_twigs = 0.00003,				
				pond_mos=0.005,
				reeds=0.005,
				tentacle=0.095,
				flup=0.2,
				marsh_bush=0.05,
				marsh_tree=0.1,
				blue_mushroom = .01,
			},
    }
})

--[[AddRoom("GuiltyCityRooms",  { -- layout contents determined by maze
    colour={r=0.3,g=0.2,b=0.1,a=0.3},
    value = GROUND.ROCKY,
    --tags = {"ForceDisconnected", "Maze", "RoadPoison"},
    --internal_type = NODE_INTERNAL_CONNECTION_TYPE.EdgeCentroid,
	contents =  {
        countprefabs = {
			icey_boarrior = 1,
        },
    },
})

AddTask("GuiltyCity", {
    locks={LOCKS.RUINS},
    keys_given= {},
    room_choices =
    {
        ["GuiltyCityRooms"] = 1,
    },
    room_bg = GROUND.ROCKY,
    background_room="Clearing", 
    colour={r=0.6,g=0.6,b=0.0,a=1},
})--]]


AddTask("Get lots crystals", {
	locks={LOCKS.TIER1},
	keys_given={KEYS.ROCKS, KEYS.GOLD,KEYS.TIER2},
    value = GROUND.ROCKY,
    room_choices={
        ["crystal_mine"] = 6,
    },
	room_bg=GROUND.ROCKY,
	background_room="BGRocky",
	colour={r=1,g=1,b=0,a=1}
})

AddTask("bloodcity1",{
	locks=LOCKS.NONE,
	keys_given={KEYS.TIER1},
    room_choices={
        ["blood_room"] = 12,
		["spider_higher_room"] = 1,
    },
	room_bg=GROUND.MARSH,
	background_room="Clearing",
    colour={r=.1,g=.8,b=.1,a=.50},
})


AddTask("jadecity1",{
	locks=LOCKS.NONE,
	keys_given={KEYS.TIER1},
    room_choices={
		["jade_room"] = 1,
    },
	room_bg=GROUND.FOREST,
	background_room="Clearing",
    colour={r=.1,g=.8,b=.1,a=.50},
})

AddTask("flytrap_forest",{
	locks={LOCKS.ADVANCED_COMBAT,LOCKS.MONSTERS_DEFEATED},
	keys_given={KEYS.WALRUS,KEYS.TIER5},
    room_choices={
		["flytrap_room"] = 10,
    },
	room_bg=GROUND.FOREST,
	background_room="Clearing",
    colour={r=.1,g=.8,b=.1,a=.50},
})

AddTask("pog_and_beefalo_Plains", {
	locks={LOCKS.ADVANCED_COMBAT,LOCKS.TIER3},
	keys_given={KEYS.MEAT,KEYS.WOOL,KEYS.POOP,KEYS.WALRUS,KEYS.TIER4},
	room_choices={
		["pog_and_beefalo"] = function() return 3 + math.random(3) end, 		
			--["Wormhole_Plains"] = 1,
		["WalrusHut_Plains"] = 1,
		["Plain"] = function() return 1 + math.random(3) end, 
	}, 
	room_bg=GROUND.SAVANNA,
	background_room="BGSavanna",
	colour={r=0,g=1,b=1,a=1}
}) 

AddTask("ancient_robot_battleground", {
	locks={LOCKS.ADVANCED_COMBAT},
	keys_given={KEYS.TIER1},
	room_choices={
		["battleground_ribs"] = 1,
		["battleground_claw"] = 2,
		["battleground_leg"] = 2,
		["battleground_head"] = 1,
	}, 
	room_bg=GROUND.DESERT_DIRT,
	background_room="Clearing",
	colour={r=1.0,g=1.0,b=1.0,a=0.3},
}) 

AddTask("Flange fortress", {
		locks={LOCKS.SPIDERDENS,LOCKS.TIER2},
		keys_given={KEYS.MEAT,KEYS.SILK,KEYS.SPIDERS,KEYS.TIER2},
		entrance_room_chance=0.7,
		entrance_room=blockersets.all_marsh,
		room_choices={
			--["Wormhole"] = 1,
			["FlupMarsh"] = function() return 12 end, 
			["Marsh"] = function() return 4 end, 
			["SpiderMarsh"] = function() return 1 end,
			["SlightlyMermySwamp"]=1,
		},
		room_bg=GROUND.MARSH,
		background_room="BGMarsh",
		colour={r=.05,g=.05,b=.05,a=1}
	}) 


--


local function Add_Blood_Cities()	
	AddTaskSetPreInit("default", function(tasksetdata)
		if type(tasksetdata)=="table" and type(tasksetdata.tasks)=="table" then
			local tab=
			{
				"bloodcity1",
			}
			for k,v in pairs(tab) do
				if v then
					table.insert(tasksetdata.tasks, v)
				end
			end
		end
	end)
end

local function Add_Jade_forest()
	AddTaskSetPreInit("default", function(tasksetdata)
		if type(tasksetdata)=="table" and type(tasksetdata.tasks)=="table" then
			local tab=
			{
				"jadecity1",
			}
			for k,v in pairs(tab) do
				if v then
					table.insert(tasksetdata.tasks, v)
				end
			end
		end
	end)
end 

local function Add_Crystals()
	AddTaskSetPreInit("default", function(tasksetdata)
		if type(tasksetdata)=="table" and type(tasksetdata.tasks)=="table" then
			local tab=
			{
				"Get lots crystals",
			}
			for k,v in pairs(tab) do
				if v then
					table.insert(tasksetdata.tasks, v)
				end
			end
		end
	end)
end

local function Add_Flytraps()
	AddTaskSetPreInit("default", function(tasksetdata)
		if type(tasksetdata)=="table" and type(tasksetdata.tasks)=="table" then
			local tab=
			{
				--"Get lots crystals",
				"flytrap_forest",
			}
			for k,v in pairs(tab) do
				if v then
					table.insert(tasksetdata.tasks, v)
				end
			end
		end
	end)
end 

local function Add_Pogs()
	AddTaskSetPreInit("default", function(tasksetdata)
		if type(tasksetdata)=="table" and type(tasksetdata.tasks)=="table" then
			local tab=
			{
				--"Get lots crystals",
				"pog_and_beefalo_Plains",
			}
			for k,v in pairs(tab) do
				if v then
					table.insert(tasksetdata.tasks, v)
				end
			end
		end
	end)
end 

local function Add_BattleGround()
	AddTaskSetPreInit("default", function(tasksetdata)
		if type(tasksetdata)=="table" and type(tasksetdata.tasks)=="table" then
			local tab=
			{
				--"Get lots crystals",
				"ancient_robot_battleground",
			}
			for k,v in pairs(tab) do
				if v then
					table.insert(tasksetdata.tasks, v)
				end
			end
		end
	end)
end 

local function Add_Flangefortress()
	AddTaskSetPreInit("default", function(tasksetdata)
		if type(tasksetdata)=="table" and type(tasksetdata.tasks)=="table" then
			local tab=
			{
				--"Get lots crystals",
				"Flange fortress",
			}
			for k,v in pairs(tab) do
				if v then
					table.insert(tasksetdata.tasks, v)
				end
			end
		end
	end)
end 

--Flange fortress

--[[local function Add_GuiltyCity()
	AddTaskSetPreInit("default", function(tasksetdata)
		if type(tasksetdata)=="table" and type(tasksetdata.tasks)=="table" then
			local tab=
			{
				"GuiltyCity",
			}
			for k,v in pairs(tab) do
				if v then
					table.insert(tasksetdata.tasks, v)
				end
			end
		end
	end)
end --]]



--AddRoomPreInit

if dlc == "WarOfZerg" then 
	Add_Blood_Cities()	
end 
Add_Jade_forest()
Add_Crystals()
Add_Flytraps()
Add_Pogs()
Add_BattleGround()
--Add_GuiltyCity()
--Add_Flangefortress()
print(dlc,"IceyDlc worldgenmain !")










