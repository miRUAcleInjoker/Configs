
--local require "stategraphs/SGpig_aiur"

local assets =
{
	Asset("SOUND", "sound/pig.fsb"),
	Asset("ANIM", "anim/pig_royalguard.zip"),
	Asset("ANIM", "anim/pig_royalguard_2.zip"),
	Asset("ANIM", "anim/pig_royalguard_3.zip"),
	Asset("ANIM", "anim/pig_royalguard_rich.zip"),
	Asset("ANIM", "anim/pig_royalguard_rich_2.zip"),
	
	Asset("ANIM", "anim/townspig_basic.zip"),
    Asset("ANIM", "anim/townspig_attacks.zip"),
    Asset("ANIM", "anim/townspig_actions.zip"),
}

local prefabs =
{
    "meat",
    "poop",
    "tophat",
    "pigskin",
    "halberd",
    "strawhat",
    "monstermeat",
    "pigcrownhat",
    "pig_scepter",
    "pigman_shopkeeper_desk",
    "pedestal_key",
    "firecrackers",
}

local MAX_TARGET_SHARES = 5
local SHARE_TARGET_DIST = 30

local function getSpeechType(inst,speech)
    local line = speech.DEFAULT

    if inst.talkertype and speech[inst.talkertype] then
        line = speech[inst.talkertype]
    end

    if type(line) == "table" then
        line = line[math.random(#line)]
    end

    return line
end

local function sayline(inst, line, mood)
    inst.components.talker:Say(line, 1.5, nil, true, mood)
end

local function ontalk(inst, script, mood)
    if inst:HasTag("guard") then
        if mood and mood == "alarmed" then
            inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/city_pig/guard_alert")
        else
            inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/city_pig/conversational_talk_gaurd","talk")
        end
    else
        if inst.female then
            if mood and mood == "alarmed" then
                inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/city_pig/scream_female")
            else
               inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/city_pig/conversational_talk_female","talk")
            end
        else
            if mood and mood == "alarmed" then
                inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/city_pig/scream")
            else
    	       inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/city_pig/conversational_talk","talk")
            end
        end
    end
end

local function SpringMod(amt)
    if GetSeasonManager() and (GetSeasonManager():IsSpring() or GetSeasonManager():IsGreenSeason()) then
        return amt * TUNING.SPRING_COMBAT_MOD
    else
        return amt
    end
end

local function CalcSanityAura(inst, observer)
	if inst.components.werebeast
       and inst.components.werebeast:IsInWereState() then
		return -TUNING.SANITYAURA_LARGE
	end
	
	if inst.components.follower and inst.components.follower.leader == observer then
		return TUNING.SANITYAURA_SMALL
	end
	
	return 0
end

local function ShouldAcceptItem(inst, item)
	return item:HasTag("securitycontract")
end

local function OnGetItemFromPlayer(inst, giver, item)
	if giver.components.leader ~= nil  then
	    giver:PushEvent("makefriend")
	    giver.components.leader:AddFollower(inst)
        inst.components.follower:AddLoyaltyTime(150*TUNING.PIG_LOYALTY_PER_HUNGER)
		inst.components.follower.maxfollowtime = giver:HasTag("polite") 
			and TUNING.PIG_LOYALTY_MAXTIME + TUNING.PIG_LOYALTY_POLITENESS_MAXTIME_BONUS
			or TUNING.PIG_LOYALTY_MAXTIME
    end
end

local function OnRefuseItem(inst, item)
    inst.sg:GoToState("refuse")
    if inst.components.sleeper:IsAsleep() then
        inst.components.sleeper:WakeUp()
    end
end

local function OnEat(inst, food)
    if food.components.edible ~= nil then
        if food.components.edible.foodtype == FOODTYPE.VEGGIE then
            SpawnPrefab("poop").Transform:SetPosition(inst.Transform:GetWorldPosition())
        elseif food.components.edible.foodtype == FOODTYPE.MEAT and
            inst.components.werebeast ~= nil and
            not inst.components.werebeast:IsInWereState() and
            food.components.edible:GetHealth(inst) < 0 then
            inst.components.werebeast:TriggerDelta(1)
        end
    end
end

local function OnAttackedByDecidRoot(inst, attacker)
    local x, y, z = inst.Transform:GetWorldPosition()
    local ents = TheSim:FindEntities(x, y, z, SpringCombatMod(SHARE_TARGET_DIST) * .5, { "_combat", "_health", "pig" }, { "werepig", "guard", "INLIMBO" })
    local num_helpers = 0
    for i, v in ipairs(ents) do
        if v ~= inst and not v.components.health:IsDead() then
            v:PushEvent("suggest_tree_target", { tree = attacker })
            num_helpers = num_helpers + 1
            if num_helpers >= MAX_TARGET_SHARES then
                break
            end
        end
    end
end

local function IsPig(dude)
    return dude:HasTag("pig")
end

local function IsWerePig(dude)
    return dude:HasTag("werepig")
end

local function IsNonWerePig(dude)
    return dude:HasTag("pig") and not dude:HasTag("werepig")
end

local function IsGuardPig(dude)
    return dude:HasTag("guard") and dude:HasTag("pig")
end

local function OnAttacked(inst, data)
    --print(inst, "OnAttacked")
    local attacker = data.attacker
    inst:ClearBufferedAction()

    if attacker.prefab == "deciduous_root" and attacker.owner ~= nil then 
        OnAttackedByDecidRoot(inst, attacker.owner)
    elseif attacker.prefab ~= "deciduous_root" and not attacker:HasTag("pigelite") then
        inst.components.combat:SetTarget(attacker)

        if inst:HasTag("werepig") then
            inst.components.combat:ShareTarget(attacker, SHARE_TARGET_DIST, IsWerePig, MAX_TARGET_SHARES)
        elseif inst:HasTag("guard") then
            inst.components.combat:ShareTarget(attacker, SHARE_TARGET_DIST, attacker:HasTag("pig") and IsGuardPig or IsPig, MAX_TARGET_SHARES)
        elseif not (attacker:HasTag("pig") and attacker:HasTag("guard")) then
            inst.components.combat:ShareTarget(attacker, SHARE_TARGET_DIST, IsNonWerePig, MAX_TARGET_SHARES)
        end
    end
end

local builds = {"pig_build", "pigspotted_build"}
local guardbuilds = {"pig_guard_build"}

local function NormalRetargetFn(inst)
	local exclude_tags = { "playerghost", "INLIMBO" }
	if inst.components.follower.leader ~= nil then
		table.insert(exclude_tags, "abigail")
	end
	if inst.components.minigame_spectator ~= nil then
		table.insert(exclude_tags, "player") -- prevent spectators from auto-targeting webber
	end

    return not inst:IsInLimbo()
        and FindEntity(
                inst,
                TUNING.PIG_TARGET_DIST,
                function(guy)
                    return (guy.LightWatcher == nil or guy.LightWatcher:IsInLight())
                        and inst.components.combat:CanTarget(guy)
                end,
                { "monster", "_combat" }, -- see entityreplica.lua
                exclude_tags
            )
        or nil
end

local function NormalKeepTargetFn(inst, target)
    --give up on dead guys, or guys in the dark, or werepigs
    return inst.components.combat:CanTarget(target)
        and (target.LightWatcher == nil or target.LightWatcher:IsInLight())
        and not (target.sg ~= nil and target.sg:HasStateTag("transform"))
end

local function NormalShouldSleep(inst)
    return DefaultSleepTest(inst)
        and (inst.components.follower == nil or inst.components.follower.leader == nil
            or (FindEntity(inst, 6, nil, { "campfire", "fire" }) ~= nil and
                (inst.LightWatcher == nil or inst.LightWatcher:IsInLight())))
end

local function SetNormalPig(inst, brain_id)
    inst:RemoveTag("werepig")
    inst:RemoveTag("guard")
    --local brain = require "brains/citypigbrain"
    --inst:SetBrain(brain)
    inst:SetStateGraph("SGpig_aiur")
--	inst.AnimState:SetBuild(inst.build)
    
	--inst.components.werebeast:SetOnNormalFn(SetNormalPig)
    inst.components.sleeper:SetResistance(2)

    inst.components.combat:SetDefaultDamage(TUNING.PIG_DAMAGE)
    inst.components.combat:SetAttackPeriod(TUNING.PIG_ATTACK_PERIOD)
    inst.components.combat:SetKeepTargetFunction(NormalKeepTargetFn)
    inst.components.locomotor.runspeed = TUNING.PIG_RUN_SPEED
    inst.components.locomotor.walkspeed = TUNING.PIG_WALK_SPEED
    
    inst.components.sleeper:SetSleepTest(NormalShouldSleep)
    inst.components.sleeper:SetWakeTest(DefaultWakeTest)
    
    inst.components.lootdropper:SetLoot({})
    inst.components.lootdropper:AddRandomLoot("meat",3)
    inst.components.lootdropper:AddRandomLoot("pigskin",1)
    inst.components.lootdropper.numrandomloot = 1

    inst.components.health:SetMaxHealth(TUNING.PIG_HEALTH)
    inst.components.combat:SetRetargetFunction(3, NormalRetargetFn)
    inst.components.combat:SetTarget(nil)
    inst:ListenForEvent("suggest_tree_target", function(inst, data)
        if data and data.tree and inst:GetBufferedAction() ~= ACTIONS.CHOP then
            inst.tree_target = data.tree
        end
    end)

    inst.components.trader:Enable()
    inst.components.talker:StopIgnoringAll()
end

local function normalizetorch(torch)
    torch.components.fueled.unlimited_fuel = nil   
end

local function normalizehalberd(halberd)
    halberd.components.weapon.attackwear = nil 
end


local function throwcrackers(inst)
    local cracker = SpawnPrefab("firecrackers")
    inst.components.inventory:GiveItem( cracker )
    local pos = Vector3(inst.Transform:GetWorldPosition())
    local start_angle = inst.Transform:GetRotation()
    local radius = 5
    local attempts = 12

    local test_fn = function(offset)
        local ents = TheSim:FindEntities(pos.x+offset.x,pos.y+offset.y,pos.z+offset.z, 2, nil,{"INLIMBO"})
        
        if #ents == 0 then                     
            return true            
        end
    end    
    local pt, new_angle = FindValidPositionByFan(start_angle, radius, attempts, test_fn)

    if new_angle then
        inst.Transform:SetRotation(new_angle / DEGREES)  
    end

    local rot = inst.Transform:GetRotation() * DEGREES

    local tossdir = Vector3(0,0,0)
    tossdir.x = math.cos(rot)
    tossdir.z = -math.sin(rot)     
                            
    inst.components.inventory:DropItem(cracker, nil,nil,nil,nil,tossdir)
    cracker.components.fuse:StartFuse()    
end

local function makefn(name, build, fixer, guard_pig, shopkeeper, tags, sex, econprefab)
    local function make_common()

    	local inst = CreateEntity()
    	inst.entity:AddTransform()
    	inst.entity:AddAnimState()
    	inst.entity:AddSoundEmitter()
    	inst.entity:AddDynamicShadow()
		inst.entity:AddLightWatcher()
		inst.entity:AddNetwork()

    	inst.DynamicShadow:SetSize( 1.5, .75 )

        inst.Transform:SetFourFaced()
		
		inst:AddTag("character")
        inst:AddTag("pig")
        inst:AddTag("civilized")
        inst:AddTag("scarytoprey")
		inst:AddTag("companion")

        inst:AddTag("firecrackerdance")  

        inst:AddTag("city_pig")
        
        inst:AddComponent("talker")
        inst.components.talker.ontalk = ontalk
        inst.components.talker.fontsize = 35
        inst.components.talker.font = TALKINGFONT
        inst.components.talker.offset = Vector3(0,-600,0)
		inst.components.talker:MakeChatter()
        inst.talkertype = name
	
        inst.sayline = sayline

        --inst.components.talker.colour = Vector3(133/255, 140/255, 167/255)

        MakeCharacterPhysics(inst, 50, .5)
		
		inst:AddComponent("spawnfader")
		
		inst.entity:SetPristine()

		if not TheWorld.ismastersim then
			return inst
		end
        
        inst:AddComponent("locomotor") -- locomotor must be constructed before the stategraph
        inst.components.locomotor.runspeed = TUNING.PIG_RUN_SPEED --5
        inst.components.locomotor.walkspeed = TUNING.PIG_WALK_SPEED --3

        if tags then
            for i,tag in ipairs(tags)do
                inst:AddTag(tag)
            end
        end

        inst.AnimState:SetBank("townspig")
        inst.AnimState:SetBuild(build)

        inst.AnimState:PlayAnimation("idle_loop",true)
        inst.AnimState:Hide("hat")
        inst.AnimState:Hide("desk")
        inst.AnimState:Hide("ARM_carry")

        ------------------------------------------
        inst:AddComponent("eater")
        inst.components.eater:SetDiet({ FOODGROUP.OMNI }, { FOODGROUP.OMNI })
		inst.components.eater:SetCanEatHorrible()
		inst.components.eater:SetCanEatRaw()
        inst.components.eater.strongstomach = true -- can eat monster meat!
        inst.components.eater:SetOnEatFn(OnEat)
        ------------------------------------------
        inst:AddComponent("combat")
        inst.components.combat.hiteffectsymbol = "pig_torso"

        MakeMediumBurnableCharacter(inst, "pig_torso")

        inst:AddComponent("named")
		inst.components.named.possiblenames = STRINGS.PIGNAMES
        inst.components.named:PickNewName()

        inst:AddComponent("follower")
        inst.components.follower.maxfollowtime = TUNING.PIG_LOYALTY_MAXTIME

        ------------------------------------------
        inst:AddComponent("health")
        inst:AddComponent("sleeper")
        inst:AddComponent("inventory")
        inst:AddComponent("lootdropper")
        inst:AddComponent("knownlocations")
        --inst:AddComponent("citypossession")
        --inst:AddComponent("citypooper")
        ------------------------------------------

        inst:AddComponent("trader")
        inst.components.trader:SetAcceptTest(ShouldAcceptItem)
        inst.components.trader.onaccept = OnGetItemFromPlayer
        inst.components.trader.onrefuse = OnRefuseItem
        
        ------------------------------------------

        inst:AddComponent("sanityaura")
        inst.components.sanityaura.aurafn = CalcSanityAura
        
        ------------------------------------------
        MakeMediumFreezableCharacter(inst, "pig_torso")
        --------------------------------------------

        inst:AddComponent("inspectable")
        inst.components.inspectable.getstatus = function(inst)
            if inst:HasTag("guard") then
                return "GUARD"
            elseif inst.components.follower.leader ~= nil then
                return "FOLLOWER"
            end
        end

        if econprefab then
            inst.econprefab = econprefab
            inst.components.inspectable.nameoverride = econprefab
        end
        ------------------------------------------  
        
        inst.special_action = function (act)
            if inst.daily_gifting then
                inst.sg:GoToState("daily_gift")
            elseif inst.poop_tip then
                inst.sg:GoToState("poop_tip")
            elseif inst:HasTag("paytax") then
                inst.sg:GoToState("pay_tax")
            end
        end

        ------------------------------------------
        inst.OnSave = function(inst, data)
            data.build = inst.build      

            data.children = {}
            -- for the shopkeepers if they have spawned their desk            
            if inst.desk then
                print("SAVING THE DESK")
                table.insert(data.children, inst.desk.GUID)  
                data.desk = inst.desk.GUID              
            end

            if inst.torch then
                table.insert(data.children, inst.torch.GUID)
                data.torch = inst.torch.GUID
            end
            if inst.axe then
                table.insert(data.children, inst.axe.GUID)
                data.axe = inst.axe.GUID
            end

            if inst:HasTag("atdesk") then
                data.atdesk = true
            end
            if inst:HasTag("guards_called") then
                data.guards_called = true
            end
            if inst.task_guard1 or inst.task_guard2 then
                print("SAVING GUARD TASKS")
                data.doSpawnGuardTask = true
            end             
            -- end shopkeeper stuff
            
            if inst:HasTag("angry_at_player") then
                data.angryatplayer = true
            end   

            if inst.equipped then
                data.equipped = true
            end

            if inst:HasTag("recieved_trinket") then
                data.recieved_trinket = true
            end
            
            if inst:HasTag("paytax") then
                data.paytax = true 
            end

            if data.children and #data.children > 0 then
                return data.children
            end    
        end        
        
        inst.OnLoad = function(inst, data)    
    		if data then                
    			inst.build = data.build or builds[1]
                if data.atdesk then
                    inst.sg:GoToState("desk_pre")
                end 

                if data.guards_called then
                    inst:AddTag("guards_called")
                end

                --[[if data.doSpawnGuardTask then
                    spawnguardtasks(inst,GetPlayer())
                end--]]

                if data.equipped then
                    inst.equipped = true
                    inst.equiptask:Cancel()
                    inst.equiptask = nil
                end

                if data.angryatplayer then
                    inst:AddTag("angry_at_player") 
                end 
                if data.recieved_trinket then
                    inst:AddTag("recieved_trinket")
                end  
                if data.paytax then
                    inst:AddTag("paytax")
                end              
    		end
        end           
        
        inst.OnLoadPostPass = function(inst, ents, data)
            if data then
                if data.children then                    
                    for k,v in pairs(data.children) do
                        local item = ents[v]            
                        if item then
                            if data.desk and data.desk == v then
                                inst.desk = item.entity
                                inst:AddComponent("homeseeker") 
                                inst.components.homeseeker:SetHome(inst.desk)  
                            end
                        end                    
                    end
                end
            end
        end    

        inst:ListenForEvent("attacked", OnAttacked)    

        inst.throwcrackers = throwcrackers
        
        SetNormalPig(inst)

        --[[if fixer then
            inst:AddComponent("fixer")
        end--]]
				

        return inst
    end

    ----------------------------------------------------------------------------------------

    local function make_pig_guard ()
        local inst = make_common()

        inst:AddTag("emote_nocurtsy")
        inst:AddTag("guard")
        inst:AddTag("extinguisher")
		
		if not TheWorld.ismastersim then
			return inst
		end
		
		
		--PIG_GUARD_HEALTH
		--inst.components.health:SetMaxHealth(TUNING.PIG_GUARD_HEALTH)
		inst.components.combat:SetDefaultDamage(TUNING.PIG_GUARD_DAMAGE)
		--inst.components.combat:SetAttackPeriod(TUNING.PIG_GUARD_ATTACK_PERIOD)
		
		inst.components.freezable:SetResistance(4)
		
        inst.components.burnable:SetBurnTime(2)
		
		inst.components.inspectable.nameoverride = "pigguard"

        inst.equiptask = inst:DoTaskInTime(0,function()
            if not inst.equipped then
                inst.equipped = true

                local torch = SpawnPrefab("torch")
                inst.components.inventory:GiveItem(torch)
                torch.components.fueled.unlimited_fuel = true

                local axe =SpawnPrefab("halberd")
                inst.components.inventory:GiveItem(axe)            
                inst.components.inventory:Equip(axe)
                --axe.components.finiteuses.unlimited_uses = true
				axe.components.weapon.attackwear = 0 
                

                local armour = SpawnPrefab("armorwood")
                if armour then
                    inst.components.inventory:GiveItem(armour)
                    inst.components.inventory:Equip(armour)                
                end
            end
        end)
		
		inst.checktask = inst:DoTaskInTime(0,function()
			local axe = inst.components.inventory:FindItem(function(item)return item.prefab == "halberd"end)
			local torch = inst.components.inventory:FindItem(function(item)return item.prefab == "torch"end)
			if axe then 
				axe.components.weapon.attackwear = 0 
			end
			if torch then 
				torch.components.fueled.unlimited_fuel = true
				torch.components.fueled:SetPercent(1)
			end
		end)

		inst:WatchWorldState("isday",function()                
            inst:DoTaskInTime(0.5+(math.random()*1),function()
                local axe = inst.components.inventory:FindItem(
                    function(item)
                        if item.prefab == "halberd" then
                            return true
                        end
                    end)
                if axe then 
                    inst.components.inventory:Equip(axe) 
                end 
            end)
        end)

        inst:WatchWorldState("isdusk", 
            function() 
                --[[local function getspeech()
                    return STRINGS.CITY_PIG_GUARD_LIGHT_TORCH.DEFAULT[math.random(#STRINGS.CITY_PIG_GUARD_LIGHT_TORCH.DEFAULT)]
                end
                inst.sayline(inst, getspeech())--]]
                --inst.components.talker:Say(getspeech(), 1.5, nil, true)
                inst:DoTaskInTime(0.5+(math.random()*1),function() 
                        local torch = inst.components.inventory:FindItem(
                            function(item)
                                if item.prefab == "torch" then
                                    return true
                                end
                            end)
                        if torch then
                            inst.components.inventory:Equip(torch) 
                        end 
                    end)
            end)

        inst:ListenForEvent("dropitem", 
            function(it, data)
                if data.item.prefab == "torch" then
                    normalizetorch(data.item)
                end
                if data.item.prefab == "halberd" then
                    normalizehalberd(data.item)
                end
            end)

        inst:ListenForEvent("death", 
            function()
                local torch = inst.components.inventory:FindItem(
                    function(item)
                        if item.prefab == "torch" and item.components.fueled and item.components.fueled.unlimited_fuel then
                            return true
                        end
                    end)
                if torch then 
                    normalizetorch(torch)
                end

                local axe = inst.components.inventory:FindItem(
                    function(item)
                        if item.prefab == "halberd" and item.components.finiteuses and item.components.finiteuses.unlimited_uses then
                            return true
                        end
                    end)
                if axe then
                    normalizehalberd(axe)
                end
            end)

        local brain = require "brains/royalpigguardbrain"
        inst:SetBrain(brain)
        return inst
    end



    if guard_pig then
        return make_pig_guard
    end

    return make_common
end

local function makepigman(name, build, fixer, guard_pig, shopkeeper, tags, sex, econprefab)   
    return Prefab("common/objects/" .. name, makefn(name, build, fixer, guard_pig, shopkeeper, tags, sex, econprefab), assets, prefabs )  
end


--[[Asset("ANIM", "anim/pig_royalguard.zip"),
Asset("ANIM", "anim/pig_royalguard_2.zip"),
Asset("ANIM", "anim/pig_royalguard_3.zip"),
Asset("ANIM", "anim/pig_royalguard_rich.zip"),
Asset("ANIM", "anim/pig_royalguard_rich_2.zip"),--]]

--                      name                        build         fixer  guard shop tags               sex
return 
		makepigman("pigman_aiurguard",         "pig_royalguard",   nil,  true, nil, nil, "MALE" ),
        makepigman("pigman_aiurguard_2",       "pig_royalguard_2", nil,  true, nil, nil, "MALE" ), 
		makepigman("pigman_aiurguard_3",       "pig_royalguard_3", nil,  true, nil, nil, "MALE" ),
		makepigman("pigman_aiurguard_rich",       "pig_royalguard_rich", nil,  true, nil, nil, "MALE" ),
		makepigman("pigman_aiurguard_rich_2",       "pig_royalguard_rich_2", nil,  true, nil, nil, "MALE" )  
        