local TadalinUtil = require("tadalin_util")


local assets=
{
    --Asset("ANIM", "anim/perd_basic.zip"),
    Asset("ANIM", "anim/crickant_queen_basics.zip"),
	Asset("ANIM", "anim/dark_antqueen_part.zip"),
	--Asset("ANIM", "anim/dark_antqueen_part2.zip"),
	--Asset("ANIM", "anim/dark_antqueen_part3.zip"),
	--Asset("ANIM", "anim/dark_antqueen_part3_1.zip"),
	--Asset("ANIM", "anim/dark_antqueen_part3_2.zip"),
	Asset("ANIM", "anim/dark_antqueen_part4.zip"),
	Asset("ANIM", "anim/dark_antqueen_part5.zip"),
}

local prefabs =
{
    "antman_warrior",
    "antman_warrior_egg",
    "warningshadow",
    "throne_wall_large",
    "throne_wall",
}

local loot =
{
	--"dark_antqueen_cinder",
    "skeletonhat",
    "fossil_piece",
    "fossil_piece",
    "fossil_piece",
    "fossil_piece",
    "fossil_piece",
	"fossil_piece",
	"fossil_piece",
	"fossil_piece",
    --"chitin",
    --"chitin",
    --"chitin",
    --"chitin",
    "nightmarefuel",
    "nightmarefuel",
    "nightmarefuel",
    "nightmarefuel",
    "nightmarefuel",
    "bundlewrap_blueprint",
}

local DarkOverrideSymbols = {
	"crick_antenna",
	"crick_arm",
	"crick_egg",
	"crick_headbase",
	"crick_mouth",
}

local spawn_positions =
{
    {x = 6, z = -6},
    {x = 6, z = 6 },
    {x = 6, z = 0 },
}

local AttackRangeChange = {
	skill_summon = 20,
	skill_music = 15, 
	skill_jump = 8,
}

local function PushMusic(inst)
    if ThePlayer == nil then
        inst._playingmusic = false
    elseif ThePlayer:IsNear(inst, inst._playingmusic and 40 or 20) then
        inst._playingmusic = true
        ThePlayer:PushEvent("triggeredevent", { name = "dark_antqueen" })
    elseif inst._playingmusic and not ThePlayer:IsNear(inst, 50) then
        inst._playingmusic = false
    end
end

local function WarriorKilled(inst)
	if inst and inst:IsValid() then 
		inst.warrior_count = inst.warrior_count - 1
		if inst.warrior_count <= 0 then
			inst.warrior_count = 0
		end
	end 
end

local function SpawnWarrior(inst)
    
    local x, y, z = inst.Transform:GetWorldPosition()
    local random_offset = spawn_positions[math.random(1, #spawn_positions)]
	local target = inst.components.combat.target 
    x = x + random_offset.x + math.random(-1.5, 1.5)
    y = 35
    z = z + random_offset.z + math.random(-1.5, 1.5)
--[[
    local egg = SpawnPrefab("antman_warrior_egg")
    egg.queen = inst
    egg.Physics:Teleport(x, y, z)

    egg.start_grounddetection(egg)

    local shadow = SpawnPrefab("warningshadow")
    shadow.Transform:SetPosition(x, 0.2, z)
    shadow:shrink(1.5, 1.5, 0.25)--]]
	local egg = SpawnPrefab("tadalin_meteor")
	egg.Transform:SetPosition(x,0,z)
	--egg.Transform:SetScale(0.75,0.75,0.75)
	egg.AnimState:SetMultColour(0,0,0,0.75)
	egg.components.combat:SetDefaultDamage(40)
	egg:ListenForEvent("animover",function()
		local nightmare = SpawnPrefab(math.random() <= 0.5 and "crawlingnightmare" or "nightmarebeak")
		nightmare.persists = false 
		nightmare.Transform:SetPosition(x,0,z)
		TadalinUtil.MakeNormalTadalin(nightmare)
		if target and target:IsValid() then 
			nightmare.components.combat:SetTarget(target)
		end 
		nightmare:ListenForEvent("onremove",function()
			WarriorKilled(inst)
		end)
		nightmare:ListenForEvent("death",function()
			if nightmare and nightmare:IsValid() and nightmare.components.health and not nightmare.components.health:IsDead() then 
				nightmare.components.health:Kill()
			end
		end,inst)
	end)

    inst.warrior_count = inst.warrior_count + 1
end

local function ClearRecentlyCharged(inst, other)
    inst.recentlycharged[other] = nil
end

local function onothercollide(inst, other)
    if not other:IsValid() or not TadalinUtil.CanAttack(other) or inst.recentlycharged[other] then
        return
    elseif other:HasTag("smashable") and other.components.health ~= nil then
        --other.Physics:SetCollides(false)
        other.components.health:Kill()
    elseif other.components.workable ~= nil
        and other.components.workable:CanBeWorked()
        and other.components.workable.action ~= ACTIONS.NET then
        SpawnPrefab("collapse_small").Transform:SetPosition(other.Transform:GetWorldPosition())
        other.components.workable:Destroy(inst)
        if other:IsValid() and other.components.workable ~= nil and other.components.workable:CanBeWorked() then
            inst.recentlycharged[other] = true
            inst:DoTaskInTime(3, ClearRecentlyCharged, other)
        end
    elseif other.components.health ~= nil and not other.components.health:IsDead() and other.components.combat and TadalinUtil.CanAttack(other) then
        inst.recentlycharged[other] = true
        inst:DoTaskInTime(3, ClearRecentlyCharged, other)
        inst.SoundEmitter:PlaySound("dontstarve/creatures/rook/explo")
        --inst.components.combat:DoAttack(other, inst.weapon)
		other.components.combat:GetAttacked(inst,math.random(45,70))
    end
end

local function oncollide(inst, other)
    if not (other ~= nil and other:IsValid() and inst:IsValid())
        or inst.recentlycharged[other]
        or other:HasTag("tadalin")
		or not TadalinUtil.CanAttack(other)
        or Vector3(inst.Physics:GetVelocity()):LengthSq() < 42
		or not inst.sg:HasStateTag("moving")
		 then
        return
    end
    ShakeAllCameras(CAMERASHAKE.SIDE, .5, .05, .1, inst, 40)
    inst:DoTaskInTime(2 * FRAMES, onothercollide, other)
end

local function onskilluse(inst,data)
	local skillname = data.name
	local skillcd = data.cd
	inst[skillname] = false 
	
	inst.components.timer:StartTimer(skillname,skillcd)
end 

local function ontimerdone(inst,data)
	local skillname = data.name
	if AttackRangeChange[skillname] then 
		inst.components.combat.attackrange = AttackRangeChange[skillname]
	else
		inst.components.combat.attackrange = 6 
	end
	inst[skillname] = true 
end 

local function EnterPhase2Trigger(inst)
	print("EnterPhase2Trigger")
	inst.level = 1
	inst.summon_count = 4
end

local function EnterPhase3Trigger(inst)
	print("EnterPhase3Trigger")
	if inst.level < 2 then 
		inst.level = 2
		inst.jump_count = 2 
		inst.skill_music = true 
		inst.summon_count = 5 
	end 
end

local function EnterPhase4Trigger(inst)
	print("EnterPhase4Trigger")
	inst.level = 3
	inst.jump_count = 3 
	inst.summon_count = 6
end

local function QueenDebug(inst)
	print("--------------QueenDebug---------------")
	print(inst)
	local debugs = {
		"skill_summon",
		"skill_jump",
		"skill_music",
		"level",
		"jump_count",
		"current_jump_count",
		"warrior_count",
		"summon_count",
		"current_summon_count",
	}
	local str = ""
	for k,v in pairs(debugs) do 
		str = str.."inst."..v.." = "..tostring(inst[v]).."\n"
	end
	print(str) 
	print("------------QueenDebugOver-------------")
end 

local function OnSave(inst,data)
	data.level = inst.level 
	data.skill_jump = inst.skill_jump
	data.skill_music = inst.skill_music 
	data.summon_count = inst.summon_count
	data.jump_count = inst.jump_count
end 

local function OnLoad(inst,data)
	if data then 
		inst.level = data.level 
		inst.skill_jump = data.skill_jump 
		inst.skill_music = data.skill_music 
		inst.summon_count = data.summon_count 
		inst.jump_count = data.jump_count 
	end 
end 


local function fn()
    local inst = CreateEntity()
    local trans = inst.entity:AddTransform()
    local anim = inst.entity:AddAnimState()
    local sound = inst.entity:AddSoundEmitter()
	inst.entity:AddNetwork()

    trans:SetScale(0.9, 0.9, 0.9)

    MakeGiantCharacterPhysics(inst, 1000, 3)
	
	inst:AddTag("antqueen")
	inst:AddTag("epic")
	inst:AddTag("noepicmusic")

     
    anim:SetBank ("crick_crickantqueen")
    anim:SetBuild("crickant_queen_basics")
    --anim:AddOverrideBuild("dark_antqueen_part")
	for k,v in pairs(DarkOverrideSymbols) do 
		anim:OverrideSymbol(v, "dark_antqueen_part",v)
	end 
	inst.AnimState:HideSymbol("crick_eye1")
	inst.AnimState:HideSymbol("crick_eye2")
	inst.AnimState:HideSymbol("crick_cres")
	inst.AnimState:OverrideSymbol("crick_crown", "hat_skeleton","swap_hat")
	--inst.AnimState:OverrideSymbol("crick_ab", "dark_antqueen_part2","crick_ab")
	--inst.AnimState:AddOverrideBuild("dark_antqueen_part2")
	--inst.AnimState:OverrideSymbol("crick_ab_splode", "dark_antqueen_part3","crick_ab_splode")
	--inst.AnimState:OverrideSymbol("crick_ab_splode", "dark_antqueen_part3_2","crick_ab_splode")
	--inst.AnimState:OverrideSymbol("crick_ab_splode", "dark_antqueen_part3_3","crick_ab_splode")
	--inst.AnimState:OverrideSymbol("crick_ab", "dark_antqueen_part4","crick_ab")
	inst.AnimState:OverrideSymbol("crick_headbase", "dark_antqueen_part4","crick_headbase")
	inst.AnimState:OverrideSymbol("crick_torso", "dark_antqueen_part5","crick_torso")
	
	inst._playingmusic = false
	if not TheNet:IsDedicated() then
        inst:DoPeriodicTask(1, PushMusic,0)
    end
	
	inst.entity:SetPristine()
    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.skill_summon = true
	inst.skill_jump = true
	inst.skill_music = false 
	
	inst.level = 0
	inst.jump_count = 1 
	inst.current_jump_count = 0 
    inst.warrior_count = 0
	inst.summon_count = 3 
	inst.current_summon_count = 0
    inst.SpawnWarrior = SpawnWarrior
    inst.WarriorKilled = function () WarriorKilled(inst) end
	inst.QueenDebug = QueenDebug 
	--inst.recentlycharged = {} 
	--inst.Physics:SetCollisionCallback(oncollide)
	
    
    inst:AddComponent("locomotor")
	inst.components.locomotor.walkspeed = 6
    inst.components.locomotor.runspeed = 12
	
    inst:SetStateGraph("SGdark_antqueen")

    local brain = require "brains/dark_antqueenbrain"
    inst:SetBrain(brain)

    
    inst:AddComponent("combat")
	inst.components.combat:SetRange(6,4)
    
    inst:AddComponent("health")
	inst.components.health.fire_damage_scale = 35
	inst.components.health.destroytime = 8
    inst.components.health:SetMaxHealth(8000)
    inst.components.health:StartRegen(1, 4)

    inst:AddComponent("lootdropper")
    inst.components.lootdropper:SetLoot(loot)
    
    inst:AddComponent("inspectable")
	
	inst:AddComponent("knownlocations")
	
	inst:AddComponent("timer")
	
	inst:AddComponent("healthtrigger")
	inst.components.healthtrigger:AddTrigger(0.85, EnterPhase2Trigger)
	inst.components.healthtrigger:AddTrigger(0.6, EnterPhase3Trigger)
	inst.components.healthtrigger:AddTrigger(0.3, EnterPhase4Trigger)
	
	inst:ListenForEvent("use_antqueen_skill",onskilluse)
	inst:ListenForEvent("timerdone",ontimerdone)
	
	inst.OnSave = OnSave
	inst.OnLoad = OnLoad
	
	TadalinUtil.MakeNormalTadalin(inst)
	MakeLargeBurnableCharacter(inst, "crick_torso")
	
    return inst
end


return Prefab( "dark_antqueen", fn,   assets, prefabs)