require "cooking"
FOODTYPE.ICEY_BATTERY = "ICEY_BATTERY"

--这里描述了艾希的专属食谱的成分
local function SpawnLootBeacon(inst)
	local lootbeacon = SpawnPrefab("icey_lootbeacon")
	lootbeacon.forever = true 
	lootbeacon.canaddcolour = false
	lootbeacon:SetTarget(inst)
end 


local foods = {
	icey_battery2 = {
		name = "icey_battery2",
		str = "标准电池",
		scale = 1,
		foodtype = FOODTYPE.ICEY_BATTERY, 
		hunger = 25.5,
		sanity = 2,
		health = 3,
		shield = 3,
		perishtime = nil,
		description = "饿了吗？来块电池吧！！",
		oneatfn = nil,
		extrafn = nil,
		
		test = function(cooker, names, tags) 
			return tags.iceymagic and tags.iceymagic  >= 4
		end,
		weight = 1,
		priority = 20,
		
		cooktime = 0.2,
	},
	
	icey_battery3 = {
		name = "icey_battery3",
		str = "粘稠电池",
		scale = 1,
		foodtype = FOODTYPE.ICEY_BATTERY,
		hunger = 12.5,
		sanity = 75,
		health = 4.5,
		shield = 3,
		perishtime = nil,
		description = "黏糊糊的....",
		oneatfn = nil,
		extrafn = nil,
		
		test = function(cooker, names, tags) 
			return tags.iceymagic and tags.glommerfuel and not tags.meat
		end,
		weight = 1,
		priority = 20,
		
		cooktime = 0.6,
	},
	
	icey_battery4 = {
		name = "icey_battery4",
		str = "基因电池",
		scale = 1,
		foodtype = FOODTYPE.ICEY_BATTERY,
		hunger = 12.5,
		sanity = 7,
		health = 35,
		shield = 5,
		perishtime = nil,
		description = "用蝴蝶做电池，你可真行",
		oneatfn = nil,
		extrafn = nil,
		
		test = function(cooker, names, tags) 
			return tags.iceymagic and names.butterflywings and tags.iron
		end,
		weight = 1,
		priority = 20,
		
		cooktime = 0.5,
	},
	
	icey_battery_vigour = {
		name = "icey_battery_vigour",
		str = "聚能电池",
		scale = 1,
		foodtype = FOODTYPE.ICEY_BATTERY,
		hunger = 76.5,
		sanity = 2,
		health = 3,
		shield = 3,
		perishtime = nil,
		description = "一节更比六节强!!",
		oneatfn = nil,
		extrafn = nil,
		
		test = function(cooker, names, tags) 
			return tags.meat and tags.meat >= 1.5 and tags.iceymagic and not tags.monster
		end,
		weight = 1,
		priority = 20,
		
		cooktime = 0.8,
	}, 
	
	alloy = {
		name = "alloy",
		str = "合金",
		scale = 1,
		foodtype = FOODTYPE.ICEY_BATTERY,
		hunger = 27.5,
		sanity = 3,
		health = 2,
		shield = 3,
		perishtime = nil,
		description = "一小块合金。",
		oneatfn = nil,
		extrafn = nil,
		
		test = function(cooker, names, tags) 
			return tags.iron and tags.iron >= 4
		end,
		weight = 1,
		priority = 20,
		
		cooktime = 0.2,
	},
	
	ironpan_newcomer = {
		name = "ironpan_newcomer",
		str = "铁锅炖萌新",
		scale = 1,
		foodtype = FOODTYPE.MEAT,
		hunger = 66.5,
		sanity = 12.5,
		health = 10,
		shield = 5,
		perishtime = TUNING.PERISH_MED,
		description = "现在给大佬们表演：铁锅炖萌新！",
		oneatfn = nil,
		extrafn = nil,
		
		test = function(cooker, names, tags) 
			return tags.iron and tags.iron >= 2 and tags.meat and tags.meat >= 1.5 and not tags.monster
		end,
		weight = 1,
		priority = 20,
		
		cooktime = 0.2,
	},
	
	solar_debris = {
		name = "solar_debris",
		str = "太阳能碎片",
		scale = 1,
		foodtype = FOODTYPE.ICEY_BATTERY,
		hunger = 12.5,
		sanity = 34.5,
		health = 20,
		shield = 7,
		perishtime = nil,
		description = "相位技师的最爱！",
		oneatfn = function(inst,eater)
			if eater and eater:IsValid()  then 
				if eater.components.temperature then 
					eater.components.temperature:DoDelta(10)
					if eater.components.temperature:GetCurrent() >= 50 then 
						if eater.components.burnable then 
							eater.components.burnable:Ignite()
						end 
					end
				end
				if eater.SoundEmitter then 
					eater.SoundEmitter:PlaySound("dontstarve/common/fireAddFuel")
				end
			end
		end,
		extrafn = function(inst)	
			inst:AddComponent("fuel")
			inst.components.fuel.fuelvalue = TUNING.LARGE_FUEL
			
			if inst.components.inventoryitem and inst.components.inventoryitem.owner == nil then
				SpawnLootBeacon(inst)
			end
			inst:ListenForEvent("ondropped",SpawnLootBeacon)
		end,
		
		test = function(cooker, names, tags) 
			return tags.crystal and tags.crystal >= 2 and tags.gold
		end,
		weight = 1,
		priority = 20,
		
		cooktime = 0.2,
	},
	
	zerg_drone_cooked = {
		name = "zerg_drone_cooked",
		str = "红烧工蜂",
		scale = 1,
		foodtype = FOODTYPE.MEAT,
		hunger = 57.5,
		sanity = -2,
		health = -1,
		shield = 0,
		perishtime = TUNING.PERISH_MED,
		description = "工蜂看起来很好吃。",
		oneatfn = nil,
		extrafn = nil,
		
		test = function(cooker, names, tags) 
			return  tags.monster and tags.monster >= 2 and tags.meat and tags.iceymagic 
		end,
		weight = 1,
		priority = 20,
		
		cooktime = 0.7,
	},
	
	
	zerg_overlord_cooked = {
		name = "zerg_overlord_cooked",
		str = "酱汁王虫",
		scale = 1,
		foodtype = FOODTYPE.MEAT,
		hunger = 82.5,
		sanity = -3,
		health = -2,
		shield = 0,
		perishtime = TUNING.PERISH_MED,
		description = "掏空内脏食用，口味更佳。",
		oneatfn = nil,
		extrafn = nil,
		
		test = function(cooker, names, tags) 
			return  tags.monster and tags.monster >= 3 and tags.meat and tags.iceymagic 
		end,
		weight = 1,
		priority = 21,
		
		cooktime = 0.8,
	},
	
	zerg_bomb_ice = {
		name = "zerg_bomb_ice",
		str = "清凉爆虫",
		scale = 1,
		foodtype = FOODTYPE.MEAT,
		hunger = 25.5,
		sanity = 15,
		health = -3,
		shield = 3,
		perishtime = TUNING.PERISH_MED,
		description = "滚滚红尘的爆浆！",
		oneatfn = function(inst,eater)
			if eater and eater:IsValid()  then 
				if eater.components.temperature then 
					eater.components.temperature:DoDelta(-10)
				end
			end
		end,
		extrafn = nil,
		
		test = function(cooker, names, tags) 
			return  tags.monster and tags.frozen and tags.iceymagic 
		end,
		weight = 1,
		priority = 20,
		
		cooktime = 0.4,
	},
	
	marines_cake = {
		name = "marines_cake",
		str = "陆战队蛋糕",
		scale = 1,
		foodtype = FOODTYPE.GOODIES,
		hunger = 50,
		sanity = 50,
		health = 50,
		shield = 50,
		perishtime = TUNING.PERISH_MED,
		description = "50块钱的好兄弟们。",
		oneatfn = function(inst, eater)
            if eater.components.debuffable ~= nil and eater.components.debuffable:IsEnabled() and
                not (eater.components.health ~= nil and eater.components.health:IsDead()) and
                not eater:HasTag("playerghost") then
                eater.components.debuffable:AddDebuff("healthregenbuff", "healthregenbuff")
            end
        end,
		extrafn = nil,
		
		test = function(cooker, names, tags) 
			return tags.iceymagic and names.royal_jelly and not tags.meat and not tags.monster
		end,
		weight = 1,
		priority = 20,
		
		cooktime = 0.8,
	},
	
	sweat_bonestew = {
		name = "sweat_bonestew",
		str = "蜜汁肉汤",
		scale = 1,
		foodtype = FOODTYPE.MEAT,
		hunger = 150,
		sanity = 16.5,
		health = 30,
		shield = 7,
		perishtime = TUNING.PERISH_MED,
		description = "甜而不腻的肉汤。",
		oneatfn = nil,
		extrafn = nil,
		
		test = function(cooker, names, tags) 
			return names.honey  and tags.meat and tags.meat >= 3 and not tags.monster
		end,
		weight = 1,
		priority = 20,
		
		cooktime = 0.8,
	},
	
	sweatcustone = {
		name = "sweatcustone",
		str = "甜蜜钢砖",
		scale = 1,
		foodtype = FOODTYPE.ICEY_BATTERY,
		hunger = 37.5,
		sanity = 6.5,
		health = 30,
		shield = 4,
		perishtime = nil,
		description = "嘎嘣脆，蜂蜜味!!",
		oneatfn = nil,
		extrafn = nil,
		
		test = function(cooker, names, tags) 
			return names.honey and tags.iron and tags.iron >= 2 and names.cutstone 
		end,
		weight = 1,
		priority = 20,
		
		cooktime = 0.8,
	},
	
	battery_kabobs = {
		name = "battery_kabobs",
		str = "烤电池串",
		scale = 1,
		foodtype = FOODTYPE.ICEY_BATTERY,
		hunger = 40.5,
		sanity = 7,
		health = 2,
		shield = 3,
		perishtime = nil,
		description = "串起来的电池，有问题吗？",
		oneatfn = nil,
		extrafn = nil,
		
		test = function(cooker, names, tags) 
			return  tags.meat and names.twigs and (not tags.monster or tags.monster <= 1) and tags.iron 
		end,
		weight = 1,
		priority = 20,
		
		cooktime = 0.8,
	},
	
	nuclear_cola = {
		name = "nuclear_cola",
		str = "核子可乐",
		scale = 1,
		foodtype = FOODTYPE.ICEY_BATTERY,
		hunger = 21.5,
		sanity = 20,
		health = 15,
		shield = 6,
		perishtime = nil,
		description = "大胖子伺候！",
		oneatfn = function(inst,eater)
			if eater and eater:IsValid()  then 
				if eater.components.temperature then 
					eater.components.temperature:DoDelta(-10)
					if eater.components.temperature:GetCurrent() <= 5 then 
						if eater.components.freezable then 
							eater.components.freezable:AddColdness(8)
						end 
					end
				end
				if eater.components.burnable and (eater.components.burnable:IsBurning() or eater.components.burnable:IsSmoldering() ) then 
					eater.components.burnable:Extinguish()
				end 
			end
		end,
		extrafn = nil,
		
		test = function(cooker, names, tags) 
			return  not tags.meat and not tags.monster and tags.iron and tags.iceymagic and tags.fruit and tags.frozen
		end,
		weight = 1,
		priority = 20,
		
		cooktime = 0.8,
	},
	
	
	
	purging_stone = {
		name = "purging_stone",
		str = "解咒石",
		scale = 1,
		foodtype = FOODTYPE.GENERIC,
		hunger = 25,
		sanity = 5,
		health = 3,
		shield = 6,
		perishtime = nil,
		description = "美容石！",
		oneatfn = function(inst,eater)
			if eater and eater:IsValid() then 
				if eater.components.health then 
					eater.components.health:SetPenalty(0)
					eater.components.health:DoDelta(0)
				end 
			end
		end,
		extrafn = nil,
		
		test = function(cooker, names, tags) 
			return names.nightmarefuel and names.nightmarefuel >= 2 and tags.crystal and tags.cutstone
		end,
		weight = 1,
		priority = 20,
		
		cooktime = 1,
		
		othercookpots = {"portablecookpot"},
	},
	
	
	moss_clump_blue = {
		name = "moss_clump_blue",
		str = "蓝冻苔藓球",
		scale = 1,
		foodtype = FOODTYPE.VEGGIE,
		hunger = 25,
		sanity = 5,
		health = 3,
		shield = 6,
		perishtime = nil,
		description = "蓝洞公司出品。",
		temperature = TUNING.HOT_FOOD_BONUS_TEMP,
        temperatureduration = TUNING.BUFF_FOOD_TEMP_DURATION,
        nochill = true,
		
		oneatfn = function(inst,eater)
			if eater and eater:IsValid() then 
				if eater.components.temperature then 
					eater.components.temperature:DoDelta(5)
				end 
				
				if eater.components.debuffable and eater.components.debuffable:HasDebuff("freeze") then 
					eater.components.debuffable:RemoveDebuff("freeze")
				end 
					
				if eater.components.darksouldebuffable and eater.components.darksouldebuffable:HasDebuff("freeze") then 
					eater.components.darksouldebuffable:RemoveDebuff("freeze")
				end 
			end
			
			
		end,

		extrafn = nil,
		
		test = function(cooker, names, tags) 
			return tags.frozen and names.cutlichen 
		end,
		weight = 1,
		priority = 20,
		
		cooktime = 1,
		
		othercookpots = {"portablecookpot"},
	},
	
	moss_clump_purple = {
		name = "moss_clump_purple",
		str = "毒紫苔藓球",
		scale = 1,
		foodtype = FOODTYPE.VEGGIE,
		hunger = 25,
		sanity = 5,
		health = 3,
		shield = 6,
		perishtime = nil,
		description = "看起来有毒的样子。",
		oneatfn = function(inst,eater)
			if eater and eater:IsValid() then 
				if eater.components.debuffable and eater.components.debuffable:HasDebuff("poison") then 
					eater.components.debuffable:RemoveDebuff("poison")
				end 
				
				if eater.components.darksouldebuffable and eater.components.darksouldebuffable:HasDebuff("poison") then 
					eater.components.darksouldebuffable:RemoveDebuff("poison")
				end 
			end
		end,
		extrafn = nil,
		
		test = function(cooker, names, tags) 
			return  names.cutlichen and tags.monster
		end,
		weight = 1,
		priority = 20,
		
		cooktime = 0.3,
		
		othercookpots = {"portablecookpot"},
	},
	
	moss_clump_purple_flower = {
		name = "moss_clump_purple_flower",
		str = "毒紫花苔藓球",
		scale = 1,
		foodtype = FOODTYPE.VEGGIE,
		hunger = 25,
		sanity = 5,
		health = 3,
		shield = 6,
		perishtime = nil,
		description = "看起来有剧毒的样子。",
		oneatfn = function(inst,eater)
			if eater and eater:IsValid() then 
				if eater.components.debuffable then 
					if eater.components.debuffable:HasDebuff("poison") then 
						eater.components.debuffable:RemoveDebuff("poison")
					end 
					if eater.components.debuffable:HasDebuff("strong_poison") then 
						eater.components.debuffable:RemoveDebuff("strong_poison")
					end  
				end
				if eater.components.darksouldebuffable then
					if eater.components.darksouldebuffable:HasDebuff("poison") then 
						eater.components.darksouldebuffable:RemoveDebuff("poison")
					end 
					if eater.components.darksouldebuffable:HasDebuff("strong_poison") then 
						eater.components.darksouldebuffable:RemoveDebuff("strong_poison")
					end  
				end 
				 
			end
		end,
		extrafn = nil,
		
		test = function(cooker, names, tags) 
			return  names.cutlichen and names.cutlichen >= 2 and tags.monster and tags.moon_flower
		end,
		weight = 1,
		priority = 20,
		
		cooktime = 0.3,
		
		othercookpots = {"portablecookpot"},
	},
	
	moss_clump_red = {
		name = "moss_clump_red",
		str = "血红苔藓球",
		scale = 1,
		foodtype = FOODTYPE.VEGGIE,
		hunger = 25,
		sanity = 5,
		health = 20,
		shield = 6,
		perishtime = nil,
		description = "能够止血。",
		oneatfn = function(inst,eater)
			
			if eater and eater:IsValid() then 
				if eater.components.debuffable and eater.components.debuffable:HasDebuff("bleeds") then 
					eater.components.debuffable:RemoveDebuff("bleeds")
				end 
					
				if eater.components.darksouldebuffable and eater.components.darksouldebuffable:HasDebuff("bleeds") then 
					eater.components.darksouldebuffable:RemoveDebuff("bleeds")
				end 
			end 
		end,
		extrafn = nil,
		
		test = function(cooker, names, tags) 
			return  names.cutlichen and not tags.monster and tags.fruit
		end,
		weight = 1,
		priority = 20,
		
		cooktime = 1,
		
		othercookpots = {"portablecookpot"},
	},
	
	
}


AddIngredientValues({"moon_tree_blossom"}, {moon_flower = 1}, true)
AddIngredientValues({"moon_tree_blossom_worldgen"}, {moon_flower = 1}, true)

AddIngredientValues({"icey_magic"}, {iceymagic=1,inedible = 1}, true)
AddIngredientValues({"iron"}, {iron=1,inedible = 1}, true)
AddIngredientValues({"crystal_item"}, {crystal=1,inedible = 1}, true)
AddIngredientValues({"cutcrystal"}, {crystal=20,inedible = 1}, true)

AddIngredientValues({"quagmire_smallmeat"}, {meat = 0.5}, true)
AddIngredientValues({"quagmire_cookedsmallmeat"}, {meat = 0.5}, true)

AddIngredientValues({"cutstone"}, {cutstone=1,inedible = 1}, true)
AddIngredientValues({"glommerfuel"}, {glommerfuel=1}, true)
AddIngredientValues({"goldnugget"}, {gold=1}, true)

return foods 