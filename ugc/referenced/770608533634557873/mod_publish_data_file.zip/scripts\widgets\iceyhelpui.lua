local Widget = require "widgets/widget" 
local Text = require "widgets/text" --Text类，文本处理
local TextButton = require "widgets/textbutton"
local Image = require "widgets/image"
local ImageButton = require "widgets/imagebutton"
local Menu = require "widgets/menu"
local NineSlice = require "widgets/nineslice"

local BUTTON_START_X = -600 
local BUTTON_START_Y = 250
local BUTTON_DISTS = 60
local BUTTON_TEXTSIZE = 50

local IceyHelpUI = Class(Widget, function(self, owner)
	Widget._ctor(self, "IceyHelpUI") 
    self.owner = owner
	
	self.mainmenu = self:AddChild(Image("images/fepanels_redux_shop_panel.xml", "shop_panel.tex"))
	self.mainmenu:SetPosition(0,0)
	self.mainmenu:SetHAnchor(0) -- 设置原点x坐标位置，0、1、2分别对应屏幕中、左、右
	self.mainmenu:SetVAnchor(0) -- 设置原点y坐标位置，0、1、2分别对应屏幕中、上、下
	self.mainmenu:SetScale(1.5,2,1)
	self.mainmenu:Hide()
	
	self.button_basic = self.mainmenu:AddChild(TextButton())
	self.button_basic:SetText("基础")
	self.button_basic:SetPosition(BUTTON_START_X,BUTTON_START_Y)
	self.button_basic:SetHAnchor(0)
	self.button_basic:SetVAnchor(0)
	self.button_basic:SetTextSize(BUTTON_TEXTSIZE)
	
	self.button_weapon = self.mainmenu:AddChild(TextButton())
	self.button_weapon:SetText("武器")
	self.button_weapon:SetPosition(BUTTON_START_X,BUTTON_START_Y - BUTTON_DISTS)
	self.button_weapon:SetHAnchor(0)
	self.button_weapon:SetVAnchor(0)
	self.button_weapon:SetTextSize(BUTTON_TEXTSIZE)
	
	self.button_armor = self.mainmenu:AddChild(TextButton())
	self.button_armor:SetText("防具")
	self.button_armor:SetPosition(BUTTON_START_X,BUTTON_START_Y - BUTTON_DISTS*2)
	self.button_armor:SetHAnchor(0)
	self.button_armor:SetVAnchor(0)
	self.button_armor:SetTextSize(BUTTON_TEXTSIZE)
	
	self.button_monster = self.mainmenu:AddChild(TextButton())
	self.button_monster:SetText("敌人")
	self.button_monster:SetPosition(BUTTON_START_X,BUTTON_START_Y - BUTTON_DISTS*3)
	self.button_monster:SetHAnchor(0)
	self.button_monster:SetVAnchor(0)
	self.button_monster:SetTextSize(BUTTON_TEXTSIZE)
	
	self.button_boss = self.mainmenu:AddChild(TextButton())
	self.button_boss:SetText("头目")
	self.button_boss:SetPosition(BUTTON_START_X,BUTTON_START_Y - BUTTON_DISTS*4)
	self.button_boss:SetHAnchor(0)
	self.button_boss:SetVAnchor(0)
	self.button_boss:SetTextSize(BUTTON_TEXTSIZE)
	
	--self.pictureshow = 
	
	self.callonbutton = self:AddChild(TextButton())
	self.callonbutton:SetText("战地手册")
	self.callonbutton:SetColour(0/255,131/255,255/255,1)
	self.callonbutton:SetHAnchor(1) -- 设置原点x坐标位置，0、1、2分别对应屏幕中、左、右
	self.callonbutton:SetVAnchor(2) -- 设置原点y坐标位置，0、1、2分别对应屏幕中、上、下
    self.callonbutton:SetPosition(100,75) -- 设置ancientmac widget相对原点的偏移量，70，-50表明向右70，向下50，第三个参数无意义。
	self.callonbutton:SetOnClick(function()
		if self.mainmenu.shown then 
			self.mainmenu:Hide()
		else
			self.mainmenu:Show()
		end 
	end)
	
end)

return IceyHelpUI