--[[local function CantSeeSneakingPlayer(inst,player)
	local cant_see = false 
	
	--local see_dist = 4 
	--local dist = math.sqrt(player:GetDistanceSqToInst(inst))
	
	local my_pos = inst:GetPosition()
	local player_pos = player:GetPosition()
	local my_angle = inst.Transform:GetRotation()
	local player_to_my_angle = inst:GetAngleToPoint(player_pos)
	local angle_sub = math.abs(player_to_my_angle - my_angle)
	
	if angle_sub > 90 then 
		cant_see = true 
	end
	
	--print("CantSeeSneakingPlayer?","my_angle:",my_angle,"player_to_my_angle:",player_to_my_angle,"angle_sub:",angle_sub,cant_see)
	if inst.sg and inst.sg:HasStateTag("sleeping") then 
		cant_see = true 
	end
	return cant_see
end --]]


local function ApplySuitableSpeedMult(inst) 
	local self = inst.components.iceysneaker
	self:ApplySuitableSpeedMult() 
end 

local function onsneakervision_enable(self,sneakervision_enable)
	self.inst.replica.iceysneaker:ApplySneakerVision(sneakervision_enable)
end 

local IceySneaker = Class(function(self, inst)
	self.inst = inst
	self.issneaking = false 
	self.sneak_speed_mult = 0.5
	self.mount_sneak_speed_mult = 0.25
	self.sneakervision_enable = false 
	--self:StopSneak()
end,
nil,
{
	sneakervision_enable = onsneakervision_enable,
})

function IceySneaker:GetSuitableSpeedMult()
	--local runspeed = self.inst.components.locomotor:GetRunSpeed() 
	return (self.inst.components.rider and self.inst.components.rider:IsRiding()) and self.mount_sneak_speed_mult or self.sneak_speed_mult
end 

function IceySneaker:ApplySuitableSpeedMult()
	if self:IsSneaking() then 
		local speedmult = self:GetSuitableSpeedMult() 
		self.inst.components.locomotor:SetExternalSpeedMultiplier(self.inst, "icey_sneaking",speedmult)
		self.inst.components.locomotor:EnableGroundSpeedMultiplier(false)
	else
		self.inst.components.locomotor:RemoveExternalSpeedMultiplier(self.inst, "icey_sneaking")
		self.inst.components.locomotor:EnableGroundSpeedMultiplier(true)
	end
end 

function IceySneaker:ApplySneakerVision(enable)
	print("IceySneaker:ApplySneakerVision()",enable)
	self.sneakervision_enable = enable
    self.inst.components.playervision:ForceNightVision(enable)
end 

function IceySneaker:StartSneak()
	self:StopSneak()
	self.inst:AddTag("icey_sneaking")
	self.issneaking = true  
	self.inst:ListenForEvent("mounted",ApplySuitableSpeedMult)
	self.inst:ListenForEvent("dismount",ApplySuitableSpeedMult)
	self.inst:ListenForEvent("dismounted",ApplySuitableSpeedMult)
	self:ApplySuitableSpeedMult() 
	--self:ApplySneakerVision(true) 
end

function IceySneaker:IsSneaking()
	return self.issneaking
end 

function IceySneaker:StopSneak()
	if self:IsSneaking() then 
		self.inst:RemoveTag("icey_sneaking")
		self.issneaking = false 
		self.inst:RemoveEventCallback("mounted",ApplySuitableSpeedMult)
		self.inst:RemoveEventCallback("dismount",ApplySuitableSpeedMult)
		self.inst:RemoveEventCallback("dismounted",ApplySuitableSpeedMult)
		self:ApplySuitableSpeedMult() 
		--self:ApplySneakerVision(false) 
	end 
end

-------------����Ŀ�������
function IceySneaker:OnTargetBack(target)
	local my_pos = self.inst:GetPosition()
	local target_pos = target:GetPosition()
	
	local my_angle = self.inst:GetRotation()
	local target_angle = target:GetRotation()
	local target_to_my_angle = self.inst:GetAngleToPoint(target_pos)
	
	return math.abs(target_angle - target_to_my_angle) <= 90 
end

function IceySneaker:CanTerminateTarget(target,kill_in_sleep)
	return target and target:IsValid() and self:IsSneaking()
	and (self:OnTargetBack(target) or (kill_in_sleep and target.sg and target.sg:HasStateTag("sleeping")))
end

return IceySneaker