modimport("scripts/tools/waffles")

local function HasFakeGroundNearBy(map,x,y,z)
	local grounds = TheSim:FindEntities(x,y,z,75,{"FAKEGROUND"})
	for k,v in pairs(grounds) do 
		local v_pos = v:GetPosition()
		local target_pos = Vector3(x,y,z)
		local dist = target_pos:Dist(v_pos)
			
		if v.FAKEGROUND_RADIUS == nil or v.FAKEGROUND_RADIUS >= dist then 
			return true,v  
		end
	end
	return false 
end

local function IsPassableAtPoint(map, passable, x, y, z)
	if passable then
		return true
	end
	return map:HasFakeGroundNearBy(x, y, z)
end

local function GetInteriorTileCenterPoint(x, y, z)
	return math.floor((x + 2) / 4) * 4, 0, math.floor((z + 2) / 4) * 4
end

local function GetInteriorTileKey(...)
	local x, y, z = GetInteriorTileCenterPoint(...)
	return x.."_"..z
end

Waffles.GetInteriorTileKey = GetInteriorTileKey

local function GetTileCenterPoint(map, pos, ...)
	if pos ~= nil then
		return unpack(pos)
	end
	return GetInteriorTileCenterPoint(...)
end

local function IsPathClear(pathfinder, isclear, ...)
	if isclear then
		return true
	end
	if TheWorld.Map:HasFakeGroundNearBy(arg[1], arg[2], arg[3]) then
		if (arg[7] and arg[7].ignorewalls) or not TheWorld.Pathfinder:HasWall(arg[4], arg[5], arg[6]) then
			return true
		end
	end
	return false
end

AddPrefabPostInit("world", function(inst)
	local Map = getmetatable(inst.Map).__index
	Map.HasFakeGroundNearBy = HasFakeGroundNearBy
	Waffles.SequenceFn(Map, "IsPassableAtPoint", true, IsPassableAtPoint)
	Waffles.SequenceFn(Map, "IsAboveGroundAtPoint", true, IsPassableAtPoint)
	--Waffles.SequenceFn(Map, "IsDeployPointClear", true, IsDeployPointClear)
	Waffles.SequenceFn(Map, "GetTileCenterPoint", true, GetTileCenterPoint)
	
	local Pathfinder = getmetatable(inst.Pathfinder).__index
	Waffles.SequenceFn(Pathfinder, "IsClear", true, IsPathClear)
	
	if not IsServer then
		return
	end
	
	--inst:DoTaskInTime(0, AddTelebaseSearchExtension)
end)

local function CheckAreaBgm(inst)
	local x,y,z = inst:GetPosition():Get() 
	local hasfakeground,ground = TheWorld.Map:HasFakeGroundNearBy(x,y,z)  
	if hasfakeground and ground and ground:IsValid() and ground.areaname 
	--and math.sqrt(inst:GetDistanceSqToInst(ground)) <= 45 
	then 
		inst:PushEvent("checkareabgm",{areaname = ground.areaname})
	else	
		inst:PushEvent("checkareabgm",{areaname = "NULL"})
	end
end 

AddPlayerPostInit(function(inst)
	inst.CheckAreaBgm = CheckAreaBgm 
	inst:DoTaskInTime(1,CheckAreaBgm)
	inst:DoPeriodicTask(5,CheckAreaBgm) 
end)

require("entityscript")
function EntityScript:IsOnValidGround()
	local x,y,z = self.Transform:GetWorldPosition() 
    local tile = self:GetCurrentTileType()
    return (tile ~= nil and tile ~= GROUND.IMPASSABLE) or TheWorld.Map:HasFakeGroundNearBy(x,y,z)  
end
