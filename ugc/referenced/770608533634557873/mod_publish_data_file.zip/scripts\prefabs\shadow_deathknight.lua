local assets =
{
        Asset( "ANIM", "anim/player_basic.zip" ),
        Asset( "ANIM", "anim/player_idles_shiver.zip" ),
        Asset( "ANIM", "anim/player_actions.zip" ),
        Asset( "ANIM", "anim/player_actions_axe.zip" ),
        Asset( "ANIM", "anim/player_actions_pickaxe.zip" ),
        Asset( "ANIM", "anim/player_actions_shovel.zip" ),
        Asset( "ANIM", "anim/player_actions_blowdart.zip" ),
        Asset( "ANIM", "anim/player_actions_eat.zip" ),
        Asset( "ANIM", "anim/player_actions_item.zip" ),
        Asset( "ANIM", "anim/player_actions_uniqueitem.zip" ),
        Asset( "ANIM", "anim/player_actions_bugnet.zip" ),
        Asset( "ANIM", "anim/player_actions_fishing.zip" ),
        Asset( "ANIM", "anim/player_actions_boomerang.zip" ),
        Asset( "ANIM", "anim/player_bush_hat.zip" ),
        Asset( "ANIM", "anim/player_attacks.zip" ),
        Asset( "ANIM", "anim/player_idles.zip" ),
        Asset( "ANIM", "anim/player_rebirth.zip" ),
        Asset( "ANIM", "anim/player_jump.zip" ),
        Asset( "ANIM", "anim/player_amulet_resurrect.zip" ),
        Asset( "ANIM", "anim/player_teleport.zip" ),
        Asset( "ANIM", "anim/wilson_fx.zip" ),
        Asset( "ANIM", "anim/player_one_man_band.zip" ),
        Asset( "ANIM", "anim/shadow_hands.zip" ),
		
		Asset( "ANIM", "anim/player_transform_merm.zip" ),
		Asset("ANIM", "anim/swap_alex_blade.zip"),
		
        Asset( "SOUND", "sound/sfx.fsb" ),
        Asset( "SOUND", "sound/wilson.fsb" ),
        Asset( "ANIM", "anim/beard.zip" ),
		Asset("SOUND", "sound/pig.fsb"),
		
		Asset("ANIM", "anim/shadow_rook.zip"),
        Asset("ANIM", "anim/shadow_rook_upg_build.zip"),
		Asset("ANIM", "anim/shadow_insanity2_basic.zip"),
}



local speech_infected = 
{
	"你无法杀死自己的罪恶",
	"让我们融为一体吧",
	"展开审判的翅膀",
	"时机已到.....",
	"没有和平...就没有安宁....",
}


local MAX_TARGET_SHARES = 5
local SHARE_TARGET_DIST = 30

local werepigbrain = require "brains/deathknightbrain"

local function OnFinishDisappear(inst)
	if inst then 
		inst:Hide()
		inst:RemoveEventCallback("animover",OnFinishDisappear)
	end 
end 

local function OnDisAppear(inst,isremove)
	inst.components.health:SetInvincible(true)
	inst.Transform:SetFourFaced()
	inst.AnimState:SetBank("shadow_rook") 
	inst.AnimState:SetBuild("shadow_rook")
    inst.AnimState:PlayAnimation("teleport",false)
	inst.Transform:SetPosition(0,5,0)
	inst.Transform:SetScale(0.5,0.5,0.5)
	if isremove then 
		if not inst.components.health:IsDead() then 
			inst:ListenForEvent("animover",inst.Remove)
		end 
	else 
		inst:ListenForEvent("animover",OnFinishDisappear)
	end
end

local function OnShow(inst)
	inst.components.health:SetInvincible(false)
	inst.Transform:SetSixFaced()
	inst.AnimState:SetBank("wilsonbeefalo") 
	inst.AnimState:SetBuild("webber")
	inst.sg:GoToState("attack")
	inst.Transform:SetScale(1,1,1)
	inst.Transform:SetPosition(0,1,0) 
	inst:Show()
	
	inst.shield = SpawnPrefab("icey_shield")
	inst.shield.entity:SetParent(inst.entity)         
	inst.shield.Transform:SetPosition(0,2,0) 
	inst.shield.AnimState:SetMultColour(0,0,0,0.8)
	inst.shield.Transform:SetScale(1.3,1.3,1.3)  
	
	local fxs = SpawnPrefab("shadow_bishop_fx")
	fxs.Transform:SetPosition(inst.Transform:GetWorldPosition())
	
end 

local function ontalk(inst, script)
    inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/idle")
end

local function CalcSanityAura(inst, observer)
    return -TUNING.SANITYAURA_LARGE
end



local function OnAttacked(inst, data)
    --print(inst, "OnAttacked")
    local attacker = data.attacker
	inst.components.combat:SetTarget(attacker)
	inst.components.combat:ShareTarget(attacker, 30, function(dude)
        return  (dude:HasTag("shadowchesspiece"))
            and not dude.components.health:IsDead()
    end, 10)
end

local function OnNewTarget(inst, data)
	--[[inst:DoTaskInTime(math.random(0,5),function()
		inst.components.talker:Say(speech_infected[math.random(1,#speech_infected)])
	end)--]]
end

local function WerepigRetargetFn(inst)
    return FindEntity(
        inst,
        30,
        function(guy)
            return inst.components.combat:CanTarget(guy)
        end,
        { "_combat","player"}, --See entityreplica.lua (re: "_combat" tag)
        { "monster","shadowchesspiece","structure","prey","smallcreature"}
    )
end

local function WerepigKeepTargetFn(inst, target)
    return inst.components.combat:CanTarget(target)
           and not target:HasTag("shadowchesspiece") 
end

local function OnChildDeath(inst)
	if inst.fire2 then 
		inst.fire2:Remove()
	end
end 

local function common(prefab,bank,build,anim)
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddDynamicShadow()
    inst.entity:AddLightWatcher()
    inst.entity:AddNetwork()

    MakeCharacterPhysics(inst, 50, .5)

    inst.DynamicShadow:SetSize(0,0)
	inst.Transform:SetSixFaced()

    --inst:AddTag("character")
	--inst:AddTag("groggy")
    inst:AddTag("tadalin")  
	inst:AddTag("hostile")
	inst:AddTag("shadowchesspiece")
	inst:AddTag("epic")
	inst:AddTag("noepicmusic")
	--inst:AddTag("NOCLICK")
	--inst:AddTag("monster")
	--inst:AddTag("infected")
	
    inst.AnimState:SetBank(bank) 
	inst.AnimState:SetBuild(build)
    inst.AnimState:PlayAnimation(anim, true)

	--inst.AnimState:OverrideSymbol("swap_hat", "hat_skeleton", "swap_hat")
	inst.AnimState:Hide("leg")
	inst.AnimState:Hide("foot")
	inst.AnimState:Hide("face")
	inst.AnimState:OverrideSymbol("swap_object", "swap_alex_blade", "swap_alex_blade")
	inst.AnimState:OverrideSymbol("swap_saddle","saddle_war", "swap_saddle")
    inst.AnimState:Show("ARM_carry")
    inst.AnimState:Hide("ARM_normal")
	
	
	
	--inst.AnimState:SetMultColour(1,1,1,1)
	inst.AnimState:SetMultColour(0,0,0,0.8)
	

    --Sneak these into pristine state for optimization
    inst:AddTag("_named")
    inst.entity:SetPristine()
	
	inst:AddComponent("talker")
    inst.components.talker.fontsize = 35
    inst.components.talker.font = TALKINGFONT
    --inst.components.talker.colour = Vector3(133/255, 140/255, 167/255)
    inst.components.talker.offset = Vector3(0, -400, 0)
    inst.components.talker:MakeChatter()
	inst.components.talker.ontalk = ontalk

    if not TheWorld.ismastersim then
        return inst
    end

	inst.OnDisAppear = OnDisAppear
	inst.OnShow = OnShow
	
	--[[inst.fire2 = SpawnPrefab("torchfire_shadow")
	--inst.fire.Transform:SetScale(0.3,0.3,0.3)
    inst.fire2.entity:AddFollower()
    inst.fire2.Follower:FollowSymbol(inst.GUID, "swap_object", 0, 0, 0)--]]

	inst:AddComponent("combat")
    inst.components.combat:SetTarget(nil)
    inst.components.combat:SetRetargetFunction(math.random() + 0.5, WerepigRetargetFn)
    inst.components.combat:SetKeepTargetFunction(WerepigKeepTargetFn) 
	inst.components.combat:SetDefaultDamage(20)
    inst.components.combat:SetAttackPeriod(2)
	inst.components.combat:SetRange(3,3)
	
    inst:AddComponent("locomotor") -- locomotor must be constructed before the stategraph
    inst.components.locomotor.runspeed = 2
    inst.components.locomotor.walkspeed = 1.5
	
	inst:AddComponent("rider")
	inst:AddComponent("pinnable")
    inst:AddComponent("bloomer")

    ------------------------------------------
    inst:AddComponent("health")
	inst.components.health:SetMaxHealth(10000)
   
    inst:AddComponent("named")
	inst.components.named:SetName("噩梦融合体")

   
    ------------------------------------------
    inst:AddComponent("follower")
    inst.components.follower.maxfollowtime = TUNING.PIG_LOYALTY_MAXTIME
    ------------------------------------------
    inst:AddComponent("inventory")
	inst.components.inventory.DropEverything = function(self,ondeath, keepequip)
		if self.activeitem ~= nil then
			self:DropItem(self.activeitem)
			self:SetActiveItem(nil)
		end

		for k = 1, self.maxslots do
			local v = self.itemslots[k]
			if v ~= nil then
				v:Remove()
			end
		end

		if not keepequip then
			for k, v in pairs(self.equipslots) do
				if not (ondeath and v.components.inventoryitem.keepondeath) then
					v:Remove()
				end
			end
		end
	
	end 
    ------------------------------------------
    inst:AddComponent("lootdropper")
	inst.components.lootdropper:SetLoot({  })
    inst.components.lootdropper.numrandomloot = 0
    ------------------------------------------
    inst:AddComponent("knownlocations")
    ------------------------------------------

    inst:AddComponent("sanityaura")
    inst.components.sanityaura.aurafn = CalcSanityAura


    inst:AddComponent("inspectable")
    inst.components.inspectable:SetDescription("....")
   
	inst:SetBrain(werepigbrain)
    inst:SetStateGraph("SGDeathKnight")
	
    inst:ListenForEvent("attacked", OnAttacked)
    inst:ListenForEvent("newcombattarget", OnNewTarget)
	inst:ListenForEvent("death",OnChildDeath)
	inst:ListenForEvent("onremove",OnChildDeath)

    return inst
end

local ly_people = 
{
	--[["wilson",
	"wathgrithr",
	"wendy",
	"wes",
	"waxwell",--]]
	"webber",
	--"icey",
	--[["wolfgang",
	"wickerbottom",
	"willow",
	"winona",
	"woodie",
	"wx78",--]]
}

local prefabs_infected = {}

for k,v in pairs(ly_people) do 
	local function Infecteds()
		local inst = common(v.."_deathknight","wilsonbeefalo",v,"idle")
		return inst
	end
	table.insert(prefabs_infected,Prefab(v.."_deathknight", Infecteds, assets))
end


return unpack(prefabs_infected)
