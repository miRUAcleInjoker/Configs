--------darkspirit
local invade_strs = {
	"遭到灵体 %s 的入侵",
	"你的世界正在被 %s 入侵",
}

local stop_invade_strs = {
	"灵体 %s 停止了入侵",
}

local function ondeath(inst,data)
	inst.components.darkspirit:StopInvade() 
end 

local DarkSpirit = Class(function(self,inst)
	self.inst = inst 
	self.isinvading = false 
	self.invader_name = nil 
	
	inst:ListenForEvent("death",ondeath)
--[[	if inst.components.health then 
		local old_SetPercent = inst.components.health.SetPercent
		local old_SetVal = inst.components.health.SetVal
		local old_DoDelta = inst.components.health.DoDelta
	end--]]
	--self.inst:ListenForEvent("death",ondeath)
end)

function DarkSpirit:SetInvaderName(name)
	self.invader_name = tostring(name) 
end 

function DarkSpirit:IsInvading()
	return self.isinvading
end 

function DarkSpirit:StartInvade()
	if not self:IsInvading() then 
		self.isinvading = true 
		self.inst:AddTag("darkspirit")
		self.inst:SpawnChild("statue_transition")
		self.inst:SpawnChild("statue_transition_2")
		for k,player in pairs(AllPlayers) do 
			if player and player:IsValid() and player.SoundEmitter then 
				player.SoundEmitter:PlaySound("dontstarve/cave/nightmare_warning")
			end
		end 
		local name = self.invader_name or self.inst.name or tostring(self.inst) or " "
		local str = string.format(invade_strs[math.random(1,#invade_strs)],name) or ""
		TheNet:Announce(str)
	else
		print("[DarkSpirit:StartInvade()]:ERROR!This entity is already invading!")
	end 
end

function DarkSpirit:StopInvade()
	if self:IsInvading() then 
		self.isinvading = false  
		self.inst:RemoveTag("darkspirit")
		
		local name = self.invader_name or self.inst.name or tostring(self.inst) or " "
		local str = string.format(stop_invade_strs[math.random(1,#stop_invade_strs)],name) or ""
		TheNet:Announce(str)
	else
		print("[DarkSpirit:StopInvade()]:ERROR!This entity is not invading!")
	end 
end



return DarkSpirit 