local assets =
{
    Asset("ANIM", "anim/rock_crystal.zip"),--------建筑的贴图文件
	Asset("IMAGE","images/inventoryimages/crystal_item.tex"),
	Asset("ATLAS","images/inventoryimages/crystal_item.xml")
}

local assets_cuts = {
	Asset("ANIM", "anim/cutcrystal.zip"),
	Asset("IMAGE","images/inventoryimages/cutcrystal.tex"),
	Asset("ATLAS","images/inventoryimages/cutcrystal.xml")
}

SetSharedLootTable( 'rock_crystal',     --------------建筑被破坏后掉落的东西列表
{
    {'crystal_item', 1.00},
	{'crystal_item', 0.75},
	{'crystal_item', 0.50},
	{'crystal_item', 0.25},
	--{'opalpreciousgem', 0.01},
})

local max_workleft = 125

local function CheckWork(inst,workleft,max)
	if workleft / max_workleft <= 0.33 then 
		inst.AnimState:PlayAnimation("idle_33")
		MakeObstaclePhysics(inst, 0.33) --------------建筑物理碰撞体积
	elseif workleft / max_workleft <= 0.66 then 
		inst.AnimState:PlayAnimation("idle_66")
		MakeObstaclePhysics(inst, 0.66) --------------建筑物理碰撞体积
	end
end 

local function OnWorked(inst,worker,workleft)
	local pos = inst:GetPosition()
	pos.y = pos.y + math.random()
	CheckWork(inst,workleft,max_workleft)
	if workleft <= 0 then ----------------如果在一次砸击中建筑被彻底破坏了
        local pos = inst:GetPosition()
        inst.components.lootdropper:DropLoot(pos)---------------原地掉落列表中的东西
		inst.components.lootdropper:DropLoot(pos)---------------原地掉落列表中的东西
		inst.components.lootdropper:DropLoot(pos)---------------原地掉落列表中的东西
		if math.random(0,100) < 1 then 
			local item = SpawnPrefab("opalpreciousgem")
			if item then 
				item.Transform:SetPosition(pos.x,pos.y,pos.z)
			end 
		end
		inst.SoundEmitter:PlaySound("dontstarve_DLC001/common/iceboulder_smash")
        inst:Remove()--------移除建筑
	elseif workleft % 8 == 0 then 
		inst.components.lootdropper:DropLoot(pos)---------------原地掉落列表中的东西
    end 
	
end 

local function OnNewSpawn(inst)
	local random = math.random(0,100)
	local scale = 1
	if random <= 33 then 
		scale = 1
	elseif random <= 66 then 
		scale = 0.65
	else
		scale = 0.34
	end

	inst.components.workable:SetWorkLeft(inst.components.workable.workleft * scale)
	CheckWork(inst,inst.components.workable.workleft,max_workleft)
end

local function OnRockLoad(inst,data)
	CheckWork(inst,inst.components.workable.workleft,max_workleft)
end 

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddMiniMapEntity()
    inst.entity:AddNetwork()

    MakeObstaclePhysics(inst, 1) --------------建筑物理碰撞体积
	local minimap = inst.entity:AddMiniMapEntity() -------------设置小地图标志
	minimap:SetIcon("rock_crystal.tex")
	

    inst.AnimState:SetBank("rock_crystal")
    inst.AnimState:SetBuild("rock_crystal")
    inst.AnimState:PlayAnimation("idle_100") ----------喜闻乐见的动画设置
	
	inst.AnimState:SetMultColour(141/255,224/255,255/255,1)
	inst.Transform:SetScale(1.5,1.5,1.5)-----------------在这里设置建筑的放大缩小
	
	inst:AddTag("rock_crystal") -------------------添加一个小标签QwQ
	inst:AddTag("antlion_sinkhole_blocker")
    inst:AddTag("frozen")
	
    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst:AddComponent("lootdropper")
	inst.components.lootdropper:SetChanceLootTable('rock_crystal') -------------设置掉落物组件，和开头的列表对应
	
	inst:AddComponent("workable")
    inst.components.workable:SetWorkAction(ACTIONS.MINE)
	inst.components.workable:SetWorkLeft(max_workleft)
    inst.components.workable:SetOnWorkCallback(OnWorked)
	inst.components.workable.Destroy = function(self,destroyer)
		for i = 1,self.workleft do 
			if self:CanBeWorked() then
				self:WorkedBy(destroyer,1)
			end
		end 
	end 

    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("矿物储量不足") ------------设置可检查组件
	
	inst.OnNewSpawn = OnNewSpawn
	inst.OnLoad = OnRockLoad
	CheckWork(inst,inst.components.workable.workleft,max_workleft)	
	
	
    MakeHauntableWork(inst)--------------被作祟时的函数，这里是空的
    MakeSnowCovered(inst)--------------建筑物积雪时的函数，这里是空的
	
	
    return inst
end


local function fn_item()
	local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddMiniMapEntity()
	inst.entity:AddDynamicShadow()
    inst.entity:AddNetwork()
	
	MakeInventoryPhysics(inst)
	inst.DynamicShadow:SetSize(0.5,0.5)
	
    inst.AnimState:SetBank("rock_crystal")
    inst.AnimState:SetBuild("rock_crystal")
    inst.AnimState:PlayAnimation("item"..math.random(1,3)) ----------喜闻乐见的动画设置
	
	inst.AnimState:SetMultColour(141/255,224/255,255/255,0.8)
	
	inst.Transform:SetScale(0.5,0.5,0.5)-----------------在这里设置建筑的放大缩小
	
	inst:AddTag("crystal_item") -------------------添加一个小标签QwQ
    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("矿物储量很足") ------------设置可检查组件
	
	inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "crystal_item"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/crystal_item.xml"
	
	inst:AddComponent("stackable")
	inst.components.stackable.maxsize = TUNING.STACK_SIZE_SMALLITEM
	
	

    MakeHauntableWork(inst)--------------被作祟时的函数，这里是空的
	
    return inst
end

local function fn_cuts()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()

    MakeInventoryPhysics(inst)

    inst.AnimState:SetBank("cutcrystal")
    inst.AnimState:SetBuild("cutcrystal")
    inst.AnimState:PlayAnimation("idle")

    inst:AddTag("molebait")

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst:AddComponent("stackable")
    inst.components.stackable.maxsize = TUNING.STACK_SIZE_LARGEITEM
	
    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("矿物储量非常足") ------------设置可检查组件

    inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "cutcrystal"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/cutcrystal.xml"
	
    inst:AddComponent("tradable")
    inst.components.tradable.rocktribute = 3
	inst.components.tradable.goldvalue = 3

    inst:AddComponent("bait")

    MakeHauntableLaunch(inst)

    return inst
end

return Prefab("rock_crystal", fn, assets),
Prefab("crystal_item", fn_item, assets),
Prefab("cutcrystal", fn_cuts, assets_cuts)