local IceyUtil = require("icey_util")
local IceyWeaponSkillUtil = require("icey_weaponskill_util")

local brain = require("brains/blood_blade_minion_brain")

local assets=
{
	Asset("ANIM", "anim/sword_buster.zip"),
    Asset("ANIM", "anim/swap_sword_buster.zip"),
	
	Asset("ANIM", "anim/swap_blood_blade.zip"),
	
	Asset("SOUNDPACKAGE", "sound/blood_blade_minion.fev"),
    Asset("SOUND", "sound/blood_blade_minion.fsb"),
	
	--blood_blade
	
	Asset("IMAGE","images/inventoryimages/blood_blade.tex"),
	Asset("ATLAS","images/inventoryimages/blood_blade.xml"),
}

local FunnySounds = {
	attack = {
		"blood_blade_minion/blade/blood_blade_tao",
		"blood_blade_minion/blade/blood_blade_xinei",
	},
	attack_hop = {
		"blood_blade_minion/blade/blood_blade_oliya",
		"blood_blade_minion/blade/blood_blade_kuluoyi",
		"blood_blade_minion/blade/blood_blade_toliya",
	},
	attack_circle = {
		"blood_blade_minion/blade/blood_blade_oliya",
		"blood_blade_minion/blade/blood_blade_nuoliya",
	},
	attack_charge = {
		"blood_blade_minion/blade/blood_blade_suoliya",
		"blood_blade_minion/blade/blood_blade_tao",
	},
	hit = {
		"blood_blade_minion/blade/blood_blade_aohu",
		"blood_blade_minion/blade/blood_blade_songna",
		"blood_blade_minion/blade/blood_blade_nu",
	},
	death = {	
		"blood_blade_minion/blade/blood_blade_awuyi",
		"blood_blade_minion/blade/blood_blade_aohu",
	},
	taunt = {
		--"blood_blade_minion/blade/blood_blade_awuyi",
		"blood_blade_minion/blade/blood_blade_tao",
		"blood_blade_minion/blade/blood_blade_xinei",
		--"blood_blade_minion/blade/blood_blade_aohu",
		"blood_blade_minion/blade/blood_blade_songna",
		--"blood_blade_minion/blade/blood_blade_nu",
	},
}

local function PlayFunnySound(inst,name)
	local sounds = {}
	local soundpack = FunnySounds[name]
	for k,v in pairs(soundpack) do 
		if v ~= inst.LastSound then 
			table.insert(sounds,v)
		end
	end
	
	local soundname = sounds[math.random(1,#sounds)]
	inst.SoundEmitter:PlaySound(soundname)
	inst.LastSound = soundname
end 

local function onequip(inst, owner) 
	owner.AnimState:OverrideSymbol("swap_object", "swap_blood_blade", "swap_blood_blade")
	owner.AnimState:Show("ARM_carry") 
	owner.AnimState:Hide("ARM_normal") 
	
end

local function onunequip(inst, owner) 
	owner.AnimState:Hide("ARM_carry") 
	owner.AnimState:Show("ARM_normal")
end

local function OnHitOther(inst,data)
	SpawnPrefab("icey_weaponsparks"):SetPiercing(inst,data.target)
end 

local SymbolToHide = {
	"arm_lower",
	"arm_upper",
	"torso",
}

local function ChangeState(inst,state)
	if state == "weapon" then 
		--[[inst.AnimState:Hide("ARM_carry") 
		inst.AnimState:Show("ARM_normal")
		inst.AnimState:ClearOverrideSymbol("swap_object")
		inst.AnimState:SetBank("sword_buster")
		inst.AnimState:SetBuild("sword_buster")
		inst.AnimState:PlayAnimation("idle")
		inst.Transform:SetNoFaced()--]]
		
		if inst.sg then 
			inst.sg:GoToState("idle")
		end 
		inst:ClearStateGraph()
		inst:StopBrain()
		inst.Physics:Stop() 
	elseif state == "minion" then 
		inst.AnimState:SetBank("wilson")
		inst.AnimState:SetBuild("swap_icey_hunter_clothing1")
		inst.AnimState:PlayAnimation("idle")
		inst.AnimState:OverrideSymbol("swap_object", "swap_blood_blade", "swap_blood_blade")
		inst.AnimState:Show("ARM_carry") 
		inst.AnimState:Hide("ARM_normal") 
		for k,v in pairs(SymbolToHide) do 
			inst.AnimState:HideSymbol(v)
		end
		inst.Transform:SetFourFaced()
		
		inst:SetStateGraph("SGblood_blade_minion")
		inst:RestartBrain()
		inst.Physics:Stop() 
	end
end 

local function OnPickUp(inst,owner)
	inst:ChangeState("weapon")
end 

local function OnDropped(inst)
	print(inst,"OnDropped")
	inst:ChangeState("minion")
end 

local function OnChoose(inst,owner)
	return owner == inst.components.follower.leader or owner:HasTag("icey_shadow")
end 

local function OnInit(inst)
	local owner = inst.components.inventoryitem.owner
	if owner then
		inst:ChangeState("weapon")
	else
		inst:ChangeState("minion")
	end
end 

local function OnRemove(pet)
	--SpawnPrefab(pet:HasTag("flying") and "spawn_fx_small_high" or "spawn_fx_small").Transform:SetPosition(pet.Transform:GetWorldPosition())
	--pet.components.inventory:DropEverything()
	--pet.components.lootdropper:DropLoot()
	local owner = pet.components.inventoryitem:GetGrandOwner()
	if owner and owner:IsVaid() then 
		if owner.components.inventory then 
			owner.components.inventory:DropItem(pet)
		elseif owner.components.container then 
			owner.components.container:DropItem(pet)
		end 
	end
	local x,y,z = pet.Transform:GetWorldPosition()
	SpawnAt("brokentool",Vector3(x,y,z))
	local soul = SpawnAt("dark_antqueen_soul",Vector3(x,y,z))
	PlayFunnySound(soul,"death")
end 

local function commonfn(Sim)
	local inst = CreateEntity()
	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddSoundEmitter()
	inst.entity:AddNetwork()
	
	MakeInventoryPhysics(inst)
	RemovePhysicsColliders(inst)
	
	--inst.AnimState:SetBank("sword_buster")
	--inst.AnimState:SetBuild("sword_buster")
	--inst.AnimState:PlayAnimation("idle")
	
	inst.AnimState:AddOverrideBuild("player_lunge")
    inst.AnimState:AddOverrideBuild("player_attack_leap")
    inst.AnimState:AddOverrideBuild("player_superjump")
    inst.AnimState:AddOverrideBuild("player_multithrust")
    inst.AnimState:AddOverrideBuild("player_parryblock")

	inst:AddTag("hop_attack")
	inst:AddTag("pointy")
	inst:AddTag("companion")
	inst:AddTag("critter")
	inst:AddTag("notraptrigger")
    inst:AddTag("noauradamage")
    inst:AddTag("small_livestock")
    inst:AddTag("NOBLOCK")
	
	inst.entity:SetPristine()
    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.LastSound = nil 
	inst.CircleLoop = 0
	inst.ChangeState = ChangeState 
	inst.PlayFunnySound = PlayFunnySound 
	
	inst:AddComponent("age")
    inst:AddComponent("knownlocations")
	inst:AddComponent("bloomer")
    inst:AddComponent("colouradder")
	inst:AddComponent("timer")
	
	inst:AddComponent("crittertraits")
	inst.components.crittertraits:SetOnAbandonedFn(OnRemove)
	local old_OnPet = inst.components.crittertraits.OnPet
	inst.components.crittertraits.OnPet = function(self,petter)
		self.inst:PushEvent("pre_critter_onpet")
		if self.inst.sg:HasStateTag("sleeping") 
		or not ( 
			self.inst.sg:HasStateTag("busy") 
			or self.inst.sg:HasStateTag("working")
			or (self.inst:GetBufferedAction() and self.inst:GetBufferedAction():IsValid())
		) then 
			old_OnPet(self,petter)
		end 
	end 
	
	
	inst:AddComponent("locomotor") -- locomotor must be constructed before the stategraph
    inst.components.locomotor.walkspeed = 5
    inst.components.locomotor.runspeed = 7
	inst.components.locomotor.softstop = true
	inst.components.locomotor.pathcaps = { allowocean = true }
	
	inst:AddComponent("follower")
    inst.components.follower:KeepLeaderOnAttacked()
    inst.components.follower.keepdeadleader = true
	inst.components.follower.keepleaderduringminigame = true
	
	inst:AddComponent("combat")
    inst.components.combat.defaultdamage = 34
	inst.components.combat:SetRange(4,2)
    inst.components.combat:SetAreaDamage(3,0.6)
	inst.components.combat:SetAttackPeriod(3)
    --inst.components.combat:SetRetargetFunction(3, Retarget)
	--inst.components.combat:SetKeepTargetFunction(KeepTarget)
	inst.components.combat:EnableAreaDamage(false) 

	inst:AddComponent("weapon")
	inst.components.weapon:SetDamage(42)	
	inst.components.weapon:SetRange(0.1)

	inst:AddComponent("inspectable")
	
	inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "blood_blade"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/blood_blade.xml"
	
	inst:AddComponent("equippable")
	inst.components.equippable:SetOnEquip( onequip )
	inst.components.equippable:SetOnUnequip( onunequip )
	
	inst:AddComponent("chosenpeople")
	inst.components.chosenpeople:SetChosenFn(OnChoose)
	
	inst:SetBrain(brain)
	
	inst:DoTaskInTime(0,OnInit)
	inst:ListenForEvent("onputininventory",OnPickUp)
	inst:ListenForEvent("ondropped",OnDropped)
	inst:ListenForEvent("onhitother",OnHitOther)
	--inst:ListenForEvent("onremove",OnRemove)
	IceyUtil.MakeIceyAlly(inst) 
	
	return inst
end

-------------------------------------------------------------------------------
local function builder_onbuilt(inst, builder)
    local theta = math.random() * 2 * PI
    local pt = builder:GetPosition()
    local radius = 1
    local offset = FindWalkableOffset(pt, theta, radius, 6, true)
    if offset ~= nil then
        pt.x = pt.x + offset.x
        pt.z = pt.z + offset.z
    end
    builder.components.petleash:SpawnPetAt(pt.x, 0, pt.z, inst.pettype, inst.linked_skinname)
    inst:Remove()
end

local function MakeBuilder(prefab)
    local function fn()
        local inst = CreateEntity()

        inst.entity:AddTransform()

        inst:AddTag("CLASSIFIED")

        --[[Non-networked entity]]
        inst.persists = false

        --Auto-remove if not spawned by builder
        inst:DoTaskInTime(0, inst.Remove)

        if not TheWorld.ismastersim then
            return inst
        end

        inst.pettype = prefab
        inst.OnBuiltFn = builder_onbuilt

        return inst
    end

    return Prefab(prefab.."_builder", fn, nil, { prefab })
end
-------------------------------------------------------------------------------

return Prefab( "blood_blade_minion", commonfn, assets),
MakeBuilder("blood_blade_minion")
