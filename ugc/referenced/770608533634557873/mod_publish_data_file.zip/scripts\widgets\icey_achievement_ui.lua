local Screen = require "widgets/screen"
local TEMPLATES = require "widgets/redux/templates"
local Widget = require "widgets/widget"
local Text = require "widgets/text"
local TextButton = require "widgets/textbutton"
local Image = require "widgets/image"
local ImageButton = require "widgets/imagebutton"
local PopupDialogScreen = require "screens/redux/popupdialog"

local panel1_width = 500 --左面板宽度
local panel1_height = 500 --左面板高度
local panel2_width = 300 --右面板宽度
local panel2_height = 500 --右面板高度
local panel_space = 72 --左右面板间隙
local panel1_posx = - (panel_space + panel2_width) / 2
local panel2_posx = (panel_space + panel1_width) / 2
local list_height = panel1_height * 0.8
local list_width = panel1_width
local listrow_width = list_width
local listrow_height = 125
local scrollbar_tint = {0xA0/255, 0x52/255, 0x2D/255, 1}

--[[if id == nil then
			id = QUAGMIRE_NUM_FOOD_RECIPES
			self.all_recipes[id].id_str = STRINGS.UI.RECIPE_BOOK.SYRUP_RECIPE_ID
		end

		local is_image_loaded = true
        if QUAGMIRE_USE_KLUMP then
            is_image_loaded = IsKlumpLoaded("images/quagmire_food_inv_images_hires_"..client_name..".tex")
        end

		self.all_recipes[id].name = client_name
		self.all_recipes[id].recipe = recipe
		self.all_recipes[id].icon = client_name..".tex"
		if recipe.dish == nil then
			self.all_recipes[id].atlas = GetInventoryItemAtlas(self.all_recipes[id].icon)
		elseif not is_image_loaded then
			self.all_recipes[id].atlas = "images/quagmire_food_common_inv_images_hires.xml"
			self.all_recipes[id].icon = (recipe.station[1]=="pot" and "goop_" or "burnt_") .. recipe.dish .. ".tex"
		else
			self.all_recipes[id].atlas = "images/quagmire_food_inv_images_hires_"..client_name..".xml"
		end
		
		self.all_recipes[id].coin = recipe.base_value ~= nil and (recipe.base_value.coin4 ~= nil and 4 or recipe.base_value.coin3 ~= nil and 3 or recipe.base_value.coin2 ~= nil and 2 or 1) or nil
		self.all_recipes[id].silver = recipe.silver_value ~= nil and (recipe.silver_value.coin4 ~= nil and 4 or recipe.silver_value.coin3 ~= nil and 3 or recipe.silver_value.coin2 ~= nil and 2 or 1) or nil
	end--]]

--[[local all_achievements = {
	{name = "first_eat",title = "吃下第一口食物",desc = "blabla"},
}--]]

local function list_widget_constructor(context, i)--这里是每个表单布局
    local slide_factor = 0
	
    local group = Widget("list_root")
    group.hideable_root = group:AddChild(Widget("list"))
    group.hideable_root:SetPosition(-listrow_width/2 + slide_factor, 0)

    group.bg = group.hideable_root:AddChild(TEMPLATES.ListItemBackground(listrow_width, listrow_height))--每个表单的背景图
	group.bg:SetTextures("images/frontscreen.xml", "highlight_hover.tex")
    group.bg:SetOnGainFocus(function() context.screen.scroll_list:OnWidgetFocus(group) end)
    group.bg:SetPosition(listrow_width/2 - slide_factor, 0)
    group.focus_forward = group.bg
	
	--成就贴图
	group.IMAGE = group.hideable_root:AddChild(Image("images/battle_focus.xml","battle_focus.tex"))
	group.IMAGE:SetPosition(75,0)
	group.IMAGE:SetScale(0.8,0.8)
	
	--成就进度
	group.PROCESS = group.hideable_root:AddChild(Text(NUMBERFONT, 32))
	group.PROCESS:SetPosition(75,-45)
	
	--成就名字
	group.TITLE = group.hideable_root:AddChild(Text(DEFAULTFONT, 32))
	group.TITLE:SetColour(0xFF/255, 0xF6/255, 0x8F/255, 1)
	--group.TITLE:SetHorizontalSqueeze(true)
	group.TITLE:SetPosition(350, 20)
	group.TITLE:SetHAlign(ANCHOR_LEFT)
	group.TITLE:SetVAlign(ANCHOR_TOP)
	group.TITLE:SetRegionSize(450, 50)
	--group.TITLE:SetSize()
	
	--成就描述
	group.DESC = group.hideable_root:AddChild(Text(NUMBERFONT, 27))
	group.DESC:SetPosition(275,-60)
	group.DESC:EnableWordWrap(true)
	group.DESC:SetHAlign(ANCHOR_LEFT)
	group.DESC:SetVAlign(ANCHOR_TOP)
	group.DESC:SetRegionSize(300, 150)
	
	
	
	group.name = "MISSING_ACHIEVEMENT_NAME"
	

    return group
end

local function list_widget_update(context, widget, data)--这里是每个表单的具体数值
    if widget == nil then
        return
    elseif data == nil then
        widget.hideable_root:Hide()
        return
    else
        widget.hideable_root:Show()
    end
	
	local owner = context.screen.owner
	local process_str = owner.replica.icey_achievement_user:GetProcessDisplay(data.name)
	local is_achieved = owner.replica.icey_achievement_user:IsAchieved(data.name)
	
    widget.name = data.name
	widget.TITLE:SetString(data.title)
	widget.DESC:SetString(data.desc)
	if is_achieved then 
		widget.IMAGE:SetTint(1,1,1,1)
	else
		widget.IMAGE:SetTint(0.1,0.1,0.1,1)
	end 
	
	widget.PROCESS:SetString(process_str)
end

local aceevent = Class(Screen, function(self, owner,eventlist)--eventlist=具体数据表单,在界面按钮中加载，参考商店写法
	Screen._ctor(self, "aceevent")
	TheInput:ClearCachedController()
	self.owner = owner
	self.data = eventlist 
	--[[if owner.player_classified then
		owner.player_classified.lr_.mainscreen = self
	end--]]
	local data = eventlist
    self.black = self:AddChild(ImageButton("images/global.xml", "square.tex"))
    self.black.image:SetVRegPoint(ANCHOR_MIDDLE)
    self.black.image:SetHRegPoint(ANCHOR_MIDDLE)
    self.black.image:SetVAnchor(ANCHOR_MIDDLE)
    self.black.image:SetHAnchor(ANCHOR_MIDDLE)
    self.black.image:SetScaleMode(SCALEMODE_FILLSCREEN)
    self.black.image:SetTint(0, 0, 0, .35)
    self.black:SetOnClick(function() self:EnableShown(false) end)
	
	self.root = self:AddChild(Widget("ROOT"))
    self.root:SetVAnchor(ANCHOR_MIDDLE)
    self.root:SetHAnchor(ANCHOR_MIDDLE)
    self.root:SetPosition(0, 0, 0)
    self.root:SetScaleMode(SCALEMODE_PROPORTIONAL)
	

	self.panel = self.root:AddChild(Image("images/quagmire_recipebook.xml", "quagmire_recipe_menu_bg.tex"))
	self.panel:SetScale(0.2)
	self.panel:ScaleTo(0.2, 0.75, 0.2, function() 
		self:Init() 
	end)
	self.guanbi = self.panel:AddChild(ImageButton("images/global_redux.xml", "close.tex"))
	self.guanbi:SetOnClick(function() self:EnableShown(false) end)
	self.guanbi:SetPosition(380, -200, 0)	
	
	self.switch = self:AddChild(TextButton("switch"))
	self.switch:SetText("成就")
	self.switch:SetOnClick(function() 
		self:EnableShown(not self.root.shown) 
	end)
	self.switch:SetHAnchor(1) -- 设置原点x坐标位置，0、1、2分别对应屏幕中、左、右
	self.switch:SetVAnchor(2) -- 设置原点y坐标位置，0、1、2分别对应屏幕中、上、下
    self.switch:SetPosition(100,125,0) -- 设置ancientmac widget相对原点的偏移量
	
	
	self:SetInitData(data)
	
	self:EnableShown(false)
end)



function aceevent:EnableShown(enable)
	if enable then 
		self.black:Show()
		self.root:Show()
		self.panel:Show()
		self:StartUpdating()
	else
		self.black:Hide()
		self.root:Hide()
		self.panel:Hide()
		self:StopUpdating()
	end
end 

function aceevent:Init() --开始载入界面元素
	self.panel:SetScale(0.75)

	self.title = self.root:AddChild(Text(HEADERFONT, 34, "成就展柜"))
	self.title:SetPosition(panel1_posx - 120, 220)
	self.title:SetColour(0x8B/255, 0x00/255, 0x00/255, 1)
	

    self.scroll_list = self.root:AddChild(TEMPLATES.ScrollingGrid(
            self.data,
            {
                scroll_context = {
                    screen = self,
                },
                widget_width  = listrow_width,
                widget_height = listrow_height,
                num_visible_rows = math.floor(list_height / listrow_height),
                num_columns = 1,
                item_ctor_fn = list_widget_constructor,
                apply_fn = list_widget_update,
                scrollbar_offset = 20,
                scrollbar_height_offset = -60,
            }))
    self.scroll_list:SetPosition(-50,20)
	self.scroll_list.up_button.image:SetTint(unpack(scrollbar_tint))
	self.scroll_list.down_button.image:SetTint(unpack(scrollbar_tint))
	self.scroll_list.position_marker.image:SetTint(unpack(scrollbar_tint))
	--[[self.no = self.root:AddChild(Text(DEFAULTFONT, 40, "成就列表"))
	self.no:SetPosition(-185, 0)--]]
	--[[if self.initdata then
		self.scroll_maillist:SetItemsData(self.initdata)
	end]]--
	--
	
end


function aceevent:OnUpdate(dt)
	self.scroll_list:RefreshView() 
end 

function aceevent:SetInitData(data)--用来加载表单数据
	data = data or self.data 
	if self.scroll_list then		
		self.scroll_list:SetItemsData(data)
	else
		self.initdata = data
	end
end

return aceevent