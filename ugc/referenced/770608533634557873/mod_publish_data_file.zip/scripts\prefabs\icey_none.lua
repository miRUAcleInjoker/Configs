local assets =
{
	Asset( "ANIM", "anim/icey.zip" ),
	Asset( "ANIM", "anim/ghost_icey_build.zip" ),
}

local skins =
{
	normal_skin = "icey",
	ghost_skin = "ghost_icey_build",
}

local base_prefab = "icey"

local skin_tags = {"ICEY", "CHARACTER"}

return CreatePrefabSkin("icey_none",
{
	base_prefab = base_prefab, 
	skins = skins, 
	assets = assets,
	skin_tags = skin_tags,
	
	build_name_override = "icey",
	
	skip_item_gen = true,
	skip_giftable_gen = true,
})