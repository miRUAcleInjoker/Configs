local IceyUtil = require("icey_util")

local assets = {   
	Asset("ANIM", "anim/icey_seeleslash.zip"),  
}  

local function fn()
    local inst = CreateEntity()
	
	inst.entity:AddTransform()
	inst.entity:AddAnimState()
    inst.entity:AddNetwork()
	inst.entity:AddSoundEmitter()
	
	
	
	inst.AnimState:SetBloomEffectHandle("shaders/anim.ksh")
    inst.AnimState:SetBank("icey_seeleslash")
    inst.AnimState:SetBuild("icey_seeleslash")
    inst.AnimState:PlayAnimation("idle")
	
	inst.Transform:SetScale(2, 2, 2)   	
	inst.AnimState:SetLightOverride(1)   	
	inst.AnimState:SetFinalOffset(-1)   	
	inst.AnimState:SetOrientation(ANIM_ORIENTATION.OnGround)   
		
	inst:AddTag("FX")
	
    inst.entity:SetPristine()
	

    if not TheWorld.ismastersim then
        return inst
    end

    inst.persists = false
	
	--[[inst.DoAoeAttack = function(self,owner,radius,canattackfn)
		canattackfn = canattackfn or IceyUtil.CanAttack
		radius = radius or 7
		local x,y,z = inst:GetPosition():Get()
		for k,v in pairs(TheSim:FindEntities(x,y,z,radius,{"_combat"})) do 
			if v and canattackfn(v,owner) then 
				v.components.combat:GetAttacked(owner,math.random(62,120))
				SpawnAt("dark_hit_fx_icey",v:GetPosition())
			end
		end 
		
		inst.SoundEmitter:PlaySound("dontstarve/sanity/rook/taunt")
		inst.SoundEmitter:PlaySound("dontstarve_DLC003/common/crafted/vortex_armour/equip_off")
	end--]]
	
	inst:ListenForEvent("animover", inst.Remove)

	return inst
end

return Prefab("icey_seeleslash", fn,assets)