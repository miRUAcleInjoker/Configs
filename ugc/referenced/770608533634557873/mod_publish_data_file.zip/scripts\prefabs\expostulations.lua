require "prefabutil"

local assets =
{
    Asset("ANIM", "anim/sign_home.zip"),
	Asset("ANIM", "anim/expostulations.zip"),
	
    Asset("ANIM", "anim/ui_expostulations_5x3.zip"),
	
	Asset( "IMAGE", "images/inventoryimages/expostulations.tex" ),
	Asset( "ATLAS", "images/inventoryimages/expostulations.xml" ),
    Asset("MINIMAP_IMAGE", "sign"),
}

local prefabs =
{
    "collapse_small",
}

local SignGenerator = require"signgenerator"
local writeables = require"writeables"
local expostulations_kind = {
    prompt = STRINGS.SIGNS.MENU.PROMPT,
    animbank = "ui_expostulations_5x3",
    animbuild = "ui_expostulations_5x3",
    menuoffset = Vector3(6, -70, 0),

    cancelbtn = { text = STRINGS.SIGNS.MENU.CANCEL, cb = nil, control = CONTROL_CANCEL },
    middlebtn = { text = STRINGS.SIGNS.MENU.RANDOM, cb = function(inst, doer, widget)
            widget:OverrideText( SignGenerator(inst, doer) )
        end, control = CONTROL_MENU_MISC_2 },
    acceptbtn = { text = STRINGS.SIGNS.MENU.ACCEPT, cb = nil, control = CONTROL_ACCEPT },

	EditTextColour = {203/255,4/255,1/255,1},
    --defaulttext = SignGenerator,
} 

local old_makescreen = writeables.makescreen
 
function writeables.makescreen(inst, doer,...)
	if inst.prefab == "expostulations" then 
		local data = expostulations_kind
		if doer and doer.HUD then
			return doer.HUD:ShowWriteableWidget(inst, data)
		end
	else
		old_makescreen(inst,doer,...) 
	end 
end 

local function onhammered(inst, worker)
    inst.components.lootdropper:DropLoot()
    local fx = SpawnPrefab("collapse_small")
    fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
    fx:SetMaterial("wood")
    inst:Remove()
end

local function onhit(inst, worker)

end


local function onbuilt(inst)
    inst.SoundEmitter:PlaySound("dontstarve/common/sign_craft")
end

local function onphasechange(inst)
	local phase = TheWorld.state.phase
	--print(inst,"onphasechange",day)	
	if phase == "day" then 
		inst.Light:Enable(false)
	else
		inst.Light:Enable(true)
	end
end 

local function SetOnGround(inst)
    inst.AnimState:SetOrientation(ANIM_ORIENTATION.OnGround)
    inst.AnimState:SetLayer(LAYER_BACKGROUND)
    inst.AnimState:SetSortOrder(3)
end 

local SCALE = 1

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddMiniMapEntity()
    inst.entity:AddNetwork()
	inst.entity:AddLight()

    --MakeObstaclePhysics(inst, .2)
	
	inst.Light:SetIntensity(0.7)
	inst.Light:SetRadius(0.75)
	inst.Light:SetFalloff(0.5)
	inst.Light:SetColour(255/255,143/255,0/255)
	inst.Light:Enable(true)
	inst.Light:EnableClientModulation(true)

    inst.MiniMapEntity:SetIcon("sign.png")

    inst.AnimState:SetBank("expostulations")
    inst.AnimState:SetBuild("expostulations")
    inst.AnimState:PlayAnimation("idle")
	
	inst.Transform:SetScale(SCALE,SCALE,SCALE)
	
	SetOnGround(inst)

    --inst:AddTag("structure")
    inst:AddTag("sign")
    --Sneak these into pristine state for optimization
    inst:AddTag("_writeable")
	
	inst:AddTag("destroyable")
	
    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    --Remove these tags so that they can be added properly when replicating components below
    inst:RemoveTag("_writeable")

    inst:AddComponent("inspectable")
    inst:AddComponent("writeable")
    inst:AddComponent("lootdropper")

    --inst:AddComponent("workable")
    --inst.components.workable:SetWorkAction(ACTIONS.HAMMER)
    --inst.components.workable:SetWorkLeft(1)
    --inst.components.workable:SetOnFinishCallback(onhammered)
    --inst.components.workable:SetOnWorkCallback(onhit)
	
	
	inst:AddComponent("savedrotation")

    MakeHauntableWork(inst)
	
	onphasechange(inst)
    inst:ListenForEvent("onbuilt", onbuilt)
	inst:WatchWorldState("phase",onphasechange)

    return inst
end

return Prefab("expostulations", fn, assets, prefabs),
    MakePlacer("expostulations_placer", "expostulations", "expostulations", "idle",true,nil,nil,SCALE,90,nil,SetOnGround)
