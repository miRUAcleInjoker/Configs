local function GetHugeDamage(inst,delta,multi)
	delta = delta or 0
	multi = multi or 1
	
	local health = inst.components.health
	local damage = 0
	
	if health and not health:IsDead() then
		local maxhealth = health.maxhealth
		if inst:HasTag("player") then 
			damage = math.max(45,maxhealth * 0.5)
		elseif inst:HasTag("character") then 
			damage = math.min(75,maxhealth * 0.25)
		elseif inst:HasTag("epic") then 
			damage = math.min(125,maxhealth * 0.05)
		else
			damage = 75 
		end
	end 
	
	return math.max(0,(damage + delta) * multi)
end 

local function PushFakeAttacked(target,attacker,damage)
	target:PushEvent("attacked", { attacker = attacker, damage = damage or 0})
end 

local function DurationToRate(time)
	return FRAMES / time
end 

local darksouldebuffs = {
	darksouldebuff_poison = {
		OnActivated = function(inst,target)
			inst.buff_fx = target:SpawnChild("poisonbubble")
		end,
		OnDetached = function(inst,target)
			if inst.buff_fx and inst.buff_fx:IsValid() then 
				inst.buff_fx:KillFX()
			end
		end,
		OnActivatedDirty = function(inst)
			local parent = inst.entity:GetParent() 
			local activated = inst.replica.darksouldebuff:IsActivated()
			if activated then 
				parent:PushEvent("startcorrosivedebuff", inst)
			end 
		end,
		health_delta_tick = -0.01,
		
	},
	
	darksouldebuff_strong_poison = {
		OnActivated = function(inst,target)
			inst.buff_fx = target:SpawnChild("poisonbubble")
		end,
		OnDetached = function(inst,target)
			if inst.buff_fx and inst.buff_fx:IsValid() then 
				inst.buff_fx:KillFX()
			end
		end,
		OnActivatedDirty = function(inst)
			local parent = inst.entity:GetParent() 
			local activated = inst.replica.darksouldebuff:IsActivated()
			if activated then 
				parent:PushEvent("startcorrosivedebuff", inst)
			end 
		end,
		health_delta_tick = -0.03,
		
	},
	
	darksouldebuff_bleeds = {
		OnActivated = function(inst,target,activated_num)
			if activated_num <= 1 then
				local fx = target:SpawnChild("blood_hit_fx_icey")
				local buffname = inst.components.darksouldebuff.name
				fx.Transform:SetPosition(0,-1,0)
				fx.AnimState:SetMultColour(196/255,0,0,1)
				if target.components.health and not target.components.health:IsDead() then 
					local damage =  GetHugeDamage(target)
					--target.components.health:DoDelta(delta,true,buffname,nil,nil,true)
					--target.components.combat:GetAttacked(inst,damage)
					target.components.health:DoDelta(-damage,true,buffname,nil,nil,true)
					PushFakeAttacked(target,inst,damage)
					if target.SoundEmitter then 
						target.SoundEmitter:PlaySound("dontstarve/impacts/lava_arena/poison_hit")
					end 
				end
				
			end 
			
			---�������ֶ�����
			inst:DoTaskInTime(2,function()
				inst.components.darksouldebuff:Stop()
			end)
		end,	
		decrease_rate_activated = 0,		---�����Ͳ�����percent�ˣ�Ϊ�˷�������������Ŀ���ui
	},
	
	darksouldebuff_freeze = {
		OnActivated = function(inst,target,activated_num)
			if activated_num <= 1 then
				local buffname = inst.components.darksouldebuff.name
				if target.components.health and not target.components.health:IsDead() then 
					local damage = GetHugeDamage(target,15)
					--target.components.combat:GetAttacked(inst,damage)
					target.components.health:DoDelta(-damage,true,buffname,nil,nil,true)
				end
				
				if target.components.freezable then 
					target.components.freezable:Freeze()
				end
				
				if target.components.temperature then 
					target.components.temperature:DoDelta(-50)
				end 
			end 
		end,		
		
		stamina_recover_multi = 0.25,
		damagetaken_multi = 1.25,
		
		decrease_rate_activated = 0.003,
	},
	
	darksouldebuff_curse_death = {
		OnActivated = function(inst,target,activated_num)
			if activated_num <= 1 then
				local fx = target:SpawnChild("blood_hit_fx_icey")
				local buffname = inst.components.darksouldebuff.name
				fx.Transform:SetPosition(0,-1,0)
				fx.AnimState:SetMultColour(0,0,0,1)
				if target.components.health and not target.components.health:IsDead() then 
					local delta = - target.components.health.maxhealth * 100 
					target.components.health:DeltaPenalty(0.75)
					target.components.health:DoDelta(delta,true,buffname,nil,nil,true)
					if target.SoundEmitter then 
						target.SoundEmitter:PlaySound("dontstarve/impacts/lava_arena/poison_hit")
					end 
				end
			end 
			
			---�������ֶ�����
			inst:DoTaskInTime(2,function()
				inst.components.darksouldebuff:Stop()
			end)
			
		end,	
		decrease_rate_activated = 0,	---�����Ͳ�����percent�ˣ�Ϊ�˷�������������Ŀ���ui
		NotRemoveOnDeath = true,        ---���󲻻��Ƴ�buff��Ϊ���������������Ҳ�ܿ���Ư����buffͼ��
	},
	
	--dantalion_atkbuff
	dantalion_atkbuff = {
		OnActivated = function(inst,target,activated_num)
			if activated_num <= 1 then
				SpawnAt("blossom_hit_fx_dark_icey",target:GetPosition())
			end
		end,
		OnDetached = function(inst,target)
			SpawnAt("blossom_hit_fx_dark_icey",target:GetPosition())
		end,
		damagetaken_multi = 0.85,
		stamina_recover_multi = 1.25,
		damage_multi = 1.25,
		decrease_rate_activated = DurationToRate(15),
	},
	
	--handgun_albert_noregenbuff
	handgun_albert_noregenbuff = {
		OnActivated = function(inst,target,activated_num)
			
		end,
		OnDetached = function(inst,target)
			--SpawnAt("blossom_hit_fx_dark_icey",target:GetPosition())
		end,
		healthregen_multi = 0,
		decrease_rate_activated = DurationToRate(60),
	},

}

return darksouldebuffs