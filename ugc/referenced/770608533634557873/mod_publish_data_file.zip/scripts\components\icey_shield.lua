local easing = require("easing")
local SourceModifierList = require("util/sourcemodifierlist")

local function onmax(self, max)
    self.inst.replica.icey_shield:SetMax(max)
end

local function oncurrent(self, current)
    self.inst.replica.icey_shield:SetCurrent(current)
end


local IceyShield = Class(function(self, inst)
	self.inst = inst 
	self.max = 100
    self.current = self.max
	self.recover_rate = SourceModifierList(self.inst) 
	self.consume_rate = SourceModifierList(self.inst) 
	
	self.onshieldchange = nil 
	self.onpowerup = nil 
	
	self.calc_base_fn = nil 
	
	
	inst:StartUpdatingComponent(self)
end,
nil,
{
	max = onmax,
    current = oncurrent,
})

function IceyShield:SetOnShieldChangeFn(fn)
	self.onshieldchange = fn 
end 

function IceyShield:SetOnPowerUpFn(fn)
	self.onpowerup = fn 
end 

function IceyShield:SetCalcBaseFn(fn)
	self.calc_base_fn = fn 
end 

function IceyShield:SetMax(max,setfull)
	local old_percentage = self:GetPercent()
	self.max = max
	if setfull then 
		self:SetPercent(1)
	else
		self:SetPercent(old_percentage)
	end
	self:DoDelta(0)
end 

function IceyShield:SetCurrent(val)
	local old_shield = self.current
	local try_delta = val - self.current
	
	self.current = val
	self.current = math.max(0,self.current)
	self.current = math.min(self.max,self.current)
	local new_shield = self.current
	local delta = new_shield - old_shield
	
	if self.onshieldchange then 
		self.onshieldchange(self.inst,old_shield,new_shield,try_delta,delta)
	end
	
	if old_shield < new_shield and self:IsMaxedShield() then 
		if self.onpowerup then 
			self.onpowerup(self.inst)
		end
	end 
	
	self.inst:PushEvent("icey_shield_change",{old = old_shield,current = new_shield,try_delta = try_delta,delta = delta})
end 

function IceyShield:SetPercent(percent)
	self:SetCurrent(percent*self.max)
end 
--inst.components.icey_shield:DoDelta(
function IceyShield:DoDelta(delta)
	self:SetCurrent(self.current+delta)
end 

function IceyShield:GetCurrent()
	return self.current
end 

function IceyShield:GetMax()
	return self.max
end 

function IceyShield:GetPercent()
	return self.current / self.max
end 

function IceyShield:IsMaxedShield()
	return self.current >= self.max 
end 

function IceyShield:GetCalcBase()
	return (self.calc_base_fn and self.calc_base_fn(self.inst)) or 1
end 

function IceyShield:CalcConsumeRate()
	return self.consume_rate:Get()
end 

function IceyShield:CalcRecoverRate()
	return self.recover_rate:Get()
end 

function IceyShield:OnUpdate(dt)
	local base = self:GetCalcBase()
	if base >= 0 then
		base = base * self:CalcRecoverRate()
	else
		base = base * self:CalcConsumeRate()
	end
	self:DoDelta(base*dt)
end

function IceyShield:OnSave()
	return {
		current = self.current 
	}
end

function IceyShield:OnLoad(data)
	if data then
		self.current = data.current 
	end 
	self:DoDelta(0)
end

IceyShield.LongUpdate = IceyShield.OnUpdate

return IceyShield 