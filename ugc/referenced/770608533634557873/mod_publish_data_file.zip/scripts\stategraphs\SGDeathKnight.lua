require("stategraphs/commonstates")

local function DoFoleySounds(inst)

	for k,v in pairs(inst.components.inventory.equipslots) do
		if v.components.inventoryitem and v.components.inventoryitem.foleysound then
			inst.SoundEmitter:PlaySound(v.components.inventoryitem.foleysound)
		end
	end

end

local actionhandlers = 
{
	ActionHandler(ACTIONS.EAT, "eat"),
}

   
local events=
{
	CommonHandlers.OnLocomote(true, false),

    EventHandler("doattack", function(inst)
        if not inst.components.health:IsDead() then
			inst.sg:GoToState("attack")
        end
    end),
    
    EventHandler("death", function(inst)
		if inst.rook then 
			inst.rook:RemoveTag("NOCLICK")
		end
		inst.sg:GoToState("death")
    end),
}

local states= 
{
	
	

    State{
        name = "idle",
        tags = {"idle", "canrotate"},
        onenter = function(inst, pushanim)     
            inst.components.locomotor:Stop()
			inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/idle")
            local anims = {"idle_loop"}                            
            if pushanim then
                for k,v in pairs (anims) do
					inst.AnimState:PushAnimation(v, k == #anims)
				end
            else
                inst.AnimState:PlayAnimation(anims[1], #anims == 1)
                for k,v in pairs (anims) do
					if k > 1 then
						inst.AnimState:PushAnimation(v, k == #anims)
					end
				end
            end  
            inst.sg:SetTimeout(math.random()*4+2)
        end,
    },
	
	    State{
        name = "death",
        tags = {"busy","death"},
        
        onenter = function(inst)
            inst.components.locomotor:Stop()
			print("In Death SG")
			inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/grunt")
			local x, y, z = inst.Transform:GetWorldPosition()
			SpawnPrefab("statue_transition_2").Transform:SetPosition(x, y, z)	
			inst.OnDisAppear(inst) 
        end,  
		timeline=
        {
            TimeEvent(12*FRAMES, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/grunt")
            end),
        },    
		events=
        {
            EventHandler("animover", function(inst)  end),
        },
        
        onexit= function(inst)
            
        end,         
    },
	
------------------------------------------------------------------------------------------------------------------------------------------------------
   State{
        name = "attack",
        tags = {"attack", "notalking", "abouttoattack", "busy"},
        
        onenter = function(inst)
			inst.sg.statemem.target = inst.components.combat.target
            inst.components.combat:StartAttack()
			inst.components.locomotor:Stop()
                inst.AnimState:PlayAnimation("atk_pre")
                inst.AnimState:PushAnimation("atk", false)
               
                if inst.sg.statemem.projectilesound == nil then
                    inst.SoundEmitter:PlaySound(
                        "dontstarve/wilson/attack_nightsword",
                        nil, nil, true
                    )
                end
                --cooldown = math.max(cooldown, 13 * FRAMES)
			
        end,
		
        timeline=
        {	
            TimeEvent(8*FRAMES, function(inst) 
				if inst.sg.statemem.target then 
					inst.components.combat:DoAttack(inst.sg.statemem.target) 
				end 
				inst.sg:RemoveStateTag("abouttoattack") 
			end),
            TimeEvent(9*FRAMES, function(inst) 
				inst.sg:RemoveStateTag("busy")
				inst.sg:RemoveStateTag("attack")
			end),				
        },
        
        events=
        {
           EventHandler("animqueueover", function(inst)
                inst.sg:GoToState("idle")
            end),
        },
    },       
   
    State{
        name = "run_start",
        tags = {"moving", "running", "canrotate"},
        
        onenter = function(inst)
			inst.components.locomotor:RunForward()
            inst.AnimState:PlayAnimation("idle_walk_pre")
            inst.sg.mem.foosteps = 0
        end,

        onupdate = function(inst)
            inst.components.locomotor:RunForward()
        end,

        events=
        {   
            EventHandler("animover", function(inst) inst.sg:GoToState("run") end ),        
        },
        
        timeline=
        {
        
            TimeEvent(4*FRAMES, function(inst)
                PlayFootstep(inst)
                DoFoleySounds(inst)
            end),
        },        
        
    },

    State{
        
        name = "run",
        tags = {"moving", "running", "canrotate"},
        
        onenter = function(inst) 
            inst.components.locomotor:RunForward()
            inst.AnimState:PlayAnimation("idle_walk")
        end,
        
        onupdate = function(inst)
            inst.components.locomotor:RunForward()
        end,

        timeline=
        {
            TimeEvent(7*FRAMES, function(inst)
				inst.sg.mem.foosteps = inst.sg.mem.foosteps + 1
                PlayFootstep(inst, inst.sg.mem.foosteps < 5 and 1 or .6)
                DoFoleySounds(inst)
            end),
            TimeEvent(15*FRAMES, function(inst)
				inst.sg.mem.foosteps = inst.sg.mem.foosteps + 1
                PlayFootstep(inst, inst.sg.mem.foosteps < 5 and 1 or .6)
                DoFoleySounds(inst)
            end),
        },
        
        events=
        {   
            EventHandler("animover", function(inst) inst.sg:GoToState("run") end ),        
        },
        
        
    },
    
    State{
        name = "run_stop",
        tags = {"canrotate", "idle"},
        
        onenter = function(inst) 
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("idle_walk_pst")
        end,
        
        events=
        {   
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end ),        
        },       
    },    
	
	State{
        name = "hit",
        tags = { "busy", "pausepredict" },

        onenter = function(inst, frozen)
            inst.components.locomotor:Stop()
            inst:ClearBufferedAction()

            inst.AnimState:PlayAnimation("hit")

            if frozen == "noimpactsound" then
                frozen = nil
            else
                inst.SoundEmitter:PlaySound("dontstarve/wilson/hit")
            end
			inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/hurt")
			
            local stun_frames = frozen and 10 or 6
            inst.sg:SetTimeout(stun_frames * FRAMES)
        end,

        ontimeout = function(inst)
			if inst.components.health:IsDead() then 
				inst.sg:GoToState("death")
			else
				inst.sg:GoToState("idle")
			end 
        end,
    },
	
	State{
        name = "disappear",
        tags = { "busy", "pausepredict" },

        onenter = function(inst)
           
        end,

        
		
		onexit = function(inst)
		
		end,
    },
	
	State{
        name = "show",
        tags = { "busy", "pausepredict" },

        onenter = function(inst)
           
        end,

        
		
		onexit = function(inst)
		
		end,
    },
}

    
return StateGraph("SGDeathKnight", states, events, "idle", actionhandlers)

