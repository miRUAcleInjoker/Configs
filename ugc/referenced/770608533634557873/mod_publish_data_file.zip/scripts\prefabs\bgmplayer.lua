
local function Playfn(inst)
	inst.SoundEmitter:KillAllSounds()
	inst.SoundEmitter:PlaySound(inst.sound,inst.name)
	inst:DoTaskInTime(inst.time,function() Playfn(inst) end)
end 

local function main()
	local inst = CreateEntity()
	inst.entity:AddTransform()
	inst.entity:AddSoundEmitter()
	inst.entity:AddNetwork()
	inst.entity:SetPristine()
	
	if not TheWorld.ismastersim then
		return inst
	end
	
	inst.sound = ""
	inst.name = ""
	inst.time = 10
	inst:DoTaskInTime(1,function()
		Playfn(inst)
	end )
	
	return inst 
end 

return Prefab("bgmplayer", main)
