local assets =
{
	Asset("ANIM", "anim/werepig_build.zip"),
	Asset("ANIM", "anim/infectedpig_build.zip"),
    Asset("ANIM", "anim/werepig_basic.zip"),
    Asset("ANIM", "anim/werepig_actions.zip"),
    Asset("SOUND", "sound/pig.fsb"),
}

local prefabs =
{
    "meat",
    "monstermeat",
    "poop",
    "tophat",
    "strawhat",
    "pigskin",
}

local speech_infected = 
{
	"我们...必须...进食！",
	"新鲜的肉....杀光.....",
	"为了...虫群....",
	"把你...献给...主人....",
	"食物......",
}

local MAX_TARGET_SHARES = 5
local SHARE_TARGET_DIST = 30

local moonbeastbrain = require "brains/moonbeastbrain"
local werepigbrain = require "brains/werepigbrain"

local function ontalk(inst, script)
    inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/idle")
end

local function CalcSanityAura(inst, observer)
    return -TUNING.SANITYAURA_LARGE * 1.5
end

local function OnEat(inst, food)
    if food.components.edible ~= nil then
        if food.components.edible.foodtype == FOODTYPE.VEGGIE then
            SpawnPrefab("poop").Transform:SetPosition(inst.Transform:GetWorldPosition())
        elseif food.components.edible.foodtype == FOODTYPE.MEAT and
            inst.components.werebeast ~= nil and
            not inst.components.werebeast:IsInWereState() and
            food.components.edible:GetHealth(inst) < 0 then
            inst.components.werebeast:TriggerDelta(1)
        end
    end
end

local function OnAttackedByDecidRoot(inst, attacker)
    local x, y, z = inst.Transform:GetWorldPosition()
    local ents = TheSim:FindEntities(x, y, z, SpringCombatMod(SHARE_TARGET_DIST) * .5, { "_combat", "_health", "pig" }, { "werepig", "tadalin", "INLIMBO" })
    local num_helpers = 0
    for i, v in ipairs(ents) do
        if v ~= inst and not v.components.health:IsDead() then
            v:PushEvent("suggest_tree_target", { tree = attacker })
            num_helpers = num_helpers + 1
            if num_helpers >= MAX_TARGET_SHARES then
                break
            end
        end
    end
end

local function IsPig(dude)
    return dude:HasTag("pig")
end

local function IsWerePig(dude)
    return dude:HasTag("werepig")
end

local function IsNonWerePig(dude)
    return dude:HasTag("pig") and not dude:HasTag("werepig")
end

local function IsGuardPig(dude)
    return dude:HasTag("guard") and dude:HasTag("pig")
end

local function OnAttacked(inst, data)
    --print(inst, "OnAttacked")
    local attacker = data.attacker
    inst:ClearBufferedAction()

    if attacker.prefab == "deciduous_root" and attacker.owner ~= nil then 
        OnAttackedByDecidRoot(inst, attacker.owner)
    elseif attacker.prefab ~= "deciduous_root" then
        inst.components.combat:SetTarget(attacker)

        if inst:HasTag("werepig") then
            inst.components.combat:ShareTarget(attacker, SHARE_TARGET_DIST, IsWerePig, MAX_TARGET_SHARES)
        elseif inst:HasTag("guard") then
            inst.components.combat:ShareTarget(attacker, SHARE_TARGET_DIST, attacker:HasTag("pig") and IsGuardPig or IsPig, MAX_TARGET_SHARES)
        elseif not (attacker:HasTag("pig") and attacker:HasTag("guard")) then
            inst.components.combat:ShareTarget(attacker, SHARE_TARGET_DIST, IsNonWerePig, MAX_TARGET_SHARES)
        end
    end
end

local function OnNewTarget(inst, data)
    if inst:HasTag("werepig") then
        inst.components.combat:ShareTarget(data.target, SHARE_TARGET_DIST, IsWerePig, MAX_TARGET_SHARES)
    end
	inst.components.talker:Say(speech_infected[math.random(1,#speech_infected)])
end

local function WerepigRetargetFn(inst)
    return FindEntity(
        inst,
        30,
        function(guy)
            return inst.components.combat:CanTarget(guy)
        end,
        { "_combat" }, --See entityreplica.lua (re: "_combat" tag)
        { "monster","tadalin","structure","prey","smallcreature","spider"}
    )
end

local function WerepigKeepTargetFn(inst, target)
    return inst.components.combat:CanTarget(target)
           and not target:HasTag("tadalin") 
end


local function GetStatus(inst)
    return (inst:HasTag("werepig") and "WEREPIG")
        or (inst:HasTag("guard") and "GUARD")
        or (inst.components.follower.leader ~= nil and "FOLLOWER")
        or nil
end

local function OnChange(inst)
	local day = TheWorld.state.phase
	if TheWorld:HasTag("cave") then 
		day = "dusk"
	end
	if inst.components.burnable then 
		if (day == "dusk" or day == "night") then 
			inst.components.burnable:SetBurnTime(10)
			inst.components.burnable:Extinguish()
			inst.components.health.fire_damage_scale = 1.5
		else
			inst:DoTaskInTime(math.random() * 2,function()
				if inst.components.health and not inst.components.health:IsDead() then 
					inst.components.health:Kill()
				end 
			end)
		end
	end 
end

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddDynamicShadow()
    inst.entity:AddLightWatcher()
    inst.entity:AddNetwork()

    MakeCharacterPhysics(inst, 50, .5)

    inst.DynamicShadow:SetSize(1.5, .75)
    inst.Transform:SetFourFaced()

    inst:AddTag("character")
    inst:AddTag("pig")
    inst:AddTag("scarytoprey")  
	inst:AddTag("werepig") 
	inst:AddTag("hostile")
	inst:AddTag("tadalin")
	inst:AddTag("infected")
    inst.AnimState:SetBank("pigman") 
	--inst.AnimState:SetBuild("werepig_build")
	inst.AnimState:SetBuild("infectedpig_build")
    inst.AnimState:PlayAnimation("idle_loop", true)
    inst.AnimState:Hide("hat")

    --Sneak these into pristine state for optimization
    inst:AddTag("_named")
	--inst:SetPrefabNameOverride("pigman")
    inst.entity:SetPristine()
	
	inst:AddComponent("talker")
    inst.components.talker.fontsize = 35
    inst.components.talker.font = TALKINGFONT
    --inst.components.talker.colour = Vector3(133/255, 140/255, 167/255)
    inst.components.talker.offset = Vector3(0, -400, 0)
    inst.components.talker:MakeChatter()

    if not TheWorld.ismastersim then
        return inst
    end

    --Remove these tags so that they can be added properly when replicating components below
    inst:RemoveTag("_named")
	inst:AddComponent("entitytracker")

	inst:SetBrain(werepigbrain)
    inst:SetStateGraph("SGwerepig")
	
   

	inst:AddComponent("combat")
    inst.components.combat.hiteffectsymbol = "pig_torso"
    inst.components.combat:SetTarget(nil)
    inst.components.combat:SetRetargetFunction(3, WerepigRetargetFn)
    inst.components.combat:SetKeepTargetFunction(WerepigKeepTargetFn) 
	inst.components.combat:SetDefaultDamage(TUNING.WEREPIG_DAMAGE * 1.5)
    inst.components.combat:SetAttackPeriod(TUNING.WEREPIG_ATTACK_PERIOD * 0.75)
	
    inst:AddComponent("locomotor") -- locomotor must be constructed before the stategraph
	inst.components.locomotor.runspeed = TUNING.WEREPIG_RUN_SPEED 
    inst.components.locomotor.walkspeed = TUNING.WEREPIG_WALK_SPEED 
	
    inst:AddComponent("bloomer")

    ------------------------------------------
    inst:AddComponent("eater")
    inst.components.eater:SetDiet({ FOODGROUP.OMNI }, { FOODGROUP.OMNI })
    inst.components.eater:SetCanEatHorrible()
    inst.components.eater:SetCanEatRaw()
    inst.components.eater.strongstomach = true -- can eat monster meat!
    inst.components.eater:SetOnEatFn(OnEat)
    ------------------------------------------
    inst:AddComponent("health")
	inst.components.health:SetMaxHealth(TUNING.WEREPIG_HEALTH)
   

    MakeMediumBurnableCharacter(inst, "pig_torso")

    inst:AddComponent("named")
	inst.components.named:SetName("畸变的猪人")

    ------------------------------------------
    MakeHauntablePanic(inst)
    ------------------------------------------
    inst:AddComponent("follower")
    inst.components.follower.maxfollowtime = TUNING.PIG_LOYALTY_MAXTIME
    ------------------------------------------
    inst:AddComponent("inventory")
    ------------------------------------------
    inst:AddComponent("lootdropper")
	inst.components.lootdropper:SetLoot({ "spoiled_food", "monstermeat" })
    inst.components.lootdropper.numrandomloot = 0
    ------------------------------------------
    inst:AddComponent("knownlocations")
    ------------------------------------------

    inst:AddComponent("sanityaura")
    inst.components.sanityaura.aurafn = CalcSanityAura

    ------------------------------------------
    MakeMediumFreezableCharacter(inst, "pig_torso")
	inst.components.freezable:SetDefaultWearOffTime(TUNING.MOONPIG_FREEZE_WEAR_OFF_TIME)
    ------------------------------------------

    inst:AddComponent("inspectable")
    inst.components.inspectable:SetDescription("它看起来很不友好....")
    ------------------------------------------
	OnChange(inst)
	inst:WatchWorldState("startday", OnChange)
    inst:ListenForEvent("attacked", OnAttacked)
    inst:ListenForEvent("newcombattarget", OnNewTarget)

    return inst
end

return Prefab("pigman_infected", fn, assets)
