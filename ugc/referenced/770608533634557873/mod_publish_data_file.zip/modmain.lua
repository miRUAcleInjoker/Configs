PrefabFiles = {
	"icey",
	"icey_none",
	
	"icey_shadow",--------艾希影分身
	"icey_shadow2",--------艾希影分身2
	"icey_shadow3",
	"icey_shadow4",
	"icey_weaponsparks",
	"icey_hits_variety_fx",
	"icey_reticulearc",
	"icey_blade",---------艾希的大剑
	"icey_reaper",--------收割者回旋镖
	"icey_foods",---------艾希的食物/电池
	"icey_shield",--------艾希护盾特效
	"icey_armor",---------艾希的护甲
	"icey_armor2",
	"icey_ball",----------反组引力球
	"icey_fucker",--------旁白
	"icey_sans",----------黯影·艾希
	"icey_goods",---------纪念章
	"icey_crystals",------水晶矿相关
	"icey_sicence_buildings",----------为了科学!
	"icey_tower",---------水晶塔
	"icey_pod",
	"icey_cookpot",
	"icey_foods_cookpot",
	--"icey_quagmire_food",
	"icey_lootbeacon",
	"icey_pokeball",
	"icey_sunderarmordebuff",
	"xuhua_line",---------虚化回路
	"zerg_crusher",-------灵能粉碎器
	"happy_target",-------吵吵机器人
	"super_icebox",-------时滞冰箱
	"photon_cannon",------光子眼球炮塔
	"darkchest",----------末影箱
	"icey_park_fence",---------带电栅栏
	"icey_park_gate",----------不带电的门
	"icey_tent",---------------休眠仓
	"icey_carrook",------------战车
	"shield_bars",-------------护盾显示条
	"hyperion_circle",---------休伯利安号
	"fireball_projectile",
	"icey_kill_fx",
	"icey_charge_fx",
	"red_lightning",
	
	"pod_projectile",
	"icey_pod_projectile_smoke",
	--------------------------------下面的放在zerg_spiders.lua
	--"spider_xianfeng",-------先锋
	--"spider_haojie",---------浩劫
	--"spider_chaser",---------追猎者
	--"spider_bomb",-----------爆虫
	--"spider_dragoon",--------龙骑士
	
	"pigman_infected",---------被感染的猪人
	"infected_people",---------被感染的人类
	"sky_walker",--------------天罚行者
	"bgmplayer",
	"zerg_spiders",-----------所有下级蜘蛛
	"spider_higher",---------主宰
	"jade",------------------青玉巨神
	"merm_death",------------死徒
	"tadalin_tower",----------虚空邪能水晶塔
	"pighouse_blood",--------被感染的猪人房
	"lavaarena_meteor",
	
	"icey_fxs",-----------------为后面的boss做的额外特效
	"snake_charge",-------------世界吞噬者的炮弹
	
	"spider_monkey",------------末日巨兽（暂定）
	
	"pugalisk",-----------------世界吞噬者（暂定）
	"snake_scales_fx",----------蛇鳞片特效
	"snake_bone",---------------巨蟒骨头
	"worm_bait",----------------虫饵
	"gaze_beam",
	"icey_food_extra",
	
	"shadow_seed",--------------黯影核心
	"gestalt_report",-----------盖什塔尔计划书
	"shadow_mixtrues",
	"shadow_deathknight",
	"mixture_pre_fx",
	
	"icey_damage_number",---------伤害数值
	"metal_gear_alert",-----------警报音
	
	"mean_flytrap",
	"adult_flytrap",
	"nectar_pod",
	"venus_stalk",
	"walkingstick",
	
	"moon_giaour",------------机械邪教徒
	"machine_badge",
	"moon_giaour_prefx",
	"icey_healingcircle",
	"moon_giaour_golem",
	"moon_giaour_minion",------------机械邪教徒的走狗
	
	"time_demon",-------时间膜人
	"time_demon_frog",
	"timecrack",
	
	"ancient_herald",---------远古先驱
	"ancient_herald_fossilspike",
	"ancient_herald_root",
	"laser_ring",
	
	"icey_boarrior",---------巨人尤姆
	"boarrior_groundlifts",---地震波fx
	
	"tigershark_duke", -------虎鲨公爵
	"tigershark_duke_shadow",
	"sharkitten_projectile",
	"sharkitten_tornado",
	
	"boss_elecarmet_icey",--------暮光执政官
	"boss_elecarmet_meteor",
	"boss_elecarmet_prefx",
	
	"ancient_robots",--------先史遗产机器人
	"metal_hulk_merge",
	"metal_hulk_merge_laseronly",
	"metal_hulk_bullet_shock",
	"metal_hulk_eyeflame",
	"iron",
	"sparks_green_fx",
	"robot_leaf_fx",
	
	"death_legion",
	
	"dark_antqueen",
	
	"pog",---------小狐狸
	"pogherd",
	
	"pigeon",-------咕咕咕？
	"pigeon_swarm",
	
	"storm_controlor",
	"storm_controlor_stormfx",
	
	"blood_goosplash",
	
	"dark_halberd",----幽邃战斧
	"gold_dust_repair",---修理光粉
	"expostulations",----建言
	"bloodmooneye",------血红眼眸宝珠
	
	"chest_monster",---------宝箱怪
	"chest_monster_hat",
	
	"wugong",---------恶搞用
	
	"icey_cooking_spit", ----新的烤肉架
	
	"icey_fossilized_fx",
	
	"clocktower_rooms",
	"clocktower_spear_trap",
	"clocktower_spotlight",
	"clocktower_catapult",
	"clocktower_catapult_projectile",
	"clocktower_fire_statue",
	"clocktower_key",
	
	"metroworld_radiation_debuff",
	"metroworld_gasmasks",
	"fakedynamicshadow", 
	"sparkle_fx",
	
	"icey_dracula",
	"death_dragon",
	
	"dragonslayer_trident",
	--"jingdoor_cloud",
	
	"pyromancy_flame",--咒术之火
	"eyeflame_net",
	"pyromancy_books",
	"pyromancy_iron_flesh_debuff",
	
	"battlestandard_buff_fxs",
	
	"icey_boss_soul",
	"icey_boss_cinders",
	
	"icey_armor_vortexcloak",
	
	"mutsuki_ai",--睦月AI
	
	"player_eyeflame",
	
	"green_peekhen",
	"green_peekhenspawner",
	
	"icey_normal_debuff",
	"icey_normal_darksouldebuff",
	"icey_darksouldebuffs",
	"icey_battlecry_fxs",
	
	"spider_higher_spear",
	
	"armor_metalplate",
	"hat_metalplate",
	"knight_cutlass",
	
	"icey_ironlord_orb",
	"icey_living_artifact",
	
	"insanity_skulls",
	
	"yhorm_blade",
	"yhorm_shield",
	
	"icey_smelter",
	--"icey_axe_victorian",
	
	"icey_forge_armors",
	"icey_forge_hats",
	
	"riledlucyspin_fx",
	
	--"icey_boat",
	
	"shadowmixtures_blade",
	"icey_seeleslash",
	"shadowmixtures_blade_smoke",
	"shadowmixtures_blade_smoke2",
	
	"icey_hunter_hat1",
	"icey_hunter_clothing1",
	"hunter_trusty_shooter",
	"hunter_blunderbuss",
	"gunpowder_projectile_smokefx",
	"cloudpuff",
	
	"useless_corkbat",
	"useless_pegleg",
	
	"icey_pigman_aiur",
	"aiur_securitycontract",
	
	"blood_blade_minion",
	"waxwelljournal_dantalion",
	
	"vacuum_sword_fx",
	
	"icey_snake_eye",
	
	"icey_shower_bg_white_anim", -- 测试背景
	
	"shovel_dirt_projectile",
	
	"icey_water_fx",
	
	"icey_sikushui",
	
	"poisonbubble",
	
	"flup",
	
	
	"jack",
	"icey_darts_projectile",
	"icey_moltendarts_projectile",
	
	"handgun_albert",
	
	"cursed_blade",
	"hat_icey_chicken",
	
	"dead_cell_head",
	"flyhead_stone",
	--"pugalisk_fountain",------喷泉，不需要
	--"pugalisk_ruins_pillar",--柱子，不需要
	--"pugalisk_trap_door",-----陷阱门，不需要
	
	--"yuki_gun",------幽姬yuki的霰弹枪
	--"gunfire",
	--"yuki_gunfire_fx",
}

Assets = {
	
	--Asset("ANIM", "anim/pandaman.zip"),
	
	--ThePlayer.AnimState:OverrideSymbol("swap_object", "swap_yhorm_shield_in", "swap_yhorm_shield_in")
	--Asset("ANIM", "anim/swap_yhorm_shield_in.zip"),
	
	--人物滑铲动画
	Asset("ANIM", "anim/player_actions_roll.zip"),
	
	--从晓美焰那里借(bai)鉴(piao)的时停滤镜
	Asset("IMAGE", "images/colour_cubes/icey_theworld_cc.tex"),
	
	--钢铁侠（应该是这个名字吧）相关的动画
	Asset("ANIM", "anim/player_living_suit_shoot.zip"),	
	Asset("ANIM", "anim/player_living_suit_morph.zip"),			
	Asset("ANIM", "anim/player_living_suit_punch.zip"),
	Asset("ANIM", "anim/player_living_suit_destruct.zip"),
	Asset("ANIM", "anim/living_suit_build.zip"),
	Asset("ANIM", "anim/livingartifact_meter.zip"),
	Asset("IMAGE", "images/icey_ironlord_ui.tex"),
    Asset("ATLAS", "images/icey_ironlord_ui.xml"),
	
	--枪动画
	Asset("ANIM", "anim/player_actions_speargun.zip"),	
	Asset("ANIM", "anim/player_mount_actions_speargun.zip"),
	Asset("ANIM", "anim/player_pistol.zip"),
	
	
	Asset("IMAGE", "images/pyromancy_slot1.tex"),
    Asset("ATLAS", "images/pyromancy_slot1.xml"),
	
	Asset("ANIM", "anim/swap_beeguard.zip"),
	Asset("IMAGE","images/inventoryimages/beeguard.tex"),
	Asset("ATLAS","images/inventoryimages/beeguard.xml"),
	
	
	Asset("ANIM", "anim/swap_warly_cookpot.zip"),
	
	Asset("ANIM", "anim/stamina.zip"),
	Asset("ANIM", "anim/focus.zip"),
	Asset("ANIM", "anim/status_stamina.zip"),
	Asset("ANIM", "anim/status_focus.zip"),
	Asset("ANIM", "anim/status_iceyironlord.zip"),
	
	--Asset("ANIM", "anim/health_fake_ui.zip"),
	
	
	Asset("ANIM", "anim/spider_tropical_build.zip"),
	
	Asset("ANIM", "anim/death_show.zip"),
	
	Asset("ANIM", "anim/player_teleport_bfb.zip"),
	Asset("ANIM", "anim/player_teleport_bfb2.zip"),	
	
	Asset("ANIM", "anim/player_lifeplant.zip"),	
	
	Asset("ANIM", "anim/werewilba_actions.zip"),		

	Asset("ANIM", "anim/swap_alex_blade.zip"),
	
	Asset("ANIM", "anim/sword_buster.zip"),
    Asset("ANIM", "anim/swap_sword_buster.zip"),
	
	Asset("ANIM", "anim/icey_blade.zip"),
    Asset("ANIM", "anim/swap_icey_blade.zip"),
    Asset("ANIM", "anim/swap_icey_blade2.zip"),
	
	Asset("ANIM", "anim/lavaarena_lucy.zip"),
	
	Asset( "ANIM", "anim/overload_ui.zip" ),
    Asset( "IMAGE", "images/saveslot_portraits/icey.tex" ),
    Asset( "ATLAS", "images/saveslot_portraits/icey.xml" ),
	
	Asset( "IMAGE", "images/icey_keycheck_ui.tex" ),
    Asset( "ATLAS", "images/icey_keycheck_ui.xml" ),

  --  Asset( "IMAGE", "images/selectscreen_portraits/icey.tex" ),
  --  Asset( "ATLAS", "images/selectscreen_portraits/icey.xml" ),
	
  --  Asset( "IMAGE", "images/selectscreen_portraits/icey_silho.tex" ),
  --  Asset( "ATLAS", "images/selectscreen_portraits/icey_silho.xml" ),

    Asset( "IMAGE", "bigportraits/icey.tex" ),
    Asset( "ATLAS", "bigportraits/icey.xml" ),
	
	Asset( "IMAGE", "bigportraits/icey_none.tex" ),
	Asset( "ATLAS", "bigportraits/icey_none.xml" ),
	
	Asset( "IMAGE", "images/map_icons/icey.tex" ),
	Asset( "ATLAS", "images/map_icons/icey.xml" ),
	
	Asset( "IMAGE", "images/avatars/avatar_icey.tex" ),
    Asset( "ATLAS", "images/avatars/avatar_icey.xml" ),
	
	Asset( "IMAGE", "images/avatars/avatar_ghost_icey.tex" ),
    Asset( "ATLAS", "images/avatars/avatar_ghost_icey.xml" ),
	
	Asset( "IMAGE", "images/avatars/self_inspect_icey.tex" ),
    Asset( "ATLAS", "images/avatars/self_inspect_icey.xml" ),
	
	Asset( "IMAGE", "images/names_icey.tex" ),  --人物名字
    Asset( "ATLAS", "images/names_icey.xml" ),
	
	--------------------------------------------------------------
	--buff贴图
	Asset( "IMAGE", "images/bufficons/bleeds.tex" ),
	Asset( "ATLAS", "images/bufficons/bleeds.xml" ),
	Asset( "IMAGE", "images/bufficons/bleeds_gray.tex" ),
	Asset( "ATLAS", "images/bufficons/bleeds_gray.xml" ),
	
	Asset( "IMAGE", "images/bufficons/poison.tex" ),
	Asset( "ATLAS", "images/bufficons/poison.xml" ),
	Asset( "IMAGE", "images/bufficons/poison_gray.tex" ),
	Asset( "ATLAS", "images/bufficons/poison_gray.xml" ),
	
	Asset( "IMAGE", "images/bufficons/strong_poison.tex" ),
	Asset( "ATLAS", "images/bufficons/strong_poison.xml" ),
	Asset( "IMAGE", "images/bufficons/strong_poison_gray.tex" ),
	Asset( "ATLAS", "images/bufficons/strong_poison_gray.xml" ),
	
	Asset( "IMAGE", "images/bufficons/freeze.tex" ),
	Asset( "ATLAS", "images/bufficons/freeze.xml" ),
	Asset( "IMAGE", "images/bufficons/freeze_gray.tex" ),
	Asset( "ATLAS", "images/bufficons/freeze_gray.xml" ),
	
	Asset( "IMAGE", "images/bufficons/curse_death.tex" ),
	Asset( "ATLAS", "images/bufficons/curse_death.xml" ),
	Asset( "IMAGE", "images/bufficons/curse_death_gray.tex" ),
	Asset( "ATLAS", "images/bufficons/curse_death_gray.xml" ),
	
	Asset( "IMAGE", "images/bufficons/curse_death2.tex" ),
	Asset( "ATLAS", "images/bufficons/curse_death2.xml" ),
	Asset( "IMAGE", "images/bufficons/curse_death2_gray.tex" ),
	Asset( "ATLAS", "images/bufficons/curse_death2_gray.xml" ),
	
	Asset( "IMAGE", "images/bufficons/dantalion_atkbuff.tex" ),
	Asset( "ATLAS", "images/bufficons/dantalion_atkbuff.xml" ),
	Asset( "IMAGE", "images/bufficons/dantalion_atkbuff_gray.tex" ),
	Asset( "ATLAS", "images/bufficons/dantalion_atkbuff_gray.xml" ),
	
	Asset( "IMAGE", "images/bufficons/handgun_albert_noregenbuff.tex" ),
	Asset( "ATLAS", "images/bufficons/handgun_albert_noregenbuff.xml" ),
	Asset( "IMAGE", "images/bufficons/handgun_albert_noregenbuff_gray.tex" ),
	Asset( "ATLAS", "images/bufficons/handgun_albert_noregenbuff_gray.xml" ),
	
	
	
	--_gray
	
	--------------------------------------------------------------
	
	Asset( "IMAGE", "images/iceytab.tex" ),-------------------------专属科技图片
    Asset( "ATLAS", "images/iceytab.xml" ),
	
	Asset( "IMAGE", "images/map_icons/rock_crystal.tex" ),
	Asset( "ATLAS", "images/map_icons/rock_crystal.xml" ),
	
	Asset( "IMAGE", "images/map_icons/icey_tower.tex" ),
	Asset( "ATLAS", "images/map_icons/icey_tower.xml" ),
	
	Asset( "IMAGE", "images/map_icons/zerg_crusher.tex" ),
	Asset( "ATLAS", "images/map_icons/zerg_crusher.xml" ),
	
	Asset( "IMAGE", "images/map_icons/happy_target.tex" ),
	Asset( "ATLAS", "images/map_icons/happy_target.xml" ),
	
	Asset( "IMAGE", "images/map_icons/photon_cannon.tex" ),
	Asset( "ATLAS", "images/map_icons/photon_cannon.xml" ),
	
	Asset( "IMAGE", "images/map_icons/darkchest.tex" ),
	Asset( "ATLAS", "images/map_icons/darkchest.xml" ),
	
	Asset( "IMAGE", "images/inventoryimages/icey_park_gate.tex" ),
	Asset( "ATLAS", "images/inventoryimages/icey_park_gate.xml" ),
	
	Asset( "IMAGE", "images/inventoryimages/icey_park_gate_item.tex" ),
	Asset( "ATLAS", "images/inventoryimages/icey_park_gate_item.xml" ),
	
	Asset( "IMAGE", "images/inventoryimages/icey_tent.tex" ),
	Asset( "ATLAS", "images/inventoryimages/icey_tent.xml" ),
	
	Asset( "IMAGE", "images/inventoryimages/icey_carrook.tex" ),
	Asset( "ATLAS", "images/inventoryimages/icey_carrook.xml" ),

	--------------------------------------------------------------
	Asset( "IMAGE", "images/main.tex" ),
	Asset( "ATLAS", "images/main.xml" ),
	
	Asset( "IMAGE", "images/level.tex" ),
	Asset( "ATLAS", "images/level.xml" ),
	--------------------------------------------------------------以下是技能贴图
	Asset( "IMAGE", "images/iron_body.tex" ),
	Asset( "ATLAS", "images/iron_body.xml" ),
	
	Asset( "IMAGE", "images/foot_star.tex" ),
	Asset( "ATLAS", "images/foot_star.xml" ),
	
	Asset( "IMAGE", "images/sky_death.tex" ),
	Asset( "ATLAS", "images/sky_death.xml" ),
	
	Asset( "IMAGE", "images/steady.tex" ),
	Asset( "ATLAS", "images/steady.xml" ),
	
	Asset( "IMAGE", "images/quick_shield.tex" ),
	Asset( "ATLAS", "images/quick_shield.xml" ),
	
	Asset( "IMAGE", "images/dangerous.tex" ),
	Asset( "ATLAS", "images/dangerous.xml" ),
	
	Asset( "IMAGE", "images/blood_steal.tex" ),
	Asset( "ATLAS", "images/blood_steal.xml" ),
	
	Asset( "IMAGE", "images/shinobi_execution.tex" ),
	Asset( "ATLAS", "images/shinobi_execution.xml" ),
	
	Asset( "IMAGE", "images/all_shield.tex" ),
	Asset( "ATLAS", "images/all_shield.xml" ),
	
	Asset( "IMAGE", "images/charge.tex" ),
	Asset( "ATLAS", "images/charge.xml" ),
	
	Asset( "IMAGE", "images/shield_attack.tex" ),
	Asset( "ATLAS", "images/shield_attack.xml" ),
	
	Asset( "IMAGE", "images/battle_focus.tex" ),
	Asset( "ATLAS", "images/battle_focus.xml" ),
	
	Asset( "IMAGE", "images/sacrifice.tex" ),
	Asset( "ATLAS", "images/sacrifice.xml" ),
	
	Asset( "IMAGE", "images/hyperion.tex" ),
	Asset( "ATLAS", "images/hyperion.xml" ),
	
	Asset( "IMAGE", "images/death_slaughter.tex" ),
	Asset( "ATLAS", "images/death_slaughter.xml" ),
	
	Asset( "IMAGE", "images/soul_torrent.tex" ),
	Asset( "ATLAS", "images/soul_torrent.xml" ),
	
	Asset( "IMAGE", "images/great_coupling.tex" ),
	Asset( "ATLAS", "images/great_coupling.xml" ),
	
	Asset( "IMAGE", "images/liangzi_run.tex" ),
	Asset( "ATLAS", "images/liangzi_run.xml" ),
	
	Asset( "IMAGE", "images/shield_crush.tex" ),
	Asset( "ATLAS", "images/shield_crush.xml" ),
	
	Asset( "IMAGE", "images/newton_grave.tex" ),
	Asset( "ATLAS", "images/newton_grave.xml" ),
	
	Asset( "IMAGE", "images/wudao_sanity.tex" ),
	Asset( "ATLAS", "images/wudao_sanity.xml" ),
	
	Asset( "IMAGE", "images/electricity_shadow.tex" ),
	Asset( "ATLAS", "images/electricity_shadow.xml" ),
	
	Asset( "IMAGE", "images/nucler_weapon.tex" ),
	Asset( "ATLAS", "images/nucler_weapon.xml" ),
	
	Asset( "IMAGE", "images/battleground_eating.tex" ),
	Asset( "ATLAS", "images/battleground_eating.xml" ),
	
	Asset( "IMAGE", "images/king_card.tex" ),
	Asset( "ATLAS", "images/king_card.xml" ),
	
	Asset( "IMAGE", "images/mult_shadow.tex" ),
	Asset( "ATLAS", "images/mult_shadow.xml" ),
	
	Asset( "IMAGE", "images/hit_ground.tex" ),
	Asset( "ATLAS", "images/hit_ground.xml" ),
	
	Asset( "IMAGE", "images/iron_hitter.tex" ),
	Asset( "ATLAS", "images/iron_hitter.xml" ),
	
	Asset( "IMAGE", "images/red_reboot.tex" ),
	Asset( "ATLAS", "images/red_reboot.xml" ),
	
	Asset( "IMAGE", "images/go_hide.tex" ),
	Asset( "ATLAS", "images/go_hide.xml" ),
	
	Asset( "IMAGE", "images/shut_down.tex" ),
	Asset( "ATLAS", "images/shut_down.xml" ),
	
	Asset( "IMAGE", "images/death_machinegun.tex" ),
	Asset( "ATLAS", "images/death_machinegun.xml" ),
	
	Asset( "IMAGE", "images/fire_keeper.tex" ),
	Asset( "ATLAS", "images/fire_keeper.xml" ),
	
	Asset( "IMAGE", "images/snow_dancer.tex" ),
	Asset( "ATLAS", "images/snow_dancer.xml" ),
	
	Asset( "IMAGE", "images/starve_walker.tex" ),
	Asset( "ATLAS", "images/starve_walker.xml" ),
	
	Asset( "IMAGE", "images/harvell_coser.tex" ),
	Asset( "ATLAS", "images/harvell_coser.xml" ),
	
	Asset( "IMAGE", "images/exectuer.tex" ),
	Asset( "ATLAS", "images/exectuer.xml" ),
	
	Asset( "IMAGE", "images/dark_charge.tex" ),
	Asset( "ATLAS", "images/dark_charge.xml" ),
	
	Asset( "IMAGE", "images/rude_storm.tex" ),
	Asset( "ATLAS", "images/rude_storm.xml" ),
	
	Asset( "IMAGE", "images/witch_time.tex" ),
	Asset( "ATLAS", "images/witch_time.xml" ),
	
	
	
	Asset( "IMAGE", "images/icey_bg_white.tex" ),--纯白背景
    Asset( "ATLAS", "images/icey_bg_white.xml" ),
	
	Asset("SOUNDPACKAGE", "sound/ly_battleship.fev"),
    Asset("SOUND", "sound/ly_battleship.fsb"),
	
	--Asset("SOUNDPACKAGE", "sound/icey_bgms.fev"),
    --Asset("SOUND", "sound/icey_bgms.fsb"),
	
	--Asset("SOUNDPACKAGE", "sound/icey_sans.fev"),
    --Asset("SOUND", "sound/icey_sans.fsb"),
	
	Asset("SOUNDPACKAGE", "sound/hyperion_new.fev"),-------真·休伯利安号语音
    Asset("SOUND", "sound/hyperion_new.fsb"),
	
	--Asset("SOUNDPACKAGE", "sound/taila_epic_music.fev"),-------泰拉瑞亚boss音乐
    --Asset("SOUND", "sound/taila_epic_music.fsb"),
	
	--Asset("SOUNDPACKAGE", "sound/taila_epic_music_extra.fev"),-------泰拉瑞亚boss音乐++
    --Asset("SOUND", "sound/taila_epic_music_extra.fsb"),
	
	--Asset("SOUNDPACKAGE", "sound/cc_music.fev"),-------CrackleCardle音乐
    --Asset("SOUND", "sound/cc_music.fsb"),
	
	Asset("SOUNDPACKAGE", "sound/cc_voice.fev"),-------CrackleCardle人物语音
    Asset("SOUND", "sound/cc_voice.fsb"),
	
	--Asset("SOUNDPACKAGE", "sound/shadow_mixtures.fev"),-------噩梦融合怪音乐
    --Asset("SOUND", "sound/shadow_mixtures.fsb"),
	
	--Asset("SOUNDPACKAGE", "sound/evilcity_music.fev"),-------恶魔城音乐
    --Asset("SOUND", "sound/evilcity_music.fsb"),
	
	--Asset("SOUNDPACKAGE", "sound/hamlet_hack.fev"),-------哈姆雷特hack音乐
	--Asset("SOUND", "sound/hamlet_hack.fsb"),
	
	--Asset("SOUNDPACKAGE", "sound/juda_guardian.fev"),-------四大boss中的一些bgm
    --Asset("SOUND", "sound/juda_guardian.fsb"),
	
	
	Asset("SOUNDPACKAGE", "sound/icey_bgms_remaster.fev"),-------重制版boss的BGM
    Asset("SOUND", "sound/icey_bgms_remaster.fsb"),
	
	Asset("SOUNDPACKAGE", "sound/icey_sfx.fev"),
    Asset("SOUND", "sound/icey_sfx.fsb"),

}

GLOBAL.setmetatable(env,{__index=function(t,k) return GLOBAL.rawget(GLOBAL,k) end})


---------------free for TGP !-----------------
--[[if GLOBAL.TheSim.RAILGetPlatform and GLOBAL.TheSim:RAILGetPlatform() == "TGP" then
	  local name = "艾希,I see ! "
      for _, mod in ipairs(GLOBAL.ModManager.mods) do 
           if mod and mod.modinfo and mod.modinfo.id  == name  then
                GLOBAL.KnownModIndex:Disable(name)
          end
      end
	print("########################################################")
	print("同胞们，听我说:")
	print("时间不多了，摆在你面前的是这个种族和文明在战火中所存留下来的一切。")	
	print("还有那些在TGP上被腐化的同胞。")
	print("我们的族人曾掌控饥荒，我们的前途曾充满荣光。")
	print("但是在傲慢与分裂之下，我们辜负了神圣的职责，走向了灭亡。")
	print("腾讯，似乎是团结我们的纽带，却最终铸成了这场分裂。它所带来的希望不过是个谎言。")
	print("如今，我们必须抛弃这一谎言，还有我们所有的偏见与傲慢，让他们成为历史。")
	print("因为我们正为了同样的信念而战，那就是，坚信我们饥友绝不会就此消亡！")
	print("坚信我们饥友能够秉承同样的信念团结一致，坚信我们饥友能够创造一个更加伟大而强盛的文明。")
	print("在战斗中信任彼此，凝聚意志，让这最后一战永垂不朽！")
	print("En Trao Steam!En Trao Gabe!En Trao Don'tStarve !")
	print("########################################################")
    GLOBAL.Shutdown()
end--]]

--------------------------------------------------TUNINGS------------------------------------------------------------

---熔炉mod
TUNING.GAMEMODE_STARTING_ITEMS.LAVAARENA.ICEY = { "icey_blade", "icey_armor" }

---PVP
--[[if TheNet:GetPVPEnabled() then 
	GLOBAL.TUNING.ICEY_NO_TAGS = {"INLIMBO","companion"}
	else 
	GLOBAL.TUNING.ICEY_NO_TAGS = {"INLIMBO","player","companion"}
end--]]

GLOBAL.TUNING.ICEY_NO_TAGS = {"INLIMBO","companion"}
GLOBAL.TUNING.ICEY_NO_SGTAGS = {"invisible"}

--[[if not FOOD_TAGS then 
	FOOD_TAGS = {}
end --]]
--[[FOOD_TAGS = FOOD_TAGS or {} 
FOOD_TAGS.inedible = "不可食用度"----------兼容show me--]]

--GLOBAL.HUMAN_MEAT_ENABLED = true----------诶嘿~诶嘿嘿~

----世界吞噬者的数据
GLOBAL.TUNING.PUGALISK_HEALTH = 3200
GLOBAL.TUNING.PUGALISK_ATTACK_PERIOD = 3
GLOBAL.TUNING.PUGALISK_MELEE_RANGE = 6
GLOBAL.TUNING.PUGALISK_DAMAGE = 100
GLOBAL.TUNING.PUGALISK_TARGET_DIST = 40
GLOBAL.TUNING.PUGALISK_TAIL_TARGET_DIST = 6
GLOBAL.TUNING.PUGALISK_RUINS_PILLAR_WORK = 3


-------食人花们的数据
GLOBAL.TUNING.FLYTRAP_CHILD_HEALTH = 250
GLOBAL.TUNING.FLYTRAP_CHILD_DAMAGE = 15
GLOBAL.TUNING.FLYTRAP_CHILD_SPEED = 4  

GLOBAL.TUNING.FLYTRAP_TEEN_HEALTH = 300
GLOBAL.TUNING.FLYTRAP_TEEN_DAMAGE = 20
GLOBAL.TUNING.FLYTRAP_TEEN_SPEED = 3.5

GLOBAL.TUNING.FLYTRAP_HEALTH = 350
GLOBAL.TUNING.FLYTRAP_DAMAGE = 25
GLOBAL.TUNING.FLYTRAP_SPEED = 3

GLOBAL.TUNING.FLYTRAP_TARGET_DIST = 8
GLOBAL.TUNING.FLYTRAP_KEEP_TARGET_DIST= 15
GLOBAL.TUNING.FLYTRAP_ATTACK_PERIOD = 3

GLOBAL.TUNING.ADULT_FLYTRAP_HEALTH = 400
GLOBAL.TUNING.ADULT_FLYTRAP_DAMAGE = 30
GLOBAL.TUNING.ADULT_FLYTRAP_ATTACK_PERIOD = 5
GLOBAL.TUNING.ADULT_FLYTRAP_ATTACK_DIST = 4
GLOBAL.TUNING.ADULT_FLYTRAP_STOPATTACK_DIST = 6

-------------------远古机器人们的数据
GLOBAL.TUNING.ROBOT_TARGET_DIST = 15 
GLOBAL.TUNING.ROBOT_RIBS_DAMAGE = 34
GLOBAL.TUNING.ROBOT_RIBS_HEALTH = 1000
GLOBAL.TUNING.ROBOT_LEG_DAMAGE = 34*2
--GLOBAL.TUNING.LASER_DAMAGE = 20

-------------------小狐狸的数据
GLOBAL.TUNING.POG_ATTACK_RANGE = 3
GLOBAL.TUNING.POG_MELEE_RANGE = 2.5
GLOBAL.TUNING.POG_TARGET_DIST = 25
GLOBAL.TUNING.POG_WALK_SPEED = 2
GLOBAL.TUNING.POG_RUN_SPEED = 4.5
GLOBAL.TUNING.POG_DAMAGE = 25
GLOBAL.TUNING.POG_HEALTH = 150
GLOBAL.TUNING.POG_ATTACK_PERIOD = 2
GLOBAL.TUNING.MIN_POGNAP_INTERVAL = 30
GLOBAL.TUNING.MAX_POGNAP_INTERVAL = 120
GLOBAL.TUNING.MIN_POGNAP_LENGTH = 20
GLOBAL.TUNING.MAX_POGNAP_LENGTH = 40
GLOBAL.TUNING.POG_LOYALTY_MAXTIME = 480
GLOBAL.TUNING.POG_LOYALTY_PER_ITEM = 480*.1
GLOBAL.TUNING.POG_EAT_DELAY = 0.5
GLOBAL.TUNING.POG_SEE_FOOD = 30

-------------------咒蛙的数据
GLOBAL.TUNING.FLUP_JUMPATTACK_RANGE = 4
GLOBAL.TUNING.FLUP_MELEEATTACK_RANGE = 2
GLOBAL.TUNING.FLUP_HIT_RANGE = 1.75
GLOBAL.TUNING.FLUP_HEALTH = 100
GLOBAL.TUNING.FLUP_ATTACK_PERIOD = 2
GLOBAL.TUNING.FLUP_DAMAGE = 25
GLOBAL.TUNING.FLUP_DART_DAMAGE = 20

-------------------虎鲨公爵的数据
GLOBAL.TUNING.TIGERSHARK_WALK_SPEED = 8
GLOBAL.TUNING.TIGERSHARK_RUN_SPEED = 12
GLOBAL.TUNING.TIGERSHARK_HEALTH = 10000
GLOBAL.TUNING.TIGERSHARK_DAMAGE = 100
GLOBAL.TUNING.TIGERSHARK_ATTACK_PERIOD = 3
GLOBAL.TUNING.TIGERSHARK_ATTACK_RANGE = 4
GLOBAL.TUNING.TIGERSHARK_SPLASH_RADIUS = 5
GLOBAL.TUNING.TIGERSHARK_SPLASH_DAMAGE = 125

---技能CD
GLOBAL.TUNING.ICEY_MISS_CD = 0.3-----迭影步
GLOBAL.TUNING.ICEY_KILL_CD_H = 360-----休伯利安号
GLOBAL.TUNING.ICEY_KILL_CD_DS = 10-----死亡进击
GLOBAL.TUNING.ICEY_KILL_CD_SA = 5-----超载融合
GLOBAL.TUNING.ICEY_KILL_CD_SOUL = 5 
GLOBAL.TUNING.ICEY_SHOW_CD = 0.3-------护盾显示
GLOBAL.TUNING.ICEY_PARRY_CD = 0.3

local IceyUtil = require("icey_util")

local function GetKeyFromConfig(config)
    local key = GetModConfigData(config)
	--print("GetKeyFromConfig key:",key)
    return key and (type(key) == "number" and key or GLOBAL[key])
end

local function GetKeyFromConfigInString(config)
	return tostring(GetModConfigData(config))
end 

GLOBAL.TUNING.ICEY_MISS_KEY = GetKeyFromConfig("icey_miss")
GLOBAL.TUNING.ICEY_KILL_KEY = GetKeyFromConfig("icey_kill")
--GLOBAL.TUNING.ICEY_SHOW_KEY = GetKeyFromConfig("icey_show")
GLOBAL.TUNING.ICEY_PARRY_KEY = GetKeyFromConfig("icey_parry")
GLOBAL.TUNING.ICEY_PODSHOOT_KEY = GetKeyFromConfig("icey_podshoot")--KEY_LSHIFT
GLOBAL.TUNING.ICEY_SNEAK_KEY = GetKeyFromConfig("icey_sneak")--KEY_LCTRL
GLOBAL.TUNING.ICEY_FLYHEAD_KEY = GetKeyFromConfig("icey_flyhead")--KEY_V

GLOBAL.TUNING.ICEY_MISS_KEY_STRING = GetKeyFromConfigInString("icey_miss")
GLOBAL.TUNING.ICEY_KILL_KEY_STRING = GetKeyFromConfigInString("icey_kill")
GLOBAL.TUNING.ICEY_PARRY_KEY_STRING = GetKeyFromConfigInString("icey_parry")
GLOBAL.TUNING.ICEY_PODSHOOT_KEY_STRING = GetKeyFromConfigInString("icey_podshoot")
GLOBAL.TUNING.ICEY_SNEAK_KEY_STRING = GetKeyFromConfigInString("icey_sneak")
GLOBAL.TUNING.ICEY_FLYHEAD_KEY_STRING = GetKeyFromConfigInString("icey_flyhead")--KEY_V

GLOBAL.TUNING.ICEY_DLCS = GetModConfigData("icey_dlcs")
GLOBAL.TUNING.ICEY_LANGUAGE = GetModConfigData("icey_language")
GLOBAL.TUNING.ICEY_JADE_MUSIC = GetModConfigData("icey_jade_music")
GLOBAL.TUNING.ICEY_DAMAGE_NUMBERS = GetModConfigData("icey_damage_numbers")
GLOBAL.TUNING.ICEY_GAL_CV = GetModConfigData("icey_gal_cv")
-----------------------------------------------------------------------------------------------------------------
--modimport("engine.lua")
modimport("icey_strings.lua")
modimport("icey_stewer_api.lua")
modimport("icey_darkspirit_api.lua")
modimport("modmain_clocktower.lua")
modimport("pyromancy_slot_api.lua")
modimport("darksouls_api.lua")
modimport("icey_critters_api.lua")
modimport("btmods_forbider.lua")
modimport("icey_ironlord_api.lua")
modimport("icey_vacuum_sword_api.lua")
--modimport("icey_achievement_api.lua")
modimport("icey_snakeeye_api.lua")
modimport("icey_reflect_laser_user_api.lua")
modimport("icey_eater_api.lua")
modimport("icey_level_api.lua")
modimport("icey_swimmer_api.lua")
modimport("icey_miss_api.lua")
modimport("icey_timestop_api.lua")
modimport("icey_revivablecorpse_api.lua")
--modimport("icey_loghelper.lua")

--modimport("ly_worldtarvel_new_api.lua")
--modimport("icey_birdbrain_fix_api.lua")


--modimport("oasislake_api.lua")
--modimport("icey_writeablewidget_api.lua")
--modimport("icey_quickpick.lua")
--modimport("api_multingredients.lua")
--modimport("showme_chs.lua")
--modimport("scripts/stategraphs/lavaaction_icey.lua") -----------------------------定义熔炉技能动作SG
modimport("scripts/stategraphs/icey_sg_attack.lua") --------------------------定义艾希特殊攻击SG
modimport("scripts/stategraphs/icey_sg_parry.lua") --------------------------定义艾希格挡攻击SG
modimport("scripts/stategraphs/icey_sg_walk.lua") --------------------------定义艾希行走攻击SG
--modimport("scripts/stategraphs/fenix_wing_sg_skill.lua") --------------------------定义重生之翼技能SG
modimport("scripts/stategraphs/icey_sg_fossilized.lua")
modimport("scripts/stategraphs/icey_sg_attacked.lua")
modimport("scripts/stategraphs/icey_sg_aoeweapon.lua")
modimport("scripts/stategraphs/icey_sg_skill.lua")
modimport("scripts/stategraphs/icey_sg_chickenhat.lua")

--modimport("scripts/stategraphs/sg_icey_skills.lua")

--[[Load "chatinputscreen"
Load "consolescreen"
Load "textedit"--]]

AddReplicableComponent("icey_shield")
AddReplicableComponent("icey_level")

----------------------------------
GLOBAL.FOODTYPE.ICEY_BATTERY = "ICEY_BATTERY"
------------------------------------
ICEYtab = AddRecipeTab("艾希",234, "images/iceytab.xml", "iceytab.tex", "icey")
------------------------------------

AddRecipe("icey_resolver", 
{Ingredient("icey_battery",4,"images/inventoryimages/icey_battery.xml"),Ingredient("transistor",2),Ingredient("cutstone",2)}, 
ICEYtab, TECH.SCIENCE_ONE, "icey_resolver_placer", nil, nil, nil, "icey", "images/inventoryimages.xml", "researchlab2_pod.tex" )

AddRecipe("crystal_item", 
{Ingredient("icey_magic",20,"images/inventoryimages/icey_magic.xml")}, 
ICEYtab, TECH.SCIENCE_ONE, nil, nil, nil, 20, "icey", "images/inventoryimages/crystal_item.xml", "crystal_item.tex" )

AddRecipe("cutcrystal", 
{Ingredient("crystal_item",20,"images/inventoryimages/crystal_item.xml")}, 
ICEYtab, TECH.SCIENCE_ONE, nil, nil, nil, nil, "icey", "images/inventoryimages/cutcrystal.xml", "cutcrystal.tex" )

AddRecipe("icey_tower", 
{Ingredient("cutcrystal",5,"images/inventoryimages/cutcrystal.xml")}, 
ICEYtab, TECH.SCIENCE_ONE, "icey_tower_placer", 1, nil, nil, "icey", "images/map_icons/icey_tower.xml", "icey_tower.tex" )

AddRecipe("xuhua_line_item", 
{Ingredient("cutcrystal",1,"images/inventoryimages/cutcrystal.xml")}, 
ICEYtab, TECH.SCIENCE_ONE, nil, nil, nil, 20, "icey", "images/inventoryimages/xuhua_line.xml", "xuhua_line.tex" )

AddRecipe("power_line_item", 
{Ingredient("cutcrystal",1,"images/inventoryimages/cutcrystal.xml")}, 
ICEYtab, TECH.SCIENCE_TWO, nil, nil, nil, 2, "icey", "images/inventoryimages/power_line.xml", "power_line.tex" )

AddRecipe("zerg_crusher", 
{Ingredient("cutcrystal",2,"images/inventoryimages/cutcrystal.xml"),Ingredient("spider_higher_good",1,"images/inventoryimages/spider_higher_good.xml")}, 
ICEYtab, TECH.SCIENCE_ONE, "zerg_crusher_placer", 1, nil, nil, "icey", "images/map_icons/zerg_crusher.xml", "zerg_crusher.tex" )

AddRecipe("happy_target", 
{Ingredient("cutcrystal",2,"images/inventoryimages/cutcrystal.xml"),Ingredient("cookedmeat",4),Ingredient("nightmarefuel",4)}, 
ICEYtab, TECH.SCIENCE_ONE, "happy_target_placer", 1, nil, nil, "icey", "images/map_icons/happy_target.xml", "happy_target.tex" )

AddRecipe("super_icebox", 
{Ingredient("cutcrystal",3,"images/inventoryimages/cutcrystal.xml"),Ingredient("gears",1)}, 
ICEYtab, TECH.SCIENCE_TWO, "super_icebox_placer", 1, nil, nil, "icey", "images/inventoryimages.xml", "icebox.tex" )

AddRecipe("photon_cannon_item", 
{Ingredient("cutcrystal",3,"images/inventoryimages/cutcrystal.xml")}, 
ICEYtab, TECH.SCIENCE_TWO, nil, nil, nil, nil, "icey", "images/inventoryimages/photon_cannon_item.xml", "photon_cannon_item.tex" )

AddRecipe("darkchest", 
{Ingredient("cutcrystal",3,"images/inventoryimages/cutcrystal.xml"),Ingredient("nightmarefuel",10)}, 
ICEYtab, TECH.SCIENCE_TWO, "darkchest_placer", 1, nil, nil, "icey", "images/map_icons/darkchest.xml", "darkchest.tex" )

AddRecipe("icey_park_fence_tall_item", 
{Ingredient("cutcrystal",4,"images/inventoryimages/cutcrystal.xml")}, 
ICEYtab, TECH.SCIENCE_ONE, nil,nil, nil, 10, "icey", "images/inventoryimages/icey_park_fence_tall.xml", "icey_park_fence_tall.tex" )

AddRecipe("icey_park_fence_short_item", 
{Ingredient("cutcrystal",2,"images/inventoryimages/cutcrystal.xml")}, 
ICEYtab, TECH.SCIENCE_ONE, nil, nil, nil, 10, "icey", "images/inventoryimages/icey_park_fence_short.xml", "icey_park_fence_short.tex" )

AddRecipe("icey_park_gate_item", 
{Ingredient("crystal_item",8,"images/inventoryimages/crystal_item.xml")}, 
ICEYtab, TECH.SCIENCE_ONE,nil, nil, nil, nil, "icey", "images/inventoryimages/icey_park_gate.xml", "icey_park_gate.tex" )

AddRecipe("icey_tent", 
{Ingredient("cutcrystal",5,"images/inventoryimages/cutcrystal.xml"),Ingredient("ice",15),Ingredient("icey_battery",3,"images/inventoryimages/icey_battery.xml")}, 
ICEYtab, TECH.SCIENCE_ONE,"icey_tent_placer", 1, nil, nil, "icey", "images/inventoryimages/icey_tent.xml", "icey_tent.tex" )

AddRecipe("icey_carrook", 
{Ingredient("cutcrystal",5,"images/inventoryimages/cutcrystal.xml"),Ingredient("goldnugget",15),Ingredient("gears",3)}, 
ICEYtab, TECH.SCIENCE_ONE,"icey_carrook_placer", 1, nil, nil, "icey", "images/inventoryimages/icey_carrook.xml", "icey_carrook.tex" )

AddRecipe("icey_battery", 
{Ingredient("icey_magic",4,"images/inventoryimages/icey_magic.xml"),Ingredient("transistor",1)}, 
ICEYtab, TECH.NONE, nil, nil, nil, nil, "icey", "images/inventoryimages/icey_battery.xml", "icey_battery.tex" )

AddRecipe("icey_armor", 
{Ingredient("icey_battery",1,"images/inventoryimages/icey_battery.xml"),Ingredient("bluegem",1),Ingredient("gears",2)}, 
ICEYtab, TECH.NONE, nil, nil, nil, nil, "icey", "images/inventoryimages/icey_armor.xml", "icey_armor.tex" )

AddRecipe("icey_armor2", 
{Ingredient("icey_battery",1,"images/inventoryimages/icey_battery.xml"),Ingredient("bluegem",1),Ingredient("gestalt_report",1,"images/inventoryimages/gestalt_report.xml")}, 
ICEYtab, TECH.NONE, nil, nil, nil, nil, "icey", "images/inventoryimages/icey_armor2.xml", "icey_armor2.tex" )

AddRecipe("icey_blade", 
{Ingredient("icey_battery",1,"images/inventoryimages/icey_battery.xml"),Ingredient("bluegem",1),Ingredient("gears",2)}, 
ICEYtab, TECH.NONE, nil, nil, nil, nil, "icey", "images/inventoryimages/icey_bluerose.xml", "icey_bluerose.tex" )

AddRecipe("icey_ball", 
{Ingredient("icey_battery",1,"images/inventoryimages/icey_battery.xml"),Ingredient("trinket_6",2)}, 
ICEYtab, TECH.NONE, nil, nil, nil, 3, "icey", "images/inventoryimages/icey_ball.xml", "icey_ball.tex" )

AddRecipe("icey_reaper", 
{Ingredient("icey_battery",1,"images/inventoryimages/icey_battery.xml"),Ingredient("boomerang",1),Ingredient("nightmarefuel",4)}, 
ICEYtab, TECH.NONE, nil, nil, nil, nil, "icey", "images/inventoryimages.xml", "boomerang.tex" )

AddRecipe("icey_cookpot_item", 
{Ingredient("icey_battery",1,"images/inventoryimages/icey_battery.xml"),Ingredient("cutcrystal",3,"images/inventoryimages/cutcrystal.xml"),Ingredient("bluegem",1)}, 
ICEYtab, TECH.NONE, nil, nil, nil, nil, "icey", "images/inventoryimages/icey_cookpot.xml", "icey_cookpot.tex" )

AddRecipe("icey_snake_eye", 
{Ingredient("icey_battery",1,"images/inventoryimages/icey_battery.xml"),Ingredient("pugalisk_soul",1,"images/inventoryimages/pugalisk_soul.xml")}, 
ICEYtab, TECH.NONE, nil, nil, nil, nil, "icey", "images/inventoryimages/icey_snake_eye.xml", "icey_snake_eye.tex" )

AddRecipe("hat_icey_chicken", 
{Ingredient("turkeydinner",1)}, 
ICEYtab, TECH.NONE, nil, nil, nil, nil, nil,"images/inventoryimages/hat_icey_chicken.xml","hat_icey_chicken.tex" )

AddRecipe("worm_bait", 
{Ingredient("humanmeat",3),Ingredient("monstermeat_dried",2),Ingredient("mosquitosack",1)}, 
RECIPETABS.SURVIVAL, TECH.NONE, nil, nil, nil, nil, nil, "images/inventoryimages/worm_bait.xml", "worm_bait.tex" )

AddRecipe("walkingstick", 
{Ingredient("goldnugget", 1),Ingredient("venus_stalk", 3,"images/inventoryimages/venus_stalk.xml"),Ingredient("twigs", 4)}, 
RECIPETABS.DRESS, TECH.NONE, nil, nil, nil, nil, nil, "images/inventoryimages/walkingstick.xml", "walkingstick.tex" )

--[[AddRecipe("dark_halberd", 
{Ingredient("alloy",2,"images/inventoryimages/alloy.xml", "alloy.tex"), Ingredient("nightmarefuel",8),Ingredient("twigs", 2)}, 
RECIPETABS.WAR, TECH.SCIENCE_TWO, nil, nil, nil, nil, nil, "images/inventoryimages/dark_halberd.xml", "dark_halberd.tex" )--]]


AddRecipe("gold_dust_repair", 
{Ingredient("alloy",1,"images/inventoryimages/alloy.xml"), Ingredient("goldnugget",1)}, 
RECIPETABS.WAR, TECH.SCIENCE_TWO, nil, nil, nil, 2, nil, "images/inventoryimages/gold_dust_repair.xml", "gold_dust_repair.tex" )

AddRecipe("expostulations", 
{Ingredient("flint",3)}, 
RECIPETABS.SURVIVAL, TECH.NONE, "expostulations_placer", 0.1, nil, nil, nil, "images/inventoryimages/expostulations.xml", "expostulations.tex" )

AddRecipe("icey_cooking_spit", 
{Ingredient("twigs", 3),Ingredient("charcoal", 2), Ingredient("alloy", 3,"images/inventoryimages/alloy.xml")}, 
RECIPETABS.FARM, TECH.SCIENCE_ONE, "icey_cooking_spit_placer", nil, nil, nil, nil, "images/inventoryimages/icey_cooking_spit.xml", "icey_cooking_spit.tex" )

AddRecipe("icey_smelter", 
{Ingredient("cutstone", 6), Ingredient("boards", 4), Ingredient("redgem", 1)}, 
RECIPETABS.SCIENCE, TECH.SCIENCE_TWO,"icey_smelter_placer",nil, nil, nil, nil,"images/inventoryimages/icey_smelter.xml", "icey_smelter.tex")


AddRecipe("icey_armor_vortexcloak", 
{Ingredient("nightmarefuel",5),Ingredient("armor_sanity",1),Ingredient("shadow_mixtrues_soul",1,"images/inventoryimages/shadow_mixtrues_soul.xml")}, 
RECIPETABS.MAGIC, TECH.MAGIC_THREE, nil, nil, nil, 1, nil, "images/inventoryimages/icey_armor_vortexcloak.xml", "icey_armor_vortexcloak.tex" )


AddRecipe("shadowmixtures_blade", 
{Ingredient("nightmarefuel",5),Ingredient("nightsword",1),Ingredient("shadow_mixtrues_soul",1,"images/inventoryimages/shadow_mixtrues_soul.xml")}, 
RECIPETABS.MAGIC, TECH.MAGIC_THREE, nil, nil, nil, 1, nil, "images/inventoryimages/shadowmixtures_blade.xml", "shadowmixtures_blade.tex" )



AddRecipe("pyromancy_flame", 
{Ingredient("redgem",1)}, 
RECIPETABS.MAGIC, TECH.NONE, nil, nil, nil, 1, "pyromancy_master", "images/inventoryimages/pyromancy_flame.xml", "pyromancy_flame.tex" )

AddRecipe("pyromancy_fireball", 
{Ingredient("papyrus",1),Ingredient("torch",1),Ingredient("ash",7)}, 
RECIPETABS.MAGIC, TECH.NONE, nil, nil, nil, 1, "pyromancy_master", "images/inventoryimages/pyromancy_fireball.xml", "pyromancy_fireball.tex" )

AddRecipe("pyromancy_bursting_fireball", 
{Ingredient("papyrus",1),Ingredient("spider_higher_soul",1,"images/inventoryimages/spider_higher_soul.xml")}, 
RECIPETABS.MAGIC, TECH.MAGIC_THREE, nil, nil, nil, 1, "pyromancy_master", "images/inventoryimages/pyromancy_bursting_fireball.xml", "pyromancy_bursting_fireball.tex" )

AddRecipe("pyromancy_acid_surge", 
{Ingredient("papyrus",1),Ingredient("jade_soul",1,"images/inventoryimages/jade_soul.xml")}, 
RECIPETABS.MAGIC, TECH.MAGIC_THREE, nil, nil, nil, 1, "pyromancy_master", "images/inventoryimages/pyromancy_acid_surge.xml", "pyromancy_acid_surge.tex" )

AddRecipe("pyromancy_boulder_heave", 
{Ingredient("papyrus",1),Ingredient("sewing_tape",3),Ingredient("rocks",20)}, 
RECIPETABS.MAGIC, TECH.MAGIC_THREE, nil, nil, nil, 1, "pyromancy_master", "images/inventoryimages/pyromancy_boulder_heave.xml", "pyromancy_boulder_heave.tex" )

AddRecipe("pyromancy_iron_flesh", 
{Ingredient("papyrus",1),Ingredient("pugalisk_soul",1,"images/inventoryimages/pugalisk_soul.xml"),Ingredient("alloy",5,"images/inventoryimages/alloy.xml")}, 
RECIPETABS.MAGIC, TECH.MAGIC_THREE, nil, nil, nil, 1, "pyromancy_master", "images/inventoryimages/pyromancy_iron_flesh.xml", "pyromancy_iron_flesh.tex" )

AddRecipe("pyromancy_floating_chaos", 
{Ingredient("papyrus",1),Ingredient("pugalisk_soul",1,"images/inventoryimages/pugalisk_soul.xml")}, 
RECIPETABS.MAGIC, TECH.MAGIC_THREE, nil, nil, nil, 1, "pyromancy_master", "images/inventoryimages/pyromancy_floating_chaos.xml", "pyromancy_floating_chaos.tex" )

AddRecipe("pyromancy_rapport", 
{Ingredient("papyrus",1),Ingredient("icey_sans_soul",1,"images/inventoryimages/icey_sans_soul.xml")}, 
RECIPETABS.MAGIC, TECH.MAGIC_THREE, nil, nil, nil, 1, "pyromancy_master", "images/inventoryimages/pyromancy_rapport.xml", "pyromancy_rapport.tex" )

AddRecipe("pyromancy_firestorm", 
{Ingredient("papyrus",1),Ingredient("moon_giaour_soul",1,"images/inventoryimages/moon_giaour_soul.xml")}, 
RECIPETABS.MAGIC, TECH.MAGIC_THREE, nil, nil, nil, 1, "pyromancy_master", "images/inventoryimages/pyromancy_firestorm.xml", "pyromancy_firestorm.tex" )

Recipe("mutsuki_ai_builder", 
{Ingredient("opalpreciousgem",1),Ingredient("icey_sans_soul",1,"images/inventoryimages/icey_sans_soul.xml")},
RECIPETABS.ORPHANAGE,TECH.ORPHANAGE_ONE,nil,nil,true,nil,nil,"images/inventoryimages/mutsuki_ai.xml", "mutsuki_ai.tex" )

Recipe("blood_blade_minion_builder", 
{Ingredient("ruins_bat",1),Ingredient("dark_antqueen_soul",1,"images/inventoryimages/dark_antqueen_soul.xml")},
RECIPETABS.ORPHANAGE,TECH.ORPHANAGE_ONE,nil,nil,true,nil,nil,"images/inventoryimages/blood_blade.xml", "blood_blade.tex" )



Recipe("waxwelljournal_dantalion_builder", 
{Ingredient("waxwelljournal",1),Ingredient("dark_antqueen_soul",1,"images/inventoryimages/dark_antqueen_soul.xml")},
RECIPETABS.ORPHANAGE,TECH.ORPHANAGE_ONE,nil,nil,true,nil,nil,nil, "waxwelljournal.tex" )

Recipe("bloodmooneye", 
{Ingredient("redgem",1),Ingredient("moonrockcrater",1),Ingredient("sky_walker_soul",1,"images/inventoryimages/sky_walker_soul.xml")},
RECIPETABS.MAGIC,TECH.MAGIC_THREE,nil,nil,nil,1,nil,"images/inventoryimages.xml", "redmooneye.tex" )

Recipe("cursed_blade", 
{Ingredient("nightsword",1),Ingredient("deerclops_eyeball",1),Ingredient("sky_walker_soul",1,"images/inventoryimages/sky_walker_soul.xml")},
RECIPETABS.MAGIC,TECH.MAGIC_THREE,nil,nil,nil,1,nil,"images/inventoryimages/cursed_blade.xml", "cursed_blade.tex" )


AddRecipe("spider_higher_spear", 
{Ingredient("spear",1),Ingredient("spider_higher_good",1,"images/inventoryimages/spider_higher_good.xml"),Ingredient("spider_higher_soul",1,"images/inventoryimages/spider_higher_soul.xml")}, 
RECIPETABS.WAR, TECH.SCIENCE_TWO, nil, nil, nil, nil, nil,"images/inventoryimages/spider_higher_spear.xml","spider_higher_spear.tex" )

AddRecipe("yhorm_blade", 
{Ingredient("ruins_bat",1),Ingredient("icey_boarrior_soul",1,"images/inventoryimages/icey_boarrior_soul.xml")}, 
RECIPETABS.WAR, TECH.SCIENCE_TWO, nil, nil, nil, nil, nil,"images/inventoryimages/yhorm_blade.xml","yhorm_blade.tex" )

AddRecipe("yhorm_shield", 
{Ingredient("dragon_scales",1),Ingredient("icey_boarrior_soul",1,"images/inventoryimages/icey_boarrior_soul.xml")}, 
RECIPETABS.WAR, TECH.SCIENCE_TWO, nil, nil, nil, nil, nil,"images/inventoryimages/yhorm_shield.xml","yhorm_shield.tex" )



AddRecipe("storm_controlor", 
{Ingredient("goose_feather",8), Ingredient("alloy",5,"images/inventoryimages/alloy.xml"), Ingredient("rope", 2)}, 
RECIPETABS.WAR, TECH.SCIENCE_TWO, nil, nil, nil, nil, nil,"images/inventoryimages/storm_controlor.xml","storm_controlor.tex" )

AddRecipe("armor_metalplate", 
{Ingredient("alloy",5,"images/inventoryimages/alloy.xml"), Ingredient("hammer", 1)}, 
RECIPETABS.WAR, TECH.SCIENCE_TWO, nil, nil, nil, nil,"knight_master","images/inventoryimages/armor_metalplate.xml","armor_metalplate.tex" )

AddRecipe("hat_metalplate", 
{Ingredient("alloy",3,"images/inventoryimages/alloy.xml"), Ingredient("footballhat", 1)}, 
RECIPETABS.WAR, TECH.SCIENCE_TWO, nil, nil, nil, nil,"knight_master","images/inventoryimages/hat_metalplate.xml","hat_metalplate.tex" )

AddRecipe("halberd", 
{Ingredient("alloy",1,"images/inventoryimages/alloy.xml", "alloy.tex"),Ingredient("twigs", 2)}, 
RECIPETABS.WAR, TECH.SCIENCE_TWO, nil, nil, nil, nil, "knight_master", "images/inventoryimages/dark_halberd.xml", "dark_halberd.tex" )

AddRecipe("knight_cutlass", 
{Ingredient("alloy",3,"images/inventoryimages/alloy.xml"), Ingredient("fish", 1), Ingredient("eel", 1)}, 
RECIPETABS.WAR, TECH.SCIENCE_TWO, nil, nil, nil, nil,"knight_master","images/inventoryimages/knight_cutlass.xml","knight_cutlass.tex" )

AddRecipe("aiur_securitycontract", 
{Ingredient("goldnugget",8),Ingredient("papyrus", 1)}, 
RECIPETABS.WAR, TECH.SCIENCE_ONE, nil, nil, nil, nil,"knight_master","images/inventoryimages/aiur_securitycontract.xml","aiur_securitycontract.tex" )


AddRecipe("icey_hunter_hat1", 
{Ingredient("houndstooth", 2),Ingredient("silk", 6)}, 
RECIPETABS.WAR, TECH.SCIENCE_ONE, nil, nil, nil, nil,"hunter_master","images/inventoryimages/icey_hunter_hat1.xml","icey_hunter_hat1.tex" )

AddRecipe("icey_hunter_clothing1", 
{Ingredient("houndstooth", 8),Ingredient("silk", 6),Ingredient("goldnugget", 2)}, 
RECIPETABS.WAR, TECH.SCIENCE_ONE, nil, nil, nil, nil,"hunter_master","images/inventoryimages/icey_hunter_clothing1.xml","icey_hunter_clothing1.tex" )

AddRecipe("hunter_trusty_shooter", 
{Ingredient("alloy",2,"images/inventoryimages/alloy.xml"), Ingredient("goldnugget", 2), Ingredient("redgem", 1)}, 
RECIPETABS.WAR, TECH.SCIENCE_ONE, nil, nil, nil, nil,"hunter_master","images/inventoryimages/hunter_trusty_shooter.xml","hunter_trusty_shooter.tex" )

AddRecipe("hunter_blunderbuss", 
{Ingredient("alloy",2,"images/inventoryimages/alloy.xml"), Ingredient("goldnugget", 5), Ingredient("gears", 1)}, 
RECIPETABS.WAR, TECH.SCIENCE_TWO, nil, nil, nil, nil,"hunter_master","images/inventoryimages/hunter_blunderbuss.xml","hunter_blunderbuss.tex" )

AddRecipe("insanity_skull_wilson", 
{Ingredient("moonglass",8),Ingredient("boneshard",12)}, 
RECIPETABS.MOON_ALTAR, TECH.MOON_ALTAR_TWO, nil, nil, nil, nil, "hunter_master","images/inventoryimages/insanity_skull_wilson.xml","insanity_skull_wilson.tex" )


AddRecipe("useless_pegleg", 
{Ingredient("log", 1), Ingredient("twigs",2)}, 
RECIPETABS.WAR, TECH.NONE, nil, nil, nil, nil,nil,"images/inventoryimages/useless_pegleg.xml","useless_pegleg.tex" )


AddRecipe("useless_corkbat", 
{Ingredient("log", 6), Ingredient("boards", 1)}, 
RECIPETABS.WAR, TECH.SCIENCE_ONE, nil, nil, nil, nil,nil,"images/inventoryimages/useless_corkbat.xml","useless_corkbat.tex" )


AddRecipe("icey_living_artifact", 
{Ingredient("infused_iron",6,"images/inventoryimages/infused_iron.xml"),Ingredient("metal_hulk_merge_soul",1,"images/inventoryimages/metal_hulk_merge_soul.xml"),Ingredient("pugalisk_soul",1,"images/inventoryimages/pugalisk_soul.xml")}, 
RECIPETABS.WAR, TECH.SCIENCE_TWO, nil, nil, nil, nil, nil,"images/inventoryimages/icey_living_artifact.xml","icey_living_artifact.tex" )




--




local iceyui = require("widgets/iceyui")
local iceylevelui = require("widgets/iceylevelui")
local iceysoundwidget = require("widgets/iceysoundwidget")
local iceyhelpui = require("widgets/iceyhelpui")
local iceykeycheckui = require("widgets/iceykeycheckui")
--local g11_ui = GLOBAL.require("widgets/g11_ui")

local function inv_redefine(self)
    if self.owner:HasTag("icey") then
        self.iceyui = self:AddChild(iceyui(self.owner))
		self.iceylevelui = self:AddChild(iceylevelui(self.owner))
		self.iceysoundwidget = self:AddChild(iceysoundwidget(self.owner))
		self.iceykeycheckui = self:AddChild(iceykeycheckui(self.owner))
		--self.iceyhelpui = self:AddChild(iceyhelpui(self.owner))
		
		-----------iceylevelui的缩放
		TheInput:AddKeyDownHandler(KEY_SPACE, function()
			local underHUD = TheInput:GetHUDEntityUnderMouse() 
			if underHUD and underHUD.GUID and  underHUD.GUID == self.iceylevelui.inst.GUID + 1 then 
				print("KEY_SPACE underHUD:",underHUD,underHUD.GUID,self.iceylevelui.inst.GUID)
				if not self.iceylevelui.scale then self.iceylevelui.scale = 1 end
				if self.iceylevelui.scale <= 1.5 then
					self.iceylevelui:Scale_DoDelta(0.05)
				elseif self.iceylevelui.scale > 1.5 then
					self.iceylevelui.scale = 0.75
					self.iceylevelui:SetScale(0.75)
				end
			end
		end)
		function self.owner.iceyui_overload_oncheckfn(flag)-----------------------检查显示UI：新增主人函数
			self.iceyui.overload_ui.oncheckfn(flag)
		end
    end
	function self.owner.EnableMovementPredictionFn(flag)
		print("self.owner.EnableMovementPredictionFn success!Set:",flag)
		self.owner:EnableMovementPrediction(flag)
	end
end


local function add_net(inst)-----------------------------------------------检查显示UI：新增网络变量
	inst.show_overload_ui = net_string(inst.GUID,"inst.show_overload_ui","show_overload_ui")
	inst:ListenForEvent("show_overload_ui",function(inst)
		print("show_overload_ui event push")
		if inst._parent and inst._parent.iceyui_overload_oncheckfn then 
			inst._parent.iceyui_overload_oncheckfn(inst.show_overload_ui:value())
		end
	end)
	
	inst.Icey_EnableMovementPrediction = net_bool(inst.GUID,"inst.Icey_EnableMovementPrediction","yanchiListen")
	inst:ListenForEvent("yanchiListen",function(inst)
		print("yanchiListen event push")
		if inst._parent and inst._parent.EnableMovementPredictionFn then 
			inst._parent.EnableMovementPredictionFn(inst.Icey_EnableMovementPrediction:value())
		end
	end)
	inst.Icey_EnableMovementPrediction:set(true)
end 


AddPrefabPostInit("player_classified", add_net)-----------------------------------------------检查显示UI：新增网络变量
AddClassPostConstruct("widgets/controls", inv_redefine)

AddMinimapAtlas("images/map_icons/rock_crystal.xml")
AddMinimapAtlas("images/map_icons/icey_tower.xml")
AddMinimapAtlas("images/map_icons/icey.xml")
AddMinimapAtlas("images/map_icons/zerg_crusher.xml")
AddMinimapAtlas("images/map_icons/happy_target.xml")
AddMinimapAtlas("images/map_icons/photon_cannon.xml")
AddMinimapAtlas("images/map_icons/darkchest.xml")
AddMinimapAtlas("images/inventoryimages/icey_tent.xml")
AddMinimapAtlas("images/map_icons/mutsuki_ai.xml")

AddModCharacter("icey", "FEMALE")



--------------------------------------------------------------------------------------------------



AddComponentPostInit("birdspawner",function(self)
	local oldSpawnBird = self.SpawnBird
	self.SpawnBird = function(self,spawnpoint, ignorebait)
		if TheWorld.Map.HasFakeGroundNearBy and TheWorld.Map:HasFakeGroundNearBy(spawnpoint:Get()) then 
			return 
		end 
		local bird = oldSpawnBird(self,spawnpoint,ignorebait)
		local retbird = bird
		if math.random() <= 0.1 then 
			local x,y,z = bird:GetPosition():Get()
			local sg = bird.sg and bird.sg.sg.currentstate
			local newbird = SpawnPrefab("pigeon")
			newbird.Transform:SetPosition(x,y,z)
			if newbird.sg and newbird.sg.sg.states[sg] then 
				newbird.sg:GoToState(sg)
			end
			retbird = newbird
			bird:Remove()
			if math.random() <= 0.5 then 
				local swarm = SpawnPrefab("pigeon_swarm")
				swarm.Transform:SetPosition(x,y,z)
			end
		end 
		return retbird
	end
end)

AddComponentPostInit("quaker",function(self)
	self:SetDebris( {
    { -- common
        weight = 0.75,
        loot = {
            "rocks",
            "flint",
			"crystal_item",
        },
    },
    { -- uncomon
        weight = 0.20,
        loot = {
            "goldnugget",
            "nitre",
            "rabbit",
            "mole",
        },
    },
    { -- rare
        weight = 0.05,
        loot = {
            "redgem",
            "bluegem",
            "marble",
        },
    },
})
end)

AddComponentPostInit("combat",function(self)
	local old_GetAttacked = self.GetAttacked
	self.GetAttacked = function(self,attacker, damage, weapon, stimuli)
		if damage > 0 and self.inst.components.health and  not self.inst.components.health:IsInvincible() then
			self.inst:PushEvent("preattacked",{attacker = attacker,damage = damage,weapon = weapon,stimuli = stimuli})
		end 
		return old_GetAttacked(self,attacker, damage, weapon, stimuli)
	end
end)

AddComponentPostInit("combat",function(self)
	self.LastFindChickenTargetTime = 0

	------------是否可以发现一个正在潜行的敌人
	self.CantSeeSneakingTarget = function(self,target)
		local phase = TheWorld.state.phase	
		--------对潜行敌人的视距随着昼夜而改变
		local see_dist = (phase == "day" and 15) or (phase == "dust" and 7.5) or (phase == "night" and 5) or 7.5 
		return target and target:IsValid() and target.components.iceysneaker and target.components.iceysneaker:IsSneaking() and (
		------------潜行的敌人在我身后，我看不到他
		(target.components.iceysneaker:OnTargetBack(self.inst))
		------------或者潜行的敌人离我太远了
		or (math.sqrt(target:GetDistanceSqToInst(self.inst)) > see_dist )
		------------或者潜行的敌人处于黑暗之中而我又不是夜行生物
		or ( not self.inst:HasTag("cavedweller") and target.LightWatcher and not target.LightWatcher:IsInLight())
		------------或者我在睡觉
		or (self.inst.sg and self.inst.sg:HasStateTag("sleeping")) 
		)
	end 
	
	local old_SetTarget = self.SetTarget
	self.SetTarget = function(self,target)
		local oldtarget = self.target 
		local ret = old_SetTarget(self,target)
		local newtarget = self.target 

		
		self.inst:DoTaskInTime(0,function() 
			if target and target:IsValid() and oldtarget ~= newtarget 
			and self.defaultdamage and self.defaultdamage > 0 
			and target.components.iceysneaker and target.components.iceysneaker:IsSneaking()
			and not (self.inst.sg and self.inst.sg:HasStateTag("sleeping")) 
			and not (self.inst.components.health and self.inst.components.health:IsDead()) then 
				local alert = self.inst:SpawnChild("metal_gear_alert")
				local height = (self.inst:HasTag("smallcreature") and 0.5) or (self.inst:HasTag("largecreature") and 2) or 1 
				alert.Transform:SetPosition(0,height,0)
			end
		end) 
			
		return ret
	end
	
	local old_SetRetargetFunction = self.SetRetargetFunction
	self.SetRetargetFunction = function(self,period, fn)
		local ret = old_SetRetargetFunction(self,period, fn)
		local old_targetfn = self.targetfn
		self.targetfn = function(inst)
			if old_targetfn == nil or type(old_targetfn) ~= "function" then 
				return 
			end 
			
			local target = old_targetfn(inst)
			if target and target:IsValid() then
				----------当我无法发现潜行的敌人时，我不能用这个函数将其设定为目标
				if target.components.iceysneaker and target.components.iceysneaker:IsSneaking() and self:CantSeeSneakingTarget(target) then 
					target = nil 
				end 
				----------我不能把带有3根鸡毛的菜鸡帽装备者作为目标
				if target and target.components.inventory and target.components.inventory:EquipHasTag("hat_icey_chicken_full") then
					if GetTime() - self.LastFindChickenTargetTime >= 3 then 
						self.LastFindChickenTargetTime = GetTime()
						if inst.sg and inst.sg.sg.states.taunt and not self.inst.sg:HasStateTag("busy") and not self.inst.sg:HasStateTag("sleeping") then 
							inst.sg:GoToState("taunt")
							local fx = SpawnPrefab("emote_fx") 
							if fx ~= nil then 
								if self.inst.components.rider and self.inst.components.rider:IsRiding() then 
									fx.Transform:SetSixFaced() 
								end 
								fx.entity:SetParent(self.inst.entity) 
								local offset = {
									large = {-145,5},
									character = {-125,4},
									default = {-45,3},
								}
								local choose_offset = (self.inst:HasTag("largecreature") and offset.large )
								or (self.inst:HasTag("character") and offset.character )
								or offset.default
								if self.hiteffectsymbol then 
									fx.entity:AddFollower() 
									fx.Follower:FollowSymbol(self.inst.GUID, self.hiteffectsymbol, 0, choose_offset[1], 0) 
								else
									fx.Transform:SetPosition(0,choose_offset[2],0)
								end 
							end
						end 
						
						
					end 
					target = nil 
				end
			end
			
			--
			return target 
		end 
		return ret 
	end 
	
	
	local wathgrithr_spirit_smallScale = .5
	local wathgrithr_spirit_medScale = .7
	local wathgrithr_spirit_largeScale = 1.1
	
	local function spawnspirit(inst, x, y, z, scale)
		local fx = SpawnPrefab("wathgrithr_spirit")
		fx.Transform:SetPosition(x, y, z)
		fx.Transform:SetScale(scale, scale, scale)
	end
	
	local old_ShareTarget = self.ShareTarget 
	self.ShareTarget = function(self,target, range, fn, maxnum)
		local current_sneaker = target.components.iceysneaker and target.components.iceysneaker:CanTerminateTarget(self.inst,true)
		self.inst:DoTaskInTime(0,function()
			if self.inst and self.inst:IsValid() then
				-------------被埋伏的很好的潜行者杀死/昏睡的生物无法发动声援
				--[[print("Sneaker ShareTarget:",
					current_sneaker,
					self.inst.components.health and self.inst.components.health:IsDead(),
					self.inst.components.sleeper and self.inst.components.sleeper:IsAsleep())--]]
				if current_sneaker and ((self.inst.components.health and self.inst.components.health:IsDead()) 
					or (self.inst.components.sleeper and self.inst.components.sleeper:IsAsleep())
					)
				then 
					--inst:SpawnChild("")
					local x, y, z = self.inst.Transform:GetWorldPosition()
					local scale = (self.inst:HasTag("smallcreature") and wathgrithr_spirit_smallScale)
						or (self.inst:HasTag("largecreature") and wathgrithr_spirit_largeScale)
						or wathgrithr_spirit_medScale
					spawnspirit(self.inst, x, y, z, scale)
					return 
				end 
				
				old_ShareTarget(self,target, range, fn, maxnum)
			end
		end)
	end 
end)

--------------------------------------------------------------------------
local id = "ICEY_REAP" --必须大写，动作会被加入到ACTIONS表中，key就是id。
local name = (TUNING.ICEY_LANGUAGE == "chinese" and "收割") or (TUNING.ICEY_LANGUAGE == "english" and "Reap")
local fn = function(act) -- 动作触发的函数。传入的是一个BufferedAction对象。可以通过它直接调用动作的执行者，目标，具体的动作内容等等，详情请查看bufferedaction.lua文件，也可以参考actions.lua里各个action的fn。
	local equip = act.doer.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS) or doer.replica.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
	if act.target:HasTag("pickable") then
		--print("Reap Action:",act.doer,act.target,act.doer)
		equip:DoTaskInTime(0,function()
			if act.doer.components.inventory then 
				act.doer.components.inventory:DropItem(equip, true, true)
			end 
			equip.components.projectile:Throw(act.doer,act.target,act.doer)
		end)
		return true
	end
end

--注册动作
AddAction(id,name,fn) -- 将上面编写的内容传入MOD API,添加动作。
ACTIONS.ICEY_REAP.distance=TUNING.BOOMERANG_DISTANCE
ACTIONS.ICEY_REAP.priority = 10
--绑定组件
--在这里需要动一动脑筋。选择要和哪个组件进行绑定，绑定成什么类型，设定怎样的条件可以触发动作，全凭个人喜好。

local type = "SCENE" -- 设置动作绑定的类型
local component = "pickable" -- 设置动作绑定的组件
local testfn = function(inst, doer, actions, right) -- 设置动作的检测函数，如果满足条件，就向人物的动作可执行表中加入某个动作。right表示是否是右键动作。
	local equip = (doer.components.inventory and doer.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS))
	or (doer.replica.inventory and doer.replica.inventory:GetEquippedItem(EQUIPSLOTS.HANDS))
	
	if equip and equip:IsValid() and equip:HasTag("ACTION_REAP") 
	and inst:HasTag("pickable") and doer:HasTag("player") then
		table.insert(actions, ACTIONS.ICEY_REAP)
	end
end
AddComponentAction(type, component, testfn)


--[[绑定state
在联机版中添加新动作需要对wilson和wilson_cient两个sg都进行state绑定。
此处选择的state最好是整个执行过程中某个阶段带有inst:PerformBufferedAction()语句的。这条语句是触发动作的fn用的。如果整个state里没有这句，则动作的fn是不会触发的，也就不会达到你预期的效果。
推荐使用的官方state: dostandingaction,doshortaction,dolongaction，dojostleaction
除此之外你也可以自行编写state，自己控制播放什么动画，何时触发动作的fn等等。需要注意的是主机端和客机端在这上面的代码是有区别，具体请参考官方的代码。--]]


local state = "dojostleaction" -- 设定要绑定的state
AddStategraphActionHandler("wilson",ActionHandler(ACTIONS.ICEY_REAP, state))
AddStategraphActionHandler("wilson_client",ActionHandler(ACTIONS.ICEY_REAP,state))
-----------------------------------------------------------------------------------------------
local id = "POD_SWITCH" 
local name = (TUNING.ICEY_LANGUAGE == "chinese" and "切换开关") or (TUNING.ICEY_LANGUAGE == "english" and "Switch")
local fn = function(act) 
	local doer = act.doer
	if doer.components.poduser then
		doer.components.poduser:Switch()
		return true 
	end
end

AddAction(id,name,fn) -- 将上面编写的内容传入MOD API,添加动作。
ACTIONS.POD_SWITCH.distance=2
ACTIONS.POD_SWITCH.priority = 10

local type = "SCENE" -- 设置动作绑定的类型
local component = "inspectable" -- 设置动作绑定的组件
local testfn = function(inst, doer, actions, right) -- 设置动作的检测函数，如果满足条件，就向人物的动作可执行表中加入某个动作。right表示是否是右键动作。
	
	if inst:HasTag("icey_pod") and doer:HasTag("player") and doer:HasTag("poduser") then
		table.insert(actions, ACTIONS.POD_SWITCH)
	end
end
AddComponentAction(type, component, testfn)

local state = "doshortaction" -- 设定要绑定的state
AddStategraphActionHandler("wilson",ActionHandler(ACTIONS.POD_SWITCH, state))
AddStategraphActionHandler("wilson_client",ActionHandler(ACTIONS.POD_SWITCH,state))


ACTIONS.FUSE = Action()
ACTIONS.FUSE.fn = function(act)
	-- print("ACTIONS.MATE.fn")
	if act.target == act.doer then
		return false
	end

	if act.doer.components.fuseable then
		act.doer.components.fuseable:Mate()
		return true
	end
end

ACTIONS.BARK = Action(nil,nil,nil, 3)
ACTIONS.BARK.fn = function(act)
	return true
end

ACTIONS.RANSACK = Action(nil,nil,nil, 0.5)
ACTIONS.RANSACK.fn = function(act)
	return true
end

ACTIONS.FLUP_HIDE = Action({})
ACTIONS.FLUP_HIDE.fn = function(act)
	return true
end

--------------------------------------------------------------
local oldactionpickup = ACTIONS.PICKUP.fn 
ACTIONS.PICKUP.fn = function(act) 
	if act.doer.components.inventory ~= nil and act.target ~= nil 
	and act.target.components.pickupable ~= nil and not act.target:IsInLimbo() then     
		act.doer:PushEvent("onpickupitem", {item = act.target}) 
		return act.target.components.pickupable:OnPickup(act.doer) 
	end 
	return oldactionpickup(act) 
end  

local function stewerfix(inst, doer, actions, right) 
	local function CanBePickUp(inst) 
		return not inst:HasTag("donecooking") and not inst:HasTag("readytocook") and inst.replica.container ~= nil and #inst.replica.container:GetItems() == 0 and not inst:HasTag("isopen") and not inst:HasTag("iscooking") 
	end 
	if inst:HasTag("pickupable") and right and CanBePickUp(inst) then 
		table.insert(actions, GLOBAL.ACTIONS.PICKUP)     
	end 
end  
AddComponentAction("SCENE", "pickupable", stewerfix)  
--------------------------------------------------------------
--------------------------------------------------------------
local oldactionharvest = ACTIONS.HARVEST.fn 
ACTIONS.HARVEST.fn = function(act) 
	if act.target.components.melter then
        return act.target.components.melter:Harvest(act.doer)
	else
		return oldactionharvest(act)
	end  
end  

local function melterfix(inst, doer, actions, right) 
	if not inst:HasTag("burnt") and not (doer.replica.rider ~= nil and doer.replica.rider:IsRiding()) then
		if inst:HasTag("donecooking") then
            table.insert(actions, ACTIONS.HARVEST)
		end 
	end 
end 

AddComponentAction("SCENE", "melter", melterfix)  
--------------------------------------------------------------
local WEAPON_REPAIR = Action()
WEAPON_REPAIR.id = "WEAPON_REPAIR"
WEAPON_REPAIR.str = (TUNING.ICEY_LANGUAGE == "chinese" and "修复") or (TUNING.ICEY_LANGUAGE == "english" and "Repair")
WEAPON_REPAIR.priority = 10
WEAPON_REPAIR.fn = function(act) -- 动作触发的函数。传入的是一个BufferedAction对象。可以通过它直接调用动作的执行者，目标，具体的动作内容等等，详情请查看bufferedaction.lua文件，也可以参考actions.lua里各个action的fn。
	local item = act.invobject
	if item and item:IsValid()  and act.doer:HasTag("player")  then
		item.components.weaponrepairer:Repair(act.doer,act.target)
		return true 
	end
	return false
end


--注册动作
AddAction(WEAPON_REPAIR) -- 将上面编写的内容传入MOD API,添加动作。
--ACTIONS.WEAPON_REPAIR.distance=TUNING.BOOMERANG_DISTANCE

--绑定组件
--在这里需要动一动脑筋。选择要和哪个组件进行绑定，绑定成什么类型，设定怎样的条件可以触发动作，全凭个人喜好。

local type = "USEITEM" -- 设置动作绑定的类型
local component = "weaponrepairer" -- 设置动作绑定的组件
local testfn = function(inst, doer, target, actions) -- 设置动作的检测函数，如果满足条件，就向人物的动作可执行表中加入某个动作。right表示是否是右键动作。
	if  doer:HasTag("player") and target:HasTag("weaponrepairable") then
		table.insert(actions, ACTIONS.WEAPON_REPAIR)
	end
end
AddComponentAction(type, component, testfn)


--[[绑定state
在联机版中添加新动作需要对wilson和wilson_cient两个sg都进行state绑定。
此处选择的state最好是整个执行过程中某个阶段带有inst:PerformBufferedAction()语句的。这条语句是触发动作的fn用的。如果整个state里没有这句，则动作的fn是不会触发的，也就不会达到你预期的效果。
推荐使用的官方state: dostandingaction,doshortaction,dolongaction，dojostleaction
除此之外你也可以自行编写state，自己控制播放什么动画，何时触发动作的fn等等。需要注意的是主机端和客机端在这上面的代码是有区别，具体请参考官方的代码。--]]


local state = "dolongaction" -- 设定要绑定的state
AddStategraphActionHandler("wilson",ActionHandler(ACTIONS.WEAPON_REPAIR, state))
AddStategraphActionHandler("wilson_client",ActionHandler(ACTIONS.WEAPON_REPAIR,state))
---------------------------------------------------------------------------------------------------
local invade_strs = {
	"遭到暗灵 %s 的入侵",
	"你的世界正在被 %s 入侵",
}
local USEBLOODEYE = Action()
USEBLOODEYE.id = "USEBLOODEYE"
USEBLOODEYE.str = (TUNING.ICEY_LANGUAGE == "chinese" and "化身暗灵") or (TUNING.ICEY_LANGUAGE == "english" and "Become Dark Spirit")
USEBLOODEYE.priority = 10
USEBLOODEYE.fn = function(act) -- 动作触发的函数。传入的是一个BufferedAction对象。可以通过它直接调用动作的执行者，目标，具体的动作内容等等，详情请查看bufferedaction.lua文件，也可以参考actions.lua里各个action的fn。
	local item = act.invobject
	if item and item:IsValid() and item:HasTag("darkspirit_stone") 
	and act.doer.components.darkspirit and not act.doer.components.darkspirit:IsInvading() then
		act.doer.components.darkspirit:StartInvade() 
		item:Remove() 
		return true 
	end
	return false
end


--注册动作
AddAction(USEBLOODEYE) -- 将上面编写的内容传入MOD API,添加动作。

local type = "INVENTORY" -- 设置动作绑定的类型
local component = "inventoryitem" -- 设置动作绑定的组件
local testfn = function(inst, doer,actions, right) -- 设置动作的检测函数，如果满足条件，就向人物的动作可执行表中加入某个动作。right表示是否是右键动作。
	if doer:HasTag("player") and not doer:HasTag("darkspirit") and inst:HasTag("darkspirit_stone") then
		table.insert(actions, ACTIONS.USEBLOODEYE)
	end
end
AddComponentAction(type, component, testfn)

local state = "dolongaction" -- 设定要绑定的state
AddStategraphActionHandler("wilson",ActionHandler(ACTIONS.USEBLOODEYE, state))
AddStategraphActionHandler("wilson_client",ActionHandler(ACTIONS.USEBLOODEYE,state))
---------------------------------------------------------------------------------------------------


---------------------------------------------------------------------------------------------------

local DESTROYTIP = Action()
DESTROYTIP.id = "DESTROYTIP"
DESTROYTIP.str = (TUNING.ICEY_LANGUAGE == "chinese" and "摧毁") or (TUNING.ICEY_LANGUAGE == "english" and "Destroy")
DESTROYTIP.priority = 10
DESTROYTIP.fn = function(act) -- 动作触发的函数。传入的是一个BufferedAction对象。可以通过它直接调用动作的执行者，目标，具体的动作内容等等，详情请查看bufferedaction.lua文件，也可以参考actions.lua里各个action的fn。
	local item = act.target
	if item and item:IsValid() then 
		--item:Remove() 
		local pos = item:GetPosition()
		item:AddTag("NOCLICK")
		item.persists = false
		ErodeAway(item)
		SpawnPrefab("burnt_marsh_bush_erode").Transform:SetPosition(pos:Get())
		return true 
	end
	return false
end


--注册动作
AddAction(DESTROYTIP) -- 将上面编写的内容传入MOD API,添加动作。

local type = "SCENE" -- 设置动作绑定的类型
local component = "writeable" -- 设置动作绑定的组件
local testfn = function(inst, doer, actions, right) -- 设置动作的检测函数，如果满足条件，就向人物的动作可执行表中加入某个动作。right表示是否是右键动作。
	if doer:HasTag("player") and inst:HasTag("destroyable") and right then
		table.insert(actions, ACTIONS.DESTROYTIP)
	end
end
AddComponentAction(type, component, testfn)

local state = "dolongaction" -- 设定要绑定的state
AddStategraphActionHandler("wilson",ActionHandler(ACTIONS.DESTROYTIP, state))
AddStategraphActionHandler("wilson_client",ActionHandler(ACTIONS.DESTROYTIP,state))
---------------------------------------------------------------------------------------------------
local function arround_circle(x,y,z,r)
	repeat
		local offset = r
		local x1, y1, z1 = 0,0,0
		local arc = math.random(0,360)
		local h = math.random(1,offset)
		x1 = x + math.cos(arc) * h
		z1 = z + math.sin(arc) * h
		if TheWorld.Map:IsPassableAtPoint(x1,y1, z1) then
			return x1, y1, z1
		end
	until TheWorld.Map:IsPassableAtPoint(x1, y1, z1)
end 

local function tadalin_army()
	print(TheWorld.ismastersim)
	if  TheNet:GetIsClient() then return end
	--if  TheNet:GetIsServer() and TheNet:GetServerIsDedicated() then return end
	if TheWorld.state.cycles <= 24 or TheWorld.state.cycles % 8 ~= 0 or #AllPlayers == 0 then 
		return
	end
	local minions = 
	{
		[1] = "spider_haojie",
		[2] = "spider_xianfeng",
		[3] = "spider_chaser",
		[4] = "spider_bomb",
		[5] = "spider_dragoon",
	}
	
	local luckguy = {}
	local after_time = math.random(45,120)
	for i=1,math.random(2,3) do 
		local nums = math.random(#AllPlayers)
		local can = true
		for k,v in pairs(luckguy) do 
			if v == AllPlayers[nums] then 
				can = false
				i = i - 1 
				break
			end
		end 
		if can then 
			table.insert(luckguy,AllPlayers[nums])
		end 
	end 
	
	print("浩劫军团入侵!")
	TheNet:Announce("警告,浩劫军团即将抵达。")
	
	TheWorld:DoTaskInTime(after_time,function()
	
	for k,v in pairs(luckguy) do 
		print("LUCK GUY:",v)
		
		if not v or not v:IsValid() then 
			return
		end 
		local x,y,z = v:GetPosition():Get()
		repeat
			local offset = 20
			local x1, y1, z1 = 0,0,0
			local arc = math.random(0,360)
			local h = math.random(1,offset)
			x1 = x + math.cos(arc) * h
			z1 = z + math.sin(arc) * h
			if TheWorld.Map:IsPassableAtPoint(x1, y1, z1) then
					local tadalin = SpawnPrefab("tadalin_tower")
					local fx = SpawnPrefab("red_lightning")
					local time = 0.3
					tadalin.Transform:SetPosition(x1, y1, z1)
					fx.Transform:SetPosition(x1, y1, z1)
					TheWorld:StartThread(function()		
						for i=1,math.random(3,5) do 
							local fx = SpawnPrefab("red_lightning")
							local spider = SpawnPrefab(minions[math.random(1,5)])
							local x2,y2,z2 = arround_circle(x1,y1,z1,7)
							fx.Transform:SetScale(10,10,10)
							fx.Transform:SetPosition(x2,y2,z2)
							spider.Transform:SetPosition(x2,y2,z2)
							if spider.components.combat and v then 
								spider.components.combat:SetTarget(v)
							end
							Sleep(time)
							time = time - 0.05
						end
					end)
				
				break
				
			end
		until TheWorld.Map:IsPassableAtPoint(x1, y1, z1)
	end
	end)
	
end 

local function ly_worldfn(world)
	if TUNING.ICEY_DLCS == "WarOfZerg" then 
		world:WatchWorldState("startday",tadalin_army)
	end 
end 

local function onbossdefeated(inst,data)
	local name = data.name
	inst.components.iceybossworld:Add(name)
end 

local function AddWorldBoss(world)
	if not TheWorld.ismastersim then
		return inst
	end
	world:AddComponent("iceybossworld")
	world:ListenForEvent("iceybossdefeated",onbossdefeated)
end 

local function AddClockTowerWorld(world)
	if not TheWorld.ismastersim then
		return inst
	end
	world:AddComponent("clocktowerspawner")
	----------为了时计塔房间的特殊判断
--[[	local old_IsPassableAtPoint = world.Map.IsPassableAtPoint
	world.Map.IsPassableAtPoint = function(self,x,y,z,...)
		local grounds = TheSim:FindEntities(x,y,z,30,{"FAKEGROUND"})
		for k,v in pairs(grounds) do 
			local v_pos = v:GetPosition()
			local target_pos = Vector3(x,y,z)
			
			local dist = target_pos:Dist(v_pos)
			
			if v.FAKEGROUND_RADIUS == nil or v.FAKEGROUND_RADIUS >= dist then 
				return true 
			end
		end
		return old_IsPassableAtPoint(self,x,y,z,...)
	end --]]
end 

local function AddMetroWorld(world)
	if not TheWorld.ismastersim then 
		return inst
	end
	if not world:HasTag("cave") then 
		world:AddComponent("metroworld")
		--world.components.metroworld:InitSeason() 
	end 
	
end 

local function deerclops_to_walker(inst)
	if not TheWorld.ismastersim then
		return inst
	end
	if TUNING.ICEY_DLCS == "WarOfZerg"  then 
		inst:DoTaskInTime(0,function()
			if not TheWorld.components.iceybossworld:IsDefeated("spider_higher") then
				return 
			end
			local walker = SpawnPrefab("sky_walker")
			walker.Transform:SetPosition(inst:GetPosition():Get())
			TheNet:Announce("警告,侦测到不明改造生物")
			inst:Hide()
			inst.components.lootdropper:SetLoot({})
			inst.components.health:Kill()
		end)
	end 
end

local function krampus_to_san(inst)
	if not TheWorld.ismastersim then
		return inst
	end
	
	local strs = {
		"感到罪恶爬上了脊梁......",
		"这种人，应该在地狱里燃烧....",
	}
	
	
	inst:DoTaskInTime(0,function()
			if not TheWorld.components.iceybossworld:IsDefeated("sky_walker") or not TheWorld.components.iceybossworld:IsDefeated("pugalisk") then 
				return 
			end 
			local x,y,z = inst:GetPosition():Get()
			local ents = TheSim:FindEntities(x,y,z,10000,{"_combat","epic"})
			for k,v in pairs(ents) do 
				if v.prefab == "klaus" then 
					return
				elseif v.prefab == "icey_sans" then 
					return
				end
			end 
			local walker = SpawnPrefab("icey_sans")
			local target = inst.spawnedforplayer 
			local name =  (target and target.name) or "你"
			local str = strs[math.random(1,#strs)]
			print(target,name)
			walker.Transform:SetPosition(x,y,z)
			
			if target then 
				walker.components.combat:SetTarget(target)
				if name ~= "你" and target:HasTag("icey") and walker.components.named then 
					walker.components.named:SetName(name)
				end 
				walker.Transform:SetPosition(target:GetPosition():Get())
				walker.sg:GoToState("icey_lance_pst",{target = target})
			end 
			
			TheNet:Announce(name..str)
			inst:Remove()
		end)
end

local function AddCrystal(inst)
	local SMASHABLE_WORK_ACTIONS =
{
    CHOP = true,
    DIG = true,
    HAMMER = true,
    MINE = true,
}
local SMASHABLE_TAGS = { "_combat", "_inventoryitem", "campfire" }
for k, v in pairs(SMASHABLE_WORK_ACTIONS) do
    table.insert(SMASHABLE_TAGS, k.."_workable")
end
local NON_SMASHABLE_TAGS = { "INLIMBO", "playerghost" }

local DENSITY = 0.1 -- the approximate density of rock prefabs in the rocky biomes
local FIVERADIUS = CalculateFiveRadius(DENSITY)
local EXCLUDE_RADIUS = 3

local function onexplode(inst)
    inst.SoundEmitter:PlaySound("dontstarve/common/meteor_impact")

    if inst.warnshadow ~= nil then
        inst.warnshadow:Remove()
        inst.warnshadow = nil
    end

    local shakeduration = .7 * inst.size
    local shakespeed = .02 * inst.size
    local shakescale = .5 * inst.size
    local shakemaxdist = 40 * inst.size
    ShakeAllCameras(CAMERASHAKE.FULL, shakeduration, shakespeed, shakescale, inst, shakemaxdist)

    local x, y, z = inst.Transform:GetWorldPosition()

    if not inst:IsOnValidGround() then
        local splash = SpawnPrefab("splash_ocean")
        if splash ~= nil then
            splash.Transform:SetPosition(x, y, z)
        end
    else
        local scorch = SpawnPrefab("burntground")
        if scorch ~= nil then
            scorch.Transform:SetPosition(x, y, z)
            local scale = inst.size * 1.3
            scorch.Transform:SetScale(scale, scale, scale)
        end
        local launched = {}
        local ents = TheSim:FindEntities(x, y, z, inst.size * TUNING.METEOR_RADIUS, nil, NON_SMASHABLE_TAGS, SMASHABLE_TAGS)
        for i, v in ipairs(ents) do
            --V2C: things "could" go invalid if something earlier in the list
            --     removes something later in the list.
            --     another problem is containers, occupiables, traps, etc.
            --     inconsistent behaviour with what happens to their contents
            --     also, make sure stuff in backpacks won't just get removed
            --     also, don't dig up spawners
            if v:IsValid() and not v:IsInLimbo() then
                if v.components.workable ~= nil then
                    if v.components.workable:CanBeWorked() and not (v.sg ~= nil and v.sg:HasStateTag("busy")) then
                        local work_action = v.components.workable:GetWorkAction()
                        --V2C: nil action for campfires
                        if (work_action == nil or SMASHABLE_WORK_ACTIONS[work_action.id]) and
                            (work_action ~= ACTIONS.DIG
                            or (v.components.spawner == nil and
                                v.components.childspawner == nil)) then
                            v.components.workable:WorkedBy(inst, inst.workdone or 20)
                        end
                    end
                elseif v.components.combat ~= nil then
                    v.components.combat:GetAttacked(inst, inst.size * TUNING.METEOR_DAMAGE, nil)
                elseif v.components.inventoryitem ~= nil then
                    if v.components.container ~= nil then
                        -- Spill backpack contents, but don't destroy backpack
                        if math.random() <= TUNING.METEOR_SMASH_INVITEM_CHANCE then
                            v.components.container:DropEverything()
                        end
                        Launch(v, inst, TUNING.LAUNCH_SPEED_SMALL)
                        launched[v] = true
                    elseif v.components.mine ~= nil and not v.components.mine.inactive then
                        -- Always smash things on the periphery so that we don't end up with a ring of flung loot
                        v.components.mine:Deactivate()
                        Launch(v, inst, TUNING.LAUNCH_SPEED_SMALL)
                        launched[v] = true
                    elseif (inst.peripheral or math.random() <= TUNING.METEOR_SMASH_INVITEM_CHANCE)
                        and not v:HasTag("irreplaceable") then
                        -- Always smash things on the periphery so that we don't end up with a ring of flung loot
                        local vx, vy, vz = v.Transform:GetWorldPosition()
                        SpawnPrefab("ground_chunks_breaking").Transform:SetPosition(vx, 0, vz)
                        v:Remove()
                    else
                        Launch(v, inst, TUNING.LAUNCH_SPEED_SMALL)
                        launched[v] = true
                    end
                end
            end
        end

        for i, v in ipairs(inst.loot) do
            if math.random() <= v.chance then
                local canspawn = true
                --Check if there's space to deploy rocks
                --Similar to CanDeployAtPoint check in map.lua
                local ents = TheSim:FindEntities(x, y, z, FIVERADIUS, {"boulder"})
                if #ents < 5 then
                    ents = TheSim:FindEntities(x, y, z, EXCLUDE_RADIUS, nil, { "NOBLOCK", "FX" })
                    for k, v in pairs(ents) do
                        if v ~= inst and
                            not launched[v] and
                            v.entity:IsValid() and
                            v.entity:IsVisible() and
                            v.components.placer == nil and
                            v.entity:GetParent() == nil then
                            canspawn = false
                            break
                        end
                    end
                else
                    canspawn = false
                end
                if canspawn then
                    local drop = SpawnPrefab(v.prefab)
                    if drop ~= nil then
                        drop.Transform:SetPosition(x, y, z)
                        if drop.components.inventoryitem ~= nil then
                            drop.components.inventoryitem:OnDropped(true)
                        end
                    end
                end
            end
        end
    end
end

local function dostrike(inst)
    inst.striketask = nil
    inst.AnimState:PlayAnimation("crash")
    inst:DoTaskInTime(0.33, onexplode)
    inst:ListenForEvent("animover", inst.Remove)
    -- animover isn't triggered when the entity is asleep, so just in case
    inst:DoTaskInTime(3, inst.Remove)
end

local warntime = 1
local sizes = 
{ 
    small = .7,
    medium = 1,
    large = 1.3,
}
local work =
{
    small = 1,
    medium = 2,
    large = 20,
}

local function SetPeripheral(inst, peripheral)
    inst.peripheral = peripheral
end

local function SetSize(inst, sz, mod)
    if inst.autosizetask ~= nil then
        inst.autosizetask:Cancel()
        inst.autosizetask = nil
    end
    if inst.striketask ~= nil then
        return
    end

    if sizes[sz] == nil then
        sz = "small"
		
    end

    inst.size = sizes[sz]
    inst.workdone = work[sz]
    inst.warnshadow = SpawnPrefab("meteorwarning")

    if mod == nil then
        mod = 1
    end

    if sz == "medium" then
        inst.loot =
        {
			{ prefab = "rock_crystal", chance = 0.75},
            { prefab = "rocks", chance = TUNING.METEOR_CHANCE_INVITEM_OFTEN * mod },
            { prefab = "rocks", chance = TUNING.METEOR_CHANCE_INVITEM_RARE * mod },
            { prefab = "flint", chance = TUNING.METEOR_CHANCE_INVITEM_ALWAYS * mod },
            { prefab = "flint", chance = TUNING.METEOR_CHANCE_INVITEM_VERYRARE * mod },
			--[[{ prefab = "crystal_item", chance = TUNING.METEOR_CHANCE_INVITEM_OFTEN * mod },
            { prefab = "crystal_item", chance = TUNING.METEOR_CHANCE_INVITEM_RARE * mod },
			{ prefab = "crystal_item", chance = TUNING.METEOR_CHANCE_INVITEM_OFTEN * mod },
            { prefab = "crystal_item", chance = TUNING.METEOR_CHANCE_INVITEM_RARE * mod },
			{ prefab = "crystal_item", chance = TUNING.METEOR_CHANCE_INVITEM_OFTEN * mod },
            { prefab = "crystal_item", chance = TUNING.METEOR_CHANCE_INVITEM_RARE * mod },--]]
            { prefab = "moonrocknugget", chance = TUNING.METEOR_CHANCE_INVITEM_SOMETIMES * mod },
        }
    elseif sz == "large" then
        local rand = math.random()
        if rand <= TUNING.METEOR_CHANCE_BOULDERMOON * mod then
            inst.loot =
            {
                {
                    prefab = (rand <= .33 and "rock_moon") or ("rock_crystal"),
                    chance = 1,
                },
            }
        elseif rand <= TUNING.METEOR_CHANCE_BOULDERFLINTLESS * mod then
            rand = math.random() -- Randomize which flintless rock we use
            inst.loot =
            {
                {
                    prefab =
						(rand <= .90 and "rock_crystal") or 
                        (rand <= .33 and "rock_flintless") or
                        (rand <= .67 and "rock_flintless_med") or
                        "rock_flintless_low",
                    chance = 1,
                },
            }
        else -- Don't check for chance or mod this one: we need to pick a boulder
            inst.loot =
            {
	            { 
                    prefab = "moonrocknugget",
                    chance = TUNING.METEOR_CHANCE_INVITEM_SOMETIMES * mod
                },
				{ 
                    prefab = "crystal_item",
                    chance = 0.1
                },
				--[[{ 
                    prefab = "crystal_item",
                    chance = 1
                },
				{ 
                    prefab = "crystal_item",
                    chance = 1
                },--]]
                {
                    prefab = "rock1",
                    chance = 1,
                },
            }
        end
    else -- "small" or other undefined
        inst.loot =
        {
			{ prefab = "crystal_item", chance = 0.1},
        }
    end

    inst.Transform:SetScale(inst.size, inst.size, inst.size)
    inst.warnshadow.Transform:SetScale(inst.size, inst.size, inst.size)

    -- Now that we've been set to the appropriate size, go for the gusto
    inst.striketask = inst:DoTaskInTime(warntime, dostrike)

    inst.warnshadow.entity:SetParent(inst.entity)
    inst.warnshadow.startfn(inst.warnshadow, warntime, .33, 1)
end

local function AutoSize(inst)
    inst.autosizetask = nil
    local rand = math.random()
    inst:SetSize(rand <= .33 and "large" or (rand <= .67 and "medium" or "small"))
end

	inst.SetSize = SetSize
    inst.SetPeripheral = SetPeripheral
end

local function IsIceyDamage(cause)
	return cause and (cause == "icey" or string.find(cause,'icey_shadow'))
end 

local function keepNDecimalPlaces(decimal,n)-----------------------四舍五入保留n位小数的代码
	n = n or 0
	local h = math.pow(10,n)
    decimal = math.floor((decimal * h)+0.5)/h       
    return  decimal 
end

local function DamageNumberTest(inst)
--[[	local inst = ThePlayer 
	local x,y,z = inst:GetPosition():Get() 
	local players = TheSim:FindEntities(x,y,z,30,{"player"}) 
	for k,v in pairs(players) do 
		local number2 = v:SpawnChild("icey_damage_number") 
		number2:UpdateDamageNumbers(v, inst, "TEXT TEST" , nil, nil, true,{1,1,1,1}) 
	end --]]
end

local function showdamagenumber(inst,data)
	local overtime = data.overtime
	if overtime then 
		return 
	end 
	if inst.components.health  then 
		local max = inst.components.health:GetMaxWithPenalty() or 0
		local amount = (data.newpercent - data.oldpercent) * max
		local data_amount = data.amount
		local cause = data.cause
		if amount and data_amount and data_amount ~= 0 then
			--print("damage number! cause:",cause)
			local colour = (IsIceyDamage(cause) and {13/255,190/255,222/255,1}) or {255/255,80/255,40/255,1}
			if amount > 0 then
				colour = { 0 / 255, 255 / 255, 78 / 255, 1 }
			end
			--print("Damage number:",amount)
			amount = math.abs(amount)
			
			--amount = math.floor(amount+0.5)
			
			if amount < 1 then 
				amount = keepNDecimalPlaces(amount,1)
			else
				amount = keepNDecimalPlaces(amount)
			end 
			
			if amount <= 0.1 then 
				return -------依然太小的数字不显示
			end 
			
			local large = amount >= 100
			local x,y,z = inst:GetPosition():Get()
			local players = TheSim:FindEntities(x,y,z,30,{"player"})
			
			for k,v in pairs(players) do 
				local number = v:SpawnChild("icey_damage_number")
				number:UpdateDamageNumbers(v, inst, amount , nil, nil, large,colour)
			end  
		end  
	end
end 


 

local function AddDamageNumber(inst)
	if not TheWorld.ismastersim then
        return inst
    end
	if inst.components.health and inst.components.combat then 
		inst:ListenForEvent("healthdelta",showdamagenumber)
		--inst:ListenForEvent("numbertest",DamageNumberTest)
		--c_findnext("icey"):PushEvent("numbertest")
	end
end 

local function AddMoonBase(inst)
	if not TheWorld.ismastersim then
        return inst
    end
	
	inst:AddComponent("moon_giaour_spawner")
	--[[inst:DoTaskInTime(0,function()
		inst.components.moon_giaour_spawner:SpawnMinions()
	end)--]]
end 

local IceyBoss = {
	"spider_higher",--------主宰
	"sky_walker",-----------天罚行者
	"pugalisk",-------------世界吞噬者
	"icey_sans",------------黯影·艾希
	"shadow_mixtrues",------噩梦融合体
	"moon_giaour",----------FDA-7 巨擘
	
	"icey_boarrior",--------罪业之都的孤独王者------巨人尤姆
	"tigershark_duke",------栖身深海的失落贵族------虎鲨公爵
	"dark_antqueen",
	"ancient_herald",-------沉默的黯影文明贤者------远古先驱
	"metal_hulk_merge",-----和平行者
	
	"boss_elecarmet",-------暮光执政官
	"jade",-----------------青玉巨神
	--"wugong",---------------牛角帽阵列
	
	"death_dragon",
}

local function NormalOnBossDeath(inst)
	TheWorld:PushEvent("iceybossdefeated",{name = inst.prefab})
	if inst.components.lootdropper then 
		inst.components.lootdropper:SpawnLootPrefab(inst.prefab.."_soul",inst:GetPosition())
	end
end 

local function AddIceyBoss(inst)
	if inst.prefab ~= "ancient_herald" and inst.prefab ~= "death_dragon" then 
		inst.entity:AddMiniMapEntity()
		inst.MiniMapEntity:SetCanUseCache(false)
		inst.MiniMapEntity:SetDrawOverFogOfWar(true)
		inst.MiniMapEntity:SetIcon(inst.prefab..".tex")
	end
	
	if not TheWorld.ismastersim then
		return inst
	end
	
	if inst.prefab ~= "ancient_herald" and inst.prefab ~= "death_dragon" then 
		inst.EnableOnMap = IceyUtil.EnableDrawOverFogOfWar		
		inst.EnableOnMapInTimes = function(self,time)
			self:EnableOnMap(true) 
			if self.DisableOnMapTask then 
				self.DisableOnMapTask:Cancel()
				self.DisableOnMapTask = nil 
			end 
			self.DisableOnMapTask = self:DoTaskInTime(time,function()
				self:EnableOnMap(false) 
				self.DisableOnMapTask:Cancel()
				self.DisableOnMapTask = nil 
			end)
		end
	end
	
	inst:ListenForEvent("death",NormalOnBossDeath)
end 

for k,v in pairs(IceyBoss) do 
	if v ~= "ancient_herald" and v ~= "death_dragon" then 
		table.insert(Assets,Asset( "IMAGE", "images/map_icons/"..v..".tex" ))
		table.insert(Assets,Asset( "ATLAS", "images/map_icons/"..v..".xml" ))
		AddMinimapAtlas("images/map_icons/"..v..".xml")
	end 
	AddPrefabPostInit(v,AddIceyBoss)
end 

local function AddClockWorksIron(inst)
	if not TheWorld.ismastersim then
		return inst
	end
	
	if not inst:HasTag("chess") or inst:HasTag("icey_carrook") then 
		return 
	end 
	
	if not (inst.components.combat and inst.components.health) then 
		return
	end 
	
	inst.IronNumber = 0
	
	inst:DoTaskInTime(0,function()
		inst.IronNumber = 20 * inst.components.health:GetPercent()
	end)

	
	inst:ListenForEvent("attacked",function(inst,data)
		local damage = data.damage or 0
		local randbase = inst:HasTag("cavedweller") and 50 or 100 
		if math.random()*randbase <= damage and inst.IronNumber > 0 then 
			if inst.components.lootdropper then 
				inst.components.lootdropper:SpawnLootPrefab("iron",inst:GetPosition())
				inst.IronNumber = inst.IronNumber - 1
			end 
		end 
	end)
end 

local function AddWeaponRepairTag(inst)
	if not TheWorld.ismastersim then
		return inst
	end
	
	if inst.components.armor or inst.components.finiteuses then 
		inst:AddTag("weaponrepairable")
	end
end 

local function AddPortal(inst)
	if not TheWorld.ismastersim then
		return inst
	end
	
	local function NoHoles(pt)
		return not TheWorld.Map:IsPointNearHole(pt)
	end
	
	inst:AddComponent("spawner")
    inst.components.spawner:Configure("chest_monster", TUNING.TOTAL_DAY_TIME * 10)
    inst.components.spawner:SetOnlySpawnOffscreen(true)
	inst.components.spawner:SetOnVacateFn(function(inst,child)
		local pos = inst:GetPosition()
		local offset = FindWalkableOffset(pos, math.random(0,360), math.random(6,8), 8, true, true, NoHoles) or Vector3(0,0,0)
		child.Transform:SetPosition((pos+offset):Get())
	end)
end 

local function AddPigElites(inst)
	if not TheWorld.ismastersim then
		return inst
	end
	
	local names = {
		["pigelite1"] = "教宗沙利♂Van",
		["pigelite2"] = "奴隶骑士Gay♂尔",
		["pigelite3"] = "发狂暗灵弗Door♂林克",
		["pigelite4"] = "妖王Oh♂斯罗艾斯",
	}
	
	if inst.prefab == "pigelite1" then 
		
	elseif inst.prefab == "pigelite2" then 
	
	elseif inst.prefab == "pigelite3" then 
	
	elseif inst.prefab == "pigelite4" then 
	
	end
	
	if not inst.components.named then 
		inst:AddComponent("named")
	end
	inst:DoTaskInTime(0.1,function()
		inst.components.named:SetName(names[inst.prefab])
	end)
end 

local function SleepingWeaponAPI(inst)
	if not TheWorld.ismastersim then
        return inst
    end
	
	local old_sleepattack = inst.components.weapon.onattack
	local new_sleepattack = function(inst, attacker, target)
		old_sleepattack(inst, attacker, target)
		if attacker and attacker.components.iceysneaker and attacker.components.iceysneaker:CanTerminateTarget(target,true) then 
			if target.components.sleeper ~= nil then
				target.components.sleeper:AddSleepiness(10, 15, inst)
			elseif target.components.grogginess ~= nil then
				target.components.grogginess:AddGrogginess(2, 15)
			end
		end 
	end 
    inst.components.weapon:SetOnAttack(new_sleepattack)
end 

local function AddPlayerDarkSpirit(inst)
	if not TheWorld.ismastersim then
        return inst
    end
	
	inst:AddComponent("darkspirit")
end 

local function AddMetroWorldPlayer(inst)
	if not TheWorld.ismastersim then
        return inst
    end
	
	inst:AddComponent("metroworldplayer")
end 

AddPrefabPostInit("world", ly_worldfn)
AddPrefabPostInit("world",AddWorldBoss)
AddPrefabPostInit("world",AddClockTowerWorld)


AddPrefabPostInit("deerclops", deerclops_to_walker)
AddPrefabPostInit("krampus", krampus_to_san)
AddPrefabPostInit("shadowmeteor", AddCrystal)
AddPrefabPostInit("moonbase",AddMoonBase)
AddPrefabPostInitAny(AddClockWorksIron)
AddPrefabPostInitAny(AddWeaponRepairTag)
AddPrefabPostInit("multiplayer_portal",AddPortal)
AddPrefabPostInit("multiplayer_portal_moonrock_constr",AddPortal)
AddPrefabPostInit("multiplayer_portal_moonrock",AddPortal)

AddPrefabPostInit("pigelite1",AddPigElites)
AddPrefabPostInit("pigelite2",AddPigElites)
AddPrefabPostInit("pigelite3",AddPigElites)
AddPrefabPostInit("pigelite4",AddPigElites)

AddPrefabPostInit("blowdart_sleep",SleepingWeaponAPI)

AddPlayerPostInit(AddPlayerDarkSpirit)

AddClassPostConstruct("cameras/followcamera", function(self)

	local function CheckTarget(self)
		if not (self.target and self.target:IsValid()) or not self.targetpos then 
			--self.target = ThePlayer
			--self.targetpos = Vector3(ThePlayer.Transform:GetWorldPosition())
			self:SetTarget(ThePlayer) 
		end
	end 
	
	local old_Snap = self.Snap
	local old_Update = self.Update 
	
	self.Snap = function(self)
		CheckTarget(self)
		old_Snap(self)
	end
	
	self.Update = function(self,dt)
		CheckTarget(self)
		old_Update(self,dt)
	end 
	
end)

AddPrefabPostInit("player_classified", function(inst)
	local player = inst._parent 
	inst._camera_focus_target = net_entity(inst.GUID, "inst._camera_focus_target","camera_focus_targetdirty")
	inst._camera_controllable = net_bool(inst.GUID, "inst._camera_controllable","camera_controllable_dirty")
	inst._camera_heading = net_float(inst.GUID, "inst._camera_heading","camera_headingdirty")
	
	inst:ListenForEvent("camera_focus_targetdirty",function(inst)
		local new_target = inst._camera_focus_target:value()
		if new_target and new_target:IsValid() and player and  player.HUD then 
			TheCamera:SetTarget(new_target)
		end
	end)
	
	inst:ListenForEvent("camera_controllable_dirty",function(inst)
		if player and player.HUD then
			TheCamera:SetControllable(inst._camera_controllable:value())
		end 
	end)
	
	
	inst:ListenForEvent("camera_headingdirty",function(inst)
		if player and player.HUD then
			TheCamera:SetHeadingTarget(inst._camera_heading:value())
		end 
		--TheCamera:Snap()
	end)
	
	
	inst._camera_focus_target:set(player)
	inst._camera_controllable:set(true)
	inst._camera_heading:set(0)
end)

AddPlayerPostInit(function(inst)
	inst:DoPeriodicTask(1,function()
		local focustarget = FindEntity(inst,16,nil,{"CAMERAFOCUS"})
		if TheWorld.ismastersim then
			local classified_target = inst.player_classified._camera_focus_target:value()
			if focustarget and focustarget:IsValid() 
			and not (classified_target and classified_target:IsValid()
				and classified_target ~= focustarget and classified_target:HasTag("CAMERAFOCUS")) then 
				inst.player_classified._camera_focus_target:set(focustarget)
				inst.player_classified._camera_controllable:set(false)
				inst.player_classified._camera_heading:set(45)
				inst.player_classified._camera_heading:set_local(45)
			else
				inst.player_classified._camera_focus_target:set(ThePlayer)
				inst.player_classified._camera_controllable:set(true)
				inst.player_classified._camera_heading:set_local(0)
			end 
			--inst:PushEvent("camera_headingdirty")
		end 
		if inst.HUD ~= nil then 
			if focustarget and focustarget:IsValid() 
			and not (TheCamera.target and TheCamera.target:IsValid()
				and TheCamera.target ~= focustarget and TheCamera.target:HasTag("CAMERAFOCUS")) then 
				TheCamera:SetTarget(focustarget)
				TheCamera:SetControllable(false)
				TheCamera:SetHeadingTarget(45) 
			else
				TheCamera:SetTarget(ThePlayer)
				TheCamera:SetControllable(true)
			end 
		end 
	end) 
end)

GLOBAL.ACTIONS.CASTAOE.priority = -99-----------设置熔炉武器的优先级

AddComponentPostInit("playercontroller",function(self)
	local old_HasAOETargeting = self.HasAOETargeting
	self.HasAOETargeting = function(self)
		local target = TheInput:GetWorldEntityUnderMouse()
		local position = TheInput:GetWorldPosition()
		local rightaction = self.inst.components.playeractionpicker:GetRightClickActions(position,target)
		local senceactions = (target and target:IsValid())
			and self.inst.components.playeractionpicker:GetSceneActions(target,true)
		
		if (#rightaction == 0 or rightaction[1].action == ACTIONS.CASTAOE) then 
			if not senceactions or #senceactions == 0 or senceactions[1].action == ACTIONS.CASTAOE then 
				return old_HasAOETargeting(self) 
			end 
		end
		return false 
	end 

	
	--[[self.inst:DoPeriodicTask(1,function()
		local target = TheInput:GetWorldEntityUnderMouse()
		local position = TheInput:GetWorldPosition()
		local rma = self.inst.components.playeractionpicker:GetRightClickActions(position,target)
		local sence_actions = target and target:IsValid() and self.inst.components.playeractionpicker:GetSceneActions(target,true)
		
		local str_right = "当前右键动作:"
		local str_sence = "当前SENCE动作:"
		
		if rma and #rma > 0 then 
			for k,v in pairs(rma) do 
				str_right = str_right..tostring(v.action.str).." "
			end 
		end 
		
		if sence_actions and #sence_actions > 0 then 
			for k,v in pairs(sence_actions) do 
				str_sence = str_sence..tostring(v.action.str).." "
			end 
		end 
		
		self.inst.components.talker:Say(str_right.."\n"..str_sence)
	end)--]]

end)

AddComponentPostInit("playeractionpicker",function(self)
	--[[local old_rightclickoverride = self.rightclickoverride or function(player,target,position) return {},true end 
	
	self.rightclickoverride = function(player,target,position)
		--print("self.rightclickoverride!!!!!!")
		local equipitem = self.inst.replica.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
		if target and target:IsValid() and equipitem and equipitem:IsValid() then
            local equipactions = self:GetEquippedItemActions(target, equipitem, true)
			local senceactions = self:GetSceneActions(target,true)
			
            if equipitem.components.aoetargeting then
				if #senceactions > 0 and  senceactions[1].action.action ~= ACTIONS.CASTAOE then 
					return senceactions,false 
				end
            end
        end
		
		return old_rightclickoverride(player,target,position)
	end --]]
	
	local old_GetRightClickActions = self.GetRightClickActions 
	
	local function FixForAoe(inst, target, position)
		local equipitem = inst.replica.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
		if target and target:IsValid() and equipitem and equipitem:IsValid() then
			local old_rmb = old_GetRightClickActions(self,position, target)
            local equipactions = self:GetEquippedItemActions(target, equipitem, true)
			local senceactions = self:GetSceneActions(target,true)
			
            if equipitem.components.aoetargeting then
				local aoe_index = nil 
				for k,v in pairs(equipactions) do 
					if v.action.action == ACTIONS.CASTAOE and #equipactions > 1 then
						aoe_index = k
					end
				end
				
				if aoe_index then
					table.remove(equipactions,aoe_index) 
				end 
				
				for k,v in pairs(senceactions) do 
					table.insert(equipactions,v)
				end
				
				return equipactions,false 
            end
        end
		
		return {},true
	end 
	
	
	self.GetRightClickActions = function(self,position, target,...)
	
		if self.disable_right_click then
			return {}
		end

		local actions, usedefault = FixForAoe(self.inst, target, position)
		if not usedefault or (actions ~= nil and #actions > 0) then
			return actions or {}
		end
				
		return old_GetRightClickActions(self,position, target,...)
	end
	

end)

if TUNING.ICEY_DLCS == "Metro2033" then 
	FUELTYPE.GASMASK = "GASMASK"
	AddPrefabPostInit("world",AddMetroWorld)
	AddPlayerPostInit(AddMetroWorldPlayer)
	
	AddComponentPostInit("inventoryitem",function(self)
		self.radiation_absorb = 0 
		self.SetRadiationAbsorb = function(self,absorb)
			self.radiation_absorb = absorb
		end 
	end) 
	
	AddComponentPostInit("inventory",function(self)
		self.CaclRadiationAbsorb = function(self)
			local all_absorb = 0
			for k,v in pairs(self.equipslots) do 
				if v and v:IsValid() and v.components.inventoryitem then 
					all_absorb = all_absorb + v.components.inventoryitem.radiation_absorb
				end
			end 
			
			all_absorb = math.max(0,all_absorb)
			all_absorb = math.min(0.95,all_absorb)
			
			return all_absorb
		end 
	end) 
end 

if TUNING.ICEY_DAMAGE_NUMBERS == "on" then 
	AddPrefabPostInitAny(AddDamageNumber)
end 

local extrafoods = {
	snakebonesoup = {
		test = function(cooker, names, tags) 
			return tags.bone and tags.bone >= 2 and tags.meat and tags.meat >= 2 
		end,
		name = "snakebonesoup",
		priority = 20,
		foodtype = "MEAT",
		weight = 1;
		health = TUNING.HEALING_LARGE,
		hunger = TUNING.CALORIES_MED,
		perishtime = TUNING.PERISH_MED,
		sanity = TUNING.SANITY_SMALL,
		cooktime = 1,
	},
}

for k,v in pairs(extrafoods) do
	v.name = k
	v.weight = v.weight or 1
	v.priority = v.priority or 0
end

for k,recipe in pairs(extrafoods) do 
	AddCookerRecipe("cookpot",recipe)
end 

--[[local icey_preparedfoods = require("preparedfoods_icey")
for k,recipe in pairs(icey_preparedfoods) do 
	AddCookerRecipe("icey_cookpot",recipe)
end--]]

AddIngredientValues({"snake_bone"}, {bone=1}, true)


AddPrefabPostInit("world", function(inst)
	local function GetTile(pos)
		local map = TheWorld.Map
		local ptx, pty, ptz = pos:Get()
		local tilecenter_x, tilecenter_y, tilecenter_z  = map:GetTileCenterPoint(ptx, 0, ptz)
		local tx, ty = map:GetTileCoordsAtPoint(ptx, 0, ptz)
		local actual_tile = map:GetTile(tx, ty)

		if actual_tile ~= nil and tilecenter_x ~= nil and tilecenter_z ~= nil then
			if actual_tile >= GROUND.UNDERGROUND then
				local xpercent = (tilecenter_x - ptx) / TILE_SCALE + .25
				local ypercent = (tilecenter_z - ptz) / TILE_SCALE + .25

				local x_min = xpercent > .666 and -1 or 0
				local x_max = xpercent < .333 and 1 or 0
				local y_min = ypercent > .666 and -1 or 0
				local y_max = ypercent < .333 and 1 or 0

				local x_off = 0
				local y_off = 0

				for x = x_min, x_max do
					for y = y_min, y_max do
						local tile = map:GetTile(tx + x, ty + y)
						if tile > actual_tile then
							actual_tile = tile
							x_off = x
							y_off = y
						end
					end
				end
			end

			return actual_tile, GetTileInfo(actual_tile)
		end
	end 
	inst.CalcPoint = function(self)
		local num = 0
		local all_num = #TheWorld.topology.nodes
		for i, v in ipairs(TheWorld.topology.nodes) do
			local tile = GetTile(Vector3(v.x,0,v.y))
			if tile == GROUND.PEBBLEBEACH or tile == GROUND.METEOR then
				num = num + 1
			end
		end 
		print("拓扑节点计算:","num / all_num = ",num,"/",all_num)
	end 
	inst:DoTaskInTime(1,inst.CalcPoint)
end) 

--[[AddPlayerPostInit(function(inst)
	inst.CalcPoint = function(self)
		local num = 0
		local all_num = #TheWorld.topology.nodes
		for i, v in ipairs(TheWorld.topology.nodes) do
			ThePlayer.Transform:SetPosition(v.x,0,v.y)
			local tile = ThePlayer:GetCurrentTileType()
			if tile == GROUND.PEBBLEBEACH or tile == GROUND.METEOR then
				num = num + 1
			end
		end 
		print("拓扑节点计算:","num / all_num = ",num,"/",all_num)
	end 
end) --]]
local EnemyShower = require("widgets/enemy_shower")
AddClassPostConstruct("widgets/controls", function(self)
	self.EnemyShower = self:AddChild(EnemyShower(self.owner))
end)