local Widget = require "widgets/widget" 
local Text = require "widgets/text" --Text类，文本处理
local TextButton = require "widgets/textbutton"
local Image = require "widgets/image"
local ImageButton = require "widgets/imagebutton"
local Menu = require "widgets/menu"
local NineSlice = require "widgets/nineslice"


local BUTTON_START_X = -600 
local BUTTON_START_Y = 250
local BUTTON_DISTS = 60
local BUTTON_TEXTSIZE = 50

local HELP_START_X = -0
local HELP_START_Y = 100
local HELP_START_DELTA = 45 

local configs = {
	{name = "icey_miss",str = "闪避"},
	{name = "icey_kill",str = "必杀技"},
	{name = "icey_parry",str = "格挡"},
	{name = "icey_podshoot",str = "辅助机射击"},
	{name = "icey_sneak",str = "潜行"},
}

--local modname = ModIndex:GetModActualName("艾希,I see ! ")
local function GetKeyFromConfigString(config,modname)
	--return tostring(configs[config].." : "..GetModConfigData(config))
	local p = 0
	for k,v in pairs(configs) do 
		if v.name == config then 
			p = k 
		end
	end 
	if p <= 0 then 
		return "" 
	end
	
	local key_str = TUNING[string.upper(config).."_KEY_STRING"] or ""
	if key_str and string.find(key_str,"KEY_") then 
		local finds = string.find(key_str,"KEY_")
		key_str = string.sub(key_str,finds + 4)
	end
	return tostring(configs[p].str.." : "..key_str) 
end

local IceyKeyCheckUI = Class(Widget, function(self, owner)
	Widget._ctor(self, "IceyKeyCheckUI") 
    self.owner = owner
	
	self.mainmenu = self:AddChild(Image("images/icey_keycheck_ui.xml", "icey_keycheck_ui.tex"))
	self.mainmenu:SetPosition(0,0)
	self.mainmenu:SetHAnchor(0) -- 设置原点x坐标位置，0、1、2分别对应屏幕中、左、右
	self.mainmenu:SetVAnchor(0) -- 设置原点y坐标位置，0、1、2分别对应屏幕中、上、下
	self.mainmenu:SetScale(1,1.25,1)
	self.mainmenu:Hide()
	
	
	self.urlbutton = self.mainmenu:AddChild(ImageButton("images/global_redux.xml", "button_carny_long_normal.tex", "button_carny_long_hover.tex", "button_carny_long_disabled.tex", "button_carny_long_down.tex"))
	self.urlbutton:SetText("攻略贴")
	self.urlbutton:SetHAnchor(2)
	self.urlbutton:SetVAnchor(2)
	self.urlbutton:SetPosition(-450,240,0)--设置坐标
	self.urlbutton:SetScale(0.7,0.7)--设置大小
	self.urlbutton.image:SetScale(0.8,0.8)
	self.urlbutton:SetFont(HEADERFONT)
	self.urlbutton:SetOnClick(function()
		VisitURL("https://tieba.baidu.com/p/5902993586?red_tag=1405728916",false)
		--VisitURL(resolvefilepath("test.html"),false)
	end)
	
	local count = 0 
	for k,v in pairs(configs) do 
		self[v.name] = self.mainmenu:AddChild(Text(NUMBERFONT,45,GetKeyFromConfigString(v.name)))
		self[v.name]:SetHAnchor(0) -- 设置原点x坐标位置，0、1、2分别对应屏幕中、左、右
		self[v.name]:SetVAnchor(0) -- 设置原点y坐标位置，0、1、2分别对应屏幕中、上、下
		self[v.name]:SetPosition(HELP_START_X,HELP_START_Y - HELP_START_DELTA * count)
		count = count + 1 
	end 
		
	self.callonbutton = self:AddChild(TextButton())
	self.callonbutton:SetText("帮助")
	self.callonbutton:SetColour(0/255,131/255,255/255,1)
	self.callonbutton:SetHAnchor(1) -- 设置原点x坐标位置，0、1、2分别对应屏幕中、左、右
	self.callonbutton:SetVAnchor(2) -- 设置原点y坐标位置，0、1、2分别对应屏幕中、上、下
    self.callonbutton:SetPosition(100,20) -- 设置ancientmac widget相对原点的偏移量，70，-50表明向右70，向下50，第三个参数无意义。
	self.callonbutton:SetOnClick(function()
		if self.mainmenu.shown then 
			self.mainmenu:Hide()
		else
			self.mainmenu:Show()
		end 
	end)
	
end)

return IceyKeyCheckUI