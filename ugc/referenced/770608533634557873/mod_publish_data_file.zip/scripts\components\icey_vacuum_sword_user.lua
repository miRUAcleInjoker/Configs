--icey_vacuum_sword_user
local IceyUtil = require("icey_util")
local IceyVacuumSwordUser = Class(function(self, inst)
	self.inst = inst 
	self.onattack = nil 
	self.last_atk_time = 0
	self.cooldown_time = 0.1
	
	self.colour_flash_set = 0.7
	self.colour_flash = self.colour_flash_set
end)

function IceyVacuumSwordUser:CanDoAttack()
	local weapon = self.inst.components.combat:GetWeapon()
	return weapon and weapon:HasTag("vacuum_sword") and GetTime() - self.last_atk_time >= self.cooldown_time
end 

function IceyVacuumSwordUser:SetOnAttack(fn)
	self.onattack = fn 
end 

function IceyVacuumSwordUser:PushColour(delta)
	local falsh = self.colour_flash
	local inst = self.inst 
	delta = delta or 0 
	inst.components.bloomer:PushBloom("vacuum_sword", "shaders/anim.ksh", -2)
    inst.components.colouradder:PushColour("vacuum_sword", 0,falsh,falsh,0)
	
	self.colour_flash = self.colour_flash + delta
	if self.colour_flash <= 0 then 
		self.colour_flash = 0
	end
	if self.colour_flash >= self.colour_flash_set then 
		self.colour_flash = self.colour_flash_set
	end
end 

function IceyVacuumSwordUser:PopColour()
	--self.colour_flash = 0.6 
	local inst = self.inst 
	inst.components.bloomer:PopBloom("vacuum_sword")
	inst.components.colouradder:PopColour("vacuum_sword")
end 

function IceyVacuumSwordUser:OnUpdate(dt)
	self:PushColour(-0.075)
	if self.colour_flash <= 0 then 
		self.colour_flash = self.colour_flash_set
		self.inst:StopUpdatingComponent(self)
	end
end 

function IceyVacuumSwordUser:SpawnFx(target_pos)
	local inst = self.inst
	target_pos = target_pos or (inst.components.combat.target and inst.components.combat.target:GetPosition()) or nil 
	if not target_pos then 
		return 
	end 
	inst:FacePoint(target_pos)
	SpawnAt("vacuum_sword_fx",inst).Transform:SetRotation(inst.Transform:GetRotation())
end 

function IceyVacuumSwordUser:DoAttack(target_pos)
	local inst = self.inst
	
	target_pos = target_pos or (inst.components.combat.target and inst.components.combat.target:GetPosition()) or nil 
	if not target_pos or not self:CanDoAttack() then 
		return 
	end 
	
	
	local mypos = inst:GetPosition()
	local vec = target_pos - mypos
	local vec_normalize = vec:GetNormalized()
	
	
	--fx.Transform:SetPosition(1.5,0,0)
	
	local function SpawnSparks(inst,data)
		SpawnPrefab("icey_weaponsparks"):SetPosition(inst,data.target)
	end 
	inst:ListenForEvent("onhitother",SpawnSparks)

	local ents = TheSim:FindEntities(target_pos.x,target_pos.y,target_pos.z,2.2,{"_combat"})
	for k,v in pairs(ents) do 
		if IceyUtil.CanAttack(v,inst) then 
			local damage = inst.components.combat:CalcDamage(v, inst.components.combat:GetWeapon(),0.7)
			v.components.combat:GetAttacked(inst,damage)
		end
	end 
	
	local function RotateFX(fx)
		fx.Transform:SetPosition((target_pos+Vector3(0,1,0)):Get())
		fx.Transform:SetRotation(inst.Transform:GetRotation())
		fx.Transform:SetScale(2,2,2)
	end

	RotateFX(SpawnPrefab("vacuum_sword_slash_fx"..math.random(1,2)))
	
	if self.onattack then 
		self.onattack(inst,target_pos) 
	end
	
	inst:RemoveEventCallback("onhitother",SpawnSparks)
	
	self.inst:StopUpdatingComponent(self)
	self.colour_flash = self.colour_flash_set
	self.inst:StartUpdatingComponent(self)
end

return IceyVacuumSwordUser