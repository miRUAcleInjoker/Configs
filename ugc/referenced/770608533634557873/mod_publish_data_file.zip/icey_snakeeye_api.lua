local IceyUtil = require("icey_util")

local UIAnim = require "widgets/uianim"
local TargetIndicator = require "widgets/targetindicator"

local SNAKEEYE_DIST_TOO_FAR = 70


local function IsValidTarget(owner,v)
	return (
		v and v:IsValid() 
		and owner:IsNear(v,SNAKEEYE_DIST_TOO_FAR) 
		--and (v.replica.health == nil or not v.replica.health:IsDead())
		and not v.entity:FrustumCheck()
	)
end 

local function FindSnakeEyeTargets(inst)
	local pos = inst:GetPosition()		
	return TheSim:FindEntities(pos.x,pos.y,pos.z,SNAKEEYE_DIST_TOO_FAR,
	{},
	{"pugalisk_body","pugalisk_tail","FX","INLIMBO","judas"},
	{"epic","chester_eyebone","tadalin_tower","walrus","warg","walrus_camp"})
	--
end 

local function AddSnakeEyeIndicator(self,target,data)
	if not self.snakeeye_targetindicators then
        self.snakeeye_targetindicators = {}
    end

    local ti = self.under_root:AddChild(TargetIndicator(self.owner, target, data))
    table.insert(self.snakeeye_targetindicators, ti)
end 

local function HasSnakeEyeIndicator(self,target)
	if not self.snakeeye_targetindicators then return end

    for i,v in pairs(self.snakeeye_targetindicators) do
        if v and v:GetTarget() == target then
            return true
        end
    end
    return false
end 

local function RemoveSnakeEyeIndicator(self,target)
	if not self.snakeeye_targetindicators then return end

    local index = nil
    for i,v in pairs(self.snakeeye_targetindicators) do
        if v and v:GetTarget() == target then
            index = i
            break
        end
    end
    if index then
        local ti = table.remove(self.snakeeye_targetindicators, index)
        if ti then ti:Kill() end
    end
end 

local function EnableSnakeEye(self,enable)
	local owner = self.owner
	if not owner then 
		return 
	end 
	
	if self.SnakeEyeTask then
		self.SnakeEyeTask:Cancel()
	end
	self.SnakeEyeTask = nil 
	
	local entity_targets = {}
		
	for k,v in pairs(self.snakeeye_targetindicators) do 
		table.insert(entity_targets,v:GetTarget())
	end
	
	for k,v in pairs(entity_targets) do 
		self:RemoveSnakeEyeIndicator(v)
	end 
	
	--[[for i, v in ipairs(self.snakeeye_targetindicators) do
		while true do
			self:RemoveSnakeEyeIndicator(v)
			v = self.snakeeye_targetindicators[i]
			if v == nil then
				break
			end
		end
	end--]]
		
	self.snakeeye_targetindicators = {} 
	
	
	if enable then 
		self.SnakeEyeTask = owner:DoPeriodicTask(0,function()
			
			
			local now_entity_targets = {}
		
			for k,v in pairs(self.snakeeye_targetindicators) do 
				table.insert(now_entity_targets,v:GetTarget())
			end
			
			for k,v in pairs(now_entity_targets) do 
				if not IsValidTarget(owner,v) then
					self:RemoveSnakeEyeIndicator(v)
				end 
			end 
			
			--[[for i, v in ipairs(self.snakeeye_targetindicators) do
				while not IsValidTarget(owner,v:GetTarget()) do
					self:RemoveSnakeEyeIndicator(v)
					v = self.snakeeye_targetindicators[i]
					if v == nil then
						break
					end
				end
			end--]]
			
			local ents = FindSnakeEyeTargets(owner)
			for k,v in pairs(ents) do 
				if IsValidTarget(owner,v) and not self:HasSnakeEyeIndicator(v) then 
					self:AddSnakeEyeIndicator(v,{should_imitate_target = true})
					--print("Add snake eye target",v)
				end
			end
			
			--[[local invalid_index = nil 
			for k,v in pairs(self.snakeeye_targetindicators) do 
				if not IsValidTarget(owner,v) then 
					invalid_index = k
				end
			end
			
			if invalid_index then 
				--print("Remove snake eye target",self.snakeeye_targetindicators[invalid_index])
				self:RemoveTargetIndicator(self.snakeeye_targetindicators[invalid_index])
				table.remove(self.snakeeye_targetindicators, invalid_index)
			end --]]
			
		end)		
	end
end 
--ThePlayer.HUD:EnableSnakeEye(true)
--ThePlayer.HUD:EnableSnakeEye(false)
--ThePlayer.entity:GetDebugString()
AddClassPostConstruct("screens/playerhud", function(self)
	self.SnakeEyeTask = nil 
	self.snakeeye_target = {} 
	self.snakeeye_targetindicators = {}	
	self.EnableSnakeEye = EnableSnakeEye
	self.AddSnakeEyeIndicator = AddSnakeEyeIndicator
	self.HasSnakeEyeIndicator = HasSnakeEyeIndicator
	self.RemoveSnakeEyeIndicator = RemoveSnakeEyeIndicator
end)


local anim_override = {
	walrus = {
		bank = "walrus",
	},
	little_walrus = {
		bank = "walrus",
	},
	walrus_camp = {
		--bank = "walrus_house",
		extrafn = function(self,unpack_data)
			if unpack_data then 
				local anim = self:GetAnimState()
				if unpack_data.build == "walrus_house" then 
					anim:SetBank("walrus_house")
					anim:SetBuild("walrus_house")
					--anim:SetOrientation(ANIM_ORIENTATION.Default)
					--anim:SetLayer(LAYER_WORLD)
					--anim:SetSortOrder(0)
				elseif unpack_data.build == "igloo_track" then 
					anim:SetBank("igloo_track")
					anim:SetBuild("igloo_track")
					--anim:SetOrientation(ANIM_ORIENTATION.OnGround)
					--anim:SetLayer(LAYER_BACKGROUND)
					--anim:SetSortOrder(3)
				end
			end 
		end 
	},
	
	
	warg = {
		bank = "warg",
	},
	beequeen = {
		bank = "bee_queen",
	},
	claywarg = {
		bank = "claywarg",
	},
	chester_eyebone = {
		bank = "eyebone",
		scale = 0.45,
	},
	moose = {
		bank = "goosemoose",
	},
	spiderqueen = {
		bank = "spider_queen",
	},
	dragonfly = {
		bank = "dragonfly",
	},

	spider_monkey = {
		bank = "spiderape",
	},
	spider_higher = {
		bank = "spider_queen",
	},
	pugalisk = {
		bank = "giant_snake",
	},
	
	
	icey_sans = {
		bank = "wilson",
		scale = 0.45,
	},
	
	
	
	shadow_mixtrues = {
		bank = "shadow_rook",
		extrafn = function(self)
			local suffix = 2
			local anim = self:GetAnimState()
            anim:OverrideSymbol("base",           "shadow_rook_upg_build", "base"..suffix)
            anim:OverrideSymbol("big_horn",       "shadow_rook_upg_build", "big_horn"..suffix)
            anim:OverrideSymbol("bottom_head",    "shadow_rook_upg_build", "bottom_head"..suffix)
            anim:OverrideSymbol("small_horn_lft", "shadow_rook_upg_build", "small_horn_lft"..suffix)
            anim:OverrideSymbol("small_horn_rgt", "shadow_rook_upg_build", "small_horn_rgt"..suffix)
            anim:OverrideSymbol("top_head",       "shadow_rook_upg_build", "top_head"..suffix)
		end,
	},
	
	moon_giaour = {
		bank = "wilson",
		scale = 0.45,
	},
	
	metal_hulk_merge = {
		bank = "metal_hulk",
	},
	icey_boarrior = {
		bank = "boarrior",
		extrafn = function(self,unpack_data)
			local anim = self:GetAnimState()
			local build = unpack_data.build
			
			if build and build == "lavaarena_boarrior_alt2" then
				anim:AddOverrideBuild("icey_boarrior_weaponswap_fire") 
			else
				anim:AddOverrideBuild("icey_boarrior_weaponswap") 
			end
		end,
	},
	dark_antqueen = {
		bank = "crick_crickantqueen",
		extrafn = function(self)
			local DarkAntqueenOverrideSymbols = {
				"crick_antenna",
				"crick_arm",
				"crick_egg",
				"crick_headbase",
				"crick_mouth",
			}
			local anim = self:GetAnimState()
			for k,v in pairs(DarkAntqueenOverrideSymbols) do 
				anim:OverrideSymbol(v, "dark_antqueen_part",v)
			end 
			anim:HideSymbol("crick_eye1")
			anim:HideSymbol("crick_eye2")
			anim:HideSymbol("crick_cres")
			anim:OverrideSymbol("crick_crown", "hat_skeleton","swap_hat")
			anim:OverrideSymbol("crick_headbase", "dark_antqueen_part4","crick_headbase")
			anim:OverrideSymbol("crick_torso", "dark_antqueen_part5","crick_torso")
		end,
	},
	tigershark_duke = {
		bank = "tigershark",
	},
	
	--Leigon elecarmet
	elecarmet = {
		extrafn = function(self)

			local anim = self:GetAnimState()
			anim:OverrideSymbol("arm", "elecarmet_normal1", "arm")
			anim:OverrideSymbol("chest", "elecarmet_normal1", "chest")

			anim:OverrideSymbol("eyes", "elecarmet_normal2", "eyes")
			anim:OverrideSymbol("rock2", "elecarmet_normal2", "rock2")
			anim:OverrideSymbol("shoulder", "elecarmet_normal2", "shoulder")
			anim:OverrideSymbol("swap_weapon", "elecarmet_normal2", "swap_weapon")

			anim:OverrideSymbol("hand", "elecarmet_normal3", "hand")
			anim:OverrideSymbol("head", "elecarmet_normal3", "head")
			anim:OverrideSymbol("mouth", "elecarmet_normal3", "mouth")
			anim:OverrideSymbol("nose", "elecarmet_normal3", "nose")
			anim:OverrideSymbol("pelvis", "elecarmet_normal3", "pelvis")
			anim:OverrideSymbol("rock", "elecarmet_normal3", "rock")
			anim:OverrideSymbol("swap_weapon_spin", "elecarmet_normal3", "swap_weapon_spin")
		end,
	}
}



AddClassPostConstruct("widgets/targetindicator", function(self, owner, target, data,...)
	self.TargetAnim = self.icon:AddChild(UIAnim())
	self.TargetAnim:Hide() 
	
--[[	self.ImitateTargetAnim = function(self,enable)
		self.enable_imitate_target = enable 
		if enable then 
			self.TargetAnim:Show()
			self.headbg:Hide()
			self.head:Hide()
		else
			self.TargetAnim:Hide()
			self.headbg:Show()
			self.head:Show()
		end 
	end
	
	self.owner:DoTaskInTime(0,function()
		if self.config_data and self.config_data.should_imitate_target then 
			self:ImitateTargetAnim(true)
		end
	end)--]]
	
	local old_OnUpdate = self.OnUpdate
	self.OnUpdate = function(self,...)
		
		local target = self.target
		
		if not (target and target:IsValid()) then 
			return 
		end 
		
		old_OnUpdate(self,...)
		if target and self.config_data.should_imitate_target then 
			local unpack_data = IceyUtil.UnpackDebugString(target)
			local currentface = target.AnimState and target.AnimState:GetCurrentFacing() 
			if not unpack_data then 
				return 
			end 
			
			local bank,build,anim = unpack_data.bank,unpack_data.build,unpack_data.anim
			local percent = target.AnimState:GetCurrentAnimationTime() / target.AnimState:GetCurrentAnimationLength()
			local s1,s2,s3 = target.Transform:GetScale()
			local myscale = 0.075
			
			if anim_override[target.prefab] then 
				bank,build,anim = anim_override[target.prefab].bank or bank,anim_override[target.prefab].build or build,anim_override[target.prefab].anim or anim
				myscale = anim_override[target.prefab].scale or myscale
			end 
			
			self.TargetAnim:GetAnimState():SetBank(bank)
			self.TargetAnim:GetAnimState():SetBuild(build)
			self.TargetAnim:GetAnimState():SetPercent(anim,percent)
			
			if currentface then 
				self.TargetAnim:SetFacing(currentface)
			end 
			
			if anim_override[target.prefab] and anim_override[target.prefab].extrafn then 
				anim_override[target.prefab].extrafn(self.TargetAnim,unpack_data)
			end
			
			self.TargetAnim:MoveToFront()
			self.TargetAnim:Show()
			self.TargetAnim:SetScale(s1*myscale,s2*myscale,s3*myscale)
			self.headbg:Hide()
			self.head:Hide()
			self.headframe:Hide()
			--print(target,bank,build,anim)
		end 
	end 
end)

AddPrefabPostInit("walrus_camp",function(inst)
	inst:AddTag("walrus_camp")
end)