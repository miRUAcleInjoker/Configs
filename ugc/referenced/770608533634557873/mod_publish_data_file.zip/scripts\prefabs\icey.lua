
local MakePlayerCharacter = require "prefabs/player_common"
local IceyUtil = require("icey_util")

local assets = {

		
        Asset( "ANIM", "anim/player_basic.zip" ),
        Asset( "ANIM", "anim/player_idles_shiver.zip" ),
        Asset( "ANIM", "anim/player_actions.zip" ),
        Asset( "ANIM", "anim/player_actions_axe.zip" ),
        Asset( "ANIM", "anim/player_actions_pickaxe.zip" ),
        Asset( "ANIM", "anim/player_actions_shovel.zip" ),
        Asset( "ANIM", "anim/player_actions_blowdart.zip" ),
        Asset( "ANIM", "anim/player_actions_eat.zip" ),
        Asset( "ANIM", "anim/player_actions_item.zip" ),
        Asset( "ANIM", "anim/player_actions_uniqueitem.zip" ),
        Asset( "ANIM", "anim/player_actions_bugnet.zip" ),
        Asset( "ANIM", "anim/player_actions_fishing.zip" ),
        Asset( "ANIM", "anim/player_actions_boomerang.zip" ),
        Asset( "ANIM", "anim/player_bush_hat.zip" ),
        Asset( "ANIM", "anim/player_attacks.zip" ),
        Asset( "ANIM", "anim/player_idles.zip" ),
        Asset( "ANIM", "anim/player_rebirth.zip" ),
        Asset( "ANIM", "anim/player_jump.zip" ),
        Asset( "ANIM", "anim/player_amulet_resurrect.zip" ),
        Asset( "ANIM", "anim/player_teleport.zip" ),
        Asset( "ANIM", "anim/wilson_fx.zip" ),
        Asset( "ANIM", "anim/player_one_man_band.zip" ),
        Asset( "ANIM", "anim/shadow_hands.zip" ),
        Asset( "SOUND", "sound/sfx.fsb" ),
        Asset( "SOUND", "sound/wilson.fsb" ),
        Asset( "ANIM", "anim/beard.zip" ),

        Asset( "ANIM", "anim/icey.zip" ),
		Asset( "ANIM", "anim/icey_injured.zip" ),
		
        Asset( "ANIM", "anim/ghost_icey_build.zip" ),
		
		--Asset( "ANIM", "anim/change.zip" ),-----嫦娥贴图测试
		
		Asset( "ANIM", "anim/player_transform_merm.zip" ),
		Asset("ANIM", "anim/player_actions_speargun.zip"),
		Asset("ANIM", "anim/player_mount_actions_speargun.zip"),
		
		--Asset("ANIM", "anim/icey_shield_armored.zip"),
		--Asset("ANIM", "anim/zg_player_attacks.zip"),
		--Asset("ANIM", "anim/zg_player_idles.zip"),
		--Asset("ANIM", "anim/zg_player_runs.zip"),
		
		Asset( "ANIM", "anim/iceyatk_circle.zip" ),
		--Asset( "ANIM", "anim/anim001.zip" ),
		
}

local assets_fx = {
  Asset("ANIM", "anim/lavaarena_staff_smoke_fx.zip"),
}


local prefabs = {
	"icey_blade",
	--"icey_fucker",
}

-- Custom starting items
local start_inv = {
	"icey_blade",
	--"icey_fucker",
}

local icey_skills_list = {

	"iron_body",
	"foot_star",
	"sky_death",
	"steady",
	
	"quick_shield",
	"dangerous",
	"blood_steal",
	"shinobi_execution",
	
	"all_shield",
	"charge",
	"shield_attack",
	"battle_focus",
	
	"sacrifice",
	"hyperion",
	"death_slaughter",
	"soul_torrent",
	
	"great_coupling",
	"liangzi_run",
	"shield_crush",
	"newton_grave",
	
	"wudao_sanity",
	"electricity_shadow",
	"nucler_weapon",
	"battleground_eating",
	
	"king_card",
	"mult_shadow",
	"hit_ground",
	"iron_hitter",--
	
	"red_reboot",
	"go_hide",
	"shut_down",
	"death_machinegun",
	
	"fire_keeper",
	"snow_dancer",
	"starve_walker",
	"harvell_coser",
	
	"exectuer",
	"dark_charge",
	"rude_storm",
	"witch_time",
}

local icey_save_lists = {

	--"icey_level",
	--"icey_exp",
	--"icey_levelup_exp",
	
	--[["iron_body",
	"foot_star",
	"sky_death",
	
	"quick_shield",
	"dangerous",
	"blood_steal",
	
	"all_shield",
	"charge",
	"shield_attack",
	
	"sacrifice",
	"hyperion",
	"death_slaughter",
	
	"great_coupling",
	"liangzi_run",
	"shield_crush",
	
	"wudao_sanity",
	"electricity_shadow",
	"nucler_weapon",
	
	"king_card",
	"mult_shadow",
	"hit_ground",
	
	"red_reboot",
	"go_hide",
	"shut_down",
	
	"fire_keeper",
	"snow_dancer",
	"starve_walker",
	
	"exectuer",
	"dark_charge",
	"rude_storm",--]]
}

for k,v in pairs(icey_skills_list) do 
	table.insert(icey_save_lists,v)
end 

local function InitAllSkill(inst)
	for k,v in pairs(icey_skills_list) do 
		inst[v] = 0
		inst["_"..v] = net_shortint(inst.GUID,"_"..v,"icey_guid_event")
	end
end 

local function UpdateAllSkillDirty(inst)
	for k,v in pairs(icey_skills_list) do 
		--inst["_"..v]:set(inst[v])
		inst[v] = inst["_"..v]:value() 
	end
end 



local max_level = 10
local bar_scale = 0.4

local function canattack(v,inst) ------------多重保险：判定目标是否真的可以被攻击，可以被伤害
	return IceyUtil.CanAttack(v,inst)
end  

local function keepTwoDecimalPlaces(decimal)-----------------------四舍五入保留两位小数的代码
    decimal = math.floor((decimal * 100)+0.5)*0.01       
    return  decimal 
end

local function setcd(inst,cdname,time,skillname,cansay,istimer)
	if inst.sg:HasStateTag("nointerrupt") or inst.sg:HasStateTag("knockout") or inst.sg:HasStateTag("sleeping") 
	or inst.sg.currentstate == "death"
	 then 
		return false
	end 
	if GetTime() - inst[cdname] < time then 
		if inst.components.talker and cansay then 
			local last = time - (GetTime() - inst[cdname])
			last = keepTwoDecimalPlaces(last)
			inst.components.talker:Say(skillname.."技能还需要"..last.."秒才能使用")
		end
		--print(skillname.."释放失败!")
		return false
	end 
	inst[cdname] = GetTime()
	if inst["_"..cdname] ~= nil then 
		inst["_"..cdname]:set(inst[cdname])
	end
--[[	if istimer and inst.components.timer then 
		inst.components.timer:StartTimer(cdname,time)
	end--]]
	--print(skillname.."释放成功!")
	return true
end 


local HSound = {
	smalldamage = {
		"n00",
		"o00",
		"o01",
		"o02",
		"a00",
		"a01",
		"a02",
		"a03",
		"guhu",
		"hi00",
		"hi01",
		"ugu00",
		"uhi00",
	},
	middledamage = {
		"ahi00",
		"ahi01",
		"ahi02",
		"ahi03",
		"ahi04",
		"ahi05",
		"ahi06",
		"ahi07",
		"ahi08",
		"ahi09",
		"ihi00",
		"ihi01",
		"ohi00",
		"ohi01",
	},
	hugedamage = {
		"gaha00",
		"gaha01",
		"agu00",
		"ha00",
		"ha01",
		"ha02",
		"ha03",
		"ha04",
		"u00",
		"u01",
		"u02",
		"u03",
		"u04",
		"u05",
	},
	veryhugedamage = {
		"ah00",
		"ah01",
		"ah02",
		"kya00",
		"kya01",
		"ua00",
		"ua01",
	},
	death = {
		"gya00",
		"gya01",
		"gya02",
		"gya03",
		"gya04",
	},
	
	--[["mugu00",
	"mugu01",
	"mugu02",
	"mugu03",
	"mugu04",
	"mugu06",
	"mugu07",
	"mugu08",
	"mugu09",
	"mugu10",
	"muse00",
	"muse01",
	"muse02",--]]
	
	--[["oe01",
	"oe02",
	"oe03",
	"oe04",
	"oe05",
	"oe06",--]]
}

local function PlayHDamageSound(inst,damage,soundname,type)
	if inst.icey_soundname == "NULL" then 
		return 
	end 
	soundname = soundname or inst.icey_soundname or  "ryoko"
	
	if not type then 
		if damage <= 20 then 
			type = "smalldamage"
		elseif damage <= 45 then 
			type = "middledamage"
		elseif damage <= 75 then 
			type = "hugedamage"
		else
			type = "veryhugedamage"
		end
	end 
	local list = HSound[type]
	local filename = list[math.random(1,#list)]
	local path = "cc_voice/cc_voice/"..soundname.."/"..filename
	inst.SoundEmitter:PlaySound(path)
	--inst.components.talker:Say("HSoundPlaying  CV:"..soundname.."---"..type.."---"..filename)
	--print("HSoundPlaying  CV:"..soundname.."---"..type.."---"..filename)
end 


--------------------------------------------------------------------
local function UpdateRepel(inst, x, z, creatures,rad)
    for i = #creatures, 1, -1 do
        local v = creatures[i]
        if not (v.inst:IsValid() and v.inst.entity:IsVisible()) then
            table.remove(creatures, i)
        elseif v.speed == nil then
            local distsq = v.inst:GetDistanceSqToPoint(x, 0, z)
            if distsq < rad * rad then
                if distsq > 0 then
                    v.inst:ForceFacePoint(x, 0, z)
                end
                local k = .5 * distsq / (rad * rad) - 1
                v.speed = 25 * k
                v.dspeed = 2
				if v.inst.Physics then 
					v.inst.Physics:SetMotorVelOverride(v.speed, 0, 0)
				end 
            end
        else
            v.speed = v.speed + v.dspeed
            if v.speed < 0 then
                local x1, y1, z1 = v.inst.Transform:GetWorldPosition()
                if x1 ~= x or z1 ~= z then
                    v.inst:ForceFacePoint(x, 0, z)
                end
                v.dspeed = v.dspeed + .25
				if v.inst.Physics then 
					v.inst.Physics:SetMotorVelOverride(v.speed, 0, 0)
				end 
            else
				if v.inst.Physics then 
					v.inst.Physics:ClearMotorVelOverride()
					v.inst.Physics:Stop()
				end 
                table.remove(creatures, i)
            end
        end
    end
end

local function TimeoutRepel(inst, creatures, task)
    task:Cancel()

    for i, v in ipairs(creatures) do
        if v.speed ~= nil and v.inst.Physics ~= nil then
            v.inst.Physics:ClearMotorVelOverride()
            v.inst.Physics:Stop()
        end
    end
end
--------------------------------------------------------------------

local function ToggleOffPhysics(inst)
    inst.isphysicstoggle = true
    inst.Physics:ClearCollisionMask()
    inst.Physics:CollidesWith(COLLISION.GROUND)
end

local function ToggleOnPhysics(inst)
    inst.isphysicstoggle = nil
    inst.Physics:ClearCollisionMask()
    inst.Physics:CollidesWith(COLLISION.WORLD)
    inst.Physics:CollidesWith(COLLISION.OBSTACLES)
    inst.Physics:CollidesWith(COLLISION.SMALLOBSTACLES)
    inst.Physics:CollidesWith(COLLISION.CHARACTERS)
    inst.Physics:CollidesWith(COLLISION.GIANTS)
end

--------------------------------------------------------------------

local function SpawnSoul(inst,pos,num)
	num = num or 1 
	for i=1,num do 
		local soul = SpawnAt("soul_projectile",pos+Vector3(-2+4*math.random(),0,-2+4*math.random()))
		soul:AddTag("icey_soul_projectile")
		soul:AddTag("NO_TIME_STOP")
		soul.AnimState:SetMultColour(0/255,218/255,164/255,1)
		soul.persists = false 
		soul:DoTaskInTime(10+math.random()*2,function()
			if soul:HasTag("icey_soul_projectile") then 
				soul:RemoveTag("icey_soul_projectile")
				soul:ListenForEvent("animover", soul.Remove)
				soul.AnimState:SetBank("wortox_soul_ball")
				soul.AnimState:PlayAnimation("idle_pst")
				soul.SoundEmitter:PlaySound("dontstarve/characters/wortox/soul/spawn", nil, .5)
			end 
		end)
	end 
end 

local function DoShieldFlash(inst)
	local fx = inst:SpawnChild("icey_shield")
	fx.AnimState:SetMultColour(0/255,218/255,164/255,0.8)
	fx.Transform:SetPosition(0,-1,0)
end 

--[[local function shielddodelta(inst,number)
	if inst:HasTag("no_shiled_recover") and number > 0 then 
		return
	end 
	if inst.icey_shield and number then 
		inst.icey_shield = inst.icey_shield + number
	end
	if inst.wudao_sanity == 1 and inst.icey_shield > inst.icey_max_shield and inst.components.sanity:GetPercent() < 1.0 then --武道分流
		inst.components.sanity:DoDelta(inst.icey_shield - inst.icey_max_shield,true)
	end 
	inst.icey_shield = math.max(inst.icey_shield,0)
	inst.icey_shield = math.min(inst.icey_shield,inst.icey_max_shield)
	
	inst._icey_shield:set(inst.icey_shield)
	inst._icey_max_shield:set(inst.icey_max_shield)
	
	--if inst:HasTag("noharm") then 
		--inst.components.health:SetAbsorptionAmount(1.0)
	--else 
	inst.components.health:SetAbsorptionAmount(inst.icey_shield/inst.icey_max_shield)
	--end 
	--inst.components.combat.externaldamagetakenmultipliers:SetModifier("icey_shield",1 - inst.icey_shield/inst.icey_max_shield)
	if inst.iron_body == 1 then ---钢铁身躯：+5%伤害减免
		inst.components.health:SetAbsorptionAmount(inst.components.health.absorb+0.05)
		--inst.components.combat.externaldamagetakenmultipliers:SetModifier("icey_iron_body",0.95)
	end 
	if inst.exectuer == 1 and inst.icey_shield / inst.icey_max_shield >= 0.75 then 
		inst:AddTag("icey_exectuer")
	else
		inst:RemoveTag("icey_exectuer")
	end 
	inst:PushEvent("icey_shield_dodelta",{num = number})
	updatachanges(inst)
------------------------------------------------------------------------------------
	if inst.icey_shield < inst.icey_max_shield then 
		inst.sayshield = 0
	end 
	if inst.icey_shield == inst.icey_max_shield and inst.sayshield == 0 then 
		DoShieldFlash(inst)
		inst.components.talker:Say("Power OverWhelming !")
		inst.sayshield = 1
	end 
	
	--print("当前护甲:",inst.icey_shield)
end --]]

local function ShouldDrownTest(inst)
	return inst.components.stamina and inst.components.stamina.current <= 25 
end 

local function OnShieldChange(inst,old_shield,new_shield,try_delta,delta)
	local loss_delta = try_delta - delta
	local percentage = inst.components.icey_shield:GetPercent()
	if inst.wudao_sanity == 1 and loss_delta > 0 and percentage >= 1 and inst.components.sanity:GetPercent() < 1.0 then --武道分流
		inst.components.sanity:DoDelta(loss_delta,true)
	end 
	inst.components.health:SetAbsorptionAmount(percentage + (inst.iron_body == 1 and 0.05 or 0))
	if inst.exectuer == 1 and percentage >= 0.75 then 
		inst:AddTag("icey_exectuer")
	else
		inst:RemoveTag("icey_exectuer")
	end 
end 

local function OnShieldPowerUp(inst)
	DoShieldFlash(inst)
	inst.components.talker:Say("Power OverWhelming !")
end 

local function OnCalcShieldBase(inst)
	local base = 0.25
	local hunger_add = 0 
	local temp_add = 0 
	local quick_shield = (inst.quick_shield == 1 and 0.5) or 0
	
	local is_dead = (inst.components.health and inst.components.health:IsDead())
		or inst:HasTag("playerghost")
		or inst.sg:HasStateTag("dead")
		
	if is_dead then 
		return 0 
	end 
	
	local hunger_percent = inst.components.hunger:GetPercent()
	
	local is_satiated = hunger_percent >= 0.75 
	local is_hungry = hunger_percent < 0.2 
	local is_hot = 
		(inst.components.temperature and inst.components.temperature:IsOverheating())
		or (inst.components.burnable and inst.components.burnable:IsBurning())
		or (inst.components.health and inst.components.health.takingfiredamage) 
	local is_cold = inst.components.temperature and inst.components.temperature:IsFreezing()
	
	hunger_add = (is_hungry and -12) or (is_satiated and 0.1) or 0
	
	if is_hot then 
		temp_add = (inst.fire_keeper == 1 and 0) or (inst.starve_walker == 1 and -2) or -10
	elseif is_cold then 
		temp_add = (inst.snow_dancer == 1 and 0) or (inst.starve_walker == 1 and -2) or -10
	end
	
	local sum = base + hunger_add + temp_add + quick_shield 
	
	if sum > 0 and inst:HasTag("no_shiled_recover") then 
		return 0
	else
		return sum
	end
end 

local function check_sanwei(inst)
	local current_level = inst.components.icey_level:GetCurrentLevel()
	inst.components.hunger.max = (150 + (current_level-1)*3)
	inst.components.sanity.max = (120 + (current_level-1)*3)
	if inst.exectuer == 1 then 
		inst.components.health.maxhealth = 20
	else
		inst.components.health.maxhealth = (75 + (current_level-1)*3)
	end
	inst.components.health:DoDelta(0)
	inst.components.hunger:DoDelta(0)
	inst.components.sanity:DoDelta(0)
end

--inst.components.icey_level:ExpDoDelta()
--[[local function ExpDoDelta(inst,num)
	inst.icey_exp = inst.icey_exp + num
	while inst.icey_exp >= inst.icey_levelup_exp do      --------------升级了！
		inst.icey_exp = inst.icey_exp - inst.icey_levelup_exp
		
		inst.icey_level = inst.icey_level + 1
		inst.icey_level = math.min(max_level,inst.icey_level)
		
		inst.icey_levelup_exp = inst.icey_level * 100
		
		check_sanwei(inst)
	end 
	
	inst.icey_max_miss_num = math.floor(inst.icey_level / 3) + 1 
	inst._icey_max_miss_num:set(inst.icey_max_miss_num)
	
	inst._icey_exp:set(inst.icey_exp)
	inst._icey_level:set(inst.icey_level)
	inst._icey_levelup_exp:set(inst.icey_levelup_exp)
	--print("Gain Exp:",num,"Now Level:",inst.ly_level,"Now Exp:",inst.exp,"Exp need to up:",inst.level_up_exp - inst.exp)
end --]]

local function OnSetLevel(inst,is_levelup,old_level,new_level)
	check_sanwei(inst)
	inst.icey_max_miss_num = math.floor(new_level / 3) + 1 
	inst._icey_max_miss_num:set(inst.icey_max_miss_num)
end 

local function OnSetExp(inst,try_delta)
	if not inst.components.icey_level:IsLevelMaxed() then 
		try_delta = keepTwoDecimalPlaces(try_delta)
		if try_delta >= 0.5 then 
			local large = try_delta >= 10
			local colour = {13/255,190/255,222/255,1}
			
			local str = "EXP+"..try_delta
			
			for k,v in pairs(AllPlayers) do 
				if v and v:IsValid() and v:IsNear(inst,30) then 
					local number = v:SpawnChild("icey_damage_number")
					number:UpdateDamageNumbers(v, inst, str , nil, nil, large,colour)
				end 
			end  
		end 
	end
end 
-------------------------------------------------------------------------------------------------------------
local AtkTags = {
	{name = "iceyatk_chop",rand = 0.8,level = 1,weapontags = {"axe","halberd","chop_attack","icey_blade"},prefabnames = {"axe"}},
	{name = "iceyatk_circle",rand = 1.0,level = 2,groundonly = true,weapontags = {"axe_victorian","shadowmixtures_blade"}},
	--{name = "iceyatk_prop",rand = 0.6,level = 2,weapontags = {"icey_blade"}},
	{name = "iceyatk_lunge",rand = 0.6,level = 3,groundonly = true,weapontags = {"pointy","halberd","icey_blade","lunge_attack"}},
	{name = "iceyatk_hop",rand = 0.6,level = 5,groundonly = true,weapontags = {"hop_attack","axe","halberd","chop_attack","hammer","heavy_blade","icey_blade","shadowmixtures_blade"},prefabnames = {"axe","hammer"}},
	{name = "iceyatk_multithrust",rand = 0.4,level = 7,weapontags = {"pointy","halberd","icey_blade"}},
	{name = "iceyatk_none"},----must be there
}

local function RemoveAllAtkTags(player)
	for k,v in pairs(AtkTags) do 
		player:RemoveTag(tostring(v.name))
	end
end 

local function HasOneOfTags(inst,tags)
	if not (inst and inst:IsValid()) then 
		return false 
	end 
	for k,v in pairs(tags) do 
		if inst:HasTag(v) then 
			return true
		end
	end
end 

local function HasOneOfPrefabnames(inst,names)
	for k,v in pairs(names) do 
		if string.find(inst.prefab,v) then 
			return true 
		end
	end
end 

local function AddRandomAtkTag(player)
	--print(player,"AddRandomAtkTag")
	
	--[[local set = setcd(player,"icey_atk_change_cd",0.3,"攻击切换",false)
	if not set then 
		return
	end --]]
	RemoveAllAtkTags(player)
	local vaild_AtkTags = {}
	local my_rand = math.random()
	local weapon = player.components.combat:GetWeapon()
	local onwater = IceyUtil.IsOnWater(player)
	local current_level = player.components.icey_level:GetCurrentLevel()
	if not weapon then 
		return 
	end 
	for k,v in pairs(AtkTags) do 
		if (v.level or 0) <= current_level and my_rand <= (v.rand or 1.0) then 
			if (v.weapontags == nil or HasOneOfTags(weapon,v.weapontags)
				or (v.prefabnames and HasOneOfPrefabnames(weapon,v.prefabnames))
			)
			and not (v.groundonly and onwater)
			 then 
				table.insert(vaild_AtkTags,v)
			end 
		end
	end 
	
	local num = math.random(1,#vaild_AtkTags)
	local tag = vaild_AtkTags[num].name

	player:AddTag(tag)
end 
------------------------------------------------------------------------------------------------------------
local function updateall(inst)--我好笨啊
	--inst.ly_sleep = inst._ly_sleep:value()

	--inst.icey_level = inst._icey_level:value()
	--inst.icey_exp = inst._icey_exp:value()
	--inst.icey_levelup_exp = inst._icey_levelup_exp:value()
	
	UpdateAllSkillDirty(inst) 
	
	inst.icey_misscd = inst._icey_misscd:value()
	inst.icey_killcd = inst._icey_killcd:value()
	
	inst.GetTime = inst._GetTime:value()
	
	inst.icey_miss_num = inst._icey_miss_num:value()
	inst.icey_max_miss_num = inst._icey_max_miss_num:value()
	
	inst.icey_soundname = inst._icey_soundname:value()

end 

local function apply_skills(inst)
	if inst.hyperion == 1  then ---休伯利安号 
		inst.death_slaughter = 0  ---死亡进击
	end
	if inst.death_slaughter == 1  then --二选一
		inst.hyperion = 0  
	end
	
	--inst.components.locomotor.walkspeed = 4 * (1 + (inst.foot_star == 1 and 0.05 or 0) + (inst.liangzi_run == 1 and 0.10 or 0))
	--inst.components.locomotor.runspeed = 6 * (1 + (inst.foot_star == 1 and 0.05 or 0) + (inst.liangzi_run == 1 and 0.10 or 0))
	inst.components.locomotor:SetExternalSpeedMultiplier(inst, "icey_foot_star", inst.foot_star == 1 and 1.05 or 1)
	inst.components.locomotor:SetExternalSpeedMultiplier(inst, "icey_liangzi_run", inst.liangzi_run == 1 and 1.10 or 1)
	
	if inst.nucler_weapon == 1  then---融核武装
		inst.components.combat.damagemultiplier = 1.2
	end

	if inst.fire_keeper == 1  then ---消防屏障
		inst.components.health.fire_damage_scale = 0
		inst.components.health.fire_timestart = 99999
		inst.components.temperature.maxtemp = TUNING.OVERHEAT_TEMP - 15
	elseif inst.snow_dancer == 1  then ---霜雪舞者
		--免疫冰冻
		if inst.components.freezable then 
			inst.components.freezable.resistance = 999999
		end 
		--不怕冷
		inst.components.temperature.mintemp = 5
	elseif inst.starve_walker == 1  then ---荒蛮之主
		inst.components.health.fire_damage_scale = 0.5
		inst.components.health.fire_timestart = 5
		inst.components.temperature.maxtemp = TUNING.OVERHEAT_TEMP + 5
		if inst.components.freezable then 
			inst.components.freezable.resistance = 5
		end 
		inst.components.temperature.mintemp = -5
	end 
	
	if inst.exectuer == 1 then  ---势不可挡
		inst.components.icey_shield:SetMax(350)
		inst.components.health:SetMaxHealth(20)
	elseif inst.dark_charge == 1  then ---暗影冲锋
		
	elseif inst.rude_storm == 1  then ---鲁莽风暴
		inst.components.combat.damagemultiplier = 1.75
	end 
	
	if inst.steady == 1 then 
		inst.components.stamina.externalconsumeratemultipliers:SetModifier(inst,0.9,"icey_steady")
	else
		inst.components.stamina.externalconsumeratemultipliers:RemoveModifier(inst,"icey_steady")
	end
	--updateall(inst)
	check_sanwei(inst)
end 

local function reset_skills(inst)
	for k,v in pairs(icey_skills_list) do 
		inst[v] = 0
		inst["_"..v]:set(inst[v])
	end
	--inst.components.combat.externaldamagetakenmultipliers:RemoveModifier("icey_iron_body")
	inst.components.icey_shield:SetMax(100)
	inst.components.combat.damagemultiplier = 1
	inst.components.health.fire_damage_scale = 1
	inst.components.health.fire_timestart = 1
	inst.components.temperature.maxtemp = TUNING.MAX_ENTITY_TEMP
	inst.components.temperature.mintemp = TUNING.MIN_ENTITY_TEMP
	if inst.components.freezable then 
		inst.components.freezable.resistance = 1
	end 
	apply_skills(inst)
end 

local function GetMaxArmorabsorbe(inst)
	
end 

local function OnPreAttacked(inst,data)
	local dmg = data.damage
	local attacker = data.attacker
	local weapon = data.weapon
	local stimuli = data.stimuli

	if inst:HasTag("great_parrying") and inst:CanParryDamage(attacker,dmg,weapon,stimuli) then ---------完美防御
		--local delta = math.min(dmg,35)
		inst.components.icey_shield:DoDelta(math.random()*5 + 2)
		inst:AddTag("great_parrying_attack")
		inst.GreatParryingTarget = attacker
		--inst.SoundEmitter:PlaySound("dontstarve/wilson/equip_item_gold")
		inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/trails/hide_pre",nil,0.5)
		if inst.CancelGreatParryingAttackTask then 
			inst.CancelGreatParryingAttackTask:Cancel()
		end 
		inst.CancelGreatParryingAttackTask = inst:DoTaskInTime(0.5,function()
			inst:RemoveTag("great_parrying_attack")
			inst.CancelGreatParryingAttackTask = nil 
			inst.GreatParryingTarget = nil 
		end)
	end
end 

local function OnAttacked(inst, data)
	local dmg = data.damage
	local redirected = data.redirected
	--local dmg_redirected = 
	--local original_damage = data.damage
	local attacker = data.attacker
	local weapon = data.weapon
	local stimuli = data.stimuli
	--local projectile = data.projectile
	local x,y,z = inst:GetPosition():Get()
	local shield_percentage = inst.components.icey_shield:GetPercent()
	
	print("合计造成伤害:",dmg)
	if dmg and dmg > 0 and not redirected then 
		PlayHDamageSound(inst,dmg)
	end 
	
	if inst.dangerous == 1 then --危机关系
		local set = setcd(inst,"dangerouscd",15,"危机关系",false)
		if set then 
			--inst.components.locomotor.walkspeed = inst.components.locomotor.walkspeed * 1.10
			--inst.components.locomotor.runspeed = inst.components.locomotor.runspeed * 1.10
			inst.components.locomotor:SetExternalSpeedMultiplier(inst, "icey_dangerous",1.10)
			inst:DoTaskInTime(5,function()
				--inst.components.locomotor.walkspeed = inst.components.locomotor.walkspeed / 1.10
				--inst.components.locomotor.runspeed = inst.components.locomotor.runspeed / 1.10
				inst.components.locomotor:RemoveExternalSpeedMultiplier(inst, "icey_dangerous")
			end)
		end 
	end
	if attacker and attacker:IsValid() and not attacker:HasTag("icey_power_building") and attacker ~= inst and inst.exectuer == 1 and shield_percentage >= 0.33 then -----势不可挡的弹反
		local rad = 4
		rad = rad * shield_percentage
		if attacker:IsNear(inst,rad) then 
			if attacker.components.combat and not inst:CanParryDamage(attacker,dmg,weapon,stimuli) then 
				attacker.components.combat:GetAttacked(inst,math.random(1,10))
			end 
			if attacker:HasTag("player") then 
				attacker:PushEvent("repelled", { repeller = inst, radius = rad })
			else 
				print("exectuer knockback",attacker,rad)
				local creatures = {}
				if attacker.Physics then 
					table.insert(creatures,{inst = attacker})
				end 
				if #creatures > 0 then
					inst:DoTaskInTime(10 * FRAMES, TimeoutRepel, creatures,
						inst:DoPeriodicTask(0, UpdateRepel, nil, x, z, creatures,rad)
					)
				end
			end 
		end 
		DoShieldFlash(inst)
	end 

	if not redirected then 
		print("正常受伤 护盾减少 dmg:",dmg)
		inst.components.icey_shield:DoDelta(-dmg)
		
	else
		
		if inst.sg:HasStateTag("parrying") then 
			if not inst:CanParryDamage(attacker,dmg,weapon,stimuli) then 
				print("格挡中但是格挡失败 dmg:",dmg)
				inst.components.icey_shield:DoDelta(-dmg)
				if inst.components.stamina then 
					if inst.harvell_coser == 1 then 
						inst.components.stamina:DoDelta(-dmg*0.3)
						inst.components.stamina:Pause(0.5) 
					else
						inst.components.stamina:DoDelta(-dmg)
						inst.components.stamina:Pause(2) 
					end 
				end
			else
				print("格挡中且格挡成功 dmg/10:",dmg/10)
				inst.components.icey_shield:DoDelta(-dmg/10)
				if inst.components.stamina then 
					if inst.harvell_coser == 1 then 
						inst.components.stamina:DoDelta(-dmg*0.1)
					else
						inst.components.stamina:DoDelta(-dmg*0.8)
						inst.components.stamina:Pause(1) 
					end 
				end
			end 
			
		end
	end
	
end 



local function OnHealthDelta(inst,data)
	local newpercent = data.newpercent 
	local currenthealth = inst.components.health.currenthealth 
	--local clothing = inst.components.skinner:GetClothing()
	
	if not inst:HasTag("playerghost") and not inst.components.icey_ironlord:IsIronLord() then 
		if newpercent <= 0.5 then 
			inst.AnimState:SetBuild("icey_injured")
		else
			inst.AnimState:SetBuild("icey")
		end 
	end 
end 

--[[local function badtempfn(inst)
	if inst.components.temperature and inst.components.burnable and inst.components.health then 
		local delta = -3
		local infire = (inst.components.temperature:IsOverheating() 
			or inst.components.burnable:IsBurning() 
			or inst.components.health.takingfiredamage )
		local infreeze = inst.components.temperature:IsFreezing()
		if inst.starve_walker == 1 then 
			delta = -0.5
		end 
		if ( 
		(infire and inst.fire_keeper == 0)
		or 
		(infreeze and inst.snow_dancer == 0) 
		) 
		and inst.icey_badtempfn == nil then
			if infire then 
				delta = delta * inst.components.health.fire_damage_scale * inst.components.health.fire_damage_scale_sourcemodifier:Get()
			end
			inst.icey_badtempfn = inst:DoPeriodicTask(0.5,function()
				inst.components.icey_shield:DoDelta(delta)
			end)
		elseif inst.icey_badtempfn then 
			inst.icey_badtempfn:Cancel()
			inst.icey_badtempfn = nil
		end 
	end 
	
end --]]

------根据所有装备的inst.components.equippable.icey_mults参数获取精华获取量增益
local function GetEquipGainBonus(inst)
	local mult = 1 
	if inst.components.inventory ~= nil then
		for k,v in pairs(EQUIPSLOTS) do 
			local equip = inst.components.inventory:GetEquippedItem(v)
			if equip and equip.components.equippable then 
				local this_mult = equip.components.equippable.icey_mults or 1 
				mult = mult * this_mult
			end 
		end
	end 
	return mult
end 

local function onattack(inst,data)
	local target = data.target
	local stimuli = data.stimuli
	local damage = data.damage
	local sneaking_attack = false 
	local shield_current = inst.components.icey_shield.current
	local shield_percentage = inst.components.icey_shield:GetPercent()
	--[[if inst.go_hide == 1 and not inst:HasTag("death_slaughter")then 
		inst:Show() 
		inst.DynamicShadow:SetSize(1.3, .6) 
		inst.MiniMapEntity:SetIcon("icey.tex") 
		if inst.outofhidefn ~= nil then 
			inst.outofhidefn:Cancel()
			inst.outofhidefn = nil
		end
	end --]]
	--[[if math.random() <= 0.3 and (not data.stimuli or data.stimuli ~= "icey_shadow_attack") then 
		SpawnShadowsAttack(inst,target)
	end --]]
	if inst.blood_steal == 1 and (damage and damage >= 10) then --生物质汲取
		inst.components.icey_shield:DoDelta(0.5)
	end 
	if inst.shield_attack == 1 and (damage and damage >= 30) then --盾牌猛击
		if math.random(0,100) <= 50 and target and target:IsValid() and target.components.health and not target.components.health:IsDead() then
			target.components.health:DoDelta(-shield_current / 10)
			target.components.combat:SuggestTarget(inst)
		end 
	end 
	if inst.shield_crush == 1 and not target:HasTag("giant") and not target:HasTag("NOSHIELDCRUSH") 
		and target.prefab and target.prefab ~= "pugalisk_body" and target.prefab ~= "pugalisk_segment" 
		and target.prefab ~= "pugalisk_tail" then --守备粉碎
		--[[if target.components.health and target.components.health.absorb > -1.0 then 
			target.components.health:SetAbsorptionAmount(target.components.health.absorb - 0.01)
			target:DoTaskInTime(30,function()target.components.health:SetAbsorptionAmount(target.components.health.absorb + 0.01)end)
		end--]]
		if target.components.combat then 
			local Modifier = target.components.combat.externaldamagetakenmultipliers
			local nowmultnum = Modifier:CalculateModifierFromSource(inst,"icey_shield_crush") 
			if not nowmultnum or nowmultnum < 2 then 
				local newmultnum = nowmultnum and nowmultnum + 0.01 or 1.01
				Modifier:SetModifier(inst,newmultnum,"icey_shield_crush")
				
				if not (target.sunderarmor_fx and target.sunderarmor_fx:IsValid()) and target.components.health.maxhealth >= TUNING.SPIDER_WARRIOR_HEALTH then 
					local fx = SpawnPrefab("icey_sunderarmordebuff")
					--fx.Transform:SetScale(0.7,0.7,0.7)
					fx:SetTarget(target,target:HasTag("largecreature") and 4 or 3)
					--fx:ShowCombatMults(inst,"icey_shield_crush")
					target.sunderarmor_fx = fx 
				end 
				
				target:DoTaskInTime(10,function()
					local mult = Modifier:CalculateModifierFromSource(inst,"icey_shield_crush") or 1
					if mult and mult > 1 then 
						Modifier:SetModifier(inst,mult-0.01,"icey_shield_crush")
					end 
					local pstmult = Modifier:CalculateModifierFromSource(inst,"icey_shield_crush") or 1
					if (pstmult <= 1 or target:HasTag("playerghost") or target.components.health:IsDead()) and target.sunderarmor_fx and target.sunderarmor_fx:IsValid() then
						target.sunderarmor_fx:KillFx()
						target.sunderarmor_fx = nil 
					end 
				end)
			end 
		end
	end 
	if inst.king_card == 1 and math.random() >= 0.5 and damage and damage >= 20 then ---终极王牌
		inst.icey_killcd = inst.icey_killcd - 1
		inst._icey_killcd:set(inst.icey_killcd)
	end 
	if inst.charge == 1 then -- 冲锋
		local set = setcd(inst,"chargecd",15,"冲锋",false)
		if set then 
			--inst.components.locomotor.walkspeed = inst.components.locomotor.walkspeed * 1.15
			--inst.components.locomotor.runspeed = inst.components.locomotor.runspeed * 1.15
			inst.components.locomotor:SetExternalSpeedMultiplier(inst, "icey_charge",1.15)
			inst.chargefx_fn = inst:DoPeriodicTask(0.6,function()
				--[[local x,y,z = inst:GetPosition():Get()
				local fx = DebugSpawn("icey_charge_fx"..math.random(1,3))
				fx.Transform:SetPosition(x,y,z)--]]
			end )
			inst:DoTaskInTime(10,function()
				--inst.components.locomotor.walkspeed = inst.components.locomotor.walkspeed / 1.15
				--inst.components.locomotor.runspeed = inst.components.locomotor.runspeed / 1.15
				inst.components.locomotor:RemoveExternalSpeedMultiplier(inst, "icey_charge")
				if inst.chargefx_fn then 
					inst.chargefx_fn:Cancel()
					inst.chargefx_fn = nil
				end
			end)
		end 
	end 
	if inst.dark_charge == 1 and target.brain and not target:HasTag("NODARKCHARGE") then --暗影冲锋
		local set = setcd(inst,"dark_chargecd",15,"暗影冲锋",false)
		if set and target.brain  then 
			local time = (target:HasTag("epic") and 1.5) or 3
			local fx = SpawnPrefab("statue_transition_2")
			fx.Transform:SetPosition(target:GetPosition():Get())
			if target.brain then 
				target.brain:Stop()
			end 
			if target.components.locomotor then 
				target.components.locomotor:Stop()
			end
			if target.Physics then
				target.Physics:Stop()
			end
			inst:DoTaskInTime(time,function()
				if target.brain then 
					target.brain:Start()
				end 
			end)
		end 
	end 
	if inst.rude_storm == 1 then --鲁莽风暴
		if shield_percentage > 0.1 then 
			inst.components.icey_shield:DoDelta(-1)
		else
			inst.components.health:DoDelta(-3)
		end 
	end 
	if inst:HasTag("overload_fusion")  then -------------超载融合
		print("Icey overload_fusion onattack")
		--for i=1,math.random(2,3) do 
		if target and target:IsValid() and target.components.health and not target.components.health:IsDead() then 
			target.components.health:DoDelta(-(data.damage or 34),nil,inst.prefab)
		end 
		--end 
	end
	-----------背刺
	if inst.components.iceysneaker:CanTerminateTarget(target,true) then 
		sneaking_attack = true 
		local hitbackdamage = (data.damage*2 or 68) --* (inst.shinobi_execution + 1)
		if inst.shinobi_execution == 1 and not target:HasTag("epic") and target.components.health.currenthealth <= 500 then 
			hitbackdamage = hitbackdamage * 3
		end 
		target.components.health:DoDelta(-hitbackdamage,nil,inst.prefab)
	end 
	if target and target:IsValid() and target.components.health and target.components.health:IsDead() then 
		if not target:HasTag("icey_already_killed") then 
			
			local gain = target.components.health.maxhealth / 100
			gain = GetEquipGainBonus(inst)*gain 
			if TheNet:GetServerGameMode() == "lavaarena" then 
				gain = gain * 10
			end 
			
			local magicnum = math.min(math.random(1,math.max(gain,1)),40)
			for i=1,magicnum do ---------获得精华
				if math.random(0,100) >= 75 and  TheNet:GetServerGameMode() ~= "lavaarena" then 
					local magic = SpawnPrefab("icey_magic")
					magic.Transform:SetPosition(target:GetPosition():Get())
					if inst.components.inventory then 
						inst.components.inventory:GiveItem(magic)
					end
				end 
			end 
			if target:HasTag("epic") then 
				gain = gain * 2
				--print("Epic Monster!Gain 2x Exp")
			end 
			if target:HasTag("tadalin") then 
				gain = gain * 1.25
				--print("tadalin Monster!Gain 2x Exp")
			end 
			--杀死敌人获取经验用了额外算法，这里就不用加了
			--inst.components.icey_level:ExpDoDelta(gain)
			if inst.great_coupling == 1 then --高效耦合
				inst.icey_miss_num = inst.icey_max_miss_num
				inst._icey_miss_num:set(inst.icey_miss_num)
			end
			target:AddTag("icey_already_killed")
			
			if inst.soul_torrent == 1 then
				SpawnSoul(inst,target:GetPosition(),math.max(1,math.min(8,gain)))
			end 
			
			if sneaking_attack then 
				target.components.combat:SetTarget(nil) 
				if inst.iron_hitter == 1 then 
					if not inst.components.health:IsDead() then
						inst.components.health:DoDelta(magicnum*5)
						inst.components.sanity:DoDelta(magicnum*5)
						if inst.components.focus then 
							inst.components.focus:DoDelta(magicnum*8)
						end
						if inst.components.stamina then 
							inst.components.stamina:DoDelta(magicnum*20)
						end
					end
				end
			end 
		end 
	end
	
end

-- When the character is revived from human
local function onbecamehuman(inst)
	-- Set speed when loading or reviving from ghost (optional)
	inst.components.locomotor.walkspeed = 4
	inst.components.locomotor.runspeed = 6
	--inst:DoTaskInTime(5,function()inst:SetStateGraph("SGicey")end)
	apply_skills(inst)
	
	inst:DoTaskInTime(5,function() 
		inst.components.health:DoDelta(0) 
	end)
end



local function GetString(inst,list)
	for k,v in pairs(icey_save_lists) do 
		print(v,inst[v])
	end
end 

local function QuickSave(inst,data,list)
	for k,v in pairs(list) do 
		data[v] = inst[v] or nil 
	end 
end 

local function QuickLoad(inst,data,list)
	if data ~= nil then 
		for k,v in pairs(list) do 
			if data[v] ~= nil  then
				inst[v] = data[v]
				if inst["_"..v] ~= nil then 
					inst["_"..v]:set(inst[v])
				end 
			end
		end 
	end 
end 

local function onsave(inst,data)
	QuickSave(inst,data,icey_save_lists)
	data.icey_health = inst.components.health.currenthealth or nil 
	data.icey_hunger = inst.components.hunger.current or nil
	data.icey_sanity = inst.components.sanity.current or nil 
end 

-- When loading or spawning the character
local function onload(inst,data)
    inst:ListenForEvent("ms_respawnedfromghost", onbecamehuman)
    if not inst:HasTag("playerghost") then
        onbecamehuman(inst)
    end
	QuickLoad(inst,data,icey_save_lists)
	--ExpDoDelta(inst,0)
	--check_sanwei(inst)
	if not inst:HasTag("playerghost") then 
		apply_skills(inst)
	end 
	if data then 
		if data.icey_health ~= nil then 
			inst.components.health.currenthealth = data.icey_health
		end 
		if data.icey_hunger ~= nil then
			inst.components.hunger.current = data.icey_hunger
		end 
		if data.icey_sanity ~= nil then
			inst.components.sanity.current = data.icey_sanity 
		end 
		--[[if data.icey_level then
			--inst.icey_level = data.icey_level
			inst.components.icey_level:SetLevel(data.icey_level)
		end
		if data.icey_exp then
			--inst.icey_exp = data.icey_exp
			inst.components.icey_level:SetExp(data.icey_exp)
		end--]]
	end
	GetString(inst,icey_save_lists)
	
end

local function OnNewSpawn(inst,data)
	print("熔炉模式检测：",TheNet:GetServerGameMode() == "lavaarena")
	if TheNet:GetServerGameMode() == "lavaarena" then 
		local weapon = SpawnPrefab("icey_blade")
		local armor = SpawnPrefab("icey_armor")
		local x,y,z = inst:GetPosition():Get()
		weapon.Transform:SetPosition(x,y,z)
		--weapon:SetLevel()
		inst.components.inventory:Equip(weapon)
		inst.components.inventory:Equip(armor)
	end
	onload(inst,data)
end 

local function oneat(inst,food)
	local gain = food.components.edible.hungervalue / 20
	local healthvalue,sanityvalue = food.components.edible.healthvalue,food.components.edible.sanityvalue
	local lost =  (healthvalue < 0 and  healthvalue or 0) + (sanityvalue < 0 and sanityvalue or 0)
	if gain < 0 then 
		gain = 0
	end
	if inst.battleground_eating == 1 and inst.components.focus and food.components.edible.foodtype == FOODTYPE.ICEY_BATTERY then 
		inst.components.focus:DoDelta(math.max(0,sanityvalue))
	end 
--[[	if inst.components.metroworldplayer then 
		inst.components.metroworldplayer:SicknessDoDelta(-5)
	end --]]
	inst.components.icey_level:ExpDoDelta(gain)
	
	inst.components.icey_shield:DoDelta(gain+lost)
end 

local function onwork(inst)
	inst.components.icey_level:ExpDoDelta(0.1)
end 

local function ondeath(inst)
	PlayHDamageSound(inst,99999,nil,"death")
	if inst.icey_bars then 
		inst.icey_bars:Remove()
		inst.icey_bars = nil 
	end
	if inst.shield_updata then 
		inst.shield_updata:Cancel()
		inst.shield_updata = nil 
	end
	if inst.red_reboot == 1 and math.random(0,100) <= 30 then ---红色重启
		inst:DoTaskInTime(2.5,function()
		--inst.Physics:Teleport(pos.x,0,pos.z)
			if inst:HasTag("playerghost") then 
				inst:PushEvent("respawnfromghost")
			end 
		end )
		
		inst:DoTaskInTime(8,function()
			if not inst:HasTag("playerghost") and (inst.components.health and  not inst.components.health:IsDead() )then 
				inst.components.hunger:SetPercent(1.0)
				inst.components.health:SetPercent(1.0)
				inst.components.sanity:SetPercent(1.0)
				inst.components.stamina:SetPercent(1.0)
				inst.components.focus:SetPercent(1.0)
				inst.components.icey_shield:SetPercent(1.0)
			end 
		end )
	end
end 

local function DefaultFaceClient(inst,x,y,z,entity)
	if entity and not (x and y and z)  then 
		x,y,z = entity:GetPosition():Get()
	end
	inst:ForceFacePoint(x,y,z)
end 


local function fuck_you_stop(inst)
	inst:AddTag("icey_missing")
	inst.components.playercontroller:Enable(false)
	--inst.Physics:SetCollides(false)
	--inst.Physics:ClearMotorVelOverride() 
	--inst.sg:GoToState("run_stop")
	inst.components.locomotor:Stop()
	ChangeToGhostPhysics(inst)
	--inst.Physics:Stop()
	RemovePhysicsColliders(inst)
	inst.components.health:SetInvincible(true)
	inst.AnimState:SetRayTestOnBB(true)
	ToggleOffPhysics(inst)
end 

local function ok_you_are_free(inst,finalsg,finalanim)
	--print("是不是死了:",inst.components.health:IsDead())
	inst:RemoveTag("icey_missing")
	if not (inst.components.rider and inst.components.rider:IsRiding()) then 
		inst.AnimState:PlayAnimation("atk_leap_lag")
	end 
	if inst.sg:HasStateTag("nointerrupt") or (inst.components.rider and inst.components.rider:IsRiding()) or (inst.components.health:IsDead() or inst:HasTag("playerghost")) then 
		finalsg = nil
		finalanim = nil
	end 

	--inst.Physics:SetCollides(true)
	inst.components.locomotor:Stop()
	inst.Physics:ClearMotorVelOverride() 
	--inst.Physics:Stop() 
	inst.AnimState:SetMultColour(1,1,1,1)
	inst.components.playercontroller:Enable(true)
	ChangeToCharacterPhysics(inst)
	inst:DoTaskInTime(0.1,function()
		if not (
			inst.sg:HasStateTag("nointerrupt") or 
			(inst.components.rider and inst.components.rider:IsRiding()) or 
			(inst.components.health:IsDead() or inst:HasTag("playerghost")) or 
			(inst.sg.currentstate.name == "death")
		) then 
			if finalsg ~= nil  then 
				inst.sg:GoToState(finalsg) 
			end
			if finalanim ~= nil then 
				inst.AnimState:PlayAnimation(finalanim,true)
			end
		end 
	end )
	inst.components.health:SetInvincible(false)
	inst.AnimState:SetRayTestOnBB(false)
	if inst.isphysicstoggle then 
		ToggleOnPhysics(inst)
	end 
end 

local function maketrail(inst)
	inst:StartThread(function()		
		for i = 1,5 do 
			if i ~= 1 then 
				local chargemult = inst.components.locomotor:GetExternalSpeedMultiplier(inst, "icey_charge")
				local fxname = (chargemult and chargemult > 1) and "halloween_firepuff_cold_"..math.random(1,3) or "spear_gungnir_lungefx"
				local x,y,z = inst:GetPosition():Get()
				local fx = SpawnPrefab(fxname)
				fx.Transform:SetPosition(x,y,z)
				fx.Transform:SetScale(1,i/5,1)
			end 
			Sleep(0.000001)
		end 
	end )
end 

--[[	inst:StartThread(function()		 
		for i = 1,64 do  
			c_gonext("pighouse_blood") 
			Sleep(2) 
		end  
	end ) --]]



local function superise_motherfucker(inst,eny)
	if eny and eny.components.health and  inst.components.combat:GetWeapon() and not eny.components.health:IsDead() then 
		inst:PushEvent("icey_greatmiss",{eny = eny})
		local x,y,z = eny:GetPosition():Get()
		local myweapon = inst.components.combat:GetWeapon()
		if not (myweapon and myweapon:IsValid()) or (myweapon and myweapon:HasTag("no_icey_miss")) then 
			return 
		end 
		local dmg = myweapon.components.weapon.damage
		
		local shadow = DebugSpawn("icey_shadow2")    ---------------召唤影分身
		local shadowweapon = DebugSpawn(myweapon.prefab) ------为影分身生成虚武器
		local shadowprotect = DebugSpawn("armorruins")---------为影分身生成虚护甲
		
		if TheNet:GetServerGameMode() == "lavaarena" then 
			shadow:AddComponent("buffable")
		end 
		
		shadow.Transform:SetPosition(x,y,z)
		shadowweapon.Transform:SetPosition(x,y,z)
		shadowprotect.Transform:SetPosition(x,y,z)
		
		shadowprotect.components.armor:SetAbsorption(1.0) ------影分身是无敌的，所以护甲是100%伤害吸收
		shadowprotect.components.equippable:SetOnEquip(function(inst,owner) end ) ----------护甲的贴图太难看了，这样设计onequip就不会显示护甲贴图了
		
		--shadow.components.health:SetAbsorptionAmount(1.0)------影分身本体也是无敌的
		shadow.components.inventory:Equip(shadowweapon)
		shadow.components.inventory:Equip(shadowprotect)
		shadow.components.colouradder:PushColour("leap", 96/255, 249/255, 255/255, 0)
		
		shadow:DoTaskInTime(0,function()
			shadow:ForceFacePoint(eny:GetPosition():Get())
			inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon")
			shadow.AnimState:PlayAnimation("atk_leap")	
			inst.SoundEmitter:PlaySound("dontstarve/common/lava_arena/fireball")
		end)
		shadow:DoTaskInTime(0.4,function()
			if inst.electricity_shadow == 1 then ---------化电幻影
				if canattack(eny,inst) then 
					eny.components.combat:GetAttacked(inst,dmg * 2,shadowweapon,"electric")
				end 
				inst:StartThread(function()	
					for i=1,5 do 
						--local crackle = SpawnPrefab("hammer_mjolnir_crackle")
						local cracklebase = SpawnPrefab("hammer_mjolnir_cracklebase")
						local cracklehit = SpawnPrefab("hammer_mjolnir_cracklehit")
						local cracklehitfx = SpawnPrefab("cracklehitfx")
						
						--crackle.Transform:SetPosition(x,y,z)
						cracklebase.Transform:SetPosition(x,y,z)
						cracklehit.Transform:SetPosition(x,y,z)
						cracklehitfx.Transform:SetPosition(x,y,z)
						
						--crackle:ListenForEvent("animover", function(inst) inst:Remove() end )
						cracklebase:ListenForEvent("animover", function(inst) inst:Remove() end )
						cracklehit:ListenForEvent("animover", function(inst) inst:Remove() end )
						cracklehitfx:ListenForEvent("animover", function(inst) inst:Remove() end )
						
						if eny and eny:IsValid()  and not (eny.components.health:IsDead() or eny:HasTag("playerghost") or eny.sg:HasStateTag("death"))then
							eny.components.combat:GetAttacked(inst,0.1,nil,"electric")
						end 
						Sleep(0.2)
					end
				end)
			else
				if canattack(eny,inst) then 
					eny.components.combat:GetAttacked(inst,dmg * 2)
				end 
			end 
			inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon")
			if inst.witch_time == 1 then  
				local set = setcd(inst,"witch_timecd",90,"狂野膜法",false)
				if set then
					inst.components.timestoper:TheWorld(inst:GetPosition(),nil,5,nil,{"INLIMBO","icey_shadow"},nil,function(guy)
						return guy:HasTag("projectile") or IceyUtil.CanAttack(guy,inst)
					end)
				end 
			end 
			if inst.soul_torrent == 1 then 
				local num = eny.components.health.maxhealth / 150
				if eny:HasTag("epic") then 
					num = num * 2
				end
				SpawnSoul(inst,eny:GetPosition(),math.max(1,math.min(num,3)))
			end 
			if eny.components.health:IsDead() then 
				if inst.components.health and not inst.components.health:IsDead() then
					inst.components.health:DoDelta(dmg/5)
				end 
				--杀死敌人获取经验用了额外算法，这里就不用加了
				--PS:我当初写代码的时候是不是闪避杀死敌人能在这额外获得一次经验？？？
				--inst.components.icey_level:ExpDoDelta(eny.components.health.currenthealth / 100)
				inst.components.icey_shield:DoDelta(dmg/2)
			else 
				--[[if inst.components.timestoper then 
					inst.components.timestoper:SingleStopTime(eny,5)
				end--]]
				
				if inst.components.health and not inst.components.health:IsDead() then
					inst.components.health:DoDelta(dmg/50)
				end 
				inst.components.icey_shield:DoDelta(dmg/10)
				if inst.death_slaughter == 1 and not eny.great_set_fx then        -------------斩模式
					local greatset = SpawnPrefab("greatmiss_set")
					local fx = SpawnPrefab("blossom_hit_fx")
					inst.SoundEmitter:PlaySound("dontstarve/wilson/equip_item_gold")
					fx.AnimState:SetAddColour(36/256, 210/256, 231/256, 0)
					greatset.SetMultColour(0/255,255/255,240/255,1)
					
					greatset.entity:SetParent(eny.entity)
					fx.entity:SetParent(eny.entity)
					if eny:HasTag("largecreature") then    
						greatset.Transform:SetScale(0.6,0.6,0.6)  
						fx.Transform:SetPosition(0,4,0) 
						greatset.Transform:SetPosition(0,4.5,0) 
					elseif eny:HasTag("character") then 
						greatset.Transform:SetScale(0.5,0.5,0.5)  
						fx.Transform:SetPosition(0,2,0)    
						greatset.Transform:SetPosition(0,2.5,0) 
					else 
						greatset.Transform:SetScale(0.5,0.5,0.5)  
						fx.Transform:SetPosition(0,1.5,0)    
						greatset.Transform:SetPosition(0,2,0) 
					end 
				
					eny:AddTag("after_greatmiss")
					eny.great_set_fx = greatset
					greatset.owner = eny
					eny:DoTaskInTime(2,function()
						eny:RemoveTag("after_greatmiss")
						if greatset then 
							--eny.great_set_fx = nil 
							greatset.KillMe()
						end
						
					end)
				end 
			end
			--inst.SoundEmitter:PlaySound("dontstarve/common/freezecreature")
		end)
		inst:DoTaskInTime(0.7,function()
			if shadowweapon then shadowweapon:Remove() end 
			if shadow then shadow:Remove() end 
			if shadowprotect then shadowprotect:Remove() end 
			if inst.go_hide == 1 then 
				local set = setcd(inst,"go_hidecd",30,"光学迷彩",false)
				if set then
					inst:Hide()
					inst.DynamicShadow:SetSize(0,0)
					inst.MiniMapEntity:SetIcon("none.tex")
					if inst.outofhidefn ~= nil then 
						inst.outofhidefn:Cancel()
						inst.outofhidefn = nil
					end 
					inst.outofhidefn = inst:DoTaskInTime(5,function() 
						inst:Show() 
						inst.DynamicShadow:SetSize(1.3, .6) 
						inst.MiniMapEntity:SetIcon("icey.tex") 
					end)
				end 
			end 
		end )
		
	end
end 
	
local function rescue(inst,begin)
	inst:PutBackOnGround()
	if not IceyUtil.IsPassableAtPoint(inst:GetPosition():Get()) then 
		if inst.Physics ~= nil then 
			inst.Physics:Teleport(begin:Get())
		end 
		if inst.Transform ~= nil then 
			inst.Transform:SetPosition(begin:Get())
		end
	end 
	if inst.components.talker then 
		inst.components.talker:Say("妈耶,掉海里了!")
	end 
end 

local function icey_missfn(inst,x,y,z)
	if inst.sg:HasStateTag("fossilized") then 
		return 
	end 
	if inst.components.stamina and inst.components.stamina.current < 6 then 
		return 
	end 
	local hasground,ground = TheWorld.Map:HasFakeGroundNearBy(inst:GetPosition():Get())
	if hasground and ground and ground:IsValid() then
		if ground and ground.NoMiss then 
			inst.components.talker:Say("有什么东西阻止我闪避。")
			return 
		end
	end  
		
	local cancast = setcd(inst,"icey_misscd",TUNING.ICEY_MISS_CD,"闪避",false,true)
	if not cancast or inst.icey_miss_num <= 0 then
		return 
	end 
	--inst:AddTag("noharm")
	local is_swimming = inst.components.icey_swimmer:IsSwimming()
	if inst.components.stamina then 
		inst.components.stamina:DoDelta(-6 * (is_swimming and 5 or 1))
		inst.components.stamina:Pause(0.3 * (is_swimming and 5 or 1))
	end 
	
	inst.icey_miss_num = inst.icey_miss_num - 1 
	inst.icey_miss_num = math.max(0,inst.icey_miss_num)
	inst._icey_miss_num:set(inst.icey_miss_num)
	
	if inst.components.inventory and inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS) == nil then 
		inst.AnimState:ClearOverrideSymbol("swap_object")
	end 
	if inst.components.freezable and inst.components.freezable:IsFrozen() then 
		inst.components.freezable:Unfreeze()
	end 
	fuck_you_stop(inst) -------------------------给我停下来！！！
	local old_buff = inst.components.health.absorb
	local mouse = Vector3(x,y,z)
	local begin = inst:GetPosition()
	local a,b,c = begin:Get()
	local greatmiss = false
	local eny = nil 
	local ents = TheSim:FindEntities(a, b, c, 5, {"_combat"},{"time_stopped"})
	local movingspeed = 40
	local movingtime = 0.2
	local r,g,b,a = 17/255,29/255,184/255,0.3
	if inst.sg:HasStateTag("moving") then 
		movingspeed = 250
		movingtime = 0.2
		r,g,b,a = 166/255,252/255,242/255,0.3
		maketrail(inst)
	end 
	--inst.components.health:SetAbsorptionAmount(1.0)
		for k,v in pairs(ents) do
			if v:IsValid() and v.components.combat and v.components.combat.target == inst and v.sg and v.sg:HasStateTag("attack") then 
				eny = v
				greatmiss = true----------------------若闪避时有人在攻击我，则触发极限闪避
				break
			end
		end 
	inst.SoundEmitter:PlaySound("dontstarve/common/staff_blink")
	if not (inst.components.rider and inst.components.rider:IsRiding()) then 
		inst.AnimState:PlayAnimation("atk_leap_lag")
	end 
	inst:ForceFacePoint(mouse:Get())
	inst.AnimState:SetMultColour(r,g,b,a)
	inst.Physics:SetMotorVelOverride(movingspeed,0,0)
	inst:DoTaskInTime(movingtime,function() 
		--inst:RemoveTag("noharm")
		--inst.components.health:SetAbsorptionAmount(old_buff)
		ok_you_are_free(inst,"idle",nil)-----------------好了你可以走了
		if inst.components.iceysneaker:IsSneaking() then 
			inst.components.iceysneaker:StopSneak()
		end 
		if eny and greatmiss then 
			if inst.all_shield == 1 then --全副武装 
				inst.components.icey_shield:DoDelta(10)
			end
			inst:StartThread(function()
				for i = 1,1 + inst.mult_shadow do 
					superise_motherfucker(inst,eny)---------------------极限闪避程序
					Sleep(0.3)
				end 
			end)
		end
		
		if not IceyUtil.IsPassableAtPoint(inst:GetPosition():Get()) and not (IceyUtil.IsOnWater(inst) and inst.components.icey_swimmer) then
			rescue(inst,begin)
		end
	end )
end 

local function MakeTrail2(inst, doer, targetpos,num)
	print("make trail2!")
	num = num or 10 
	inst.SoundEmitter:PlaySound("dontstarve/common/lava_arena/fireball")
	local x,y,z  = doer.Transform:GetWorldPosition()
	local distanceToTargetPos = math.abs(math.sqrt(math.pow(targetpos.x - x, 2) + math.pow(targetpos.z - z, 2)))
	local x2     = targetpos.x - x
	local z2     = targetpos.z - z
	local angle  = math.acos(x2/distanceToTargetPos)
	local sacle = 0.1
	if (x2 < 0 and z2 < 0 and math.deg(angle) < 180 and math.deg(angle) >= 90) or 
	   (x2 >= 0 and z2 < 0 and math.deg(angle) < 90 and math.deg(angle) > 0) then
		angle = -angle
	end
	for i = 0, num do
		local lungefx = SpawnPrefab("spear_gungnir_lungefx")
		lungefx.Transform:SetScale(sacle,sacle,sacle)
		sacle = sacle + 1/num
		lungefx.Transform:SetPosition(x + ((i / num) * distanceToTargetPos) * math.cos(angle), 0, z + ((i / num) * distanceToTargetPos) * math.sin(angle))
	end
	
end



local function icey_killfn(inst,x,y,z)
	if TheWorld:HasTag("cave") or 
	(TheWorld.Map.HasFakeGroundNearBy and TheWorld.Map:HasFakeGroundNearBy(x,y,z)) then 
		inst.components.talker:Say("这里太狭窄了，战舰没办法进入战场。")
		return 
	end 
	local cancast = setcd(inst,"icey_killcd",TUNING.ICEY_KILL_CD_H,"必杀",false,true)
	if cancast ~= true then
		return 
	end 
	print("icey_killfn !")
	
	local mouse = Vector3(x,y,z)
	local my = inst:GetPosition()
	local ship = SpawnPrefab("hyperion_circle")
	ship.Transform:SetPosition(my:Get())
	ship.components.ly_projectile:Throw(inst,mouse,false)
	ship.owner = inst
	ship.owner_id = inst.userid or 0
	
end 

local function icey_killfn_old(inst,x,y,z)
	local myweapon = inst.components.combat:GetWeapon()
	
	if not myweapon then 
		inst.components.talker:Say("我需要一把武器")
		return
	end
	
	local damage = myweapon.components.weapon.damage
	local pos = Vector3(x,y,z)
	local my = inst:GetPosition()
	local dx = pos.x - my.x
	local dz = pos.z - my.z
	local maxdist = 6
	local dist = math.sqrt(dx*dx + dz*dz)
	if dist > maxdist then 
		pos = 
		{
			x =	my.x + maxdist*dx/math.sqrt(dx*dx + dz*dz),
			y = 0,
			z = my.z + maxdist*dz/math.sqrt(dx*dx + dz*dz),
		}
	end 
	
	if not TheWorld.Map:IsPassableAtPoint(pos.x,pos.y,pos.z) then 
	--and not IceyUtil.IsOnWaterAtPoint(pos.x,pos.y,pos.z) then
		inst.components.talker:Say("我做不到")
		return
	end 
	
	if inst.components.stamina and inst.components.stamina.current <= 15 then 
		return 
	end 
	
	local cancast = setcd(inst,"icey_killcd",TUNING.ICEY_KILL_CD_DS,"必杀",false,true)
	if cancast ~= true then
		return 
	end 
	inst:AddTag("un_breakable")
	inst:AddTag("death_slaughter")
	local num = 5
	local time = 0.3
	inst.components.stamina:DoDelta(-15)
	inst.components.stamina:Pause(1)
	MakeTrail2(inst, inst, pos)
	inst.Physics:Teleport(pos.x,pos.y,pos.z)
	--inst.sg:GoToState("attack")
	inst.AnimState:PlayAnimation("atk")
	local ents    = TheSim:FindEntities(pos.x,pos.y,pos.z, 4, {"_combat"},TUNING.ICEY_NO_TAGS)
	inst:StartThread(function()		
		inst.components.health:SetInvincible(true)
		for k,v in pairs(ents) do
			if canattack(v,inst) then
				local eny = v:GetPosition()
				--MakeTrail2(inst, inst, eny)
				--inst.Physics:Teleport(eny.x+math.random(0.5,-0.5),eny.y,eny.z+math.random(0.5,-0.5))
				--inst:ForceFacePoint(eny.x,eny.y,eny.z)
				--inst.sg:GoToState("attack")
				inst:Hide()
				--inst.AnimState:PlayAnimation("atk")
				inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon")
				local hitfx = SpawnPrefab("blossom_hit_fx")
				local killfx = SpawnPrefab("icey_kill_fx")
				local mult = (v:HasTag("after_greatmiss") and 1.5 ) or 1
				hitfx.AnimState:SetAddColour(36/256, 210/256, 231/256, 0)
				hitfx.Transform:SetPosition(eny.x,eny.y,eny.z)
				killfx.Transform:SetScale(3,3,3)
				killfx.Transform:SetPosition(eny.x,eny.y,eny.z)
 
				inst:DoTaskInTime(0.1,function()
					if canattack(v,inst) then 
						v.components.combat:GetAttacked(inst, damage * mult)
					end 
					if v.great_set_fx  then --------------------完美死亡进击
						v.great_set_fx:ShutDown()
					end
				end)
				if v.components.health and v.components.health:IsDead() then 
					inst.components.icey_shield:DoDelta(20)
				else
					inst.components.icey_shield:DoDelta(3)
				end
				num = num - 1
				Sleep(time)
				time = time -0.05
			end
			if ((#ents > 0 and k == #ents) or num <= 0 )then
				--MakeTrail2(inst, inst, pos)
				inst.Physics:Teleport(pos.x,pos.y,pos.z)
				inst:Show()
				--inst.AnimState:PlayAnimation("atk_leap")
				if not ((inst.components.health:IsDead() or inst:HasTag("playerghost")) or 
					(inst.sg.currentstate.name == "death"))	 then 
					inst.sg:GoToState("iceyatk_hop",true)
					inst.sg:RemoveStateTag("autopredict")
					inst.sg:AddStateTag("nopredict")
				else
					inst.AnimState:PlayAnimation("atk_leap")
				end 
				local ents2 = TheSim:FindEntities(pos.x,pos.y,pos.z, 2, {"_combat"},TUNING.ICEY_NO_TAGS)
				for _,n in pairs(ents2) do
					if canattack(n,inst) then
						inst:DoTaskInTime(0.4,function()
							local mult = (n:HasTag("after_greatmiss") and 2 ) or 1
							if canattack(n,inst) then
								n.components.combat:GetAttacked(inst, damage * 1.5 * mult)
							end 
							if  n:HasTag("after_greatmiss") then     --------------------完美死亡进击
								n:RemoveTag("after_greatmiss")
							end
							if n.great_set_fx  then 
								n.great_set_fx:ShutDown()
							end
							if n.components.health and n.components.health:IsDead() then 
								inst.components.icey_shield:DoDelta(10)
							else
								inst.components.icey_shield:DoDelta(2)
							end
							inst.SoundEmitter:PlaySound("dontstarve/common/destroy_smoke")
						end)
					end 
				end
				break
			end
			inst:Show()
		end
	end)
	
	inst:DoTaskInTime(1.5,function()
		inst:RemoveTag("un_breakable")
		inst:RemoveTag("death_slaughter")
		inst.components.health:SetInvincible(false)
	end)
end 

local function Icey_OnSacrificeDelta(inst)
	if inst.components.health and inst.components.health:GetPercent() <= 0.1 then 
		--inst.components.health:StopRegen()
		--inst.components.bloomer:PopBloom("overcharge")
		inst.SoundEmitter:KillSound("overcharge_sound")
		if inst.overload_task then 
			inst.overload_task:Cancel()
			inst.overload_task = nil 
		end 
		inst:RemoveTag("overload_fusion")
		inst:RemoveTag("no_shiled_recover")
		inst:RemoveEventCallback("healthdelta",Icey_OnSacrificeDelta)
		inst:RemoveEventCallback("death",Icey_OnSacrificeDeath)
		--inst.components.locomotor.walkspeed = inst.components.locomotor.walkspeed / 2
		--inst.components.locomotor.runspeed = inst.components.locomotor.runspeed / 2 
		inst.components.locomotor:RemoveExternalSpeedMultiplier(inst, "icey_overload_fusion")
		
		print("Sacrifice Stop because of Low health")
	end 
end 

function Icey_OnSacrificeDeath(inst)
	if inst.components.health then 
		--inst.components.health:StopRegen()
	end 
	--inst.components.bloomer:PopBloom("overcharge")
	inst.SoundEmitter:KillSound("overcharge_sound")
	if inst.overload_task then 
		inst.overload_task:Cancel()
		inst.overload_task = nil 
	end 
	inst:RemoveTag("overload_fusion")
	inst:RemoveTag("no_shiled_recover")
	--inst.components.locomotor.walkspeed = inst.components.locomotor.walkspeed / 2
	--inst.components.locomotor.runspeed = inst.components.locomotor.runspeed / 2 
	inst.components.locomotor:RemoveExternalSpeedMultiplier(inst, "icey_overload_fusion")
	inst:RemoveEventCallback("healthdelta",Icey_OnSacrificeDelta)
	inst:RemoveEventCallback("death",Icey_OnSacrificeDeath)
	print("Sacrifice Stop because of Death")
end 

local function DoSacrifice_BigBang(inst)
	local pos = inst:GetPosition()
	local crackle = SpawnPrefab("hammer_mjolnir_crackle")
	local cracklebase = SpawnPrefab("hammer_mjolnir_cracklebase")
	local cracklehit = SpawnPrefab("hammer_mjolnir_cracklehit")
	local cracklehitfx = SpawnPrefab("cracklehitfx")
	local fx1 = SpawnPrefab("groundpoundring_fx")
	local fx2 = SpawnPrefab("groundpound_fx")
	
	ShakeAllCameras(CAMERASHAKE.VERTICAL, .7, .025, 1.25, inst, 40)
	TheWorld:PushEvent("screenflash",0.5)
	inst.SoundEmitter:PlaySound("dontstarve/rain/thunder_close")
	
	fx1.Transform:SetPosition(pos.x,pos.y,pos.z)
	fx2.Transform:SetPosition(pos.x,pos.y,pos.z)
	
	crackle.Transform:SetPosition(pos.x,pos.y,pos.z)
	cracklebase.Transform:SetPosition(pos.x,pos.y,pos.z)
	cracklehit.Transform:SetPosition(pos.x,pos.y,pos.z)
	cracklehitfx.Transform:SetPosition(pos.x,pos.y,pos.z)
		
	crackle.AnimState:SetMultColour(73/255, 240/255, 235/255, 0.9)
	cracklebase.AnimState:SetMultColour(73/255, 240/255, 235/255, 1)
	cracklehit.AnimState:SetMultColour(73/255, 240/255, 235/255, 1)
	cracklehitfx.AnimState:SetMultColour(73/255, 240/255, 235/255, 1)
		
	crackle:ListenForEvent("animover", function(inst) inst:Remove() end )
	cracklebase:ListenForEvent("animover", function(inst) inst:Remove() end )
	cracklehit:ListenForEvent("animover", function(inst) inst:Remove() end )
	cracklehitfx:ListenForEvent("animover", function(inst) inst:Remove() end )
		
	local ents = TheSim:FindEntities(pos.x,pos.y,pos.z,5, {"_combat"},TUNING.ICEY_NO_TAGS)
	for k,v in pairs(ents) do
		if canattack(v,inst)   then
			v.components.combat:GetAttacked(inst,math.random(80,160)) 
		end
	end

end 

local function icey_killfn_sacrifice(inst,x,y,z)
	if inst:HasTag("overload_fusion") then 
		inst.components.talker:Say("过载模式正在使用中")
		return 
	end 
	if inst.components.health and inst.components.health:GetPercent() <= 0.3 then
		inst.components.talker:Say("生命值过低，无法启动超载模式")
		return 
	end 
	local cancast = setcd(inst,"icey_killcd",TUNING.ICEY_KILL_CD_SA,"必杀",false,true)
	if cancast ~= true then
		return 
	end 
	
	--inst.AnimState:PlayAnimation("atk_leap_lag")
	inst:AddTag("un_breakable")
	--inst.components.playercontroller:Enable(false)
	
	inst.SoundEmitter:PlaySound("dontstarve/creatures/eyeballturret/charge")
		
	if inst.HUD and inst.HUD.controls and inst.HUD.controls.iceyui then 
		inst.HUD.controls.iceyui.overload_ui.oncheckfn("show")
	end 
	
	if inst.player_classified and inst.player_classified.show_overload_ui then --------------------检查显示UI
		print("inst.player_classified descriptionfn",inst.player_classified.show_overload_ui)
		inst.player_classified.show_overload_ui:set(tostring("show"))
	end
	
	inst:DoTaskInTime(1.5,function()		
		
		inst:RemoveTag("un_breakable")
		inst.components.playercontroller:Enable(true)
		if inst.components.health and not inst.components.health:IsDead() then 
			inst.components.talker:Say("过载模式：启动")
			--inst.AnimState:PlayAnimation("atk")
			--inst.components.bloomer:PushBloom("overcharge", "shaders/anim.ksh", 50)
			DoSacrifice_BigBang(inst)
			inst.components.icey_shield:SetPercent(0)
			inst:AddTag("overload_fusion")
			inst:AddTag("no_shiled_recover")
			--inst.components.health:StartRegen(-1,0.3)
			--inst.components.locomotor.walkspeed = inst.components.locomotor.walkspeed * 2
			--inst.components.locomotor.runspeed = inst.components.locomotor.runspeed * 2 
			inst.components.locomotor:SetExternalSpeedMultiplier(inst, "icey_overload_fusion",2)
			if inst.overload_task == nil then 
				inst.overload_task = inst:DoPeriodicTask(0.3,function()
					local mx,my,mz = inst:GetPosition():Get()
					inst.SoundEmitter:KillSound("overcharge_sound")
					inst.SoundEmitter:PlaySound("dontstarve/characters/wx78/charged", "overcharge_sound")
					--local spark = SpawnPrefab("sparks")
					--spark.entity:SetParent(inst.entity)   
					--spark.Transform:SetPosition(0,1 + math.random() * 1.5, 0)
					local spark = SpawnPrefab("electrichitsparks")
					spark:AlignToTarget(inst, inst, true)
					spark.entity:SetParent(inst.entity)   
					spark.Transform:SetPosition(0,0.7 + math.random()*0.5 , 0)
					
					inst.components.health:DoDelta(-1)
					if inst.components.stamina then 
						inst.components.stamina:DoDelta(30)
					end
				end)
			end
			inst:ListenForEvent("healthdelta",Icey_OnSacrificeDelta)
			inst:ListenForEvent("death",Icey_OnSacrificeDeath)
		end
	end)
	
	inst:DoTaskInTime(2.4,function()
		if inst.HUD and inst.HUD.controls and inst.HUD.controls.iceyui then 
			inst.HUD.controls.iceyui.overload_ui.oncheckfn("hide")
		end 
	
		if inst.player_classified and inst.player_classified.show_overload_ui then --------------------检查显示UI
			print("inst.player_classified descriptionfn",inst.player_classified.show_overload_ui)
			inst.player_classified.show_overload_ui:set(tostring("hide"))
		end
	end)
end 

local function icey_killfn_soul(inst,x,y,z)
	local mx,my,mz = inst:GetPosition():Get()
	local souls = TheSim:FindEntities(mx,my,mz,15,{"icey_soul_projectile"})
	
	if #souls <= 0 then
		if not inst.sg:HasStateTag("icey_skill_soul_torrent") then 
			inst.components.talker:Say("附近的灵魂碎片太少了，无法发动这个技能。")
		end 
		return
	end 
	local cancast = setcd(inst,"icey_killcd",TUNING.ICEY_KILL_CD_SOUL,"必杀",false,true)
	if cancast ~= true then
		return 
	end 

	for k,v in pairs(souls) do 
		v:RemoveTag("icey_soul_projectile")
		v.components.projectile:Throw(v, inst, v)
	end
	inst.sg:GoToState("icey_skill_soul_torrent",#souls)
end 
local function icey_killfn_all(inst,x,y,z)
	if inst.hyperion == 1 then 
		icey_killfn(inst,x,y,z)
	elseif inst.death_slaughter == 1 then 
		icey_killfn_old(inst,x,y,z)
	elseif inst.sacrifice == 1 then 
		icey_killfn_sacrifice(inst,x,y,z)
	elseif inst.soul_torrent == 1 then 
		icey_killfn_soul(inst,x,y,z)
	elseif inst.components.talker then
		inst.components.talker:Say("我还没学会任何一种必杀技,等我的等级大于等于4级以后就行了")
	end
end 



local function CanParryDamage(inst,attacker,damage,weapon,stimuli)
	if not attacker then 
		return 
	end
	local myangle = inst:GetRotation() ---get我的角度
	local attackerangle = inst:GetAngleToPoint(attacker:GetPosition():Get()) ---get我到目标的角度
	local deltaangle = math.abs(myangle - attackerangle)----角度差
	local current_level = inst.components.icey_level:GetCurrentLevel()
	if deltaangle > 180 then 
		deltaangle = 360 - deltaangle
	end
	--print("CanParryDamage:",)
	return inst.sg:HasStateTag("parrying") and inst.parry_damage <= inst.max_parry_damage 
	and  deltaangle <= 75 and stimuli ~= "electric" and damage <= 11 + current_level * 14
	and (inst.components.stamina == nil or inst.components.stamina.current >= damage/2)
end 

local function redirectdamagefn(inst, attacker, damage, weapon, stimuli)
	inst.parry_damage = inst.parry_damage + damage
	return CanParryDamage(inst, attacker, damage, weapon, stimuli) and inst.components.combat:GetWeapon() or nil 
end 

local function icey_parry_startfn(inst,x,y,z)
	local weapon = inst.components.combat:GetWeapon()
	if not HasOneOfTags(weapon,{"icey_blade","heavy_blade"}) then 
		return 
	end 
	if inst.sg:HasStateTag("preparrying") or inst.sg:HasStateTag("parrying") or inst.sg:HasStateTag("busy") then 
		return
	end 
	if inst.components.rider and inst.components.rider:IsRiding() then 
		return
	end 
	local cancast = setcd(inst,"icey_parrycd",TUNING.ICEY_PARRY_CD,"开始格挡",false)
	if cancast ~= true then
		return 
	end 
	--local fx = SpawnPrefab("icey_reticulearc")
	--fx.Transform:SetPosition(inst:GetPosition():Get())
	--fx:ForceFacePoint(x,y,z)
	--inst.ParryFx = fx 
	inst:ForceFacePoint(x,y,z)
	--inst.sg:GoToState("parry_pre")
	--inst:PushEvent("icey_parry_pre",{facepos = Vector3(x,y,z)})
	inst.sg:GoToState("icey_parry_pre",{facepos = Vector3(x,y,z)})
	inst.sg:AddStateTag("parrying")
	inst:AddTag("great_parrying") --------完美防御
	if inst.CancelGeratParryingTask then 
		inst.CancelGeratParryingTask:Cancel()
	end 
	inst.CancelGeratParryingTask = inst:DoTaskInTime(0.5,function()--------完美防御持续时间是0.5秒
		inst:RemoveTag("great_parrying")
		inst.CancelGeratParryingTask = nil 
	end)
	inst.sg.statemem.parrytime = 99999
    inst.sg.statemem.item = weapon
	inst.components.combat.redirectdamagefn = redirectdamagefn
	
	if inst.components.stamina then 
		inst.components.stamina.externalrecoverratemultipliers:SetModifier(inst,0.2,"parrying")
	end
end 

local function icey_parry_loopfn(inst,x,y,z,entity)
	inst:ForceFacePoint(x,y,z)
end 

local function icey_parry_overfn(inst,x,y,z)
	inst:RemoveTag("great_parrying")
	if inst.CancelGeratParryingTask then 
		inst.CancelGeratParryingTask:Cancel()
		inst.CancelGeratParryingTask = nil 
	end 
	inst.components.combat.redirectdamagefn = nil 
	if inst.sg:HasStateTag("parrying") then 
		inst.AnimState:PlayAnimation("parry_pst")
		inst.sg:GoToState("idle", true)
	end 
	if inst.ParryFx and inst.ParryFx:IsValid() then 
		inst.ParryFx:Remove()
		inst.ParryFx = nil 
	end 
	if inst.ClearParryDamageTask then 
		inst.ClearParryDamageTask:Cancel()
	end 
	inst.ClearParryDamageTask = inst:DoTaskInTime(0.45,function()
		inst.parry_damage = 0
		inst.ClearParryDamageTask = nil 
	end)
	if inst:HasTag("great_parrying_attack") then 
		--inst.sg:GoToState("iceyatk_lunge")
		if  canattack(inst.GreatParryingTarget,inst) then 
			--inst:GetBufferedAction().target = inst.GreatParryingTarget
			local weapon = inst.components.combat:GetWeapon()
			local newdamage = weapon and weapon.components.weapon.damage or 20
			local dist = math.sqrt(inst:GetDistanceSqToInst(inst.GreatParryingTarget))
			if dist > 4 then 
				--local pos = inst.GreatParryingTarget:GetPosition()
				--MakeTrail2(inst,inst,pos,dist*2)
				--inst.Transform:SetPosition(pos:Get())
				local mypos = inst:GetPosition()
				local targetpos = inst.GreatParryingTarget:GetPosition()
				local towards = targetpos - mypos
				local length = math.sqrt(towards.x*towards.x + towards.y*towards.y +towards.z*towards.z ) / dist
				towards = Vector3(-towards.x/length,-towards.y/length,-towards.z/length)
				
				--inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/trails/hide_pre")
				local shadow = SpawnPrefab("icey_shadow3")
				shadow:SetHitSound("dontstarve/creatures/lava_arena/trails/hide_pre")
				shadow:SetSpeed(dist/(3*FRAMES))
				shadow:SetPosition(targetpos,towards)
				shadow:SetDamage(newdamage)
				shadow:SetTarget(inst.GreatParryingTarget)
				shadow:Init(inst)
			else
				inst.GreatParryingTarget.components.combat:GetAttacked(inst,newdamage*2)
			end 
				inst.sg:GoToState("iceyatk_lunge",{target = inst.GreatParryingTarget})
				inst.sg:RemoveStateTag("autopredict")
				inst.sg:AddStateTag("nopredict")
				if inst.battle_focus == 1 and inst.components.focus then 
					inst.components.focus:DoDelta(7)
				end
			--inst.GreatParryingTarget.components.combat:GetAttacked(inst,40)
		end
	end
	inst.GreatParryingTarget = nil 
	
	if inst.components.stamina then 
		inst.components.stamina.externalrecoverratemultipliers:RemoveModifier(inst,"parrying")
	end
end 

local function canbullethit(inst,owner,target)
	return canattack(target,owner)
end 

local function icey_podshoot_loop(inst,x,y,z,entity)
	--print("icey_podshoot_loop")
	--[[local bullet = SpawnPrefab("fireball_projectile")
	if not bullet.components.ly_projectile then 
		bullet:AddComponent("ly_projectile")
	end 
	inst:ForceFacePoint(x,y,z)
	bullet.Transform:SetPosition(inst:GetPosition():Get())
	bullet.components.ly_projectile:CopyFrom()
	bullet.components.ly_projectile:SetCanHit(canbullethit)
	bullet.components.ly_projectile:Throw(inst,Vector3(x,y,z),true)
	inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_firestaff")--]]
	--print("Ready to shoot:",x,y,z)
	
	local mypos = inst:GetPosition()
	local targetpos = Vector3(x,y,z)
	
	inst.components.poduser:Shoot(targetpos)
	if inst.death_machinegun == 1 then 
		local vec = targetpos - mypos
		local vec_vertical = Vector3(-vec.z,0,vec.x):GetNormalized()
		local extra_length = math.abs(math.tan(math.pi/15) * vec:Length())
		local offset = vec_vertical * extra_length
		inst.components.poduser:Shoot(targetpos+offset)
		inst.components.poduser:Shoot(targetpos-offset)
		inst.components.poduser:TemperatureDoDelta(-1.5)
	end
end 

local function OnPodShoot(inst,data)
	if inst.newton_grave == 1 then 
		local function IsSuitableTarget(target)
			local ret = target and target:IsValid() and target.components.health 
				and not target.components.health:IsDead() and target.components.combat
			if ret then 
				local x,y,z = target.Transform:GetWorldPosition()
				return ret and y <= 1
			end
			return false 
		end 
		local bullet = data.projectile
		if bullet and bullet:IsValid() then 
			bullet:DoPeriodicTask(0,function()
				if not (IsSuitableTarget(bullet.target)) then 
					
					bullet.target = FindEntity(bullet,6,function(guy)
						return IceyUtil.CanAttack(guy,inst) and (
							guy:HasTag("hostile") or guy.components.combat:TargetIs(inst)
						)
					end,{"_combat"},{"INLIMBO"})
				else
					local bullet_rota = bullet:GetRotation() 
					local angle_to_target = bullet:GetAngleToPoint(bullet.target:GetPosition():Get())
					local rotation_delta = angle_to_target - bullet_rota
					local normalize_delta = (rotation_delta > 0 and 1) or (rotation_delta < 0 and -1) or 0 
					local final_delta = 0
					if rotation_delta >= 0 then 
						final_delta = math.min(rotation_delta,normalize_delta*15)
					else
						final_delta = math.max(rotation_delta,normalize_delta*15)
					end
					
					bullet.Transform:SetRotation(bullet_rota + final_delta)
					--bullet:ForceFacePoint(bullet.target:GetPosition():Get())
				end 
			end)
		end
	end
end 

local function SiFangKillfn(inst,x,y,z,entity)
	local mypos = inst:GetPosition()
	local weapon = inst.components.combat:GetWeapon()
	local colour = {4/255, 231/255, 251/255,0.7}
	if not (weapon and weapon:IsValid()) then 
		return 
	end 
	for rota = 0,270,90 do 
		local shadow = SpawnPrefab("icey_shadow4")
		local shadowweapon = SpawnPrefab(weapon.prefab)
		local myrota = inst.Transform:GetRotation()
		shadowweapon.Transform:SetPosition(mypos:Get())
		shadow.owner = inst 
		shadow.Transform:SetPosition(mypos:Get())
		shadow.components.inventory:Equip(shadowweapon)
		shadow.Transform:SetRotation(myrota + rota)
		shadow.components.colouradder:PushColour("charge",unpack(colour) )
		--shadow.AnimState:SetMultColour(4/255, 231/255, 251/255,1)
		shadow.AnimState:PlayAnimation("atk_leap_lag")
		--shadow.AnimState:PushAnimation("lunge_lag",false)
		shadow.Physics:SetMotorVel(15, 0, 0)
		inst.SoundEmitter:PlaySound("dontstarve/common/destroy_metal")
		shadow:DoTaskInTime(0.5,function()
			if shadow:IsOnValidGround() then 
				shadow.Physics:Stop()
			else
				local fx = SpawnPrefab("blossom_hit_fx")
				local x,y,z = shadow:GetPosition():Get()
				fx.AnimState:SetMultColour(4/255, 231/255, 251/255, 0.7)
				fx.Transform:SetPosition(x,y,z)
				shadow:Remove()
			end 
		end)
		shadow:DoTaskInTime(5,shadow.Remove)
	end
end 

local TimeStopAddColour = {34/255,0/255,57/255,1}
local TimeStopMultColour = {124/255,0/255,255/255,1}

local function OnSingleStopTime(inst,target,delay,stopped_components,isTheWorld)
	--[[if target and target:HasTag("_combat")  then 
		if target.SoundEmitter then 
			target.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/enemy/metal_robot/smash")
		end 
		local fx = SpawnPrefab("laser_ring")
		fx:AddTag("NO_TIME_STOP")
		fx.Transform:SetPosition(target:GetPosition():Get())
		ShakeAllCameras(CAMERASHAKE.FULL, .35, .02, 1, inst, 40)
	end --]]
	
	if target and target:IsValid() and not target:HasTag("shadow") then 
		--[[if target.components.bloomer ~= nil then
            target.components.bloomer:PushBloom(inst, "shaders/anim.ksh", -1)
        elseif target.AnimState then 
            target.AnimState:SetBloomEffectHandle("shaders/anim.ksh")
        end
		
		if target.components.colouradder ~= nil then
            target.components.colouradder:PushColour(inst, unpack(TimeStopColour))
        elseif target.AnimState then 
            target.AnimState:SetMultColour(unpack(TimeStopColour))
        end--]]
		if target.AnimState then 
			target.oldMultColour_timestop = {target.AnimState:GetMultColour()}
			target.AnimState:SetMultColour(unpack(TimeStopMultColour))
		end 
	end
end 

local function OnSingleResumeTime(inst,target,delay,stopped_components)
	if target and target:IsValid() and not target:HasTag("shadow") then 
		--[[if target.components.colouradder == nil then
            if target.components.freezable ~= nil then
                target.components.freezable:UpdateTint()
            end
        end
        if target.components.bloomer == nil and target.AnimState then
            target.AnimState:ClearBloomEffectHandle()
        end--]]
		if target.AnimState then 
			if target.oldMultColour_timestop then 
				target.AnimState:SetMultColour(unpack(target.oldMultColour_timestop))
			else
				target.AnimState:SetMultColour(1,1,1,1)
			end
		end 
	end
end 

local function OnTheWorld(inst,pos,radius,delay)
	local scale = radius / 10
	local timecrack = SpawnPrefab("timecrack")
	timecrack.AnimState:SetAddColour(unpack(TimeStopAddColour))
	timecrack.Transform:SetScale(scale,scale,scale)
	timecrack.Transform:SetPosition(pos:Get())
	timecrack:DoTaskInTime(delay,timecrack.KillFx)
	
	if inst.SoundEmitter then 
		inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/enemy/metal_robot/smash")
	end 
	local fx = SpawnPrefab("laser_ring")
	fx:AddTag("NO_TIME_STOP")
	fx.Transform:SetPosition(pos:Get())
	fx.Transform:SetScale(1.5,1.5,1.5)
	ShakeAllCameras(CAMERASHAKE.FULL, .35, .02, 1, inst, 40)
end 

local function TimeStoperTest(inst,target)
	return not target:HasTag("icey_pod") --and not target:HasTag("hyperion_circle") and not target:HasTag("hyperion_laser")  
end 

local function icey_theworld(inst)
	inst.components.timestoper:TheWorld()
end 


local function icey_sneaking(inst)
	if inst.components.iceysneaker and not (inst.components.icey_swimmer and inst.components.icey_swimmer:IsSwimming()) then 
		if inst.components.iceysneaker:IsSneaking() then 
			inst.components.iceysneaker:StopSneak()
		else
			inst.components.iceysneaker:StartSneak() 
		end
	end
end 

local function deadcell_flyheadfn(inst,x,y,z)
	if inst.components.deadcellpassive_flyhead:IsFlyingHead() then 
		inst.components.deadcellpassive_flyhead:StopFlyHead()
	else
		inst.components.deadcellpassive_flyhead:StartFlyHead(Vector3(x,y,z))
	end
end 

--[[local function icey_rightbutton_down(inst,x,y,z,entity)
	if inst.components.icey_ironlord:IsIronLord() then 
		local cancast = setcd(inst,"icey_ironshootcd",0.33,"钢铁射击",false)
		if cancast ~= true then
			return 
		end 
		--inst:PushEvent("rightbuttondown")
		DefaultFaceClient(inst,x,y,z,entity)
		inst.components.icey_ironlord:StartCharge() 
	end 
end 

local function icey_rightbutton_loop(inst,x,y,z,entity)
	if inst.components.icey_ironlord:IsIronLord() then 
		DefaultFaceClient(inst,x,y,z,entity)
	end 
end 

local function icey_rightbutton_up(inst,x,y,z,entity)
	if inst.components.icey_ironlord:IsIronLord() then 
		--inst:PushEvent("rightbuttonup")
		DefaultFaceClient(inst,x,y,z,entity)
		inst.components.icey_ironlord:Shoot(Vector3(x,y,z)) 
	end 
end --]]

--[[local function ReBuildRPC()----------------可以清空过量的RPC并重新添加正确RPC
	MOD_RPC["icey"] = nil   
	--MOD_RPC["issac"] = nil   
	if TheNet:GetIsClient() then  
		AddModRPCHandler("icey","icey_miss",function() end)
		AddModRPCHandler("icey","icey_kill",function() end)
		AddModRPCHandler("icey","icey_sifangkill",function() end)
		AddModRPCHandler("icey","icey_parry_start",function() end)
		AddModRPCHandler("icey","icey_parry_loop",function() end)  
		AddModRPCHandler("icey","icey_parry_over",function() end)
		AddModRPCHandler("icey","icey_podshoot_loop",function() end)
		AddModRPCHandler("icey","icey_theworld",function() end)
		AddModRPCHandler("icey","icey_sneaking",function() end)
		
		AddModRPCHandler("icey","icey_rightbutton_down",function() end)
		AddModRPCHandler("icey","icey_rightbutton_loop",function() end)
		AddModRPCHandler("icey","icey_rightbutton_up",function() end)
	end  
	print("RPC BUILD FINISHED!",TheWorld.ismastersim,TheNet:GetIsClient())  
end--]]

-------------在这里添加RPC比较合适
if  TheNet:GetIsServer() then 
	AddModRPCHandler("icey","icey_miss",icey_missfn)
	AddModRPCHandler("icey","icey_kill",icey_killfn_all)
	AddModRPCHandler("icey","icey_sifangkill",SiFangKillfn)
	AddModRPCHandler("icey","icey_parry_start",icey_parry_startfn)
	AddModRPCHandler("icey","icey_parry_loop",icey_parry_loopfn)
	AddModRPCHandler("icey","icey_parry_over",icey_parry_overfn)
	AddModRPCHandler("icey","icey_podshoot_loop",icey_podshoot_loop)
	AddModRPCHandler("icey","icey_theworld",icey_theworld)
	AddModRPCHandler("icey","icey_sneaking",icey_sneaking)
	AddModRPCHandler("icey","deadcell_flyhead",deadcell_flyheadfn)
	--AddModRPCHandler("icey","icey_rightbutton_down",icey_rightbutton_down)
	--AddModRPCHandler("icey","icey_rightbutton_loop",icey_rightbutton_loop)
	--AddModRPCHandler("icey","icey_rightbutton_up",icey_rightbutton_up)
else
	AddModRPCHandler("icey","icey_miss",function() end)
	AddModRPCHandler("icey","icey_kill",function() end)
	AddModRPCHandler("icey","icey_sifangkill",function() end)
	AddModRPCHandler("icey","icey_parry_start",function() end)
	AddModRPCHandler("icey","icey_parry_loop",function() end)  
	AddModRPCHandler("icey","icey_parry_over",function() end)
	AddModRPCHandler("icey","icey_podshoot_loop",function() end)
	AddModRPCHandler("icey","icey_theworld",function() end)
	AddModRPCHandler("icey","icey_sneaking",function() end)
	AddModRPCHandler("icey","deadcell_flyhead",function() end)
	
	--AddModRPCHandler("icey","icey_rightbutton_down",function() end)
	--AddModRPCHandler("icey","icey_rightbutton_loop",function() end)
	--AddModRPCHandler("icey","icey_rightbutton_up",function() end)
end




-- This initializes for both the server and client. Tags can be added here.
local common_postinit = function(inst) 
	-- Minimap icon
	inst.MiniMapEntity:SetIcon( "icey.tex" )
	inst:AddTag("icey")
	------------------------------------------	
	
	inst.icey_misscd = 0
	inst.icey_killcd = 0
	inst.icey_parrycd = 0
	
	
	
	inst.dangerouscd = 0
	inst.chargecd = 0
	inst.go_hidecd = 0
	inst.dark_chargecd = 0
	inst.witch_timecd = 0
	
	--inst.icey_ironshootcd = 0

	inst.GetTime = GetTime()


	
	--inst.icey_level = 1
	--inst.icey_exp = 0
	--inst.icey_levelup_exp = inst.icey_level * 100
	
	inst.icey_miss_num = 0    ----------闪避次数充能
	inst.icey_max_miss_num = 1 
	
	inst.parry_damage = 0 --------合计格挡的伤害
	inst.max_parry_damage = 200 --------合计格挡的伤害的上限
	
	----------------------------------------------------------------------------下面全是技能，小心花眼

	
	InitAllSkill(inst)
	
	inst.icey_atk_change_cd = 0 ----攻击行为切换
	inst.icey_soundname = TUNING.ICEY_GAL_CV
	
	--inst.sneaker_vision = false 
	
	----------------------------------------------------------------------------前面加_的伪变量

	
	--inst._icey_level = net_shortint(inst.GUID,"_icey_level","icey_guid_event")
	--inst._icey_exp = net_shortint(inst.GUID,"_icey_exp","icey_guid_event")
	--inst._icey_levelup_exp = net_shortint(inst.GUID,"_icey_levelup_exp","icey_guid_event")
	
	
	
	inst._icey_misscd = net_shortint(inst.GUID,"_icey_misscd","icey_guid_event")
	inst._icey_killcd = net_shortint(inst.GUID,"_icey_killcd","icey_guid_event")
	
	inst._GetTime = net_shortint(inst.GUID,"_GetTime","icey_guid_event")
	
	inst._icey_miss_num = net_shortint(inst.GUID,"_icey_miss_num","icey_guid_event")
	inst._icey_max_miss_num = net_shortint(inst.GUID,"_icey_max_miss_num","icey_guid_event")
	
	inst._icey_soundname = net_string(inst.GUID,"_icey_soundname","icey_guid_event")
	
	----------------------------------------------------------------------------
	AddReplicableComponent("iceysneaker")
	
	MakeInventoryFloatable(inst, "med", 1)
	--RemovePhysicsColliders(inst)
	
	inst:AddComponent("icey_swimmer")
	--inst.components.icey_swimmer:SetOnStartSwim(OnStartSwim)
	--inst.components.icey_swimmer:SetOnStopSwim(OnStopSwim)
	
--[[	local old_OnLandedClient = inst.components.floater.OnLandedClient
	inst.components.floater.OnLandedClient = function(self,...)
		old_OnLandedClient(self,...)
		self.inst.DynamicShadow:Enable(false)
		self.inst.AnimState:SetFloatParams(0.45, 1.0,0.5)
	end 
	
	local old_OnNoLongerLandedClient = inst.components.floater.OnNoLongerLandedClient
	inst.components.floater.OnNoLongerLandedClient = function(self,...)
		old_OnNoLongerLandedClient(self,...)
		self.inst.DynamicShadow:Enable(true)
	end--]]
	
	if TheWorld.ismastersim then
		
	else
		inst:ListenForEvent("icey_guid_event",updateall)
	end
	
	inst:AddComponent("icey_keyhandler")	
	inst.components.icey_keyhandler:AddActionListener(TUNING.ICEY_MISS_KEY,{Namespace = "icey",Action = "icey_miss"},nil,DefaultFaceClient)
	inst.components.icey_keyhandler:AddActionListener(TUNING.ICEY_KILL_KEY,{Namespace = "icey",Action = "icey_kill"},nil,DefaultFaceClient)
	--inst.components.icey_keyhandler:AddActionListener(KEY_F1,{Namespace = "icey",Action = "icey_theworld"},nil,DefaultFaceClient)
	--inst.components.icey_keyhandler:AddActionListener(KEY_F1,{Namespace = "icey",Action = "icey_sifangkill"},nil,DefaultFaceClient)
	--inst.components.icey_keyhandler:AddActionListener(TUNING.ICEY_PARRY_KEY,{Namespace = "icey",Action = "icey_parry_start"},true)
	--inst.components.icey_keyhandler:AddActionListener(TUNING.ICEY_PARRY_KEY,{Namespace = "icey",Action = "icey_parry_over"})
	inst.components.icey_keyhandler:AddActionListener(TUNING.ICEY_SNEAK_KEY,{Namespace = "icey",Action = "icey_sneaking"})
	inst.components.icey_keyhandler:AddActionListenerWhileDown(TUNING.ICEY_PARRY_KEY,{Namespace = "icey",Action = "icey_parry_start"},{Namespace = "icey",Action = "icey_parry_loop"},{Namespace = "icey",Action = "icey_parry_over"},0,{keepfn = DefaultFaceClient})
	inst.components.icey_keyhandler:AddActionListenerWhileDown(TUNING.ICEY_PODSHOOT_KEY,nil,{Namespace = "icey",Action = "icey_podshoot_loop"},nil,0.15)
	--inst.components.icey_keyhandler:AddMouseActionListener(MOUSEBUTTON_RIGHT,{Namespace = "icey",Action = "icey_rightbutton_down"},true,DefaultFaceClient)
	--inst.components.icey_keyhandler:AddMouseActionListener(MOUSEBUTTON_RIGHT,{Namespace = "icey",Action = "icey_rightbutton_up"},false,DefaultFaceClient)
	--inst.components.icey_keyhandler:AddMouseActionListenerWhileDown(MOUSEBUTTON_RIGHT,{Namespace = "icey",Action = "icey_rightbutton_down"},{Namespace = "icey",Action = "icey_rightbutton_loop"},{Namespace = "icey",Action = "icey_rightbutton_up"},0,{keepfn = DefaultFaceClient})
	inst.components.icey_keyhandler:AddActionListener(TUNING.ICEY_FLYHEAD_KEY,{Namespace = "icey",Action = "deadcell_flyhead"})

	--inst:AddComponent("timer")

	
	--inst.rebuild_rpcfn = ReBuildRPC
	inst.getstring = GetString--(inst,list)
	inst.CanParryDamage = CanParryDamage
	inst.CanAttack = canattack
	inst.apply_skills = apply_skills
	inst.reset_skills = reset_skills
	--TheInput:AddKeyDownHandler(KEY_F11, ReBuildRPC)
	
	
end

-- This initializes for the server only. Components are added here.
local master_postinit = function(inst)
	-- choose which sounds this character will play
	
	inst.soundsname = "wendy"
	--inst:RemoveComponent("drownable")
	
	inst:DoTaskInTime(0,function()
		if inst.components.drownable then 
			inst.components.drownable:SetShouldDrownTest(ShouldDrownTest)
		end 
	end)
	
	inst:AddComponent("deadcellpassive_flyhead")
	
	
	inst:AddComponent("icey_shield")
	inst.components.icey_shield:SetOnShieldChangeFn(OnShieldChange)
	inst.components.icey_shield:SetOnPowerUpFn(OnShieldPowerUp)
	inst.components.icey_shield:SetCalcBaseFn(OnCalcShieldBase)
	
	inst:AddComponent("icey_level")
	inst.components.icey_level:SetOnLevel(OnSetLevel)
	inst.components.icey_level:SetOnExp(OnSetExp)
	
	inst:AddComponent("poduser")
	inst.components.poduser:SetCanHit(canbullethit)
	
	inst:AddComponent("timestoper")
	inst.components.timestoper:SetOnSingleStopTime(OnSingleStopTime)
	inst.components.timestoper:SetOnSingleResumeTime(OnSingleResumeTime)
	inst.components.timestoper:SetOnTheWorld(OnTheWorld)
	inst.components.timestoper:SetTimeStoperTest(TimeStoperTest)
	--inst.components.timestoper:SetOnSingleStopTime()
	
	inst:AddComponent("iceysneaker")
	
	
	inst.components.health:SetMaxHealth(75)
	inst.components.hunger:SetMax(150)
	inst.components.sanity:SetMax(120)
    --inst.Transform:SetScale(1.3, 1.3, 1.3)
	--inst.components.builder.science_bonus = 1
	
	inst.components.locomotor.walkspeed = 4
	inst.components.locomotor.runspeed = 6

	inst.components.sanity.rate_modifier = 1    
	-- Damage multiplier (optional)
    inst.components.combat.damagemultiplier = 1.0
	
	-- Hunger rate (optional)
	inst.components.hunger.hungerrate = 1.0 * TUNING.WILSON_HUNGER_RATE
	
	inst.components.eater:SetOnEatFn(oneat)
	inst.components.eater:SetDiet({FOODGROUP.OMNI, FOODTYPE.ICEY_BATTERY})
	
	local old_Eat = inst.components.eater.Eat
	inst.components.eater.Eat = function(self,food, feeder)
		if food and food.components.edible and food.components.edible.foodtype ~= FOODTYPE.ICEY_BATTERY then 
			local health_mult = food.components.edible.healthvalue > 0 and 0.8 or 1 
			local hunger_mult = food.components.edible.hungervalue > 0 and 0.8 or 1 
			local sanity_mult = food.components.edible.sanityvalue > 0 and 0.8 or 1 
			self:SetAbsorptionModifiers(health_mult,hunger_mult,sanity_mult)
			local ret = old_Eat(self,food, feeder)
			self:SetAbsorptionModifiers(1,1,1)
			return ret
		else
			return old_Eat(self,food, feeder) 
		end 
	end 
	
	local oldDoAreaAttack = inst.components.combat.DoAreaAttack
	inst.components.combat.DoAreaAttack = function(self,target, range, weapon, validfn, stimuli, excludetags)
		local old_validfn = validfn
		validfn = function(enemy)
			return (old_validfn == nil or old_validfn(enemy)) and IceyUtil.CanAttack(enemy,inst)
		end
		return oldDoAreaAttack(self,target, range, weapon, validfn, stimuli, excludetags)
	end
	
	---------------------------


	inst:ListenForEvent("onhitother", onattack)
	inst:ListenForEvent("preattacked", OnPreAttacked)
	inst:ListenForEvent("attacked", OnAttacked)
	inst:ListenForEvent("death", ondeath)
	inst:ListenForEvent("picksomething", onwork)  
	inst:ListenForEvent("builditem", onwork)
	inst:ListenForEvent("buildstructure", onwork)
	inst:ListenForEvent("newcombattarget",AddRandomAtkTag)
	inst:ListenForEvent("equip",RemoveAllAtkTags)
	inst:ListenForEvent("unequip",RemoveAllAtkTags)
	inst:ListenForEvent("podshoot",OnPodShoot)
	inst:ListenForEvent("healthdelta",OnHealthDelta)
	
	inst._icey_soundname:set(inst.icey_soundname)
	
	
	inst:DoTaskInTime(0,apply_skills)
	--inst:DoPeriodicTask(0,UpdateFloater)
	inst:DoPeriodicTask(0, function()inst.GetTime = GetTime() inst._GetTime:set(inst.GetTime) end) -----------MDZZ
	--inst:DoPeriodicTask(2, function()if inst.quick_shield == 1 then inst.components.icey_shield:DoDelta(1)end end)--快速充能
	inst:DoPeriodicTask(3,function() 
		inst.icey_miss_num = inst.icey_miss_num + 1  
		inst.icey_miss_num = math.min(inst.icey_max_miss_num,inst.icey_miss_num)
		inst._icey_miss_num:set(inst.icey_miss_num)
		inst._icey_max_miss_num:set(inst.icey_max_miss_num)
	end)
	
	--ExpDoDelta(inst,0)
	inst.OnSave = onsave
	inst.OnLoad = onload
    inst.OnNewSpawn = OnNewSpawn
	--inst:SetStateGraph("SGicey")
end
-------------------------------------------------------------特效
local function FastForwardFX(inst, pct)
  if inst._task ~= nil then
    inst._task:Cancel()
  end
  local len = inst.AnimState:GetCurrentAnimationLength()
  pct = math.clamp(pct, 0, 1)
  inst.AnimState:SetTime(len * pct)
  inst._task = inst:DoTaskInTime(len * (1 - pct) + 2 * FRAMES, inst.Remove)
end

--[[local function SetMotionFX(inst, dx, dy, dz)
    inst.Physics:SetMotorVel(dx, dy, dz)
end]]

local function fxfn()
  local inst = CreateEntity()

  inst.entity:AddTransform()
  inst.entity:AddAnimState()
  --inst.entity:AddPhysics()
  inst.entity:AddNetwork()

  --[[inst.Physics:SetMass(1)
  inst.Physics:CollidesWith(COLLISION.GROUND)
  inst.Physics:SetSphere(.2)]]

  inst:AddTag("FX")
  inst:AddTag("NOCLICK")

  inst.AnimState:SetBank("lavaarena_staff_smoke_fx")
  inst.AnimState:SetBuild("lavaarena_staff_smoke_fx")
  inst.AnimState:PlayAnimation("idle")
  inst.AnimState:SetAddColour(0, 192/255, 1, 0)
  inst.AnimState:SetBloomEffectHandle("shaders/anim.ksh")

  inst.entity:SetPristine()

  if not TheWorld.ismastersim then
    return inst
  end

  inst.persists = false
  inst._task = inst:DoTaskInTime(inst.AnimState:GetCurrentAnimationLength() + 2 * FRAMES, inst.Remove)

  inst.FastForward = FastForwardFX
  --inst.SetMotion = SetMotionFX

  return inst
end


return MakePlayerCharacter("icey", prefabs, assets, common_postinit, master_postinit, start_inv),
Prefab("spear_gungnir_lungefx", fxfn, assets_fx)

--[[for k,v in pairs(ThePlayer.AnimState) do 
	print(v) 
end --]]
