local assets =
{ 
    --Asset("ANIM", "anim/chest_monster_hat.zip"),
    Asset("ANIM", "anim/swap_chest_monster_hat.zip"), 

    Asset("ATLAS", "images/inventoryimages/chest_monster_hat.xml"),
    Asset("IMAGE", "images/inventoryimages/chest_monster_hat.tex"),
}

local function OnKillOther(owner,data)
	local victim = data.victim
	for i=1,math.random()*2 + 1 do 
		if victim and victim:IsValid() and not victim:HasTag("killed_chest_monster_hat") and  victim.components.lootdropper then 
			victim.components.lootdropper:DropLoot(Vector3(victim.Transform:GetWorldPosition()))      
		end
	end 
	victim:AddTag("killed_chest_monster_hat")    
end 

local function DeltaHealth(inst,hat)
	if inst and inst:IsValid() and inst.components.health and not inst.components.health:IsDead() and not inst:HasTag("playerghost") then
		inst.components.health:DoDelta(-3,nil,hat.prefab,false,nil,true)
	end
end 


local function OnEquip(inst, owner) 
    owner.AnimState:OverrideSymbol("swap_hat", "swap_chest_monster_hat","swap_chest_monster_hat")
    owner.AnimState:Show("HAT")
    owner.AnimState:Show("HAIR_HAT")
    owner.AnimState:Hide("HAIR_NOHAT")
    owner.AnimState:Hide("HAIR")

    if owner:HasTag("player") then
        owner.AnimState:Hide("HEAD")
        owner.AnimState:Show("HEAD_HAT")
    end
	
	if inst.HurtOwnerTask then 
		inst.HurtOwnerTask:Cancel()
		inst.HurtOwnerTask = nil 
	end
	inst.HurtOwnerTask = owner:DoPeriodicTask(1,DeltaHealth,nil,inst)
	inst:ListenForEvent("killed",OnKillOther,owner)
end

local function OnUnequip(inst, owner) 
	owner.AnimState:ClearOverrideSymbol("swap_hat")
    owner.AnimState:Hide("HAT")
    owner.AnimState:Hide("HAIR_HAT")
    owner.AnimState:Show("HAIR_NOHAT")
    owner.AnimState:Show("HAIR")

    if owner:HasTag("player") then
        owner.AnimState:Show("HEAD")
        owner.AnimState:Hide("HEAD_HAT")
    end
	
	if inst.HurtOwnerTask then 
		inst.HurtOwnerTask:Cancel()
		inst.HurtOwnerTask = nil 
	end
	inst:RemoveEventCallback("killed",OnKillOther,owner)
end

local function fn()

    local inst = CreateEntity()
    local trans = inst.entity:AddTransform()
	
    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()  --这个联机也必须加 
	
    MakeInventoryPhysics(inst)	
	inst.AnimState:SetBank("swap_chest_monster_hat")
    inst.AnimState:SetBuild("swap_chest_monster_hat")
    inst.AnimState:PlayAnimation("idle",true)
	
	
	----------------------上面的东西 对主副机都有效
	
	inst.entity:SetPristine()   --这四句话 放到这里 也就是bank build 和tag之类的后面-。-
	if not TheWorld.ismastersim then
        return inst
    end
	
	----------------------下面的只对主机执行
	
    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("我不想把它戴在头上.....")
	
	inst:AddComponent("waterproofer")
	inst.components.waterproofer:SetEffectiveness(TUNING.WATERPROOFNESS_SMALL)


    inst:AddComponent("inventoryitem")
    inst.components.inventoryitem.imagename = "chest_monster_hat"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/chest_monster_hat.xml"
	
    inst:AddComponent("equippable")
    inst.components.equippable.equipslot = EQUIPSLOTS.HEAD 
    inst.components.equippable:SetOnEquip(OnEquip)
    inst.components.equippable:SetOnUnequip(OnUnequip)
	inst.components.equippable.dapperness = -TUNING.DAPPERNESS_MED
	inst.components.equippable.icey_mults = 1.2 
	
	MakeHauntableLaunch(inst)  --这个放后面就好了

    return inst
end

return  Prefab("chest_monster_hat", fn, assets, prefabs)