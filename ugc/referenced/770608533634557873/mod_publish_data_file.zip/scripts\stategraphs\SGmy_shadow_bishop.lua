local ShadowChess = require("stategraphs/SGshadow_chesspieces_my")

--See SGshadow_chesspieces_my.lua for CommonEventList

local SWARM_PERIOD = .5
local SWARM_START_DELAY = .25

local function DoSwarmAttack(inst)
    inst.components.combat:DoAreaAttack(inst, inst.components.combat.hitrange, nil, nil, nil, { "INLIMBO", "notarget", "invisible", "noattack", "flight", "playerghost", "shadow", "shadowchesspiece", "shadowcreature", "shadowminion" })
end

local function DoSwarmFX(inst)
    local fx = SpawnPrefab("shadow_bishop_fx")
    fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
    fx.Transform:SetScale(inst.Transform:GetScale())
    fx.AnimState:SetMultColour(inst.AnimState:GetMultColour())
end

local function DoBallsAttack(inst,target)
	if target and target:IsValid() and target.components.combat then 
		local bullet = SpawnPrefab("blossom_projectile_dark_icey")
		local x,y,z = inst.Transform:GetWorldPosition()
		if not bullet.components.weapon then 
			bullet:AddComponent("weapon")
		end 
		bullet.components.weapon:SetDamage(math.random()*10 + 5)
		bullet.Transform:SetPosition(x,y,z)
		
		--[[bullet.components.projectile:Throw(inst,target)
		
		
		local adds1 = 2 + math.random() * 3
		local adds2 = 2 + math.random() * 3
		if math.random() <= 0.5 then 
			adds1 = -adds1
		end 
		if math.random() <= 0.5 then 
			adds2 = -adds2
		end 
		bullet.Transform:SetPosition(x+adds1,y,z+adds2)--]]
		
		
		local scaler =  2 * (math.random()*2.5 - 1.25)
		local offset = Vector3(math.random(), 0, math.random()):Normalize()*scaler
		local targetpos = target:GetPosition()
		bullet.components.projectile:Throw(inst,target)
		
		bullet.Transform:SetPosition((inst:GetPosition() + offset):Get())
		
		bullet:DoTaskInTime(1,function()
			bullet.components.projectile:SetHoming(false)
		end)
	end
end 

local states =
{
    State{
        name = "attack",
        tags = { "attack", "busy" },

        onenter = function(inst, target)
            if target ~= nil and target:IsValid() then
                inst.sg.statemem.target = target
            end
			inst.AnimState:OverrideSymbol("wing", "swap_alex_blade", "swap_alex_blade")
            inst.Physics:Stop()
            inst.components.combat:StartAttack()
            inst.AnimState:PlayAnimation("taunt")
			inst.SoundEmitter:PlaySound("dontstarve/creatures/eyeballturret/charge")
        end,

        onupdate = function(inst)
            if inst.sg.statemem.target ~= nil then
                if not inst.sg.statemem.target:IsValid() then
                    inst.sg.statemem.target = nil
                end
            end
        end,

        timeline =
        {

			
            TimeEvent(8 * FRAMES, function(inst)
				DoBallsAttack(inst,inst.sg.statemem.target,Vector3(0,0,-6))
                DoSwarmFX(inst)
				inst.SoundEmitter:PlaySound("dontstarve/creatures/eyeballturret/shoot")
                --inst.SoundEmitter:PlaySound(inst.sounds.attack, "attack")
            end),
			
			TimeEvent(16 * FRAMES, function(inst)
				DoBallsAttack(inst,inst.sg.statemem.target)
                DoSwarmFX(inst)
				inst.SoundEmitter:PlaySound("dontstarve/creatures/eyeballturret/shoot")
                --inst.SoundEmitter:PlaySound(inst.sounds.attack, "attack")
            end),
			
			TimeEvent(20 * FRAMES, function(inst)
				--inst.components.combat:DoAttack(inst.sg.statemem.target)
				DoBallsAttack(inst,inst.sg.statemem.target,Vector3(0,0,6))
                DoSwarmFX(inst)
				inst.SoundEmitter:PlaySound("dontstarve/creatures/eyeballturret/shoot")
                --inst.SoundEmitter:PlaySound(inst.sounds.attack, "attack")
            end),
        },

        events =
        {
            EventHandler("animover", function(inst)
                if inst.AnimState:AnimDone() then
					inst.AnimState:OverrideSymbol("wing","shadow_bishop_upg_build", "wing2")
                    inst.sg.statemem.attack = false
					inst.sg:GoToState("taunt")
                end
				inst.SoundEmitter:KillSound("attack")
            end),
        },

        onexit = function(inst)
            if not inst.sg.statemem.attack then
                inst.components.health:SetInvincible(false)
                inst.SoundEmitter:KillSound("attack")
            end
        end,
    },

   
}

ShadowChess.States.AddIdle(states, "idle_loop")
ShadowChess.States.AddLevelUp(states, "transform", 22, 58, 95)
ShadowChess.States.AddTaunt(states, "taunt", 3, 12, 47)
ShadowChess.States.AddHit(states, "hit", 0, 14)
ShadowChess.States.AddDeath(states, "disappear", 20,
{
    ShadowChess.Functions.DeathSoundTimelineEvent(19 * FRAMES),
})
ShadowChess.States.AddEvolvedDeath(states, "death", 25,
{
    ShadowChess.Functions.DeathSoundTimelineEvent(26 * FRAMES),
    ShadowChess.Functions.DeathSoundTimelineEvent(38 * FRAMES),
    ShadowChess.Functions.DeathSoundTimelineEvent(41 * FRAMES),
    ShadowChess.Functions.DeathSoundTimelineEvent(55 * FRAMES),
})
ShadowChess.States.AddDespawn(states, "disappear",
{
    ShadowChess.Functions.DeathSoundTimelineEvent(19 * FRAMES),
})

CommonStates.AddWalkStates(states)

return StateGraph("SGmy_shadow_bishop", states, ShadowChess.CommonEventList, "idle")
