local assets =
{

        Asset( "ANIM", "anim/player_basic.zip" ),
        Asset( "ANIM", "anim/player_idles_shiver.zip" ),
        Asset( "ANIM", "anim/player_actions.zip" ),
        Asset( "ANIM", "anim/player_actions_axe.zip" ),
        Asset( "ANIM", "anim/player_actions_pickaxe.zip" ),
        Asset( "ANIM", "anim/player_actions_shovel.zip" ),
        Asset( "ANIM", "anim/player_actions_blowdart.zip" ),
        Asset( "ANIM", "anim/player_actions_eat.zip" ),
        Asset( "ANIM", "anim/player_actions_item.zip" ),
        Asset( "ANIM", "anim/player_actions_uniqueitem.zip" ),
        Asset( "ANIM", "anim/player_actions_bugnet.zip" ),
        Asset( "ANIM", "anim/player_actions_fishing.zip" ),
        Asset( "ANIM", "anim/player_actions_boomerang.zip" ),
        Asset( "ANIM", "anim/player_bush_hat.zip" ),
        Asset( "ANIM", "anim/player_attacks.zip" ),
        Asset( "ANIM", "anim/player_idles.zip" ),
        Asset( "ANIM", "anim/player_rebirth.zip" ),
        Asset( "ANIM", "anim/player_jump.zip" ),
        Asset( "ANIM", "anim/player_amulet_resurrect.zip" ),
        Asset( "ANIM", "anim/player_teleport.zip" ),
        Asset( "ANIM", "anim/wilson_fx.zip" ),
        Asset( "ANIM", "anim/player_one_man_band.zip" ),
        Asset( "ANIM", "anim/shadow_hands.zip" ),
        Asset( "SOUND", "sound/sfx.fsb" ),
        Asset( "SOUND", "sound/wilson.fsb" ),
        Asset( "ANIM", "anim/beard.zip" ),

        Asset( "ANIM", "anim/icey.zip" ),
        Asset( "ANIM", "anim/ghost_icey_build.zip" ),
}



local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddDynamicShadow()
    inst.entity:AddNetwork()

    inst.DynamicShadow:SetSize(1.5, .75)
    inst.Transform:SetFourFaced()

    inst.AnimState:SetBank("wilson") 
	inst.AnimState:SetBuild("icey")
    inst.AnimState:PlayAnimation("idle")
	
    inst.AnimState:Show("ARM_carry")
    inst.AnimState:Hide("ARM_normal")
	
	inst.AnimState:AddOverrideBuild("player_lunge")
    inst.AnimState:AddOverrideBuild("player_attack_leap")
    inst.AnimState:AddOverrideBuild("player_superjump")
    inst.AnimState:AddOverrideBuild("player_multithrust")
    inst.AnimState:AddOverrideBuild("player_parryblock")
	
	inst:AddTag("icey_shadow")
	--inst:AddTag("NO_TIME_STOP")


    inst.entity:SetPristine()
	

    if not TheWorld.ismastersim then
        return inst
    end

	inst:AddComponent("colouradder")

	inst:AddComponent("combat")
   
    inst:AddComponent("bloomer")

    inst:AddComponent("health")
	inst.components.health:SetAbsorptionAmount(1.0)------Ӱ��������Ҳ���޵е�

    inst:AddComponent("inventory")
	
	inst:DoTaskInTime(1,inst.Remove)
	inst:DoTaskInTime(0.3,function()
		inst.components.bloomer:PushBloom("leap", "shaders/anim.ksh", -2)
	end)
	inst:DoTaskInTime(0.6 * FRAMES,function()
		inst.components.bloomer:PopBloom("leap")
	end)
	
	inst.persists = false 

    return inst
end

return Prefab("icey_shadow2", fn, assets)
