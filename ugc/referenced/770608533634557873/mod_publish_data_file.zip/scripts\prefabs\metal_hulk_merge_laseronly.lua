local IceyUtil = require("icey_util")

local assets = {
	Asset("ANIM", "anim/metal_hulk_build.zip"),
	Asset("ANIM", "anim/metal_hulk_basic.zip"),
    Asset("ANIM", "anim/metal_hulk_attacks.zip"),
    Asset("ANIM", "anim/metal_hulk_actions.zip"),
    Asset("ANIM", "anim/metal_hulk_barrier.zip"),
    Asset("ANIM", "anim/metal_hulk_explode.zip"),    
    Asset("ANIM", "anim/metal_hulk_bomb.zip"),    
    Asset("ANIM", "anim/metal_hulk_projectile.zip"),    

    Asset("ANIM", "anim/laser_explode_sm.zip"),  
    Asset("ANIM", "anim/smoke_aoe.zip"),
    Asset("ANIM", "anim/laser_explosion.zip"),
    --Asset("ANIM", "anim/ground_chunks_breaking.zip"),
    Asset("ANIM", "anim/ground_chunks_breaking_brown.zip"),
	
    Asset("ANIM", "anim/metal_hulk_ring_fx.zip"),

	
	Asset("ANIM", "anim/lavaarena_hammer_attack_fx.zip"),
	Asset("ANIM", "anim/rock_basalt.zip"),
}

local HideSymbols = {
	"body01",
	"blot_b",
	"blot_c",
	"blot_f",
	"cable01",
	"cable02",
	"claw01",
	"dirt_scrape01",
	"ear01",
	"energy_ball01",
	"eye01",
	"hand01",
	"head01",
	"horn01",
	"horn02",
	"jaw_back01",
	"jaw01",
	"lightning_ball01",
	"lightning_ball02",
	"lightning01",
	"peg01",
	"portal_glow01",
	"portal01",
	"red_glow01",
	"red_rune01",
	"segment01",
	"shoulder01",
	"smoke01",
	"sprk_1",
	"sprk_2",
	"sprk_3",
	"teleport_patch01",
	"toe01",
	--[["",
	"",
	"",
	"",--]]
}

local function ShakeIfClose(inst)
    ShakeAllCameras(CAMERASHAKE.FULL, 0.7, 0.02, 0.3, inst, 30)
end

local function SetLightRadius(inst, radius)
    inst.Light:SetRadius(radius)
end

local function DisableLight(inst)
    inst.Light:Enable(false)
end

local function DoAnim(inst)
	local x, y, z = inst.Transform:GetWorldPosition()
	if inst.AnimState ~= nil then
        inst.AnimState:PlayAnimation("hit_"..tostring(math.random(5)))
        inst:Show()
        inst:DoTaskInTime(inst.AnimState:GetCurrentAnimationLength() + 2 * FRAMES, inst.Remove)

        inst.Light:Enable(true)
        inst:DoTaskInTime(4 * FRAMES, SetLightRadius, .5)
        inst:DoTaskInTime(5 * FRAMES, DisableLight)

        SpawnPrefab("deerclops_laserscorch").Transform:SetPosition(x, 0, z)
        local fx = SpawnPrefab("deerclops_lasertrail")
        fx.Transform:SetPosition(x, 0, z)
        fx:FastForward(GetRandomMinMax(.3, .7))
    else
        inst:DoTaskInTime(2 * FRAMES, inst.Remove)
    end
end 

local function DoCircleLaserAtk(inst,rad,start_roa)
	ShakeIfClose(inst)
	start_roa = start_roa or inst:GetRotation() or 0
	inst:StartThread(function()
		for roa = start_roa  ,start_roa+ 360,18 do 
			roa = roa * DEGREES
			local mypos = inst:GetPosition()
			local spawnpos = mypos + Vector3(math.cos(roa)*rad,0,math.sin(roa)*rad)
			local fx1 = SpawnPrefab("deerclops_laser")
			local targets, skiptoss = {}, {}
			local delay = 0.5
			local fx2 = SpawnPrefab("deerclops_laserscorch")
			fx1.Transform:SetScale(2,2,2)
			fx1.Transform:SetPosition(spawnpos:Get())
			
			fx2.Transform:SetScale(1.75,1.75,1.75)
			fx2.Transform:SetPosition(spawnpos:Get())
			
			fx1:SetPrefabNameOverride(inst.nameoverride)
			fx1.caster = inst
			--fx1:Trigger(delay * FRAMES, targets, skiptoss)
			DoAnim(fx1)
			inst:DoDamage(spawnpos,4,75)
			inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/enemy/metal_robot/laser")
			--ShakeIfClose(inst)
			Sleep(0)
		end
		
		ShakeIfClose(inst)
	end)
end 

local function DoDamage(inst,pos,rad,damage)
    local targets = {}
	pos = pos or inst:GetPosition()
	damage = damage or 35
    local x, y, z = pos:Get()
  
    --setfires(x,y,z, rad)
    for i, v in ipairs(TheSim:FindEntities(x, 0, z, rad, nil, { "laser", "DECOR", "INLIMBO" , "tadalin" })) do  --  { "_combat", "pickable", "campfire", "CHOP_workable", "HAMMER_workable", "MINE_workable", "DIG_workable" }
		--if TadalinUtil.CanAttack(v) then 
			if not targets[v] and v:IsValid() and not v:IsInLimbo() and not (v.components.health ~= nil and v.components.health:IsDead()) and not v:HasTag("laser_immune") then            
				local vradius = 0
				if v.Physics then
					vradius = v.Physics:GetRadius()
				end

				local range = rad + vradius
				if v:GetDistanceSqToPoint(Vector3(x, y, z)) < range * range then
					local isworkable = false
					if v.components.workable ~= nil then
						local work_action = v.components.workable:GetWorkAction()
						--V2C: nil action for campfires
						isworkable =
							(   work_action == nil and v:HasTag("campfire")    ) or
							
								(   work_action == ACTIONS.CHOP or
									work_action == ACTIONS.HAMMER or
									work_action == ACTIONS.MINE or   
									work_action == ACTIONS.DIG
								)
					end
					if isworkable then
						targets[v] = true
						v:DoTaskInTime(0.6, function() 
							if v.components.workable then
								v.components.workable:Destroy(inst) 
								local vx,vy,vz = v.Transform:GetWorldPosition()
								--v:DoTaskInTime(0.3, function() setfires(vx,vy,vz,1) end)
							end
						 end)
						if v:IsValid() and v:HasTag("stump") then
						   -- v:Remove()
						end
					elseif v.components.pickable ~= nil
						and v.components.pickable:CanBePicked()
						and not v:HasTag("intense") then
						targets[v] = true
						local num = v.components.pickable.numtoharvest or 1
						local product = v.components.pickable.product
						local x1, y1, z1 = v.Transform:GetWorldPosition()
						v.components.pickable:Pick(inst) -- only calling this to trigger callbacks on the object
						if product ~= nil and num > 0 then
							for i = 1, num do
								local loot = SpawnPrefab(product)
								loot.Transform:SetPosition(x1, 0, z1)
								targets[loot] = true
							end
						end

					elseif v.components.health and v.components.combat then                    
						--inst.components.combat:DoAttack(v)   
						v.components.combat:GetAttacked(inst,damage)             
						if v:IsValid() then
							if not v.components.health or not v.components.health:IsDead() then
								if v.components.freezable ~= nil then
									if v.components.freezable:IsFrozen() then
										v.components.freezable:Unfreeze()
									elseif v.components.freezable.coldness > 0 then
										v.components.freezable:AddColdness(-2)
									end
								end
								if v.components.temperature ~= nil then
									local maxtemp = math.min(v.components.temperature:GetMax(), 10)
									local curtemp = v.components.temperature:GetCurrent()
									if maxtemp > curtemp then
										v.components.temperature:DoDelta(math.min(10, maxtemp - curtemp))
									end
								end
							end
						end                   
					end
					if v:IsValid() and v.AnimState then
						SpawnPrefab("deerclops_laserhit"):SetTarget(v)
					end
				end
			end
		--end
    end
end

--[[TimeEvent(1*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/enemy/metal_robot/laser_pre") end),
            TimeEvent(30*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/trails/step") end),
			TimeEvent(30*FRAMES, function(inst) 
				inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/trails/taunt")
				inst.LaserSwitch = true
				DoCircleLaserAtk(inst,9)
				--inst.SoundEmitter:PlaySound("dontstarve/creatures/together/toad_stool/roar_phase")
				inst:PushEvent("use_metalhulk_skill",{cd = 10,name = "skill_circleatk"})
			end),
			TimeEvent(30*FRAMES, ShakeRoar),
			TimeEvent(50*FRAMES, function(inst)
				inst.LaserSwitch = false 
			end),--]]

local TimeLines = {
	TimeEvent(1*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/enemy/metal_robot/laser_pre") end),
    TimeEvent(30*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/trails/step") end),
	TimeEvent(30*FRAMES, function(inst) 
		inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/trails/taunt")
			DoCircleLaserAtk(inst,9)
		end),
	TimeEvent(30*FRAMES, ShakeIfClose),
}

local function ExtraFn(inst)
	for k,v in pairs(HideSymbols) do 
		inst.AnimState:HideSymbol(v)
	end 
	
	if not TheWorld.ismastersim then
		return inst
	end	  
	
	inst.DoDamage = DoDamage 
	
	for k,v in pairs(TimeLines) do 
		inst:DoTaskInTime(v.time,v.fn)
	end
end 

return IceyUtil.CreateNormalFx("metal_hulk_merge_laseronly",assets,"metal_hulk","metal_hulk_build","atk_circle",false,ExtraFn)