require "behaviours/follow"
require "behaviours/wander"

local MIN_FOLLOW = 4
local MAX_FOLLOW = 11
local MED_FOLLOW = 6
local MAX_CHASE_TIME = 6

local SpotlightChildBrain = Class(Brain, function(self, inst)
    Brain._ctor(self, inst)
end)

function SpotlightChildBrain:OnStart()
    local root = PriorityNode(
    {

    }, .25)

    self.bt = BT(self.inst, root)
end

return SpotlightChildBrain