local Widget = require "widgets/widget"
local Image = require "widgets/image"


local IceyIronLordUI = Class(Widget, function(self, owner)
    self.owner = owner
    Widget._ctor(self, "IceyIronLordUI")
	self:SetClickable(false)

	self.img = self:AddChild(Image("images/icey_ironlord_ui.xml", "living_artifact.tex"))
    self.img:SetHAnchor(ANCHOR_MIDDLE)
    self.img:SetVAnchor(ANCHOR_MIDDLE)
    self.img:SetScaleMode(SCALEMODE_FILLSCREEN)
    self.img:SetVRegPoint(ANCHOR_MIDDLE)
    self.img:SetHRegPoint(ANCHOR_MIDDLE)

    self.currentalpha = 0
    self.alphabaseline = 0
    self.time = 2
    self.dist = 0
    self:Hide() 
    self:UpdateState()
end)

local function OwnerIsIronLord(self)
	return self.owner and self.owner.replica.icey_ironlord and self.owner.replica.icey_ironlord:IsIronLord()
end 

function IceyIronLordUI:GetNewFlashTime()
    local time = 0
    local nextflash = 0
	
	local timeremaining = self.owner.replica.icey_ironlord:GetCurrent()
	local timemax = self.owner.replica.icey_ironlord:GetMax() 

    local per = timeremaining / timemax
    if per > 0.5 then
        time = 1
        nextflash = 2
    elseif per > 0.3 then
        time = 0.5
        nextflash = 1    
    elseif per > 0.05 then
        time = 0.3
        nextflash = 0.6
    else
        time = 0.13
        nextflash = 0.26    
    end

    --GetPlayer():PushEvent("livingartifactoverpulse",{time=time})
	self:Flash({time=time}) 
    TheFocalPoint.SoundEmitter:PlaySoundWithParams("dontstarve_DLC003/common/crafted/iron_lord/pulse")---- jason i have "intensity" 0=low pulse 1=high pulse, it increases in volume and pitch
    self.flashtask = self.owner:DoTaskInTime(nextflash, function() self:GetNewFlashTime() end)
end

function IceyIronLordUI:UpdateState()
	if OwnerIsIronLord(self) then
		self:TurnOn()
	else
		self:TurnOff()
	end
end

function IceyIronLordUI:TurnOn()
	self.time = 1
	self.alphabaseline = 0.3
	self.dist = 0.3
	self:Show()
    self:StartUpdating()
	self.flashtask = self.owner:DoTaskInTime(1, function() self:GetNewFlashTime() end)
end

function IceyIronLordUI:TurnOff()
	self.time = 0.3
	self.alphabaseline = 0
    self.dist = 0.3
    self:OnUpdate(0)
	if self.flashtask then 
		self.flashtask:Cancel()
		self.flashtask = nil
	end  
end

function IceyIronLordUI:OnUpdate(dt)
	
	local dir = 0
	local target = self.alphabaseline
	if self.alphaspike then
		target = self.alphaspike
	end
	if self.currentalpha ~= target then
		dir = target - self.currentalpha
	end
	if dir > 0 then
		self.currentalpha = math.min(self.currentalpha + (self.dist/(30*self.time)),target)
	else
		self.currentalpha = math.max(self.currentalpha - (self.dist/(30*self.time)),target)
	end
	if self.alphaspike and self.currentalpha == self.alphaspike then
		self.alphaspike = nil
	end

	local r,g,b = 1,1,1
	
	--[[local player = GetPlayer()
	if player.livingartifact then
		local la = player.livingartifact
		g = Remap(la.timeremaining, la.timemax, 0, 1, 0.1)
		b = Remap(la.timeremaining, la.timemax, 0, 1, 0)
	end--]]
	if self.owner.replica.icey_ironlord then 
		local timeremaining = self.owner.replica.icey_ironlord:GetCurrent()
		local timemax = self.owner.replica.icey_ironlord:GetMax() 
		g = Remap(timeremaining, timemax, 0, 1, 0.1)
		b = Remap(timeremaining, timemax, 0, 1, 0)
	end 
	
	self.img:SetTint(r,g,b, self.currentalpha)
	if self.currentalpha <= 0 then
		self:Hide()
	else
		self:Show()
	end
end

function IceyIronLordUI:Flash(data)
	self.time = data  and data.time or 0.2
	self.alphaspike = data and data.goal or 0.5   	
	self.dist = math.abs(self.currentalpha - self.alphaspike)	
end

return IceyIronLordUI