local Widget = require "widgets/widget" --Widget������widget��������
local Text = require "widgets/text" --Text�࣬�ı�����
local TextButton = require "widgets/textbutton"
local Image = require "widgets/image"
local ImageButton = require "widgets/imagebutton"
local UIAnim = require "widgets/uianim"

local DeathShow = Class(Widget, function(self,owner) 
	Widget._ctor(self, "DeathShow") 
	self.owner = owner
	
	self.death_ui = self:AddChild(UIAnim())
    self.death_ui:GetAnimState():SetBank("death_show")
    self.death_ui:GetAnimState():SetBuild("death_show")
	self.death_ui:SetHAnchor(ANCHOR_MIDDLE)
    self.death_ui:SetVAnchor(ANCHOR_MIDDLE)
    --self.death_ui:SetScaleMode(SCALEMODE_PROPORTIONAL)
    self.death_ui:SetClickable(false)
	self.death_ui:SetScale(1.5,1.5,1.5)
	self.death_ui:Hide() 
	
	self.currentmultcolour = {176/255,0/255,0/255,1}
	self.animplaying = false 
end)


function DeathShow:FadeIn(anim)
	anim = anim or "death"
	
	self.currentmultcolour = {176/255,0/255,0/255,1}
	self.death_ui:Show() 
	self.death_ui:GetAnimState():PlayAnimation(anim)
	self.death_ui:GetAnimState():SetMultColour(unpack(self.currentmultcolour))
	if self.owner.SoundEmitter then 
		self.owner.SoundEmitter:PlaySound("dontstarve/common/lava_arena/portal_doom")
	end
	
	--self:StartUpdating()
	if self.task then 
		self.task:Cancel()
		self.task = nil 
	end
	self.task = self.owner:DoTaskInTime(3,function()
		self:StartUpdating()
	end)
end

function DeathShow:FadeOut()
	if self.task then 
		self.task:Cancel()
		self.task = nil 
	end
	self.currentmultcolour = {176/255,0/255,0/255,0}
	self.death_ui:Hide() 
	self:StopUpdating()
end 

function DeathShow:OnUpdate(dt)
	local r,g,b,a = unpack(self.currentmultcolour)
	local new_a = math.max(0,a-dt/3)
	self.currentmultcolour = {r,g,b,new_a}
	self.death_ui:GetAnimState():SetMultColour(unpack(self.currentmultcolour))
	if new_a <= 0 then 
		self:FadeOut()
	end
end

return DeathShow