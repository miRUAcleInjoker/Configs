require "behaviours/wander"
require "behaviours/chaseandattack"
require "behaviours/doaction"
require "behaviours/panic"

local MAX_WANDER_DIST = 20
local START_RUN_DIST = 3
local STOP_RUN_DIST = 5
local MAX_CHASE_TIME = 10
local MAX_CHASE_DIST = 30
local SEE_TARGET_DIST = 20
local SEE_FOOD_DIST = 10
local RUN_AWAY_DIST = 6
local STOP_RUN_AWAY_DIST = 8

local function FindTarget(inst)
	return inst.components.combat.target 
end 

local function HasTarget(inst)
	return inst.components.combat.target  ~= nil 
end 

local function AttackAction(inst)
	local target = FindTarget(inst)
	print("Try attack action!",inst)
    if target and target:IsValid() then
		print("BufferedAction attack !",inst)
        return BufferedAction(inst, target, ACTIONS.ATTACK,nil,target:GetPosition(),nil,nil,true)
    end
end 



local ChaosBrain = Class(Brain, function(self, inst)
    Brain._ctor(self, inst)
end)

function ChaosBrain:OnStart()
    --print(self.inst, "ChaosBrain:OnStart")
    local root = PriorityNode(
    {
		WhileNode(function() return HasTarget(self.inst)  end, "HasTarget",
			ChattyNode(self.inst, "Attack",
				DoAction(self.inst, function() return AttackAction(self.inst) end, "Attack", true))),
		--ChaseAndAttack(self.inst, 15, 25),
        Wander(self.inst, function() return  end, MAX_WANDER_DIST),
    }, .5)

    self.bt = BT(self.inst, root)
end

function ChaosBrain:OnInitializationComplete()
    --self.inst.components.knownlocations:RememberLocation("home", Point(self.inst.Transform:GetWorldPosition()), true)
end

return ChaosBrain
