require "behaviours/follow"
require "behaviours/wander"
require "behaviours/standstill"

local MIN_FOLLOW_DIST = 0
local MAX_FOLLOW_DIST = 10
local TARGET_FOLLOW_DIST = 10

local MAX_CHASE_TIME = 30

local MAX_WANDER_DIST = 10

local JackBrain = Class(Brain, function(self, inst)
    Brain._ctor(self, inst)
end)

function JackBrain:OnStart()    
    local root = PriorityNode(
    {
		WhileNode( function() return self.inst.components.combat.target and self.inst.components.combat:InCooldown() end, "Dodge",
            RunAway(self.inst, function() return self.inst.components.combat.target end, 8, 10) ),
		ChaseAndAttack(self.inst, MAX_CHASE_TIME),
		Wander(self.inst),
		StandStill(self.inst, function() return self.inst.sg:HasStateTag("idle") end),
    }, 0.2)
        
    self.bt = BT(self.inst, root)
end

return JackBrain
