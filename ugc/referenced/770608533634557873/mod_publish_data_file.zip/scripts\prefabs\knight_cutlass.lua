local IceyUtil = require("icey_util")

local assets=
{
	Asset("ANIM", "anim/cutlass.zip"),
	Asset("ANIM", "anim/swap_cutlass.zip"),
	
	Asset("IMAGE","images/inventoryimages/knight_cutlass.tex"),
	Asset("ATLAS","images/inventoryimages/knight_cutlass.xml"),
}

local function ReticuleTargetFnLine()
    return Vector3(ThePlayer.entity:LocalToWorldSpace(6.5, 0, 0))
end

local function ReticuleMouseTargetFnLine(inst, mousepos)
    if mousepos ~= nil then
        local x, y, z = inst.Transform:GetWorldPosition()
        local dx = mousepos.x - x
        local dz = mousepos.z - z
        local l = dx * dx + dz * dz
        if l <= 0 then
            return inst.components.reticule.targetpos
        end
        l = 6.5 / math.sqrt(l)
        return Vector3(x + dx * l, 0, z + dz * l)
    end
end

local function ReticuleUpdatePositionFnLine(inst, pos, reticule, ease, smoothing, dt)
    local x, y, z = inst.Transform:GetWorldPosition()
    reticule.Transform:SetPosition(x, 0, z)
    local rot = -math.atan2(pos.z - z, pos.x - x) / DEGREES
    if ease and dt ~= nil then
        local rot0 = reticule.Transform:GetRotation()
        local drot = rot - rot0
        rot = Lerp((drot > 180 and rot0 + 360) or (drot < -180 and rot0 - 360) or rot0, rot, dt * smoothing)
    end
    reticule.Transform:SetRotation(rot)
end

local function oncastfn(inst,doer,pos)
	if IceyUtil.DefaultCostFn(doer,{stamina = 20,focus = 10}) then 
		inst.components.rechargeable:StartRecharge()
		doer:PushEvent("combat_lunge",{targetpos = pos,weapon = inst})
	end 
end 

local function onfinished(inst)
    inst:Remove()
end

local function onequip(inst, owner) 
    owner.AnimState:OverrideSymbol("swap_object", "swap_cutlass", "swap_cutlass")
    owner.AnimState:Show("ARM_carry") 
    owner.AnimState:Hide("ARM_normal") 
end

local function onunequip(inst, owner) 
    owner.AnimState:Hide("ARM_carry") 
    owner.AnimState:Show("ARM_normal") 
end

local function onattack(inst, attacker, target)
    --[[if target.prefab == "twister" then
        target.components.health:DoDelta(-TUNING.CUTLASS_BONUS_DAMAGE)
    end--]]
	if target and target:IsValid() and target.components.health and target.components.health:IsDead() then
		local x,y,z = target.Transform:GetWorldPosition()
		SpawnAt(math.random() <= 0.5 and "fish" or "eel",target:GetPosition()).components.inventoryitem:DoDropPhysics(x,y,z,true)
	end
end

local function fn()
	local inst = CreateEntity()
	
	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddNetwork()
    
    MakeInventoryPhysics(inst)
    
    inst.AnimState:SetBank("cutlass")
    inst.AnimState:SetBuild("cutlass")
    inst.AnimState:PlayAnimation("idle")
    
    inst:AddTag("sharp")
    inst:AddTag("cutlass")
	inst:AddTag("aoeweapon_lunge")
	inst:AddTag("rechargeable")
	
	
	inst:AddComponent("aoetargeting")
	inst.components.aoetargeting.range = 8
	inst.components.aoetargeting.reticule.validcolour = { 1, .75, 0, 1 }
	inst.components.aoetargeting.reticule.invalidcolour = { .5, 0, 0, 1 }
	inst.components.aoetargeting.reticule.ease = true
	inst.components.aoetargeting.reticule.mouseenabled = true
	inst.components.aoetargeting.reticule.reticuleprefab = "reticulelongmulti"
	inst.components.aoetargeting.reticule.pingprefab = "reticulelongmultiping"
	inst.components.aoetargeting.reticule.targetfn = ReticuleTargetFnLine
	inst.components.aoetargeting.reticule.mousetargetfn = ReticuleMouseTargetFnLine
	inst.components.aoetargeting.reticule.updatepositionfn = ReticuleUpdatePositionFnLine
	
	inst.entity:SetPristine()	
	
    if not TheWorld.ismastersim then
        return inst
    end	  

    inst:AddComponent("weapon")
    inst.components.weapon:SetDamage(68)
    inst.components.weapon:SetOnAttack(onattack)
    
    -------
    
    inst:AddComponent("finiteuses")
    inst.components.finiteuses:SetMaxUses(150)
    inst.components.finiteuses:SetUses(150)
    inst.components.finiteuses:SetOnFinished( onfinished )

    inst:AddComponent("inspectable")
    
    inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "knight_cutlass"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/knight_cutlass.xml"
    
    inst:AddComponent("equippable")
    inst.components.equippable:SetOnEquip( onequip )
    inst.components.equippable:SetOnUnequip( onunequip )
	
	inst:AddComponent("rechargeable")
	inst.components.rechargeable:SetRechargeTime(15)
	
	inst:AddComponent("aoespell")
	if TheNet:GetServerGameMode() == "lavaarena" then 
		inst.components.aoespell:SetAOESpell(oncastfn)
	else  
		inst.components.aoespell:SetOnCastFn(oncastfn)
	end 
	
	inst:AddComponent("aoeweapon_lunge")
	inst.components.aoeweapon_lunge:SetCanAttack(function(weapon,lunger,target)
		return IceyUtil.CanAttack(target,lunger)
	end)
    
    return inst
end

return Prefab( "knight_cutlass", fn, assets) 
