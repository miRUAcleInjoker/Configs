local SNEAKERVISION_COLOURCUBES =
{
    day = "images/colour_cubes/beaver_vision_cc.tex",
    dusk = "images/colour_cubes/beaver_vision_cc.tex",
    night = "images/colour_cubes/beaver_vision_cc.tex",
    full_moon = "images/colour_cubes/beaver_vision_cc.tex",
}

local IceySneaker = Class(function(self, inst)
	self.inst = inst
	--self._issneaking = net_bool(inst.GUID, "iceysneaker._issneaking") 
	--self._sneakervision_enable = net_bool(inst.GUID, "iceysneaker._sneakervision_enable") 
end)

function IceySneaker:ApplySneakerVision(enable)
	print("IceySneaker(Replica):ApplySneakerVision()",enable)
	if enable then
        self.inst.components.playervision:SetCustomCCTable(SNEAKERVISION_COLOURCUBES)
    else
        self.inst.components.playervision:SetCustomCCTable(nil)
    end
end


return IceySneaker