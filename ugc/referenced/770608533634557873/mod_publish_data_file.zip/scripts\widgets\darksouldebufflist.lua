local Text = require "widgets/text"
local Image = require "widgets/image"
local Widget = require "widgets/widget"
local UIAnim = require "widgets/uianim"
local DarkSoulDebuffSlot = require "widgets/darksouldebuffslot"

local STZRT_X = 0
local SLOTDIST = 60

local DarkSoulDebuffList = Class(Widget, function(self, owner)
    Widget._ctor(self,"DarkSoulDebuffList")
	self.owner = owner
	self.buffslots = {}
	
	self:SetHAnchor(1) -- ����ԭ��x����λ�ã�0��1��2�ֱ��Ӧ��Ļ�С�����
	self:SetVAnchor(2) -- ����ԭ��y����λ�ã�0��1��2�ֱ��Ӧ��Ļ�С��ϡ���
	
	
	
	--self:StartUpdating()
end)



function DarkSoulDebuffList:AddBuff(name,ent,percent,activated)
	if not self.buffslots[name] then 
		self.buffslots[name] = self:AddChild(DarkSoulDebuffSlot(self.owner,name,ent,percent,activated))
		self.buffslots[name].OnBuffEntityRemove = function()
			self:RemoveBuff(name)		
		end 
		
		self:Line()
		self.owner:ListenForEvent("onremove",self.buffslots[name].OnBuffEntityRemove,ent)
	end
	self.buffslots[name]:SetBuff(percent,activated)
end

function DarkSoulDebuffList:RemoveBuff(name)
	local ent = self.buffslots[name]:GetBuffEntity()
	self.owner:RemoveEventCallback("onremove",self.buffslots[name].OnBuffEntityRemove,ent)
	
	
	self.buffslots[name]:Kill()
	self.buffslots[name] = nil 
	self:Line()
end

function DarkSoulDebuffList:Line()
	local index = 1 
	for name,v in pairs(self.buffslots) do 
		local x,y,z = STZRT_X + SLOTDIST * (index - 1),0,0
		v:SetPosition(x,y,z)
		index = index + 1
	end
end 



return DarkSoulDebuffList
