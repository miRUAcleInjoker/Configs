local brain = require "brains/leifbrain"

local assets =
{	
	Asset("ANIM", "anim/leif_walking.zip"),
    Asset("ANIM", "anim/leif_actions.zip"),
    Asset("ANIM", "anim/leif_attacks.zip"),
    Asset("ANIM", "anim/leif_idles.zip"),
    Asset("ANIM", "anim/jade_0.zip"),
    Asset("SOUND", "sound/leif.fsb"),
}

local prefabs =
{
    "meat",
    "log", 
    "character_fire",
    "greengem",
}

local speech = {
	"你无FA♂抵挡Dark♂自然的力量",
	"我是Dark♂自然的守护者",
	"欢♂迎",
	"为了Dark♂自然",
	"真是壮♂观",
	"很自然的错误",
}

local music_name = (TUNING.ICEY_JADE_MUSIC == "on" and "jade") or (TUNING.ICEY_JADE_MUSIC == "off" and "default")

local function PushMusic(inst)
    if ThePlayer == nil then
        inst._playingmusic = false
    elseif ThePlayer:IsNear(inst, inst._playingmusic and 40 or 20) then
		--print(inst,ThePlayer,"Push the triggeredevent at",GetTime())
        inst._playingmusic = true
        ThePlayer:PushEvent("triggeredevent", { name = music_name ,duration = 3})
    elseif inst._playingmusic and not ThePlayer:IsNear(inst, 50) then
        inst._playingmusic = false
    end
end

------------------------------------------------------------------------

local function SetLeifScale(inst, scale)
    inst._scale = scale ~= 1 and scale or nil

    inst.Transform:SetScale(scale, scale, scale)
    inst.Physics:SetCapsule(.5 * scale, 1)
    inst.DynamicShadow:SetSize(4 * scale, 1.5 * scale)

    inst.components.locomotor.walkspeed = 1.5 * scale

    inst.components.combat:SetDefaultDamage(TUNING.LEIF_DAMAGE * scale)
    inst.components.combat:SetRange(3 * scale)

    local health_percent = inst.components.health:GetPercent()
    inst.components.health:SetMaxHealth(TUNING.LEIF_HEALTH * scale)
    inst.components.health:SetPercent(health_percent, true)
end

local function onpreloadfn(inst, data)
    if data ~= nil and data.jadescale ~= nil then
        SetLeifScale(inst, data.jadescale)
    end
end

local function onloadfn(inst, data)
    if data ~= nil then
        if data.hibernate then
            inst.components.sleeper.hibernate = true
        end
		if data.summon_level then
			inst.summon_level = data.summon_level
		end 
		if data.issmall then 
			inst.issmall = data.issmall
		end 
        if data.sleep_time ~= nil then
            inst.components.sleeper.testtime = data.sleep_time
        end
        if data.sleeping then
            inst.components.sleeper:GoToSleep()
        end
    end
end

local function onsavefn(inst, data)
    data.jadescale = inst._scale
	data.summon_level = inst.summon_level
	data.issmall = inst.issmall
    if inst.components.sleeper:IsAsleep() then
        data.sleeping = true
        data.sleep_time = inst.components.sleeper.testtime
    end

    if inst.components.sleeper:IsHibernating() then
        data.hibernate = true
    end
end

local function CalcSanityAura(inst)
    return inst.components.combat.target ~= nil and -TUNING.SANITYAURA_LARGE or -TUNING.SANITYAURA_MED
end

local function OnBurnt(inst)
    if inst.components.propagator and inst.components.health and not inst.components.health:IsDead() then
        inst.components.propagator.acceptsheat = true
    end
end

local function OnAttacked(inst, data)
	
    inst.components.combat:SetTarget(data.attacker)
	 inst.components.combat:ShareTarget(data.attacker, 30, function(dude)
        return dude:HasTag("jade")
            and not dude.components.health:IsDead()
    end, 10)
end

local function jadesummon(inst)

	if inst.issmall == 1 then 
		return
	end 
	local rad = 5
	local pos = inst:GetPosition()
	if not inst.sg:HasStateTag("hit") and not inst.sg:HasStateTag("attack") and not inst.sg:HasStateTag("death") then 
		if inst.components.talker then 
			inst.components.talker:Say(speech[math.random(1,#speech)])
		end
		inst.sg:GoToState("panic")
		inst:DoTaskInTime(0.734,function() inst.sg:GoToState("idle") end )
		local jade = DebugSpawn("jade")
		jade.Transform:SetPosition(pos.x,0,pos.z)
		SetLeifScale(jade,inst.summon_level)
		inst.summon_level = inst.summon_level + 0.1
		jade.issmall = 1
	end
end 

local function ontalk(inst, script)
    --inst.SoundEmitter:PlaySound("dontstarve/creatures/leif/death_V0")
end

local function ondeath(inst)

end 

local function OnPauseSummon(inst)
	if inst.SummonJadeTask ~= nil then 
		print(inst,"OnPauseSummon Jade")
		inst.SummonJadeTask:Cancel()
		inst.SummonJadeTask = nil 
	end
end 

local function OnStartSummon(inst)
	print("OnStartSummon Jade Check:",inst,inst.summon_level,inst.issmall)
	if inst.SummonJadeTask == nil then 
		print(inst,"OnStartSummon Jade")
		inst.SummonJadeTask = inst:DoPeriodicTask(5,function() 
			if inst.summon_level < 2 and inst.issmall == 0 then  
				jadesummon(inst) 
			else
				OnPauseSummon(inst)
			end 
		end )
	end 
end 



local function common_fn(build)
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddDynamicShadow()
    inst.entity:AddNetwork()

    MakeCharacterPhysics(inst, 1000, .5)

    inst.DynamicShadow:SetSize(4, 1.5)
    inst.Transform:SetFourFaced()

    inst:AddTag("epic")
	inst:AddTag("noepicmusic")
    inst:AddTag("monster")
    inst:AddTag("hostile")
    inst:AddTag("jade")
    inst:AddTag("tree")
    inst:AddTag("evergreens")
    inst:AddTag("largecreature")

    inst.AnimState:SetBank("leif")
    inst.AnimState:SetBuild(build)
    inst.AnimState:PlayAnimation("idle_loop", true)
	
	inst:AddComponent("talker") ------------------------talker缁勪欢蹇呴』鍔犲湪  涓诲鏈哄墠闈紒锛侊紒锛侊紒锛侊紒锛侊紒锛?
	inst.components.talker.fontsize = 35
    inst.components.talker.font = TALKINGFONT
    --inst.components.talker.colour = Vector3(133/255, 140/255, 167/255)
    inst.components.talker.offset = Vector3(0, -1000, 0)
    inst.components.talker:MakeChatter()
	inst.components.talker.ontalk = ontalk

    inst._playingmusic = false
	if not TheNet:IsDedicated() then
        inst:DoPeriodicTask(1, PushMusic,0)
    end


    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    local color = .5 + math.random() * .5
    inst.AnimState:SetMultColour(color, color, color, 1)

    ------------------------------------------

    inst.OnPreLoad = onpreloadfn
    inst.OnLoad = onloadfn
    inst.OnSave = onsavefn

    ------------------------------------------

    inst:AddComponent("locomotor") -- locomotor must be constructed before the stategraph
    inst.components.locomotor.walkspeed = 1.5

    ------------------------------------------
    inst:SetStateGraph("SGJade")

    ------------------------------------------

    inst:AddComponent("sanityaura")
    inst.components.sanityaura.aurafn = CalcSanityAura

--[[    MakeLargeBurnableCharacter(inst, "marker")
    inst.components.burnable.flammability = TUNING.LEIF_FLAMMABILITY
    inst.components.burnable:SetOnBurntFn(OnBurnt)
    inst.components.propagator.acceptsheat = true--]]

    MakeHugeFreezableCharacter(inst, "marker")
    ------------------
    inst:AddComponent("health")
    inst.components.health:SetMaxHealth(TUNING.LEIF_HEALTH)

    ------------------

    inst:AddComponent("combat")
    inst.components.combat:SetDefaultDamage(TUNING.LEIF_DAMAGE)
    inst.components.combat.playerdamagepercent = TUNING.LEIF_DAMAGE_PLAYER_PERCENT
    inst.components.combat.hiteffectsymbol = "marker"
    inst.components.combat:SetRange(3)
    inst.components.combat:SetAttackPeriod(TUNING.LEIF_ATTACK_PERIOD)

    ------------------------------------------
    MakeHauntableIgnite(inst)
    ------------------------------------------

    inst:AddComponent("sleeper")
    inst.components.sleeper:SetResistance(3)
	
	

    ------------------------------------------

    inst:AddComponent("lootdropper")
    inst.components.lootdropper:SetLoot({"greengem"})

    ------------------------------------------

    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("GTMD青玉德")
    ------------------------------------------

	
    inst:SetBrain(brain)
	
	inst.SetLeifScale = SetLeifScale
	inst.summon_level = 0.1
	inst.issmall = 0
	
	OnStartSummon(inst)
    inst:ListenForEvent("attacked", OnAttacked)
	inst:ListenForEvent("death",ondeath)
	inst:ListenForEvent("entitywake",OnStartSummon)
	inst:ListenForEvent("entitysleep",OnPauseSummon)
    
	
    return inst
end

local function normal_fn()
    return common_fn("jade_0")
end



return Prefab("jade", normal_fn, assets, prefabs)