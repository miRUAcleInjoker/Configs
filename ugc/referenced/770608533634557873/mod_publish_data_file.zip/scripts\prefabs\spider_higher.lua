local assets =
{
    Asset("ANIM", "anim/spider_higher_1.zip"),
	Asset("ANIM", "anim/spider_queen.zip"),
    Asset("ANIM", "anim/spider_queen_2.zip"),
    --Asset("ANIM", "anim/spider_queen_3.zip"),
    --Asset("SOUND", "sound/spider.fsb"),
}

local prefabs =
{
    "monstermeat",
    "silk",
    "spider_higher_good",
    "spidereggsack",
}

local brain = require "brains/spider_higherbrain"

local loot =
{
	"redgem",
	"redgem",
    "monstermeat",
    "monstermeat",
    "monstermeat",
    "monstermeat",
	"monstermeat",
	"monstermeat",
	"monstermeat",
    "silk",
    "silk",
    "silk",
    "silk",
	"silk",
	"silk",
	"silk",
	"silk",
    "spidereggsack",
	"spidereggsack",
	"spidereggsack",
	"spider_higher_good",
}

local minions = 
{
	[1] = "spider_haojie",
	[2] = "spider_xianfeng",
	[3] = "spider_chaser",
	[4] = "spider_bomb",
	[5] = "spider_dragoon",
}

local SHARE_TARGET_DIST = 30

local function PushMusic(inst)
    if ThePlayer == nil then
        inst._playingmusic = false
    elseif ThePlayer:IsNear(inst, inst._playingmusic and 40 or 20) then
        inst._playingmusic = true
        ThePlayer:PushEvent("triggeredevent", { name = "spider_higher" })
    elseif inst._playingmusic and not ThePlayer:IsNear(inst, 50) then
        inst._playingmusic = false
    end
end

------------------------------------------------------------------------
local function oncollapse(inst, other)
    if other:IsValid() and other.components.workable ~= nil and other.components.workable:CanBeWorked() and not other:HasTag("tadalin") then
        SpawnPrefab("collapse_small").Transform:SetPosition(other.Transform:GetWorldPosition())
		if other.prefab == "pighouse" then 
			SpawnPrefab("pighouse_blood").Transform:SetPosition(other.Transform:GetWorldPosition())
		elseif other.prefab == "mermhouse" then 
			SpawnPrefab("mermhouse_blood").Transform:SetPosition(other.Transform:GetWorldPosition())
		end
        other.components.workable:Destroy(inst)
    end
end

local function oncollide(inst, other)
    if other ~= nil 
	--and (other:HasTag("tree") or other:HasTag("boulder") or other:HasTag("wall") or other:HasTag("building")) 
	and --HasTag implies IsValid
        Vector3(inst.Physics:GetVelocity()):LengthSq() >= 1 then
        inst:DoTaskInTime(2 * FRAMES, oncollapse, other)
    end
end

local function onattack(inst,data)
	--SetFighting(inst,true)
	local target = data.target
	print(inst)
	print(data)
	--print(inst.blood_damage)
	print(data.damage)
	--print(fin)
	local namea = minions[math.random(1,#minions)]
	local nameb = minions[math.random(1,#minions)]
	if data.damage~=nil then inst.components.health:DoDelta(data.damage)	end 
	if target and target.components.health and target.components.health:IsDead() then
		local pos = target:GetPosition()
		DebugSpawn(namea).Transform:SetPosition(pos.x,0,pos.z)
		DebugSpawn(nameb).Transform:SetPosition(pos.x,0,pos.z)
	end
end

local function Retarget(inst)
	--SetFighting(inst,true)
    if not inst.components.health:IsDead() and not inst.components.sleeper:IsAsleep() then
        local oldtarget = inst.components.combat.target
        local newtarget = FindEntity(inst, 10, 
            function(guy) 
                return inst.components.combat:CanTarget(guy) 
            end,
            { "character", "_combat" },
            { "monster", "INLIMBO","tadalin" }
        )

        if newtarget ~= nil and newtarget ~= oldtarget then
            inst.components.combat:SetTarget(newtarget)
        end
    end
end

local function CalcSanityAura(inst, observer)
    return observer:HasTag("spiderwhisperer") and 0 or -TUNING.SANITYAURA_HUGE
end

local function ShareTargetFn(dude)
    return  (dude:HasTag("spider") or dude:HasTag("tadalin")) and not dude.components.health:IsDead()
end

local function OnAttacked(inst, data)
	--SetFighting(inst,true)
    if data.attacker ~= nil then
        inst.components.combat:SetTarget(data.attacker)
        inst.components.combat:ShareTarget(data.attacker, SHARE_TARGET_DIST, ShareTargetFn, 2)
    end
end

local function ondeath(inst)
	--SetFighting(inst,false)
end 

local function BabyCount(inst)
    return inst.components.leader.numfollowers
end

local function MakeBaby(inst)
    local angle = inst.Transform:GetRotation() / DEGREES
    local prefab = "spiderden"
    local spider = DebugSpawn(prefab)
    if spider ~= nil then
        local rad = spider:GetPhysicsRadius(0) + inst:GetPhysicsRadius(0) + .25
        local x, y, z = inst.Transform:GetWorldPosition()
        spider.Transform:SetPosition(x + rad * math.cos(angle), 0, z + rad * math.sin(angle))
        --spider.sg:GoToState("taunt")
       -- inst.components.leader:AddFollower(spider)
       -- if inst.components.combat.target ~= nil then
            --spider.components.combat:SetTarget(inst.components.combat.target)
       -- end
    end
end

local function MaxBabies(inst)
    local x, y, z = inst.Transform:GetWorldPosition()
    local ents = TheSim:FindEntities(x, 0, z, TUNING.SPIDERQUEEN_NEARBYPLAYERSDIST, { "player" }, { "playerghost" })
    return RoundBiasedDown(math.pow(#ents * 20, 1 / 1.4))
end

local function AdditionalBabies(inst)
    local x, y, z = inst.Transform:GetWorldPosition()
    local ents = TheSim:FindEntities(x, 0, z, TUNING.SPIDERQUEEN_NEARBYPLAYERSDIST, { "player" }, { "playerghost" })
    return RoundBiasedUp(#ents * .5)
end

local function fn()
    local inst = CreateEntity()
	
	--spider_higher_damage = 0
	
    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddLightWatcher()
    inst.entity:AddDynamicShadow()
    inst.entity:AddNetwork()

    MakeCharacterPhysics(inst, 1500, 3)
    inst.DynamicShadow:SetSize(7*1.5, 3*1.5)
    inst.Transform:SetFourFaced()

    inst:AddTag("cavedweller")
    inst:AddTag("monster")
    inst:AddTag("hostile")
    inst:AddTag("epic")
	inst:AddTag("noepicmusic")
    inst:AddTag("largecreature")
    inst:AddTag("spider_higher")
    inst:AddTag("spider")
	inst:AddTag("tadalin")
	--inst:AddTag("largecreature")
    inst.AnimState:SetBank("spider_queen")
    inst.AnimState:SetBuild("spider_higher_1")
    inst.AnimState:PlayAnimation("idle", true)
	inst.Transform:SetScale(1.5,1.5,1.5)
	
	inst:AddComponent("talker")
	inst.components.talker.fontsize = 35
    inst.components.talker.font = TALKINGFONT
    inst.components.talker:MakeChatter()
	
    inst.entity:SetPristine()
	
	if not TheNet:IsDedicated() then
        inst._playingmusic = false
        inst:DoPeriodicTask(1, PushMusic, 0)
    end
	
    if not TheWorld.ismastersim then
        return inst
    end
    inst.Physics:SetCollisionCallback(oncollide)

    inst.structuresDestroyed = 0
    inst:SetStateGraph("SGhigher")

    inst:AddComponent("lootdropper")
    inst.components.lootdropper:SetLoot(loot)

    ---------------------
    MakeLargeBurnableCharacter(inst, "body")
    MakeLargeFreezableCharacter(inst, "body")
    inst.components.burnable.flammability = TUNING.SPIDER_FLAMMABILITY

    ------------------
    inst:AddComponent("health")
    inst.components.health:SetMaxHealth(2250)

    ------------------

    inst:AddComponent("combat")
    inst.components.combat:SetRange(TUNING.SPIDERQUEEN_ATTACKRANGE*1.2)
    inst.components.combat:SetDefaultDamage(100)
    inst.components.combat:SetAttackPeriod(TUNING.SPIDERQUEEN_ATTACKPERIOD)
    inst.components.combat:SetRetargetFunction(3, Retarget)
	--inst.components.combat.onhitotherfn = function(a,b,c,d) inst.blood_damage = c end 
    ------------------

    inst:AddComponent("sanityaura")
    inst.components.sanityaura.aurafn = CalcSanityAura

    ------------------

    inst:AddComponent("sleeper")
    inst.components.sleeper:SetResistance(4)
    ------------------

    inst:AddComponent("locomotor")
    inst.components.locomotor:SetSlowMultiplier( 1 )
    inst.components.locomotor:SetTriggersCreep(false)
    inst.components.locomotor.pathcaps = { ignorecreep = true }
    inst.components.locomotor.walkspeed = TUNING.SPIDERQUEEN_WALKSPEED

    ------------------

    inst:AddComponent("eater")
    inst.components.eater:SetDiet({ FOODTYPE.MEAT }, { FOODTYPE.MEAT })
    inst.components.eater:SetCanEatHorrible()
    inst.components.eater.strongstomach = true -- can eat monster meat!

    ------------------

    inst:AddComponent("incrementalproducer")
    inst.components.incrementalproducer.countfn = BabyCount
    inst.components.incrementalproducer.producefn = MakeBaby
    inst.components.incrementalproducer.maxcountfn = MaxBabies
    inst.components.incrementalproducer.incrementfn = AdditionalBabies
    inst.components.incrementalproducer.incrementdelay = TUNING.SPIDERQUEEN_GIVEBIRTHPERIOD

    ------------------

    inst:AddComponent("inspectable")

    inst:AddComponent("leader")

    MakeHauntableGoToState(inst, "poop", TUNING.HAUNT_CHANCE_OCCASIONAL, TUNING.HAUNT_COOLDOWN_MEDIUM, TUNING.HAUNT_CHANCE_LARGE)

    ------------------

    inst:SetBrain(brain)
	--inst.blood_damage = 0
    inst:ListenForEvent("attacked", OnAttacked)
    inst:ListenForEvent("onhitother", onattack)
	inst:ListenForEvent("death",ondeath)
    return inst
end

return Prefab("spider_higher", fn, assets, prefabs)
