--ThePlayer.sg:GoToState("fenix_sword_attack_pre",c_findnext(""))

AddStategraphState("wilson", 
 State{
		name = "fenix_sword_attack_pre",
        tags = { "fenix_skill","attack", "notalking", "abouttoattack", "nopredict" },
		onenter = function(inst,target)
			
			
			inst.sg.statemem.fenix_sword_attack_target = target
            inst.Physics:Stop()
            inst.components.combat:StartAttack()

			inst.Transform:SetScale(0.5,0.5,0.5)
			inst:ForceFacePoint(target.Transform:GetWorldPosition())
			inst.AnimState:SetBank("shadow_rook")
			inst.AnimState:SetBuild("shadow_rook")
            inst.AnimState:PlayAnimation("teleport")
			--inst.AnimState:Resume()
			
			inst.components.health:SetInvincible(true)
			if inst.components.poduser then
				inst.components.poduser:SetVisiable(false) 
			end
		end,
		timeline =
		{			
			TimeEvent(0 * FRAMES, function(inst)
				inst.SoundEmitter:PlaySound("dontstarve/sanity/rook/attack_grunt")
            end),
			
			TimeEvent(12 * FRAMES, function(inst)
				inst.SoundEmitter:PlaySound("dontstarve/sanity/rook/teleport")
            end),
		},

    ontimeout = function(inst)
        --inst.sg:GoToState("idle", true)
    end,

    events =
    {
        EventHandler("animover", function(inst)
            if inst.AnimState:AnimDone() then
				inst:Hide()
				
				inst:DoTaskInTime(0.75,function()
					inst.sg:GoToState("fenix_sword_attack_teleport", inst.sg.statemem.fenix_sword_attack_target)
				end) 
            end
        end),
    },

    onexit = function(inst)
		inst:Show()
		inst.AnimState:SetBank("wilson")
		inst.AnimState:SetBuild(inst.prefab)
		inst.Transform:SetScale(1,1,1)
		inst.components.health:SetInvincible(false)
		if inst.components.poduser then
			inst.components.poduser:SetVisiable(true) 
		end
    end,
		
}
)

AddStategraphState("wilson_client", 
 State{
		name = "fenix_sword_attack_pre",
        tags = { "fenix_skill","attack", "notalking", "abouttoattack", "nopredict" },
		onenter = function(inst,target)
			
			
			inst.sg.statemem.fenix_sword_attack_target = target
            inst.Physics:Stop()
            inst.replica.combat:StartAttack()

			inst.Transform:SetScale(0.5,0.5,0.5)
			inst:ForceFacePoint(target.Transform:GetWorldPosition())
			inst.AnimState:SetBank("shadow_rook")
			inst.AnimState:SetBuild("shadow_rook")
            inst.AnimState:PlayAnimation("teleport")
			--inst.AnimState:Resume()
		end,
		timeline =
		{			
			TimeEvent(0 * FRAMES, function(inst)
				inst.SoundEmitter:PlaySound("dontstarve/sanity/rook/attack_grunt")
            end),
			
			TimeEvent(12 * FRAMES, function(inst)
				inst.SoundEmitter:PlaySound("dontstarve/sanity/rook/teleport")
            end),
		},

    ontimeout = function(inst)
        --inst.sg:GoToState("idle", true)
    end,

    events =
    {
        EventHandler("animover", function(inst)
            if inst.AnimState:AnimDone() then
				inst:Hide()
				
				inst:DoTaskInTime(0.75,function()
					inst.sg:GoToState("fenix_sword_attack_teleport", inst.sg.statemem.fenix_sword_attack_target)
				end) 
            end
        end),
    },

    onexit = function(inst)
		inst:Show()
		inst.AnimState:SetBank("wilson")
		inst.AnimState:SetBuild(inst.prefab)
		inst.Transform:SetScale(1,1,1)
    end,
		
}
)

AddStategraphState("wilson", 
 State{
		name = "fenix_sword_attack_teleport",
        tags = { "fenix_skill","attack", "notalking", "abouttoattack", "nopredict" },
		onenter = function(inst,target)
			inst.sg.statemem.fenix_sword_attack_target = target
            inst.Physics:Stop()
			local fx = inst:SpawnChild("icey_shield")
			fx.AnimState:SetMultColour(0/255,218/255,164/255,0.8)
			fx.Transform:SetPosition(0,-1,0)
			local targetpos = target:GetPosition()
			local offset = FindWalkableOffset(targetpos, math.random(0,360), 2.5, nil, true, true) or Vector3(0,0,0)
			inst.Transform:SetPosition((targetpos+offset):Get())
			inst:ForceFacePoint(target.Transform:GetWorldPosition())
			inst.AnimState:PlayAnimation("multithrust_yell")
			inst.AnimState:PushAnimation("lunge_pre",false)
			inst.AnimState:PushAnimation("atk_leap",false)
            --inst.SoundEmitter:PlaySound("dontstarve/common/deathpoof")
			inst.components.health:SetInvincible(true)
		end,
		timeline =
		{			
			TimeEvent(15 * FRAMES, function(inst)
                inst.SoundEmitter:PlaySound("dontstarve/common/twirl", nil, nil, true)
            end),
			TimeEvent(32 * FRAMES, function(inst)
                ShakeAllCameras(CAMERASHAKE.VERTICAL, .7, .015, .8, inst, 20)
                inst.sg:RemoveStateTag("nointerrupt")
				inst.components.combat:DoAttack(inst.sg.statemem.fenix_sword_attack_target)
				inst.components.combat:DoAttack(inst.sg.statemem.fenix_sword_attack_target)
				inst.components.combat:DoAreaAttack(inst.sg.statemem.fenix_sword_attack_target,2.5, 
					inst.components.combat:GetWeapon(), nil, nil, { "INLIMBO","companion" })
				inst.SoundEmitter:PlaySound("dontstarve/common/destroy_smoke",nil,nil,true)
            end),
		},

    ontimeout = function(inst)
        --inst.sg:GoToState("idle", true)
    end,

    events =
    {
        EventHandler("animover", function(inst)
            if inst.AnimState:AnimDone() then
                inst.sg:GoToState("idle")
            end
        end),
    },

    onexit = function(inst)
		inst.components.health:SetInvincible(false)
    end,
		
}
)

AddStategraphState("wilson_client", 
 State{
		name = "fenix_sword_attack_teleport",
        tags = { "fenix_skill","attack", "notalking", "abouttoattack", "nopredict" },
		onenter = function(inst,target)
			inst.sg.statemem.fenix_sword_attack_target = target
            inst.Physics:Stop()
			inst:ForceFacePoint(target.Transform:GetWorldPosition())
			inst.AnimState:PlayAnimation("multithrust_yell")
			inst.AnimState:PushAnimation("lunge_pre",false)
			inst.AnimState:PushAnimation("atk_leap",false)
		end,
		timeline =
		{			
			TimeEvent(15 * FRAMES, function(inst)
                inst.SoundEmitter:PlaySound("dontstarve/common/twirl", nil, nil, true)
            end),
			TimeEvent(32 * FRAMES, function(inst)
                ShakeAllCameras(CAMERASHAKE.VERTICAL, .7, .015, .8, inst, 20)
                inst.sg:RemoveStateTag("nointerrupt")
				inst.SoundEmitter:PlaySound("dontstarve/common/destroy_smoke",nil,nil,true)
            end),
		},

    ontimeout = function(inst)
        --inst.sg:GoToState("idle", true)
    end,

    events =
    {
        EventHandler("animover", function(inst)
            if inst.AnimState:AnimDone() then
                inst.sg:GoToState("idle")
            end
        end),
    },

    onexit = function(inst)
	
    end,
		
}
)