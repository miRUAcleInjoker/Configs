
local assets =
{
	Asset("ANIM", "anim/living_artifact.zip"),
	
	Asset("IMAGE", "images/inventoryimages/icey_living_artifact.tex"),
    Asset("ATLAS", "images/inventoryimages/icey_living_artifact.xml"),
}




local function CanInteract(inst,doer)
    if doer and doer:HasTag("player") and not doer:HasTag("playerghost") and not doer.were 
	and (not doer.components.rider or not doer.components.rider:IsRiding()) 
	and (doer.components.icey_ironlord and not doer.components.icey_ironlord:IsIronLord()) 
	and inst.components.inventoryitem:GetGrandOwner() == doer 
	then
        return true
    end
end

local function OnActivate(inst)
    local doer = inst.components.inventoryitem:GetGrandOwner()
	if CanInteract(inst,doer) then 
		doer.components.icey_ironlord:DoDelta(180)
		doer.components.icey_ironlord:BecomeIronLord() 
		doer.components.inventory:DropItem(inst) 
		inst.AnimState:PlayAnimation("activate")
		inst:ListenForEvent("animover",function() 
			if inst.AnimState:IsCurrentAnimation("activate") then
				inst:Remove()
			end
		end)
	end
	
	--inst.components.useableitem.inuse = false 
end

local function onequip(inst,owner)
	--inst:DoTaskInTime(0,OnActivate) 
end 

local function fn(Sim)
	local inst = CreateEntity()
	
	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddNetwork()
	
	
    MakeInventoryPhysics(inst)

    inst.AnimState:SetBank("living_artifact")
    inst.AnimState:SetBuild("living_artifact")
    inst.AnimState:PlayAnimation("idle")
	
	inst.entity:SetPristine()	
	
    if not TheWorld.ismastersim then
        return inst
    end	  
    
    inst:AddComponent("inspectable")

    --inst:AddComponent("machine")
    --inst.components.machine.turnonfn = OnActivate
	--inst.components.machine.caninteractfn = CanInteract
	--inst.components.machine.cooldowntime  = 99999 
	inst:AddComponent("useableitem")------ 
    inst.components.useableitem:SetOnUseFn(OnActivate)

    inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "icey_living_artifact"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/icey_living_artifact.xml"
	
	inst:AddComponent("equippable")
	inst.components.equippable:SetOnEquip(onequip)

    return inst
end



return Prefab( "icey_living_artifact", fn, assets)

