require "brains/spidermonkeybrain"
require "stategraphs/SGspidermonkey"

local assets = 
{
	--Asset("ANIM", "anim/kiki_basic.zip"),
	--Asset("ANIM", "anim/spidermonkey_build.zip"),
    Asset("ANIM", "anim/spiderape_basics.zip"),
    Asset("ANIM", "anim/spiderape_build.zip"),
	Asset("ANIM", "anim/spider_monkey_ender.zip"),
	Asset("SOUND", "sound/monkey.fsb"),
}

local prefabs = 
{
	"poop",
	"monkeyprojectile",
	"monstermeat",
	"spidergland",
}

local SLEEP_DIST_FROMHOME   = 1
local SLEEP_DIST_FROMTHREAT = 20
local MAX_CHASEAWAY_DIST    = 32
local MAX_TARGET_SHARES     = 5
local SHARE_TARGET_DIST     = 40

SetSharedLootTable('spider_monkey',
{
    {'monstermeat',     1.0},
    {'monstermeat',     1.0},    
    {'spidergland',    0.75},
    {'beardhair',      0.75},
    {'beardhair',      0.75},
    {'beardhair',      0.75},
    {'silk',           0.25},
})

local function PushMusic(inst)
    if ThePlayer == nil then
        inst._playingmusic = false
    elseif ThePlayer:IsNear(inst, inst._playingmusic and 40 or 20) then
		--print(inst,ThePlayer,"Push the triggeredevent at",GetTime())
        inst._playingmusic = true
        ThePlayer:PushEvent("triggeredevent", { name = "spider_monkey" ,duration = 3})
    elseif inst._playingmusic and not ThePlayer:IsNear(inst, 50) then
        inst._playingmusic = false
    end
end

local function WeaponDropped(inst)
    inst:Remove()
end

local function oneat(inst)
	-- Monkey ate some food. Give him some poop!
	if inst.components.inventory then
		local maxpoop = 3
		local poopstack = inst.components.inventory:FindItem(function(item) return item.prefab == "poop" end)
		if poopstack and poopstack.components.stackable.stacksize < maxpoop then
			local newpoop = SpawnPrefab("poop")
			inst.components.inventory:GiveItem(newpoop)
		elseif not poopstack then
			local newpoop = SpawnPrefab("poop")
			inst.components.inventory:GiveItem(newpoop)
		end
	end
end

local function onthrow(weapon, inst)
	if inst.components.inventory then
		local poopstack = inst.components.inventory:FindItem(function(item) return item.prefab == "poop" end)
		if poopstack then
			inst.components.inventory:ConsumeByName("poop", 1)
		end
	end
end

local function hasammo(inst)
	if inst.components.inventory then
		local poopstack = inst.components.inventory:FindItem(function(item) return item.prefab == "poop" end)
		return poopstack ~= nil
	end
end

local function GetWeaponMode(weapon)
	local inst = weapon.components.inventoryitem.owner
	if hasammo(inst) and (inst.components.combat.target and inst.components.combat.target:HasTag("player")) then
		return weapon.components.weapon.modes["RANGE"]
	else
		return weapon.components.weapon.modes["MELEE"]
	end
end

local function MakeProjectileWeapon(inst)
    if inst.components.inventory then
        local weapon = CreateEntity()
        weapon.entity:AddTransform()
        MakeInventoryPhysics(weapon)
        weapon:AddComponent("weapon")
        weapon.components.weapon:SetDamage(1)
        -- weapon.components.weapon:SetRange(17)
        weapon.components.weapon.modes =
        {
        	RANGE = {damage = 0, ranged = true, attackrange = 17, hitrange = 17 + 2},
        	MELEE = {damage = 20, ranged = false, attackrange = 0, hitrange = 1}
    	}
        weapon.components.weapon.variedmodefn = GetWeaponMode
        weapon.components.weapon:SetProjectile("monkeyprojectile")
        weapon.components.weapon:SetOnProjectileLaunch(onthrow)
        weapon:AddComponent("inventoryitem")
        weapon.persists = false
        weapon.components.inventoryitem:SetOnDroppedFn(function() WeaponDropped(weapon) end)
        weapon:AddComponent("equippable")
        inst.components.inventory:Equip(weapon)
        return weapon
    end
end



local function OnAttacked(inst, data)
	inst.components.combat:SuggestTarget(data.attacker)
	inst.components.combat:ShareTarget(data.attacker, 30, function(dude)
        return  (dude:HasTag("spider") or dude:HasTag("tadalin"))
            and not dude.components.health:IsDead()
    end, 10)
end


local function retargetfn(inst)
	return FindEntity(
        inst,
        30,
        function(guy)
            return inst.components.combat:CanTarget(guy)
        end,
        { "_combat" }, --See entityreplica.lua (re: "_combat" tag)
        { "monster","tadalin","structure","prey","smallcreature"}
    )
end

local function KeepTarget(inst, target)
    return true
end

local function IsInCharacterList(name)
	local characters = GetActiveCharacterList()

	for k,v in pairs(characters) do
		if name == v then
			return true
		end
	end
end

local function OnMonkeyDeath(inst, data)
	if data.inst:HasTag("monkey") then	-- A monkey died! 
		if IsInCharacterList(data.cause) then	-- And it was the player! Run home!
			-- Drop all items, go home
			inst:DoTaskInTime(math.random(), function() 
				if inst.components.inventory then
					inst.components.inventory:DropEverything(false, true)
				end

				if inst.components.homeseeker and inst.components.homeseeker.home then
					inst.components.homeseeker.home:PushEvent("monkeydanger")
				end
			end)
		end
	end
end

local function onpickup(inst, data)
	if data.item then
		if data.item.components.equippable and
		data.item.components.equippable.equipslot == EQUIPSLOTS.HEAD and not 
		inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HEAD) then
			-- Ugly special case for how the PICKUP action works.
			-- Need to wait until PICKUP has called "GiveItem" before equipping item.
			inst:DoTaskInTime(0.1, function() inst.components.inventory:Equip(data.item) end)		
		end
	end
end

local function DoFx(inst)
    if ExecutingLongUpdate then
        return
    end
    inst.SoundEmitter:PlaySound("dontstarve/common/ghost_spawn")
    
    local fx = SpawnPrefab("statue_transition_2")
    if fx then
        fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
        fx.AnimState:SetScale(.8, .8, .8)
    end
    fx = SpawnPrefab("statue_transition")
    if fx then
        fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
        fx.AnimState:SetScale(.8, .8, .8)
    end
end

local function onnear(inst) 
    inst:AddTag("agitated")
    inst:PushEvent("agitated")
    -- inst.components.locomotor.walkspeed = TUNING.SPIDER_MONKEY_SPEED_AGITATED
end

local function onfar(inst) 
    inst:RemoveTag("agitated")
    -- inst.components.locomotor.walkspeed = TUNING.SPIDER_MONKEY_SPEED
end

local function OnSave(inst, data)

end

local function OnLoad(inst, data)

end

local function OnHitOther(inst, data) --knockback
	local other = data.target
	if other.sg  then
		other:PushEvent("knockback", {knocker = inst, radius = 5})
	else
	--this stuff below is mostly left here for creatures in basegame. For modders that are reading this, use the knockback event above.
	if other ~= nil and not (other:HasTag("epic") or other:HasTag("largecreature")) then
		
		if other:IsValid() and other.entity:IsVisible() and not (other.components.health ~= nil and other.components.health:IsDead()) then
            if other.components.combat ~= nil then
                --other.components.combat:GetAttacked(inst, 10)
                if other.Physics ~= nil then
					local x, y, z = inst.Transform:GetWorldPosition()
                    local distsq = other:GetDistanceSqToPoint(x, 0, z)

						other:ForceFacePoint(x, 0, z)
						local k = .5 * distsq / 9 - 1
						other.speed = 60 * k
						other.dspeed = 2
						other.Physics:ClearMotorVelOverride()
						other.Physics:Stop()
						
						if other.components.inventory and other.components.inventory:ArmorHasTag("heavyarmor") or other:HasTag("heavybody") then 
						--Leo: Need to change this to check for bodyslot for these tags.
						other:DoTaskInTime(0.1, function(inst) 
							other.Physics:Stop()
							other.Physics:SetMotorVelOverride(-2, 0, 0) 
						end)
						else
						other:DoTaskInTime(0, function(inst) 
							other.Physics:Stop()
							other.Physics:SetMotorVelOverride(-20, 0, 0) 
						end)
						end
						other:DoTaskInTime(0.4, function(inst) 
							other.Physics:ClearMotorVelOverride()
							other.Physics:Stop()
						end)
					--end
                end
            end
        end
	end
	end
end



local function fn()
	local inst = CreateEntity()
	local trans = inst.entity:AddTransform()
	local anim = inst.entity:AddAnimState()
	local sound = inst.entity:AddSoundEmitter()	
    inst.soundtype = ""
	local shadow = inst.entity:AddDynamicShadow()
	inst.entity:AddNetwork()
	shadow:SetSize(2, 1.25)
	
	inst.Transform:SetFourFaced()

	--inst.Transform:SetScale(2.2, 2.2, 2.2)
	MakeCharacterPhysics(inst, 40, 1.5)
   

    anim:SetBank("spiderape")
	anim:SetBuild("spider_monkey_ender")
	
	anim:PlayAnimation("idle_loop", true)
	
	trans:SetScale(1.3,1.3,1.2)

	inst:AddTag("spider_monkey")
	inst:AddTag("animal")
	inst:AddTag("spider")
	inst:AddTag("tadalin")
	inst:AddTag("epic")
	inst:AddTag("noepicmusic")
	
	inst._playingmusic = false
	if not TheNet:IsDedicated() then
        inst:DoPeriodicTask(1, PushMusic,0)
    end
	
	inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

	inst:AddComponent("inventory")

	inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("末日巨兽好兄弟")

	inst:AddComponent("thief")

    inst:AddComponent("locomotor")
    inst.components.locomotor:SetSlowMultiplier(1)
    inst.components.locomotor:SetTriggersCreep(false)
    inst.components.locomotor.pathcaps = { ignorecreep = false }
    inst.components.locomotor.walkspeed = 10
    inst.components.locomotor.runspeed = 12 

    inst:AddComponent("combat")
	inst.components.combat.areahitdamagepercent = 0.75
    inst.components.combat:SetAttackPeriod(1)
    inst.components.combat:SetRange(4)
    inst.components.combat:SetRetargetFunction(1, retargetfn)
    inst.components.combat:SetDefaultDamage(80)
    inst.components.combat:SetKeepTargetFunction(KeepTarget)

    inst:AddComponent("health")
    inst.components.health:SetMaxHealth(3500)
    
    inst:AddComponent("periodicspawner")
    inst.components.periodicspawner:SetPrefab("poop")
    inst.components.periodicspawner:SetRandomTimes(200, 400)
    inst.components.periodicspawner:SetDensityInRange(20, 2)
    inst.components.periodicspawner:SetMinimumSpacing(15)
    inst.components.periodicspawner:Start()

    inst:AddComponent("lootdropper")
    inst.components.lootdropper:SetChanceLootTable("spider_monkey")
    inst.components.lootdropper.droppingchanceloot = false

	inst:AddComponent("eater")
	--inst.components.eater:SetVegetarian()
	inst.components.eater:SetOnEatFn(oneat)

	--inst:AddComponent("sleeper")
	-- inst.components.sleeper:SetNocturnal()

    inst:AddComponent("knownlocations")
    inst:AddComponent("herdmember")
    inst.components.herdmember:SetHerdPrefab("spider_monkey_herd")

	inst:AddComponent("playerprox")
    inst.components.playerprox:SetDist(20, 23)
    inst.components.playerprox:SetOnPlayerNear(onnear)
    inst.components.playerprox:SetOnPlayerFar(onfar)
    
	inst:AddComponent("sanityaura")
    inst.components.sanityaura.aura = -25

	local brain = require "brains/spidermonkeybrain"
	inst:SetBrain(brain)
	inst:SetStateGraph("SGspidermonkey")

	inst.HasAmmo = hasammo
	inst.curious = true

    inst.listenfn = function(listento, data) OnMonkeyDeath(inst, data) end

	inst:ListenForEvent("onpickup", onpickup)
    inst:ListenForEvent("attacked", OnAttacked)
	inst:ListenForEvent("onhitother", OnHitOther)
	inst:DoTaskInTime(60,function()
		if inst and inst:IsValid() and inst.components.health and not inst.components.health:IsDead() then 
			inst.sg:GoToState("taunt",true)
		end 
	end)

    --inst.weapon = MakeProjectileWeapon(inst)

    inst.OnSave = OnSave
    inst.OnLoad = OnLoad
	
	MakeMediumBurnableCharacter(inst)
    MakeMediumFreezableCharacter(inst)

	return inst
end

return Prefab("spider_monkey", fn, assets, prefabs)
