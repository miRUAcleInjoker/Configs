require "behaviours/follow"
require "behaviours/standstill"

local WugongBodyBrain = Class(Brain, function(self, inst)
    Brain._ctor(self, inst)
end)

local MIN_FOLLOW = 0.5
local MED_FOLLOW = 0.5
local MAX_FOLLOW = 0.5

local function HasValidLeader(inst)
	return inst:GetHost()
end 

local function NeedStop(inst)
	return not HasValidLeader(inst) or (not inst:GetHost().sg:HasStateTag("moving"))
end 

function WugongBodyBrain:OnStart()
    local root = PriorityNode(
    {
		Follow(self.inst, function() return self.inst.components.follower.leader end, MIN_FOLLOW, MED_FOLLOW, MAX_FOLLOW)
    }, 0.01)

    self.bt = BT(self.inst, root)
end

return WugongBodyBrain
