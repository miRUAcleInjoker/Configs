local MoonGiaourSpawner = Class(function(self, inst)
	self.inst = inst
	self.sacrifice_num = 0
	self.max_sacrifice_num = 4 
	
	self.activited = false
	--self.attackers = {}
end)

function MoonGiaourSpawner:GetNums()
	return self.sacrifice_num
end 

function MoonGiaourSpawner:Set(num)
	self.sacrifice_num = num 
	self.sacrifice_num = math.max(self.sacrifice_num,0)
	if self.sacrifice_num >= self.max_sacrifice_num then 
		self:SpawnGiaour()
		self.sacrifice_num = 0
		self.activited = false 
	end
end 

function MoonGiaourSpawner:DoDelta(delta)
	print("MoonGiaourSpawner:DoDelta",delta)
	self:Set(self:GetNums() + delta)
end 

function MoonGiaourSpawner:SpawnMinions()
	if self.activited or FindEntity(self.inst, 10000, function(guy) return guy.prefab == "moon_giaour" end) then 
		return 
	end 
	self.activited = true 
	for i=1,4 do 
		local minion = SpawnPrefab("moon_giaour_minion")
		local pos = self.inst:GetPosition()
		local offset = Vector3(3*(1-math.random()*2),0,3*(1-math.random()*2))
		minion.Transform:SetPosition((pos + offset):Get())
		minion.components.knownlocations:RememberLocation("moonbase",pos,true)
	end
end 

function MoonGiaourSpawner:SpawnGiaour()
	local pos = self.inst:GetPosition()
	local offset = Vector3(3*(1-math.random()*2),0,3*(1-math.random()*2))
	local finalpos = (pos + offset)
	
	local prefx = SpawnPrefab("moon_giaour_prefx")
	prefx.Transform:SetPosition(finalpos:Get())
	
	--[[self.inst:DoTaskInTime(3,function()
		local prefx = SpawnPrefab("tadalin_meteor")
		prefx.Transform:SetPosition(finalpos:Get())
		
		self.inst:DoTaskInTime(0.3,function()
			local boss = SpawnPrefab("moon_giaour")
			boss.Transform:SetPosition(finalpos:Get())
		end)
	end)--]]
end 

function MoonGiaourSpawner:OnSave()
	return {
		activited = self.activited,
		sacrifice_num = self.sacrifice_num,
	}
end

function MoonGiaourSpawner:OnLoad(data)
	if data then 
		self.sacrifice_num = data.sacrifice_num
		self.activited = data.activited
	end 
end

function MoonGiaourSpawner:Debug()
	return "MoonGiaourSpawner: Nums:"..self:GetNums()
end


return MoonGiaourSpawner