local assets =
{
    Asset("ANIM", "anim/crystal_crab.zip"),
}

local prefabs =
{
    "quagmire_crabmeat",
}

local brain = require "brains/crystal_crabbrain"


local function CreateShell(bank, build, anim,lightoverride, addcolour, multcolour,scale)
  local inst = CreateEntity()
  scale = scale or 1

  inst:AddTag("FX")
  inst:AddTag("NOCLICK")
  --[[Non-networked entity]]
  inst.entity:SetCanSleep(false)
  inst.persists = false

  inst.entity:AddTransform()
  inst.entity:AddAnimState()

  MakeInventoryPhysics(inst)
  inst.Physics:ClearCollisionMask()

  inst.AnimState:SetBank(bank)
  inst.AnimState:SetBuild(build)
  inst.AnimState:PlayAnimation(anim)

  inst.Transform:SetScale(scale,scale,scale)
  if addcolour ~= nil then
    inst.AnimState:SetAddColour(unpack(addcolour))
  end
  if multcolour ~= nil then
    inst.AnimState:SetMultColour(unpack(multcolour))
  end
  if lightoverride > 0 then
    inst.AnimState:SetLightOverride(lightoverride)
  end
  inst.AnimState:SetFinalOffset(-1)

  --inst:ListenForEvent("animover", inst.Remove)

  return inst
end

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddDynamicShadow()
    inst.entity:AddNetwork()

    MakeCharacterPhysics(inst, 1, .25)

    inst.DynamicShadow:SetSize(1, .75)
    inst.Transform:SetSixFaced()

    inst.AnimState:SetBank("crystal_crab")
    inst.AnimState:SetBuild("crystal_crab")
    inst.AnimState:PlayAnimation("idle")

    inst:AddTag("animal")
    inst:AddTag("prey")
    inst:AddTag("smallcreature")
    inst:AddTag("canbetrapped")
    inst:AddTag("cattoy")
    inst:AddTag("crab")

    MakeFeedableSmallLivestockPristine(inst)

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst:AddComponent("health")
	inst.components.health:SetMaxHealth(50)
	
	inst:AddComponent("combat")
	
	inst:AddComponent("locomotor")
	inst.components.locomotor.runspeed = 1
    inst.components.locomotor.walkspeed = 4
	
	inst:SetStateGraph("SGcrystal_crab")
	inst:SetBrain(brain)
	
	inst.CreateShell = CreateShell
	

    --event_server_data("quagmire", "prefabs/quagmire_pebblecrab").master_postinit(inst)

    return inst
end

return Prefab("crystal_crab", fn, assets, prefabs)
