--[[
���´���ȫ��copy����¯mod���������ٺٺٺٺ�
]]

local data = {
	---------------------------------------------------------------------------
	--Forge Season 1
	armorlight = {
		prefab = "reedtunic",
		tags = { "grass" },
		foleysound = "dontstarve/movement/foley/grassarmour",
		hitsound = "dontstarve/wilson/hit_armour",
		cooldown_rate = 0.90,
		masterfn = function(inst)
			inst.components.armor:InitCondition(300,0.55)
			inst.components.equippable.stamina_consumerate = 0.85
			inst.components.equippable.stamina_recoverrate = 1.15
		end
	},
	
	armorlightspeed = {
		prefab = "featheredtunic",
		tags = { "grass" },
		foleysound = "dontstarve/movement/foley/grassarmour",
		hitsound = "dontstarve/wilson/hit_armour",
		masterfn = function(inst)
			inst.components.armor:InitCondition(350,0.60)
			inst.components.equippable.walkspeedmult = 1.10
			inst.components.equippable.stamina_consumerate = 0.90
			inst.components.equippable.stamina_recoverrate = 1.10
		end
	},
	
	armormedium = {
		prefab = "forge_woodarmor",
		tags = { "wood" },
		foleysound = "dontstarve/movement/foley/logarmour",
		hitsound = "dontstarve/wilson/hit_armour",
		masterfn = function(inst)
			inst.components.armor:InitCondition(450,0.80)
		end
	},
	
	armormediumdamager = {
		prefab = "jaggedarmor",
		tags = { "wood" },
		foleysound = "dontstarve/movement/foley/logarmour",
		hitsound = "dontstarve/wilson/hit_armour",
		damage_multi = 1.10,
		masterfn = function(inst)
			inst.components.armor:InitCondition(400,0.80)
		end
	},
	
	armormediumrecharger = {
		prefab = "silkenarmor",
		tags = { "wood" },
		foleysound = "dontstarve/movement/foley/logarmour",
		hitsound = "dontstarve/wilson/hit_armour",
		cooldown_rate = 0.85,
		masterfn = function(inst)
			inst.components.armor:InitCondition(400,0.80)
		end
	},
	
	armorheavy = {
		prefab = "splintmail",
		tags = { "marble" },
		foleysound = "dontstarve/movement/foley/marblearmour",
		hitsound = "dontstarve/wilson/hit_marble",
		masterfn = function(inst)
			inst.components.armor:InitCondition(600,0.85)
		end
	},
	
	armorextraheavy = {
		prefab = "steadfastarmor",
		tags = { "marble", "heavyarmor" },
		foleysound = "dontstarve/movement/foley/marblearmour",
		hitsound = "dontstarve/wilson/hit_marble",
		masterfn = function(inst)
			inst.components.armor:InitCondition(1200,0.98)
			inst.components.equippable.walkspeedmult = 0.65
			inst.components.equippable.stamina_consumerate = 1.35
			inst.components.equippable.stamina_recoverrate = 0.65
		end
	},
	
	---------------------------------------------------------------------------
	--Forge Season 2
	armor_hpextraheavy = {
		prefab = "steadfastgrandarmor",
		tags = { "ruins", "metal", "heavyarmor" },
		foleysound = "dontstarve/movement/foley/metalarmour",
		hitsound = "dontstarve/wilson/hit_metal",
		masterfn = function(inst)
			inst.nameoverride = "lavaarena_armor_hpextraheavy"
			inst.components.armor:InitCondition(1200,0.95)
		end
	},
	
	armor_hppetmastery = {
		prefab = "whisperinggrandarmor",
		tags = { "ruins", "metal" },
		foleysound = "dontstarve/movement/foley/metalarmour",
		hitsound = "dontstarve/wilson/hit_metal",
		masterfn = function(inst)
			inst.nameoverride = "lavaarena_armor_hppetmastery"
			inst.components.armor:InitCondition(1200,0.90)
			inst.components.equippable.stamina_consumerate = 0.8
			inst.components.equippable.stamina_recoverrate = 1.2
		end
	},
	
	armor_hprecharger = {
		prefab = "silkengrandarmor",
		tags = { "ruins", "metal" },
		foleysound = "dontstarve/movement/foley/metalarmour",
		hitsound = "dontstarve/wilson/hit_metal",
		cooldown_rate = 0.7,
		masterfn = function(inst)
			inst.nameoverride = "lavaarena_armor_hprecharger"
			inst.components.armor:InitCondition(1200,0.90)
		end
	},
	
	armor_hpdamager = {
		prefab = "jaggedgrandarmor",
		tags = { "ruins", "metal" },
		foleysound = "dontstarve/movement/foley/metalarmour",
		hitsound = "dontstarve/wilson/hit_metal",
		damage_multi = 1.20,
		cooldown_rate = 0.85,
		masterfn = function(inst)
			inst.nameoverride = "lavaarena_armor_hpdamager"
			inst.components.armor:InitCondition(1200,0.95)
		end
	},
}

local function MakeArmour(name)
	local build = name
	if not name:find("armor_") then
		build = build:gsub("armor", "armor_")
	end
	
    local assets = {
        Asset("ANIM", "anim/"..build..".zip"),
    }
	
	local function OnBlocked(owner) 
		owner.SoundEmitter:PlaySound(data[name].hitsound)
	end
	
	local function onequip(inst, owner)
		owner.AnimState:OverrideSymbol("swap_body", build, "swap_body")
		inst:ListenForEvent("blocked", OnBlocked, owner)
		
		if data[name].damage_multi then 
			owner.components.combat.externaldamagemultipliers:SetModifier(inst,data[name].damage_multi,inst.prefab)
		end
	end

	local function onunequip(inst, owner) 
		owner.AnimState:ClearOverrideSymbol("swap_body")
		inst:RemoveEventCallback("blocked", OnBlocked, owner)
		
		if data[name].damage_multi then 
			owner.components.combat.externaldamagemultipliers:RemoveModifier(inst,inst.prefab)
		end
	end

    local function fn()
        local inst = CreateEntity()

        inst.entity:AddTransform()
        inst.entity:AddAnimState()
        inst.entity:AddNetwork()

        MakeInventoryPhysics(inst)
		
		inst.nameoverride = "lavaarena_"..name

        inst.AnimState:SetBank(build)
        inst.AnimState:SetBuild(build)
        inst.AnimState:PlayAnimation("anim")

        for i, v in ipairs(data[name].tags) do
            inst:AddTag(v)
        end

        inst.foleysound = data[name].foleysound

        inst.entity:SetPristine()

        if not TheWorld.ismastersim then
            return inst
        end
		
        inst:AddComponent("inventoryitem")
		inst.components.inventoryitem.imagename = "lavaarena_"..name
		
        inst:AddComponent("inspectable")

        inst:AddComponent("equippable")
        inst.components.equippable.equipslot = EQUIPSLOTS.BODY
        inst.components.equippable:SetOnEquip(onequip)
        inst.components.equippable:SetOnUnequip(onunequip)
		inst.components.equippable.cooldown_rate = data[name].cooldown_rate
		
		inst:AddComponent("armor")
		
		data[name].masterfn(inst)

        return inst
    end
	
	return Prefab("icey_forge_"..name,fn,assets)
end

local armors = {}
for k,v in pairs(data) do
    table.insert(armors, MakeArmour(k))
end
return unpack(armors)