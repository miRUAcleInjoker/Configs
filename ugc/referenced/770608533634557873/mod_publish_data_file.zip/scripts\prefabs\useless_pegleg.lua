local IceyUtil = require("icey_util")
local IceyWeaponSkillUtil = require("icey_weaponskill_util")

local assets =
{
	Asset("ANIM", "anim/swap_peg_leg.zip"),
	Asset("ANIM", "anim/peg_leg.zip"),
	Asset("IMAGE","images/inventoryimages/useless_pegleg.tex"),
	Asset("ATLAS","images/inventoryimages/useless_pegleg.xml"),
}

local function clientfn(inst)
	IceyWeaponSkillUtil.AddAoetargetingClient(inst,"line",{"iceyweaponskill_taunt"},15)
end 

local function onattack(inst, attacker, target)
	local buff = attacker.components.debuffable:GetDebuff("taunt_pegleg")
	if buff and math.random() <= 0.33 then 
		inst.components.helmsplitter.ready = true
		inst:AddTag("helmsplitter")  
	end 
end 

local function OnHelmSplit(inst,attacker,target)
	--ShakeAllCameras(CAMERASHAKE.VERTICAL, .7, .025, 1.25, inst, 40)
	--inst.SoundEmitter:PlaySound("dontstarve_DLC001/creatures/bearger/groundpound")
	inst.SoundEmitter:PlaySound("dontstarve/common/deathpoof")
end 

local function serverfn(inst)
	if not TheWorld.ismastersim then
		return inst
	end	  
	
	inst:AddComponent("helmsplitter")
	inst.components.helmsplitter:SetOnHelmSplitFn(OnHelmSplit)
	
	IceyWeaponSkillUtil.AddAoetargetingServer(inst,function(inst,doer,pos)
		if IceyUtil.DefaultCostFn(doer,{focus = 5}) then 
			inst.components.rechargeable:StartRecharge()
			inst.components.helmsplitter.ready = true 
			inst:AddTag("helmsplitter") 
			doer.components.debuffable:AddDebuff("taunt_pegleg","icey_normal_debuff")
			
			local fx = doer:SpawnChild("battlestandard_buff_fxs")
			fx:Play("attack_fx3")
			local buff = doer.components.debuffable:GetDebuff("taunt_pegleg")
			buff:Init({damage_multi = 1.10,buff_fx = fx,duration = 10})
			
			local battlecryfx = doer:SpawnChild("icey_battlecry_fxs")	
			battlecryfx:DoTaskInTime(2+math.random(),battlecryfx.RemoveBattleCryFX)		
		end 
	end,nil,10)
	
	inst.components.weapon:SetOnAttack(onattack)
	
end

local DATA = {
	prefabname = "useless_pegleg",
	assets = assets,
	tags = {"pegleg"},
	bank = "peg_leg",
	build = "peg_leg",
	anim = "idle",
	swapanims = {"swap_peg_leg","swap_object"},
	damage = 34,
	ranges = 0.2,
	maxuse = 45,
	clientfn = clientfn,
	serverfn = serverfn,
}

--[[return IceyUtil.CreateNormalWeapon("useless_pegleg",assets,{"pegleg"},
	"peg_leg",
	"peg_leg",
	"idle",
	{"swap_peg_leg","swap_object"},
	28,0.2,75,clientfn,serverfn
)--]]
return IceyUtil.CreateNormalWeapon(DATA)