local IceyUtil = require("icey_util")

local assets =
{
    Asset("ANIM", "anim/swap_spider_higher_spear.zip"),
	Asset("IMAGE","images/inventoryimages/spider_higher_spear.tex"),
	Asset("ATLAS","images/inventoryimages/spider_higher_spear.xml"),
	
	Asset("ANIM", "anim/spider_higher_1.zip"),
	Asset("ANIM", "anim/spider_queen.zip"),
    Asset("ANIM", "anim/spider_queen_2.zip"),
}

local PAD_DURATION = .1
local FLASH_TIME = .3

local function canattack(target,inst) ------------���ر��գ��ж�Ŀ���Ƿ���Ŀ��Ա����������Ա��˺�
	return IceyUtil.CanAttack(target,inst)
end  

local function ReticuleTargetFnPoint()
    local player = ThePlayer
    local ground = TheWorld.Map
    local pos = Vector3()
    --Cast range is 8, leave room for error
    --4 is the aoe range
    for r = 7, 0, -.25 do
        pos.x, pos.y, pos.z = player.entity:LocalToWorldSpace(r, 0, 0)
        if ground:IsPassableAtPoint(pos:Get()) and not ground:IsGroundTargetBlocked(pos) then
            return pos
        end
    end
    return pos
end

local function OnLeapFn(doer,startpos,targetpos)
	local crackle = SpawnPrefab("hammer_mjolnir_crackle")
	local cracklebase = SpawnPrefab("hammer_mjolnir_cracklebase")
	local cracklehit = SpawnPrefab("hammer_mjolnir_cracklehit")
	local cracklehitfx = SpawnPrefab("cracklehitfx")
	local weapon = doer.components.combat:GetWeapon()
	
	crackle.Transform:SetPosition(targetpos.x,targetpos.y,targetpos.z)
	cracklebase.Transform:SetPosition(targetpos.x,targetpos.y,targetpos.z)
	cracklehit.Transform:SetPosition(targetpos.x,targetpos.y,targetpos.z)
	cracklehitfx.Transform:SetPosition(targetpos.x,targetpos.y,targetpos.z)
		
	crackle.AnimState:SetMultColour(87/255,12/255,12/255,0.9)
	cracklebase.AnimState:SetMultColour(153/255,4/255,4/255,1)
	cracklehit.AnimState:SetMultColour(35/255,4/255,4/255,1)
	cracklehitfx.AnimState:SetMultColour(35/255,4/255,4/255,1)
	
	local dmg = 75
	local radius = 5

		
	local ents  = TheSim:FindEntities(targetpos.x,targetpos.y,targetpos.z,radius, {"_combat"},TUNING.ICEY_NO_TAGS)
	for k,v in pairs(ents) do
		local new_dmg = dmg
		if canattack(v,doer) then
			v.components.combat:GetAttacked(doer, new_dmg) 
		end
	end
			
	doer.SoundEmitter:PlaySound("dontstarve/common/destroy_smoke")
	doer.SoundEmitter:PlaySound("dontstarve/creatures/spiderwarrior/Attack")
	local fx = SpawnAt("spider_higher_spear_scarefx",doer:GetPosition())
	fx.Transform:SetRotation(doer:GetRotation())
	fx.components.epicscare:Scare(5)
	
end 

local function OnLeap(inst)
	SpawnPrefab("forginghammer_crackle_fx"):SetTarget(inst)
	inst.components.rechargeable:StartRecharge()
end

local function oncastfn(inst, doer,pos)
	if IceyUtil.DefaultCostFn(doer,{stamina = 40,focus = 20}) then
		inst.components.rechargeable:StartRecharge()
		doer:PushEvent("combat_leap", {targetpos = pos, weapon = inst})
	end 
end

local function onequip(inst, owner)
    owner.AnimState:OverrideSymbol("swap_object", "swap_spider_higher_spear", "swap_spider_higher_spear")
    owner.AnimState:Show("ARM_carry")
    owner.AnimState:Hide("ARM_normal")
end

local function onunequip(inst, owner)
    owner.AnimState:Hide("ARM_carry")
    owner.AnimState:Show("ARM_normal")
end

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()

    MakeInventoryPhysics(inst)

    inst.AnimState:SetBank("swap_spider_higher_spear")
    inst.AnimState:SetBuild("swap_spider_higher_spear")
    inst.AnimState:PlayAnimation("idle")

    inst:AddTag("hop_attack")
    inst:AddTag("pointy")
	inst:AddTag("aoeweapon_leap")
	inst:AddTag("rechargeable")
	
	inst:AddComponent("aoetargeting")
	inst.components.aoetargeting:SetTargetFX("weaponsparks")
	inst.components.aoetargeting.reticule.reticuleprefab = "reticuleaoe"
	inst.components.aoetargeting.reticule.pingprefab = "reticuleaoeping"
	inst.components.aoetargeting.reticule.targetfn = ReticuleTargetFnPoint
	inst.components.aoetargeting.reticule.validcolour = { 1, .75, 0, 1 }
	inst.components.aoetargeting.reticule.invalidcolour = { .5, 0, 0, 1 }
	inst.components.aoetargeting.reticule.ease = true
	inst.components.aoetargeting.reticule.mouseenabled = true
	inst.components.aoetargeting:SetRange(12)

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	

    inst:AddComponent("weapon")
    inst.components.weapon:SetDamage(45)

    inst:AddComponent("inspectable")

    inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "spider_higher_spear"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/spider_higher_spear.xml"

    inst:AddComponent("equippable")
    inst.components.equippable:SetOnEquip(onequip)
    inst.components.equippable:SetOnUnequip(onunequip)
	
	inst:AddComponent("aoespell")
	if TheNet:GetServerGameMode() == "lavaarena" then 
		inst.components.aoespell:SetAOESpell(oncastfn)
	else  
		inst.components.aoespell:SetOnCastFn(oncastfn)
	end 
	
	inst:AddComponent("aoeweapon_leap")
	inst.components.aoeweapon_leap:SetOnLeap(OnLeapFn)
	if TheNet:GetServerGameMode() == "lavaarena"  then 
		inst.components.aoeweapon_leap:SetOnLeapFn(OnLeap)
	end 
	
	inst:AddComponent("rechargeable")
	inst.components.rechargeable:SetRechargeTime(15)

    MakeHauntableLaunch(inst)

    return inst
end

local function UpdatePing(inst, s0, s1, t0, duration, multcolour, addcolour)
    if next(multcolour) == nil then
        multcolour[1], multcolour[2], multcolour[3], multcolour[4] = inst.AnimState:GetMultColour()
    end
    if next(addcolour) == nil then
        addcolour[1], addcolour[2], addcolour[3], addcolour[4] = inst.AnimState:GetAddColour()
    end
    local t = GetTime() - t0
    local k = 1 - math.max(0, t - PAD_DURATION) / duration
    k = 1 - k * k
    local s = Lerp(s0, s1, k)
    local c = Lerp(1, 0, k)
    inst.Transform:SetScale(s, s, s)
    inst.AnimState:SetMultColour(c * multcolour[1], c * multcolour[2], c * multcolour[3], c * multcolour[4])

    k = math.min(FLASH_TIME, t) / FLASH_TIME
    c = math.max(0, 1 - k * k)
    inst.AnimState:SetAddColour(c * addcolour[1], c * addcolour[2], c * addcolour[3], c * addcolour[4])
end

local function FadeOut(inst,startscale,adds)
	if inst.fadetask then 
		inst.fadetask:Cancel()
		inst.fadetask = nil 
	end
	startscale = startscale or 3
	adds = adds or 1 
	inst.fadetask = inst:DoPeriodicTask(0, UpdatePing, nil, startscale, startscale + adds, GetTime(), 0.5, {}, {})
	inst:DoTaskInTime(0.5,inst.Hide) 
end 

local function FxFn()
	local inst = CreateEntity()
	
	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()
	
	inst.Transform:SetFourFaced()
	
	inst.AnimState:SetBloomEffectHandle("shaders/anim.ksh")
	
    inst.AnimState:SetBank("spider_queen")
    inst.AnimState:SetBuild("spider_higher_1")
    inst.AnimState:PlayAnimation("taunt")
	
	inst.Transform:SetScale(1.5,1.5,1.5)
	
	inst:AddTag("FX")
	
    inst.entity:SetPristine()
	
    if not TheWorld.ismastersim then
        return inst
    end

    inst.persists = false
	
	inst:AddComponent("epicscare")
    inst.components.epicscare:SetRange(10)
	
	inst:DoTaskInTime(0.1,function()
		inst.SoundEmitter:PlaySoundWithParams("dontstarve/creatures/spiderqueen/scream", {intensity=10})
	end) 
	
	inst:DoTaskInTime(0,function()
        FadeOut(inst,1.5,0.2)
    end)  
	
	return inst
end

return Prefab("spider_higher_spear", fn, assets),
Prefab("spider_higher_spear_scarefx", FxFn, assets)
