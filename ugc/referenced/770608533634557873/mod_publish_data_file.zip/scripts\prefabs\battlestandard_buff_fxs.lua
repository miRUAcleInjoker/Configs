local assets = {
    Asset("ANIM", "anim/lavaarena_battlestandard.zip"),
}
local function fn()
	local inst = CreateEntity()
	
    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()

    inst.AnimState:SetBank("lavaarena_battlestandard")
    inst.AnimState:SetBuild("lavaarena_battlestandard")
	inst.AnimState:SetOrientation(ANIM_ORIENTATION.OnGround)
    inst.AnimState:SetLayer(LAYER_BACKGROUND)
    inst.AnimState:SetSortOrder(3)
	
	inst:AddTag("NOCLICK")
		
	inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.persists = false 
	
	--heal_fx defend_fx attack_fx3
	inst.Play = function(self,anim)
		self.AnimState:PlayAnimation(anim,true)
	end 
	
	return inst
end

return Prefab("battlestandard_buff_fxs", fn,assets)
