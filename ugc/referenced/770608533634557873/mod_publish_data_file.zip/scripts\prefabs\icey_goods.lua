local assets = 
{
	spider_higher_good = {
		Asset( "ANIM", "anim/icey_goods.zip" ),
		Asset( "ATLAS", "images/inventoryimages/spider_higher_good.xml" ),
	},
	sky_walker_good = {
		Asset( "ANIM", "anim/icey_goods.zip" ),
		Asset( "ATLAS", "images/inventoryimages/sky_walker_good.xml" ),
	},
}

local function fn_common(name,Description,scale)
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()

    MakeInventoryPhysics(inst)
	
	inst:AddTag("CANT_RESOLVE")
	
    inst.AnimState:SetBank("icey_goods")
    inst.AnimState:SetBuild("icey_goods")
    inst.AnimState:PlayAnimation(name)
	inst.Transform:SetScale(scale,scale,scale)

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription(Description)

    inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.atlasname = "images/inventoryimages/"..name..".xml"
	inst.components.inventoryitem.imagename = name
	

    return inst
end

local packs = {}
local lists= 
{
	{name = "spider_higher_good",Description = "沾满了无辜者的血迹",scale = 1},
	--{name = "sky_walker_good",Description = "天罚行者纪念章",scale = 1},
}
for k,v in pairs(lists) do 
	local function fn()
		local inst = fn_common(v.name,v.Description,v.scale)
		return inst
	end
	table.insert(packs,Prefab(v.name,fn, assets[v.name]))
end


return unpack(packs)




