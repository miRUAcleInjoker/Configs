local IceyUtil = require("icey_util")

local colourtoadd = { 0.1, 0.5, 0.1 }
local colouraddspeed = 1 -- #seconds it takes to reach color
local tickrate = 1 -- of a second (for acid)
local tickvalue = -8.75 -- per second (for acid)

local function GetTickDamage(inst,player)
	local mult = player.components.inventory and (1 - player.components.inventory:CaclRadiationAbsorb()) or 1 
	return -(5*math.random() + 2) * mult
end 

local function OnTick(inst, target)
	inst.tickcount = inst.tickcount and inst.tickcount + 1
    if target.components.health ~= nil and
        not target.components.health:IsDead() and
        not target:HasTag("playerghost") then
		local mult = target.acidmult ~= nil and target.acidmult or 1 --incase modded players want resistances.
        --target.components.health:DoDelta(tickvalue*tickrate, true, "scorpeon_dot")
		target.components.health:DoDelta(GetTickDamage(inst,target), true, "metroworld_radiation_debuff", nil, nil, true)
		if target.components.metroworldplayer then 
			target.components.metroworldplayer:SicknessDoDelta(-GetTickDamage(inst,target))
		end
    else
        inst.components.debuff:Stop()
    end
end

local function OnAttached(inst, target)
    inst.entity:SetParent(target.entity)
	inst.tickcount = 0
    inst.task = inst:DoPeriodicTask(tickrate, OnTick, nil, target)
	
--[[	if target.components.colourfader then
		target.components.colourfader:StartFade(colourtoadd, .25)
	end--]]
	
    inst:ListenForEvent("death", function()
        inst.components.debuff:Stop()
    end, target)
end

local function OnDetached(inst, target)
--[[	if not (target.components.debuffable and target.components.debuffable.debuffs["healingcircle_regenbuff"])
	and target.components.colourfader then
		target.components.colourfader:StartFade({0, 0, 0}, .25)
	end--]]
	
	inst:Remove()
end

local function OnTimerDone(inst, data)
    if data.name == "corrosiveover" then
        inst.components.debuff:Stop()
    end
	--print("DEBUG: Scorp Acid Tick Count is "..inst.tickcount and inst.tickcount or "Error")
end

local function OnExtended(inst, target)
    inst.components.timer:StopTimer("corrosiveover")
    inst.components.timer:StartTimer("corrosiveover", inst.duration)
    inst.task:Cancel()
	
--[[	if target and target.components.colourfader then
		target.components.colourfader:StartFade(colourtoadd, .25)
	end--]]
	
    inst.task = inst:DoPeriodicTask(tickrate, OnTick, nil, target)
end

local function DoT_OnInit(inst)
    local parent = inst.entity:GetParent()
    if parent ~= nil then
        parent:PushEvent("startcorrosivedebuff", inst)
    end
end

local function fn(inst)
	local inst = CreateEntity()
	local trans = inst.entity:AddTransform()
	inst.entity:AddNetwork()
	inst.entity:AddAnimState()
	inst.entity:AddSoundEmitter()

	inst:AddTag("CLASSIFIED")

    inst:DoTaskInTime(0, DoT_OnInit)
	
	inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
    inst:AddComponent("debuff")
    inst.components.debuff:SetAttachedFn(OnAttached)
    inst.components.debuff:SetDetachedFn(OnDetached)
    inst.components.debuff:SetExtendedFn(OnExtended)
    --inst.components.debuff.keepondespawn = true
	
	inst.duration = 15
	
	--inst.nameoverride = "peghook_dot" --So we don't have to make the describe strings.

    inst:AddComponent("timer")
	inst:DoTaskInTime(0, function() -- in case we want to change duration
		inst.components.timer:StartTimer("corrosiveover", inst.duration)
	end)
    inst:ListenForEvent("timerdone", OnTimerDone)
	
	return inst
	
end
--ThePlayer.components.debuffable:AddDebuff("metroworld_radiation_debuff", "metroworld_radiation_debuff")
return Prefab("metroworld_radiation_debuff", fn)