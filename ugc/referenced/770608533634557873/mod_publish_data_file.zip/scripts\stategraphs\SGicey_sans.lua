require("stategraphs/commonstates")

local function DoFoleySounds(inst)

	for k,v in pairs(inst.components.inventory.equipslots) do
		if v.components.inventoryitem and v.components.inventoryitem.foleysound then
			inst.SoundEmitter:PlaySound(v.components.inventoryitem.foleysound)
		end
	end

end

local function canattack(v,inst) ------------多重保险：判定目标是否真的可以被攻击，可以被伤害
	return v and v:IsValid()  and v ~= inst and  
	v.components and v.components.combat and v.components.health and not v.components.health:IsDead() 
end 

local function fuck_you_stop(inst)
	inst.components.locomotor:Stop()
	inst.Physics:Stop()
end 

local function ok_you_are_free(inst)
	if not inst.components.health:IsDead() then 
		inst.AnimState:PlayAnimation("atk_leap_lag")
	end 
	inst.Physics:Stop() 
	inst.AnimState:SetMultColour(1,1,1,1)
end 

local function superise_motherfucker(inst,eny)
	if eny and eny.components.health  and not eny.components.health:IsDead() then 
		local x,y,z = eny:GetPosition():Get()
		local dmg = 45
		
		local shadow = DebugSpawn("icey_shadow")    ---------------召唤影分身
		local shadowweapon = DebugSpawn("icey_blade") ------为影分身生成虚武器
		local shadowprotect = DebugSpawn("armorruins")---------为影分身生成虚护甲
		
		shadow.Transform:SetPosition(x,y,z)
		shadowweapon.Transform:SetPosition(x,y,z)
		shadowprotect.Transform:SetPosition(x,y,z)
		
		shadowprotect.components.armor:SetAbsorption(1.0) ------影分身是无敌的，所以护甲是100%伤害吸收
		shadowprotect.components.equippable:SetOnEquip(function(inst,owner) end ) ----------护甲的贴图太难看了，这样设计onequip就不会显示护甲贴图了
		
		shadow.components.health:SetAbsorptionAmount(1.0)------影分身本体也是无敌的
		shadow.components.inventory:Equip(shadowweapon)
		shadow.components.inventory:Equip(shadowprotect)
		shadow.components.colouradder:PushColour("leap", 188/255, 12/255, 12/255, 0)
		
		shadow:DoTaskInTime(0,function()
			shadow:ForceFacePoint(eny:GetPosition():Get())
			inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon")
			shadow.AnimState:PlayAnimation("atk_leap")	
			inst.SoundEmitter:PlaySound("dontstarve/common/lava_arena/fireball")
		end)
		shadow:DoTaskInTime(0.4,function()
			if eny and eny:IsValid() and eny:IsNear(shadow,2) and eny.components.combat then 
				eny.components.combat:GetAttacked(inst,dmg)
			end 
			inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon")
			if eny.components.health:IsDead() and inst.components.health then 
				inst.components.health:DoDelta(dmg/5)
			else 
				inst.components.health:DoDelta(dmg/50)
			end
			--inst.SoundEmitter:PlaySound("dontstarve/common/freezecreature")
		end)
		inst:DoTaskInTime(0.7,function()
			if shadowweapon then shadowweapon:Remove() end 
			if shadow then shadow:Remove() end 
			if shadowprotect then shadowprotect:Remove() end 
		end )
	end
end

local function maketrail(inst)
	inst:StartThread(function()		
		for i = 1,5 do 
			if i ~= 1 then 
				local x,y,z = inst:GetPosition():Get()
				local fx = SpawnPrefab("spear_gungnir_lungefx")
				fx.Transform:SetPosition(x,y,z)
				fx.Transform:SetScale(1,i/5,1)
			end 
			Sleep(0.000001)
		end 
	end )
end

local function MakeTrail2(inst, doer, targetpos)
	print("make trail2!")
	inst.SoundEmitter:PlaySound("dontstarve/common/lava_arena/fireball")
	local x,y,z  = doer.Transform:GetWorldPosition()
	local distanceToTargetPos = math.abs(math.sqrt(math.pow(targetpos.x - x, 2) + math.pow(targetpos.z - z, 2)))
	local x2     = targetpos.x - x
	local z2     = targetpos.z - z
	local angle  = math.acos(x2/distanceToTargetPos)
	local sacle = 0.1
	if (x2 < 0 and z2 < 0 and math.deg(angle) < 180 and math.deg(angle) >= 90) or 
	   (x2 >= 0 and z2 < 0 and math.deg(angle) < 90 and math.deg(angle) > 0) then
		angle = -angle
	end
	for i = 0, 10 do
		local lungefx = SpawnPrefab("spear_gungnir_lungefx")
		lungefx.Transform:SetScale(sacle,sacle,sacle)
		sacle = sacle + 0.1
		lungefx.Transform:SetPosition(x + ((i / 10) * distanceToTargetPos) * math.cos(angle), 0, z + ((i / 10) * distanceToTargetPos) * math.sin(angle))
	end
	
end

local function rescue(inst,begin)
	inst:PutBackOnGround()
	if not inst:IsOnValidGround() then 
		if inst.Physics ~= nil then 
			inst.Physics:Teleport(begin:Get())
		end 
		if inst.Transform ~= nil then 
			inst.Transform:SetPosition(begin:Get())
		end
	end 
end

local function icey_missfn(inst,x,y,z)
	inst:AddTag("noharm")
	if inst.components.freezable and inst.components.freezable:IsFrozen() then 
		inst.components.freezable:Unfreeze()
	end 
	fuck_you_stop(inst) -------------------------给我停下来！！！
	local begin = inst:GetPosition()
	local a,b,c = begin:Get()
	local greatmiss = false
	local eny = nil 
	local ents = TheSim:FindEntities(a, b, c, 5, {"_combat"})
	local movingspeed = 40
	local movingtime = 0.2
	local r,g,b,a = 121/255,6/255,6/255,0.3
	if inst.sg:HasStateTag("moving") then 
		movingspeed = 250
		movingtime = 0.2
		r,g,b,a = 188/255,12/255,12/255,0.3
		maketrail(inst)
	end 
		for k,v in pairs(ents) do
			if v:IsValid() and v.components.combat and v.components.combat.target == inst and v.sg and v.sg:HasStateTag("attack") then 
				eny = v
				greatmiss = true----------------------若闪避时有人在攻击我，则触发极限闪避
				break
			end
		end 
	inst.SoundEmitter:PlaySound("dontstarve/common/staff_blink")
	if not (inst.components.rider and inst.components.rider:IsRiding()) then 
		inst.AnimState:PlayAnimation("atk_leap_lag")
	end 
	inst:ForceFacePoint(x,y,z)
	inst.AnimState:SetMultColour(r,g,b,a)
	inst.Physics:SetMotorVelOverride(movingspeed,0,0)
	inst:DoTaskInTime(movingtime,function() 
		inst:RemoveTag("noharm")
		ok_you_are_free(inst)-----------------好了你可以走了
			if eny and greatmiss then 
				inst:StartThread(function()
					for i = 1,2 do 
						superise_motherfucker(inst,eny)---------------------极限闪避程序
						Sleep(0.3)
					end 
				end)
			end
		
		local a1,b1,c1 = inst:GetPosition():Get()
		if not TheWorld.Map:IsAboveGroundAtPoint(a1,b1,c1) then
			rescue(inst,begin)
		end
		
	end )
	
end


local function icey_killfn_old(inst,pos)-------------死亡进击
	local damage = 45
	local my = inst:GetPosition()
	local dx = pos.x - my.x
	local dz = pos.z - my.z
	local maxdist = 6
	local dist = math.sqrt(dx*dx + dz*dz)
	if dist > maxdist then 
		pos = 
		{
			x =	my.x + maxdist*dx/math.sqrt(dx*dx + dz*dz),
			y = 0,
			z = my.z + maxdist*dz/math.sqrt(dx*dx + dz*dz),
		}
	end 
	local num = 5
	local time = 0.3
	
	MakeTrail2(inst, inst, pos)
	inst.Physics:Teleport(pos.x,pos.y,pos.z)
	inst.AnimState:PlayAnimation("atk")
	local ents    = TheSim:FindEntities(pos.x,pos.y,pos.z, 4, {"_combat"},{"monster","tadalin"})
	inst:StartThread(function()		
		for _,v in pairs(ents) do
			if canattack(v,inst) then
				local eny = v:GetPosition()
				inst:Hide()
				inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon")
				local hitfx = SpawnPrefab("blossom_hit_fx")
				local killfx = SpawnPrefab("icey_kill_fx")
				hitfx.AnimState:SetAddColour(36/256, 210/256, 231/256, 0)
				hitfx.Transform:SetPosition(eny.x,eny.y,eny.z)
				killfx.Transform:SetScale(3,3,3)
				killfx.Transform:SetPosition(eny.x,eny.y,eny.z)
				inst:DoTaskInTime(0.1,function()
					if v and v:IsValid() and v.components.combat and  v.components.health and not v.components.health:IsDead() then 
						v.components.combat:GetAttacked(inst, damage)
					end 
				end)
				num = num - 1
				Sleep(time)
				time = time -0.05
			end
			if num <= 1 then
				--MakeTrail2(inst, inst, pos)
				inst.Physics:Teleport(pos.x,pos.y,pos.z)
				inst:Show()
				inst.AnimState:PlayAnimation("atk_leap")
				local ents2 = TheSim:FindEntities(pos.x,pos.y,pos.z, 2, {"_combat"})
				for _,n in pairs(ents2) do
					inst:DoTaskInTime(0.4,function()
					if canattack(n,inst) then
						n.components.combat:GetAttacked(inst, damage * 1.5)
						inst.SoundEmitter:PlaySound("dontstarve/common/destroy_smoke")
					end 
					end)
				end
				break
			end
			inst:Show()
			print("Sans show !")
			if not inst.components.health:IsDead() then 
				print("Sans goto ds attack sg!")
				inst.sg:GoToState("attack")
			end 
		end
	end)
end 

local function icey_killfn(inst,pos) 
	local my = inst:GetPosition()
	local ship = SpawnPrefab("hyperion_circle")
	ship.Transform:SetPosition(my:Get())
	ship.components.ly_projectile:Throw(inst,pos,false)
	ship.owner = inst
end

local function Ball_OnHit(inst, attacker, target)
	local pos = inst:GetPosition()
    local x, y, z = pos:Get()
	local ents = TheSim:FindEntities(x,y,z,4,{},{"INLIMBO","NOCLICK","CANT_RESOLVE","tadalin","monster"})
	local fx1 = SpawnPrefab("sleepbomb_burst")
	local fx2 = SpawnPrefab("statue_transition_2")
	for k,v in pairs(ents) do
		if canattack(v) then 
			v.components.combat:GetAttacked(attacker,math.random(250,400))
			if v.components.health:IsDead() then 
			end
		end 
		if v and v.components and v.components.edible then
			v:Remove()
		end
		if v and v.components and v.components.inventoryitem then
			v:Remove()
		end
		if v and v.components and v.components.workable then 
			v.components.workable:Destroy(attacker)
		end
	end
    fx1.Transform:SetPosition(x, y, z)
	fx2.Transform:SetPosition(x, y, z)
	fx2.Transform:SetScale(2.5,2.5,2.5)
    --SpawnPrefab("sleepcloud").Transform:SetPosition(x, y, z)
	inst:Remove()
end

local function ThrowBall(inst)
	local x,y,z = inst:GetPosition():Get()
	local target = inst.sg.statemem.target or (inst.components.combat and inst.components.combat.target) or inst
	local ball = SpawnPrefab("icey_ball")
	ball.fire = SpawnPrefab("torchfire_shadow")
	ball.fire.entity:SetParent(ball.entity)     
	ball.fire.Transform:SetPosition(0,0,0)  
	
	ball.components.complexprojectile:SetOnHit(Ball_OnHit)
	ball.Transform:SetPosition(x,y,z)
	ball.components.complexprojectile:Launch(target:GetPosition(), inst)
end 

local actionhandlers = 
{
	ActionHandler(ACTIONS.EAT, "eat"),
	ActionHandler(ACTIONS.FUSE, "fuse"),
}

   
local events=
{
	CommonHandlers.OnLocomote(true, false),

    EventHandler("attacked", function(inst, data)
		--inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/idle")
		if not inst.sg:HasStateTag("busy") and not inst.sg:HasStateTag("icey_skill") and data.damage and data.damage >= 34 then 
			inst.sg:GoToState("hit")
		end 
	end),

    EventHandler("doattack", function(inst,data)
        if not inst.components.health:IsDead() and data.target:IsValid() then
			inst.sg.statemem.target = data.target
			if inst._icey_ds   and  inst.components.health:GetPercent() <= 0.75 then 
				inst.sg:GoToState("icey_ds",{target = data.target})
				inst._icey_ds = false
				inst.components.timer:StartTimer("icey_ds",11)
			--[[elseif inst._icey_h and inst.components.health and  inst.components.health:GetPercent() <= 0.5 then 
				inst.sg:GoToState("icey_h",{target = data.target})
				inst._icey_h = false
				inst.components.timer:StartTimer("icey_h",60)--]]
			elseif inst._icey_lance and  inst.components.health:GetPercent() <= 0.5 then 
				inst.sg:GoToState("icey_lance",{target = data.target})
				inst._icey_lance = false
				inst.components.timer:StartTimer("icey_lance",35)
			elseif inst._icey_boom and  inst.components.health:GetPercent() <= 0.3 then 
				inst.sg:GoToState("icey_boom",{target = data.target})
				inst._icey_boom = false
				inst.components.timer:StartTimer("icey_boom",10)
			else
				inst.sg:GoToState("attack")
			end
			inst:CheckRange()
        end
    end),
    
    EventHandler("death", function(inst)
		print("Preper to go to death sg")
        inst.sg:GoToState("death")
    end),
}

local states= 
{

	State{
        name = "fuse",
        tags = {"busy","fuse"},
        
        onenter = function(inst)
            inst.components.locomotor:Stop()
			inst.AnimState:PlayAnimation("give")
            inst.AnimState:PushAnimation("give_pst", false)
			
			inst.sg:SetTimeout(20*FRAMES)
        end,
		timeline=
        {
            TimeEvent(12*FRAMES, function(inst) 
                --inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/grunt")
				inst:PerformBufferedAction()
            end),
        }
    },
	
	State{
        name = "infected",
        tags = {"busy"},
        
        onenter = function(inst)
            inst.components.locomotor:Stop()
			print("In infected SG")
			inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/grunt")
            --inst.AnimState:Hide("swap_arm_carry")
            inst.AnimState:PlayAnimation("transform_merm")
			--inst.AnimState:PushAnimation("idle_merm")
            inst.components.lootdropper:DropLoot(Vector3(inst.Transform:GetWorldPosition()))  
			
        end,
		timeline=
        {
            TimeEvent(12*FRAMES, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/grunt")
            end),
        },        
        
        events=
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end),
        },
        
        onexit= function(inst)
            
        end,
    },

	

    State{
        name = "death",
        tags = {"busy","death"},
        
        onenter = function(inst)
            inst.components.locomotor:Stop()
			print("In Death SG")
			inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/grunt")
            inst.AnimState:Hide("swap_arm_carry")
			if math.random(1,100) >= 50 then 
				inst.AnimState:PlayAnimation("transform_merm")
			else
				inst.AnimState:PlayAnimation("death")
			end 
            inst.components.lootdropper:DropLoot(Vector3(inst.Transform:GetWorldPosition()))
			inst.components.lootdropper:SetLoot({})
			
        end,  
		timeline=
        {
            TimeEvent(12*FRAMES, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/grunt")
            end),
			TimeEvent(40*FRAMES, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/grunt")
            end),
        },    
		events=
        {
            EventHandler("animover", function(inst)  end),
        },
        
        onexit= function(inst)
            
        end,         
    },

    State{
        name = "idle",
        tags = {"idle", "canrotate"},
        onenter = function(inst, pushanim)     
            inst.components.locomotor:Stop()
			inst.AnimState:PlayAnimation("idle_loop", true)
            inst.sg:SetTimeout(1)
        end,
    },

    State{
        name = "eat",
        tags ={"busy"},
        onenter = function(inst)
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("quick_eat")
        end,

        timeline=
        {
            TimeEvent(12*FRAMES, function(inst) 
                inst:PerformBufferedAction() 
                inst.sg:RemoveStateTag("busy")
            end),
        },        
        
        events=
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end),
        },
        
        onexit= function(inst)
            inst.SoundEmitter:KillSound("eating")    
        end,
    },    
	
------------------------------------------------------------------------------------------------------------------------------------------------------
	State{
        name = "icey_miss",
        tags ={"busy","icey_skill"},
        onenter = function(inst,data)
			inst.components.locomotor:Stop()
			local attacker = data.attacker
			local x1,y1,z1 = inst:GetPosition():Get()
			local x2,y2,z2 = attacker:GetPosition():Get()
			local delx,dely,delz = x2 - x1,y2 - y1,z2 - z1
			local finx,finy,finz = x1 - delx - math.random(),y1 - dely,z1 - delz - math.random()
            icey_missfn(inst,finx,finy,finz)
        end,
      
        
        events=
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end),
        },
        
        onexit= function(inst)
            --inst.SoundEmitter:KillSound("eating")    
        end,
    },    
	
	State{
        name = "icey_ds",
        tags ={"busy","icey_skill","attack"},
        onenter = function(inst,data)
			inst.components.locomotor:Stop()
            icey_killfn_old(inst,data.target:GetPosition())
        end,
		
		events=
        {
           EventHandler("animqueueover", function(inst)
                inst.sg:GoToState("idle")
            end),
        },

    }, 
	
	State{
        name = "icey_h",
        tags ={"busy","icey_skill","attack"},
        onenter = function(inst,data)
			inst.components.locomotor:Stop()
            icey_killfn(inst,data.target:GetPosition())
			inst.sg:SetTimeout(1)
        end,
		           
    }, 
	
	State{
        name = "icey_lance",
        tags ={"busy","icey_skill","attack"},
        onenter = function(inst,data)
			inst.components.locomotor:Stop()
			local x,y,z = data.target:GetPosition():Get()
			inst.AnimState:PlayAnimation("superjump_pre")
			inst.AnimState:PushAnimation("superjump_lag")
			inst.AnimState:PushAnimation("superjump")
			inst.sg:SetTimeout(3)
			inst:DoTaskInTime(3,function()
				--inst.Transform:SetPosition(x,y,z)
				inst.sg:GoToState("icey_lance_pst",{target = data.target})
			end)
        end,

        timeline=
        {
		
			TimeEvent(0.7, function(inst) 
				inst:Hide()
				inst.DynamicShadow:SetSize(0,0)
			end),
        },   
		

    }, 
	
	State{
        name = "icey_lance_pst",
        tags ={"busy","icey_skill","attack"},
        onenter = function(inst,data)
			inst.components.locomotor:Stop()
			local x,y,z = data.target:GetPosition():Get()
			inst.Transform:SetPosition(x,y,z)
			inst:Show()
			inst.DynamicShadow:SetSize(1.3,0.6)
			inst.AnimState:PlayAnimation("superjump_land")
			inst:DoTaskInTime(0.3,function()
				if  inst.components.health:IsDead() then 
					return
				end
				local pos = inst:GetPosition()
				local ents = TheSim:FindEntities(pos.x,pos.y,pos.z,5, {"_combat"},{"tadalin"})
				local fx1 = SpawnPrefab("groundpoundring_fx")
				local fx2 = SpawnPrefab("groundpound_fx")
				fx1.Transform:SetPosition(pos.x,pos.y,pos.z)
				fx2.Transform:SetPosition(pos.x,pos.y,pos.z)
				ShakeAllCameras(CAMERASHAKE.VERTICAL, .7, .025, 1.25, inst, 40)
				for k,v in pairs(ents) do 
					if v ~= inst  then 
						v.components.combat:GetAttacked(inst,math.random(80,160))
					end
				end
			end)
			inst.sg:SetTimeout(1)
        end,
 
		
		events=
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end),
        },    
        
    }, 
	
	State{
        name = "icey_boom",
        tags ={"busy","icey_skill","attack"},
        onenter = function(inst,data)
			inst.components.locomotor:Stop()
			local my = inst:GetPosition()
			local eny = data.target:GetPosition()
			local delx,dely,delz = eny.x - my.x,eny.y - my.y,eny.z - my.z
            icey_missfn(inst,eny.x + delx,eny.y + dely,eny.z + delz)
        end,

        timeline=
        {
		
			TimeEvent(0.1, function(inst) 
                ThrowBall(inst)
            end),
			
      
        },        
        
        events=
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end),
        },
        
        onexit= function(inst)
            --inst.SoundEmitter:KillSound("eating")    
        end,
    },
	
------------------------------------------------------------------------------------------------------------------------------------------------------
    State{
        name = "attack",
        tags = {"attack", "notalking", "abouttoattack", "busy"},
        
        onenter = function(inst)
			inst.sg.statemem.target = inst.components.combat.target
            inst.components.combat:StartAttack()
			inst.components.locomotor:Stop()
                inst.AnimState:PlayAnimation("atk_pre")
                inst.AnimState:PushAnimation("atk", false)
               
                if inst.sg.statemem.projectilesound == nil then
                    inst.SoundEmitter:PlaySound(
                        "dontstarve/wilson/attack_weapon",
                        nil, nil, true
                    )
                end
                --cooldown = math.max(cooldown, 13 * FRAMES)
			
        end,
		
        timeline=
        {	
            TimeEvent(8*FRAMES, function(inst) 
				inst.components.combat:DoAttack(inst.sg.statemem.target) 
				inst.sg:RemoveStateTag("abouttoattack") 
			end),
            TimeEvent(9*FRAMES, function(inst) 
				inst.sg:RemoveStateTag("busy")
				inst.sg:RemoveStateTag("attack")
			end),				
        },
        
        events=
        {
           EventHandler("animqueueover", function(inst)
                inst.sg:GoToState("idle")
            end),
        },
    },       
   
    State{
        name = "run_start",
        tags = {"moving", "running", "canrotate"},
        
        onenter = function(inst)
			inst.components.locomotor:RunForward()
            inst.AnimState:PlayAnimation("run_bronya_pre")
            inst.sg.mem.foosteps = 0
        end,

        onupdate = function(inst)
            inst.components.locomotor:RunForward()
        end,

        events=
        {   
            EventHandler("animover", function(inst) inst.sg:GoToState("run") end ),        
        },
        
        timeline=
        {
        
            TimeEvent(4*FRAMES, function(inst)
                PlayFootstep(inst)
                DoFoleySounds(inst)
            end),
        },        
        
    },

    State{
        
        name = "run",
        tags = {"moving", "running", "canrotate"},
        
        onenter = function(inst) 
            inst.components.locomotor:RunForward()
            inst.AnimState:PlayAnimation("run_bronya_loop",true)
        end,
        
        onupdate = function(inst)
            inst.components.locomotor:RunForward()
        end,

        timeline=
        {
            TimeEvent(7*FRAMES, function(inst)
				inst.sg.mem.foosteps = inst.sg.mem.foosteps + 1
                PlayFootstep(inst, inst.sg.mem.foosteps < 5 and 1 or .6)
                DoFoleySounds(inst)
            end),
            TimeEvent(15*FRAMES, function(inst)
				inst.sg.mem.foosteps = inst.sg.mem.foosteps + 1
                PlayFootstep(inst, inst.sg.mem.foosteps < 5 and 1 or .6)
                DoFoleySounds(inst)
            end),
        },
        
        events=
        {   
            EventHandler("animover", function(inst) inst.sg:GoToState("run") end ),        
        },
        
        
    },
    
    State{
        name = "run_stop",
        tags = {"canrotate", "idle"},
        
        onenter = function(inst) 
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("run_bronya_pst")
        end,
        
        events=
        {   
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end ),        
        },       
    },    
	
	State{
        name = "hit",
        tags = { "busy", "pausepredict","hit"},

        onenter = function(inst, frozen)
            inst.components.locomotor:Stop()
            inst:ClearBufferedAction()

            inst.AnimState:PlayAnimation("hit")

            if frozen == "noimpactsound" then
                frozen = nil
            else
                inst.SoundEmitter:PlaySound("dontstarve/wilson/hit")
            end
			
            local stun_frames = frozen and 10 or 6
            inst.sg:SetTimeout(stun_frames * FRAMES)
        end,

        ontimeout = function(inst)
			if inst.components.health:IsDead() then 
				inst.sg:GoToState("death")
			else
				inst.sg:GoToState("idle")
			end 
        end,
    },
}

    
return StateGraph("SGicey_sans", states, events, "idle", actionhandlers)

