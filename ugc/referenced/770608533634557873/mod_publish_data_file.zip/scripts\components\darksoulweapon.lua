local function onlevel(self, level)
    self.inst.replica.darksoulweapon:SetLevel(level)
end

local function onmaxlevel(self, maxlevel)
    self.inst.replica.darksoulweapon:SetMaxLevel(maxlevel)
end

local function onproperty(self, property)
    self.inst.replica.darksoulweapon:SetProperty(property)
end

local function onattack_fire(inst,data)
	local target = data.target
	local attacker = data.attacker 
	local level = inst.components.darksoulweapon.level
	if target and target:IsValid() and target.components.burnable then 
		target.components.burnable:Ignite(true)
		if target.components.combat then 
			target.components.combat:GetAttacked(attacker,level*3)
		end
	end
end 

local Properties = {
	fire = {onadd = nil,onremove = nil,onattack = onattack_fire},
} 

local function darksoulweapon_onattack(inst,data)
	local self = inst.components.darksoulweapon
	if self.property and Properties[self.property] and Properties[self.property].onattack then 
		Properties[self.property].onattack(inst,data)
	end
end 

local DarkSoulWeapon = Class(function(self, inst)
	self.inst = inst
	self.level = 0
	self.maxlevel = 10 
	self.property = nil 
	self.canproperty = true 
	
	inst:ListenForEvent("darksoulweapon_onattack",darksoulweapon_onattack)
end,
nil,
{
	level = onlevel,
	maxlevel = onmaxlevel,
	property = onproperty,
})

function DarkSoulWeapon:SetLevel(level)
	local old_level = self.level
	self.level = level
	self.level = math.min(self.level,self.maxlevel)
	self.level = math.max(self.level,0)
	self.inst:PushEvent("darksoulweapon_levelchange",{oldlevel = old_level,level = self.level})
end 

function DarkSoulWeapon:SetCanProperty(enable)
	self.canproperty = enable
end 

function DarkSoulWeapon:SetMaxLevel(max)
	self.maxlevel = max 
end 

function DarkSoulWeapon:LevelDoDelta(val)
	self:SetLevel(self.level + val)
end

function DarkSoulWeapon:HasValidProperty()
	return self.property and Properties[self.property]
end

function DarkSoulWeapon:SetProperty(property)
	if self:HasValidProperty() then 
		print("[DarkSoulWeapon]:ERROR,property already exist!")
		return 
	end 
	if Properties[property] and self.canproperty then 
		local old_property = self.property
		self.property = property
		if Properties[property].onadd then 
			Properties[property].onadd(self.inst)
		end 
		self.inst:PushEvent("darksoulweapon_propertychange",{oldproperty = old_property,property = self.property})
	else
		print("[DarkSoulWeapon]:ERROR,property not found!")
	end
end

function DarkSoulWeapon:RemoveProperty()
	if self.property and Properties[self.property] and Properties[self.property].onremove then 
		Properties[self.property].onremove(self.inst)
	end
	self.property = nil 
end

function DarkSoulWeapon:OnSave()
	return {
		maxlevel = self.maxlevel,
		level = self.level,
		property = self.property,
	}
end

function DarkSoulWeapon:OnLoad(data)
	if data then 
		self:SetMaxLevel(data.maxlevel)
		self:SetLevel(data.level)
		self:SetProperty(data.property)
	end
end

return DarkSoulWeapon