local assets_blue =
{
    Asset("ANIM", "anim/icey_drone.zip")
}



local function findowner(inst)
	if inst.ownerid ~= nil then 
		local owner = FindEntity(inst, 50, function(guy) return guy:HasTag("player") and guy.userid == inst.ownerid end )
		inst.components.follower:SetLeader(owner)
		inst.findownerfn:Cancel()
	end
end 

local function onsave(inst,data)
	data.ownerid = inst.ownerid or nil 
end 

local function onload(inst,data)
	if data ~= nil then 
		if data.ownerid ~= nil then 
			inst.ownerid = data.ownerid
		end
	end
end 
local function common_blue()
    local inst = CreateEntity()
    
    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
	inst.entity:AddLight()
    inst.entity:AddDynamicShadow()
    inst.entity:AddNetwork()
	
	inst.DynamicShadow:SetSize(1.5, 1)

	--MakePoisonableCharacter(inst)
	MakeCharacterPhysics(inst, 1, .3)

	inst.Transform:SetTwoFaced()
	inst.Transform: SetScale(2,2,2)
	
	inst.AnimState:SetBank("icey_drone")
	inst.AnimState:SetBuild("icey_drone")
	inst.AnimState:PlayAnimation("idle")
	
	inst.Light:SetIntensity(0.7)
	inst.Light:SetRadius(2)
	inst.Light:SetFalloff(0.5)
	inst.Light:SetColour(44/255,143/255,255/255)
	inst.Light:Enable(true)
	
	inst.entity:SetPristine()
	
	inst.ownerid = nil

    if not TheWorld.ismastersim then
        return inst
    end

	inst:AddComponent("inspectable")
	
	inst:AddComponent("locomotor")
    inst.components.locomotor:SetSlowMultiplier(1)
    inst.components.locomotor:SetTriggersCreep(false)
    inst.components.locomotor.pathcaps = { ignorecreep = true }
	inst.components.locomotor.walkspeed = 2
    inst.components.locomotor.runspeed = 3
	
	inst:AddComponent("follower")

	inst:AddComponent("knownlocations")

	inst:SetStateGraph("SGicey_drone")
    local brain = require("brains/icey_drone_brain")
    inst:SetBrain(brain)

	inst.findownerfn = inst:DoPeriodicTask(1,function()findowner(inst)end)

	inst.OnSave = onsave
	inst.OnLoad = onload

	return inst
end

return Prefab("icey_drone", common_blue, assets_blue)

--local chest = c_spawn("treasurechest")   c_spawn("icey_drone").components.follower:SetLeader(chest)