require("stategraphs/commonstates")


local function startaura(inst)
    inst.SoundEmitter:PlaySound("dontstarve/ghost/ghost_attack_LP", "angry")
end

local function stopaura(inst)
    inst.SoundEmitter:KillSound("angry")
end


local events=
{
    CommonHandlers.OnLocomote(true, true),
    --EventHandler("startaura",  function(inst) startaura(inst) end),
    --EventHandler("stopaura", function(inst) stopaura(inst) end),
	EventHandler("doattack", function(inst,data)
		local target = data.target
		if not inst.components.health:IsDead() then 
			if inst.SummonSkill then 
				inst.sg:GoToState("summon",target)
			elseif inst.SummonMeteor then 
				inst.sg:GoToState("summon_meteor",target)
			else
				inst.sg:GoToState("attack",target)
			end 
		end
	
	end),
	EventHandler("summon_spikes",function(inst,data)
		local target = data.target
		if not inst.components.health:IsDead() then 
			if inst.SummonSpikes  then
				inst.sg:GoToState("summon_spikes",target)
			end 
		end
	end),
    EventHandler("attacked", function(inst) 
		if not inst.components.health:IsDead() and not inst.sg:HasStateTag("busy") then 
			inst.sg:GoToState("hit") 
		end 
	end),
    EventHandler("death", function(inst) inst.sg:GoToState("death") end),
	
	CommonHandlers.OnLocomote(false,true),
}

local function getidleanim(inst)
    return "idle"
end

local function CircleNightAttack(inst,target,rad)
	rad = rad or 3
	local x,y,z = target:GetPosition():Get()
	--inst.SoundEmitter:PlaySound(math.random() <= 0.5 and "dontstarve/sanity/knight/attack_1" or "dontstarve/sanity/rook/taunt")
	--inst.CircleNightAttackTask = inst:StartThread(function()
		for i=0,360,60 do 
			local nightmare = SpawnPrefab(math.random() <= 0.25 and "nightmarebeak" or "crawlingnightmare")
			nightmare.Transform:SetPosition(x+rad*math.cos(i),y,z+rad*math.sin(i))
			nightmare.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/shield")
			nightmare:DoTaskInTime(0.2,function()
				nightmare.components.combat:SetTarget(target)
				nightmare.sg:GoToState("attack",target)
				nightmare:DoTaskInTime(1,function()
					--nightmare.sg.mem.soundcache = nil 
					nightmare.sg:GoToState("disappear")
					nightmare:ListenForEvent("animover", nightmare.Remove)
					nightmare:ListenForEvent("entitysleep", nightmare.Remove)
				end)
			end)
			--Sleep(0.2)
		end
--[[		if inst.CircleNightAttackTask then 
			inst.CircleNightAttackTask:SetList(nil)
			inst.CircleNightAttackTask = nil 
		end
	end)--]]
end 

local function SummonNightmare(inst,target)
	CircleNightAttack(inst,target)
	inst:PushEvent("use_herald_skill",{name = "SummonSkill",cd = 15})
end 

local NOTAGS_FIRE = {"laser", "DECOR", "INLIMBO" ,"tadalin","player"}
local NOTAGS_ATTACK = {"laser", "DECOR", "INLIMBO" ,"tadalin","structure","monster"}

local function setfires(x,y,z, rad)
    for i, v in ipairs(TheSim:FindEntities(x, 0, z, rad, nil,NOTAGS_FIRE)) do 
        if v.components.burnable then
            v.components.burnable:Ignite()
        end
    end
end

local function DoDamage(inst, rad)
    local targets = {}
    local x, y, z = inst.Transform:GetWorldPosition()
  
    setfires(x,y,z, rad)
    for i, v in ipairs(TheSim:FindEntities(x, 0, z, rad, nil, NOTAGS_ATTACK)) do  --  { "_combat", "pickable", "campfire", "CHOP_workable", "HAMMER_workable", "MINE_workable", "DIG_workable" }
        if not targets[v] and v:IsValid() and not v:IsInLimbo() and not (v.components.health ~= nil and v.components.health:IsDead()) and not v:HasTag("laser_immune") then
            local vradius = 0
            if v.Physics then
                vradius = v.Physics:GetRadius()
            end

            local range = rad + vradius
            if v:GetDistanceSqToPoint(Vector3(x, y, z)) < range * range then
                local isworkable = false
                if v.components.workable ~= nil then
                    local work_action = v.components.workable:GetWorkAction()
                    --V2C: nil action for campfires
                    isworkable =
                        (   work_action == nil and v:HasTag("campfire")) or
                        
                            (   work_action == ACTIONS.CHOP or
                                work_action == ACTIONS.HAMMER or
                                work_action == ACTIONS.MINE or
                                work_action == ACTIONS.DIG
                            )
                end
                if isworkable then
                    targets[v] = true
                    v:DoTaskInTime(0.6, function() 
                        if v.components.workable then
                            v.components.workable:Destroy(inst) 
                            local vx,vy,vz = v.Transform:GetWorldPosition()
                            v:DoTaskInTime(0.3, function() setfires(vx,vy,vz,1) end)
                        end
                     end)
                    if v:IsValid() and v:HasTag("stump") then
                       -- v:Remove()
                    end
                elseif v.components.pickable ~= nil
                    and v.components.pickable:CanBePicked()
                    and not v:HasTag("intense") then
                    targets[v] = true
                    local num = v.components.pickable.numtoharvest or 1
                    local product = v.components.pickable.product
                    local x1, y1, z1 = v.Transform:GetWorldPosition()
                    v.components.pickable:Pick(inst) -- only calling this to trigger callbacks on the object
                    if product ~= nil and num > 0 then
                        for i = 1, num do
                            local loot = SpawnPrefab(product)
                            loot.Transform:SetPosition(x1, 0, z1)
                            targets[loot] = true
                        end
                    end

                elseif v.components.health then
                    --inst.components.combat:DoAttack(v)
                    if v:IsValid() then
                        if not v.components.health or not v.components.health:IsDead() then
                            if v.components.freezable ~= nil then
                                if v.components.freezable:IsFrozen() then
                                    v.components.freezable:Unfreeze()
                                elseif v.components.freezable.coldness > 0 then
                                    v.components.freezable:AddColdness(-2)
                                end
                            end
                            if v.components.temperature ~= nil then
                                local maxtemp = math.min(v.components.temperature:GetMax(), 10)
                                local curtemp = v.components.temperature:GetCurrent()
                                if maxtemp > curtemp then
                                    v.components.temperature:DoDelta(math.min(10, maxtemp - curtemp))
                                end
                            end
                        end
                    end                   
                end
                if v:IsValid() and v.AnimState then
                    SpawnPrefab("deerclops_laserhit"):SetTarget(v)
                end
            end
        end
    end
end

local function SpawnOneSpike(inst,pos,scale,damage)
	scale = scale or 1
	local x,y,z = pos:Get()
	local spike = SpawnPrefab("ancient_herald_fossilspike")
	spike.Transform:SetPosition(x,y,z)
	spike.Transform:SetScale(scale,scale,scale)
	spike:ForceFacePoint(x,y,z)
	spike.AnimState:SetMultColour(0,0,0,1)
	local ents = TheSim:FindEntities(x, 0, z, 1.3, {"_combat","_health"}, NOTAGS_ATTACK)
	for k,v in pairs(ents) do 
		v:PushEvent("knockback", {knocker = inst, radius = 1})
		if not v.components.health:IsDead() then 
			v.components.combat:GetAttacked(inst,damage)
		end
	end 
end 

local function SpawnLineSpikes(inst,beginpos,endpos,num)
	beginpos = beginpos or inst:GetPosition()
	local deltapos = endpos - beginpos
	local extranum = 2 * math.random() + 3 
	local dx,dy,dz = deltapos:Get()
	inst:StartThread(function()
		for i=0,num+extranum do 
			local pos = beginpos +  Vector3((i/num) * dx,(i/num) * dy,(i/num) * dz)
			SpawnOneSpike(inst,pos,(i/num) + 0.5,10 + (i/num)*30)
			Sleep(0.1)
		end
		--inst.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/fossil_spike")
	end)
end 

local function SpawnRoot(inst,target,num)
	--[[local target = inst.sg.statemem.summontarget
		if not (target and target:IsValid()) then 
		inst.sg.statemem.summontarget = nil 
		return
	end--]]
	for i=1,num do 
		target = target or inst.components.combat.target
		if not (target and target:IsValid()) then 
			return
		end 
		local offset = Vector3( 5 - math.random()*10,0,5 - math.random()*10)
		local pos = inst:GetPosition()
		local root = SpawnPrefab("ancient_herald_root")
		local mx, my, mz = target.Transform:GetWorldPosition()
		local rootpos = Vector3(mx, 0, mz)
		local angle = inst:GetAngleToPoint(rootpos) * DEGREES
		root.Transform:SetPosition((pos + offset):Get())
		root.AnimState:SetMultColour(0,0,0,1)
		root:PushEvent("givetarget",{owner = inst,target = target,targetpos = target:GetPosition(),targetangle = angle})
	end 
end 

local function StopSpawnMeteor(inst)
	if inst.SpawnMeteorTask then 
		inst.SpawnMeteorTask:Cancel()
		inst.SpawnMeteorTask = nil 
	end
end 

local function SpawnMeteor(inst)
	StopSpawnMeteor(inst)
	inst.SpawnMeteorTask = inst:DoPeriodicTask(math.random() + 0.2,function()
		--for i = 1,num do 
			local pos = inst:GetPosition()
			local offset = Vector3(10 - math.random()*20,0,10 - math.random()*20)
			local x,y,z = (pos+offset):Get()
			local meteor = SpawnPrefab("tadalin_meteor")
			meteor.Transform:SetPosition(x,0,z)
			--Sleep(math.random() + 0.3)
		--end 
	end)
	inst:PushEvent("use_herald_skill",{name = "SummonMeteor",cd = 35})
end 


local function CanBecomeTadalin(target)
	print("CanBecomeTadalin?")
	return  target:HasTag("player") and not target:HasTag("tadalin") 
end 

local function PlayerDoAttack(inst,data)
	local weapon = inst.components.combat ~= nil and inst.components.combat:GetWeapon() or nil
	local target = data.target
	if inst.sg:HasStateTag("attack") then 
		return
	end
    local sg =  (weapon == nil and "attack")
             or (weapon:HasTag("blowdart") and "blowdart")
             or (weapon:HasTag("thrown") and "throw")
             or (weapon:HasTag("multithruster") and "multithrust_pre")
             or (weapon:HasTag("helmsplitter") and "helmsplitter_pre")
             or "attack"
	inst:DoTaskInTime(0,function()
		inst.components.combat:SetTarget(target)
	end)
	inst.sg:GoToState(sg)
end 

local function OnBecomeTadalin(inst,target)
	print("OnBecomeTadalin",target)
	target:AddTag("tadalin")
	if target:HasTag("player") then 
		target.sg:GoToState("hit_darkness")
	end 
	if target.components.playercontroller then 
		target.components.playercontroller:Enable(false)
	end
	target.components.talker:Say("为了.....黯影......")
	target.components.combat:SetRetargetFunction(3, inst.components.combat.targetfn)
    target.components.combat:SetKeepTargetFunction(inst.components.combat.keeptargetfn)
	target:SetBrain(require "brains/chaosbrain")
	target:RestartBrain()
	--target:ListenForEvent("doattack",PlayerDoAttack)
end 

local function OnReturnFromTadalin(inst,target)
	print("OnReturnFromTadalin",target)
	target:RemoveTag("tadalin")
	if target.components.playercontroller then 
		target.components.playercontroller:Enable(true)
	end
	target.components.talker:Say("啊？发生了什么？")
	target.components.combat:SetRetargetFunction(0,nil)
    target.components.combat:SetKeepTargetFunction(nil)
	target:SetBrain(nil)
	target:RestartBrain()
	--target:RemoveEventCallback("doattack",PlayerDoAttack)
end 

local function MindControl(inst,target)
	if CanBecomeTadalin(target) then 
		OnBecomeTadalin(inst,target)
		target:DoTaskInTime(30,function()
			OnReturnFromTadalin(inst,target)
		end)
	end
end 



local states=
{
	

    State
    {
        name = "idle",
        tags = {"idle", "canrotate", "canslide"},
        onenter = function(inst)
			inst.Physics:Stop()
            inst.AnimState:PlayAnimation(getidleanim(inst), true)
        end,
    },
	
	
	State
    {
        name = "taunt",
        tags = {"taunt", "canrotate", "canslide","busy"},
        onenter = function(inst)
			inst.Physics:Stop()
            inst.AnimState:PlayAnimation("taunt")
			inst.SoundEmitter:PlaySound("dontstarve/sanity/knight/attack_grunt")
			inst.SoundEmitter:PlaySound("dontstarve/sanity/knight/attack_1")
			SpawnRoot(inst,nil,15)
        end,
		events=
        {
            EventHandler("animover", function(inst, data) inst.sg:GoToState("idle") end)
        },
    },
	
	State
    {
        name = "summon",
        tags = {"summon","busy"},
        onenter = function(inst,target)
			inst.Physics:Stop()
            inst.components.combat:StartAttack()
            inst.AnimState:PlayAnimation("summon")
			inst.sg.statemem.summontarget = target
			inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/ancient_herald/summon")
			inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/ancient_herald/summon_2d")
			inst.SoundEmitter:PlaySound("dontstarve/sanity/bishop/taunt")
			--startaura(inst)
        end,

		
		timeline=
        {
            TimeEvent(20*FRAMES, function(inst) SummonNightmare(inst,inst.sg.statemem.summontarget) end),
        },
		
		events=
        {
            EventHandler("animover", function(inst, data) inst.sg:GoToState("idle") end)
        },
    },
	
	State
    {
        name = "summon_spikes",
        tags = {"summon","busy"},
        onenter = function(inst,target)
			inst.Physics:Stop()
            inst.components.combat:StartAttack()
            inst.AnimState:PlayAnimation("summon")
			inst.sg.statemem.summontarget = target
			inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/ancient_herald/summon")
            inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/ancient_herald/summon_2d")
			inst.SoundEmitter:PlaySound("dontstarve/sanity/bishop/taunt")
			--startaura(inst)
        end,
		

		
		timeline=
        {
            TimeEvent(20*FRAMES, function(inst)
				for i=0,3 do 
					local target = inst.sg.statemem.summontarget
					if not (target and target:IsValid()) then 
						inst.sg.statemem.summontarget = nil 
						return
					end
					local offset = Vector3( 5 - math.random()*10,0,5 - math.random()*10)
					local pos = inst:GetPosition()
					SpawnLineSpikes(inst,(pos + offset),target:GetPosition(),5)
					--SummonNightmare(inst,inst.sg.statemem.summontarget) 
				end 
				inst:PushEvent("use_herald_skill",{name = "SummonSpikes",cd = 25})
			end),
        },
		
		events=
        {
            EventHandler("animover", function(inst, data) inst.sg:GoToState("idle") end)
        },
    },
	
	State
	{
        name = "summon_meteor",
        tags = {"summon","busy"},
        onenter = function(inst,target)
			inst.Physics:Stop()
            inst.components.combat:StartAttack()
            inst.AnimState:PlayAnimation("summon",true)
			inst.sg.statemem.summontarget = target
			
			inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/ancient_herald/summon")
            inst.SoundEmitter:PlaySound("dontstarve/sanity/bishop/taunt")
			--startaura(inst)
			SpawnMeteor(inst)
			
			inst.sg:SetTimeout(200 * FRAMES)
        end,
		
		ontimeout = function(inst)
			inst.sg:GoToState("taunt")
		end,
		
		onexit = function(inst)
			StopSpawnMeteor(inst)
		end,
		
		
		timeline=
        {
            
        },
		
		events=
        {
            --EventHandler("animover", function(inst, data) inst.sg:GoToState("idle") end)
        },
    },
	
	State
    {
        name = "attack",
        tags = {"attack","busy"},
        onenter = function(inst,target)
            inst.Physics:Stop()
            inst.components.combat:StartAttack()
            inst.AnimState:PlayAnimation("attack")
            inst.sg.statemem.target = target
			--inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/ancient_herald/attack")
            --inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/ancient_herald/attack_2d")
			--inst.SoundEmitter:PlaySound("dontstarve/sanity/rook/attack_grunt")
			--inst.SoundEmitter:PlaySound("dontstarve/sanity/rook/attack_1")
			--inst.SoundEmitter:PlaySound("dontstarve/sanity/knight/attack_grunt")
			--inst.SoundEmitter:PlaySound("dontstarve/sanity/knight/attack_1")
			--startaura(inst)
        end,
		
		onexit = function(inst)
			--stopaura(inst)
		end,
		
		
		timeline=
        {
            TimeEvent(20*FRAMES, function(inst) 
				local target = inst.sg.statemem.target
				inst.components.aura:OnTick()
				inst.components.combat:DoAttack(target) 
				--inst.SoundEmitter:PlaySound("dontstarve/creatures/deerclops/laser")
				--local ring = SpawnPrefab("laser_ring")
                --ring.Transform:SetPosition(inst.Transform:GetWorldPosition())
                --ring.Transform:SetScale(1.1, 1.1, 1.1)
                --DoDamage(inst, 6)
				
				--MindControl(inst,target)
			end),
        },
		
		events=
        {
            EventHandler("animover", function(inst, data) inst.sg:GoToState("idle") end)
        },
    },
    
    State
    {
        name = "appear",
		tags = {"busy"},
        onenter = function(inst)
            inst.AnimState:PlayAnimation("appear")
            --inst.SoundEmitter:PlaySound("dontstarve/ghost/ghost_howl")
            inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/ancient_herald/appear")
        end,
        
        events=
        {
            EventHandler("animover", function(inst, data)  inst.sg:GoToState("idle") end)
        },
        
    },    
    
    State{
        name = "hit",
        tags = {"busy"},
        
        onenter = function(inst)
            --inst.SoundEmitter:PlaySound("dontstarve/ghost/ghost_howl")
            --inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/ancient_herald/hit")
			inst.SoundEmitter:PlaySound("dontstarve/ghost/ghost_howl")
			--inst.SoundEmitter:PlaySound("dontstarve/sanity/knight/hit_response")
            inst.AnimState:PlayAnimation("hit")
            inst.Physics:Stop()            
        end,
        
        events=
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end ),
        },
    },

    -- DEATH STATE
    State
    {
        name = "death",
		tags = {"busy"},
        onenter = function(inst)
            inst.Physics:Stop()
            inst.AnimState:PlayAnimation("death")
            --inst.SoundEmitter:PlaySound("dontstarve/ghost/ghost_howl")
			inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/ancient_herald/death")
        end,
        
        events=
        {
            EventHandler("animover", function(inst, data) 
                if inst.components.lootdropper then
                    inst.components.lootdropper:DropLoot()
                end
            end)
        },
    },
   
}

--CommonStates.AddSimpleWalkStates(states, "walk")
--CommonStates.AddSimpleRunStates(states, getidleanim)
local walkanims = {
	startwalk = "walk_pre",
    walk = "walk_loop",
    stopwalk = "walk_pst",
}
CommonStates.AddWalkStates(states,
{
    starttimeline =
    {
        
    },

	walktimeline =
    {
        
	},

    endtimeline =
    {
        
    },

}, walkanims, true)
    
return StateGraph("SGancient_herald", states, events, "appear")