

AddClassPostConstruct("widgets/writeablewidget", function(self, owner, writeable, config)
	local colour = {203/255,4/255,1/255,1}
	if config and config.EditTextColour then 
		colour = config.EditTextColour
	end
	self.edit_text:SetColour(colour)

end)