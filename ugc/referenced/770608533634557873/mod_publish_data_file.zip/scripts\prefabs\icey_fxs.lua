local function GetDamages(inst, attacker, defaultdmg)
	local head = attacker and attacker.components.inventory and attacker.components.inventory:GetEquippedItem(EQUIPSLOTS.HEAD)
	return head and head.magicdamagemult and defaultdmg * head.magicdamagemult or defaultdmg
end

local assets_fireballhit = {
  Asset("ANIM", "anim/fireball_2_fx.zip"),
  Asset("ANIM", "anim/deer_fire_charge.zip"),
}

local assets_blossomhit = {
  Asset("ANIM", "anim/lavaarena_heal_projectile.zip"),
}

local assets_gooballhit = {
  Asset("ANIM", "anim/gooball_fx.zip"),
}

--------------------------------------------------------------------------

local function CreateTail(bank, build, lightoverride, addcolour, multcolour)
  local inst = CreateEntity()

  inst:AddTag("FX")
  inst:AddTag("NOCLICK")
  --[[Non-networked entity]]
  inst.entity:SetCanSleep(false)
  inst.persists = false

  inst.entity:AddTransform()
  inst.entity:AddAnimState()

  MakeInventoryPhysics(inst)
  inst.Physics:ClearCollisionMask()

  inst.AnimState:SetBank(bank)
  inst.AnimState:SetBuild(build)
  inst.AnimState:PlayAnimation("disappear")
  if addcolour ~= nil then
    inst.AnimState:SetAddColour(unpack(addcolour))
  end
  if multcolour ~= nil then
    inst.AnimState:SetMultColour(unpack(multcolour))
  end
  if lightoverride > 0 then
    inst.AnimState:SetLightOverride(lightoverride)
  end
  inst.AnimState:SetFinalOffset(-1)

  inst:ListenForEvent("animover", inst.Remove)

  return inst
end

local function OnUpdateProjectileTail(inst, bank, build, speed, lightoverride, addcolour, multcolour, hitfx, tails)
  local x, y, z = inst.Transform:GetWorldPosition()
  for tail, _ in pairs(tails) do
    tail:ForceFacePoint(x, y, z)
  end
  if inst.entity:IsVisible() then
    local tail = CreateTail(bank, build, lightoverride, addcolour, multcolour)
    local rot = inst.Transform:GetRotation()
    tail.Transform:SetRotation(rot)
    rot = rot * DEGREES
    local offsangle = math.random() * 2 * PI
    local offsradius = math.random() * .2 + .2
    local hoffset = math.cos(offsangle) * offsradius
    local voffset = math.sin(offsangle) * offsradius
    tail.Transform:SetPosition(x + math.sin(rot) * hoffset, y + voffset, z + math.cos(rot) * hoffset)
    tail.Physics:SetMotorVel(speed * (.2 + math.random() * .3), 0, 0)
    tails[tail] = true
    inst:ListenForEvent("onremove", function(tail) tails[tail] = nil end, tail)
    tail:ListenForEvent("onremove", function(inst)
      tail.Transform:SetRotation(tail.Transform:GetRotation() + math.random() * 30 - 15)
    end, inst)
  end
end

local function OnHitFireBallFn(inst, attacker, target)
	inst:Remove()
	local x,y,z = target.Transform:GetWorldPosition()
	local cast = SpawnPrefab("fireball_hit_fx")
	cast.Transform:SetPosition(x,y,z)
	if cast and cast:IsAsleep() then
	    cast:Remove()
	end
end

local function OnHitBlossomFn(inst, attacker, target)
	--target.components.combat:GetAttacked(attacker, GetDamages(inst, attacker, TUNING.MOD_LAVAARENA.HEALINGSTAFF.DAMAGES))
	local hitfx = SpawnPrefab(inst.hitfx)
	hitfx.Transform:SetPosition(target.Transform:GetWorldPosition())
	inst:Remove()
end

local function OnHitGooballFn(inst, attacker, target)
	local hitfx = SpawnPrefab(inst.hitfx)
	hitfx.Transform:SetPosition(target.Transform:GetWorldPosition())
	inst:Remove()
end

local function OnThrowFireballFn(inst)
	inst:AddTag("NOCLICK")
	inst:ListenForEvent("entitysleep", inst.Remove)
	local x,y,z = inst.Transform:GetWorldPosition()
	local cast = SpawnPrefab("fireball_cast_fx")
	cast.Transform:SetPosition(x,y,z)
	cast:Show()
	--cast.AnimState:PlayAnimation("pre")
end

local function OnThrowBlossomFn(inst)
	inst:AddTag("NOCLICK")
	inst:ListenForEvent("entitysleep", inst.Remove)
end

local function OnThrowGooballFn(inst)
	inst:AddTag("NOCLICK")
	inst:ListenForEvent("entitysleep", inst.Remove)
	local x,y,z = inst.Transform:GetWorldPosition()
	local cast = SpawnPrefab("dark_hit_fx_icey")
	cast.Transform:SetPosition(x,y,z)
	cast:Show()
end

local function OnThrowDarkballFn(inst)
	inst:AddTag("NOCLICK")
	inst:ListenForEvent("entitysleep", inst.Remove)
end 

local function MakeProjectile(name, bank, build, speed, lightoverride, addcolour, multcolour, hitfx, onhitfn, onthrowfn,offset)
  local assets = {
    Asset("ANIM", "anim/"..build..".zip"),
  }

  local prefabs = hitfx ~= nil and { hitfx } or nil

  local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()

    MakeInventoryPhysics(inst)
    RemovePhysicsColliders(inst)

    inst.AnimState:SetBank(bank)
    inst.AnimState:SetBuild(build)
    inst.AnimState:PlayAnimation("idle_loop", true)
    if addcolour ~= nil then
      inst.AnimState:SetAddColour(unpack(addcolour))
    end
    if multcolour ~= nil then
      inst.AnimState:SetMultColour(unpack(multcolour))
    end
    if lightoverride > 0 then
      inst.AnimState:SetLightOverride(lightoverride)
    end
    inst.AnimState:SetFinalOffset(-1)

    inst:AddTag("projectile")

    if not TheNet:IsDedicated() then
      inst:DoPeriodicTask(0, OnUpdateProjectileTail, nil, bank, build, speed, lightoverride, addcolour, multcolour, hitfx, {})
    end

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
      return inst
    end
	inst.hitfx = hitfx
		inst:AddComponent("projectile")
		inst.components.projectile:SetSpeed(speed)
		inst.components.projectile:SetHoming(true) -- Lock the target and follow it
		inst.components.projectile:SetOnThrownFn(onthrowfn)
		inst.components.projectile:SetOnHitFn(onhitfn)
		inst.components.projectile:SetOnMissFn(inst.Remove)
		if offset then 
			inst.components.projectile:SetLaunchOffset(offset)
		end 
		inst.components.projectile:SetHitDist(1.5) -- distance before the target is registered "hits" by the projectile
		inst:ListenForEvent("onthrown", function(inst, data)
			inst.AnimState:SetOrientation(ANIM_ORIENTATION.Default)
			if inst.Physics ~= nil and not inst:HasTag("nocollisionoverride") then
				inst.Physics:ClearCollisionMask()
				inst.Physics:CollidesWith(COLLISION.GROUND)
				if TUNING.COLLISIONSAREON then
					inst.Physics:CollidesWith(COLLISION.OBSTACLES)
				end
			end
		end)
		
		inst:AddComponent("ly_projectile")
		inst.components.ly_projectile:SetSpeed(speed)
		inst.components.ly_projectile:SetOnThrownFn(onthrowfn)
		inst.components.ly_projectile:SetOnHitFn(onhitfn)
		inst.components.ly_projectile:SetOnMissFn(inst.Remove)
		if offset then 
			inst.components.ly_projectile:SetLaunchOffset(offset)
		end 
		inst.components.ly_projectile:SetHitDist(1.5) -- distance before the target is registered "hits" by the projectile
	inst:DoTaskInTime(10,inst.Remove)
    return inst
  end

  return Prefab(name, fn, assets, prefabs)
end

--------------------------------------------------------------------------

local function fireballhit_fn()
  local inst = CreateEntity()

  inst.entity:AddTransform()
  inst.entity:AddAnimState()
  inst.entity:AddSoundEmitter()
  inst.entity:AddNetwork()

  inst.AnimState:SetBank("fireball_fx")
  inst.AnimState:SetBuild("deer_fire_charge")
  inst.AnimState:PlayAnimation("blast")
  inst.AnimState:SetBloomEffectHandle("shaders/anim.ksh")
  inst.AnimState:SetLightOverride(1)
  inst.AnimState:SetFinalOffset(-1)

  inst:AddTag("FX")
  inst:AddTag("NOCLICK")

  inst.entity:SetPristine()

  if not TheWorld.ismastersim then
    return inst
  end

	inst:ListenForEvent("animover", inst.Remove)
	inst:ListenForEvent("entitysleep", inst.Remove)
	inst:DoTaskInTime(10,inst.Remove)
	inst.persists = false

  return inst
end

--------------------------------------------------------------------------

local function blossomhit_fn()
  local inst = CreateEntity()

  inst.entity:AddTransform()
  inst.entity:AddAnimState()
  inst.entity:AddSoundEmitter()
  inst.entity:AddNetwork()

  inst.AnimState:SetBank("lavaarena_heal_projectile")
  inst.AnimState:SetBuild("lavaarena_heal_projectile")
  inst.AnimState:PlayAnimation("hit")
  inst.AnimState:SetAddColour(0, .1, .05, 0)
  inst.AnimState:SetFinalOffset(-1)

  inst:AddTag("FX")
  inst:AddTag("NOCLICK")

  inst.entity:SetPristine()

  if not TheWorld.ismastersim then
    return inst
  end

	inst.persists = false
	inst:ListenForEvent("animover", inst.Remove)
	inst:ListenForEvent("entitysleep", inst.Remove)
	inst:DoTaskInTime(10,inst.Remove)
  return inst
end

local function blossomhit_dark_fn()
  local inst = CreateEntity()

  inst.entity:AddTransform()
  inst.entity:AddAnimState()
  inst.entity:AddSoundEmitter()
  inst.entity:AddNetwork()

  inst.AnimState:SetBank("lavaarena_heal_projectile")
  inst.AnimState:SetBuild("lavaarena_heal_projectile")
  inst.AnimState:PlayAnimation("hit")
  inst.AnimState:SetMultColour(0, 0, 0, 1)
  inst.AnimState:SetFinalOffset(-1)

  inst:AddTag("FX")
  inst:AddTag("NOCLICK")

  inst.entity:SetPristine()

  if not TheWorld.ismastersim then
    return inst
  end

	inst.persists = false
	inst:ListenForEvent("animover", inst.Remove)
	inst:ListenForEvent("entitysleep", inst.Remove)
	inst:DoTaskInTime(10,inst.Remove)

  return inst
end

--------------------------------------------------------------------------

local function gooballhit_fn()
  local inst = CreateEntity()

  inst.entity:AddTransform()
  inst.entity:AddAnimState()
  inst.entity:AddSoundEmitter()
  inst.entity:AddNetwork()

  inst.AnimState:SetBank("gooball_fx")
  inst.AnimState:SetBuild("gooball_fx")
  inst.AnimState:PlayAnimation("blast")
  inst.AnimState:SetMultColour(.2, 1, 0, 1)
  inst.AnimState:SetFinalOffset(-1)

  inst:AddTag("FX")
  inst:AddTag("NOCLICK")

  inst.entity:SetPristine()

  if not TheWorld.ismastersim then
    return inst
  end

	inst.persists = false
	inst:ListenForEvent("animover", inst.Remove)
	inst:ListenForEvent("entitysleep", inst.Remove)
	inst:DoTaskInTime(10,inst.Remove)

  return inst
end

local function bloodhit_fn()
  local inst = CreateEntity()

  inst.entity:AddTransform()
  inst.entity:AddAnimState()
  inst.entity:AddSoundEmitter()
  inst.entity:AddNetwork()

  inst.AnimState:SetBank("gooball_fx")
  inst.AnimState:SetBuild("gooball_fx")
  inst.AnimState:PlayAnimation("blast")
  inst.AnimState:SetMultColour( 223/255, 17/255, 0, 1)
  inst.AnimState:SetFinalOffset(-1)

  inst:AddTag("FX")
  inst:AddTag("NOCLICK")

  inst.entity:SetPristine()

  if not TheWorld.ismastersim then
    return inst
  end

	inst.persists = false
	inst:ListenForEvent("animover", inst.Remove)
	inst:ListenForEvent("entitysleep", inst.Remove)
	inst:DoTaskInTime(10,inst.Remove)

  return inst
end

local function darkhit_fn()
  local inst = CreateEntity()

  inst.entity:AddTransform()
  inst.entity:AddAnimState()
  inst.entity:AddSoundEmitter()
  inst.entity:AddNetwork()

  inst.AnimState:SetBank("gooball_fx")
  inst.AnimState:SetBuild("gooball_fx")
  inst.AnimState:PlayAnimation("blast")
  inst.AnimState:SetMultColour( 0,0, 0, 1)
  inst.AnimState:SetFinalOffset(-1)

  inst:AddTag("FX")
  inst:AddTag("NOCLICK")

  inst.entity:SetPristine()

  if not TheWorld.ismastersim then
    return inst
  end

	inst.persists = false
	inst:ListenForEvent("animover", inst.Remove)
	inst:ListenForEvent("entitysleep", inst.Remove)
	inst:DoTaskInTime(10,inst.Remove)

  return inst
end

--------------------------------------------------------------------------

return  MakeProjectile("blossom_projectile_dark_icey", "lavaarena_heal_projectile", "lavaarena_heal_projectile", 15, 0,nil, { 0,0, 0, 1 }, "blossom_hit_fx_dark_icey", OnHitBlossomFn, OnThrowBlossomFn),  
     MakeProjectile("blood_projectile_icey", "gooball_fx", "gooball_fx", 20, 0, nil, { 223/255, 17/255, 0, 1 }, "blood_hit_fx_icey", OnHitGooballFn, OnThrowGooballFn),
	MakeProjectile("dark_projectile_icey", "gooball_fx", "gooball_fx", 20, 0, nil, { 0,0, 0, 1 }, "dark_hit_fx_icey", OnHitGooballFn, OnThrowDarkballFn),
	Prefab("blossom_hit_fx_dark_icey", blossomhit_dark_fn, assets_blossomhit),
	Prefab("blood_hit_fx_icey", bloodhit_fn, assets_gooballhit),
	Prefab("dark_hit_fx_icey", darkhit_fn, assets_gooballhit)
     