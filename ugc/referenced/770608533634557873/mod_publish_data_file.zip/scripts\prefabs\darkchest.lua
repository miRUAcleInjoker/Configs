require "prefabutil"

local containers = require("containers")
local widgetsetup_old = containers.widgetsetup

local darkchest =
{
    widget =
    {
        slotpos = {},
        animbank = "ui_chest_3x3",
        animbuild = "ui_chest_3x3",
        pos = Vector3(0, 200, 0),
        side_align_tip = 160,
    },
    type = "chest",
}

for y = 2, 0, -1 do
    for x = 0, 2 do
        table.insert(darkchest.widget.slotpos, Vector3(80 * x - 80 * 2 + 80, 80 * y - 80 * 2 + 80, 0))
    end
end

function containers.widgetsetup(container, prefab, data, ...)
	if container.inst.prefab == "darkchest" or prefab == "darkchest" then
		for k, v in pairs(darkchest) do
            container[k] = v
        end
        container:SetNumSlots(container.widget.slotpos ~= nil and #container.widget.slotpos or 0)
        return
	end
    return widgetsetup_old(container, prefab, data, ...)
end

local function TeleportItems(doer,inst,v)
		local items = v.components.container:FindItems(function() return true end)
		for i,j in pairs(items) do 
			if not inst.components.container:IsFull() then 
				--j.Transform:SetPosition(inst:GetPosition():Get())
				--v.components.container:DropItem(j)
				v.components.container:RemoveItem(j, true)
				j.Transform:SetPosition(inst:GetPosition():Get())
				inst.components.container:GiveItem(j)
				--v.components.container:RemoveItemBySlot()
			else	
				break
			end 
		end
end 
AddModRPCHandler("darkchest", "darkchest_teleport", TeleportItems)

local function onopen(inst)
    if not inst:HasTag("burnt") then
        inst.AnimState:PlayAnimation("open")
        inst.SoundEmitter:PlaySound("dontstarve/wilson/chest_open")
    end
	if inst.IsOn and not inst.components.container:IsFull() then 
		local x,y,z = inst:GetPosition():Get()
		local ents = TheSim:FindEntities(x,y,z,10000,{"darkchest"})
		for k,v in pairs(ents) do 
			if v and v:IsValid() and v ~= inst  and v.prefab == "darkchest" and v.components.container 
			and v.IsOn  and not v.components.container:IsEmpty() then 
				
				local vfx = SpawnPrefab("sanity_lower")
				vfx.Transform:SetPosition(v:GetPosition():Get())
				v.SoundEmitter:PlaySound("dontstarve/sanity/shadowrock_down")
				
				local mfx = SpawnPrefab("sanity_raise")
				mfx.Transform:SetPosition(x,y,z)
				inst.SoundEmitter:PlaySound("dontstarve/sanity/shadowrock_up")
				inst:DoTaskInTime(0.5,function()
					if inst.components.container then 
						TeleportItems(nil,inst,v)
					end 
					if inst.replica.container then 
						SendModRPCToServer(MOD_RPC["darkchest"]["darkchest_teleport"],inst,v)
					end
				end)
			end
		end
	end
end 

local function onclose(inst)
    if not inst:HasTag("burnt") then
        inst.AnimState:PlayAnimation("close")
        inst.SoundEmitter:PlaySound("dontstarve/wilson/chest_close")
    end
end

local function onhammered(inst, worker)
    inst.components.lootdropper:DropLoot()
    if inst.components.container ~= nil then
        inst.components.container:DropEverything()
    end
    local fx = SpawnPrefab("collapse_small")
    fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
    fx:SetMaterial("wood")
    inst:Remove()
end

local function onhit(inst, worker)
    if not inst:HasTag("burnt") then
        inst.AnimState:PlayAnimation("hit")
        inst.AnimState:PushAnimation("closed", false)
        if inst.components.container ~= nil then
            inst.components.container:DropEverything()
            inst.components.container:Close()
        end
    end
end

local function doshadow(inst)
    if inst.zaptask ~= nil then
        inst.zaptask:Cancel()
    end

	local fx = SpawnPrefab("cane_ancient_fx")
    fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
	fx.Transform:SetScale(1.5,1.5,1.5)
	--fx.Transform:SetAddColour(161/255,26/255,13/255,1)

    inst.zaptask = inst:DoTaskInTime(math.random(), doshadow)
end

local function discharge(inst)
	if inst.zaptask ~= nil then
        inst.zaptask:Cancel()
        inst.zaptask = nil
    end
end 

local function turnon(inst)
	doshadow(inst)
	inst.Light:Enable(true)
end 

local function turnoff(inst)
	discharge(inst)
	inst.Light:Enable(false)
end 

local function CheckPower(inst,data)
	local power = data.power
	inst.building_power = inst.building_power + power
	inst.building_power = math.max(0,inst.building_power)
	inst.building_power = math.min(inst.max_building_power,inst.building_power)
	if inst.building_power > 0 and not inst.IsOn then 
		print(inst,"Turn on!")
        turnon(inst)
		inst.IsOn = true
    elseif inst.building_power <= 0 and inst.IsOn then
		print(inst,"Turn off!")
        turnoff(inst)
		inst.IsOn = false
    end 
end 

local function onbuilt(inst)
    inst.AnimState:PlayAnimation("place")
    inst.AnimState:PushAnimation("closed", false)
    inst.SoundEmitter:PlaySound("dontstarve/common/chest_craft")
end

local function onsave(inst, data)
	data.building_power = inst.building_power
end

local function onload(inst, data)
	if data then 
		if data.building_power then 
			inst.building_power = data.building_power
		end
		CheckPower(inst,{fromer = inst,power = 0})
	end
end

local function MakeChest(name, bank, build, indestructible, custom_postinit, prefabs)
    local assets =
    {
		--Asset("ANIM", "anim/".."skull_chest"..".zip"),
        Asset("ANIM", "anim/"..build..".zip"),
        Asset("ANIM", "anim/ui_chest_3x2.zip"),
		
    }

    local function fn()
        local inst = CreateEntity()

        inst.entity:AddTransform()
        inst.entity:AddAnimState()
        inst.entity:AddSoundEmitter()
        inst.entity:AddMiniMapEntity()
		inst.entity:AddLight()
        inst.entity:AddNetwork()

        inst.MiniMapEntity:SetIcon(name..".tex")
		
		inst.Light:Enable(false)
		inst.Light:SetRadius(1.5)
		inst.Light:SetFalloff(1)
		inst.Light:SetIntensity(.5)
		inst.Light:SetColour(132/255,0/255,193/255)

        inst:AddTag("structure")
        inst:AddTag("chest")
		inst:AddTag("darkchest")
		inst:AddTag("icey_power_use")
		inst:AddTag("icey_power_building")

        inst.AnimState:SetBank(bank)
        inst.AnimState:SetBuild(build)
        inst.AnimState:PlayAnimation("closed")

        MakeSnowCoveredPristine(inst)

        inst.entity:SetPristine()

        if not TheWorld.ismastersim then
            return inst
        end
		
		inst.IsOn = false
		inst.building_power = 0
		inst.max_building_power = 500

        inst:AddComponent("inspectable")
		inst.components.inspectable.descriptionfn = function(inst,doer)
			return (inst.IsOn and "终界之力潜藏与此" ) or "它需要充电了!"
		end
		
        inst:AddComponent("container")
        inst.components.container:WidgetSetup("darkchest",darkchest)
        inst.components.container.onopenfn = onopen
        inst.components.container.onclosefn = onclose

        inst:AddComponent("lootdropper")
        inst:AddComponent("workable")
        inst.components.workable:SetWorkAction(ACTIONS.HAMMER)
        inst.components.workable:SetWorkLeft(2)
        inst.components.workable:SetOnFinishCallback(onhammered)
        inst.components.workable:SetOnWorkCallback(onhit)

        MakeMediumPropagator(inst)

        inst:AddComponent("hauntable")
        inst.components.hauntable:SetHauntValue(TUNING.HAUNT_TINY)

		inst:DoPeriodicTask(1,function()
			inst:PushEvent("powertrans",{former = inst,power = -10})
		end)
		inst:ListenForEvent("powertrans",CheckPower)
        inst:ListenForEvent("onbuilt", onbuilt)
        MakeSnowCovered(inst)

        inst.OnSave = onsave 
        inst.OnLoad = onload

        if custom_postinit ~= nil then
            custom_postinit(inst)
        end

        return inst
    end

    return Prefab(name, fn, assets, prefabs)
end

return MakeChest("darkchest", "chest", "skull_chest", false, nil, { "collapse_small" }),
    MakePlacer("darkchest_placer", "chest", "skull_chest", "closed")