local assets=
{
	Asset("ANIM", "anim/walking_stick.zip"),
	Asset("ANIM", "anim/swap_walking_stick.zip"),
	Asset("IMAGE","images/inventoryimages/walkingstick.tex"),
	Asset("ATLAS","images/inventoryimages/walkingstick.xml")
    --Asset("INV_IMAGE", "cane"),
}

local function onfinished(inst)
    inst:Remove()
end

local function onlocomote(owner)
	local walking_stick = owner.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
	if walking_stick and walking_stick:IsValid() then 
		if owner.sg and owner.sg:HasStateTag("moving") and walking_stick.equipped then
			walking_stick.components.fueled:StartConsuming()
		else
			walking_stick.components.fueled:StopConsuming()
		end
	end 
end 

local function onequip(inst, owner) 
    owner.AnimState:OverrideSymbol("swap_object", "swap_walking_stick", "swap_object")
    owner.AnimState:Show("ARM_carry") 
    owner.AnimState:Hide("ARM_normal") 
    inst.equipped = true
	inst:ListenForEvent("locomote",onlocomote,owner)
end

local function onunequip(inst, owner) 
    owner.AnimState:Hide("ARM_carry") 
    owner.AnimState:Show("ARM_normal") 
    inst.equipped = false
    inst.components.fueled:StopConsuming()
	inst:RemoveEventCallback("locomote",onlocomote,owner)
end

local function onwornout(inst)
    inst:Remove()
end



local function fn(Sim)
	local inst = CreateEntity()
	local trans = inst.entity:AddTransform()
	local anim = inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter() 
	inst.entity:AddNetwork()       
    MakeInventoryPhysics(inst)
    
    inst.AnimState:SetBank("walking_stick")
    inst.AnimState:SetBuild("walking_stick")
    inst.AnimState:PlayAnimation("walking_stick")
    	
	inst.entity:SetPristine()	
	
    if not TheWorld.ismastersim then
        return inst
    end	  

    inst:AddComponent("weapon")
    inst.components.weapon:SetDamage(17)
    
    inst:AddComponent("inspectable")
    
    inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "walkingstick"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/walkingstick.xml"
    
    inst:AddComponent("equippable")
    
    inst.components.equippable:SetOnEquip( onequip )
    inst.components.equippable:SetOnUnequip( onunequip )
    inst.components.equippable.walkspeedmult = 1.3

    inst:AddComponent("fueled")
    --inst.components.fueled:SetSectionCallback(onfuelchange)
    inst.components.fueled:InitializeFuelLevel(TUNING.TOTAL_DAY_TIME * 3)
    inst.components.fueled:SetDepletedFn(inst.Remove)
    inst.components.fueled:SetFirstPeriod(TUNING.TURNON_FUELED_CONSUMPTION, TUNING.TURNON_FULL_FUELED_CONSUMPTION)

    --inst:ListenForEvent("locomote",onlocomote,owner) 

    return inst
end


return Prefab( "common/inventory/walkingstick", fn, assets) 

