

---------------------------------------------------STRINGS------------------------------------------------------------
---------------------------------------------------CHINESE---------------------------------------------------------
--STRINGS.ICEY_ACHIEVEMENTS = {}
--STRINGS.ICEY_ACHIEVEMENTS[string.upper("first_eat")] = "第一口食物"
--STRINGS.ICEY_ACHIEVEMENTS[string.upper("first_killother")] = "首杀"

PREFAB_SKINS.icey = {"icey_none"}

--[[STRINGS.ANNOUNCE_ICEY_SUITUP = {
	DEFAULT = "让我们融为一体吧！",--"Let's become the whole."
	ICEY = "非支援硬体.....侦测成功！",--"Non-support hardware...Detection success!",
	
	WAGSTAFF = "我发现了！",--"EUREKA!",
	WATHGRITHR = "为了英灵殿！",--"For Valhalla!",
	WORMWOOD = "嘿呀！",--"YAY!",
	WILBUR = "伊！！伊！！",--"EEE EEE!",
	WX78 = "升级完毕！",--"UPGRADE COMPLETE!!",
	WOODLEGS = "耶耶耶耶耶嗝儿！",--"Yarrrrrg!",
	WOODIE = "让我们上吧，嗬！",--"Let's go, eh!",
	WOLFGANG = "沃尔夫刚现在非常强大！",--"WOLFGANG IS MIGHTY!",
	WILSON = "为了科学！",--"For Science!",
	WILLOW = "燃烧殆尽吧！",--"BURN IT ALL!",
	WILBA = "威尔芭冲你而来！",--"SOMETHING WILBA THIS WAY COMES!",
	WICKERBOTTOM = "我宁愿读书！",--"I'd rather be reading!",
	WHEELER = "冒险！",--"Adventure!",
	WEBBER = "这个真是太cooooooool了！",--"This is cool!",
	WENDY = "我已成为死神！",--"I have become Death!",
	WARLY = "我要把你开膛破肚咯！",--"Eat your heart out!",--其实翻译成“嫉妒吧”更好？
	WARBUCKS = "呼啊啊啊啊！",--"Huzzah!",
	WALANI = "冲浪了！！",--"Surf's up!",
	MAXWELL = "我就是这个世界的主宰！",--"I AM SUPERIOR!",
	WAXWELL = "我就是这个世界的主宰！",--"I AM SUPERIOR!",
	WORTOX = "熔铁恶魔启动！",
}--]]



STRINGS.LAUGHAT_CHICKEN = {
	GENERIC = "你怎么戴着小鸡的帽子？",
	WILSON = "你怎么戴着小鸡的帽子？",
	ICEY = "菜 就 多 练 练",
	WATHGRITHR = "我的盟友居然是个滑稽的胆小鬼！",
	WORMWOOD = "菜鸡朋友。",
	WX78 = "侦测到辣鸡属性。",
	WOODIE = "这帽子看得我诅咒都快犯了。",
	WOLFGANG = "把帽子摘下来！你要像沃尔夫冈一样勇敢！",
	WILLOW = "伯尼说它很喜欢你的帽子！",
	WICKERBOTTOM = "你好菜啊！",
	WEBBER = "我们一致认为你是个菜鸡！",
	WENDY = "你不可能缩在这帽子里度过一生。",
	WARLY = "晚餐有谁想吃炖鸡头的吗？",
	WAXWELL = "愚蠢！",
	WORTOX = "鸡你太美！",
	
	PIGMAN = {"猪人看着菜鸡","哦吼，菜鸡。","胆小鬼。"},
	PIGGUARD = {"猪人看着菜鸡","哦吼，菜鸡。","胆小鬼。"},
	BUNNYMAN = {"是菜鸡！","菜！","菜鸡烧肉！"},
}


STRINGS.NAMES[string.upper("bleeds")] = "出血" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("bleeds")] = {
	NORMAL = "出血状态会因受到利刃或刺针攻击而累积,\n一旦超过累积上限,便会受到巨大伤害.",
	ACTIVATED = "",
}

STRINGS.NAMES[string.upper("freeze")] = "冻伤" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("freeze")] = {
	NORMAL = "如果寒气超过累积上限时,\n将会受到伤害,也会陷入冻伤状态.",
	ACTIVATED = "冻伤状态会持续一段时间,\n减伤率,精力恢复速度也会下降.",
}

STRINGS.NAMES[string.upper("curse_death")] = "咒死" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("curse_death")] = {
	NORMAL = "你正在受到敌人诅咒,\n人一旦深陷诅咒,便会立即原地去世.",
	ACTIVATED = "你已经死了.",
}

STRINGS.NAMES[string.upper("poison")] = "中毒" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("poison")] = {
	NORMAL = "你的身体正在累积毒素!\n当毒素超过积累上限时,\n便会陷入中毒状态!",
	ACTIVATED = "中毒状态会持续一段时间,\n同时血量会持续减少.",
}

STRINGS.NAMES[string.upper("strong_poison")] = "剧毒" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("strong_poison")] = {
	NORMAL = "你的身体正在累积剧毒!\n当毒素超过积累上限时,\n便会陷入剧毒状态!",
	ACTIVATED = "剧毒状态会持续很长的时间,\n同时血量会大量减少.",
}

STRINGS.NAMES[string.upper("dantalion_atkbuff")] = "至理名言" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("dantalion_atkbuff")] = {
	NORMAL = "",
	ACTIVATED = "你受到了但他林咒文的庇护,\n攻击力,减伤率与精力恢复速度都有所提高.",
}

STRINGS.NAMES[string.upper("handgun_albert_noregenbuff")] = "坏死" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("handgun_albert_noregenbuff")] = {
	NORMAL = "",
	ACTIVATED = "你的身体陷入坏死状态,\n期间无法通过任何方式恢复生命值.",
}

if TUNING.ICEY_LANGUAGE == "chinese" then 

--[[STRINGS.ACTIONS.CASTAOE ={
	SAFULASI = "死吧,虫子!",
	AIUR_PROTECTER = "狂热冲锋",
	ALEX_BLADE = "淘汰之刃",
	GAUSS_GUN = "聚变打击",
	SHADOW_SAD = "亡者大军",
	WALL_FACER = "执剑人的决意",
	ICEY_BLADE = "突围冲击",
	FIREBAT = "放置燃油",
	ARBITER = "神风冲击",
}--]]
STRINGS.ACTIONS.CASTAOE.ICEY_BLADE = "突围冲击" 
STRINGS.ACTIONS.CASTAOE.DRAGONSLAYER_TRIDENT = "风暴落雷" 
STRINGS.ACTIONS.CASTAOE.PYROMANCY_FLAME = "释放咒术" 
STRINGS.ACTIONS.CASTAOE.AXE = "战吼" 
STRINGS.ACTIONS.CASTAOE.GOLDENAXE = "战吼" 
STRINGS.ACTIONS.CASTAOE.PICKAXE = "一鼓作气" 
STRINGS.ACTIONS.CASTAOE.GOLDENPICKAXE = "一鼓作气" 
STRINGS.ACTIONS.CASTAOE.HAMBAT = "食欲" 
STRINGS.ACTIONS.CASTAOE.NIGHTSTICK = "忍耐" 
STRINGS.ACTIONS.CASTAOE.SPEAR = "突击"
STRINGS.ACTIONS.CASTAOE.SPEAR_WATHGRITHR = "天空突刺"
STRINGS.ACTIONS.CASTAOE.SPIDER_HIGHER_SPEAR = "随兴狂王"
STRINGS.ACTIONS.CASTAOE.BEEGUARD = "毒刺导弹"
STRINGS.ACTIONS.CASTAOE.KNIGHT_CUTLASS = "咸鱼突刺"
STRINGS.ACTIONS.CASTAOE.YHORM_BLADE = "战吼"
STRINGS.ACTIONS.CASTAOE.YHORM_SHIELD = "盾牌冲击"
STRINGS.ACTIONS.CASTAOE.ICEY_AXE_VICTORIAN = "回旋斩"
STRINGS.ACTIONS.CASTAOE.LUCY = STRINGS.ACTIONS.CASTAOE.LAVAARENA_LUCY
STRINGS.ACTIONS.CASTAOE.SHADOWMIXTURES_BLADE = "魔天陇月"
STRINGS.ACTIONS.CASTAOE.USELESS_CORKBAT = "战吼"
STRINGS.ACTIONS.CASTAOE.USELESS_PEGLEG = "战吼"
STRINGS.ACTIONS.CASTAOE.SHOVEL = "掘地求升"
STRINGS.ACTIONS.CASTAOE.GOLDENSHOVEL = "掘地求升"
STRINGS.ACTIONS.CASTAOE.HANDGUN_ALBERT = "速效灭菌弹" 
STRINGS.ACTIONS.CASTAOE.HAMMER = "追地" 
STRINGS.ACTIONS.CASTAOE.CURSED_BLADE = "赎罪" 



STRINGS.NAMES.ICEY = "艾希"
STRINGS.SKIN_NAMES.icey = "艾希"
STRINGS.SKIN_NAMES.icey_none = "艾希"
STRINGS.CHARACTER_TITLES.icey = "艾希"
STRINGS.CHARACTER_NAMES.icey = "艾希"
STRINGS.CHARACTER_DESCRIPTIONS.icey = "*是作者的老婆\n*从倒下的敌人身上汲取能量\n*控（矿）场技能丰富\n"
STRINGS.CHARACTER_QUOTES.icey = "\"又有死宅在找我的本子\""
STRINGS.CHARACTERS.ICEY = require "speech_iceyv2"


STRINGS.NAMES.ICEY_SHADOW = "艾希之影"
---------------------------------
STRINGS.NAMES.SPIDER_HAOJIE = "浩劫"
STRINGS.NAMES.SPIDER_XIANFENG = "先锋"
STRINGS.NAMES.SPIDER_CHASER = "追猎者"
STRINGS.NAMES.SPIDER_BOMB = "爆虫"
STRINGS.NAMES.SPIDER_DRAGOON = "龙骑士"
STRINGS.NAMES.SPIDER_HIGHER = "主宰"
STRINGS.NAMES.TADALIN_TOWER = "虚空邪能水晶塔"
STRINGS.NAMES.SKY_WALKER = "天罚行者"
STRINGS.NAMES.JADE = "青玉巨神"
STRINGS.NAMES.ICEY_SANS = "黯影·艾希"
----------------------------------
STRINGS.NAMES.MERM_DEATH = "死徒"
STRINGS.NAMES.PIGHOUSE_BLOOD = "被感染的猪舍"
STRINGS.NAMES.MERMHOUSE_BLOOD = "被感染的小屋"
----------------------------------
STRINGS.NAMES.SPIDER_HIGHER_GOOD = "主宰纪念章"
STRINGS.NAMES.SKY_WALKER_GOOD = "天罚行者纪念章"
---------------------------------------------------
STRINGS.NAMES.SPIDER_MONKEY = "末日巨兽"
---------------------------------------------------
STRINGS.NAMES.PUGALISK = "世界吞噬者"
STRINGS.NAMES.PUGALISK_BODY = "世界吞噬者"
STRINGS.NAMES.PUGALISK_TAIL = "世界吞噬者"
STRINGS.NAMES.PUGALISK_SEGMENT = "世界吞噬者"
STRINGS.NAMES.SNAKE_BONE = "巨大蛇骨" 
STRINGS.NAMES.SNAKEBONESOUP = "蛇骨汤"
----------------------------------------------------
STRINGS.NAMES.MEAN_FLYTRAP = "幼儿园小班花"  
STRINGS.NAMES.MEAN_FLYTRAP_NAMES = {
	"幼儿园小班花",
	"幼儿园中班花",
	"幼儿园大班花",
} 
STRINGS.NAMES.ADULT_FLYTRAP = "幼儿园老班花"
STRINGS.NAMES.VENUS_STALK = "班花草茎"   
STRINGS.NAMES.WALKINGSTICK = "疾行手杖"
STRINGS.RECIPE_DESC.WALKINGSTICK = "疾如岛风!"
STRINGS.NAMES.NECTAR_POD = "班花的花蜜"   
----------------------------------------------------
STRINGS.NAMES.TIME_DEMON = "时间膜人"
----------------------------------------------------
STRINGS.NAMES.ICEY_BOARRIOR = "巨人尤姆"
----------------------------------------------------
STRINGS.NAMES.TIGERSHARK_DUKE = "虎鲨公爵"
STRINGS.NAMES.SHARKITTEN_PROJECTILE = "猫鲨"
----------------------------------------------------
STRINGS.NAMES.BOSS_ELECARMET = "暮光执政官" 
----------------------------------------------------
STRINGS.NAMES.MOON_GIAOUR = "FDA-7 巨擘" 
STRINGS.NAMES.MOON_GIAOUR_MINION = "机械教的异端"
STRINGS.NAMES.MACHINE_BADGE = "机魂圣徽"
----------------------------------------------------
STRINGS.NAMES.ANCIENT_HERALD = "远古先驱"
STRINGS.NAMES.ANCIENT_ROBOTS = "和平行者战斗群"
STRINGS.NAMES.METAL_HULK_MERGE = "和平行者"
STRINGS.CHARACTERS.GENERIC.DESCRIBE.METAL_HULK_MERGE = "今天又是核平的一天。"
STRINGS.NAMES.IRON = "铁矿石"
----------------------------------------------------
STRINGS.NAMES.DEATH_LEGION = "圣·死人军团"
STRINGS.CHARACTERS.GENERIC.DESCRIBE.DEATH_LEGION = "大尸球！"
----------------------------------------------------
STRINGS.NAMES.DARK_ANTQUEEN = "人脓们的化身"
STRINGS.CHARACTERS.GENERIC.DESCRIBE.DARK_ANTQUEEN = "你可真丑！"
----------------------------------------------------
STRINGS.NAMES.SHADOW_SEED = "黯影的原核"
STRINGS.NAMES.GESTALT_REPORT =  "盖什塔尔计划书"
----------------------------------------------------
STRINGS.NAMES.ICEY_POD = "监视者温蒂"
----------------------------------------------------
STRINGS.NAMES.POG = "波格狐狸"
----------------------------------------------------
STRINGS.NAMES.WUGONG = "帽精"
STRINGS.NAMES.WUGONG_BODY = "帽精"
----------------------------------------------------
STRINGS.NAMES.CHEST_MONSTER = "贪欲者"
STRINGS.NAMES.CHEST_MONSTER_HAT = "贪欲者的烙印"

--[[STRINGS.NAMES.PIGELITE1 = "教宗沙利♂Van"
STRINGS.NAMES.PIGELITE2 = "奴隶骑士Gay♂尔"
STRINGS.NAMES.PIGELITE3 = "发狂暗灵弗Door♂林克"
STRINGS.NAMES.PIGELITE4 = "妖王Oh♂斯罗艾斯"--]]


STRINGS.NAMES[string.upper("expostulations")] = "建言" 
STRINGS.RECIPE_DESC[string.upper("expostulations")] = "留给后人一些提示。"

STRINGS.NAMES[string.upper("icey_resolver")] = "分解引擎" 
STRINGS.RECIPE_DESC[string.upper("icey_resolver")] = "看起来比炼金引擎科学多了!"

STRINGS.NAMES[string.upper("cutcrystal")] = "水晶砖" 
STRINGS.RECIPE_DESC[string.upper("cutcrystal")] = "不一样的闪闪!"

STRINGS.NAMES[string.upper("icey_tower")] = "水晶塔压制单元" 
STRINGS.RECIPE_DESC[string.upper("icey_tower")] = "产生灵能的主要建筑"

STRINGS.NAMES[string.upper("xuhua_line_item")] = "虚化回路" 
STRINGS.RECIPE_DESC[string.upper("xuhua_line_item")] = "输送灵能"

STRINGS.NAMES[string.upper("power_line_item")] = "强化回路" 
STRINGS.RECIPE_DESC[string.upper("power_line_item")] = "强化灵能"

STRINGS.NAMES[string.upper("zerg_crusher")] = "灵能粉碎器" 
STRINGS.RECIPE_DESC[string.upper("zerg_crusher")] = "用敌人来粉碎敌人"

STRINGS.NAMES[string.upper("happy_target")] = "吵吵假人" 
STRINGS.RECIPE_DESC[string.upper("happy_target")] = "嘲讽!圣盾!"

STRINGS.NAMES[string.upper("super_icebox")] = "时滞冰箱" 
STRINGS.RECIPE_DESC[string.upper("super_icebox")] = "能够冻结时间"

STRINGS.NAMES[string.upper("photon_cannon_item")] = "光子眼球炮塔" 
STRINGS.RECIPE_DESC[string.upper("photon_cannon_item")] = "基础的防御建筑"

STRINGS.NAMES[string.upper("darkchest")] = "末影之箱" 
STRINGS.RECIPE_DESC[string.upper("darkchest")] = "撕裂末影之力"

STRINGS.NAMES[string.upper("icey_park_fence_tall")] = "防暴栅栏(高)" 
STRINGS.RECIPE_DESC[string.upper("icey_park_fence_tall")] = "你不能通过这里"

STRINGS.NAMES[string.upper("icey_park_fence_short")] = "防暴栅栏(低)" 
STRINGS.RECIPE_DESC[string.upper("icey_park_fence_short")] = "你不能通过这里"

STRINGS.NAMES[string.upper("icey_park_fence_tall_item")] = "防暴栅栏(高)" 
STRINGS.RECIPE_DESC[string.upper("icey_park_fence_tall_item")] = "你不能通过这里"

STRINGS.NAMES[string.upper("icey_park_fence_short_item")] = "防暴栅栏(低)" 
STRINGS.RECIPE_DESC[string.upper("icey_park_fence_short_item")] = "你不能通过这里"

STRINGS.NAMES[string.upper("icey_park_gate_item")] = "防暴门" 
STRINGS.RECIPE_DESC[string.upper("icey_park_gate_item")] = "这边请"

STRINGS.NAMES[string.upper("icey_tent")] = "低温静滞场" 
STRINGS.RECIPE_DESC[string.upper("icey_tent")] = "睡个好觉"

STRINGS.NAMES[string.upper("icey_carrook")] = "掠夺者" 
STRINGS.RECIPE_DESC[string.upper("icey_carrook")] = "令大地颤抖"

STRINGS.NAMES[string.upper("icey_battery")] = "护盾电池" 
STRINGS.RECIPE_DESC[string.upper("icey_battery")] = "为你的护盾充能!"

STRINGS.NAMES[string.upper("icey_battery2")] = "高能电池" 
STRINGS.RECIPE_DESC[string.upper("icey_battery2")] = "Blzzzzzz..."

STRINGS.NAMES[string.upper("icey_battery3")] = "熔融电池" 
STRINGS.RECIPE_DESC[string.upper("icey_battery3")] = "使人精神饱满"

STRINGS.NAMES[string.upper("icey_battery4")] = "纳米电池" 
STRINGS.RECIPE_DESC[string.upper("icey_battery4")] = "维修用"

STRINGS.NAMES[string.upper("icey_armor")] = "护盾发生器"  
STRINGS.RECIPE_DESC[string.upper("icey_armor")] = "自动使用你的护盾电池!"

STRINGS.NAMES[string.upper("icey_armor2")] = "幻崩投影组件"  
STRINGS.RECIPE_DESC[string.upper("icey_armor2")] = "影分身！瞬！"

STRINGS.NAMES[string.upper("icey_magic")] = "生命精华"

STRINGS.NAMES[string.upper("icey_blade")] = "高频切割刃" 
STRINGS.RECIPE_DESC[string.upper("icey_blade")] = "战士,已经苏醒！"

STRINGS.NAMES[string.upper("icey_reaper")] = "死神1000型" 
STRINGS.RECIPE_DESC[string.upper("icey_reaper")] = "对庄稼来说,所有收割者都是死神"

STRINGS.NAMES[string.upper("worm_bait")] = "腐化诱饵" 
STRINGS.RECIPE_DESC[string.upper("worm_bait")] = "招待一条贪吃蛇"

STRINGS.NAMES[string.upper("icey_ball")] = "反组引力球" 
STRINGS.RECIPE_DESC[string.upper("icey_ball")] = "湮灭在即！"

STRINGS.NAMES[string.upper("icey_fucker")] = "庞白君" 
STRINGS.RECIPE_DESC[string.upper("icey_fucker")] = "我们热爱的旁白"

STRINGS.NAMES[string.upper("rock_crystal")] = "晶体矿" 

STRINGS.NAMES[string.upper("crystal_item")] = "晶体矿石"
STRINGS.RECIPE_DESC[string.upper("crystal_item")] = "用精华凝聚实体。"

STRINGS.NAMES[string.upper("storm_controlor")] = "风暴管束者"
STRINGS.RECIPE_DESC[string.upper("storm_controlor")] = "若想打倒巨人，必须有风暴剑。"

STRINGS.NAMES[string.upper("dark_halberd")] = "幽邃战斧"
STRINGS.RECIPE_DESC[string.upper("dark_halberd")] = "你用不着去打宝箱怪"

STRINGS.NAMES[string.upper("halberd")] = "战斧"
STRINGS.RECIPE_DESC[string.upper("halberd")] = "锋利，而且致命。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("halberd")] = "我能像一个真正的守卫一样战斗了。"

STRINGS.NAMES[string.upper("icey_axe_victorian")] = "佣兵手斧"
STRINGS.RECIPE_DESC[string.upper("icey_axe_victorian")] = ""
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("icey_axe_victorian")] = ""

STRINGS.NAMES[string.upper("gold_dust_repair")] = "修理光粉"
STRINGS.RECIPE_DESC[string.upper("gold_dust_repair")] = "用来修理装备。"

STRINGS.NAMES[string.upper("bloodmooneye")] = "血红眼眸宝珠"
STRINGS.RECIPE_DESC[string.upper("bloodmooneye")] = "化身暗灵，入侵别人的世界。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("bloodmooneye")] = "入侵别人，抢走余火吧。"


STRINGS.NAMES[string.upper("icey_cookpot")] = "科技电饭锅"
STRINGS.NAMES[string.upper("icey_cookpot_item")] = "科技电饭锅"
STRINGS.RECIPE_DESC[string.upper("icey_cookpot_item")] = "当然，是蓝色的"

STRINGS.NAMES[string.upper("icey_smelter")] = "冶炼台"
STRINGS.RECIPE_DESC[string.upper("icey_smelter")] = "用来冶炼合金！"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("icey_smelter")] = "大炼钢铁的时候到了。"

STRINGS.NAMES[string.upper("icey_cooking_spit")] = "烤肉架"
STRINGS.RECIPE_DESC[string.upper("icey_cooking_spit")] = "能够稍微防潮，应该吧。"

STRINGS.NAMES[string.upper("gashat")] = "空气过滤器"
STRINGS.RECIPE_DESC[string.upper("gashat")] = "最简单的防辐射尘用具"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("gashat")] = "最简单的防辐射尘用具。"

STRINGS.NAMES[string.upper("gasmaskhat")] = "防毒面具"
STRINGS.RECIPE_DESC[string.upper("gasmaskhat")] = "戴上去让人有点不舒服"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("gasmaskhat")] = "戴上去让人有点不舒服。"

STRINGS.NAMES[string.upper("pyromancy_flame")] = "咒术之火"
STRINGS.RECIPE_DESC[string.upper("pyromancy_flame")] = "释放咒术的基本触媒。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("pyromancy_flame")] = "一小团火苗组成的手套。"

STRINGS.NAMES[string.upper("xuhua_line")] = "虚化回路" 

STRINGS.NAMES[string.upper("power_line")] = "强化回路" 

STRINGS.NAMES[string.upper("photon_cannon")] = "光子眼球炮塔" 

STRINGS.NAMES[string.upper("icey_park_gate")] = "防暴门" 

STRINGS.NAMES[string.upper("icey_pokeball")] = "精灵球" 

STRINGS.NAMES[string.upper("metroworld_radiation_debuff")] = "辐射毒气"

STRINGS.NAMES[string.upper("clocktower_door")] = "时计塔之门" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("clocktower_door")] = "滴答滴答！"

STRINGS.NAMES[string.upper("clocktower_spear_trap")] = "尖刺陷阱" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("clocktower_spear_trap")] = "看起来很危险。"

STRINGS.NAMES[string.upper("clocktower_spear_trap_broken")] = "损坏的陷阱" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("clocktower_spear_trap_broken")] = "他已经坏掉了。"

STRINGS.NAMES[string.upper("clocktower_spotlight")] = "警戒者探照灯" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("clocktower_spotlight")] = "别被它发现了！"

STRINGS.NAMES[string.upper("clocktower_catapult")] = "投石机阵列" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("clocktower_catapult")] = "看起来很危险。"

STRINGS.NAMES[string.upper("clocktower_fire_statue")] = "火焰佣兵" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("clocktower_fire_statue")] = "烫！烫！"

STRINGS.NAMES[string.upper("clocktower_catapult_projectile")] = "石块" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("clocktower_catapult_projectile")] = "啊啊啊啊啊！"

STRINGS.NAMES[string.upper("flup")] = "咒蛙" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("flup")] = "给人带来诅咒的不详生物。"


STRINGS.NAMES[string.upper("icey_dracula")] = "魔王·犹大" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("icey_dracula")] = "你笑得好像老德啊。"

STRINGS.NAMES[string.upper("death_dragon")] = "真祖·犹大" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("death_dragon")] = ""

STRINGS.NAMES[string.upper("dragonslayer_trident")] = "猎龙草叉" 
STRINGS.RECIPE_DESC[string.upper("dragonslayer_trident")] = "古代园丁用来叉草的武器。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("dragonslayer_trident")] = "带着雷电的气息。"

STRINGS.NAMES[string.upper("jingdoor_cloud")] = "筋Door♂云" 
STRINGS.RECIPE_DESC[string.upper("jingdoor_cloud")] = "新日暮里跤♂警的跤♂通工具"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("jingdoor_cloud")] = "带着哲学的气息。"

STRINGS.NAMES[string.upper("pyromancy_fireball")] = "火球" 
STRINGS.RECIPE_DESC[string.upper("pyromancy_fireball")] = "发射火球。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("pyromancy_fireball")] = "发射火球。"

STRINGS.NAMES[string.upper("pyromancy_bursting_fireball")] = "火焰霰弹" 
STRINGS.RECIPE_DESC[string.upper("pyromancy_bursting_fireball")] = "发射火焰霰弹。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("pyromancy_bursting_fireball")] = "发射火焰霰弹。"

STRINGS.NAMES[string.upper("pyromancy_acid_surge")] = "强酸液" 
STRINGS.RECIPE_DESC[string.upper("pyromancy_acid_surge")] = "喷射能腐蚀装备的强酸液。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("pyromancy_acid_surge")] = "喷射能腐蚀装备的强酸液。"

STRINGS.NAMES[string.upper("pyromancy_boulder_heave")] = "吐岩" 
STRINGS.RECIPE_DESC[string.upper("pyromancy_boulder_heave")] = "投掷沉重岩石。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("pyromancy_boulder_heave")] = "投掷沉重岩石。"

STRINGS.NAMES[string.upper("pyromancy_iron_flesh")] = "铁身躯" 
STRINGS.RECIPE_DESC[string.upper("pyromancy_iron_flesh")] = "使自己坚硬如铁，但是降低速度。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("pyromancy_iron_flesh")] = "使自己坚硬如铁，但是降低速度。"

STRINGS.NAMES[string.upper("pyromancy_rapport")] = "魅惑" 
STRINGS.RECIPE_DESC[string.upper("pyromancy_rapport")] = "魅惑一名生物成为暂时的同伴。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("pyromancy_rapport")] = "魅惑一名生物成为暂时的同伴。"

STRINGS.NAMES[string.upper("pyromancy_floating_chaos")] = "浮空混沌" 
STRINGS.RECIPE_DESC[string.upper("pyromancy_floating_chaos")] = "能放出飞散火块的混沌火球。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("pyromancy_floating_chaos")] = "能放出飞散火块的混沌火球。"

STRINGS.NAMES[string.upper("pyromancy_firestorm")] = "火焰风暴" 
STRINGS.RECIPE_DESC[string.upper("pyromancy_firestorm")] = "在自己身边召唤火焰风暴。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("pyromancy_firestorm")] = "在自己身边召唤火焰风暴。"

STRINGS.NAMES[string.upper("icey_armor_vortexcloak")] = "漆黑斗篷" 
STRINGS.RECIPE_DESC[string.upper("icey_armor_vortexcloak")] = "用过度沉积在一起的灵魂制作的披风。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("icey_armor_vortexcloak")] = "它们的力量太过于邪恶了。"

STRINGS.NAMES[string.upper("shadowmixtures_blade")] = "噩魔爪痕" 
STRINGS.RECIPE_DESC[string.upper("shadowmixtures_blade")] = "漆黑得看不清原本面目的刀。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("shadowmixtures_blade")] = "好强的暗瘴气。"


STRINGS.NAMES[string.upper("mutsuki_ai")] = "睦月" 
STRINGS.RECIPE_DESC[string.upper("mutsuki_ai")] = "领养一个被净化的灵魂。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("mutsuki_ai")] = "咕噜喵画的灰常可爱。"

STRINGS.NAMES[string.upper("mutsuki_ai_builder")] = "睦月" 
STRINGS.RECIPE_DESC[string.upper("mutsuki_ai_builder")] = "领养一个被净化的灵魂。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("mutsuki_ai_builder")] = "咕噜喵画的灰常可爱。"

STRINGS.NAMES[string.upper("spider_higher_spear")] = "女王磔枪" 
STRINGS.RECIPE_DESC[string.upper("spider_higher_spear")] = "看起来挺恐怖的。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("spider_higher_spear")] = "死了也不让你安生。"

STRINGS.NAMES[string.upper("yhorm_blade")] = "尤姆大柴刀" 
STRINGS.RECIPE_DESC[string.upper("yhorm_blade")] = "炼成的小型化砍刀。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("yhorm_blade")] = "即便轻量化了也很重。"

STRINGS.NAMES[string.upper("yhorm_shield")] = "尤姆大盾" 
STRINGS.RECIPE_DESC[string.upper("yhorm_shield")] = "尤姆丢弃的大盾。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("yhorm_shield")] = "就像一堵墙一样。"

STRINGS.NAMES[string.upper("handgun_albert")] = "阿尔伯特01R" 
STRINGS.RECIPE_DESC[string.upper("handgun_albert")] = "灌注血清子弹的手枪。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("handgun_albert")] = "威斯克你可还好？"

STRINGS.NAMES[string.upper("cursed_blade")] = "诅咒之刃" 
STRINGS.RECIPE_DESC[string.upper("cursed_blade")] = "被击中就死。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("cursed_blade")] = "想玩点刺激的吗？"

STRINGS.NAMES[string.upper("hat_icey_chicken")] = "菜鸡帽"
STRINGS.RECIPE_DESC[string.upper("hat_icey_chicken")] = "只有菜鸡们才会戴的帽子....你不会戴的对吧？"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("hat_icey_chicken")] = "你好菜啊。"


STRINGS.NAMES[string.upper("armor_metalplate")] = "骑士铠甲" 
STRINGS.RECIPE_DESC[string.upper("armor_metalplate")] = "下级骑士的铠甲。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("armor_metalplate")] = "稍微有点重。"

STRINGS.NAMES[string.upper("hat_metalplate")] = "骑士头盔" 
STRINGS.RECIPE_DESC[string.upper("hat_metalplate")] = "下级骑士的头盔。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("hat_metalplate")] = "有点重，但不算太重。"

STRINGS.NAMES[string.upper("knight_cutlass")] = "旗鱼短剑" 
STRINGS.RECIPE_DESC[string.upper("knight_cutlass")] = "用死掉的旗鱼做的剑。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("knight_cutlass")] = "很锋利的短剑。"

STRINGS.NAMES[string.upper("icey_living_artifact")] = "无畏战士套装"
STRINGS.RECIPE_DESC[string.upper("icey_living_artifact")] = "一款适合莽的动力外骨骼。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("icey_living_artifact")] = "这是个战争机器装置，我得好好使用它！"

STRINGS.NAMES[string.upper("infused_iron")] = "充能的铁" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("infused_iron")] = "被某种能流充能的铁块。"



STRINGS.NAMES[string.upper("icey_hunter_clothing1")] = "亚楠猎人服装"
STRINGS.RECIPE_DESC[string.upper("icey_hunter_clothing1")] = "亚楠新猎人们的标准服饰。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("icey_hunter_clothing1")] = "很轻便的服装，就是有点紧。"

STRINGS.NAMES[string.upper("icey_hunter_hat1")] = "亚楠猎人帽"
STRINGS.RECIPE_DESC[string.upper("icey_hunter_hat1")] = "亚楠新猎人们的标准服饰。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("icey_hunter_hat1")] = "带三角折边的帽子。"


STRINGS.NAMES[string.upper("hunter_blunderbuss")] = "手持加农炮"
STRINGS.RECIPE_DESC[string.upper("hunter_blunderbuss")] = "威力巨大的火药枪。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("hunter_blunderbuss")] = "太长了，不适合枪反。"

STRINGS.NAMES[string.upper("hunter_trusty_shooter")] = "火焰喷射器"
STRINGS.RECIPE_DESC[string.upper("hunter_trusty_shooter")] = "牛角型的短枪。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("hunter_trusty_shooter")] = "牛角型的短枪。"

STRINGS.NAMES[string.upper("death_dragon_ball")] = "暗术弹" 

STRINGS.NAMES.GREEN_PEEKHEN = "皮普鸡"
STRINGS.CHARACTERS.GENERIC.DESCRIBE.GREEN_PEEKHEN = "这是凤凰吗？"

STRINGS.NAMES[string.upper("icey_boss_cinder")] = "薪王柴薪" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("icey_boss_cinder")] = "某位薪王留下的柴薪。"

STRINGS.NAMES[string.upper("clocktower_key")] = "时计塔的钥匙" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("clocktower_key")] = "用来打开时计塔的大门。"

STRINGS.NAMES[string.upper("insanity_skull")] = "狂人的姿势" 
STRINGS.RECIPE_DESC[string.upper("insanity_skull")] = "一块奇怪的头骨。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("insanity_skull")] = "一块奇怪的头骨。"

STRINGS.NAMES[string.upper("useless_corkbat")] = "大型棍棒" 
STRINGS.RECIPE_DESC[string.upper("useless_corkbat")] = "大型的木制棍棒。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("useless_corkbat")] = "大型的木制棍棒。"

STRINGS.NAMES[string.upper("useless_pegleg")] = "棍棒" 
STRINGS.RECIPE_DESC[string.upper("useless_pegleg")] = "一般的木制棍棒。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("useless_pegleg")] = "一般的木制棍棒。"

STRINGS.NAMES[string.upper("aiur_securitycontract")] = "折越场安保协议" 
STRINGS.RECIPE_DESC[string.upper("aiur_securitycontract")] = "用来召唤你的高原同伴！"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("aiur_securitycontract")] = "我可以组建我自己的军队了！"

STRINGS.NAMES[string.upper("blood_blade_minion")] = "血液使者" 
STRINGS.RECIPE_DESC[string.upper("blood_blade_minion")] = "背负着远古被处刑者怨念的断头剑。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("blood_blade_minion")] = "竟然是剑魔！"

STRINGS.NAMES[string.upper("blood_blade_minion_builder")] = "使魔·血液使者" 
STRINGS.RECIPE_DESC[string.upper("blood_blade_minion_builder")] = "召唤血液使者来帮助你。"

STRINGS.NAMES[string.upper("waxwelljournal_dantalion")] = "但他林" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("waxwelljournal_dantalion")] = "愿古老智慧祝福你。"
STRINGS.NAMES[string.upper("waxwelljournal_dantalion_builder")] = "使魔·但他林" 
STRINGS.RECIPE_DESC[string.upper("waxwelljournal_dantalion_builder")] = "召唤大书库的魔书-但他林来帮助你。"



STRINGS.NAMES[string.upper("icey_snake_eye")] = "蛇眼" 
STRINGS.RECIPE_DESC[string.upper("icey_snake_eye")] = "老蛇用过的电子眼罩。"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("icey_snake_eye")] = "我没瞎呢。"

STRINGS.NAMES[string.upper("insanity_skull_wilson")] = "狂人的姿势" 
STRINGS.RECIPE_DESC[string.upper("insanity_skull_wilson")] = "受到启发的疯子的头骨。"

STRINGS.NAMES[string.upper("icey_sikushui")] = "鲨鱼皮泳衣" 
STRINGS.RECIPE_DESC[string.upper("icey_sikushui")] = "死库水！"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("icey_sikushui")] = "为啥一个作战机器人穿需要这种东西啊。"

STRINGS.NAMES[string.upper("flyhead_stone")] = "人造人符文" 
STRINGS.RECIPE_DESC[string.upper("flyhead_stone")] = "分头行动！"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("flyhead_stone")] = "接 头 霸 王"



STRINGS.ANNOUNCE_ICEY_SUITUP = {
	DEFAULT = "让我们融为一体吧！",--"Let's become the whole."
	ICEY = "非支援硬体.....侦测成功！",--"Non-support hardware...Detection success!",
	
	WAGSTAFF = "我发现了！",--"EUREKA!",
	WATHGRITHR = "为了英灵殿！",--"For Valhalla!",
	WORMWOOD = "嘿呀！",--"YAY!",
	WILBUR = "伊！！伊！！",--"EEE EEE!",
	WX78 = "升级完毕！",--"UPGRADE COMPLETE!!",
	WOODLEGS = "耶耶耶耶耶嗝儿！",--"Yarrrrrg!",
	WOODIE = "让我们上吧，嗬！",--"Let's go, eh!",
	WOLFGANG = "沃尔夫刚现在非常强大！",--"WOLFGANG IS MIGHTY!",
	WILSON = "为了科学！",--"For Science!",
	WILLOW = "燃烧殆尽吧！",--"BURN IT ALL!",
	WILBA = "威尔芭冲你而来！",--"SOMETHING WILBA THIS WAY COMES!",
	WICKERBOTTOM = "我宁愿读书！",--"I'd rather be reading!",
	WHEELER = "冒险！",--"Adventure!",
	WEBBER = "这个真是太cooooooool了！",--"This is cool!",
	WENDY = "我已成为死神！",--"I have become Death!",
	WARLY = "我要把你开膛破肚咯！",--"Eat your heart out!",--其实翻译成“嫉妒吧”更好？
	WARBUCKS = "呼啊啊啊啊！",--"Huzzah!",
	WALANI = "冲浪了！！",--"Surf's up!",
	MAXWELL = "我就是这个世界的主宰！",--"I AM SUPERIOR!",
	WAXWELL = "我就是这个世界的主宰！",--"I AM SUPERIOR!",
	WORTOX = "熔铁恶魔启动！",
}


local pignames = {
	--黑魂3
	"霍拉斯",
	"安里",
	"霍克伍德",
	"安德烈",
	"鲁道斯",
	"希里斯",
	"李奥纳德",
	"罗沙丽亚",
	"帕奇",
	"尤艾尔",
	"尤莉雅",
	"葛雷瑞特",
	"柯弭库斯",
	"伊莉娜",
	"伊果",
	"杰克巴尔多",
	"欧贝克",
	"卡露拉",
	"幽儿希卡",
	"艾玛",
	"洛斯里克王子",
	"洛里安王子",
	"埃尔德里奇",
	"尤姆",
	"古达",
	"波尔多",
	"沃尼尔",
	"拉普",
	"贺弗莱特",
	
	--合金装备
	"Liquid Snake",
	"Solid Snake",
	"Solidus Snake",
	"Vemon Snake",
	"Quiet",
	"Demon Snake",
	"The Boss",
	"Big Boss",
	"Naked Snake",
	"Strange Love",
	"左轮山猫",
	"液体山猫",
	"“骷髅脸”",
	"帕兹",
	"Radien",
	
	--使命召唤
	"肥皂",
	"普莱斯",
	"尤里",
	"“睡魔”",
	"“幽灵”",
	"“小强”",
	"马卡洛夫",
	"卡玛洛夫",
	"谢菲尔德",
	
	--黑岩射手
	"小鸟游黄泉",
	"黑衣麻陶",
	
	--恶魔城
	"德拉库拉",
	"阿鲁卡多",
	"拉尔夫",
	"西蒙",
	"加百列",
	"祖斯特",
	"马克西姆",
	"来须苍真",
	"有角幻也",
	"尤利乌斯",
	"里希特",
	"玛利亚",
	"夏洛特",
	"乔纳森",
	"阿鲁巴斯",
	"夏诺雅",
	"内森",
	"休",
	
	--up主
	"木糖",
	"鱼男",
	"灭月",
	"乌莎哈",
	"枯树",
}
for k,v in pairs(pignames) do 
	table.insert(STRINGS.PIGNAMES,v)
end 

local WORLDGEN_VERBS = {
	--"正在研发",
	--"争吵",
}

local WORLDGEN_NOUNS = {
	"异虫的巢穴",
	"亡者之夜",
	"感染深渊",
	"矿场疾风",
	"黑长直",
	"高坚果巨像",
	"拉克希尔仪式",
	"折越引擎",
	"吉姆·雷诺",
	"Sans",
	"完全形态",
	"伪装者",
	"实验体3C",
	"机械邪教徒",
	"FNNDP",
	"只有风暴才能最慢的击倒大树",
	"脓薪王",
	"合金装备",
	"和平行者",
	"BIG BOSS",
	"猪鲨和虎鲨",
	"爽上",
	"火中做自己",
	"罪魁祸首",
	"德拉库拉伯爵",
	"IGA的酒杯",
	"洋葱骑士",
	"卑鄙的外乡人",
	"无耻的不死人",
	"不可燃垃圾",
	"恶魔城",
	"命运的齿轮",
	"开发者的老婆",
	"艾希的本子",
	"艾希的妹汁",
	"艾希的胖次",
	"艾希的贫乳",
}

for k,v in pairs(WORLDGEN_VERBS) do 
	table.insert(STRINGS.UI.WORLDGEN.VERBS,v)
end 

for k,v in pairs(WORLDGEN_NOUNS) do 
	table.insert(STRINGS.UI.WORLDGEN.NOUNS,v.."...")
end 

---------------------------------------------------ENGLISH---------------------------------------------------------
elseif TUNING.ICEY_LANGUAGE == "english" then 


--[[STRINGS.ACTIONS.CASTAOE ={
	SAFULASI = "死吧,虫子!",
	AIUR_PROTECTER = "狂热冲锋",
	ALEX_BLADE = "淘汰之刃",
	GAUSS_GUN = "聚变打击",
	SHADOW_SAD = "亡者大军",
	WALL_FACER = "执剑人的决意",
	ICEY_BLADE = "Sortie",
	FIREBAT = "放置燃油",
	ARBITER = "神风冲击",
}--]]

STRINGS.ACTIONS.CASTAOE.ICEY_BLADE = "Sortie"
STRINGS.ACTIONS.CASTAOE.DRAGONSLAYER_TRIDENT = "ThunderStorm" 
STRINGS.ACTIONS.CASTAOE.PYROMANCY_FLAME = "Cast Pyromancy" 
STRINGS.ACTIONS.CASTAOE.AXE = "Warcry" 
STRINGS.ACTIONS.CASTAOE.GOLDENAXE = "Warcry" 
STRINGS.ACTIONS.CASTAOE.PICKAXE = "Galvanize" 
STRINGS.ACTIONS.CASTAOE.GOLDENPICKAXE = "Galvanize" 
STRINGS.ACTIONS.CASTAOE.HAMBAT = "Appetite"
STRINGS.ACTIONS.CASTAOE.NIGHTSTICK = "Perseverance"
STRINGS.ACTIONS.CASTAOE.SPEAR = "Charge"
STRINGS.ACTIONS.CASTAOE.SPEAR_WATHGRITHR = "Sky Lance"
STRINGS.ACTIONS.CASTAOE.SPIDER_HIGHER_SPEAR = "Mad King's Folly"
STRINGS.ACTIONS.CASTAOE.BEEGUARD = "FIM-92 Stinger"
STRINGS.ACTIONS.CASTAOE.KNIGHT_CUTLASS = "Cutlass Charge"
STRINGS.ACTIONS.CASTAOE.YHORM_BLADE = "Warcry"
STRINGS.ACTIONS.CASTAOE.YHORM_SHIELD = "Shield Bash"
STRINGS.ACTIONS.CASTAOE.ICEY_AXE_VICTORIAN = "Spin Slash"
STRINGS.ACTIONS.CASTAOE.LUCY = STRINGS.ACTIONS.CASTAOE.LAVAARENA_LUCY
STRINGS.ACTIONS.CASTAOE.SHADOWMIXTURES_BLADE = "Shadow Slash"
STRINGS.ACTIONS.CASTAOE.USELESS_CORKBAT = "Warcry"
STRINGS.ACTIONS.CASTAOE.USELESS_PEGLEG = "Warcry"
STRINGS.ACTIONS.CASTAOE.SHOVEL = "Dirt Throw"
STRINGS.ACTIONS.CASTAOE.GOLDENSHOVEL = "Dirt Throw"
STRINGS.ACTIONS.CASTAOE.HANDGUN_ALBERT = "E-Necrotoxin" 
STRINGS.ACTIONS.CASTAOE.HAMMER = "Earthen Wrath" 
STRINGS.ACTIONS.CASTAOE.CURSED_BLADE = "Atonement"

STRINGS.NAMES.ICEY = "Icey"
STRINGS.SKIN_NAMES.icey = "Icey"
STRINGS.SKIN_NAMES.icey_none = "Icey"
STRINGS.CHARACTER_TITLES.icey = "Icey"
STRINGS.CHARACTER_NAMES.icey = "Icey"
STRINGS.CHARACTER_DESCRIPTIONS.icey = "*Icey is my WAIFU\n*Gains energy from the Enemy.\n*Has luxuriant skills.\n"
STRINGS.CHARACTER_QUOTES.icey = "\"Some OTAKUs are researching my R18 books.\""
STRINGS.CHARACTERS.ICEY = require "speech_iceyv2"


STRINGS.NAMES.ICEY_SHADOW = "Shadow fighter"
---------------------------------
STRINGS.NAMES.SPIDER_HAOJIE = "Havoc"
STRINGS.NAMES.SPIDER_XIANFENG = "Vanguard"
STRINGS.NAMES.SPIDER_CHASER = "Stalker"
STRINGS.NAMES.SPIDER_BOMB = "Baneling"
STRINGS.NAMES.SPIDER_DRAGOON = "Dragoon"
STRINGS.NAMES.SPIDER_HIGHER = "Overmind"
STRINGS.NAMES.TADALIN_TOWER = "Void Pylon"
STRINGS.NAMES.SKY_WALKER = "Scourge Walker"
STRINGS.NAMES.JADE = "Jade Titan"
STRINGS.NAMES.ICEY_SANS = "True Shade Icey"
----------------------------------
STRINGS.NAMES.MERM_DEATH = "Seer"
STRINGS.NAMES.PIGHOUSE_BLOOD = "Infected Pighouse"
STRINGS.NAMES.MERMHOUSE_BLOOD = "Infected Mermhouse"
----------------------------------
STRINGS.NAMES.SPIDER_HIGHER_GOOD = "Overmind medal"
STRINGS.NAMES.SKY_WALKER_GOOD = "Scourge Walker medal"
---------------------------------------------------
STRINGS.NAMES.SPIDER_MONKEY = "Ender Ultralisk"
---------------------------------------------------
STRINGS.NAMES.PUGALISK = "Eater of the World"
STRINGS.NAMES.PUGALISK_BODY = "Eater of the World"
STRINGS.NAMES.PUGALISK_TAIL = "Eater of the World"
STRINGS.NAMES.PUGALISK_SEGMENT = "Eater of the World"
STRINGS.NAMES.SNAKE_BONE = "Huge Snake Bone"
STRINGS.NAMES.SNAKEBONESOUP = "Snake Bone Soup"
----------------------------------------------------
STRINGS.NAMES.MEAN_FLYTRAP = "Mean Flytrap"  
STRINGS.NAMES.MEAN_FLYTRAP_NAMES = {
	"Small Flytrap",
	"Middle Flytrap",
	"Big Flytrap",
}
STRINGS.NAMES.ADULT_FLYTRAP = "Adult Flytrap"
STRINGS.NAMES.VENUS_STALK = "Flytrap Stalk"   
STRINGS.NAMES.WALKINGSTICK = "Walking Stick"
STRINGS.RECIPE_DESC.WALKINGSTICK = "So fast !"
STRINGS.NAMES.NECTAR_POD = "Nectar pod"   
----------------------------------------------------
STRINGS.NAMES.TIME_DEMON = "Clock Tower Demon"
----------------------------------------------------
STRINGS.NAMES.ICEY_BOARRIOR = "Yhorm the Giant"
----------------------------------------------------
STRINGS.NAMES.TIGERSHARK_DUKE = "Tiger Shark the Duke"
STRINGS.NAMES.SHARKITTEN_PROJECTILE = "Sharkitten"
----------------------------------------------------
STRINGS.NAMES.BOSS_ELECARMET = "Moon Elecarmet" 
----------------------------------------------------
STRINGS.NAMES.MOON_GIAOUR = "FDA-7 Your-Father" 
STRINGS.NAMES.MOON_GIAOUR_MINION = "Giaour of Adeptus Mechanicus"
STRINGS.NAMES.MACHINE_BADGE = "Machine Soul Badge"
----------------------------------------------------
STRINGS.NAMES.ANCIENT_HERALD = "Ancient Herald"
STRINGS.NAMES.ANCIENT_ROBOTS = "Peace Walker Battle Group"
STRINGS.NAMES.METAL_HULK_MERGE = "Peace Walker"
STRINGS.CHARACTERS.GENERIC.DESCRIBE.METAL_HULK_MERGE = "Nucler is not the peace."
STRINGS.NAMES.IRON = "Iron"
----------------------------------------------------
STRINGS.NAMES.DEATH_LEGION = "Legion of Undead"
STRINGS.CHARACTERS.GENERIC.DESCRIBE.DEATH_LEGION = "Big body ball."
----------------------------------------------------
STRINGS.NAMES.DARK_ANTQUEEN = "Soul of Human Pustule"
STRINGS.CHARACTERS.GENERIC.DESCRIBE.DARK_ANTQUEEN = "You ugly guy!"
----------------------------------------------------
STRINGS.NAMES.WUGONG = "Magical Hat"
STRINGS.NAMES.WUGONG_BODY = "Magical Hat"
----------------------------------------------------
STRINGS.NAMES.POG = "Poge"
----------------------------------------------------
STRINGS.NAMES.ICEY_POD = "Wendy The Observer"
----------------------------------------------------
STRINGS.NAMES.SHADOW_SEED = "Shaddoll Core"
STRINGS.NAMES.GESTALT_REPORT =  "Gestalt Report"
----------------------------------------------------
STRINGS.NAMES.CHEST_MONSTER = "Avarice"
STRINGS.NAMES.CHEST_MONSTER_HAT = "Symbol of Avarice"

STRINGS.NAMES[string.upper("expostulations")] = "Expostulations" 
STRINGS.RECIPE_DESC[string.upper("expostulations")] = "Give some tips to others."

STRINGS.NAMES[string.upper("icey_resolver")] = "Resolve Engine" 
STRINGS.RECIPE_DESC[string.upper("icey_resolver")] = "Much more useful than the old one!"

STRINGS.NAMES[string.upper("cutcrystal")] = "Cut Crystal" 
STRINGS.RECIPE_DESC[string.upper("cutcrystal")] = "Shinying~"

STRINGS.NAMES[string.upper("icey_tower")] = "Pylon" 
STRINGS.RECIPE_DESC[string.upper("icey_tower")] = "Hmmm,so science~"

STRINGS.NAMES[string.upper("xuhua_line_item")] = "Virtual circuit" 
STRINGS.RECIPE_DESC[string.upper("xuhua_line_item")] = "Transport Emergy"

STRINGS.NAMES[string.upper("power_line_item")] = "Powerful circuit" 
STRINGS.RECIPE_DESC[string.upper("power_line_item")] = "Strengthen Emergy"

STRINGS.NAMES[string.upper("zerg_crusher")] = "Psionic Pulverizer" 
STRINGS.RECIPE_DESC[string.upper("zerg_crusher")] = "one head for head"

STRINGS.NAMES[string.upper("happy_target")] = "Happy Dummy Target" 
STRINGS.RECIPE_DESC[string.upper("happy_target")] = "STOP ANNOYING ME!!!!!"

STRINGS.NAMES[string.upper("super_icebox")] = "Super Ice Box" 
STRINGS.RECIPE_DESC[string.upper("super_icebox")] = "Freeze time!"

STRINGS.NAMES[string.upper("photon_cannon_item")] = "Photon Cannon" 
STRINGS.RECIPE_DESC[string.upper("photon_cannon_item")] = "Defence your base"

STRINGS.NAMES[string.upper("darkchest")] = "Ender Chest" 
STRINGS.RECIPE_DESC[string.upper("darkchest")] = "Contains the power of Ends"

STRINGS.NAMES[string.upper("icey_park_fence_tall")] = "Blast Resistant Wall(Tall)" 
STRINGS.RECIPE_DESC[string.upper("icey_park_fence_tall")] = "You can't pass there"

STRINGS.NAMES[string.upper("icey_park_fence_short")] = "Blast Resistant Wall(Short)" 
STRINGS.RECIPE_DESC[string.upper("icey_park_fence_short")] = "You can't pass there"

STRINGS.NAMES[string.upper("icey_park_fence_tall_item")] = "Blast Resistant Wall(Tall)" 
STRINGS.RECIPE_DESC[string.upper("icey_park_fence_tall_item")] = "You can't pass there"

STRINGS.NAMES[string.upper("icey_park_fence_short_item")] = "Blast Resistant Wall(Short)" 
STRINGS.RECIPE_DESC[string.upper("icey_park_fence_short_item")] = "You can't pass there"

STRINGS.NAMES[string.upper("icey_park_gate_item")] = "Blast Resistant Door" 
STRINGS.RECIPE_DESC[string.upper("icey_park_gate_item")] = "This way,please"

STRINGS.NAMES[string.upper("icey_tent")] = "Dormant cabin" 
STRINGS.RECIPE_DESC[string.upper("icey_tent")] = "Have a good sleep"

STRINGS.NAMES[string.upper("icey_carrook")] = "Reaver" 
STRINGS.RECIPE_DESC[string.upper("icey_carrook")] = "Gronnnnnnn!"

STRINGS.NAMES[string.upper("icey_battery")] = "Shield Battery" 
STRINGS.RECIPE_DESC[string.upper("icey_battery")] = "Shield is POWER!"

STRINGS.NAMES[string.upper("icey_battery2")] = "High Energy Battery" 
STRINGS.RECIPE_DESC[string.upper("icey_battery2")] = "Blzzzzzz..."

STRINGS.NAMES[string.upper("icey_battery3")] = "Melt Battery" 
STRINGS.RECIPE_DESC[string.upper("icey_battery3")] = "Full of spirit and energy"

STRINGS.NAMES[string.upper("icey_battery4")] = "NMS Battery" 
STRINGS.RECIPE_DESC[string.upper("icey_battery4")] = "Repair yourself!"

STRINGS.NAMES[string.upper("icey_armor")] = "Shield Generator" 
STRINGS.RECIPE_DESC[string.upper("icey_armor")] = "Use your Shield Battery automaticly!"

STRINGS.NAMES[string.upper("icey_armor2")] = "Holographic phantom projection"  
STRINGS.RECIPE_DESC[string.upper("icey_armor2")] = "Use shadowstriker like Waxwell !"


STRINGS.NAMES[string.upper("icey_magic")] = "Living Eessence"

STRINGS.NAMES[string.upper("icey_blade")] = "High Frequency Blade" 
STRINGS.RECIPE_DESC[string.upper("icey_blade")] = "As we all known,LightSword is a major use of flashlight"

STRINGS.NAMES[string.upper("icey_reaper")] = "Death Type-1000" 
STRINGS.RECIPE_DESC[string.upper("icey_reaper")] = "All reapers are Deathes"

STRINGS.NAMES[string.upper("worm_bait")] = "Worm Bait" 
STRINGS.RECIPE_DESC[string.upper("worm_bait")] = "Meet the Eater of World"

STRINGS.NAMES[string.upper("icey_ball")] = "Splitting Bomb" 
STRINGS.RECIPE_DESC[string.upper("icey_ball")] = "I'll destroy you!"

STRINGS.NAMES[string.upper("icey_fucker")] = "Aside" 
STRINGS.RECIPE_DESC[string.upper("icey_fucker")] = "...."

STRINGS.NAMES[string.upper("rock_crystal")] = "Crystal Rock" 

STRINGS.NAMES[string.upper("crystal_item")] = "Crystals"
STRINGS.RECIPE_DESC[string.upper("crystal_item")] = "Covered by Eessence"

STRINGS.NAMES[string.upper("icey_cookpot")] = "Science CookPot"
STRINGS.NAMES[string.upper("icey_cookpot_item")] = "Science CookPot"
STRINGS.RECIPE_DESC[string.upper("icey_cookpot")] = "It's blue,of course!"

STRINGS.NAMES[string.upper("icey_smelter")] = "Smelter"
STRINGS.RECIPE_DESC[string.upper("icey_smelter")] = "Turn Iron into Alloy."
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("icey_smelter")] = "Magnificent! Perhaps I can build a factory here as well."

STRINGS.NAMES[string.upper("storm_controlor")] = "Storm Controlor"
STRINGS.RECIPE_DESC[string.upper("storm_controlor")] = "Only a storm can fell a GreatWood"

STRINGS.NAMES[string.upper("dark_halberd")] = "Dark Halberd"
STRINGS.RECIPE_DESC[string.upper("dark_halberd")] = "Needn't to kill a Mimic."

STRINGS.NAMES[string.upper("halberd")] = "Halberd"
STRINGS.RECIPE_DESC[string.upper("halberd")] = "Pointy and hurty."
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("halberd")] = "Now I can't be caught off-guard."

STRINGS.NAMES[string.upper("icey_axe_victorian")] = "Sellsword Axe"
STRINGS.RECIPE_DESC[string.upper("icey_axe_victorian")] = ""
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("icey_axe_victorian")] = ""

STRINGS.NAMES[string.upper("gold_dust_repair")] = "Repair Gold Dust"
STRINGS.RECIPE_DESC[string.upper("gold_dust_repair")] = "To repair your weapons."

STRINGS.NAMES[string.upper("bloodmooneye")] = "Red-eyed jewelry"
STRINGS.RECIPE_DESC[string.upper("bloodmooneye")] = "Invade other players....as a Dark Spirit."
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("bloodmooneye")] = "Invade others and take their ember."

STRINGS.NAMES[string.upper("icey_cooking_spit")] = "Meat Rack"
STRINGS.RECIPE_DESC[string.upper("icey_cooking_spit")] = "Protected from rain,maybe."

STRINGS.NAMES[string.upper("gashat")] = "Particulate Purifier"
STRINGS.RECIPE_DESC[string.upper("gashat")] = "Keep nasty airborne particulates away!"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("gashat")] = "Sucks all the stink out."

STRINGS.NAMES[string.upper("gasmaskhat")] = "Gas Mask"
STRINGS.RECIPE_DESC[string.upper("gasmaskhat")] = "Makes everything smell like bird."
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("gasmaskhat")] = "Now I can breath anywhere."

STRINGS.NAMES[string.upper("pyromancy_flame")] = "Pyromancy Flame"
STRINGS.RECIPE_DESC[string.upper("pyromancy_flame")] = "Pyromancy Flame"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("pyromancy_flame")] = "Pyromancy Flame"

STRINGS.NAMES[string.upper("xuhua_line")] = "Virtual circuit" 

STRINGS.NAMES[string.upper("power_line")] = "Powerful circuit"

STRINGS.NAMES[string.upper("photon_cannon")] = "Photon Cannon" 

STRINGS.NAMES[string.upper("icey_park_gate")] = "Blast Resistant Door" 

STRINGS.NAMES[string.upper("icey_pokeball")] = "Poke Ball" 

STRINGS.NAMES[string.upper("metroworld_radiation_debuff")] = "Radiation Gas" 

STRINGS.NAMES[string.upper("clocktower_door")] = "Door of Clock Tower" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("clocktower_door")] = "Tick,Tick"

STRINGS.NAMES[string.upper("clocktower_spear_trap")] = "Spear Trap" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("clocktower_spear_trap")] = "It seems dangerous!"

STRINGS.NAMES[string.upper("clocktower_spear_trap_broken")] = "Broken Spear Trap" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("clocktower_spear_trap_broken")] = "Broken."

STRINGS.NAMES[string.upper("clocktower_spotlight")] = "Vigilant" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("clocktower_spotlight")] = "Don't look ta me,OK?"

STRINGS.NAMES[string.upper("clocktower_catapult")] = "Mangonel" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("clocktower_catapult")] = "Seems dangerous."

STRINGS.NAMES[string.upper("clocktower_fire_statue")] = "Fire Statue" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("clocktower_fire_statue")] = "It burns !"

STRINGS.NAMES[string.upper("clocktower_catapult_projectile")] = "Stone" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("clocktower_catapult_projectile")] = "Ahhhhhhhh!"

STRINGS.NAMES[string.upper("flup")] = "Cursed Frog" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("flup")] = "A creature which brings curse to human."

STRINGS.NAMES[string.upper("icey_dracula")] = "Judas the Shadow Lord" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("icey_dracula")] = ""

STRINGS.NAMES[string.upper("death_dragon")] = "Judas the True Ancestor" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("death_dragon")] = ""

STRINGS.NAMES[string.upper("dragonslayer_trident")] = "DragonSlayer Pitch-fork" 
STRINGS.RECIPE_DESC[string.upper("dragonslayer_trident")] = "Weapon used by Ancient gardener."
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("dragonslayer_trident")] = "It contains the power of lightning."

STRINGS.NAMES[string.upper("jingdoor_cloud")] = "筋Door♂云" 
STRINGS.RECIPE_DESC[string.upper("jingdoor_cloud")] = "新日暮里跤♂警的跤♂通工具"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("jingdoor_cloud")] = "带着哲学的气息。"

STRINGS.NAMES[string.upper("pyromancy_fireball")] = "FireBall" 
STRINGS.RECIPE_DESC[string.upper("pyromancy_fireball")] = "Thrown the fireball"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("pyromancy_fireball")] = "Thrown the fireball"

STRINGS.NAMES[string.upper("pyromancy_bursting_fireball")] = "Bursting Fireball" 
STRINGS.RECIPE_DESC[string.upper("pyromancy_bursting_fireball")] = "Thrown bursting fireball"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("pyromancy_bursting_fireball")] = "Thrown bursting fireball"

STRINGS.NAMES[string.upper("pyromancy_acid_surge")] = "Acid Surge" 
STRINGS.RECIPE_DESC[string.upper("pyromancy_acid_surge")] = "Throw acid surge"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("pyromancy_acid_surge")] = "Throw acid surge"

STRINGS.NAMES[string.upper("pyromancy_boulder_heave")] = "Boulder Heave" 
STRINGS.RECIPE_DESC[string.upper("pyromancy_boulder_heave")] = "Throw heavy stone"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("pyromancy_boulder_heave")] = "Throw heavy stone"

STRINGS.NAMES[string.upper("pyromancy_iron_flesh")] = "Iron Flesh" 
STRINGS.RECIPE_DESC[string.upper("pyromancy_iron_flesh")] = "Make your body a Unbreakable Iron."
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("pyromancy_iron_flesh")] = "Make your body a Unbreakable Iron."

STRINGS.NAMES[string.upper("pyromancy_rapport")] = "Rapport" 
STRINGS.RECIPE_DESC[string.upper("pyromancy_rapport")] = "Rapport a creature and make friends with it"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("pyromancy_rapport")] = "Rapport a creature and make friends with it"

STRINGS.NAMES[string.upper("pyromancy_floating_chaos")] = "Floating Chaos" 
STRINGS.RECIPE_DESC[string.upper("pyromancy_floating_chaos")] = "Summon a floating chaos,which can throw fireirc to enemies"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("pyromancy_floating_chaos")] = "Summon a floating chaos,which can throw fireirc to enemies"

STRINGS.NAMES[string.upper("pyromancy_firestorm")] = "Firestorm" 
STRINGS.RECIPE_DESC[string.upper("pyromancy_firestorm")] = "Summon Firestrom"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("pyromancy_firestorm")] = "Summon Firestrom"

STRINGS.NAMES[string.upper("icey_armor_vortexcloak")] = "Vortex Cloak" 
STRINGS.RECIPE_DESC[string.upper("icey_armor_vortexcloak")] = "Pockets, dimensions deep."
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("icey_armor_vortexcloak")] = "Ha ha! Take that nightmares!"

STRINGS.NAMES[string.upper("shadowmixtures_blade")] = "Nightmare's Scar" 
STRINGS.RECIPE_DESC[string.upper("shadowmixtures_blade")] = "The last flame kindled by the Shadow Mixtures."
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("shadowmixtures_blade")] = "is shaped like the claw marks of a Nightmare."

STRINGS.NAMES[string.upper("mutsuki_ai")] = "Mutsuki" 
STRINGS.RECIPE_DESC[string.upper("mutsuki_ai")] = "So cute."
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("mutsuki_ai")] = "So cute."

STRINGS.NAMES[string.upper("mutsuki_ai_builder")] = "Mutsuki" 
STRINGS.RECIPE_DESC[string.upper("mutsuki_ai_builder")] = "Befriend a cute Mutsuki."
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("mutsuki_ai_builder")] = "So cute."

STRINGS.NAMES[string.upper("spider_higher_spear")] = "Crucifix of the Overmind" 
STRINGS.RECIPE_DESC[string.upper("spider_higher_spear")] = "Seems scary."
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("spider_higher_spear")] = "Are you still alive?"

STRINGS.NAMES[string.upper("yhorm_blade")] = "Yhorm's Great Machete" 
STRINGS.RECIPE_DESC[string.upper("yhorm_blade")] = "Great machete wielded long ago by Yhorm the Giant."
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("yhorm_blade")] = "It's so heavy."

STRINGS.NAMES[string.upper("yhorm_shield")] = "Yhorm's Greatshield" 
STRINGS.RECIPE_DESC[string.upper("yhorm_shield")] = "Greatshield used long ago by Yhorm the Giant."
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("yhorm_shield")] = "A wall."

STRINGS.NAMES[string.upper("handgun_albert")] = "Albert-01R" 
STRINGS.RECIPE_DESC[string.upper("handgun_albert")] = "A gun which is designed against the B.O.W."
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("handgun_albert")] = "As well as Wesker well."

STRINGS.NAMES[string.upper("cursed_blade")] = "Cursed Blade" 
STRINGS.RECIPE_DESC[string.upper("cursed_blade")] = "Die when you are hitted."
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("cursed_blade")] = "Want something excited?"

STRINGS.NAMES[string.upper("hat_icey_chicken")] = "Chicken Hat"
STRINGS.RECIPE_DESC[string.upper("hat_icey_chicken")] = "You are not a freshman,do you ?"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("hat_icey_chicken")] = "I'm freshman."

STRINGS.NAMES[string.upper("armor_metalplate")] = "Tin Suit" 
STRINGS.RECIPE_DESC[string.upper("armor_metalplate")] = "Strong and sturdy."
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("armor_metalplate")] = "A lit heavy."

STRINGS.NAMES[string.upper("hat_metalplate")] = "Fancy Helmet" 
STRINGS.RECIPE_DESC[string.upper("hat_metalplate")] = "Strong, sturdy and classy."
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("hat_metalplate")] = "A little heavy,not realy."

STRINGS.NAMES[string.upper("knight_cutlass")] = "Cutlass Supreme" 
STRINGS.RECIPE_DESC[string.upper("knight_cutlass")] = "Fish were harmed in the making of this."
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("knight_cutlass")] = "Very sharp."

STRINGS.NAMES[string.upper("icey_living_artifact")] = "Living Artifact" 
STRINGS.RECIPE_DESC[string.upper("icey_living_artifact")] = "Merge with a living machine."
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("icey_living_artifact")] = "A war machine !"

STRINGS.NAMES[string.upper("infused_iron")] = "Infused Iron" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("infused_iron")] = "It's an infused iron."

STRINGS.NAMES[string.upper("icey_hunter_clothing1")] = "Hunter's clothing"
STRINGS.RECIPE_DESC[string.upper("icey_hunter_clothing1")] = "The standard clothing of new hunter."
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("icey_hunter_clothing1")] = "That's suitable,but a little tight."

STRINGS.NAMES[string.upper("icey_hunter_hat1")] = "Hunter's Hat"
STRINGS.RECIPE_DESC[string.upper("icey_hunter_hat1")] = "The standard hat of new hunter."
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("icey_hunter_hat1")] = "With angels."

STRINGS.NAMES[string.upper("hunter_blunderbuss")] = "Blunderbuss"
STRINGS.RECIPE_DESC[string.upper("hunter_blunderbuss")] = "Loud and messy, but gets the job done."
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("hunter_blunderbuss")] = "Loud and messy, but gets the job done."

STRINGS.NAMES[string.upper("hunter_trusty_shooter")] = "Pew-matic Horn"
STRINGS.RECIPE_DESC[string.upper("hunter_trusty_shooter")] = "A Pew-matic Horn."
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("hunter_trusty_shooter")] = "A Pew-matic Horn"


STRINGS.NAMES[string.upper("death_dragon_ball")] = "Death ball" 

STRINGS.NAMES.GREEN_PEEKHEN = "Peep Hen"
STRINGS.CHARACTERS.GENERIC.DESCRIBE.GREEN_PEEKHEN = "..."

STRINGS.NAMES[string.upper("icey_boss_cinder")] = "Cinders of a Lord" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("icey_boss_cinder")] = "The Cinders left by a Lord."

STRINGS.NAMES[string.upper("clocktower_key")] = "Key to Clocktower" 
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("clocktower_key")] = "To open the gate of Clocktower."

STRINGS.NAMES[string.upper("insanity_skull")] = "Crazy Skull" 
STRINGS.RECIPE_DESC[string.upper("insanity_skull")] = "A Crazy Skull."
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("insanity_skull")] = "A Crazy Skull."

STRINGS.NAMES[string.upper("useless_corkbat")] = "Large Club" 
STRINGS.RECIPE_DESC[string.upper("useless_corkbat")] = "Large wooden club."
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("useless_corkbat")] = "Large wooden club."

STRINGS.NAMES[string.upper("useless_pegleg")] = "Club" 
STRINGS.RECIPE_DESC[string.upper("useless_pegleg")] = "A simple wooden club."
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("useless_pegleg")] = "A simple wooden club."

STRINGS.NAMES[string.upper("aiur_securitycontract")] = "Security Contract" 
STRINGS.RECIPE_DESC[string.upper("aiur_securitycontract")] = "Hire your own army !"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("aiur_securitycontract")] = "It says I can hire my own town guard."

STRINGS.NAMES[string.upper("blood_blade_minion")] = "Blood Emissary" 
STRINGS.RECIPE_DESC[string.upper("blood_blade_minion")] = "A blade which is alive."
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("blood_blade_minion")] = "It's....alive ?"

STRINGS.NAMES[string.upper("blood_blade_minion_builder")] = "Blood Emissary" 
STRINGS.RECIPE_DESC[string.upper("blood_blade_minion_builder")] = "A blade which is alive."

STRINGS.NAMES[string.upper("icey_snake_eye")] = "Snake Eye" 
STRINGS.RECIPE_DESC[string.upper("icey_snake_eye")] = "A electronical patch used by Old Snake."
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("icey_snake_eye")] = "Not Like the Big Boss,I'm not blind."

STRINGS.NAMES[string.upper("insanity_skull_wilson")] = "Crazy Skull" 
STRINGS.RECIPE_DESC[string.upper("insanity_skull_wilson")] = "Crazy Skull"

STRINGS.NAMES[string.upper("icey_sikushui")] = "FASTSKIN LZR RACER" 
STRINGS.RECIPE_DESC[string.upper("icey_sikushui")] = "Si Ku Shui !"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("icey_sikushui")] = "Why should I wear this?"

STRINGS.NAMES[string.upper("flyhead_stone")] = "Artificial Rune" 
STRINGS.RECIPE_DESC[string.upper("flyhead_stone")] = "Fly head !"
STRINGS.CHARACTERS.GENERIC.DESCRIBE[string.upper("flyhead_stone")] = "Fly head !"

STRINGS.ANNOUNCE_ICEY_SUITUP = {
	DEFAULT = "Let's become the whole.",
	ICEY = "Non-support hardware...Detection success!",
	
	WAGSTAFF = "EUREKA!",
	WATHGRITHR = "For Valhalla!",
	WORMWOOD = "YAY!",
	WILBUR = "EEE EEE!",
	WX78 = "UPGRADE COMPLETE!!",
	WOODLEGS = "Yarrrrrg!",
	WOODIE = "Let's go, eh!",
	WOLFGANG = "WOLFGANG IS MIGHTY!",
	WILSON = "For Science!",
	WILLOW = "BURN IT ALL!",
	WILBA = "SOMETHING WILBA THIS WAY COMES!",
	WICKERBOTTOM = "I'd rather be reading!",
	WHEELER = "Adventure!",
	WEBBER = "This is cool!",
	WENDY = "I have become Death!",
	WARLY = "Eat your heart out!",
	WARBUCKS ="Huzzah!",
	WALANI = "Surf's up!",
	MAXWELL = "I AM SUPERIOR!",
	WAXWELL = "I AM SUPERIOR!",
}

end 


STRINGS.CITY_PIG_TALK_FOLLOWWILSON = {
    DEFAULT = {"WHEREFORE ART THINE BAD GUYS?", "ONCE MORE UNTO THE BREACH, UNPIG", "TAKE ARMS!", "KILL, KILL, KILL!", "CRY HAVOC!", "THE GAME IS AFOOTS!",},
    pigman_beautician = {"VISIT MINE SHOP FOR MEDICINES", "SELLEST ME THINE FEATHERS", "I HATH NEED OF FEATHERS"},
    pigman_mechanic = {"SELLEST ME THINE REFINED'D THINGS", "IN NEED OF FIXINGS?", "SELLEST ME THINE ROPE", "SELLEST ME THINE BOARDS"},
    pigman_mayor = {"YOU VOTETH?", "GIVE ME THINE GOLD FOR GOOD CAUSE", "ENDORSETH ME?",},
    pigman_collector = {"WANT'ST STRANGE THINGS?", "SELLEST ME THINE WEIRDITIES",},
    pigman_banker = {"ALL THAT GLITTERS WORTH OINCS", "HAST THOU JEWELS?", "I BUY THOU JEWELS"},
    pigman_florist = {"VISIT MINE SHOP FOR SEEDS", "HAST THOU PLOP TO SELL?", "HAST THOU PETALS?"},
    pigman_farmer = {"I HAST FARM", "SELLETH ME THINE GRASS", "STEALEST NAUGHT MINE STUFFS"},
    pigman_miner = {"I WILLST BUY THINE ROCKS", "HAST THOU ROCKS TO SELL?", "STEAL NOT FROM MINE MINE"},
    pigman_shopkeep = {"HAST THOU CLIPPINGS?", "GIVETH ME YON CLIPPINGS FROM YON HEDGE", "TRIMETH YON SHRUBS"},
    pigman_storeowner = {"HAS'T THOU CUTTINGS O' HEDGE?", "YON HEDGES NEED'TH TRIMMING",},
    pigman_erudite = {"NEED'ST THOU MAGICS? COME'ST TO MINE SHOP", "NEED'ST FUEL O' NIGHTMARES", "HAST THOU FUEL O' NIGHTMARES?"},
    pigman_hatmaker = {"NEED'ST HATS? VISIT YON HAT SHOP", "HAST THOU SILK?", "THY HEAD IS'T IN NEED O' COVERINGS"},
    pigman_professor = {"VISIT YON ACADEMY", "HA'ST THOU RELICS?", "HATH THOU STUFFS O' OLDEN'D TIMES?"},
    pigman_hunter = {"NEED'ST THOU WEAPONS? VISIT MINE SHOP", "HAS'T THOU TOOTH O' THE HOUND?", "GET THEE TO YON WEAPONS SHOP"},
}
    STRINGS.CITY_PIG_TALK_FIND_LIGHT = {
    DEFAULT = {"ONCE MORE UNTO THE LIGHT!", "WHEREFORE ART LIGHT?", "WHEREFORE IS'T SUN?", "FREINDS, PIGGIES, UNPIGGIES, LEND ME YOUR LIGHT"},
    pigman_beautician = {"I AM TOO MUCH I' THE DARK", "'TIS DARK!", "WHEREFORE ART THE LIGHT?"},
    pigman_mechanic = {"IS'T DARK! IS'T SCARY!", "THAT WAY MADNESS LIES!",},
    pigman_mayor = {"FRIENDS, PIGGIES, UNPIGMEN, LEND ME YOUR LIGHT!", "WHEREFORE ART MINE LIGHT?"},
    pigman_royalguard = {"TAKE NAUGHT THE LIGHT!", "TAKE ARMS!", "ONCE MORE UNTO THE LIGHT!"},
    pigman_collector = {"WHEREFORE ART THE LIGHT?!", "I NEED'ST LIGHT!",},
    pigman_banker = {"BRINGETH BACK THE LIGHT!", "THIS WAY DARKNESS LIES!"},
    pigman_florist = {"I AM TOO MUCH I' THE DARK!", "THIS WAY DARKNESS LIES!",},
    pigman_storeowner = {"ONCE MORE UNTO THE LIGHT!", "WHEREFORE ART THOU, LIGHT?"},
    pigman_farmer = {"WHEREFORE IS'T SUN?", "NEED'ST LIGHT!",},
    pigman_miner = {"FINDETH LIGHT!", "IS'T TOO MUCH SCARY"},
    pigman_shopkeep = {"PROTECTETH ME!", "TAKETH NAUGHT THE LIGHT!",},
    pigman_erudite = {"'TIS TOO MUCH DARKNESS!", "DARKNESS IS AFOOTS!"},
    pigman_hatmaker = {"THIS WAY DARKNESS LIES!", "I AM TOO MUCH I' THE DARK!"},
    pigman_professor = {"THIS WAY DARKNESS LIES!", "DARKNESS 'TIS NAUGHT GOOD!"},
    pigman_hunter = {"BRING'ST BACK THE LIGHT!", "IS'T DARK! IS'T SCARY!"},

}
    STRINGS.CITY_PIG_TALK_LOOKATWILSON_TRADER = {
    pigman_beautician = {"HAS'T THOU FEATHERS?", "VISIT YON SHOP IF THOU HAS'T BOO-BOOS", "SELLEST ME FEATHERS"},
    pigman_mechanic = {"WHATFORE IS YOU?", "HAS'T THOU BOARDS?", "HAS'T THOU ROPE?", "I BUY'ST THINGS REFINED'D"},
    pigman_mayor = {"WANTS THOU HOME IN HAMLET?", "WANTS THOU PIG O' SECURITY?", "VOTE FOR ME ONLY"},
    pigman_collector = {"HAS'T THOU ODD STUFFS?", "I CAN'ST BUY YOUR ODD STUFFS?", "I SELL'ST ODD STUFFS!"},
    pigman_banker = {"HAS'T THOU JEWELS?", "I BUY'ST JEWELS FROM THOU", "WILL-TH THOU SELLEST ME THINE JEWELS?"},
    pigman_florist = {"NEED'ST I STUFFS O' PLANTS", "HAS'T THOU PETALS?"},
    pigman_farmer = {"HAS'T THOU GRASS?", "DON'T TAKETH MINE FARM STUFFS", "CAN'ST THOU SELL ME THINE GRASS?"},
    pigman_miner = {"HAS'T THOU ROCKS?", "TAKETH NAUGHT MINE ROCKS", "I WILL GIVETH THEE OINCS FOR ROCKS"},
    pigman_shopkeep = {"HAS'T THOU CLIPPINGS?", "GET THEE TO A SHRUBBERY", "SELLEST ME THINE CLIPPINGS"},
    pigman_storeowner = {"HAS'T THOU CLIPPINGS?", "GET THEE TO A SHRUBBERY", "SELLEST ME THINE CLIPPINGS"},
    pigman_erudite = {"HAS'T THOU RELICS O' PIGGIES?", "SELLEST ME THINE PIGGY RELICS", "RELIC HATH MUCH WORTH"},
    pigman_hatmaker = {"HAS'T THOU HATS?", "ME HAVE HATS FOR UNPIG HEAD", "ME BUY FEATHERS FROM YOU"},
    pigman_professor = {"YOU HAVE RELICS?", "COME TO SHOP, ME HAVE RELICS", "I NEED OLD STUFFS"},
    pigman_hunter = {"YOU NEED SMASH STUFF?", "ME TAKE OINCS FOR WEAPON", "WEAPON MAKE YOU NOT SCARED"},

    DEFAULT = {"HOW NOW, UNPIG?","HAVE THEE %s?","WELL MET","GOOD FORTUNE, THOSE WHO HAVE %s","MY KINGDOM FOR SOME %s"},
}

   STRINGS.CITY_PIG_TALK_LOOKATROYALTY_TRADER = { 
    pigman_beautician = {"THOU HAST MOST BEAUTIFUL SNOUT", "YON MAJESTY", "TAKETH THEE A GIFT?"},
    pigman_mechanic = {"HOW NOW, YOUR MAJESTY", "AT-ETH YON SERVICE", "THOU MIGHTY SCEPTER'D BEING"},
    pigman_mayor = {"YON MAJESTY!", "ME HONORED'D!", "AT YON SERVICE"},
    pigman_royalguard = {"MINE SERVICE UNTO YOU", "YON MAJESTY", "LONG LIVE YON MAJESTY!"},
    pigman_royalguard_2 = {"THY HONOR US LOWLY PIGS", "YON MAJESTY", "THOU MIGHTY SCEPTER'D BEING"},
    pigman_collector = {"AT THINE SERVICE", "THOU DO-EST US AN HONOR", "TAKEST THOU A GIFT?"},
    pigman_banker = {"YON MAJESTY!", "THOU DO-EST ME AN HONOR", "I AM AT-ETH THY SERVICE",},
    pigman_florist = {"TAKEST THINE MINE FLOWERS?", "AT YON SERVICE", "ME HONORED'D AT THINE PRESENCE!"},
    pigman_farmer = {"THINE HUMBL'EST SERVENT", "YOUR MAJESTY", "AT THINE SERVICE"},
    pigman_miner = {"YOU HONOR ME", "TAKE'ST THOU A GIFT", "ACCEPT'ETH MINE GIFT!"},
    pigman_shopkeep = {"HOW NOW, YON MAJESTY?", "LIKETH THY MINE GIFT?", "TAKE'ST THEE A GIFT?",},
    pigman_storeowner = {"AT THINE SERVICE", "LIKEST THY MINE GIFT?", "THOU MIGHTY SCEPTER'D BEING"},
    pigman_erudite = {"ACCEPT MINE HUMBLEST GIFT", "LONG LIVE YON MAJESTY", "WILL'ST THOU ACCEPT A GIFT?"},
    pigman_hatmaker = {"YON MAJESTY", "AT THINE SERVICE", "THOU MIGHTY SCEPTER'D BEING"},
    pigman_professor = {"ACCEPT'ST THOU A GIFT?", "THY HONOR ME?", "I AM THOU MOST HUMBLEST PIGGY SERVANT"},
    pigman_hunter = {"THY HONOR US LOWLY PIGS", "YON MAJESTY", "AT YON SERVICE, YON MAJESTY"},

    DEFAULT = {"GREETINGS YOUR HIGHNESS","NEED'ST THOU %s?","GOOD DAY","NEED'ST %s. HAV'TH THOU THAT?","I WANT'ST %s. WILL BUY", "YOUR MAJESTY"},
}

    STRINGS.CITY_PIG_TALK_LOOKATWILSON = {
    DEFAULT = {"WHAT HO, UNPIG", "HOW NOW, GOOD UNPIG", "WHAT NEWS?", "WELL MET"},
    ROYALTY = {"LONG LIVE THE QUEEN!","HAIL, GOOD NOBLE PIG!", "MINE LIEGE", "HAIL TO YOU, GOOD GENTLEPIGGY",}, 
}

    STRINGS.CITY_PIG_TALK_APORKALYPSE_SOON = { 
        DEFAULT = { "THE APORKALYPSE APPROACH-ETH", "WOE, DESTRUCTION, RUIN, AND DECAY!", "DOOMSDAY IS NEAR!", "SOMETHING WICKED THIS WAY COMES", "PORKTENTOUS FIGURES!", "FEAR AND PORKTENT!"},
    }

    STRINGS.CITY_TALK_ANNOUNCE_APORKALYPSE = {
        DEFAULT = { "THE APORKALYPSE COMETH!", "THE CRACK OF DOOM!", "DEATH HAVE ITS DAY!", "THEY HATH RETURNED!", "THEY KILL US FOR THEIR SPORT", "A PLAGUE ON ALL OUR HOUSES!", "BE ALL AND END ALL!"},
}

    STRINGS.CITY_PIG_TALK_RUNAWAY_WILSON = {
    DEFAULT = {"THOUST ART NOT KIND!", "STAYEST THOU AWAY!", "GET-ETH THEE AWAY!", "ADIEU YOU!"},
    pigman_beautician = {"GOODNESS!", "EEP! SNORT!", "LEAVETH THOU!!", "THOU HAST THE SMELL OF UNPIG"},
    pigman_mechanic = {"I TRUST THEE NOT!", "STAY'ST THOU BACK", "GET THEE GONE, UNPIG"},
    pigman_mayor = {"GET THEE GONE!", "GO-EST THOU AWAY!", "GUARDS! PROTECT-ETH ME!",},
    pigman_shopkeep = {"TOO CLOSE! THOU TOO CLOSE!", "BACK-ETH THEE OFF!", "GET THEE GONE!"},
    pigman_royalguard = {"STAYEST THOU AWAY!", "GET THEE GONE!", "THOU HAST THE STENCH OF UNPIG!"},
    pigman_royalguard_2 = {"GO'ST THOU AWAY", "BACK-ETH THEE OFF!", "TALK'ST THOU TO ME?"},
    pigman_storeowner = {"THINE CLOSENESS DOST OFFENDETH ME", "TOO CLOSE!", "BACK'ST THOU UP!"},
    pigman_farmer = {"WHATFORE THOU WANT'ETH WITH ME?", "GET'ST BACK!", "BACK-ETH OFF!"},
    pigman_miner = {"LEAVE'ST ME BE!", "SHOO!", "STAYEST THOU AWAY!"},
    pigman_collector = {"TAKETH NAUGHT MINE STUFFS!", "GET THEE GONE", "GO'EST THOU AWAY!"},
    pigman_banker = {"THOU HAST THE SMELL OF UNPIG", "TAKE-ETH OFF!", "GET THEE GONE!"},
    pigman_florist = {"ADIEU!", "THOU ART TOO CLOSE!", "STAND-EST NAUGHT SO CLOSE TO ME!"},
    pigman_erudite = {"LEAVETH ME BE!", "WHYFORE YOU BUG-ETH ME?", "BACK-EST THOU OFF!"},
    pigman_hatmaker = {"GO'ST THOU AWAY!", "WANT THOU TO STEAL'EST MINE STUFFS?", "GET THEE GONE!", "I TRUSTETH THEE NAUGHT!"},
    pigman_professor = {"LEAVETH ME BE!", "GO-EST THOU AWAY", "WHYFORE YOU SO CLOSE?"},
    pigman_hunter = {"BACK-ETH AWAY!", "CROWD-EST ME NAUGHT!", "GET-ETH THEE AWAY!"},

}
    STRINGS.CITY_PIG_TALK_FIGHT = {
    DEFAULT = {"AVAST!", "TO THINE DEATH!", "RAAAWR!", "I BITE MY HOOF AT THEE!"},
    pigman_beautician = {"DIE-EST NOW!", "ME KILL THEE", "TO THY DEATH!"},
    pigman_mechanic = {"I HAMMER THEE!", "HIT, HAMMER! HIT!", "I DESTROY THEE!"},
    pigman_mayor = {"KILL!", "DIE THOU!", "ME MOST VEXED!", "DESTROY!"},
    pigman_shopkeep = {"I GET THEE!", "THOU NOT NICE!", "I GET THEE!"},
    pigman_storeowner = {"GETEST THEE OUT!", "THY NOT BE WELCOME!", "GET OFF MINE PROPERTY!"},
    pigman_farmer = {"GET THEE BACK!!", "I BURY THINE!", "I GET THEE!"},
    pigman_miner = {"I CRUSHETH YOU!", "THY DYING!", "THOU DONE IT NOW!"},
    pigman_collector = {"THOU ART DONE FOR!", "GET THINE HENCE!", "THY BAD UNPIG!"},
    pigman_banker = {"THY NOT MINE FRIEND!", "I CHOP-ETH THEE!", "DIE! DIE!"},
    pigman_florist = {"THOU ART THE WORST!", "GO AWAY-EST!", "THOU ART A VILLAIN!"},
    pigman_erudite = {"VILLAIN UNPIG! BAD!", "THINE ART THE BADEST!", "AWAY FROM ME!"},
    pigman_hatmaker = {"YOU BE UNDONE!", "I SAY THEE OUT!!", "YOU MOST VEXING!"},
    pigman_professor = {"BE DONE-EST WITH THEE!", "WILL NOT YOU GO?!!", "OUT DAMNED UNPIG!"},
    pigman_hunter = {"I ATTACK-ETH THEE!", "GET THOU AWAY FROM HERE!", "YOU MOST NOT WELCOME!"},
}

    STRINGS.CITY_PIG_TALK_DAILYGIFT = {
    DEFAULT = {"WARE FOR ART THOU", "THY HUMBL'ST PIGGY SERVANT", "REMEMBER'ST ME", "GIFT FOR'ST YOU", "WITH MINE HUMBLEST GRATITUDE","TAKEST THEE MINE GIFT, YOUR MAJESTY"}
}

    STRINGS.CITY_PIG_TALK_POOPTIP = {
    DEFAULT = {"OUT, DAMNED PLOP", "HUMBLE THANKS, KIND UNPIG", "MY THANKS"},
    pigman_beautician = {"TAKEST THEE THY COIN", "HERE BE YOUR OUTRAGEOUS FORTUNE", "THANK YE, UNPIG"},
    pigman_mechanic = {"OUT, DAMNED PLOP!", "FAIR PRICE, FAIR UNPIG?", "LET-EST ME PAY FOR THYST HELP"},
    pigman_mayor = {"IS THAT PLOP I SEE BEFORE THEE?", "HONEST UNPIG", "KINDEST UNPIG"},
    pigman_shopkeep = {"UNPIG IS AN HONORABLE UNPIG", "I GIVE EVERY PLOP MINE OINC", "FAIR TERMS"},
    pigman_storeowner = {"FOR THY PLOP PICKING", "MOST EXCELLENT PICKING", "HONORABLE UNPIG"},
    pigman_farmer = {"FOR THY HONEST MANURING", "TAKEST THOU WHAT THOU'ST OWED", "HONEST OINC FOR UNPIG"},
    pigman_miner = {"'TIS FOUL", "IS A JUST PAYMENT?", "'TIS WORTHY DEED"},
    pigman_collector = {"HERE BE OINC FOR THOUST MANURE", "ALAS POOR UNPIG", "FORTUNE SMILES ONST THEE"},
    pigman_banker = {"AN OINC FOR THY TROUBLE", "A TAX FOR THY PLOP PICKING", "MANY THANKS"},
    pigman_florist = {"WE WILLST PAY FOR THY PLOPPING", "IS POO, UNPIG?", "ME PAYEST FOR PLOP PICKING"},
    pigman_erudite = {"FAIR PRICE FOR FOUL DEED", "THY PLOP-PICKING IS MOST PROFESSIONALS", "FOR PLOP OF PIGGY MAN"},
    pigman_hatmaker = {"I GIVE THE UNPIG ITS DUE", "WHAT PIECE OF WORK IS UNPIG", "YOU'ST PAID FOR PLOP OF PIG"},
    pigman_professor = {"THOUST MILK OF UNPIG KINDNESS", "SUCH STUFF AS PLOP IS MADE ON", "FOR THY TROUBLES"},
    pigman_hunter = {"PLOP AND CIRCUMSTANCE", "FOR POUND OF PLOP", "HAVE OINCS THRUST UPON THEE"}, 
}

    STRINGS.CITY_PIG_TALK_ROYAL_POOPTIP = {
    DEFAULT = {"OUT, DAMNED PLOP", "HUMBLE THANKS, YOUR HIGHNESS",},
    pigman_beautician = {"ACCEPTEST THEE MINE COIN?", "HERE BE YOUR OUTRAGEOUS FORTUNE", "HUMBLE THANKS, YOUR MAJESTY"},
    pigman_mechanic = {"OUT, DAMNED PLOP!", "THOU ART THE FINEST OF PLOP PICKERS!", "THOU DO US HONOR"},
    pigman_mayor = {"WE ARE NOT WORTHY OF THINE PLOP", "'TIS A KIND THING YOU DO", "ACCEPTEST THEE MINE COIN?"},
    pigman_shopkeep = {"WE ARE NOT WORTHY OF THINE SERVICE", "I GIVE EVERY PLOP MY OINC", "HUMBLE THANKS, YOUR MAJESTY"},
    pigman_storeowner = {"FOR THY FINE PLOP PICKING", "MOST EXCELLENT PICKING", "HONORABLE PLOP PICKER!"},
    pigman_farmer = {"FOR THY HONEST MANURING", "FOR THY ROYAL PLOP PICKING", "THOU DO US'T HONOR"},
    pigman_miner = {"OUT, DAMNED PLOP!", "FOR THY ROYAL PLOP PICKING", "HUMBLEST OF THANKS, YOUR MAJESTY"},
    pigman_collector = {"HERE BE OINC FOR THOUST ROYAL MANURE", "FOR THY ROYAL PLOP PICKING", "THOU ART THE FINEST OF PLOP PICKERS"},
    pigman_banker = {"AN OINC FOR THY TROUBLE", "'TIS A KIND THING YOU DO", "THOU DO US HONOR"},
    pigman_florist = {"THOU ART THE FINEST OF PLOP PICKERS!", "HUMBLE THANKS, YOUR MAJESTY", "ACCEPTEST THEE MINE COIN?"},
    pigman_erudite = {"FAIR PRICE FOR FOUL DEED", "THY PLOP-PICKING IS MOST EXCELLENTEST", "THOU DO'ST US HONOR"},
    pigman_hatmaker = {"ACCEPTEST THEE MINE COIN?", "OUT, DAMNED PLOP", "THOU ARE THE MOST EXCELLENTEST OF PLOP PICKERS"},
    pigman_professor = {"THOUST MILK OF UNPIG KINDNESS", "SUCH STUFF AS PLOP IS MADE ON", "FOR THY TROUBLES"},
    pigman_hunter = {"PLOP AND CIRCUMSTANCE", "FOR POUND OF PLOP", "MOST EXCELLENT PICKINGS"}, 
}

STRINGS.CITY_PIG_TALK_PAYTAX = {
    DEFAULT = {"TAKETH THINE TAX","NEED'ST THOU MINE TAX", "TAKEST THOU MINE TAX", "MANY THANKS UNTO YOU, UNPIG MAYOR"},
}


STRINGS.CITY_PIG_TALK_PROTECT = {
    DEFAULT = {"MOST FOUL! MOST FOUL!", "TAKE ARMS! TAKE ARMS!", "THOU WRETCH", "THOU COWARD!"},
}
STRINGS.CITY_PIG_TALK_EXTINGUISH = {
    DEFAULT = {"OUT OUT, BRIEF FIRES!", "FIRE IS'T BAD!", "YON FIRE BE OUT!"},
}
STRINGS.CITY_PIG_TALK_STAYOUT = {
    DEFAULT = {"MOST UNWELCOME", "AWAY, YOU CUR!", "BE'ST THEE GONE!", "FIE ON THEE, VILLAIN!"},
}
    STRINGS.CITY_PIG_TALK_FLEE = {
    DEFAULT = {"ROGUE!", "PEASANT SLAVE!", "O HORRIBLE!", "O STRANGE"},
    pigman_beautician = {"O HORRIBLE!", "O STRANGE!", "MOST HORRIBLE"},
    pigman_mechanic = {"MOST NOTABLE COWARD", "FLEE!", "AVAST!"},
    pigman_mayor = {"THAT WAY MADNESS LIES!", "NO MORE OF THAT!", "CRY MERCY"},
    pigman_royalguard = {"KILL, KILL, KILL, KILL", "FARE THEE WELL!", "ONCE MORE UNTO THE BREACH!"},
    pigman_royalguard_2 = {"TO ARMS!", "I DASH YOU TO PIECES!", "THE GAME IS UP!"},
    pigman_shopkeep = {"FOUL!", "LESS THAN FAIR!", "WOE IS ME!"},
    pigman_storeowner = {"PIGS BE UP IN ARMS", "'TIS A WILD PIG CHASE", "WHAT A PIECE OF WORK!"},
    pigman_farmer = {"THOU LILY-LIVERED UNPIG!", "LIE LOW!", "O MISERY!"},
    pigman_miner = {"IF YOU PRICK US, WE BLEED!", "'TIS RUIN'D!", "A POX ON'T!"},
    pigman_collector = {"I AM TOO MUCH ON THE RUN!", "FLEE, FIE, FO, FUM!", "SOMETHING ROTTEN!"},
    pigman_banker = {"ADIEU, ADIEU!", "REMEMBER ME!", "FIE ON THEE!"},
    pigman_florist = {"S'WOUNDS!", "ZOUNDS!", "COWARD!"},
    pigman_erudite = {"A PLAGUE ON YOUR HOUSES!", "THOU'RT MAD!", "AWAY FROM ME!"},
    pigman_hatmaker = {"RUINOUS!", "HARK! NO MORE!", "CUR!"},
    pigman_professor = {"MOST FOUL!", "NOT FAIR!", "LEAVE ME!"},
    pigman_hunter = {"TAKETH THEM AWAY!", "FIE ON THEE!", "TOIL AND TROUBLE!"},
}
    STRINGS.CITY_PIG_TALK_RUN_FROM_SPIDER = {
    DEFAULT = {"SPIDER IS'T BAD!", "LIKETH NAUGHT YON SPIDER!", "GO'ST THOU AWAY!"},
    pigman_beautician = {"O MONSTROUS!", "O HORRIBLE!", "MOST VEXING!"},
    pigman_mayor = {"GET-ETH THEE AWAY!", "ALAS!! ALACK!", "I HATE-ETH THEE, SPIDERS!"},
    pigman_mechanic = {"O MONSTROUS THING!", "WRECK-ETH NAUGHT OUR STUFFS", "GO'ST THOU AWAY!"},
    pigman_royalguard = {"PROTECT-ETH THE CITY!", "SPIDERS NAUGHT WELCOME!", "GET THEE GONE!"},
    pigman_royalguard_2 = {"PROTECT-ETH THE CITY", "SQUASH-ETH THE SPIDERS!", "GET THEE GONE!"},
    pigman_shopkeep = {"PROTECT-ETH MINE STORE!", "GET-ETH THEE GONE!", "GO-EST AWAY!"},
    pigman_storeowner = {"EEK! SNORT! AVAST!", "MOST VEXING!", "O HORRIBLE!"},
    pigman_farmer = {"O MONSTROUS THING!", "SPIDERS NAUGHT WELCOME!", "MOST VEXING!"},
    pigman_miner = {"GO-ETH THOU AWAY!", "GET THEE GONE!", "THOU AREN'ST WELCOME HENCE"},
    pigman_collector = {"GET THEE GONE!", "THOU ART BAD GUY!!", "MOST VEXING!"},
    pigman_banker = {"FOUL! FOUL! MOST FOUL!", "MONSTROUS THING!", "GET THEE GONE!!"},
    pigman_florist = {"SPIDER IS'T BAD!", "O MONSTROUS!!", "O HORROR!"},
    pigman_erudite = {"GET THEE GONE!", "AWAY! AWAY!!", "EEK!"},
    pigman_hatmaker = {"CREEP NAUGHT HENCH!", "GO'ST THOU AWAY!", "GUARD!"},
    pigman_professor = {"GET-ETH THEE AWAY!", "ALAS! ALACK!", "GET THEE GONE!"},
    pigman_hunter = {"I HATE-ETH THEE!", "LIKE-ETH THEE NAUGHT!", "EEK! SNORT! AVAST!!"},

}
    STRINGS.CITY_PIG_TALK_HELP_CHOP_WOOD = {
    DEFAULT = {"TAKETH THAT TREE!", "I SMASH-ETH YON TREE!", "I PUNCH-ETH TREE!"},
    pigman_beautician = {"I SHALL CHOP-ETH!", "YON TREE NEEDS CHOPPIN'!",},
    pigman_mechanic = {"SHALL I COMPARE TREE TO SUMMER'S DAY?", "WORK-ETH, WORK-ETH, WORK-ETH",},
    pigman_mayor = {"WHAT PIECE OF WORK IS CHOPPING", "FALL, TREE!",},
    pigman_royalguard = {"I TAKETH DOWN YON TREE", "I CHOPTING", "I GOOD FRIEND, I CHOPT TREE"},
    pigman_royalguard_2 = {"CHOP'T CHOP'T", "I AXE THEE!", "FAIR TREE SHALT FALL!"},
    pigman_shopkeep = {"'TIS HARD WORK", "I SMASH-ETH", "I SMASH THEE"},
    pigman_storeowner = {"SMASH-ETH! SMASH-ETH", "DOTH HARD WORK!", "HAVE AT THEE TREE!"},
    pigman_farmer = {"THIS TREE DOTH CHOP'T", "I TOIL", "CHOP'T CHOP'T!"},
    pigman_miner = {"YON TREE IS'T CHOP'T", "'TIS EASIER THAN MINING", "YON TREE IS'T DONE FOR!"},
    pigman_collector = {"'TIS HARD WORK", "WHAT A PIECE OF WORK IS CHOPPING",},
    pigman_banker = {"MINE HOOVES GET-ETH DIRTY", "FALL, TREE!",},
    pigman_florist = {"CHOP'T, CHOP'T", "SMASHINGS!", "TOIL, TOIL"},
    pigman_erudite = {"I HELP-ETH", "FALL, TREE!", "I AXE THEE!"},
    pigman_hatmaker = {"YON TREE SHALL FALL!", "THUS FALL-ETH THY TREE",},
    pigman_professor = {"WITH MINE LAST BREATH I CHOP AT THEE!", "CHOP'T CHOP'T", "HAVE AT THEE TREE"},
    pigman_hunter = {"THUS FALL THE TREE", "I BID THEE FALL!", "I WIN!"},
}
    STRINGS.CITY_PIG_TALK_ATTEMPT_TRADE = {
    DEFAULT = {"WHAT HAS'T THEE, UNPIG?", "NEED'ST THEE WARES?"},
    pigman_beautician = {"THEE HAS'T FEATHERS?", "THEE HAS'T BIRDY FEATHERS?", "HAS'T THEE PRETTY FEATHERS?"},
    pigman_mechanic = {"THINE NEED'ST REPAIRS?", "BRING FORTH YON REPAIRS", "THEE HAS'T REFINED GOODS?"},
    pigman_mayor = {"NEED'ST THOU A HOME?", "DEEDS BE IN YON CITY HALL", "THY WANT'ST HOME IN HAMLET?"},
    pigman_shopkeep = {"GET THEE TO SOME SHRUBBERY!", "HAS'T THEE CLIPPINGS?", "HAS'T THEE SHRUB STUFFS?"},
    pigman_storeowner = {"GET THEE TO SOME SHRUBBERY!", "HAS'T THEE CLIPPINGS?", "HAS'T THEE SHRUB STUFFS?"},
    pigman_farmer = {"HAS'T THOU GRASS?", "SELL'ST ME THINE GRASS PARTS", "ME WANT'ST GRASS STUFFS"},
    pigman_miner = {"HAS'T THOU A ROCK?", "ME PAY'ST FOR ROCKS", "I GIVETH OINC FOR THY ROCK"},
    pigman_collector = {"HAS'T THOU STRANGE THINGS?", "I BUYEST THING O' STRANGENESS", "SELLEST ME THINE WANT WEIRD STUFF?"},
    pigman_banker = {"HAST THOU JEWELS?", "I WILL'ST BUYEST JEWELS FROM THEE", "I PAYST OINCS FOR JEWELS"},
    pigman_florist = {"HAS'T THOU PLOP?", "PETALS FOR MINE SHOP?", "ME LIKE'ST PRETTY FLOWER", "ME LIKE'ST SMELLY PLOP"},
    pigman_erudite = {"HAS'T THOU DARK MAGICS?", "HAS'T THOU FUEL O' NIGHTMARE?", "SELL'ST ME THY DARK MAGICS STUFFS"},
    pigman_hatmaker = {"HAST THOU SILK?", "I NEED'TH SILK", "SELLEST ME THINE SILK"},
    pigman_professor = {"RELICS?", "HAS'T THOU RELICS?", "PAY'ST THOU OINCS FOR RELICS"},
    pigman_hunter = {"HAS'T THOU HOUNDS TOOTH?", "SELLETH THEE HOUNDS TOOTH?", "I BUY'ST TOOTH O' THE HOUNDS"},                               

}
    STRINGS.CITY_PIG_TALK_PANIC = {
    DEFAULT = {"O HORRIBLE", "AAAAAAAAAH!!", "AVAST!", "NO LIKETH", "HURLEYBURLY!"},
    pigman_beautician = {"EVIL 'TIS AFOOT", "SOMETHING WICKED THIS WAY COMES!", "O HORRORS"},
    pigman_mechanic = {"ADIEU!", "I AM TOO MUCH IN THE FEAR", "MOST FOUL! MOST FOUL!"},
    pigman_mayor = {"MOST HORRIBLE", "O' CURSED SPITE", "THIS BE MADNESS"},
    pigman_royalguard = {"ONCE MORE INTO THE BREACH!", "GUARDS PROTECT THEE!", "AVAST! AVAIL!"},
    pigman_royalguard_2 = {"ONCE MORE INTO THE BREACH!", "GUARDS PROTECT THEE!", "AVAST! AVAIL!"},
    pigman_shopkeep = {"O HORROR! O HORROR! O HORROR!", "O SLINGS AND ARROWS!", "O OUTRAGEOUS FORTUNE!"},
    pigman_storeowner = {"HEIGH, MY HEARTS!", "A PLAGUE UPON IT!", "ALL LOST!"},
    pigman_farmer = {"ALL IS'T LOST!", "ADIEU! ADIEU!", "I EXEUNT!"},
    pigman_miner = {"I GET ME GONE!", "O, WOE THE DAY!", "'TIS THE END!"},
    pigman_collector = {"BAD THINGS ARE NIGH!", "ME PROTEST SO MUCH!", "I WANT'ST NOT TO DIE!"},
    pigman_banker = {"O MONSTROUS!", "O STRANGE!", "HELP'TH ME!"},
    pigman_florist = {"OUT! OUT!", "TAKE ARMS!", "SOMETHING WICKED THIS WAY COMES!"}, 
    pigman_erudite = {"O CURSE'D SPITE!", "GO AWAY'TH!", "MOST UNKIND!"},
    pigman_hatmaker = {"OUT! OUT!", "SAVETH ME!", "MOST HORRIBLE! MOST STRANGE!"},
    pigman_professor = {"CRY YOU MERCY!", "MOST HORRIBLE! MOST STRANGE!", "IT COMETH FOR US!"},
    pigman_hunter = {"SOUND AND FURY!", "HOWL, HOWL, HOWL, HOWL!", "ALL IS'T LOST!"},
}
    STRINGS.CITY_PIG_TALK_PANICFIRE = {
    DEFAULT = {"IT BURN-ETH!", "FIRE BURN AND PIGGY BUBBLES", "FIGHT FIRE WITH WATER!", "SOMETHING FIREY THIS WAY COMES!", "FIRE FIRE FIRE"},
}
    STRINGS.CITY_PIG_TALK_FIND_MEAT = {
    DEFAULT = {"IS'T MEAT!", "'TIS MEAT I SEE BEFORE ME?!", "I EAT'TH!", "FOOD TIME IS NIGH!"},
    pigman_beautician = {"MEAT BE THE FOOD OF LOVE", "I HATH STOMACH FOR IT", "VERILY I EAT",},
    pigman_mechanic = {"THIS MEAT I SEE BEFORE ME?", "WELL SERVED", "SOMETHING YUMMY THIS WAY COMES"},
    pigman_mayor = {"'TIS A DISH FIT FOR PIGS", "GIVE'ST MAYOR MINE DUE"},
    pigman_royalguard = {"EAT OR NOT TO EAT, THERE BE NO QUESTION", "MEATS FOR'ST PIGGY"},
    pigman_royalguard_2 = {"TO MINE OWN BELLY BE TRUE!", "'TIS MEAT! 'TIS FOOD!", "HUZZA!"},
    pigman_shopkeep = {"TO MINE OWN BELLY BE TRUE", "ALLS WELL THAT ENDS IN BELLY",},
    pigman_storeowner = {"'TIS EATS!", "I EATS!", "SOMETHING YUMMY THIS WAY COMES"},
    pigman_farmer = {"MMMM...MEAT MOST FOUL!", "FOR MINE FAT PAUNCH!", "BELLY BURN, AND MEAT BUBBLE"},
    pigman_miner = {"MEAT BE THE SOUL OF FOOD", "WOULD IT WERE IN MY BELLY", "MARRY THOUGH I LOVETH FOODS!"},
    pigman_collector = {"'TIS SLOP! 'TIS FOOD!", "WHENCE COME THIS FOOD?", "PRITHEE, LET ME EAT!"},
    pigman_banker = {"THE FOOD'S THE THING", "ZOUNDS, FOR MINE FAT PAUNCH!", "WHENCE COMES THIS FOOD?!"},
    pigman_florist = {"MARRY, 'TIS MEAT!", "ALACK THE DAY,'TIS MEAT!"},
    pigman_erudite = {"AY, THERE'S THE GRUB!", "INTO THE BOWELS OF MY BELLY", "MEAT GOETH IN MINE BELLY!"},
    pigman_hatmaker = {"MINE BELLY NOT PROTEST TOO MUCH", "SIRRAH! MY FOOD!", "NOT SALAD DAYS!"},
    pigman_professor = {"MMM... MEAT THRUST UPON ME", "WHYFORE ART THERE GROUND MEAT?"},
    pigman_hunter = {"A POUND OF FLESH!", "'TIS GOOD, 'TIS GOOD INDEED!", "MUCH ADO ABOUT MEAT!"},
}
    STRINGS.CITY_PIG_TALK_FIND_MONEY = {    
    DEFAULT = {"'TIS SHINY THING!", "ALL THAT GLITTERS IS GOLD!", "YEA, THO I HAST SHINY THING!", "I GO FORTH AND BUY'ST THINGS"},
    pigman_beautician = {"OINC HAST PRETTYNESS!", "'TIS PRETTIES", "OINC HATH WORTH"},
    pigman_mechanic = {"LIKEST OINCS!", "PUT'ST OINC IN MINE POCKET", "CAN'ST ME BUY'ST STUFFS"},
    pigman_mayor = {"MINE-ETH!", "IS'T BUY'ST VOTES", "GIVE MAYOR MINE DUE"},
    pigman_royalguard = {"OUTRAGEOUS FORTUNE!", "ME KEEP'TH", "PUT MONEY IN MINE PURSE!"},
    pigman_royalguard_2 = {"MINE OINC BE TRUE!", "FORTUNE SMILE 'PON ME"},
    pigman_shopkeep = {"IT SUFFICETH", "ME TAKETH!", "SOMETHING SHINY THIS WAY COMES"},
    pigman_storeowner = {"MARRY!", "ME LIKETH", "WILL SCREW THIS TO STICKING-PLACE", "ME TAKE'ST!"},
    pigman_farmer = {"MOST EXCELLENT FANCY", "'TIS FOR HONEST DAYS WORK", "WHATFORE ART THIS?"},
    pigman_miner = {"MINE'ST!", "A POUND OF OINC", "'TIS MINE"},
    pigman_collector = {"YEA, THO I HAST SHINY THING!", "MINE OWN PURSE BE TRUE",},
    pigman_banker = {"A POUND OF OINC!", "MARRY, 'TIS COIN!", "'TIS LOST OINC FOR MINE PURSE"},
    pigman_florist = {"HATH LOVELINESS", "'TIS PRETTY!", "ALL THAT GLITTERS IS GOLD"},
    pigman_erudite = {"CATCHETH MINE EYE", "HAST VALUE", "'TIS SHININESS"},
    pigman_hatmaker = {"ME LIKETH!", "PUT MONEY IN MINE PURSE", "WHATFORE ART THIS?"},
    pigman_professor = {"OUTRAGEOUS FORTUNE!", "WANT MONEYS", "CATCHETH MINE EYE"},
    pigman_hunter = {"'TIS MINE!", "FORTUNE SMILE 'PON ME!"},
}
    
    STRINGS.CITY_PIG_TALK_FORGIVE_PLAYER = {    
    DEFAULT = {"I SHOW QUALITY OF MERCY", "ALL IS'T FORGIVEN", "HEARTILY I FORGIVEST THEE", "A POUND OF OINCS HATH SUFFICETH"},
}
    STRINGS.CITY_PIG_TALK_NOT_ENOUGH = {
    DEFAULT = {"I WANT-ETH MORE", "DOTH NOT SUFFICETH", "I REQUIRETH MORE", "NEEDETH MORE"}, -- NEW
}

    STRINGS.CITY_PIG_TALK_EAT_MEAT = {
    DEFAULT = {"NOM-ETH NOM-ETH, NOM-ETH", "O FOOD! O SLOP!", "MUNCH'D, AND MUNCH'D, AND MUNCH'D"},
  
}
    STRINGS.CITY_PIG_TALK_GO_HOME = {
    DEFAULT = {"ANON! ADIEU!", "I GET ME TO BED!"},
    pigman_beautician = {"MOST HUMBLY I LEAVES", "I SLEEP", "PERCHANCE I DREAMS"},
    pigman_mechanic = {"FARES'T THEE WELL", "MY KINGDOM FOR SOME JAMMIES", "GOOD EVENTIME"},
    pigman_mayor = {"FAIR ME WELL", "I MAKE ME BEDFELLOWS", "MY DREAMS MAY COME"},
    pigman_shopkeep = {"GET ME TO A BEDDY-BYES", "I GO MY CHAMBERS", "NIGHTY NIGHTS, SWEET UNPIGS"},
    pigman_storeowner = {"I SEE WHAT DREAMS MAY COME", "ADIEU ADIEU", "REMEMBER ME"},
    pigman_farmer = {"UNPIG, GOOD NIGHT", "PARTING SUCH SWEET SORROW", "TIL IT BE MORROW"},
    pigman_miner = {"TIL TOMORROW AND TOMORROW AND TOMORROW", "I SLUMBER'DING", "TO SLEEP OR NOT TO SLEEP?"},
    pigman_collector = {"GOOD NIGHT UNTO YOU ALL", "SWEET GOOD NIGHT!", "I BID ADIEU TO YOUS"},
    pigman_banker = {"ADIEU, UNPIG", "FARE THEE WELL", "GOOD PIGS, LET'S RETIRE"},
    pigman_florist = {"GENTLE NIGHTY-NIGHTS", "ONCE MORE UNTO MY JAMMIES", "ANON, GOOD NIGHT"},
    pigman_erudite = {"NOW IS NIGHTTIMES OF OUR DISCONTENT", "I BID ADIEUS", "UNTIL THE MORROW"},
    pigman_hatmaker = {"WHEREFORE ART MY JAMMIES?", "ALAS, I DEPART", "I BID THEE NIGHTY NIGHTS"},
    pigman_professor = {"LIGHT THROUGH MY WINDOW BREAKS", "TIS WITCHING TIME OF NIGHT", "I TAKING MY LEAVE"},
    pigman_hunter = {"ME DREAM A DREAM TONIGHT", "MY TOO TIRED FLESH GOES SLEEPIES", "SEE YOU ON THE MORROW"},
}
    STRINGS.CITY_PIG_TALK_FIX = {
    DEFAULT = {"ALL FIX'D!", "I DO'ST GOOD FIXINGS!"},
    pigman_beautician = {"I FIXETH NOT", "GET THEE TO A MECHANIC"},
    pigman_mechanic = {"I MAKETH NICE NICE", "BUILD, BUILD", "I USETH MINE HAMMER GOOD"},
    pigman_mayor = {"MAYOR SHALL NOT FIXETH","I FIXETH NOT", "GET THEE TO A MECHANIC"},
    
}
    STRINGS.CITY_PIG_GUARD_TALK_TORCH = {
    DEFAULT = {"BURN BRIGHT THE TORCHES!", "LIGHT THE TORCHES!", "BURN, TORCHES, CLEAR AND BRIGHT!"},
}
    STRINGS.CITY_PIG_GUARD_TALK_FIGHT = {
    DEFAULT = {"I STAB AT THEE!", "HAVE AT THEE!", "AWAY, CUR! AWAY!"},
}
    STRINGS.CITY_PIG_GUARD_TALK_GOHOME = {
    DEFAULT = {"STAND HO!", "WHOFORE IS THAT?", "WHATFORE THAT?", "WHAT HO!"},
}
    STRINGS.CITY_PIG_GUARD_TALK_LOOKATWILSON = {
    DEFAULT = {"MAKE NOT TROUBLES", "WHOFORE GO'ST THERE?", "TRESPASS NOT!",},
}
    STRINGS.CITY_PIG_GUARD_LIGHT_TOCH = {
    DEFAULT = {"ME LIGHT A FIERY TORCH", "TORCHES, TORCHES!", "CURFEW'S RUNGETH"},
}
    STRINGS.CITY_PIG_TALK_REFUSE_GIFT = {
    DEFAULT = {"HAVE THEE %s? WILL PAY"},   
}                               
    STRINGS.CITY_PIG_TALK_REFUSE_GIFT_DELAY = {
    DEFAULT = {"COMES'T BACK IN %s DAYS"},   
}
    STRINGS.CITY_PIG_TALK_REFUSE_GIFT_DELAY_TOMORROW = {
    DEFAULT = {"COME'ST BACK ON THE MORROW"},   
}
    STRINGS.CITY_PIG_TALK_REFUSE_PURPLEGEM = {
    DEFAULT = {"NAY! HAST THE SCARY BAD MAGICS!", "TAKETH IT AWAY!"},   
}
    STRINGS.CITY_PIG_TALK_RELIC_GIFT = {
    DEFAULT = {"TAKEST TO YON MUSEUM", "THE ACADEMY BE THE PLACE FOR IT"},            -- \"THE STY\" 
}
    STRINGS.CITY_PIG_TALK_TAKE_GIFT = {
    DEFAULT = {"MANY THANKS, GIVES'T THOU MORE %s PLEASE"},   
}
    STRINGS.CITY_PIG_TALK_GIVE_REWARD = {
    DEFAULT = {"A WORTHY JOB. TAKE THEE REWARD", "'TIS NOBLE JOB THEE DO", "A FINE JOB"},   
}
    STRINGS.CITY_PIG_TALK_GIVE_TRINKET_REWARD = {
    DEFAULT = {"OH, HOW LOVELY! TAKE THIS GIFT"},   
}     
    STRINGS.CITY_PIG_TALK_REFUSE_TRINKET_GIFT = {
    DEFAULT = {"NO MORE JUNK, THANK YOU"},   
}                             
    STRINGS.CITY_PIG_TALK_REFUSE_PRICELESS_GIFT = {
    DEFAULT = {"NO 'TIS PRICELESS!","IT IS FOUND! MUST FIND QUEEN","I CANNOT TAKE, BELONG TO ROYALTY"},   
}                         
    STRINGS.CITY_PIG_TALK_GIVE_RELIC_REWARD = {
    DEFAULT = {"MOST EXCELLENT!", "IS'T TREASURE!", "FROM YON OLDEN TIMES!"},   
}
    STRINGS.CITY_PIG_GUARD_TALK_ANGRY_PLAYER = {
    DEFAULT = {"HAS'T THEE RETURNED?!", "CUR! VILLAIN!", "OUT! FLEE!", "YOU A SEA OF TROUBLES!"},
}
    STRINGS.CITY_PIG_GUARD_TALK_RESCUE = {
    DEFAULT = { "I HELPEST THOU!", "O! THOU STUCK鈥橠ED", "NEED鈥橲T HELP?" },
}
    STRINGS.CITY_PIG_TALK_ATTEMPT_TRADE = {
    DEFAULT = {"WHAT HATH THEE?", "THY WANTS'T TRADES?", "MAKE'ST THEE DEALS?"},
}

STRINGS.CITY_PIG_SHOPKEEPER_NOT_ENOUGH = {"THY LACKETH THE OINCS", "GET THEE MORE OINCS"}
STRINGS.CITY_PIG_SHOPKEEPER_DONT_HAVE = {"BRINGETH THEE ITEM", "THOU NEED'ST ITEM", "OINCS NOT SUFFICETH, ONLY ITEM"}
STRINGS.CITY_PIG_SHOPKEEPER_SALE = {"MY THANKS", "A FINE EXCHANGE", "MANY THANKS", "THOU GOOD UNPIG"}
    
STRINGS.CITY_PIG_SHOPKEEPER_ROBBED = {"WHOFORE HAST DONE THIS?!", "ROBBED! ROBBED! ROBBED!","OH THE PIGANITY!", "REVENGE!"}
    
STRINGS.CITY_PIG_SHOPKEEPER_GREETING = {
    DEFAULT = {"WHAT SAY YOU, UNPIG?","THOU LOOK'ST FOR THINGS?","I HATH THEE WARES","BUY'ST THOU STUFFS TODAY?"},
    pigman_mayor_shopkeep = {"NEED'ST THOU A HOUSE?", "NEED'ST GUARD?", "WANT'ST THOU TO DWELL'ETH HERE?",},
    pigman_beautician = {"LOOKETH AT MINE MEDICINES", "THOU NEED'ST MEDICINES?", "NEED'ST THINGS FOR BOO-BOOS?"},
    pigman_mechanic = {"HAS'T THOU THINGS TO FIX?", "I FIXETH", "I FIXETH BROKEN THING", "YOU NEEDETH FIXINGS?"},
    pigman_miner = {"SELLETH ROCKS?", "I LIKETH ROCKS", "SELLEST ME THINE ROCKS",},
    pigman_collector = {"HAST THOU STRANGE THINGS?", "I DEALETH WITH THINGS O' STRANGENESS", "WANTS THOU STRANGE THINGS?"},
    pigman_banker = {"HAST THOU JEWELS?", "ME GIVETH OINCS FOR JEWELS", "ME LIKETH SPARKLY JEWELS"},
    pigman_florist = {"THOU NEEDS OF SEEDS?", "NEEDETH STUFFS FOR PLANTINGS?", "HAST THOU PLOP?", "HAST THOU PETALS?"},
    pigman_erudite = {"NEEDETH MAGIC THINGS?", "I SELL MAGIC THINGS?", "I SELLEST THINGS BAD DREAMS ARE MADE ON"},
    pigman_hatmaker = {"HATS? NEED'ST THOU HATS?", "NEEDST THING TO COVER THINE HEAD?", "BUY'ST THY HATS FROM ME"},
    pigman_professor = {"IN NEED'ST OF OLD THINGS?", "I LIKETH RELICS FROM YON TEMPLES", "NEED'ST THOU RELICS?",},
    pigman_hunter = {"IN NEED O' WEAPONS", "I SELL'ST SMASHY THINGS", "NEEDST THOU MURDERING THINGS?"},
}


STRINGS.CITY_PIG_TALK_FIESTA = {
    DEFAULT = {"HUZZAH! HOORAY","'TIS SWINE FIESTA DAYS!","BAD GUYS GO-ETH AWAY","PIGGIES COME OUT-ETH TO PLAY!"},
}
STRINGS.CITY_PIG_TALK_APORKALYPSE_REWARD = {
    DEFAULT = {"THOU SAVETH US!","TAKEST THOU REWARD!","THOU IS'T GOOD!","APORKALYPSE 'TIS DONE!"},
}  

