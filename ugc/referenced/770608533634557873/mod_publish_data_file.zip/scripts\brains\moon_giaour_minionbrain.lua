require "behaviours/wander"
require "behaviours/doaction"
require "behaviours/chaseandattack"
require "behaviours/standstill"
require "behaviours/runaway"
require "behaviours/follow"
require "behaviours/panic"
require "behaviours/standstill"

local STOP_RUN_DIST = 10
local SEE_PLAYER_DIST = 5
local MAX_WANDER_DIST = 5
local SEE_TARGET_DIST = 6

local MAX_CHASE_DIST = 7
local MAX_CHASE_TIME = 8

local RUN_AWAY_DIST = 10
local STOP_RUN_AWAY_DIST = 12

local function FindHealingCircle(inst)
	return FindEntity(inst,15,nil,{"healingcircle"})
end 

local function FindBattleShip(inst)
	local ship =  FindEntity(inst, 15, function(ship) return ship:HasTag("hyperion_circle") end)
	return ship~= nil
end 


local function ShouldPanic(inst)
	return inst.components.health.takingfiredamage or GetTime() - inst.components.combat.lastwasattackedtime <=  math.random(5,10)
end 

local MoonGiaourMinionBrain = Class(Brain, function(self, inst)
    Brain._ctor(self, inst)
end)

function MoonGiaourMinionBrain:OnStart()

    local root = PriorityNode(
    {
		WhileNode(function() return ShouldPanic(self.inst) end, "ShouldPanic", Panic(self.inst)),
		Wander(self.inst,function() return self.inst.components.knownlocations:GetLocation("moonbase") end, MAX_WANDER_DIST),
		StandStill(self.inst, function() return not ShouldPanic(self.inst) end, nil),
		--Wander(self.inst),
    }, .2)
    
    self.bt = BT(self.inst, root)
    
end

return MoonGiaourMinionBrain
