version = "2.8.7"
name = "艾希,I see ! "
description = "跟着箭头走..... "
author = "灵衣女王的鬼铠, 咕噜喵"

forumthread = " "

api_version = 10

dst_compatible = true

dont_starve_compatible = false
reign_of_giants_compatible = false

all_clients_require_mod = true 

priority = -999999999999999

icon_atlas = "modicon.xml"
icon = "modicon.tex"

server_filter_tags = {
	"character",
}

local keys = {"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","F1","F2","F3","F4","F5","F6","F7","F8","F9","F10","F11","F12","LAlt","RAlt","LCtrl","RCtrl","LShift","RShift","Tab","Capslock","Space","Minus","Equals","Backspace","Insert","Home","Delete","End","Pageup","Pagedown","Print","Scrollock","Pause","Period","Slash","Semicolon","Leftbracket","Rightbracket","Backslash","Up","Down","Left","Right"}
local keylist = {}
local string = ""
for i = 1, #keys do
    keylist[i] = {description = keys[i], data = "KEY_"..string.upper(keys[i])}
end


local function AddConfig(label, name, options, default)
    return {name = name, label = label, options = options, default = default}
end

configuration_options = {
	{
        name = "icey_damage_numbers",
        label = "伤害数字",
        options = 
        {
            {description = "开启", data = "on"},
            {description = "关闭", data = "off"},
        },
        default = "on"
    },
	AddConfig("闪避技能按键设置", "icey_miss",keylist,"KEY_X"),
	AddConfig("必杀技按键设置", "icey_kill",keylist,"KEY_R"),
	--AddConfig("护盾显示按键设置", "icey_show",keylist,"KEY_Z"),
	AddConfig("格挡技能按键设置", "icey_parry",keylist,"KEY_C"),
	AddConfig("辅助机射击按键设置", "icey_podshoot",keylist,"KEY_LSHIFT"),
	AddConfig("潜行技能按键设置", "icey_sneak",keylist,"KEY_Z"),
	AddConfig("人造人符文按键设置", "icey_flyhead",keylist,"KEY_V"),
	
	{
        name = "icey_dlcs",
        label = "测试的DLC(专为闲得蛋疼的人设计)",
        options = 
        {
            {description = "无", data = "none",hover = "没有任何DLC"},
            {description = "母巢之战", data = "WarOfZerg",hover = "探究浩劫军团背后的真相"},
			{description = "地铁:2033(开发者测试中)", data = "Metro2033(Beta)",hover = "在寂静的核冬天中生活"},
        },
        default = "none"
    },
	{
        name = "icey_language",
        label = "语言(Language)",
        options = 
        {
            {description = "简体中文", data = "chinese"},
            {description = "English", data = "english"},
        },
        default = "chinese"
    },
	{
        name = "icey_jade_music",
        label = "青玉巨神BGM(Jade's BGM)",
        options = 
        {
            {description = "开启", data = "on"},
            {description = "关闭", data = "off"},
        },
        default = "on"
    },
	{
        name = "icey_gal_cv",
        label = "艾希的HCV(Icey's R18 CV)",
        options = 
        {
            {description = "无", data = "NULL",hover = "不开启此功能"},
            {description = "天琦奈奈", data = "nana",hover = "警告:此功能可能含有令你不适的内容,或者不宜在工作时间打开."},
			{description = "天琦凉子", data = "ryoko",hover = "警告:此功能可能含有令你不适的内容,或者不宜在工作时间打开."},
			{description = "东云幽纪", data = "yuki",hover = "警告:此功能可能含有令你不适的内容,或者不宜在工作时间打开."},
        },
        default = "NULL"
    },
}

