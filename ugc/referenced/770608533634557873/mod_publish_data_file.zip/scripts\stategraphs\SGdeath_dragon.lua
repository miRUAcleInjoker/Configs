local TadalinUtil = require("tadalin_util")
require("stategraphs/commonstates")

local actionhandlers = 
{

}

local events=
{
    
    
    EventHandler("attacked", function(inst,data) 

	end),
    EventHandler("doattack", function(inst,data) 
		if not inst.canballattack then
			return 
		end 
        local target = data.target 
		local pos = target:GetPosition()
		local mypos = inst:GetPosition()
		local offset = Vector3(10-math.random()*20,0,10-math.random()*20)
		local timeout = inst.sg.timeout 
		--print("DEATH DRAGON timeout:",timeout)
		if inst.sg:HasStateTag("idle") then 
			inst:DoBallAttack(target,pos+offset*1.2)
		elseif inst.sg:HasStateTag("flyout") and timeout and timeout >= 3  then 
			inst:DoBallAttack(nil,mypos+offset)
		end
    end),
	EventHandler("flyin", function(inst) 
		if not inst.sg:HasStateTag("flying") then 
			inst.sg:GoToState("flyin") 
		end 
	end),
	EventHandler("flyout", function(inst) 
		if not inst.sg:HasStateTag("flying") then 
			inst.sg:GoToState("flyout") 
		end 
	end),
    EventHandler("death", function(inst) 
		if not inst.sg:HasStateTag("death") then 
			inst.sg:GoToState("death") 
		end 
	end),
    --CommonHandlers.OnLocomote(false,true),
}

local function SpawnExplode(inst,offset,scale)
	offset = offset or Vector3(0,0,0)
	scale = scale or 3
	local pos = inst:GetPosition()
	local explode = SpawnAt("positronpulse",pos+offset)
	explode.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/enemy/metal_robot/smash") 
	explode:FinishFX()
	explode.Transform:SetScale(scale,scale,scale)
	ShakeAllCameras(CAMERASHAKE.VERTICAL, .7, .025, 1.25, inst, 40)
end 

local states=
{
	State
    {
        name = "enter",
        tags = {"busy","background"},
        
        onenter = function(inst)
			inst:AddTag("background")
			inst:ChangeBuild("death_dragon_background")
			inst:EnterHigher()
			inst.Transform:SetScale(1,1,1)
            inst.Physics:Stop()
            inst.AnimState:PlayAnimation("enter",true) 			
			inst.sg:SetTimeout(3) 
			
        end,
		
		onupdate = function(inst)
			local scale = inst.Transform:GetScale()
			scale = scale + 0.02
			inst.Transform:SetScale(scale,scale,scale)
		end,
		
		ontimeout = function(inst)
			inst.sg:GoToState("flyin") 
		end,
		
		onexit = function(inst)
			inst:Show()
			inst:ChangeBuild("death_dragon")
			inst:FadeIn()
			inst:EnterLower() 
			inst:RemoveTag("background")
		end,

        timeline = 
        {
			TimeEvent(0, function(inst) 
				local pos = inst:GetPosition()
				SpawnAt("lightning",pos+Vector3(6-12*math.random(),math.random()*0.5,6-12*math.random()))
            end),
        },
		
		events =
        {
            EventHandler("animover", function(inst) 
				--inst.sg:GoToState("idle") 
				inst:FadeOut(inst.Transform:GetScale())
				inst.SoundEmitter:PlaySound("dontstarve/sanity/rook/taunt")
			end),
        },
    },
	
    State
    {
        name = "flyin",
        tags = {"busy","flying","flyin"},
        
        onenter = function(inst)
            inst.Physics:Stop()
            inst.AnimState:PlayAnimation("flyin2") 
			inst.AnimState:PushAnimation("idle",true) 
			inst.components.health:SetInvincible(true)
        end,
		
		onupdate = function(inst)

		end,
		
		onexit = function(inst)
			inst.components.health:SetInvincible(false)
		end,

        timeline = 
        {
			TimeEvent(27*FRAMES, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve/sanity/rook/taunt")
            end),
        },
        
        events =
        {
            EventHandler("animover", function(inst) 
				inst.sg:GoToState("idle") 
			end),
        },
    },
	
	--c_findnext("death_dragon").sg:GoToState("flyout")
	State
    {
        name = "attack_reap",
        tags = {"busy"},
        
        onenter = function(inst)
			inst:ChangeBuild("death_dragon_atk")
			inst:EnterHigher() 
            inst.Physics:Stop()
            inst.AnimState:PlayAnimation("atk2") 
			
			--inst.AnimState:PushAnimation("idle",true) 
			
			inst.sg:SetTimeout(5.75)
        end,
		
		ontimeout = function(inst)
			inst.sg:GoToState("flyin") 
		end,
		
		
		onexit = function(inst)
			inst:ChangeBuild("death_dragon")
			inst:EnterLower() 
			inst:FadeIn()
			if inst.sg.statemem.warningfx1 and inst.sg.statemem.warningfx1:IsValid() then 
				inst.sg.statemem.warningfx1:Remove()
			end
			if inst.sg.statemem.warningfx2 and inst.sg.statemem.warningfx2:IsValid() then 
				inst.sg.statemem.warningfx2:Remove()
			end
			inst.sg.statemem.warningfx1 = nil 
			inst.sg.statemem.warningfx2 = nil 
			inst.sg.statemem.targetpos = nil 
			inst.components.health:SetInvincible(false)
		end,

        timeline = 
        {
			TimeEvent(0, function(inst) 
				local pos = inst:GetPosition()
				for i = 1,3 do 
					SpawnAt("lightning",pos+Vector3(6-12*math.random(),math.random()*0.5,6-12*math.random()))
				end 
			end), 
			TimeEvent(3.5, function(inst) 
                local target = inst.components.combat.target
				if target and target:IsValid() then 
					inst.sg.statemem.targetpos = target:GetPosition()
					inst.sg.statemem.warningfx1 = SpawnAt("positronbeam_front",target:GetPosition())
					--inst.sg.statemem.warningfx2 = SpawnAt("positronbeam_back",target:GetPosition())
				end
            end),
			
			TimeEvent(5, function(inst) 
				if inst.sg.statemem.targetpos then 
					local attackfx = SpawnAt("tadalin_lava_lightning",inst.sg.statemem.targetpos)
					attackfx:SetSize("medium",3) 
					attackfx:DoAreaAttack(inst,6,480)
					attackfx:DestroyWorks(6)
					
					SpawnAt("positronpulse",inst.sg.statemem.targetpos):FinishFX()
					
					if inst.sg.statemem.warningfx1 and inst.sg.statemem.warningfx1:IsValid() then 
						inst.sg.statemem.warningfx1:KillFX()
					end
					
					if inst.sg.statemem.warningfx2 and inst.sg.statemem.warningfx2:IsValid() then 
						inst.sg.statemem.warningfx2:KillFX()
					end
				end
            end),
        },
        
        events =
        {
            EventHandler("animover", function(inst) 
				inst:FadeOut()
				inst.SoundEmitter:PlaySound("dontstarve/sanity/rook/taunt")
			end),
        },
    },
	
	State
    {
        name = "idle",
        tags = {"idle"},
        
        onenter = function(inst)
            inst.Physics:Stop()
			inst.AnimState:PlayAnimation("idle",true)
			inst.canballattack = true  
			inst.components.combat:SetAttackPeriod(0.4)
			inst.components.combat:CancelAttack()
			inst.sg:SetTimeout(10)
        end,
		
		onupdate = function(inst)
		
		end,
		
		
		ontimeout = function(inst)
			inst.sg:GoToState("flyout")
		end,
		
        
        events =
        {

        },
    },
	
	State
    {
        name = "flyout",
        tags = {"flying","flyout"},
        
        onenter = function(inst)
            inst.Physics:Stop()
            inst.AnimState:PlayAnimation("flyout2") 
			--inst.AnimState:PushAnimation("idle",true)
			inst.canballattack = true  
			inst.components.combat:SetAttackPeriod(0.05)
			inst.components.combat:CancelAttack()
			inst.components.health:SetInvincible(true)
			inst.sg:SetTimeout(5)
        end,
		
		ontimeout = function(inst)
			inst.sg:GoToState("attack_reap") 
		end,
		
		onexit = function(inst)
			inst.canballattack = true 
			inst.components.health:SetInvincible(false)
		end,

        timeline = 
        {
			
			TimeEvent(3, function(inst) 
                inst.canballattack = false 
            end),
			TimeEvent(25*FRAMES, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve/sanity/rook/taunt")
            end),
        },
        
        events =
        {

        },
    },
	
	State
    {
        name = "death",
        tags = {"flying","flyout","death"},
        
        onenter = function(inst)
            inst.Physics:Stop()
            inst.AnimState:PlayAnimation("flyout2") 
			inst.AnimState:SetDeltaTimeMultiplier(0.75)
			inst.sg:SetTimeout(5)
			SpawnExplode(inst)			
        end,
		
		ontimeout = function(inst)
			inst.sg:GoToState("escape") 
		end,
		
		onexit = function(inst)
			inst.AnimState:SetDeltaTimeMultiplier(1)
		end,
		

        timeline = 
        {
			TimeEvent(0.5, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/trails/taunt")
            end),
			
			
			TimeEvent(25*FRAMES, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve/sanity/rook/taunt")
            end),
        },
    },
	
	State
    {
        name = "escape",
        tags = {"busy","background","death"},
        
        onenter = function(inst)
			inst:AddTag("background")
			inst:ChangeBuild("death_dragon_background")
			inst:EnterHigher()
			
            inst.Physics:Stop()
            inst.AnimState:PlayAnimation("enter",true) 						
			local pos = inst:GetPosition()
			SpawnAt("lightning",pos+Vector3(6-12*math.random(),math.random()*0.5,6-12*math.random()))
        end,
		
		onupdate = function(inst)
			local scale = inst.Transform:GetScale()
			local x,y,z = inst.Transform:GetWorldPosition()
			y = y + 0.02
			
			scale = scale - 0.05
			scale = math.max(0.2,scale) 
			inst.Transform:SetScale(scale,scale,scale)
			inst.Transform:SetPosition(x,y,z)
		end,

        timeline = 
        {
			TimeEvent(1.1, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve/sanity/rook/taunt")
            end),
        },
		
		events =
        {
            EventHandler("animover", function(inst) 
				--inst.sg:GoToState("idle") 
				inst:FadeOut(inst.Transform:GetScale(),-0.5)
				inst.SoundEmitter:PlaySound("dontstarve/sanity/rook/taunt")
			end),
        },
    },
}



return StateGraph("SGdeath_dragon", states, events, "idle", actionhandlers)