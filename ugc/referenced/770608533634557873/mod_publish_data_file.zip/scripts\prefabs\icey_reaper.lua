local assets =
{
    Asset("ANIM", "anim/boomerang.zip"),
    Asset("ANIM", "anim/swap_boomerang.zip"),
}


local function OnRegen(inst)
    inst.components.pickable:Regen()
end

local function Reap_Pick(picker,target)
	target.components.pickable:Pick(picker)
	--[[local self = target.components.pickable
	if self.canbepicked and self.caninteractwith then
        if self.transplanted and self.cycles_left ~= nil then
            self.cycles_left = math.max(0, self.cycles_left - 1)
        end

        if self.protected_cycles ~= nil then
            self.protected_cycles = self.protected_cycles - 1
            if self.protected_cycles < 0 then
                self.protected_cycles = nil
                if self.inst.components.witherable ~= nil then
                    self.inst.components.witherable:Enable(true)
                end
            end
        end

        local loot = nil
        
        if self.droppicked and self.inst.components.lootdropper ~= nil then
            local num = self.numtoharvest or 1
            local pt = self.inst:GetPosition()
            pt.y = pt.y + (self.dropheight or 0)
            for i = 1, num do
                self.inst.components.lootdropper:SpawnLootPrefab(self.product, pt)
            end
        else
			if self.product ~= nil then 
				loot = SpawnPrefab(self.product)
			end 
            if loot ~= nil then
				loot.Transform:SetPosition(target:GetPosition():Get())
                if loot.components.inventoryitem ~= nil then
                    loot.components.inventoryitem:OnDropped(1, 1)
                end
                if self.numtoharvest > 1 and loot.components.stackable ~= nil then
                    loot.components.stackable:SetStackSize(self.numtoharvest)
                end
				if picker ~= nil then 
					picker:PushEvent("picksomething", { object = self.inst, loot = loot })
				end 
            end
        end
		print("Reaper:",loot)
		
		if self.onpickedfn ~= nil then
            self.onpickedfn(self.inst, picker, loot)
        end
		
        self.canbepicked = false
		self.inst.components.pickable:MakeEmpty()
		
        if self.baseregentime ~= nil and not (self.paused or self:IsBarren() or self.inst:HasTag("withered")) then
            if TheWorld.state.isspring then
                self.regentime = self.baseregentime * TUNING.SPRING_GROWTH_MODIFIER
            end

            if self.task ~= nil then
                self.task:Cancel()
            end
            self.task = self.inst:DoTaskInTime(self.regentime, OnRegen)
            self.targettime = GetTime() + self.regentime
        end
		self.inst:PushEvent("picked", { picker = picker, loot = loot, plant = self.inst })
    end--]]
	
end 

local function StartReap(inst,owner)
	if inst.reaper_task == nil then 
		inst.reaper_task = inst:DoPeriodicTask(0.1,function()
			local x,y,z = inst:GetPosition():Get()
			local ents = TheSim:FindEntities(x,y,z,1.5)
			for k,v in pairs(ents) do
				if v:HasTag("pickable") then 
					--[[local loot = SpawnPrefab(v.components.pickable.product)
					loot.Transform:SetPosition(v:GetPosition():Get())
					loot.components.inventoryitem:OnDropped(1, 1)
					v.components.pickable:MakeEmpty()--]]
					--v.components.pickable:Pick(owner)
					Reap_Pick(owner,v)
					inst.components.finiteuses:Use(1)
				end
			end
		end)
	end 
	if inst.firefx == nil then 
		inst.firefx = SpawnPrefab("torchfire_shadow")
		inst.firefx.entity:AddFollower()    
		inst.firefx.Follower:FollowSymbol(inst.GUID, "boomerang01", 0, 0, 0)
	end
end 

local function StopReap(inst)
	if inst.reaper_task ~= nil then 
		inst.reaper_task:Cancel()
		inst.reaper_task = nil
	end
	if inst.firefx ~= nil then 
		inst.firefx:Remove()
		inst.firefx = nil 
	end
end 

local function OnFinished(inst)
	StopReap(inst)
    inst.AnimState:PlayAnimation("used")
    inst:ListenForEvent("animover", inst.Remove)
end

local function OnEquip(inst, owner) 
    owner.AnimState:OverrideSymbol("swap_object", "swap_boomerang", "swap_boomerang")
    owner.AnimState:Show("ARM_carry") 
    owner.AnimState:Hide("ARM_normal") 
end

local function OnDropped(inst)
    inst.AnimState:PlayAnimation("idle")
	StopReap(inst)
end

local function OnUnequip(inst, owner)
    owner.AnimState:Hide("ARM_carry")
    owner.AnimState:Show("ARM_normal")
end

local function OnThrown(inst, owner, target)
    if target ~= owner then
        owner.SoundEmitter:PlaySound("dontstarve/wilson/boomerang_throw")
    end
    inst.AnimState:PlayAnimation("spin_loop", true)
	StartReap(inst,owner)
end

local function OnCaught(inst, catcher)
    if catcher ~= nil and catcher.components.inventory ~= nil and catcher.components.inventory.isopen then
        if inst.components.equippable ~= nil and not catcher.components.inventory:GetEquippedItem(inst.components.equippable.equipslot) then
            catcher.components.inventory:Equip(inst)
        else
            catcher.components.inventory:GiveItem(inst)
        end
        catcher:PushEvent("catch")
    end
	StopReap(inst)
end

local function ReturnToOwner(inst, owner)
    if owner ~= nil and not (inst.components.finiteuses ~= nil and inst.components.finiteuses:GetUses() < 1) then
        owner.SoundEmitter:PlaySound("dontstarve/wilson/boomerang_return")
        inst.components.projectile:Throw(owner, owner)
    end
end

local function OnHit(inst, owner, target)
    if owner == target or owner:HasTag("playerghost") then
        OnDropped(inst)
    else
        ReturnToOwner(inst, owner)
    end
    if target ~= nil and target:IsValid() then
        local impactfx = SpawnPrefab("impact")
        impactfx.Transform:SetPosition(target.Transform:GetWorldPosition())
		--[[if  target.components.pickable and target.components.pickable:CanBePicked() then 
			target.components.pickable:Pick(owner)
		end--]]
    end
	if inst and inst.components.finiteuses and inst.components.finiteuses:GetUses() <= 0 then 
		inst:Remove()
	end
end

local function OnMiss(inst, owner, target)
    if owner == target then
        OnDropped(inst)
    else
        ReturnToOwner(inst, owner)
    end
end

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()

    MakeInventoryPhysics(inst)
    RemovePhysicsColliders(inst)

    inst.AnimState:SetBank("boomerang")
    inst.AnimState:SetBuild("boomerang")
    inst.AnimState:PlayAnimation("idle")
    inst.AnimState:SetRayTestOnBB(true)

    inst:AddTag("thrown")
	inst:AddTag("ACTION_REAP")
    --projectile (from projectile component) added to pristine state for optimization
    inst:AddTag("projectile")

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst:AddComponent("weapon")
    inst.components.weapon:SetDamage(15)
    inst.components.weapon:SetRange(TUNING.BOOMERANG_DISTANCE, TUNING.BOOMERANG_DISTANCE+2)
    -------

    inst:AddComponent("finiteuses")
    inst.components.finiteuses:SetMaxUses(100)
    inst.components.finiteuses:SetUses(100)

    inst.components.finiteuses:SetOnFinished(OnFinished)

    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("收割,现在开始")

    inst:AddComponent("projectile")
    inst.components.projectile:SetSpeed(10)
    inst.components.projectile:SetCanCatch(true)
    inst.components.projectile:SetOnThrownFn(OnThrown)
    inst.components.projectile:SetOnHitFn(OnHit)
    inst.components.projectile:SetOnMissFn(OnMiss)
    inst.components.projectile:SetOnCaughtFn(OnCaught)
	

    inst:AddComponent("inventoryitem")
    inst.components.inventoryitem:SetOnDroppedFn(OnDropped)
	inst.components.inventoryitem.imagename = "boomerang"
	
    inst:AddComponent("equippable")
    inst.components.equippable:SetOnEquip(OnEquip)
    inst.components.equippable:SetOnUnequip(OnUnequip)

    MakeHauntableLaunch(inst)

    return inst
end

return Prefab("icey_reaper", fn, assets)
