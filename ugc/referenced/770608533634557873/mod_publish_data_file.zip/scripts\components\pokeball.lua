local function onputininventory(inst,owner)
	local self = inst.components.pokeball
	owner = inst.components.inventoryitem:GetGrandOwner()
	if owner and owner:IsValid() and owner:HasTag("player") and owner.userid  then 
		if not self.ownerid then 
			self.owner = owner
			self.ownerid = owner.userid
		elseif owner.userid == self.ownerid then 
			self.owner = owner 
		end 
	end
	inst.components.inventoryitem.canbepickedup = true 
	self:FreshName()
end 

local function NormalRetarget(inst)
	local owner = inst.PokeOwner 
	return FindEntity(
        inst,
        20,
        function(guy)
            return owner ~= nil
                and inst.components.combat:CanTarget(guy)
				and inst.PokeOwner ~= guy.PokeOwner
                and (guy.components.combat.target == owner or
                    owner.components.combat.target == guy)
        end,
        { "_combat", "_health" },
        { "INLIMBO", "noauradamage" }
    )
end 

local function NormalKeepTarget(inst,target)
	local owner = inst.PokeOwner 
	return inst.components.combat:CanTarget(target) and target ~= owner 
		and (target.components.health and not target.components.health:IsDead()) 
		and inst.PokeOwner ~= target.PokeOwner
end 


local PokeBall = Class(function(self,inst)
	self.inst = inst 
	self.owner = nil 
	self.ownerid = nil 
	
	self.poke = nil 
	
	self.catch_rand = 0.75 
	self.is_new_ball = true     ----是不是新的球(抓过精灵以后，就不是新的球了)
	self.poke_is_inside = false ----是否有精灵在球里
	self.poke_prefab = nil      ----抓住的精灵的名字
	self.summon_cd = 0          ----召唤精灵的cd
	
	if not inst.components.named then
		inst:AddComponent("named")
	end
	
	inst:ListenForEvent("onputininventory",onputininventory)
	inst:ListenForEvent("onremove",function() self:CallPokeBack(true)  end)
	inst:ListenForEvent("playerexited",function(world,player) 
		if player == self.owner then 
			self:CallPokeBack(true) 
		end 
	end,TheWorld)
	inst:DoTaskInTime(0,function() self:FreshName()end)
end)

function PokeBall:FreshName()
	local name = STRINGS.NAMES[string.upper("icey_pokeball")].."\n"
	name = name.."精灵主人:"..(self.owner and self.owner.name or "无").."\n"
	name = name.."捕捉几率:"..(self.catch_rand*100).."%\n"
	name = name.."精灵名字:"..(self.poke_prefab and STRINGS.NAMES[string.upper(self.poke_prefab)] or "无").."\n"
	name = name.."精灵状态:"..(self.poke_is_inside and "在精灵球内" or self.poke_prefab and "出战中" or "无").."\n"
	name = name.."重召唤CD:"..math.floor(self.summon_cd)
	
	self.inst.components.named:SetName(name)
end 

function PokeBall:ReturnToHand()
	if self.inst.components.inventoryitem and self.owner and self.owner.components.inventory  then 
		self.inst.Transform:SetPosition(self.owner:GetPosition():Get())
		self.owner.components.inventory:GiveItem(self.inst) 
	end
end 

function PokeBall:CdDoDelta(delta)
	self.summon_cd = self.summon_cd + delta
	self.summon_cd = math.max(0,self.summon_cd)
end 

----------能够抓捕小精灵
function PokeBall:CanCatch(target)
	return self.is_new_ball and not self.poke_is_inside and not self.poke_prefab
		and target and target:IsValid() 
		and target.components.combat and target.components.combat.defaultdamage > 0 
		and target.components.health and not target:HasTag("epic") and not target:HasTag("tadalin")
end 

function PokeBall:Catch(target)
	if not self:CanCatch(target) then 
		return 
	end
	
	self.is_new_ball = false 
	target:RemoveFromScene()
	
	SpawnPrefab("maxwell_smoke").Transform:SetPosition(target:GetPosition():Get())

	
	self.inst.SoundEmitter:PlaySound("dontstarve/forge2/beetletuar/attack")
	
	self.inst:DoTaskInTime(1,function()
		SpawnPrefab("dr_warm_loop_1").Transform:SetPosition(self.inst:GetPosition():Get())
		self.inst.SoundEmitter:KillSound("ping")
		self.inst.SoundEmitter:PlaySound("dontstarve/common/diviningrod_ping", "ping")
        self.inst.SoundEmitter:SetParameter("ping", "intensity",0.7)
	end)
	
	self.inst:DoTaskInTime(2,function()
		SpawnPrefab("dr_warm_loop_2").Transform:SetPosition(self.inst:GetPosition():Get())
		self.inst.SoundEmitter:KillSound("ping")
		self.inst.SoundEmitter:PlaySound("dontstarve/common/diviningrod_ping", "ping")
        self.inst.SoundEmitter:SetParameter("ping", "intensity",0.8)
	end)
	
	self.inst:DoTaskInTime(3,function()
		SpawnPrefab("dr_warmer_loop").Transform:SetPosition(self.inst:GetPosition():Get())
		self.inst.SoundEmitter:KillSound("ping")
		self.inst.SoundEmitter:PlaySound("dontstarve/common/diviningrod_ping", "ping")
        self.inst.SoundEmitter:SetParameter("ping", "intensity",1)
	end)
	
	self.inst:DoTaskInTime(4,function()
		SpawnPrefab("dr_hot_loop").Transform:SetPosition(self.inst:GetPosition():Get())
		self.inst.SoundEmitter:KillSound("ping")
		if math.random() <= self.catch_rand then 
			self:OnCatchSuccess(target)
		else
			self:OnCatchFail(target)
		end
	end) 
end 

function PokeBall:OnCatchSuccess(target)
	self.poke_is_inside = true
	self.poke_prefab = target.prefab 
	self.inst.components.inventoryitem.canbepickedup = true 
	self:ReturnToHand()
	self.inst.SoundEmitter:PlaySound("dontstarve/wilson/equip_item_gold")
	self:FreshName()
	target:Remove() 
end 

function PokeBall:OnCatchFail(target)
	SpawnPrefab("explode_small").Transform:SetPosition(self.inst:GetPosition():Get())
	target:ReturnToScene()
	self.inst:Remove() 
end 



----------能够释放球内的小精灵
function PokeBall:CanSummonAt(pos)
	return self.summon_cd <= 0 and self.poke_prefab and self.poke_is_inside and self.owner
		and pos and TheWorld.Map:IsPassableAtPoint(pos:Get())
end 

function PokeBall:SummonAt(pos)
	if not self:CanSummonAt(pos) then 
		return
	end
	local poke = SpawnPrefab(self.poke_prefab)
	poke.Transform:SetPosition(pos:Get())
	poke:AddTag("companion")
	poke.persists = false
	poke.PokeOwner = self.owner 
	poke.components.combat:SetRetargetFunction(1,NormalRetarget)
	poke.components.combat:SetKeepTargetFunction(NormalKeepTarget)
	if not poke.components.follower then 
		poke:AddComponent("follower")
	end 
	poke.components.follower:SetLeader(self.owner) 
	poke:ListenForEvent("newcombattarget",function(player,data)
		local target = data.target
		print("Owner NewCombatTarget",target,poke.PokeOwner,target.PokeOwner)
		if target and target:IsValid() and poke.PokeOwner ~= target.PokeOwner then 
			poke.components.combat:SuggestTarget(target)
		end 
		if poke.components.sleeper then 
			poke.components.sleeper:WakeUp()
		end
	end,self.owner)
	poke:ListenForEvent("attacked",function(player,data)
		local attacker = data.attacker
		poke.components.combat:SuggestTarget(attacker)
		if poke.components.sleeper then 
			poke.components.sleeper:WakeUp()
		end
	end,self.owner)
	--self.inst:ListenForEvent("onremove",function(mypoke,data)
		--self:CallPokeBack(false)
	--end,poke)
	poke:ListenForEvent("attacked",function(mypoke,data)
		if data.attacker and data.attacker == poke.PokeOwner then 
			self:CallPokeBack(true) 
		end 
	end)
	poke:ListenForEvent("death",function()
		self:CallPokeBack(true) 
	end)
	SpawnPrefab("explode_small").Transform:SetPosition(poke:GetPosition():Get())
	self.poke = poke
	self.poke_is_inside = false 
	
	self:ReturnToHand()
	
	self.inst.components.inventoryitem.canbepickedup = true 
	self:FreshName()
end 

----------能够召回外面的小精灵
function PokeBall:CanCallPokeBack()
	return self.poke and self.poke:IsValid() --not self.poke_is_inside and self.poke_prefab and self.poke and self.poke:IsValid() 
end 

function PokeBall:CallPokeBack(canremove,cangiveitem)
	if not self:CanCallPokeBack() then 
		return 
	end
	SpawnPrefab("maxwell_smoke").Transform:SetPosition(self.poke:GetPosition():Get())
	if canremove then 
		self.poke:Remove()
	end 
	self.poke = nil 
	self.poke_is_inside = true 
	
	if cangiveitem then 
		self:ReturnToHand()
	end
	--self:CdDoDelta(60)
	self:FreshName()
	--self:StartUpdate()
end 

function PokeBall:OnSave()
	return {
		--ownerid = self.ownerid,
		is_new_ball = self.is_new_ball, 
		poke_is_inside = self.poke_is_inside, 
		poke_prefab = self.poke_prefab,
		summon_cd = self.summon_cd,
	}
end

function PokeBall:OnLoad(data)
	if data then 
		--self.ownerid = data.ownerid
		self.is_new_ball = data.is_new_ball
		self.poke_is_inside = data.poke_is_inside
		self.poke_prefab = data.poke_prefab
		self.summon_cd = data.summon_cd 
	end 
	if self.poke_prefab then 
		self.poke_is_inside = true
	end
	self:FreshName()
end

function PokeBall:OnUpdate(dt)
	self:CdDoDelta(-dt)
	self:FreshName()
	if self.summon_cd <= 0 then 
		--self:StopUpdate()
	end
end

function PokeBall:Debug()
	local str = {
		"**********PokeBallBebug***********\n",
		"inst:",self.inst,"\n",
		"owner:",self.owner,"\n",
		"ownerid:",self.ownerid,"\n",
		"poke:",self.poke,"\n",
		"catch_rand:",self.catch_rand,"\n",
		"is_new_ball:",self.is_new_ball,"\n",
		"poke_is_inside:",self.poke_is_inside,"\n",
		"poke_prefab:",self.poke_prefab,"\n",
		"summon_cd:",self.summon_cd,"\n",
		"**********PokeBallBebugFinish******\n",
	}
	
	print(unpack(str))
	
	return str 
end

return PokeBall 