local assets =
{
    Asset("ANIM", "anim/icey_ball.zip"),
    Asset("ANIM", "anim/swap_icey_ball.zip"),
	Asset("IMAGE","images/inventoryimages/icey_ball.tex"),
	Asset("ATLAS","images/inventoryimages/icey_ball.xml")
}

local prefabs =
{
	"sleepcloud",
	"sleepbomb_burst",
    "reticule",
    "reticuleaoe",
    "reticuleaoeping",
}

local function SpawnMagic(gain,pos)
	if not gain or gain < 0 then return end 
	local x,y,z = pos:Get()
	local rad = math.random(1,300) / 300
	for i=1,math.min(math.random(1,math.max(gain,1)),40) do ---------获得精华
		if math.random(0,100) >= 25 then 
			local x1,y1,z1 = x + rad * math.cos(math.random(0,360)),0,z + rad * math.sin(math.random(0,360))
			local magic = SpawnPrefab("icey_magic")
			magic.Transform:SetPosition(x1,y1,z1)
		end 
	end 
end 

local function canattack(v) ------------多重保险：判定目标是否真的可以被攻击，可以被伤害
	return v and v:IsValid()  and  
	v.components and v.components.combat and v.components.health and not v.components.health:IsDead() 
end  

local function OnHit(inst, attacker, target)
	local pos = inst:GetPosition()
    local x, y, z = pos:Get()
	local ents = TheSim:FindEntities(x,y,z,4,{},{"INLIMBO","NOCLICK","CANT_RESOLVE"})
	local fx1 = SpawnPrefab("sleepbomb_burst")
	local fx2 = SpawnPrefab("explode_small")
	for k,v in pairs(ents) do
		if v and v:IsValid() then 
			if canattack(v) then 
				v.components.combat:GetAttacked(attacker,math.random(250,400))
				if v.components.health:IsDead() then 
					local gain = v.components.health.maxhealth / 200
					SpawnMagic(gain,pos)
				end
			elseif v.components.edible then
				local edible = v.components.edible
				local gain = (edible.healthvalue + edible.hungervalue + edible.sanityvalue) / 30
				SpawnMagic(gain,pos)
				v:Remove()
			elseif  v.components.workable then 
				v.components.workable:Destroy(attacker)
			elseif  v.components.inventoryitem and v.prefab ~= "icey_magic" then
				local gain = (v.components.stackable and v.components.stackable:StackSize()) or 1
				gain = gain * math.random(0.5,2)
				SpawnMagic(gain,pos)
				v:Remove()
			end
		end 
	end
    fx1.Transform:SetPosition(x, y, z)
	fx2.Transform:SetPosition(x, y, z)
	fx2.Transform:SetScale(2.5,2.5,2.5)
    --SpawnPrefab("sleepcloud").Transform:SetPosition(x, y, z)
	inst:Remove()
end

local function onequip(inst, owner) 
    owner.AnimState:OverrideSymbol("swap_object", "swap_icey_ball", "icey_ball")
    owner.AnimState:Show("ARM_carry") 
    owner.AnimState:Hide("ARM_normal") 
end

local function onunequip(inst, owner) 
	owner.AnimState:ClearOverrideSymbol("swap_object")
    owner.AnimState:Hide("ARM_carry") 
    owner.AnimState:Show("ARM_normal") 
end

local function onthrown(inst)
    inst:AddTag("NOCLICK")
    inst.persists = false
	
	inst.Transform:SetScale(0.5,0.5,0.5)
    inst.AnimState:PlayAnimation("rolling",true)

    inst.Physics:SetMass(1)
    inst.Physics:SetCapsule(0.2, 0.2)
    inst.Physics:SetFriction(0)
    inst.Physics:SetDamping(0)
    inst.Physics:SetCollisionGroup(COLLISION.CHARACTERS)
    inst.Physics:ClearCollisionMask()
    inst.Physics:CollidesWith(COLLISION.WORLD)
    inst.Physics:CollidesWith(COLLISION.OBSTACLES)
    inst.Physics:CollidesWith(COLLISION.ITEMS)
end

local function ReticuleTargetFn()
    local player = ThePlayer
    local ground = TheWorld.Map
    local pos = Vector3()
    --Attack range is 8, leave room for error
    --Min range was chosen to not hit yourself (2 is the hit range)
    for r = 6.5, 3.5, -.25 do
        pos.x, pos.y, pos.z = player.entity:LocalToWorldSpace(r, 0, 0)
        if ground:IsPassableAtPoint(pos:Get()) and not ground:IsGroundTargetBlocked(pos) then
            return pos
        end
    end
    return pos
end

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()

    MakeInventoryPhysics(inst)

    --projectile (from complexprojectile component) added to pristine state for optimization
    inst:AddTag("projectile")

    inst.AnimState:SetBank("icey_ball")
    inst.AnimState:SetBuild("icey_ball")
    inst.AnimState:PlayAnimation("idle")
	inst.Transform:SetScale(0.5,0.5,0.5)
    inst.AnimState:SetDeltaTimeMultiplier(.75)

    inst:AddComponent("reticule")
    inst.components.reticule.targetfn = ReticuleTargetFn
    inst.components.reticule.ease = true

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst:AddComponent("locomotor")

    inst:AddComponent("complexprojectile")
    inst.components.complexprojectile:SetHorizontalSpeed(15)
    inst.components.complexprojectile:SetGravity(-35)
    inst.components.complexprojectile:SetLaunchOffset(Vector3(.25, 1, 0))
    inst.components.complexprojectile:SetOnLaunch(onthrown)
    inst.components.complexprojectile:SetOnHit(OnHit)


    inst:AddComponent("weapon")
    inst.components.weapon:SetDamage(0)
    inst.components.weapon:SetRange(8, 10)


    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("将一切打回原子状态")
	
    inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "icey_ball"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/icey_ball.xml"

    inst:AddComponent("stackable")
	inst.components.stackable.maxsize = TUNING.STACK_SIZE_MEDITEM

    inst:AddComponent("equippable")
    inst.components.equippable:SetOnEquip(onequip)
    inst.components.equippable:SetOnUnequip(onunequip)
    inst.components.equippable.equipstack = true

    MakeHauntableLaunch(inst)

    return inst
end

return Prefab("icey_ball", fn, assets, prefabs)
