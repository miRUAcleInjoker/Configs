require "behaviours/wander"
require "behaviours/doaction"
require "behaviours/chaseandattack"
require "behaviours/standstill"
require "behaviours/useshield"

local DraculaBrain = Class(Brain, function(self, inst)
    Brain._ctor(self, inst)
end)

function DraculaBrain:OnStart()

    local root = PriorityNode(
    {
		--[[IfNode(function() return self.inst.components.health:GetPercent() < 0.5 end, "Low Health",
            UseShield(self.inst, 150, 12,true,false)),--]]
        ChaseAndAttack(self.inst, 45,35),
		Wander(self.inst, function() return self.inst.components.knownlocations:GetLocation("home") end, 20),
		StandStill(self.inst, function() return self.inst.sg:HasStateTag("idle") end, nil),
    }, .25)
    
    self.bt = BT(self.inst, root)
    
end

return DraculaBrain
