local IceyIronLord = Class(function(self, inst)
	self.inst = inst 
	self.is_ironlord = net_bool(inst.GUID, "IceyIronLord.is_ironlord", "is_ironlorddirty") 
	self.current_energy = net_ushortint(inst.GUID, "IceyIronLord.current_energy")
	self.max_energy = net_ushortint(inst.GUID, "IceyIronLord.max_energy")
end)

function IceyIronLord:SetIsIronLord(val)
	self.is_ironlord:set(val)
end

function IceyIronLord:SetCurrent(val)
	self.current_energy:set(val)
end

function IceyIronLord:SetMax(val)
	self.max_energy:set(val)
end 

function IceyIronLord:GetCurrent()
	return self.current_energy:value()
end 

function IceyIronLord:GetMax()
	return self.max_energy:value()
end

function IceyIronLord:GetPercent()
	return self.current_energy:value() / self.max_energy:value() 
end 

function IceyIronLord:IsIronLord()
	return self.is_ironlord:value()
end

return IceyIronLord