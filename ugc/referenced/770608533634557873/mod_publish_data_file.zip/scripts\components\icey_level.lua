local SourceModifierList = require("util/sourcemodifierlist")

local function onexp(self,exp)
	self.inst.replica.icey_level:SetExp(exp)
end 

local function onmax_exp(self,max_exp)
	self.inst.replica.icey_level:SetMaxExp(max_exp)
end 

local function onlevel(self,level)
	self.inst.replica.icey_level:SetLevel(level)
end 

local function onmax_level(self,max_level)
	self.inst.replica.icey_level:SetMaxLevel(max_level)
end 

local IceyLevel = Class(function(self, inst)
    self.inst = inst
    self.exp = 0
	self.max_exp = 100
	self.level = 1
	self.max_level = 10 
	
	self.onsetexp = nil 
	self.onsetlevel = nil 
	
end,
nil,
{
    exp = onexp,
	max_exp = onmax_exp,
	level = onlevel,
	max_level = onmax_level,
})

function IceyLevel:SetOnExp(fn)
	self.onsetexp = fn
end 

function IceyLevel:SetOnLevel(fn)
	self.onsetlevel = fn
end 

function IceyLevel:ReCalcMaxExp()
	self.max_exp = self.level * 100
end 

function IceyLevel:SetLevel(val)
	local old_level = self.level
	self.level = val
	self.level = math.max(1,self.level)
	self.level = math.min(self.max_level,self.level)
	local new_level = self.level
	local is_levelup = new_level > old_level
	self:ReCalcMaxExp()
	
	if self.onsetlevel then 
		self.onsetlevel(self.inst,is_levelup,old_level,new_level)
	end 
	self.inst:PushEvent("icey_level_change",{oldlevel = old_level,newlevel = new_level,islevelup = is_levelup})
end 

function IceyLevel:SetExp(val)
	local try_delta = val - self.exp
	
	self.exp = val
	self.exp = math.max(0,self.exp)
	while self.exp >= self.max_exp do 
		self.exp = self.exp - self.max_exp
		self:LevelDoDelta(1)
	end 
	
	if self.onsetexp then
		self.onsetexp(self.inst,try_delta)
	end
end 

function IceyLevel:ExpDoDelta(delta)
	return self:SetExp(self:GetCurrentExp() + delta)
end

function IceyLevel:LevelDoDelta(delta)
	return self:SetLevel(self:GetCurrentLevel() + delta)
end

function IceyLevel:GetCurrentExp()
	return self.exp
end

function IceyLevel:GetCurrentLevel()
	return self.level
end

function IceyLevel:IsLevelMaxed()
	return self.level >= self.max_level 
end 

function IceyLevel:OnSave()
	local data = {}
	data.exp = self.exp 
	data.level = self.level 
	return data
end

function IceyLevel:OnLoad(data)
	if data then 
		self.exp = data.exp
		self.level = data.level
	end
	self:ReCalcMaxExp()
	self:ExpDoDelta(0)
	self:LevelDoDelta(0)
end

return IceyLevel