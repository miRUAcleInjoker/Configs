local IceyGunCartridge = Class(function(self, inst)
	self.inst = inst
	
	self.max = 12
	self.current = self.max
	
	
	inst:AddTag("iceyguncartridge")
end)

function IceyGunCartridge:GetCurrent()
	return self.current
end 

function IceyGunCartridge:GetMax()
	return self.max
end 

function IceyGunCartridge:SetCurrent(val)
	local old_current = self.current
	self.current = math.min(val,self.max)
	self.current = math.max(0,self.current)
	return self.current - old_current
end 

function IceyGunCartridge:DoDelta(delta)
	return self:SetCurrent(self.current + delta)
end 

function IceyGunCartridge:OnRemoveFromEntity()
	self.inst:RemoveTag("iceyguncartridge")
end

function IceyGunCartridge:OnSave()
	return {
		current = self.current,
	}
end 

function IceyGunCartridge:OnLoad(data)
	if data then 
		self.current = data.current or self.max
	end
end

return IceyGunCartridge