local IceyCommonStates = require("icey_commonstates")


local function ValidateMultiThruster(inst)
    return inst.sg.statemem.weapon ~= nil
        and inst.sg.statemem.weapon.components.equippable ~= nil
        and inst.sg.statemem.weapon.components.equippable:IsEquipped()
        and inst.sg.statemem.weapon.components.inventoryitem ~= nil
        and inst.sg.statemem.weapon.components.inventoryitem:IsHeldBy(inst)
        and inst.sg.statemem.weapon.components.multithruster ~= nil
end

local function DoThrust(inst, nosound)
    if ValidateMultiThruster(inst) then
        inst.sg.statemem.weapon.components.multithruster:DoThrust(inst, inst.sg.statemem.target)
        if not nosound then
            inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon")
        end
    end
end

local function ToggleOffPhysics(inst)
    inst.sg.statemem.isphysicstoggle = true
    inst.Physics:ClearCollisionMask()
    inst.Physics:CollidesWith(COLLISION.GROUND)
end

local function ToggleOnPhysics(inst)
    inst.sg.statemem.isphysicstoggle = nil
    inst.Physics:ClearCollisionMask()
    inst.Physics:CollidesWith(COLLISION.WORLD)
    inst.Physics:CollidesWith(COLLISION.OBSTACLES)
    inst.Physics:CollidesWith(COLLISION.SMALLOBSTACLES)
    inst.Physics:CollidesWith(COLLISION.CHARACTERS)
    inst.Physics:CollidesWith(COLLISION.GIANTS)
end

local function KnockBackTarget(inst,other,pos,radius,dist)
	local x,y,z = pos.x,pos.y,pos.z
	other:PushEvent("knockback", { knocker = inst, radius = radius + dist, propsmashed = true })
	if other ~= nil and not (other:HasTag("epic") or other:HasTag("largecreature")) then
		if other:IsValid() and other.entity:IsVisible() and not (other.components.health ~= nil and other.components.health:IsDead()) then
			if other.components.combat ~= nil then
				if other.Physics ~= nil then
					local x, y, z = inst.Transform:GetWorldPosition()
					local distsq = other:GetDistanceSqToPoint(x, 0, z)
					if distsq > 0 then
						other:ForceFacePoint(x, 0, z)
					end
					local k = .5 * distsq / 25 - 1
					other.speed = 60 * k
					other.dspeed = 2
					other.Physics:ClearMotorVelOverride()
					other.Physics:Stop()					
					if other.components.inventory and other.components.inventory:ArmorHasTag("heavyarmor") or other:HasTag("heavybody") then 
					--Leo: Need to change this to check for bodyslot for these tags.
						other:DoTaskInTime(0.1, function(inst) 
							other.Physics:SetMotorVelOverride(-2, 0, 0) 
						end)
					else
						other:DoTaskInTime(0, function(inst) 
							other.Physics:SetMotorVelOverride(-20, 0, 0) 
						end)
					end
					other:DoTaskInTime(0.4, function(inst) 
						other.Physics:ClearMotorVelOverride()
						other.Physics:Stop()
					end)
				end
			end
		end
	end
end 

local function canattack(v,inst) ------------多重保险：判定目标是否真的可以被攻击，可以被伤害
	if not (v and v:IsValid() and inst and inst:IsValid()) then 
		return false 
	end
	for k,tag in pairs(TUNING.ICEY_NO_TAGS) do 
		if v:HasTag(tag) then 
			--print("canattack:",v,":HasTag:"..tag.."so it cant be attacked")
			return false 
		end
	end
	return (v.userid  == nil or v.userid ~= inst.owner_id) and v ~= inst and  
	not v:HasTag("companion") and not v:HasTag("wall") and --------------求求你别打狗切和格罗姆了
	(v.components.follower == nil or (inst ~= v.components.follower.leader)) and --------------求求你别打自己人了
	v.components and v.components.combat and v.components.health and not v.components.health:IsDead() 
end 

local function PushCQCEvent(inst,target,cqctype)
	inst:PushEvent("icey_cqc_attack",{target = target,type = cqctype})
end 

 

--[[local function DoVacuumSwordSGServer(inst)
	local buffaction = inst:GetBufferedAction()
    local target = buffaction ~= nil and buffaction.target or nil
	inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon",nil,nil,true)
	inst.SoundEmitter:PlaySound("dontstarve/common/lava_arena/fireball",nil,nil,true)
    inst.components.combat:SetTarget(target)
    inst.components.combat:StartAttack()
	inst:FacePoint(target:GetPosition())
	inst:PerformBufferedAction()
	DoVacuumSwordAttack(inst,target)
end 

local function DoVacuumSwordSGClient(inst)
	inst.replica.combat:StartAttack()
    local buffaction = inst:GetBufferedAction()
    if buffaction ~= nil then
		inst:PerformPreviewBufferedAction()
        if buffaction.target ~= nil and buffaction.target:IsValid() then
            inst:FacePoint(buffaction.target:GetPosition())
        end
    end
	inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon",nil,nil,true)
	inst.SoundEmitter:PlaySound("dontstarve/common/lava_arena/fireball",nil,nil,true)
end--]] 
--特殊攻击
AddStategraphPostInit("wilson", function(sg)
    local old_ATTACK = sg.actionhandlers[ACTIONS.ATTACK].deststate
    sg.actionhandlers[ACTIONS.ATTACK].deststate = function(inst, action,...)
		local weapon = inst.components.combat:GetWeapon()
		if weapon  then 
			if  weapon:HasTag("storm_controlor") then 
				return "storm_controlor_attack"
			elseif weapon:HasTag("halberd") then 
				inst.SoundEmitter:PlaySound("dontstarve_DLC003/common/items/weapon/halberd")
			elseif weapon:HasTag("portableitem") then 
				--inst.SoundEmitter:PlaySound("dontstarve/forge2/beetletaur/swipe")
				return "portableitem_attack"
			elseif weapon:HasTag("corkbat") then
                inst.SoundEmitter:PlaySound("dontstarve_DLC003/common/items/weapon/corkbat")
			elseif weapon:HasTag("vacuum_sword") then 
				--DoVacuumSwordSGServer(inst)
				--return 
				return "vacuum_sword"
			elseif weapon:HasTag("speargun") and not weapon:HasTag("gun_without_bullet") then 
                return "speargun"
            elseif weapon:HasTag("blunderbuss") and not weapon:HasTag("gun_without_bullet") then 
                return "speargun"
			elseif weapon:HasTag("iceygun") and not weapon:HasTag("gun_without_bullet") then 
                return "iceygun_shoot"
			end 
		end 
        if inst:HasTag("icey") and 
			not inst.sg:HasStateTag("attack") and not inst.components.health:IsDead() and not inst.components.rider:IsRiding() then
            
			
			if weapon and weapon:HasTag("yuki_gun") then 
				return "yuki_gun_atk_pre"
			end 
			
			if  weapon  then 
				if  inst:HasTag("iceyatk_multithrust") then 
					return "iceyatk_multithrust"
				elseif inst:HasTag("iceyatk_chop") then 
					return "iceyatk_chop"
				elseif inst:HasTag("iceyatk_hop") then 
					return "iceyatk_hop"
				elseif inst:HasTag("iceyatk_lunge") then 
					return "iceyatk_lunge"
				elseif inst:HasTag("iceyatk_prop") then 
					return "iceyatk_prop"
				elseif inst:HasTag("iceyatk_circle") then 
					return "iceyatk_circle"
					
				end 
			end 
		
        end
        return old_ATTACK(inst, action,...)
    end
end)
AddStategraphPostInit("wilson_client", function(sg)
    local old_ATTACK = sg.actionhandlers[ACTIONS.ATTACK].deststate
    sg.actionhandlers[ACTIONS.ATTACK].deststate = function(inst, action,...)
		local weapon = inst.replica.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
		if weapon then 
			if  weapon:HasTag("storm_controlor") then 
				return "storm_controlor_attack"
			elseif weapon:HasTag("halberd") then 
				--[[inst:DoTaskInTime(0.05,function()
					if inst.sg and inst.sg:HasStateTag("attack") and not inst.sg:HasStateTag("iceyatk_multithrust") then 
						inst.SoundEmitter:PlaySound("dontstarve_DLC003/common/items/weapon/halberd")
					end 
				end)--]]
			elseif weapon:HasTag("portableitem") then 
				return "portableitem_attack"
			elseif weapon:HasTag("vacuum_sword") then 
				--DoVacuumSwordSGServer(inst)
				return "vacuum_sword"
			elseif weapon:HasTag("speargun") then 
                return "speargun"
            elseif weapon:HasTag("blunderbuss") then 
                return "speargun"
			elseif weapon:HasTag("iceygun") then 
                return "iceygun_shoot"
			end 
		end 
        if inst:HasTag("icey") and 
			not inst.sg:HasStateTag("attack") and not inst.replica.health:IsDead() and not inst.replica.rider:IsRiding() then
            
			
			if weapon and weapon:HasTag("yuki_gun") then 
				return "yuki_gun_atk_pre"
			end 
			
			if  weapon  then 
				if  inst:HasTag("iceyatk_multithrust") then 
					return "iceyatk_multithrust"
				elseif inst:HasTag("iceyatk_chop") then 
					return "iceyatk_chop"
				elseif inst:HasTag("iceyatk_hop") then 
					return "iceyatk_hop"
				elseif inst:HasTag("iceyatk_lunge") then 
					return "iceyatk_lunge"
				elseif inst:HasTag("iceyatk_prop") then 
					return "iceyatk_prop"
				elseif inst:HasTag("iceyatk_circle") then 
					return "iceyatk_circle"
				end 
			end 
		
        end
        return old_ATTACK(inst, action,...)
    end
end)

-----------让抛射物转向目标
local function RotateToTarget(inst,dest,delta)
    local current = Vector3(inst.Transform:GetWorldPosition() )
    local direction = (dest - current):GetNormalized()
    local angle = math.acos(direction:Dot(Vector3(1, 0, 0) ) ) / DEGREES
    inst.Transform:SetRotation(angle+(delta or 0))
    inst:FacePoint(dest)
end

-----------判定是不是同方向的向量
local function IsSameFaceVect(vec1,vec2)
	local x1,y1,z1 = vec1:Get()
	local x2,y2,z2 = vec2:Get()
	return (x1*x2 + y1*y2 + z1*z2 > 0) 
end 

-----------霰弹枪额外伤害
local function DoExtraAeraAttack(inst,dest,vect,radius)
	local x,y,z = dest:Get()---------枪火花坐标
	local ents = TheSim:FindEntities(x,y,z,radius or 3.5,{"_combat"})
	for k,v in pairs(ents) do 
		if v and v:IsValid() and v.components.combat and v.components.health and not v.components.health:IsDead() then 
			local vx,vy,vz = v:GetPosition():Get()
			local dx,dy,dz = vx-x,vy-y,vz-z
			local vect_v = Vector3(vx-x,vy-y,vz-z)
			local dist = math.sqrt(dx*dx + dy*dy + dz*dz) 
			dist = math.max(dist,0.1)
			if IsSameFaceVect(vect,vect_v) then 
				local weapon = inst.components.combat:GetWeapon()
				v.components.combat:GetAttacked(inst,20/dist,weapon)
				if weapon and weapon:IsValid() then 
					weapon.components.weapon:OnAttack(inst, v)
				end
			end
		end 
	end
end 

local function DoYukiGunAtk(inst,level)
	local target = inst.components.combat.target
	local range = 2.5
	if target and target:IsValid() then 
		inst.components.combat:DoAttack()
		local x,y,z = inst:GetPosition():Get()
		local x2,y2,z2 = target:GetPosition():Get()
		local dx,dy,dz = x2 - x,y2 - y,z2 - z
		--[[inst.components.combat:DoAreaAttack(inst.components.combat.target,3, 
			inst.components.combat:GetWeapon(), nil, nil, { "INLIMBO" })--]]
		local fx = SpawnPrefab("yuki_gunfire_fx")
		local israining = TheWorld.state.israining
		if israining then 
			fx.AnimState:SetLayer(LAYER_WORLD)
		else 
			fx.AnimState:SetLayer(LAYER_WORLD_CEILING)
		end 
		fx.Transform:SetPosition(x,y,z)
		fx.Transform:SetScale(0.8,0.8,0.8)
		RotateToTarget(fx,target:GetPosition())
		fx.Transform:SetPosition(x + dx*range / math.sqrt(dx*dx + dz*dz),y,z+ dz*range / math.sqrt(dx*dx + dz*dz))
		DoExtraAeraAttack(inst,fx:GetPosition(),Vector3(dx,dy,dz),3)
	end 
	local weapon = inst.components.combat:GetWeapon()
	if weapon then 
		weapon.gunfire = SpawnPrefab("gunfire")
		weapon.gunfire.entity:AddFollower()
		weapon.gunfire.Follower:FollowSymbol(inst.GUID, "swap_object", 0, -250, 0)
	end 
	inst.SoundEmitter:PlaySound("yuki_gun/yuki_gun/atk"..level)
end 

AddStategraphState("wilson", 
 State{
		name = "yuki_gun_atk_pre",
        tags = { "attack", "notalking", "abouttoattack", "autopredict" },
		onenter = function(inst)
			local target = nil 
			inst.AnimState:OverrideSymbol("swap_object", "swap_yuki_gun", "swap_yuki_gun")
			inst.AnimState:Show("ARM_carry")
			inst.AnimState:Hide("ARM_normal")
			inst.AnimState:PlayAnimation("lunge_pre")
			
			if inst.bufferedaction ~= nil and inst.bufferedaction.target ~= nil and inst.bufferedaction.target:IsValid() then
                inst.sg.statemem.target = inst.bufferedaction.target
                inst.components.combat:SetTarget(inst.sg.statemem.target)
                inst:ForceFacePoint(inst.sg.statemem.target.Transform:GetWorldPosition())
				target = inst.sg.statemem.target
            end

            if target ~= nil and target:IsValid() then
                inst.sg.statemem.target = target
                inst:ForceFacePoint(target.Transform:GetWorldPosition())
            end
            inst.sg:SetTimeout(12 * FRAMES)
		end,
		timeline =
		{
			TimeEvent(4 * FRAMES, function(inst)
                inst.SoundEmitter:PlaySound("dontstarve/common/twirl", nil, nil, true)
            end),
		},

    ontimeout = function(inst)
		local target = inst.sg.statemem.target
		if target and target:IsValid() then 
			inst.sg:GoToState("yuki_gun_atk_loop",inst.sg.statemem.target)
		else
			inst.AnimState:Hide("ARM_carry")
			inst.AnimState:Show("ARM_normal")
			inst.sg:GoToState("idle")
		end 
    end,
	
	onexit = function(inst)
		inst.AnimState:Hide("ARM_carry")
		inst.AnimState:Show("ARM_normal")
	end 
		
}
)

AddStategraphState("wilson", 
 State{
		name = "yuki_gun_atk_loop",
        tags = { "attack", "notalking", "abouttoattack", "autopredict" },
		onenter = function(inst,target)
			inst.sg.statemem.target = target
			inst.components.combat:SetTarget(target)
			inst:ForceFacePoint(target.Transform:GetWorldPosition())
			inst.AnimState:OverrideSymbol("swap_object", "swap_yuki_gun", "swap_yuki_gun")
			inst.AnimState:Show("ARM_carry")
			inst.AnimState:Hide("ARM_normal")
			inst.AnimState:PlayAnimation("lunge_pst")
            inst.sg:SetTimeout(18 * FRAMES)
		end,
		timeline =
		{
			--[[TimeEvent(0.8 * FRAMES, function(inst)
                DoYukiGunAtk(inst,1)
            end),
			
			TimeEvent(1.6 * FRAMES, function(inst)
                DoYukiGunAtk(inst,2)
            end),--]]
			
			TimeEvent(1 * FRAMES, function(inst)
                DoYukiGunAtk(inst,3)
            end),
           
		},

    ontimeout = function(inst)
		local target = inst.sg.statemem.target
		if target and target:IsValid() and target.components.health and not target.components.health:IsDead() then 
			inst.sg:GoToState("yuki_gun_atk_loop",target)
		else 
			inst.sg:GoToState("yuki_gun_atk_pst")
		end 
    end,
	
	onexit = function(inst)
		inst.AnimState:Hide("ARM_carry")
		inst.AnimState:Show("ARM_normal")
	end 
	
		
}
)

AddStategraphState("wilson", 
	State{
		name = "yuki_gun_atk_pst",
        tags = { "attack", "notalking", "abouttoattack", "autopredict" },
		onenter = function(inst)
			inst.AnimState:OverrideSymbol("swap_object", "swap_yuki_gun", "swap_yuki_gun")
			inst.AnimState:Show("ARM_carry")
			inst.AnimState:Hide("ARM_normal")
			inst.AnimState:PlayAnimation("lunge_pre")
			inst.AnimState:PushAnimation("item_in")
		end,
		timeline =
		{
			
           
		},

		events =
		{
			EventHandler("animover", function(inst)
				if inst.AnimState:AnimDone() then
					inst.AnimState:Hide("ARM_carry")
					inst.AnimState:Show("ARM_normal")
					inst.sg:GoToState("idle")
				end
			end),
		},
		
		onexit = function(inst)
			inst.AnimState:Hide("ARM_carry")
			inst.AnimState:Show("ARM_normal")
		end 
		
	}
)


AddStategraphState("wilson_client", 
 State{
		name = "yuki_gun_atk_pre",
        tags = { "attack", "notalking", "abouttoattack", "autopredict" },
		onenter = function(inst)
			print("yuki_gun_atk_pre  client")
			local buffaction = inst:GetBufferedAction()
			local target = buffaction ~= nil and buffaction.target or nil
			if inst.replica.combat ~= nil then
				inst.replica.combat:StartAttack()
			end
			inst.components.locomotor:Stop()
        
			if target ~= nil then
				inst.AnimState:OverrideSymbol("swap_object", "swap_yuki_gun", "swap_yuki_gun")
				inst.AnimState:Show("ARM_carry")
				inst.AnimState:Hide("ARM_normal")
				inst.AnimState:PlayAnimation("lunge_pre")
			
				if buffaction ~= nil then
					inst:PerformPreviewBufferedAction()
					if buffaction.target ~= nil and buffaction.target:IsValid() then
						inst:FacePoint(buffaction.target:GetPosition())
						inst.sg.statemem.attacktarget = buffaction.target
					end
				end
				inst.sg:SetTimeout(12 * FRAMES)
			end 
		end,
		timeline =
		{
			TimeEvent(4 * FRAMES, function(inst)
				inst:ClearBufferedAction()
                inst.SoundEmitter:PlaySound("dontstarve/common/twirl", nil, nil, true)
            end),
		},

    ontimeout = function(inst)
		local target = inst.sg.statemem.attacktarget
		if target and target:IsValid() then 
			inst.sg:GoToState("yuki_gun_atk_loop",target)
		else
			inst.AnimState:Hide("ARM_carry")
			inst.AnimState:Show("ARM_normal")
		end 
    end,
	
	onexit = function(inst)
        if inst.sg:HasStateTag("abouttoattack") and inst.replica.combat ~= nil then
            inst.replica.combat:CancelAttack()
        end
		inst.AnimState:Hide("ARM_carry")
		inst.AnimState:Show("ARM_normal")
    end,
		
}
)

AddStategraphState("wilson_client", 
 State{
		name = "yuki_gun_atk_loop",
        tags = { "attack", "notalking", "abouttoattack", "autopredict" },
		onenter = function(inst,target)			
			inst.sg.statemem.attacktarget = target
			if inst.replica.combat ~= nil then
				inst.replica.combat:StartAttack()
			end
			inst.components.locomotor:Stop()
			if target ~= nil then
				inst.AnimState:OverrideSymbol("swap_object", "swap_yuki_gun", "swap_yuki_gun")
				inst.AnimState:Show("ARM_carry")
				inst.AnimState:Hide("ARM_normal")
				inst.AnimState:PlayAnimation("lunge_pst")
				inst.sg:SetTimeout(18 * FRAMES)
				inst:FacePoint(target:GetPosition())
			end 
		end,
		timeline =
		{
			--[[TimeEvent(0.8 * FRAMES, function(inst)
                DoYukiGunAtk(inst,1)
            end),
			
			TimeEvent(1.6 * FRAMES, function(inst)
                DoYukiGunAtk(inst,2)
            end),--]]
			
			TimeEvent(0.5 * FRAMES, function(inst)
				inst:ClearBufferedAction()
                --inst.SoundEmitter:PlaySound("yuki_gun/yuki_gun/atk3")
            end),
           
		},

    ontimeout = function(inst)
		local target = inst.sg.statemem.attacktarget
		if target and target:IsValid() and target.replica.health and not target.replica.health:IsDead() then 
			inst.sg:GoToState("yuki_gun_atk_loop",target)
		else 
			inst.sg:GoToState("yuki_gun_atk_pst")
		end 
    end,
	
	onexit = function(inst)
        if inst.sg:HasStateTag("abouttoattack") and inst.replica.combat ~= nil then
            inst.replica.combat:CancelAttack()
        end
		inst.AnimState:Hide("ARM_carry")
		inst.AnimState:Show("ARM_normal")
    end,
		
}
)

AddStategraphState("wilson_client", 
	State{
		name = "yuki_gun_atk_pst",
        tags = { "attack", "notalking", "abouttoattack", "autopredict" },
		onenter = function(inst)
			inst.AnimState:OverrideSymbol("swap_object", "swap_yuki_gun", "swap_yuki_gun")
			inst.AnimState:Show("ARM_carry")
			inst.AnimState:Hide("ARM_normal")
			inst.AnimState:PlayAnimation("lunge_pre")
			inst.AnimState:PushAnimation("item_in",false)
		end,
		timeline =
		{
			TimeEvent(4 * FRAMES, function(inst)
				inst:ClearBufferedAction()
                inst.SoundEmitter:PlaySound("dontstarve/common/twirl", nil, nil, true)
            end),
		},

		events =
		{
			EventHandler("animqueueover", function(inst)
				if inst.AnimState:AnimDone() then
					inst.AnimState:Hide("ARM_carry")
					inst.AnimState:Show("ARM_normal")
					inst.sg:GoToState("idle")
				end
			end),
		},
		onexit = function(inst)
			if inst.sg:HasStateTag("abouttoattack") and inst.replica.combat ~= nil then
				inst.replica.combat:CancelAttack()
			end
			inst.AnimState:Hide("ARM_carry")
			inst.AnimState:Show("ARM_normal")
		end,
	}
)

AddStategraphState("wilson", 
 State{
		name = "iceyatk_multithrust",
        tags = { "attack", "notalking", "abouttoattack", "autopredict" },
		onenter = function(inst)
			local target = nil 
			inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("multithrust")
            inst.Transform:SetEightFaced()
			
			if inst.bufferedaction ~= nil and inst.bufferedaction.target ~= nil and inst.bufferedaction.target:IsValid() then
                inst.sg.statemem.target = inst.bufferedaction.target
                inst.components.combat:SetTarget(inst.sg.statemem.target)
                inst:ForceFacePoint(inst.sg.statemem.target.Transform:GetWorldPosition())
				target = inst.sg.statemem.target
            end

            if target ~= nil and target:IsValid() then
                inst.sg.statemem.target = target
                inst:ForceFacePoint(target.Transform:GetWorldPosition())
            end

            inst.sg:SetTimeout(30 * FRAMES)
		end,
		timeline =
		{
			TimeEvent(7 * FRAMES, function(inst)
                inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon")
				inst:PerformBufferedAction()
				PushCQCEvent(inst,inst.components.combat.target,"multithrust")
            end),
            TimeEvent(9 * FRAMES, function(inst)
                inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon")
				inst.components.combat:DoAttack()
				if inst.components.combat.target then 
					inst.components.combat:DoAreaAttack(inst.components.combat.target,1.2, 
						inst.components.combat:GetWeapon(), nil, nil, { "INLIMBO" ,"companion"})
				end 
            end),
            TimeEvent(11 * FRAMES, function(inst)
                inst.sg.statemem.weapon = inst.components.combat:GetWeapon()
				inst.components.combat:DoAttack()
                --inst:PerformBufferedAction()
                DoThrust(inst)
            end),
            TimeEvent(13 * FRAMES, DoThrust),
            TimeEvent(15 * FRAMES, DoThrust),
            TimeEvent(17 * FRAMES, function(inst)
                DoThrust(inst, true)
            end),
            TimeEvent(19 * FRAMES, function(inst)
                DoThrust(inst, true)
                inst.sg:RemoveStateTag("nointerrupt")
            end),
		},

    ontimeout = function(inst)
        inst.sg:GoToState("idle", true)
    end,

    events =
    {
        EventHandler("animover", function(inst)
            if inst.AnimState:AnimDone() then
                inst.sg:GoToState("idle")
            end
        end),
    },

    onexit = function(inst)
        inst.components.combat:SetTarget(nil)
        inst.Transform:SetFourFaced()
        if ValidateMultiThruster(inst) then
            inst.sg.statemem.weapon.components.multithruster:StopThrusting(inst)
        end
    end,
		
}
)

AddStategraphState("wilson", 
 State{
		name = "iceyatk_chop",
        tags = { "attack", "notalking", "abouttoattack", "autopredict" },
		onenter = function(inst)
			local target = nil 
			inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation(inst.AnimState:IsCurrentAnimation("woodie_chop_loop") and inst.AnimState:GetCurrentAnimationTime() < 7.1 * FRAMES and "woodie_chop_atk_pre" or "woodie_chop_pre")
            inst.AnimState:PushAnimation("woodie_chop_loop", false)
			
			if inst.bufferedaction ~= nil and inst.bufferedaction.target ~= nil and inst.bufferedaction.target:IsValid() then
                inst.sg.statemem.target = inst.bufferedaction.target
                inst.components.combat:SetTarget(inst.sg.statemem.target)
                inst:ForceFacePoint(inst.sg.statemem.target.Transform:GetWorldPosition())
				target = inst.sg.statemem.target
            end

            if target ~= nil and target:IsValid() then
                inst.sg.statemem.target = target
                inst:ForceFacePoint(target.Transform:GetWorldPosition())
            end

            inst.sg:SetTimeout(9 * FRAMES)
		end,
		timeline =
		{
			TimeEvent(6 * FRAMES, function(inst)
                inst:PerformBufferedAction()
				PushCQCEvent(inst,inst.components.combat.target,"chop")
				if inst.components.combat.target then 
					inst.components.combat:DoAreaAttack(inst.components.combat.target,1.0, 
						inst.components.combat:GetWeapon(), nil, nil, { "INLIMBO" ,"companion"})
				end 
				inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon", nil, nil, true)
            end),
		},

    ontimeout = function(inst)
        inst.sg:GoToState("idle", true)
    end,

    events =
    {
        EventHandler("animover", function(inst)
            if inst.AnimState:AnimDone() then
                inst.sg:GoToState("idle")
            end
        end),
    },

    onexit = function(inst)
        inst.components.combat:SetTarget(nil)
    end,
		
}
)

AddStategraphState("wilson", 
 State{
		name = "iceyatk_hop",
        tags = { "attack", "notalking", "abouttoattack", "autopredict","nointerrupt" },
		onenter = function(inst,nohopattack)
			local target = nil 
			inst.sg.statemem.nohopattack = nohopattack
			inst.components.locomotor:Stop()
			inst.AnimState:PlayAnimation("atk_leap")
            inst.SoundEmitter:PlaySound("dontstarve/common/deathpoof")
			
			if inst.bufferedaction ~= nil and inst.bufferedaction.target ~= nil and inst.bufferedaction.target:IsValid() then
                inst.sg.statemem.target = inst.bufferedaction.target
                inst.components.combat:SetTarget(inst.sg.statemem.target)
                inst:ForceFacePoint(inst.sg.statemem.target.Transform:GetWorldPosition())
				target = inst.sg.statemem.target
            end

            if target ~= nil and target:IsValid() then
                inst.sg.statemem.target = target
                inst:ForceFacePoint(target.Transform:GetWorldPosition())
				inst.sg.statemem.targetpos = target:GetPosition()
            end
			
			
            inst.sg:SetTimeout(30 * FRAMES)
		end,
		
		onupdate = function(inst)
            if inst.sg.statemem.flash and inst.sg.statemem.flash > 0 then
                inst.sg.statemem.flash = math.max(0, inst.sg.statemem.flash - .1)
                local c = math.min(1, inst.sg.statemem.flash)
                inst.components.colouradder:PushColour("leap", 0,c,c, 0)
            end
        end,
		
		timeline =
		{
			TimeEvent(4 * FRAMES, function(inst)
                if inst.sg.statemem.targetfx ~= nil and inst.sg.statemem.targetfx:IsValid() then
                    (inst.sg.statemem.targetfx.KillFX or inst.sg.statemem.targetfx.Remove)(inst.sg.statemem.targetfx)
                    inst.sg.statemem.targetfx = nil
                end
            end),
            TimeEvent(9 * FRAMES, function(inst)
                inst.components.colouradder:PushColour("leap", 0, 0.1, 0.1, 0)
            end),
			TimeEvent(10 * FRAMES, function(inst)
                ShakeAllCameras(CAMERASHAKE.VERTICAL, .7, .015, .8, inst, 20)
                inst.components.bloomer:PushBloom("leap", "shaders/anim.ksh", -2)
                inst.components.colouradder:PushColour("leap", 0, 1, 1, 0)
                inst.sg:RemoveStateTag("nointerrupt")
				if not inst.sg.statemem.nohopattack then 
					inst:PerformBufferedAction()
					PushCQCEvent(inst,inst.components.combat.target,"hop")
					inst.components.combat:DoAttack()
					if inst.components.combat.target then 
						inst.components.combat:DoAreaAttack(inst.components.combat.target,2.5, 
							inst.components.combat:GetWeapon(), nil, nil, { "INLIMBO","companion" })
					end 
				end 
				inst.SoundEmitter:PlaySound("dontstarve/common/destroy_smoke",nil,nil,true)
            end),
            TimeEvent(11 * FRAMES, function(inst)
                inst.components.colouradder:PushColour("leap", 0, 0.3, 0.3, 0)
            end),
            TimeEvent(12 * FRAMES, function(inst)
                inst.components.colouradder:PushColour("leap", 0, 0.6, 0.6, 0)
                ToggleOnPhysics(inst)
                inst.Physics:Stop()
                inst.Physics:SetMotorVel(0, 0, 0)
				inst.sg.statemem.flash = 1.3
				--[[if inst.sg.statemem.targetpos then 
					inst.Physics:Teleport(inst.sg.statemem.targetpos.x, 0, inst.sg.statemem.targetpos.z)
				end --]]
            end),
           
            TimeEvent(25 * FRAMES, function(inst)
                inst.components.bloomer:PopBloom("leap")
            end),
		},

    ontimeout = function(inst)
        inst.sg:GoToState("idle", true)
    end,

    events =
    {
        EventHandler("animover", function(inst)
            if inst.AnimState:AnimDone() then
                inst.sg:GoToState("idle")
            end
        end),
    },

    onexit = function(inst)
		inst.sg.statemem.nohopattack = nil 
        inst.components.combat:SetTarget(nil)
		if inst.sg.statemem.isphysicstoggle then
            ToggleOnPhysics(inst)
            inst.Physics:Stop()
            inst.Physics:SetMotorVel(0, 0, 0)
            --[[local x, y, z = inst.Transform:GetWorldPosition()
            if TheWorld.Map:IsPassableAtPoint(x, 0, z) and not TheWorld.Map:IsGroundTargetBlocked(Vector3(x, 0, z)) then
                inst.Physics:Teleport(x, 0, z)
            else
                inst.Physics:Teleport(inst.sg.statemem.targetpos.x, 0, inst.sg.statemem.targetpos.z)
            end--]]
        end
        inst.components.bloomer:PopBloom("leap")
        inst.components.colouradder:PopColour("leap")
        if inst.sg.statemem.targetfx ~= nil and inst.sg.statemem.targetfx:IsValid() then
            (inst.sg.statemem.targetfx.KillFX or inst.sg.statemem.targetfx.Remove)(inst.sg.statemem.targetfx)
        end
    end,
		
}
)

AddStategraphState("wilson", 
 State{
		name = "iceyatk_lunge",
        tags = { "attack", "notalking", "abouttoattack", "autopredict" ,"nointerrupt"},
		onenter = function(inst,data)
			local target = nil  
			inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("lunge_pst")
            inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon",nil,nil,true)
			
			
			if inst.bufferedaction ~= nil and inst.bufferedaction.target ~= nil and inst.bufferedaction.target:IsValid() then
                inst.sg.statemem.target = inst.bufferedaction.target
                inst.components.combat:SetTarget(inst.sg.statemem.target)
                inst:ForceFacePoint(inst.sg.statemem.target.Transform:GetWorldPosition())
				target = inst.sg.statemem.target
            end
			if data and data.target then 
				target = data.target
			end 
            if target ~= nil and target:IsValid() then
                inst.sg.statemem.target = target
				inst.components.combat:SetTarget(target)
                inst:ForceFacePoint(target.Transform:GetWorldPosition())
            end
			
			inst.SoundEmitter:PlaySound("dontstarve/common/lava_arena/fireball",nil,nil,true)
			inst.components.bloomer:PushBloom("lunge", "shaders/anim.ksh", -2)
            inst.components.colouradder:PushColour("lunge", 0, 1, 1, 0)
			inst.sg.statemem.flash = 0.6
            inst.sg:SetTimeout(8 * FRAMES)
		end,
		
		onupdate = function(inst)
            if inst.sg.statemem.flash and inst.sg.statemem.flash > 0 then
                inst.sg.statemem.flash = math.max(0, inst.sg.statemem.flash - .1)
                inst.components.colouradder:PushColour("lunge", 0, inst.sg.statemem.flash, inst.sg.statemem.flash, 0)
            end
        end,
		
		timeline =
		{
			TimeEvent(2 * FRAMES, function(inst)
				
                inst:PerformBufferedAction()
				PushCQCEvent(inst,inst.components.combat.target,"lunge")
				if inst.components.combat.target then 
					inst.components.combat:DoAreaAttack(inst.components.combat.target,1.3, 
						inst.components.combat:GetWeapon(), nil, nil, { "INLIMBO","companion" })
				end 
				inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon", nil, nil, true)
            end),
			
			TimeEvent(7 * FRAMES, function(inst)
                inst.components.bloomer:PopBloom("lunge")
            end),
		},

    ontimeout = function(inst)
        inst.sg:GoToState("idle", true)
    end,

    events =
    {
        EventHandler("animover", function(inst)
            if inst.AnimState:AnimDone() then
                inst.sg:GoToState("idle")
            end
        end),
    },

    onexit = function(inst)
        inst.components.combat:SetTarget(nil)
		inst.components.bloomer:PopBloom("lunge")
        inst.components.colouradder:PopColour("lunge")
    end,
		
}
)

AddStategraphState("wilson", 
 State{
		name = "storm_controlor_attack",
        tags = { "attack", "notalking", "abouttoattack", "autopredict" },
		onenter = function(inst)
			local target = nil 
			inst.components.locomotor:Stop()
			inst.AnimState:PlayAnimation("atk_leap")
            inst.SoundEmitter:PlaySound("dontstarve/common/deathpoof")
			
			if inst.bufferedaction ~= nil and inst.bufferedaction.target ~= nil and inst.bufferedaction.target:IsValid() then
                inst.sg.statemem.target = inst.bufferedaction.target
                inst.components.combat:SetTarget(inst.sg.statemem.target)
                inst:ForceFacePoint(inst.sg.statemem.target.Transform:GetWorldPosition())
				target = inst.sg.statemem.target
            end

            if target ~= nil and target:IsValid() then
                inst.sg.statemem.target = target
                inst:ForceFacePoint(target.Transform:GetWorldPosition())
				inst.sg.statemem.targetpos = target:GetPosition()
            end
			
			
            inst.sg:SetTimeout(30 * FRAMES)
		end,
		
		onupdate = function(inst)
            if inst.sg.statemem.flash and inst.sg.statemem.flash > 0 then
                inst.sg.statemem.flash = math.max(0, inst.sg.statemem.flash - .1)
                local c = math.min(1, inst.sg.statemem.flash)
                inst.components.colouradder:PushColour("leap", 0,c,c, 0)
            end
        end,
		
		timeline =
		{
			TimeEvent(4 * FRAMES, function(inst)
                if inst.sg.statemem.targetfx ~= nil and inst.sg.statemem.targetfx:IsValid() then
                    (inst.sg.statemem.targetfx.KillFX or inst.sg.statemem.targetfx.Remove)(inst.sg.statemem.targetfx)
                    inst.sg.statemem.targetfx = nil
                end
            end),
            TimeEvent(9 * FRAMES, function(inst)
                inst.components.colouradder:PushColour("leap", 0, 0.1, 0.1, 0)
            end),
			TimeEvent(10 * FRAMES, function(inst)
                ShakeAllCameras(CAMERASHAKE.VERTICAL, .7, .015, .8, inst, 20)
                inst.components.bloomer:PushBloom("leap", "shaders/anim.ksh", -2)
                inst.components.colouradder:PushColour("leap", 0, 1, 1, 0)
                inst.sg:RemoveStateTag("nointerrupt")
				--inst.components.combat:DoAttack()
				--inst.components.combat:DoAttack()
				--if inst.components.combat.target then 
					--inst.components.combat:DoAreaAttack(inst.components.combat.target,2.5, 
						--inst.components.combat:GetWeapon(), nil, nil, { "INLIMBO","companion" })
				--end 
				local weapon = inst.components.combat:GetWeapon()
				weapon:StormAttack(inst,inst.components.combat.target)
				inst.SoundEmitter:PlaySound("dontstarve/common/destroy_smoke",nil,nil,true)
            end),
            TimeEvent(11 * FRAMES, function(inst)
                inst.components.colouradder:PushColour("leap", 0, 0.3, 0.3, 0)
            end),
            TimeEvent(12 * FRAMES, function(inst)
                inst.components.colouradder:PushColour("leap", 0, 0.6, 0.6, 0)
                ToggleOnPhysics(inst)
                inst.Physics:Stop()
                inst.Physics:SetMotorVel(0, 0, 0)
				inst.sg.statemem.flash = 1.3
				--[[if inst.sg.statemem.targetpos then 
					inst.Physics:Teleport(inst.sg.statemem.targetpos.x, 0, inst.sg.statemem.targetpos.z)
				end --]]
            end),
           
            TimeEvent(25 * FRAMES, function(inst)
                inst.components.bloomer:PopBloom("leap")
            end),
		},

    ontimeout = function(inst)
        inst.sg:GoToState("idle", true)
    end,

    events =
    {
        EventHandler("animover", function(inst)
            if inst.AnimState:AnimDone() then
                inst.sg:GoToState("idle")
            end
        end),
    },

    onexit = function(inst)
        inst.components.combat:SetTarget(nil)
		if inst.sg.statemem.isphysicstoggle then
            ToggleOnPhysics(inst)
            inst.Physics:Stop()
            inst.Physics:SetMotorVel(0, 0, 0)
            --[[local x, y, z = inst.Transform:GetWorldPosition()
            if TheWorld.Map:IsPassableAtPoint(x, 0, z) and not TheWorld.Map:IsGroundTargetBlocked(Vector3(x, 0, z)) then
                inst.Physics:Teleport(x, 0, z)
            else
                inst.Physics:Teleport(inst.sg.statemem.targetpos.x, 0, inst.sg.statemem.targetpos.z)
            end--]]
        end
        inst.components.bloomer:PopBloom("leap")
        inst.components.colouradder:PopColour("leap")
        if inst.sg.statemem.targetfx ~= nil and inst.sg.statemem.targetfx:IsValid() then
            (inst.sg.statemem.targetfx.KillFX or inst.sg.statemem.targetfx.Remove)(inst.sg.statemem.targetfx)
        end
    end,
		
}
)

AddStategraphState("wilson", 
 State{
		name = "iceyatk_prop",
        tags = { "doing", "busy", "notalking", "autopredict","nointerrupt"},
		onenter = function(inst,data)
			local target = nil  
			inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("atk_prop_pre")
            inst.AnimState:PushAnimation("atk_prop",false)
            inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_whoosh")
			
			
			if inst.bufferedaction ~= nil and inst.bufferedaction.target ~= nil and inst.bufferedaction.target:IsValid() then
                inst.sg.statemem.target = inst.bufferedaction.target
                inst.components.combat:SetTarget(inst.sg.statemem.target)
                inst:ForceFacePoint(inst.sg.statemem.target.Transform:GetWorldPosition())
				target = inst.sg.statemem.target
            end
			if data and data.target then 
				target = data.target
			end 
            if target ~= nil and target:IsValid() then
                inst.sg.statemem.target = target
				inst.components.combat:SetTarget(target)
                inst:ForceFacePoint(target.Transform:GetWorldPosition())
            end
		end,
		

		
		timeline =
		{
			TimeEvent(FRAMES*6, function(inst)
                local dist = .8
                local radius = 1.7
                inst.components.combat.ignorehitrange = true
                local x0, y0, z0 = inst.Transform:GetWorldPosition()
                local angle = (inst.Transform:GetRotation() + 90) * DEGREES
                local sinangle = math.sin(angle)
                local cosangle = math.cos(angle)
                local x = x0 + dist * sinangle
                local z = z0 + dist * cosangle
                for i, v in ipairs(TheSim:FindEntities(x, y0, z, radius + 3, { "_combat" }, { "flying", "FX", "NOCLICK", "DECOR", "INLIMBO", "playerghost" })) do
                    if v:IsValid() and not v:IsInLimbo() and
                        not (v.components.health ~= nil and v.components.health:IsDead()) then
                        local range = radius + v:GetPhysicsRadius(.5)
                        if v:GetDistanceSqToPoint(x, y0, z) < range * range and inst.components.combat:CanTarget(v) and canattack(v,inst) then
                            --dummy redirected so that players don't get red blood flash
                            --v:PushEvent("attacked", { attacker = inst, damage = 0, redirected = v })
                            --v:PushEvent("knockback", { knocker = inst, radius = radius + dist, propsmashed = true })
							--v.components.combat:GetAttacked(inst,)
							inst.components.combat:DoAttack(v)
							KnockBackTarget(inst,v,Vector3(x,y,z),radius,dist)
                            inst.sg.statemem.smashed = true
                        end
                    end
                end
                inst.components.combat.ignorehitrange = false
                if inst.sg.statemem.smashed then
                    local prop = inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
                    if prop ~= nil then
                        dist = dist + radius - .5
                        inst.sg.statemem.smashed = { prop = prop, pos = Vector3(x0 + dist * sinangle, y0, z0 + dist * cosangle) }
                    else
                        inst.sg.statemem.smashed = nil
                    end
                end
            end),
            TimeEvent(8 * FRAMES, function(inst)
                if inst.sg.statemem.smashed ~= nil then
                    local smashed = inst.sg.statemem.smashed
                    inst.sg.statemem.smashed = false
                    smashed.prop:PushEvent("propsmashed", smashed.pos)
                end
            end),
            TimeEvent(19 * FRAMES, function(inst)
                inst.sg:GoToState("idle", true)
            end),
		},



    events =
    {
        EventHandler("unequip", function(inst)
            if inst.sg.statemem.smashed == nil then
                inst.sg:GoToState("idle")
            end
        end),
        EventHandler("animover", function(inst)
            if inst.AnimState:AnimDone() then
                inst.sg:GoToState("idle")
            end
        end),
    },

    onexit = function(inst)
        if inst.sg.statemem.smashed then --could be false, so don't nil check
            inst.sg.statemem.smashed.prop:PushEvent("propsmashed", inst.sg.statemem.smashed.pos)
        end
    end,
		
}
)

AddStategraphState("wilson", 
 State{
		name = "iceyatk_circle",
        tags = { "attack", "notalking", "abouttoattack", "nopredict" ,"nointerrupt"},
		onenter = function(inst,data)
			local target = nil  
			inst.components.locomotor:Stop()
			inst.AnimState:SetDeltaTimeMultiplier(2)
            inst.AnimState:PlayAnimation("iceyatk_circle1")
			inst.AnimState:PushAnimation("iceyatk_circle2",false)
			inst.AnimState:PushAnimation("iceyatk_circle3",false)
			--inst.AnimState:PlayAnimation("side0")
			--inst.AnimState:PlayAnimation("side1")
			--inst.AnimState:PushAnimation("side2",false)
			--inst.AnimState:PushAnimation("side3",false)
            inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon",nil,nil,true)
			
			
			if inst.bufferedaction ~= nil and inst.bufferedaction.target ~= nil and inst.bufferedaction.target:IsValid() then
                inst.sg.statemem.target = inst.bufferedaction.target
                inst.components.combat:SetTarget(inst.sg.statemem.target)
                inst:ForceFacePoint(inst.sg.statemem.target.Transform:GetWorldPosition())
				target = inst.sg.statemem.target
            end
			if data and data.target then 
				target = data.target
			end 
            if target ~= nil and target:IsValid() then
                inst.sg.statemem.target = target
				inst.components.combat:SetTarget(target)
                inst:ForceFacePoint(target.Transform:GetWorldPosition())
            end
			
			inst.SoundEmitter:PlaySound("dontstarve/common/lava_arena/fireball",nil,nil,true)
            inst.sg:SetTimeout(8 * FRAMES)
		end,
		
		
		timeline =
		{
			TimeEvent(1 * FRAMES, function(inst)
				
                inst.components.combat:DoAttack()
				if inst.components.combat.target then 
					inst.components.combat:DoAreaAttack(inst,2.3, 
						inst.components.combat:GetWeapon(), nil, nil, { "INLIMBO","companion" })
				end 
				PushCQCEvent(inst,inst.components.combat.target,"circle")
				inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon", nil, nil, true)
            end),
		},

    ontimeout = function(inst)
        inst.sg:GoToState("idle", true)
    end,

    events =
    {
        EventHandler("animover", function(inst)
            if inst.AnimState:AnimDone() then
                inst.sg:GoToState("idle")
            end
        end),
		EventHandler("onhitother", function(inst,data)
			SpawnPrefab("icey_weaponsparks"):SetPosition(inst,data.target)
			local target_pos = data.target:GetPosition()
			local function RotateFX(fx)
				fx.Transform:SetPosition(target_pos:Get())
				fx.Transform:SetRotation(inst.Transform:GetRotation())
			end
			local rand = math.random(1,2)
			if rand == 1 then
				RotateFX(SpawnPrefab("shadowstrike_slash_fx"))
			else
				RotateFX(SpawnPrefab("shadowstrike_slash2_fx"))
			end
		end),
    },

    onexit = function(inst)
        inst.components.combat:SetTarget(nil)
		inst.AnimState:SetDeltaTimeMultiplier(1)
    end,
		
}
)

AddStategraphState("wilson_client", 
 State{
		name = "iceyatk_multithrust",
        tags = { "attack", "notalking", "abouttoattack", "autopredict" },
		onenter = function(inst)
            local buffaction = inst:GetBufferedAction()
			local target = buffaction ~= nil and buffaction.target or nil
			if inst.replica.combat ~= nil then
				inst.replica.combat:StartAttack()
			end
			inst.components.locomotor:Stop()
			inst.Transform:SetEightFaced()
			if target ~= nil then
				inst.AnimState:PlayAnimation("multithrust")
				if buffaction ~= nil then
					inst:PerformPreviewBufferedAction()
					if buffaction.target ~= nil and buffaction.target:IsValid() then
						inst:FacePoint(buffaction.target:GetPosition())
						inst.sg.statemem.attacktarget = buffaction.target
					end
				end
				inst.sg:SetTimeout(28 * FRAMES)
			end 
		end,
		timeline =
		{
			TimeEvent(7 * FRAMES, function(inst)
				inst:ClearBufferedAction()
				 inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon")
            end),
            TimeEvent(9 * FRAMES, function(inst)
				inst:ClearBufferedAction()
				inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon")
            end),
            TimeEvent(11 * FRAMES, function(inst)
                inst:ClearBufferedAction()
				inst.sg:RemoveStateTag("abouttoattack")
            end),
            TimeEvent(19 * FRAMES, function(inst)
                inst.sg:RemoveStateTag("nointerrupt")
            end),
		},

    ontimeout = function(inst)
		inst.sg:RemoveStateTag("abouttoattack")
        inst.sg:RemoveStateTag("attack")
        inst.sg:AddStateTag("idle")
        inst.sg:GoToState("idle", true)
    end,

    events =
    {
        EventHandler("animqueueover", function(inst)
            if inst.AnimState:AnimDone() then
                inst.sg:GoToState("idle")
            end
        end),
    },

    onexit = function(inst)
        inst.Transform:SetFourFaced()
		if inst.sg:HasStateTag("abouttoattack") and inst.replica.combat ~= nil then
            inst.replica.combat:CancelAttack()
        end
    end,
		
}
)

AddStategraphState("wilson_client", 
 State{
		name = "iceyatk_chop",
        tags = { "attack", "notalking", "abouttoattack", "autopredict" },
		onenter = function(inst)
        local buffaction = inst:GetBufferedAction()
		local target = buffaction ~= nil and buffaction.target or nil
        if inst.replica.combat ~= nil then
            inst.replica.combat:StartAttack()
        end
        inst.components.locomotor:Stop()
        
		if target ~= nil then
			inst.AnimState:PlayAnimation(inst.AnimState:IsCurrentAnimation("woodie_chop_loop") 
			and inst.AnimState:GetCurrentAnimationTime() < 7.1 * FRAMES 
			and "woodie_chop_atk_pre" or "woodie_chop_pre")
            inst.AnimState:PushAnimation("woodie_chop_loop", false)
			
			if buffaction ~= nil then
				inst:PerformPreviewBufferedAction()
				if buffaction.target ~= nil and buffaction.target:IsValid() then
					inst:FacePoint(buffaction.target:GetPosition())
					inst.sg.statemem.attacktarget = buffaction.target
				end
			end
			inst.sg:SetTimeout(9 * FRAMES)
		end 
			

            
		end,
		timeline =
		{
			TimeEvent(6 * FRAMES, function(inst)
                inst:ClearBufferedAction()
				inst.sg:RemoveStateTag("abouttoattack")
				inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon", nil, nil, true)
            end),
		},

    ontimeout = function(inst)
		inst.sg:RemoveStateTag("abouttoattack")
        inst.sg:RemoveStateTag("attack")
        inst.sg:AddStateTag("idle")
        inst.sg:GoToState("idle", true)
    end,

    events =
    {
        EventHandler("animqueueover", function(inst)
            if inst.AnimState:AnimDone() then
                inst.sg:GoToState("idle")
            end
        end),
    },

	onexit = function(inst)
        if inst.sg:HasStateTag("abouttoattack") and inst.replica.combat ~= nil then
            inst.replica.combat:CancelAttack()
        end
    end,
}
)

AddStategraphState("wilson_client", 
 State{
		name = "iceyatk_hop",
        tags = { "attack", "notalking", "abouttoattack", "autopredict","nointerrupt" },
		onenter = function(inst)
        local buffaction = inst:GetBufferedAction()
		local target = buffaction ~= nil and buffaction.target or nil
        if inst.replica.combat ~= nil then
            inst.replica.combat:StartAttack()
        end
        inst.components.locomotor:Stop()
        
		if target ~= nil then
			inst.AnimState:PlayAnimation("atk_leap")
            inst.SoundEmitter:PlaySound("dontstarve/common/deathpoof")
			
			if buffaction ~= nil then
				inst:PerformPreviewBufferedAction()
				if buffaction.target ~= nil and buffaction.target:IsValid() then
					inst:FacePoint(buffaction.target:GetPosition())
					inst.sg.statemem.attacktarget = buffaction.target
				end
			end
			inst.sg:SetTimeout(30 * FRAMES)
		end 
			

            
		end,
		timeline =
		{
			TimeEvent(10 * FRAMES, function(inst)
                inst.SoundEmitter:PlaySound("dontstarve/common/destroy_smoke",nil,nil,true)
            end),
			
			TimeEvent(12 * FRAMES, function(inst)
                inst:ClearBufferedAction()
				inst.sg:RemoveStateTag("abouttoattack")
            end),
		},

    ontimeout = function(inst)
		inst.sg:RemoveStateTag("abouttoattack")
        inst.sg:RemoveStateTag("attack")
        inst.sg:AddStateTag("idle")
        inst.sg:GoToState("idle", true)
    end,

    events =
    {
        EventHandler("animqueueover", function(inst)
            if inst.AnimState:AnimDone() then
                inst.sg:GoToState("idle")
            end
        end),
    },

	onexit = function(inst)
        if inst.sg:HasStateTag("abouttoattack") and inst.replica.combat ~= nil then
            inst.replica.combat:CancelAttack()
        end
    end,
}
)

AddStategraphState("wilson_client", 
 State{
		name = "iceyatk_lunge",
        tags = { "attack", "notalking", "abouttoattack", "autopredict","nointerrupt" },
		onenter = function(inst,data)
        local buffaction = inst:GetBufferedAction()
		local target = (buffaction ~= nil and buffaction.target) or (data and data.target) or nil 
        if inst.replica.combat ~= nil then
            inst.replica.combat:StartAttack()
        end
        inst.components.locomotor:Stop()
        
		if target ~= nil then
			inst:ForceFacePoint(target:GetPosition():Get())
			inst.AnimState:PlayAnimation("lunge_pst")
			inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon",nil,nil,true)
			inst.SoundEmitter:PlaySound("dontstarve/common/lava_arena/fireball",nil,nil,true)
			if buffaction ~= nil then
				inst:PerformPreviewBufferedAction()
				if buffaction.target ~= nil and buffaction.target:IsValid() then
					inst.sg.statemem.attacktarget = buffaction.target
				end
			end
			inst.sg:SetTimeout(8 * FRAMES)
		end 
			

            
		end,
		timeline =
		{
			TimeEvent(2 * FRAMES, function(inst)
                inst:ClearBufferedAction()
				inst.sg:RemoveStateTag("abouttoattack")
				inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon", nil, nil, true)
            end),
		},

    ontimeout = function(inst)
		inst.sg:RemoveStateTag("abouttoattack")
        inst.sg:RemoveStateTag("attack")
        inst.sg:AddStateTag("idle")
        inst.sg:GoToState("idle", true)
    end,

    events =
    {
        EventHandler("animqueueover", function(inst)
            if inst.AnimState:AnimDone() then
                inst.sg:GoToState("idle")
            end
        end),
    },

	onexit = function(inst)
        if inst.sg:HasStateTag("abouttoattack") and inst.replica.combat ~= nil then
            inst.replica.combat:CancelAttack()
        end
    end,
}
)

AddStategraphState("wilson_client", 
 State{
		name = "storm_controlor_attack",
        tags = { "attack", "notalking", "abouttoattack", "autopredict","nointerrupt" },
		onenter = function(inst)
        local buffaction = inst:GetBufferedAction()
		local target = buffaction ~= nil and buffaction.target or nil
        if inst.replica.combat ~= nil then
            inst.replica.combat:StartAttack()
        end
        inst.components.locomotor:Stop()
        
		if target ~= nil then
			inst.AnimState:PlayAnimation("atk_leap")
            inst.SoundEmitter:PlaySound("dontstarve/common/deathpoof")
			
			if buffaction ~= nil then
				inst:PerformPreviewBufferedAction()
				if buffaction.target ~= nil and buffaction.target:IsValid() then
					inst:FacePoint(buffaction.target:GetPosition())
					inst.sg.statemem.attacktarget = buffaction.target
				end
			end
			inst.sg:SetTimeout(30 * FRAMES)
		end 
			

            
		end,
		timeline =
		{
			TimeEvent(10 * FRAMES, function(inst)
                inst.SoundEmitter:PlaySound("dontstarve/common/destroy_smoke",nil,nil,true)
            end),
			
			TimeEvent(12 * FRAMES, function(inst)
                inst:ClearBufferedAction()
				inst.sg:RemoveStateTag("abouttoattack")
            end),
		},

    ontimeout = function(inst)
		inst.sg:RemoveStateTag("abouttoattack")
        inst.sg:RemoveStateTag("attack")
        inst.sg:AddStateTag("idle")
        inst.sg:GoToState("idle", true)
    end,

    events =
    {
        EventHandler("animqueueover", function(inst)
            if inst.AnimState:AnimDone() then
                inst.sg:GoToState("idle")
            end
        end),
    },

	onexit = function(inst)
        if inst.sg:HasStateTag("abouttoattack") and inst.replica.combat ~= nil then
            inst.replica.combat:CancelAttack()
        end
    end,
}
)


AddStategraphState("wilson_client", 
    State
    {
        name = "iceyatk_prop",
        tags = {"doing", "busy","attack","autopredict","nointerrupt"  },

        onenter = function(inst)
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("atk_prop_pre")
            inst.AnimState:PushAnimation("atk_prop",false)
            --inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_whoosh")

            inst:PerformPreviewBufferedAction()
            inst.sg:SetTimeout(2)
        end,

        onupdate = function(inst)
            if inst:HasTag("busy") then
                if inst.entity:FlattenMovementPrediction() then
                    inst.sg:GoToState("idle", "noanim")
                end
            elseif inst.bufferedaction == nil then
                inst.sg:GoToState("idle")
            end
        end,

        ontimeout = function(inst)
            inst:ClearBufferedAction()
            inst.sg:GoToState("idle")
        end,
    }
)

AddStategraphState("wilson_client", 
 State{
		name = "iceyatk_circle",
        tags = { "attack", "notalking", "abouttoattack", "nopredict" ,"nointerrupt"},
		onenter = function(inst,data)
			local buffaction = inst:GetBufferedAction()
			local target = (buffaction ~= nil and buffaction.target) or (data and data.target) or nil 
			if inst.replica.combat ~= nil then
				inst.replica.combat:StartAttack()
			end
			
			if target ~= nil then
				inst:ForceFacePoint(target:GetPosition():Get())
				inst.AnimState:SetDeltaTimeMultiplier(2)
				inst.AnimState:PlayAnimation("iceyatk_circle1")
				inst.AnimState:PushAnimation("iceyatk_circle2",false)
				inst.AnimState:PushAnimation("iceyatk_circle3",false)
				--inst.AnimState:PlayAnimation("side0")
				--inst.AnimState:PlayAnimation("side1")
				--inst.AnimState:PushAnimation("side2",false)
				--inst.AnimState:PushAnimation("side3",false)
				inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon",nil,nil,true)
				inst.SoundEmitter:PlaySound("dontstarve/common/lava_arena/fireball",nil,nil,true)
				if buffaction ~= nil then
					inst:PerformPreviewBufferedAction()
					if buffaction.target ~= nil and buffaction.target:IsValid() then
						inst.sg.statemem.attacktarget = buffaction.target
					end
				end
				inst.sg:SetTimeout(8 * FRAMES)
			end 
		end,
		
		timeline =
		{
			TimeEvent(4 * FRAMES, function(inst)
				inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon", nil, nil, true)
            end),
		},

    ontimeout = function(inst)
        inst.sg:GoToState("idle", true)
    end,

    events =
    {
        EventHandler("animover", function(inst)
            if inst.AnimState:AnimDone() then
                inst.sg:GoToState("idle")
            end
        end),
    },

    onexit = function(inst)
        inst.replica.combat:SetTarget(nil)
		inst.AnimState:SetDeltaTimeMultiplier(1)
    end,
		
}
)

AddStategraphState("wilson", 
	State{
        name = "iceygun_shoot",
        tags = {"attack", "notalking", "abouttoattack", "busy","nopredict"},
        
        onenter = function(inst,data)
			--[[local target = nil  
			if data and data.target then 
				target = data.target
			end 
			inst.components.locomotor:Stop()
			if inst.bufferedaction ~= nil and inst.bufferedaction.target ~= nil and inst.bufferedaction.target:IsValid() then
                inst.sg.statemem.target = inst.bufferedaction.target
                inst.components.combat:SetTarget(inst.sg.statemem.target)
                inst:ForceFacePoint(inst.sg.statemem.target.Transform:GetWorldPosition())
				target = inst.sg.statemem.target
            end
			
            if target ~= nil and target:IsValid() then
                inst.sg.statemem.target = target
				inst.components.combat:SetTarget(target)
                inst:ForceFacePoint(target.Transform:GetWorldPosition())
            end

            inst.components.combat:StartAttack()--]]
			
			local weapon = inst.components.combat:GetWeapon()
			
			if weapon:HasTag("gun_without_bullet") then 
				inst.sg:GoToState("idle")
				return 
			end 
			
			IceyCommonStates.SGAttackOnEnterServer(inst,15 * FRAMES)
			inst.AnimState:SetDeltaTimeMultiplier(2.5)
			
            
            local otherequipped = inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
            if (weapon and weapon:HasTag("hand_gun")) or (otherequipped and otherequipped:HasTag("hand_gun")) then
                inst.AnimState:PlayAnimation("hand_shoot")
            else
                inst.AnimState:PlayAnimation("shoot")
            end
			
			if weapon.startgunsound then 
				inst.SoundEmitter:PlaySound(weapon.startgunsound)
			end

        end,
        
        timeline=
        {
			--17
            TimeEvent(7*FRAMES, function(inst) 
				local weapon = inst.sg.statemem.weapon
                inst:PerformBufferedAction()
				inst.SoundEmitter:PlaySound(weapon and weapon.gunshootsound or "dontstarve_DLC003/common/items/weapon/blunderbuss_shoot")
				inst.AnimState:SetDeltaTimeMultiplier(1)
                inst.sg:RemoveStateTag("abouttoattack") 
            end),   
			--20         
            TimeEvent(8*FRAMES, function(inst)
                inst.sg:RemoveStateTag("attack")
            end),           
            
        },
		
		onexit = function(inst)
			inst.AnimState:SetDeltaTimeMultiplier(1)
		end,
        
        events=
        {
            EventHandler("animover", function(inst)
                inst.sg:GoToState("idle")
            end ),
        },
    }
)

AddStategraphState("wilson_client", 
	State{
        name = "iceygun_shoot",
        tags = {"attack", "notalking", "abouttoattack", "busy","nopredict"},
        
        onenter = function(inst)
            --[[local weapon = inst.replica.combat:GetWeapon()
            local otherequipped = inst.replica.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
            if (weapon and weapon:HasTag("hand_gun")) or (otherequipped and otherequipped:HasTag("hand_gun")) then
                inst.AnimState:PlayAnimation("hand_shoot")
            else
                inst.AnimState:PlayAnimation("shoot")
            end--]]
			--inst.AnimState:SetDeltaTimeMultiplier(2.5)
			--[[inst.replica.combat:StartAttack()
			local buffaction = inst:GetBufferedAction()
            if buffaction ~= nil then
                inst:PerformPreviewBufferedAction()

                if buffaction.target ~= nil and buffaction.target:IsValid() then
                    inst:FacePoint(buffaction.target:GetPosition())
                    inst.sg.statemem.attacktarget = buffaction.target
                end
            end--]]
			local weapon = inst.replica.combat:GetWeapon()
			if weapon:HasTag("gun_without_bullet") then 
				inst.sg:GoToState("idle")
				return 
			end 
			IceyCommonStates.SGAttackOnEnterClient(inst,15 * FRAMES)
			
			inst.sg:SetTimeout(15 * FRAMES)
        end,
        
        timeline=
        {
			
            TimeEvent(7*FRAMES, function(inst) 
                inst.sg:RemoveStateTag("abouttoattack") 
				inst:ClearBufferedAction()
				--inst.AnimState:SetDeltaTimeMultiplier(1)
				--inst.SoundEmitter:PlaySound("dontstarve_DLC003/common/items/weapon/blunderbuss_shoot")
            end),            
            TimeEvent(8*FRAMES, function(inst)
                inst.sg:RemoveStateTag("attack")
            end),           
            
        },
		
		onexit = function(inst)
			--inst.AnimState:SetDeltaTimeMultiplier(1)
		end,
        
        events=
        {
            EventHandler("animover", function(inst)
                inst.sg:GoToState("idle")
            end ),
        },
    }
)

AddStategraphState("wilson", 
    State{
        name = "speargun",
        tags = {"attack", "notalking", "abouttoattack","nopredict"},
        
        onenter = function(inst)
			local buffaction = inst:GetBufferedAction()
            local target = buffaction ~= nil and buffaction.target or nil
            local equip = inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
            inst.components.combat:SetTarget(target)
            inst.components.combat:StartAttack()
            inst.components.locomotor:Stop()
			
            inst.sg.statemem.target = target
            inst.sg.statemem.target_position = target and Vector3(inst.components.combat.target.Transform:GetWorldPosition())

            inst.AnimState:PlayAnimation("speargun")
            
            if inst.components.combat.target then
                if inst.components.combat.target and inst.components.combat.target:IsValid() then
                    inst:FacePoint(Point(inst.components.combat.target.Transform:GetWorldPosition()))
                end
			end
        end,
        
        timeline=
        {
           
            TimeEvent(12*FRAMES, function(inst)
                inst.sg:RemoveStateTag("abouttoattack")
                inst:PerformBufferedAction()
                if inst.components.combat:GetWeapon() and inst.components.combat:GetWeapon():HasTag("blunderbuss") then
                    inst.SoundEmitter:PlaySound("dontstarve_DLC003/common/items/weapon/blunderbuss_shoot")
                    local cloud = SpawnPrefab("cloudpuff")
                    local pt = Vector3(inst.Transform:GetWorldPosition())

					local angle
					if inst.components.combat.target and inst.components.combat.target:IsValid() then
                    	angle = (inst:GetAngleToPoint(inst.components.combat.target.Transform:GetWorldPosition()) -90)*DEGREES
					else
						angle = (inst:GetAngleToPoint(inst.sg.statemem.target_position.x, inst.sg.statemem.target_position.y, inst.sg.statemem.target_position.z) -90)*DEGREES
					end	                	
					inst.sg.statemem.target_position = nil
					
                    local DIST = 1.5
                    local offset = Vector3(DIST * math.cos( angle+(PI/2) ), 0, -DIST * math.sin( angle+(PI/2) ))

                    cloud.Transform:SetPosition(pt.x+offset.x,2,pt.z+offset.z)
                else
                    inst.SoundEmitter:PlaySound("dontstarve_DLC002/common/use_speargun")
                end
            end),
            TimeEvent(20*FRAMES, function(inst) inst.sg:RemoveStateTag("attack") end),
        },
        
        events=
        {
            EventHandler("animover", function(inst)
                inst.sg:GoToState("idle")
            end),
        },
    }
)

AddStategraphState("wilson_client", 
    State{
        name = "speargun",
        tags = {"attack", "notalking", "abouttoattack","nopredict"},
        
        onenter = function(inst)
            inst.components.locomotor:Stop()
            --inst.AnimState:PlayAnimation("speargun")
            inst.replica.combat:StartAttack()
			
            local buffaction = inst:GetBufferedAction()
            if buffaction ~= nil then
                inst:PerformPreviewBufferedAction()

                if buffaction.target ~= nil and buffaction.target:IsValid() then
                    inst:FacePoint(buffaction.target:GetPosition())
                    inst.sg.statemem.attacktarget = buffaction.target
                end
            end
			
        end,
        
        timeline=
        {
           
            TimeEvent(12*FRAMES, function(inst)
                inst.sg:RemoveStateTag("abouttoattack")
                if inst.replica.combat:GetWeapon() and inst.replica.combat:GetWeapon():HasTag("blunderbuss") then
                    inst.SoundEmitter:PlaySound("dontstarve_DLC003/common/items/weapon/blunderbuss_shoot")
                else
                    inst.SoundEmitter:PlaySound("dontstarve_DLC002/common/use_speargun")
                end
            end),
            TimeEvent(20*FRAMES, function(inst) inst.sg:RemoveStateTag("attack") end),
        },
        
        events=
        {
            EventHandler("animover", function(inst)
                inst.sg:GoToState("idle")
            end),
        },
    }
)

AddStategraphState("wilson", 
    State{
        name = "vacuum_sword",
        tags = {"attack", "notalking", "abouttoattack","nopredict"},
        
        onenter = function(inst)
			local buffaction = inst:GetBufferedAction()
            local target = buffaction ~= nil and buffaction.target or nil
            inst.components.combat:SetTarget(target)
            inst.components.combat:StartAttack()
			
            inst.sg.statemem.target = target
            inst.sg.statemem.target_position = target and Vector3(inst.components.combat.target.Transform:GetWorldPosition())
			
			--[[if not inst.AnimState:IsCurrentAnimation("atk_pre") 
				and not inst.AnimState:IsCurrentAnimation("atk")
				and not inst.AnimState:IsCurrentAnimation("lunge_pst")
				then --]]
				if math.random() <= 0.5 then 
					inst.AnimState:SetDeltaTimeMultiplier(3)
					inst.AnimState:PlayAnimation("atk_pre")
					inst.AnimState:PushAnimation("atk", false)
				else
					inst.AnimState:SetDeltaTimeMultiplier(2)
					inst.AnimState:PlayAnimation("lunge_pst")
				end 
			--end 
			inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon",nil,nil,true)
			inst.SoundEmitter:PlaySound("dontstarve/common/lava_arena/fireball",nil,nil,true)
			
			--inst.components.bloomer:PushBloom("vacuum_sword", "shaders/anim.ksh", -2)
            --inst.components.colouradder:PushColour("vacuum_sword", 0, 0.6, 0.6, 0)
            --inst.sg.statemem.flash = 0.6
            if inst.components.combat.target then
                if inst.components.combat.target and inst.components.combat.target:IsValid() then
                    inst:FacePoint(Point(inst.components.combat.target.Transform:GetWorldPosition()))
                end
			end
			
			inst.sg:SetTimeout(3 * FRAMES)
        end,
		
		ontimeout = function(inst)
			inst.sg:GoToState("idle",true)
		end,
		
		--[[onupdate = function(inst)
            if inst.sg.statemem.flash and inst.sg.statemem.flash > 0 then
                inst.sg.statemem.flash = math.max(0, inst.sg.statemem.flash - .1)
                inst.components.colouradder:PushColour("vacuum_sword", 0, inst.sg.statemem.flash, inst.sg.statemem.flash, 0)
            end
        end,--]]
		
		onexit = function(inst)
			inst.AnimState:SetDeltaTimeMultiplier(1)
			--inst.components.bloomer:PopBloom("vacuum_sword")
			--inst.components.colouradder:PopColour("vacuum_sword")
			--[[if inst.sg.statemem.vacuum_sword_fx and inst.sg.statemem.vacuum_sword_fx:IsValid() then 
				inst.sg.statemem.vacuum_sword_fx:Remove()
			end
			
			inst.sg.statemem.vacuum_sword_fx = nil --]]
		end,
		
        
        timeline=
        {
			TimeEvent(0*FRAMES, function(inst) 
				inst:PerformBufferedAction()
				inst.components.icey_vacuum_sword_user:SpawnFx()
				inst.components.icey_vacuum_sword_user:DoAttack() 
			end),
			TimeEvent(1*FRAMES, function(inst) 
				inst.components.icey_vacuum_sword_user:DoAttack() 
			end),
			TimeEvent(2*FRAMES, function(inst) 
				inst.components.icey_vacuum_sword_user:DoAttack() 
				inst.sg:RemoveStateTag("attack")
			end),
        },
    }
)

AddStategraphState("wilson_client", 
    State{
        name = "vacuum_sword",
        tags = {"attack", "notalking", "abouttoattack","nopredict"},
        
        onenter = function(inst)
            inst.replica.combat:StartAttack()
			
            local buffaction = inst:GetBufferedAction()
            if buffaction ~= nil then
                inst:PerformPreviewBufferedAction()
                if buffaction.target ~= nil and buffaction.target:IsValid() then
                    inst:FacePoint(buffaction.target:GetPosition())
                    inst.sg.statemem.attacktarget = buffaction.target
                end
            end
			
			inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon",nil,nil,true)
			inst.SoundEmitter:PlaySound("dontstarve/common/lava_arena/fireball",nil,nil,true)
			
			inst.sg:SetTimeout(3 * FRAMES)
        end,
		
		ontimeout = function(inst)
			inst.sg:GoToState("idle",true)
		end,
    }
)

AddStategraphState("wilson", 
    State{
        name = "portableitem_attack",
        tags = {"attack", "notalking", "abouttoattack","pausepredict"},
        
        onenter = function(inst)
            local buffaction = inst:GetBufferedAction()
            local target = buffaction ~= nil and buffaction.target or nil
            local equip = inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
            inst.components.combat:SetTarget(target)
            inst.components.combat:StartAttack()
            inst.components.locomotor:Stop()
			
			inst.AnimState:PlayAnimation("attack_book")
			inst.SoundEmitter:PlaySound("dontstarve/common/lava_arena/whoosh",nil,nil,true)
			inst.SoundEmitter:PlaySound("dontstarve/forge2/beetletaur/swipe",nil,nil,true)
			--ThePlayer.SoundEmitter:PlaySound("dontstarve/common/lava_arena/whoosh",nil,nil,true)
			if target ~= nil then
                inst.components.combat:BattleCry()
                if target:IsValid() then
                    inst:FacePoint(target:GetPosition())
                    inst.sg.statemem.attacktarget = target
                end
            end
			
			if inst.components.playercontroller ~= nil then
                inst.components.playercontroller:RemotePausePrediction(5)
            end
			
			inst.sg:SetTimeout(19 * FRAMES)
        end,
		
		ontimeout = function(inst)
			inst.sg:RemoveStateTag("attack")
            inst.sg:AddStateTag("idle")
		end,
		
		timeline = {
			
			TimeEvent(5 * FRAMES, function(inst)
				inst.sg:RemoveStateTag("pausepredict")
			end),
			TimeEvent(10 * FRAMES, function(inst)
                inst:PerformBufferedAction()
				
                inst.sg:RemoveStateTag("abouttoattack")
            end),
		},
		
		events =
        {
            EventHandler("equip", function(inst) inst.sg:GoToState("idle") end),
            EventHandler("unequip", function(inst) inst.sg:GoToState("idle") end),
            EventHandler("animqueueover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("idle")
                end
            end),
        },

        onexit = function(inst)
            inst.components.combat:SetTarget(nil)
            if inst.sg:HasStateTag("abouttoattack") then
                inst.components.combat:CancelAttack()
            end
        end,
    }
)

AddStategraphState("wilson_client", 
	State{
        name = "portableitem_attack",
        tags = {"attack", "notalking", "abouttoattack"},
        
        onenter = function(inst)
            if inst.replica.combat ~= nil then
                inst.replica.combat:StartAttack()
                cooldown = inst.replica.combat:MinAttackPeriod() + .5 * FRAMES
            end
            inst.components.locomotor:Stop()
            local equip = inst.replica.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
			
			local buffaction = inst:GetBufferedAction()
            if buffaction ~= nil then
                inst:PerformPreviewBufferedAction()

                if buffaction.target ~= nil and buffaction.target:IsValid() then
                    inst:FacePoint(buffaction.target:GetPosition())
                    inst.sg.statemem.attacktarget = buffaction.target
                end
            end
			
			--inst.AnimState:PlayAnimation("attack_book")
			inst.SoundEmitter:PlaySound("dontstarve/common/lava_arena/whoosh",nil,nil,true)
			inst.SoundEmitter:PlaySound("dontstarve/forge2/beetletaur/swipe",nil,nil,true)
			
			
			inst.sg:SetTimeout(19 * FRAMES)
        end,
		
		ontimeout = function(inst)
			inst.sg:RemoveStateTag("attack")
            inst.sg:AddStateTag("idle")
		end,
		
		timeline = {
			TimeEvent(10 * FRAMES, function(inst)
                inst:ClearBufferedAction()
                inst.sg:RemoveStateTag("abouttoattack")
            end),
		},
		
		events =
        {
            EventHandler("animqueueover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("idle")
                end
            end),
        },

        onexit = function(inst)
			if inst.sg:HasStateTag("abouttoattack") and inst.replica.combat ~= nil then
                inst.replica.combat:CancelAttack()
            end
        end,
    }
)