local assets =
{
    Asset("ANIM", "anim/lavaarena_heal_flowers_fx.zip"),
}

local FRAME = 1/1000

local function istadalin(ent)
	return ent:HasTag("tadalin")
end 

local function IsRecentlyAttacked(ent)
	return GetTime() - ent.components.combat.lastwasattackedtime <= 2.5
end 

local function IsIgnoreState(ent)
	if not ent.sg then 
		return true 
	end
	return ent.sg and ent.sg:HasStateTag("hiding") or ent.sg.HasStateTag("attack") or ((ent:HasTag("epic") and ent.sg:HasStateTag("caninterrupt")))
end

local function WakeUp(target)
	if target.components.sleeper and target.components.sleeper:IsAsleep() then 
		target.components.sleeper:WakeUp()
	end 
	if target.components.grogginess  then 
		target.components.grogginess.grog_amount = 0
		if target.sg  and target.sg:HasStateTag("knockout") then 
			target.sg:GoToState("wakeup")
		end 
	end
end 

local function onremove(inst)
	local x,y,z = inst:GetPosition():Get()
	local ents = TheSim:FindEntities(x,y,z,4.3)
	for k,v in pairs(ents) do 
		v:DoTaskInTime(2,WakeUp)
	end
	for k,v in pairs(inst.sleepents) do 
		v:DoTaskInTime(2,WakeUp)
	end
	inst:Remove()
end 

local function HealTadalin(inst)
	local x,y,z = inst:GetPosition():Get()
	local ents = TheSim:FindEntities(x,y,z,4.1,{"_combat","tadalin"})
	for k,v in pairs(ents) do 
		if istadalin(v) then 
			if v.components.health and not v.components.health:IsDead() then 
				v.components.health:DoDelta(1)
			end
		end
	end
end 

local function Check(inst)
	local x,y,z = inst:GetPosition():Get()
	local ents = TheSim:FindEntities(x,y,z,4.1,{"_combat"})
	for k,v in pairs(ents) do 
		if istadalin(v) then 
			--[[if v.components.health and not v.components.health:IsDead() then 
				v.components.health:DoDelta(1)
			end--]]
		else
			if v.components.sleeper or v.components.grogginess then 
				local exits = false
				for i,j in pairs(inst.sleepents) do 
					if j == v then 
						exits = true 
						break
					end 
				end
				if not exits then 
					table.insert(inst.sleepents,v)
				end 
			end
		end
	end
	local i = 1
	while i <= #inst.sleepents do 
		local v = inst.sleepents[i]
		if not (v and v:IsValid() and v.components.health and not v.components.health:IsDead() and (v.components.sleeper or v.components.grogginess) ) then 
			table.remove(inst.sleepents,i)
		elseif  math.sqrt(v:GetDistanceSqToInst(inst)) > 4.1 then 
			v:DoTaskInTime(2,WakeUp)
			table.remove(inst.sleepents,i)
		else
			i = i + 1
		end
	end
	for k,v in pairs(inst.sleepents) do 
		if not IsRecentlyAttacked(v) and not IsIgnoreState(v) then 
			if v.components.sleeper then 
				v.components.sleeper:AddSleepiness(10,3)
			elseif v.components.grogginess and  v.components.grogginess.grog_amount <= 4 then
				v.components.grogginess:AddGrogginess(1,3)
			end 
		end
	end
end 

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    --[[Non-networked entity]]

    inst:AddTag("CLASSIFIED")
	--inst:AddTag("healingcircle")
	
	inst.blooms = {}
	inst.caster = nil
	
	--inst:AddComponent("icey_heal_aura")
	--inst.components.icey_heal_aura:SetCanSleep(cansleep)
	
	inst:DoTaskInTime(10, function(inst)
		for _,v in pairs(inst.blooms) do
			if v.Kill ~= nil then v:Kill(true) end
		end
		inst:Remove()
	end)

	function inst:SpawnBlooms()
		local bloomprefab = "icey_healingcircle_bloom"
		for i = 1,15 do
			local pt = inst:GetPosition()
			if i == 1 then
				inst:DoTaskInTime(math.random(), function()
				local bloom = SpawnPrefab(bloomprefab)
				bloom.Transform:SetPosition(pt:Get())
				bloom.buffed = inst.buffed
				table.insert(inst.blooms, bloom)
				end)
			elseif i >= 2 and i < 7 then
				local theta = (i-1)/5 * 2 * PI
				local radius = 4.1/2--inst.components.icey_heal_aura.range/2
				local offset = FindWalkableOffset(pt, theta, radius, 2, true, true)
				if offset ~= nil then
					offset.x = offset.x + pt.x
					offset.z = offset.z + pt.z
					inst:DoTaskInTime(math.random(), function()
					local bloom = SpawnPrefab(bloomprefab)
					bloom.Transform:SetPosition(offset.x, 0, offset.z)
					bloom.buffed = inst.buffed
					table.insert(inst.blooms, bloom)
					end)
				end
			elseif i >= 7 then
				local theta = (i-5)/9 * 2 * PI
				local radius = 4.1--inst.components.icey_heal_aura.range
				local offset = FindWalkableOffset(pt, theta, radius, 2, true, true)
				if offset ~= nil then
					offset.x = offset.x + pt.x
					offset.z = offset.z + pt.z
					inst:DoTaskInTime(math.random(), function()
					local bloom = SpawnPrefab(bloomprefab)
					bloom.Transform:SetPosition(offset.x, 0, offset.z)
					bloom.buffed = inst.buffed
					table.insert(inst.blooms, bloom)
					end)
				end
			end
		end
	end
	
	function inst:SpawnCenter()
		local pt = inst:GetPosition()
		local center = SpawnPrefab("icey_healingcircle_center")
		center.Transform:SetPosition(pt.x, 0, pt.z)
		center:DoTaskInTime(12, inst.Remove)		
	end
	
	inst:DoTaskInTime(0, inst.SpawnCenter)
	inst:DoTaskInTime(0, inst.SpawnBlooms)
	
	inst:DoTaskInTime(15, inst.Remove)
	
    return inst
end

local function bloom_fn()
	local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()

	inst.AnimState:SetBuild("lavaarena_heal_flowers_fx")
	inst.AnimState:SetBank("lavaarena_heal_flowers")
	--inst.AnimState:HideSymbol("drop")
	
	if not TheWorld.ismastersim then
		return inst
	end 
	
	inst.variation = tostring(math.random(1, 6))
	
	--inst:AddComponent("colourfader")
	
	local function PlayFlowerSound()
		inst.SoundEmitter:PlaySound("dontstarve/wilson/pickup_reeds", "flower_sound")
		inst.SoundEmitter:SetVolume("flower_sound", .25)
	end
	
	function inst:Start()
		PlayFlowerSound()
		
		inst.AnimState:PlayAnimation("in_"..inst.variation)
		inst.AnimState:PushAnimation("idle_"..inst.variation)
		
		if inst.buffed then
			local scale = 1 + (math.random(30,40) + math.random())/100
			inst.Transform:SetScale(scale, scale, scale)
			--inst.AnimState:ShowSymbol("drop")
		end
		
		--[[inst.components.colourfader:StartFade({0, 0.3, 0.1}, 650 * FRAME, function(inst)
			inst:DoTaskInTime(350*FRAME, function() inst.components.colourfader:StartFade({0, 0, 0}, 457 * FRAME) end)
		end)--]]
	end
	
	function inst:Kill(withdelay)
		local delay = withdelay and math.random() or 0
		inst:DoTaskInTime(delay, function(inst)
			PlayFlowerSound()
			
			inst.AnimState:PushAnimation("out_"..inst.variation, false)
			inst:ListenForEvent("animover", inst.Remove)
		end)
	end

	--inst.OnSave = inst.Remove
	
	inst:DoTaskInTime(0, inst.Start)
	inst:DoTaskInTime(15, inst.Remove)
	
	return inst
end

local function center_fn()
	local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()

	inst.AnimState:SetBank("lavaarena_heal_flowers")
	inst.AnimState:SetBuild("lavaarena_heal_flowers_fx")
	
	inst.AnimState:SetMultColour(0,0,0,0)
	--inst:Hide()
	
	inst:AddTag("healingcircle")
	
	if not TheWorld.ismastersim then
		return inst
	end 
	
	inst.sleepents = {}
	
	inst.variation = tostring(math.random(1, 6))
	inst.AnimState:PlayAnimation("in_"..inst.variation)
	inst.AnimState:PushAnimation("idle_"..inst.variation)
	
	inst:DoTaskInTime(12, onremove)
	inst:DoPeriodicTask(0,Check)
	inst:DoPeriodicTask(0.25,HealTadalin)
	
	return inst
end

return Prefab("icey_healingcircle", fn, assets, prefabs),
	Prefab("icey_healingcircle_bloom", bloom_fn, assets, nil),
	Prefab("icey_healingcircle_center", center_fn, assets, nil)