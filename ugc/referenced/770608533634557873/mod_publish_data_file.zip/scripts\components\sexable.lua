----------我真是疯了才来写交配的组件

local Sexable = Class(function(self)
	self.inst = inst
	
	self.can_makesex = true
	self.onpremakesex = nil 
	self.onmakesex = nil 
	self.onexitmakesex = nil 
	
	self.inst:AddTag("sexable")
end)


function Sexable:SetOnPreMakeSex(fn)
	self.onpremakesex = fn 
end 

function Sexable:SetOnMakeSex(fn)
	self.onmakesex = fn 
end 

function Sexable:SetOnExitMakeSex(fn)
	self.onexitmakesex = fn 
end 

function Sexable:OnPreMakeSex(another)
	if self.onpremakesex then 
		self.onpremakesex(self.inst,another)
	end
end 

function Sexable:OnMakeSex(another)
	if self.onmakesex then 
		self.onmakesex(self.inst,another)
	end
end

function Sexable:OnExitMakeSex(another)
	if self.onexitmakesex then 
		self.onexitmakesex(self.inst,another)
	end
end


return Sexable