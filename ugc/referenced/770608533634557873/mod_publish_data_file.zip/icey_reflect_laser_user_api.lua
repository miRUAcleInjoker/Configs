local IceyUtil = require("icey_util")

--reflect_laser_user


--ThePlayer.components.reflect_laser_user:Shoot()
--ThePlayer.components.reflect_laser_user:ClearAllPoints()

local function OnClearPoint(inst,points)
	inst:StartThread(function()
		for k,v in pairs(points) do 
			local pos = v.pos
			local ent = v.ent
			local vec = v.vec
			local is_reflect = v.is_reflect
			--inst.Transform:SetPosition(pos:Get())
			--inst.Physics:Teleport(pos:Get())
			local targetpos = pos + vec
			inst:FacePoint(targetpos:Get())
			---inst.Physics:SetMotorVel(20)
			inst.Transform:SetPosition(pos:Get())
			if not (inst.components.rider and inst.components.rider:IsRiding()) then 
				inst.AnimState:PlayAnimation("atk_leap_lag")
			end 
			inst.AnimState:SetMultColour(166/255,252/255,242/255,0.3)
			local ents = TheSim:FindEntities(pos.x,pos.y,pos.z,3,{"_combat"})
			for k,v in pairs(ents) do 
				if IceyUtil.CanAttack(v,inst) then 
					v.components.combat:GetAttacked(inst,10)
					SpawnPrefab("icey_weaponsparks"):SetPiercing(inst,v)
				end
			end 
			if is_reflect then 
				SpawnPrefab("icey_weaponsparks"):SetBounce(inst)
			end
			if ent:IsValid() then
				ent:Remove()
			end 
			if k % 8 == 0 then 
				Sleep(0)
			end 
		end
		inst.components.reflect_laser_user:ClearAllPoints(true) 
		inst.AnimState:SetMultColour(1,1,1,1)
	end)
end 

AddPlayerPostInit(function(inst)
	if not TheWorld.ismastersim then
		return inst
	end
	
	inst:AddComponent("reflect_laser_user")
	inst.components.reflect_laser_user.onclearpoint = OnClearPoint
end)