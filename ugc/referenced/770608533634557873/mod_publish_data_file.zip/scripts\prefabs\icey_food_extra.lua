local function MakeFood(name, type, health, hunger, sanity, perishtime,extrafn) 
	local assets = { 
		Asset("ANIM", "anim/"..name..".zip"),     
		Asset("ATLAS", "images/inventoryimages/"..name..".xml"), 
	}  
	local prefabs =  { "spoiled_food", }  
	local function fn(Sim) 
		local inst = CreateEntity() 
		inst.entity:AddTransform() 
		inst.entity:AddAnimState() 
		if TheSim:GetGameID() =="DST" then 
			inst.entity:AddNetwork() 
		end  
		
		MakeInventoryPhysics(inst) 
		MakeSmallBurnable(inst) 
		MakeSmallPropagator(inst)  
		
		inst.AnimState:SetBank(name) 
		inst.AnimState:SetBuild(name) 
		inst.AnimState:PlayAnimation("idle")  
		
		inst:AddTag("preparedfood") 
		--inst:AddTag("rikofood")     
		 
		if TheSim:GetGameID()=="DST" then 
			if not TheWorld.ismastersim then 
				return inst 
			end  
			inst.entity:SetPristine() 
		end 
		
		inst:AddComponent("edible") 
		inst.components.edible.foodtype = type 
		inst.components.edible.healthvalue = health 
		inst.components.edible.hungervalue = hunger 
		inst.components.edible.sanityvalue = sanity  
		
		inst:AddComponent("inspectable") 
		
		inst:AddComponent("tradable")  
		
		inst:AddComponent("inventoryitem") 
		inst.components.inventoryitem.atlasname = "images/inventoryimages/"..name..".xml"  
		
		inst:AddComponent("stackable") 
		inst.components.stackable.maxsize = TUNING.STACK_SIZE_SMALLITEM  
		if perishtime ~= nil then 
			inst:AddComponent("perishable") 
			inst.components.perishable:SetPerishTime(perishtime) 
			inst.components.perishable:StartPerishing() 
			inst.components.perishable.onperishreplacement = "spoiled_food" 
		end  
		
		if extrafn then 
			extrafn(inst)
		end
		
		return inst 
	end  
	return Prefab(name, fn, assets, prefabs) 
end 

local function extrafn_snakesoup(inst)
	inst.components.inspectable:SetDescription("能够壮阳")
end

return MakeFood("snakebonesoup", FOODTYPE.MEAT, TUNING.HEALING_LARGE, TUNING.CALORIES_MED,TUNING.SANITY_SMALL, TUNING.PERISH_MED,extrafn_snakesoup)