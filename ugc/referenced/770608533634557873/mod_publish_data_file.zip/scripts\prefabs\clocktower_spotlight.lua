require("prefabutil")
require("class")

local childbrain = require "brains/spotlightchildbrain"

local assets =
{
    Asset("ANIM", "anim/winona_spotlight.zip"),
    Asset("ANIM", "anim/winona_spotlight_placement.zip"),
    Asset("ANIM", "anim/winona_battery_placement.zip"),
}

local assets_head =
{
    Asset("ANIM", "anim/winona_spotlight.zip"),
}

local prefabs =
{
    --"winona_spotlight_head",
    "winona_battery_sparks",
    "collapse_small",
}


local TILTS = { "", "_tilt1", "_tilt2" }

local function SetHeadTilt(headinst, tilt, lightenabled)
    headinst._tilt = tilt
    for i, v in ipairs(TILTS) do
        if i == tilt then
            headinst.AnimState:Show("light"..v)
            if lightenabled then
                headinst.AnimState:Show("light_shaft"..v)
            else
                headinst.AnimState:Hide("light_shaft"..v)
            end
        else
            headinst.AnimState:Hide("light"..v)
            headinst.AnimState:Hide("light_shaft"..v)
        end
    end
end

--------------------------------------------------------------------------

local LIGHT_EASING = .2
local LIMIT_RANGE_SQ = 40 * 40
local UPDATE_TARGET_PERIOD = .5
local LIGHT_INTENSITY_MAX = .94
local LIGHT_INTENSITY_DELTA = -.1
local LIGHT_OVERRIDE_HEAD = .7
local LIGHT_OVERRIDE_BASE = .25

local CLOCKTOWER_SPOTLIGHT_MAX_RANGE = 35
local CLOCKTOWER_SPOTLIGHT_MIN_RANGE = 4
local CLOCKTOWER_SPOTLIGHT_RADIUS = 2.4 

local NormalColour = Vector3(255 / 255, 248 / 255, 198 / 255)
local DangerousColour = Vector3(255 / 255, 248 / 255, 198 / 255)

local function LightPoint()
	local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddLight()
    inst.entity:AddNetwork()

    inst:AddTag("FX")

    inst.Light:SetIntensity(1)
    inst.Light:SetColour(NormalColour:Get())
    inst.Light:SetFalloff(0.3)
    inst.Light:SetRadius(0.1)
    inst.Light:Enable(true)

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst.persists = false

    return inst
end 

local function CreateLightLine(inst,startpos,endpos,num)
	local signal_vec = (endpos - startpos)/num
	for i=0,num do 
		local point = inst:SpawnChild("clocktower_spotlight_lightpoint")
		local spawnpos = startpos + signal_vec * i 
		point.Transform:SetPosition(spawnpos:Get())
	end
end 

local function CreateLight()
    local inst = CreateEntity()

    inst:AddTag("FX")
    --[[Non-networked entity]]
    inst.entity:SetCanSleep(false)
    inst.persists = false

    inst.entity:AddTransform()
    inst.entity:AddLight()
	
	
    inst.Light:SetFalloff(1)
    inst.Light:SetIntensity(LIGHT_INTENSITY_MAX)
    inst.Light:SetRadius(CLOCKTOWER_SPOTLIGHT_RADIUS)
    inst.Light:SetColour(NormalColour:Get())
    inst.Light:Enable(false)
	
--[[	local rad = 5
	local du_72 = 2*math.pi/5
	for i = 0,5 do 
		local startroa = du_72*i
		local endroa = du_72*(i+2)
		local startpos = Vector3(rad*math.cos(startroa),0,rad*math.sin(startroa))
		local endpos = Vector3(rad*math.cos(endroa),0,rad*math.sin(endroa))
		CreateLightLine(inst,startpos,endpos,20)
	end 
	
	inst:DoPeriodicTask(0,function()
		local now_roa = inst:GetRotation()
		inst.Transform:SetRotation(now_roa+2*math.pi/720)
	end)--]]

    return inst
end

local function FoundAroundPlayer(pos,range)
	local players = FindPlayersInRange(pos.x,pos.y,pos.z,range,true)
	if #players > 0 then 
		return players[1]
	end 
end 

local function UpdateNowLight(inst,radius,rotation)
	if radius then 
		inst.now_light_radius = radius
	end 
	if rotation then 
		inst.now_light_rotation = rotation
	end 
	if inst.now_light_radius <= CLOCKTOWER_SPOTLIGHT_MIN_RANGE then 
		inst.now_light_radius_delta = math.abs(inst.now_light_radius_delta)
	elseif inst.now_light_radius >= CLOCKTOWER_SPOTLIGHT_MAX_RANGE then 
		inst.now_light_radius_delta = - math.abs(inst.now_light_radius_delta)
	end
	inst.now_light_radius = inst.now_light_radius + inst.now_light_radius_delta
	
	inst.now_light_rotation = inst.now_light_rotation + inst.now_light_rotation_delta
	if inst.now_light_rotation >= math.pi * 2 then 
		inst.now_light_rotation = 0
	end
end 

local function IsValidPlayer(player)
	return player and player:IsValid() and player.entity:IsVisible()
end 

local function UpdateTargetPos(inst)
	--local time = GetTime() 
	local pos = inst:GetPosition() 
	if IsValidPlayer(inst._target) then 
		inst._targetpos = inst._target:GetPosition() 
		local radius = math.sqrt(inst:GetDistanceSqToPoint(inst._targetpos:Get()))
		local rotation = inst:GetAngleToPoint(inst._targetpos:Get())
		UpdateNowLight(inst,radius,rotation)
	else
		local nowrad = inst.now_light_radius
		local nowrotation = inst.now_light_rotation
		inst._targetpos = pos + Vector3(nowrad*math.cos(nowrotation),0,nowrad*math.sin(nowrotation))
		--inst._targetpos = inst:GetPosition() + Vector3(5,0,0)
	end
	
	if inst._targetpos and not IsValidPlayer(inst._target) then 
		local player = FoundAroundPlayer(inst._targetpos,CLOCKTOWER_SPOTLIGHT_RADIUS+1)
		if IsValidPlayer(player) then 
			inst._target = player
		end
	end
	
	if IsValidPlayer(inst._target) then 
		inst._lightinst.Light:SetColour(DangerousColour:Get())  
		local ents = TheSim:FindEntities(pos.x,pos.y,pos.z,35,{"_combat","clocktowerworks"})
		for k,v in pairs(ents) do 
			if v.components.combat  then 
				v.components.combat:SuggestTarget(inst._target)
			end
		end
	else
		inst._lightinst.Light:SetColour(NormalColour:Get())  
	end
end 

local function UpdateTarget(inst)
    local x, y, z = inst.Transform:GetWorldPosition()
    local maxrangesq = CLOCKTOWER_SPOTLIGHT_MAX_RANGE * CLOCKTOWER_SPOTLIGHT_MAX_RANGE
    local startrange = CLOCKTOWER_SPOTLIGHT_MAX_RANGE + CLOCKTOWER_SPOTLIGHT_RADIUS + 2
    local rangesq = startrange * startrange
    local targetIsAlive = nil
    if inst._target ~= nil then
        if not (inst._target:IsValid() and inst._target.entity:IsVisible()) then
            inst._target = nil
        else
            rangesq = inst._target:GetDistanceSqToPoint(x, y, z)
            if rangesq >= LIMIT_RANGE_SQ then
                inst._target = nil
                rangesq = startrange * startrange
            else
                targetIsAlive = not (inst._target.components.health:IsDead() or inst._target:HasTag("playerghost"))
                if targetIsAlive and rangesq < maxrangesq then
                    return
                end
            end
        end
    end
    --[[for i, v in ipairs(AllPlayers) do
        if v ~= inst._target and v.entity:IsVisible() then
            local isalive = not (v.components.health:IsDead() or v:HasTag("playerghost"))
            if isalive or not targetIsAlive then
                local distsq = v:GetDistanceSqToPoint(x, y, z)
                if distsq < rangesq or (isalive and not targetIsAlive and distsq < maxrangesq) then
                    rangesq = distsq
                    inst._target = v
                    targetIsAlive = isalive
                end
            end
        end
    end--]]
	
	UpdateTargetPos(inst)
	
end

local function UpdateLightValues(inst, dir, dist)
    local offs = inst._lightoffset:value() * inst._lightoffset:value() / 49
    dir = dir + offs * 15
    dist = dist + offs
    local theta = (dir + 90) * DEGREES
    inst._lightinst.Transform:SetPosition(math.sin(theta) * dist, 0, math.cos(theta) * dist)
    local k = math.clamp((dist - CLOCKTOWER_SPOTLIGHT_MIN_RANGE) / (CLOCKTOWER_SPOTLIGHT_MAX_RANGE - CLOCKTOWER_SPOTLIGHT_MIN_RANGE), 0, 1)
    inst._lightinst.Light:SetIntensity(LIGHT_INTENSITY_MAX + k * k * LIGHT_INTENSITY_DELTA)
end

local function OnUpdateLightCommon(inst)
    if inst._lightoffset:value() > 0 then
        inst._lightoffset:set_local(inst._lightoffset:value() - 1)
    end

    local lightenabled = inst._lightdist:value() > 0

    if inst._curlightdir == nil then
        if not lightenabled then
            return
        end
        inst._curlightdir = inst._lightdir:value()
    else
        if inst._clientheadinst ~= nil then
            --on clients, check to make sure we're predicting the light tween in the correct direction
            --by comparing it against the head transform rotation, which isn't predicted
            local headdir = inst._clientheadinst.Transform:GetRotation()
            local drot = math.abs(inst._curlightdir - headdir)
            if drot > 180 then
                drot = 360 - drot
            end
            if drot >= 90 then
                --differs by over 90 degrees? maybe we're rotating the wrong way, so snap to match the head
                inst._curlightdir = headdir
            end
        end
        local drot = inst._lightdir:value() - inst._curlightdir
        if drot > 180 then
            drot = drot - 360
        elseif drot < -180 then
            drot = drot + 360
        end
        inst._curlightdir = inst._curlightdir + drot * LIGHT_EASING
        if inst._curlightdir > 180 then
            inst._curlightdir = inst._curlightdir - 360
        elseif inst._curlightdir < -180 then
            inst._curlightdir = inst._curlightdir + 360
        end
    end

    if inst._curlightdist == nil then
        inst._curlightdist = math.max(CLOCKTOWER_SPOTLIGHT_MIN_RANGE, inst._lightdist:value())
    else
        inst._curlightdist = inst._curlightdist * (1 - LIGHT_EASING) + math.max(CLOCKTOWER_SPOTLIGHT_MIN_RANGE, inst._lightdist:value()) * LIGHT_EASING
    end

    if lightenabled then
        UpdateLightValues(inst, inst._curlightdir, inst._curlightdist)
    end
end


local function OnUpdateLightServer(inst, dt)
    if inst:IsAsleep() then
        return
    end

    local lightenabled = inst._lightdist:value() > 0
    if lightenabled then
        if inst._updatedelay > 0 then
            inst._updatedelay = inst._updatedelay - dt
        else
            UpdateTarget(inst)
            inst._updatedelay = UPDATE_TARGET_PERIOD
        end
		UpdateTargetPos(inst)
		if inst._targetpos then 
			inst._lightdir:set(inst:GetAngleToPoint(inst._targetpos:Get()))
			inst._lightdist:set(math.clamp(math.sqrt(inst:GetDistanceSqToPoint(inst._targetpos:Get())), CLOCKTOWER_SPOTLIGHT_MIN_RANGE, CLOCKTOWER_SPOTLIGHT_MAX_RANGE))
		else
			if inst._target ~= nil then
				if inst._target:IsValid() then
					inst._lightdir:set(inst:GetAngleToPoint(inst._target.Transform:GetWorldPosition()))
					inst._lightdist:set(math.clamp(math.sqrt(inst:GetDistanceSqToInst(inst._target)), CLOCKTOWER_SPOTLIGHT_MIN_RANGE, CLOCKTOWER_SPOTLIGHT_MAX_RANGE))
				else
					inst._target = nil
				end
			end
		end 
    else
        inst._target = nil
    end
    OnUpdateLightCommon(inst)
    if inst._curlightdir ~= nil then
        inst._headinst.Transform:SetEightFaced()
        inst._headinst.Transform:SetRotation(inst._curlightdir)
        local range = CLOCKTOWER_SPOTLIGHT_MAX_RANGE - CLOCKTOWER_SPOTLIGHT_MIN_RANGE
        local tilt = (inst._curlightdist - CLOCKTOWER_SPOTLIGHT_MIN_RANGE) / range
        local t1 = inst._headinst._tilt > 1 and .2 + 3 / range or .2
        local t2 = inst._headinst._tilt > 2 and .002 + 1.5 / range or .002
        SetHeadTilt(inst._headinst, (tilt > t1 and 1) or (tilt > t2 and 2) or 3, lightenabled)
    end
	
	--UpdateTargetPos(inst)
end

local function OnUpdateLightClient(inst)--, dt)
    if inst.components.updatelooper ~= nil then
        if inst:HasTag("burnt") then
            inst:RemoveComponent("updatelooper")
        else
            OnUpdateLightCommon(inst)
        end
    end
end

local function OnLightDistDirty(inst)
    local lightenabled = inst._lightdist:value() > 0
    inst._lightinst.Light:Enable(lightenabled)
    if lightenabled and inst._curlightdir == nil then
        OnUpdateLightClient(inst)
    end
end

local function OnStartHum(inst)
    inst._humtask = nil
    inst.SoundEmitter:PlaySound("dontstarve/common/together/spot_light/on_hum_LP", "humloop")
end

local function EnableHum(inst, enable)
    if enable then
        if inst._humtask == nil then
            inst._humtask = inst:DoTaskInTime(0, OnStartHum)
        end
    elseif inst._humtask ~= nil then
        inst._humtask:Cancel()
        inst._humtask = nil
    else
        inst.SoundEmitter:KillSound("humloop")
    end
end

local function EnableLight(inst, enable)
    if not enable then
        if inst._powertask ~= nil then
            inst._powertask:Cancel()
            inst._powertask = nil
        end
        if inst._lightdist:value() > 0 then
            SetHeadTilt(inst._headinst, inst._headinst._tilt, false)
            inst._headinst.AnimState:ClearBloomEffectHandle()
            inst._headinst.AnimState:SetLightOverride(0)
            inst.AnimState:SetLightOverride(0)
            inst._lightinst.Light:Enable(false)
            inst._lightdist:set(0)
            if not (inst:HasTag("NOCLICK") or inst:IsAsleep()) then
                inst.SoundEmitter:PlaySound("dontstarve/common/together/spot_light/electricity")
            end
            EnableHum(inst, false)
        end
    elseif inst._lightdist:value() <= 0 then
        if inst.AnimState:IsCurrentAnimation("place") then
            inst.AnimState:PlayAnimation("idle", true)
            inst._headinst.AnimState:PlayAnimation("idle", true)
        end
        SetHeadTilt(inst._headinst, inst._headinst._tilt, true)
        inst._headinst.AnimState:SetBloomEffectHandle("shaders/anim.ksh")
        inst._headinst.AnimState:SetLightOverride(LIGHT_OVERRIDE_HEAD)
        inst.AnimState:SetLightOverride(LIGHT_OVERRIDE_BASE)
        inst._lightinst.Light:Enable(true)
        inst._lightdist:set(CLOCKTOWER_SPOTLIGHT_MIN_RANGE)
        inst._updatedelay = 0
        if not inst:IsAsleep() then
            if inst._curlightdir == nil then
                OnUpdateLightServer(inst, 0)
            end
            inst.SoundEmitter:PlaySound("dontstarve/common/together/spot_light/on")
            EnableHum(inst, true)
        end
    end
end

local function OnEntitySleep(inst)
    EnableHum(inst, false)
end

local function OnEntityWake(inst)
    if inst._lightdist:value() > 0 then
        EnableHum(inst, true)
    end
end

--------------------------------------------------------------------------

local function OnBuilt2(inst)
    if inst.components.workable:CanBeWorked() then
        inst:RemoveTag("NOCLICK")
        if not inst:HasTag("burnt") then
            --inst.components.circuitnode:ConnectTo("engineeringbattery")
        end
    end
end

local function OnBuilt3(inst)
    inst:RemoveEventCallback("animover", OnBuilt3)
    if inst.AnimState:IsCurrentAnimation("place") then
        inst.AnimState:PlayAnimation("idle", true)
        inst._headinst.AnimState:PlayAnimation("idle", true)
    end
end

local function OnBuilt(inst)--, data)
    if inst._inittask ~= nil then
        inst._inittask:Cancel()
        inst._inittask = nil
    end
    --inst.components.circuitnode:Disconnect()
    inst:AddTag("NOCLICK")
    EnableLight(inst, false)
    inst._headinst.Transform:SetTwoFaced()
    inst.AnimState:PlayAnimation("place")
    inst._headinst.AnimState:PlayAnimation("place")
    inst.SoundEmitter:PlaySound("dontstarve/common/together/spot_light/place")
    inst:DoTaskInTime(37 * FRAMES, OnBuilt2)
    inst:ListenForEvent("animover", OnBuilt3)
end

--------------------------------------------------------------------------

local function OnWorked(inst)
    inst.AnimState:PlayAnimation("hit")
    inst.AnimState:PushAnimation("idle", true)
    inst._headinst.AnimState:PlayAnimation("hit")
    inst._headinst.AnimState:PushAnimation("idle", true)
    inst.SoundEmitter:PlaySound("dontstarve/common/together/catapult/hit")
    inst._lightoffset:set(7)
end

local function OnWorkFinished(inst)
    if inst._inittask ~= nil then
        inst._inittask:Cancel()
        inst._inittask = nil
    end
    --inst.components.circuitnode:Disconnect()
    inst.components.workable:SetWorkable(false)
    inst:AddTag("NOCLICK")
    inst.persists = false
    if inst.components.burnable ~= nil then
        if inst.components.burnable:IsBurning() then
            inst.components.burnable:Extinguish()
        end
        inst.components.burnable.canlight = false
    end

    inst.Physics:SetActive(false)
    inst.components.lootdropper:DropLoot()
    inst.AnimState:Show("light")
    EnableLight(inst, false)
    inst._headinst:Hide()
    inst.AnimState:PlayAnimation("death_pst")
    inst.SoundEmitter:PlaySound("dontstarve/common/together/spot_light/destroy")

    local fx = SpawnPrefab("collapse_small")
    fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
    fx:SetMaterial("none")

    inst:DoTaskInTime(2, ErodeAway)
end

local function OnWorkedBurnt(inst)
    inst.components.lootdropper:DropLoot()
    local fx = SpawnPrefab("collapse_small")
    fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
    fx:SetMaterial("wood")
    inst:Remove()
end

local function OnBurnt(inst)
    DefaultBurntStructureFn(inst)

    EnableLight(inst, false)
    inst._headinst:Hide()

    inst:RemoveComponent("updatelooper")

    inst.Transform:SetRotation(inst._headinst.Transform:GetRotation())
    inst.OnEntityWake = nil
    inst.OnEntitySleep = nil

    inst.components.workable:SetOnWorkCallback(nil)
    inst.components.workable:SetOnFinishCallback(OnWorkedBurnt)

    if inst._inittask ~= nil then
        inst._inittask:Cancel()
        inst._inittask = nil
    end
    --inst.components.circuitnode:Disconnect()
end

--------------------------------------------------------------------------

local function GetStatus(inst)
    return (inst:HasTag("burnt") and "BURNT")
        or (inst.components.burnable ~= nil and inst.components.burnable:IsBurning() and "BURNING")
        or (inst._powertask == nil and "OFF")
        or nil
end

local function AddBatteryPower(inst, power)
    local remaining = inst._powertask ~= nil and GetTaskRemaining(inst._powertask) or 0
    if power > remaining then
        if inst._powertask ~= nil then
            inst._powertask:Cancel()
        else
            EnableLight(inst, true)
        end
        inst._powertask = inst:DoTaskInTime(power, EnableLight, false)
    end
end

local function OnUpdateSparks(inst)
    if inst._flash > 0 then
        local k = inst._flash * inst._flash
        inst.components.colouradder:PushColour("wiresparks", .3 * k, .3 * k, 0, 0)
        inst._headinst.components.colouradder:PushColour("wiresparks", .3 * k, .3 * k, 0, 0)
        inst._flash = inst._flash - .15
    else
        inst.components.colouradder:PopColour("wiresparks")
        inst._flash = nil
        inst.components.updatelooper:RemoveOnUpdateFn(OnUpdateSparks)
    end
end

local function DoWireSparks(inst)
    inst.SoundEmitter:PlaySound("dontstarve/common/together/spot_light/electricity", nil, .5)
    SpawnPrefab("winona_battery_sparks").entity:AddFollower():FollowSymbol(inst.GUID, "wire", 0, 0, 0)
    if inst.components.updatelooper ~= nil then
        if inst._flash == nil then
            inst.components.updatelooper:AddOnUpdateFn(OnUpdateSparks)
        end
        inst._flash = 1
        OnUpdateSparks(inst)
    end
end

local function NotifyCircuitChanged(inst, node)
    node:PushEvent("engineeringcircuitchanged")
end

local function OnCircuitChanged(inst)
    --Notify other connected batteries
    --inst.components.circuitnode:ForEachNode(NotifyCircuitChanged)
end


local function OnSave(inst, data)
    if inst.components.burnable ~= nil and inst.components.burnable:IsBurning() or inst:HasTag("burnt") then
        data.burnt = true
        data.lightdir = inst.Transform:GetRotation()
        if data.lightdir == 0 then
            data.lightdir = nil
        end
    else
        data.lightdist = inst._lightdist:value() > CLOCKTOWER_SPOTLIGHT_MIN_RANGE and inst._lightdist:value() or nil
        data.lightdir = inst._lightdir:value() ~= 0 and inst._lightdir:value() or nil
        data.power = inst._powertask ~= nil and math.ceil(GetTaskRemaining(inst._powertask) * 1000) or nil
    end
end

local function OnLoad(inst, data)
    if data ~= nil then
        if data.burnt then
            inst.components.burnable.onburnt(inst)
            if data.lightdir ~= nil then
                inst.Transform:SetRotation(data.lightdir)
            end
        else
            local dirty = false
            if data.lightdir ~= nil and data.lightdir ~= inst._lightdir:value() then
                inst._lightdir:set(data.lightdir)
                inst._curlightdir = data.lightdir
                dirty = true
            end
            if data.power ~= nil then
                AddBatteryPower(inst, math.max(2 * FRAMES, data.power / 1000))
            end
            if data.lightdist ~= nil and data.lightdist ~= inst._lightdist:value() and data.lightdist > CLOCKTOWER_SPOTLIGHT_MIN_RANGE and inst._lightdist:value() > 0 then
                inst._lightdist:set(data.lightdist)
                inst._curlightdist = inst._curlightdist ~= nil and data.lightdist or nil
                dirty = true
            end
            if dirty then
                if inst._lightdist:value() > 0 then
                    UpdateLightValues(inst, inst._lightdir:value(), inst._lightdist:value())
                elseif inst._curlightdir ~= nil then
                    inst._headinst.Transform:SetEightFaced()
                    inst._headinst.Transform:SetRotation(inst._curlightdir)
                    SetHeadTilt(inst._headinst, 3, false)
                end
            end
        end
    elseif inst._lightdist:value() <= 0 and inst._headinst._tilt == 1 and inst._headinst.Transform:GetRotation() == 0 then
        --never been turned on
        inst._headinst.Transform:SetTwoFaced()
    end

    if inst._inittask ~= nil then
        inst._inittask:Cancel()
        inst._inittask = nil
    end
    if inst.components.workable:CanBeWorked() and not inst:HasTag("burnt") then
        --Enable connections, but leave the initial connection to batteries' OnPostLoad
        --inst.components.circuitnode:ConnectTo(nil)
    end
end

local function OnInit(inst)
    inst._inittask = nil
    --inst.components.circuitnode:ConnectTo("engineeringbattery")
end

local function OnVacate(inst,child)
    --SpawnPrefab("collapse_small").Transform:SetPosition(inst.Transform:GetWorldPosition())
	inst._target = child 
end
--------------------------------------------------------------------------

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddMiniMapEntity()
    inst.entity:AddNetwork()

    MakeObstaclePhysics(inst, .5)

    inst.Transform:SetEightFaced()

    inst:AddTag("engineering")
    inst:AddTag("spotlight")
    inst:AddTag("structure")
	inst:AddTag("clocktowerworks")

    inst.AnimState:SetBank("winona_spotlight")
    inst.AnimState:SetBuild("winona_spotlight")
    inst.AnimState:PlayAnimation("idle", true)
    inst.AnimState:Hide("light")
    inst.AnimState:Hide("light_tilt1")
    inst.AnimState:Hide("light_tilt2")
    inst.AnimState:Hide("light_shaft")
    inst.AnimState:Hide("light_shaft_tilt1")
    inst.AnimState:Hide("light_shaft_tilt2")
    --disable mouseover over light_shaft (hidden layers still contribute to mouseover!)
    inst.AnimState:OverrideSymbol("light_shimmer", "winona_spotlight", "dummy")
    --This will remove mouseover as well (rather than just :Hide("wire"))
    inst.AnimState:OverrideSymbol("wire", "winona_spotlight", "dummy")

    inst.MiniMapEntity:SetIcon("winona_spotlight.png")

    inst._lightinst = CreateLight()
    inst._lightinst.entity:SetParent(inst.entity)
    inst._lightdir = net_float(inst.GUID, "winona_spotlight._lightdir")
    inst._lightdist = net_float(inst.GUID, "winona_spotlight._lightdist", "lightdistdirty")
    inst._lightoffset = net_tinybyte(inst.GUID, "winona_spotlight._lightoffset")
    inst._lightdist:set(0)
    inst._curlightdir = nil
    inst._curlightdist = nil

    --Dedicated server does not need deployhelper
--[[    if not TheNet:IsDedicated() then
        inst:AddComponent("deployhelper")
        inst.components.deployhelper:AddRecipeFilter("winona_spotlight")
        inst.components.deployhelper:AddRecipeFilter("winona_catapult")
        inst.components.deployhelper:AddRecipeFilter("winona_battery_low")
        inst.components.deployhelper:AddRecipeFilter("winona_battery_high")
        inst.components.deployhelper.onenablehelper = OnEnableHelper
    end--]]

    inst:AddComponent("updatelooper")
    inst.components.updatelooper:AddOnUpdateFn(TheWorld.ismastersim and OnUpdateLightServer or OnUpdateLightClient)

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        inst:ListenForEvent("lightdistdirty", OnLightDistDirty)

        return inst
    end

    inst._headinst = SpawnPrefab("clocktower_spotlight_head")
    inst._headinst.entity:SetParent(inst.entity)

    inst.highlightchildren = { inst._headinst }

    inst._state = 1

	inst:AddComponent("leader")

    inst:AddComponent("inspectable")
    inst.components.inspectable.getstatus = GetStatus

    inst:AddComponent("colouradder")

    inst:AddComponent("lootdropper")
    inst:AddComponent("workable")
    inst.components.workable:SetWorkAction(ACTIONS.HAMMER)
    inst.components.workable:SetWorkLeft(4)
    inst.components.workable:SetOnWorkCallback(OnWorked)
    inst.components.workable:SetOnFinishCallback(OnWorkFinished)

    --inst:AddComponent("circuitnode")
    --inst.components.circuitnode:SetRange(TUNING.WINONA_BATTERY_RANGE)
    --inst.components.circuitnode:SetOnConnectFn(OnConnectCircuit)
    --inst.components.circuitnode:SetOnDisconnectFn(OnDisconnectCircuit)
	
	--[[inst:AddComponent("spawner")
    inst.components.spawner:Configure("pigguard",1)
    inst.components.spawner:SetOnlySpawnOffscreen(false)
    inst.components.spawner:SetOnVacateFn(OnVacate)--]]

    inst:ListenForEvent("onbuilt", OnBuilt)
    --inst:ListenForEvent("engineeringcircuitchanged", OnCircuitChanged)

    MakeHauntableWork(inst)
    MakeMediumBurnable(inst, nil, nil, true)
    MakeMediumPropagator(inst)
    inst.components.burnable:SetOnBurntFn(OnBurnt)

    inst.OnLoad = OnLoad
    inst.OnSave = OnSave
    inst.OnEntitySleep = OnEntitySleep
    inst.OnEntityWake = OnEntityWake
    inst.AddBatteryPower = AddBatteryPower
	inst.EnableLight = EnableLight
	
	
	inst.now_light_rotation = 0 
	inst.now_light_rotation_delta = 2*math.pi/1440 
	inst.now_light_radius = CLOCKTOWER_SPOTLIGHT_MIN_RANGE
	inst.now_light_radius_delta = 0.2 
	
	inst.Debug = function(self)
		print(inst.now_light_rotation)
		print(inst.now_light_rotation_delta)
		print(inst.now_light_radius)
		print(inst.now_light_radius_delta)
	end 
	
    inst._wired = nil
    inst._flash = nil
    inst._target = nil
	inst._targetpos = nil
    inst._updatedelay = 0
    inst._inittask = inst:DoTaskInTime(0, OnInit)
	inst:DoPeriodicTask(0,UpdateNowLight)
	
	inst:EnableLight(true) 

    return inst
end

--------------------------------------------------------------------------

local function OnHeadEntityReplicated(inst)
    local parent = inst.entity:GetParent()
    if parent ~= nil and parent.prefab == "clocktower_spotlight" then
        parent.highlightchildren = { inst }
        parent._clientheadinst = inst
    end
end

local function headfn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()

    inst:AddTag("decor") --no mouse over, let the base prefab handle that
    inst:AddTag("NOCLICK")

    inst.Transform:SetEightFaced()

    inst.AnimState:SetBank("winona_spotlight")
    inst.AnimState:SetBuild("winona_spotlight")
    inst.AnimState:PlayAnimation("idle", true)
    inst.AnimState:Hide("leg")
    inst.AnimState:Hide("ground_shadow")
    inst.AnimState:Hide("wire")
    inst.AnimState:SetFinalOffset(1)
    SetHeadTilt(inst, 1, false)

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        inst.OnEntityReplicated = OnHeadEntityReplicated

        return inst
    end

    inst:AddComponent("colouradder")

    return inst
end



--------------------------------------------------------------------------

local function childfn()
	local inst = CreateEntity()
	local trans = inst.entity:AddTransform()
	local anim = inst.entity:AddAnimState()
    inst.entity:AddNetwork()
	
    anim:SetBank("arrow_indicator")
    anim:SetBuild("arrow_indicator")
    anim:PlayAnimation("arrow_loop", true)
	
	MakeInventoryPhysics(inst)
    RemovePhysicsColliders(inst)
	
    --inst:AddTag("NOCLICK")
	
	inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.persists = false 
	
	inst:AddComponent("follower")
	
	inst:AddComponent("locomotor")
	inst.components.locomotor.walkspeed = 2
	inst.components.locomotor.runspeed = 2
	inst.components.locomotor:SetTriggersCreep(false)
	
	inst:AddComponent("knownlocations")
	
	inst:SetBrain(childbrain)
	
	return inst 
end

return Prefab("clocktower_spotlight", fn, assets, prefabs),
    Prefab("clocktower_spotlight_head", headfn, assets_head),
	Prefab("clocktower_spotlight_lightpoint", LightPoint, assets_head)
	
	--Prefab("clocktower_spotlight_child", childfn)
