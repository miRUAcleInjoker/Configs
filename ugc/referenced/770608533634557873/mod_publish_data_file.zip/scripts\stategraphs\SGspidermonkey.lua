require("stategraphs/commonstates")

local actionhandlers =
{
    ActionHandler(ACTIONS.GOHOME, "action"),
    ActionHandler(ACTIONS.PICKUP, "action"),
    ActionHandler(ACTIONS.STEAL, "action"),
    ActionHandler(ACTIONS.PICK, "action"),
    ActionHandler(ACTIONS.HARVEST, "action"),
    --ActionHandler(ACTIONS.ATTACK, "throw"),
    ActionHandler(ACTIONS.EAT, "eat"),
}

local events=
{
    CommonHandlers.OnLocomote(false, true),
    CommonHandlers.OnFreeze(),
    CommonHandlers.OnAttacked(),
    CommonHandlers.OnDeath(),
    CommonHandlers.OnSleep(),
    EventHandler("doattack", function(inst, data)
        if not inst.components.health:IsDead() and not inst.sg:HasStateTag("busy") then
			if inst.components.health:GetPercent() <= 0.5 and math.random() <= 0.25 then 
				inst.sg:GoToState("attack_special", data.target)
			else
				inst.sg:GoToState("attack", data.target)
			end 
        end
    end),

    EventHandler("agitated", function(inst, data)
        if not inst.components.health:IsDead() and not inst.sg:HasStateTag("busy") then
            inst.sg:GoToState("taunt")
        end
    end),
}

local function ShakeIfClose(inst)
    ShakeAllCameras(CAMERASHAKE.FULL, .5, .02, .2, inst, 30)
end

local function ShakePound(inst)
	inst.SoundEmitter:PlaySound("dontstarve/creatures/deerclops/bodyfall_dirt")
    ShakeAllCameras(CAMERASHAKE.FULL, 1.2, .03, .7, inst, 30)
end

local function ShakeRoar(inst)
    ShakeAllCameras(CAMERASHAKE.FULL, 0.8, .03, .5, inst, 30)
end

local states =
{
    State
    {
        name = "idle",
        tags = {"idle", "canrotate"},
        onenter = function(inst, playanim)
            inst.Physics:Stop()
            if playanim then
                inst.AnimState:PlayAnimation(playanim)
                inst.AnimState:PushAnimation("idle_loop", true)
            else
                inst.AnimState:PlayAnimation("idle_loop", true)
            end
        
        end,
    
        events =
        {
            EventHandler("animover", function(inst) 

                if (inst.components.combat.target and
                    inst.components.combat.target:HasTag("player")) or inst:HasTag("agitated") then

                    if math.random() < 0.1 then
                        inst.sg:GoToState("taunt")
                        return
                    end
                end

                inst.sg:GoToState("idle") 

            end),
        },
    },

    State
    {
        name = "action",
        onenter = function(inst, playanim)
            inst.Physics:Stop()
            inst.AnimState:PlayAnimation("interact", true)
            inst.SoundEmitter:PlaySound("dontstarve/wilson/make_trap", "make")
        end,

        onexit = function(inst)
            inst:PerformBufferedAction()
            inst.SoundEmitter:KillSound("make")
        end,

        events =
        {
            EventHandler("animover", function (inst)
                inst.sg:GoToState("idle")
            end),
        }
    }, 

    State
    {
        name = "eat",
        onenter = function(inst, playanim)
            inst.Physics:Stop()
            inst.AnimState:PlayAnimation("eat", true)
        end,
        
        onexit = function(inst)
            inst:PerformBufferedAction()
        end,

        timeline = 
        {
            TimeEvent(8*FRAMES, function(inst) 
                local waittime = FRAMES*8
                for i = 0, 3 do
                    inst:DoTaskInTime((i * waittime), function() inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/enemy/spidermonkey/bite") end)
                end
            end)
        },

        events =
        {
            EventHandler("animover", function (inst)
                inst.sg:GoToState("idle")
            end),
        }
    },

    State
    {
        name = "taunt",
        tags = {"busy"},
        
        onenter = function(inst,deathtaunt)
            inst.Physics:Stop()
            inst.AnimState:PlayAnimation("taunt")
			inst.sg.statemem.isdeathtaunt = deathtaunt
        end,

        timeline = 
        {
            TimeEvent(20*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/trails/step") end),
			TimeEvent(20*FRAMES, function(inst) 
			inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/trails/taunt")
			--inst.SoundEmitter:PlaySound("dontstarve/creatures/together/toad_stool/roar_phase")
			end),
			TimeEvent(20*FRAMES, ShakeRoar),
        },
        
        events =
        {
            EventHandler("animover", function(inst) 
				if inst.sg.statemem.isdeathtaunt and inst.components.health and not inst.components.health:IsDead()  then 
					inst.components.health:Kill()
				else
					inst.sg:GoToState("idle") 
				end 
			end),
        },
    },

    State
    {
        name = "throw",
        tags = {"attack", "busy", "canrotate", "throwing"},
        
        onenter = function(inst)
            if not inst.HasAmmo(inst) then
                inst.sg:GoToState("idle")
            end

            if inst.components.locomotor then
                inst.components.locomotor:StopMoving()
            end
            inst.AnimState:PlayAnimation("throw")
        end,

        timeline = 
        {
            TimeEvent(14*FRAMES, function(inst) inst.components.combat:DoAttack()
            inst.SoundEmitter:PlaySound("dontstarve/creatures/monkey"..inst.soundtype.."/throw") end),
        },
        
        events =
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end),
        },
    },
	
	State
    {
        name = "attack_special",
        tags = {"busy","attack"},
        
        onenter = function(inst,target)
            inst.Physics:Stop()
			inst.components.combat:StartAttack()
            inst.AnimState:PlayAnimation("attack1")
			--inst.Physics:SetMotorVelOverride(10,0,0)
        end,

        timeline = 
        {
			TimeEvent(0*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/spin") end),
			TimeEvent(6*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/swipe")
				--inst.SoundEmitter:PlaySound("dontstarve/creatures/together/klaus/swipe")
				inst.Physics:SetMotorVelOverride(10,0,0)
			end),
			TimeEvent(6*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/taunt_2")
			--inst.SoundEmitter:PlaySound("dontstarve_DLC001/creatures/bearger/taunt_short")
			end),
			TimeEvent(12*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/swipe")
				--inst.SoundEmitter:PlaySound("dontstarve/creatures/together/klaus/swipe")
				inst.Physics:SetMotorVelOverride(10,0,0)
			end),
            TimeEvent(18*FRAMES, function(inst) inst.Physics:ClearMotorVelOverride()
					inst.components.locomotor:Stop() end),
			TimeEvent(20*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/trails/attack1") end),
			TimeEvent(20*FRAMES, function(inst) 
				--inst.components.combat:DoAttack()
				ShakePound(inst)
				local target = inst.components.combat.target
				if target and target:IsValid() and target.components.combat and target.components.combat.target and target.components.combat.target == inst then 
					inst.components.combat:DoAttack(target)
				end
				inst.components.combat:DoAreaAttack(inst, 6.2, nil, nil, nil, {"battlestandard", "LA_mob", "shadow", "playerghost", "FX", "DECOR","tadalin","monster","structure"}) 
			end),
        },
        
        events =
        {
			EventHandler("onhitother", function(inst) inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/swipe") end),
			EventHandler("animover", function(inst) inst.sg:GoToState("idle") end),
        },
    },
	
	
}

CommonStates.AddWalkStates(states,
{
    starttimeline =
    {

    },

	walktimeline = 
    {
		
		TimeEvent(0*FRAMES, ShakeIfClose),
        TimeEvent(1*FRAMES, function(inst) PlayFootstep(inst) inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/step")end),
        TimeEvent(2*FRAMES, function(inst) PlayFootstep(inst) inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/step")end),
        TimeEvent(10*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/enemy/spidermonkey/idle") end),
		TimeEvent(20*FRAMES, ShakeIfClose),
        --TimeEvent(10*FRAMES, function(inst)  
           -- PlayFootstep(inst)
           -- inst.SoundEmitter:PlaySound("")
           -- if math.random() < 0.5 then
           --     inst.SoundEmitter:PlaySound("")
          --  end
        -- end),
        --TimeEvent(11*FRAMES, function(inst) PlayFootstep(inst) end),

	},

    endtimeline =
    {

    },
})


CommonStates.AddSleepStates(states,
{
    starttimeline = 
    {
     
    },

    sleeptimeline = 
    {
	TimeEvent(3*FRAMES, function(inst)
        inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/sleep_out") 
	end)
    },

    endtimeline =
    {

    },
})

CommonStates.AddCombatStates(states,
{
    attacktimeline = 
    {        
		TimeEvent(1*FRAMES, function(inst)inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/swipe") end),
        TimeEvent(11*FRAMES, function(inst) 
			inst.components.combat:DoAreaAttack(inst,5, nil, nil, nil, {"battlestandard", "LA_mob", "shadow", "playerghost", "FX", "DECOR","tadalin","monster","structure"}) 
			local target = inst.components.combat.target
			if target and target:IsValid() and target.components.combat and target.components.combat.target and target.components.combat.target == inst then 
				inst.components.combat:DoAttack(target)
			end
		end)
    },

    hittimeline =
    {
    TimeEvent(1*FRAMES, function(inst)
        inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/trails/hit")
    end)},

    deathtimeline =
    {
        TimeEvent(1*FRAMES, function(inst)
            inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/trails/taunt") 
		end),
		TimeEvent(11*FRAMES, ShakeIfClose),
			TimeEvent(11*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve/creatures/deerclops/bodyfall_dirt") end),
			TimeEvent(11*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/trails/hide_pre")
			--inst.SoundEmitter:PlaySound("dontstarve/impacts/impact_mech_med_sharp")
			end),
    },
})

CommonStates.AddFrozenStates(states)


return StateGraph("monkey", states, events, "idle", actionhandlers)