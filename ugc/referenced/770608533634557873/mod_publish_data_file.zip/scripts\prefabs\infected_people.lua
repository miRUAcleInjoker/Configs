local assets =
{
        Asset( "ANIM", "anim/player_basic.zip" ),
        Asset( "ANIM", "anim/player_idles_shiver.zip" ),
        Asset( "ANIM", "anim/player_actions.zip" ),
        Asset( "ANIM", "anim/player_actions_axe.zip" ),
        Asset( "ANIM", "anim/player_actions_pickaxe.zip" ),
        Asset( "ANIM", "anim/player_actions_shovel.zip" ),
        Asset( "ANIM", "anim/player_actions_blowdart.zip" ),
        Asset( "ANIM", "anim/player_actions_eat.zip" ),
        Asset( "ANIM", "anim/player_actions_item.zip" ),
        Asset( "ANIM", "anim/player_actions_uniqueitem.zip" ),
        Asset( "ANIM", "anim/player_actions_bugnet.zip" ),
        Asset( "ANIM", "anim/player_actions_fishing.zip" ),
        Asset( "ANIM", "anim/player_actions_boomerang.zip" ),
        Asset( "ANIM", "anim/player_bush_hat.zip" ),
        Asset( "ANIM", "anim/player_attacks.zip" ),
        Asset( "ANIM", "anim/player_idles.zip" ),
        Asset( "ANIM", "anim/player_rebirth.zip" ),
        Asset( "ANIM", "anim/player_jump.zip" ),
        Asset( "ANIM", "anim/player_amulet_resurrect.zip" ),
        Asset( "ANIM", "anim/player_teleport.zip" ),
        Asset( "ANIM", "anim/wilson_fx.zip" ),
        Asset( "ANIM", "anim/player_one_man_band.zip" ),
        Asset( "ANIM", "anim/shadow_hands.zip" ),
		
		Asset( "ANIM", "anim/player_transform_merm.zip" ),
		
        Asset( "SOUND", "sound/sfx.fsb" ),
        Asset( "SOUND", "sound/wilson.fsb" ),
        Asset( "ANIM", "anim/beard.zip" ),
		Asset("SOUND", "sound/pig.fsb"),
}



local speech_infected = 
{
	"求求你....杀了我.....",
	"来吧......",
	"命令我们！",
	"呼叫.....支援.....",
	"哦....来吧.....",
	"乐意效劳.....",
	"我愿.....效命....",
}

local weapon_list = 
{
	"spear",
	"axe",
	"pickaxe",
	"shovel",
	"pitchfork",
	"hammer",
	--"batbat",
	"hambat",
	"tentaclespike",
}

SetSharedLootTable('infected_people',
{
    --{'humanmeat',  0.5},
    {'humanmeat',  0.25},
})

local MAX_TARGET_SHARES = 5
local SHARE_TARGET_DIST = 30

local moonbeastbrain = require "brains/moonbeastbrain"
local werepigbrain = require "brains/werepigbrain"
local infectedbrain = require "brains/infectedbrain"

local function ontalk(inst, script)
    inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/idle")
end

local function CalcSanityAura(inst, observer)
    return -TUNING.SANITYAURA_LARGE * 0.75
end

local function OnEat(inst, food)
    if food.components.edible ~= nil then
        if food.components.edible.foodtype == FOODTYPE.VEGGIE then
            --SpawnPrefab("poop").Transform:SetPosition(inst.Transform:GetWorldPosition())
        elseif food.components.edible.foodtype == FOODTYPE.MEAT and
            inst.components.werebeast ~= nil and
            not inst.components.werebeast:IsInWereState() and
            food.components.edible:GetHealth(inst) < 0 then
            inst.components.werebeast:TriggerDelta(1)
        end
    end
end


local function OnAttacked(inst, data)
    --print(inst, "OnAttacked")
    local attacker = data.attacker
	inst.components.combat:SetTarget(attacker)
	inst.components.combat:ShareTarget(attacker, 30, function(dude)
        return  (dude:HasTag("tadalin"))
            and not dude.components.health:IsDead()
    end, 10)
end

local function OnNewTarget(inst, data)
	inst:DoTaskInTime(math.random(0,5),function()
		inst.components.talker:Say(speech_infected[math.random(1,#speech_infected)])
	end)
end

local function WerepigRetargetFn(inst)
    return FindEntity(
        inst,
        30,
        function(guy)
            return inst.components.combat:CanTarget(guy)
        end,
        { "_combat" }, --See entityreplica.lua (re: "_combat" tag)
        { "monster","tadalin","structure","prey","smallcreature"}
    )
end

local function WerepigKeepTargetFn(inst, target)
    return inst.components.combat:CanTarget(target)
           and not target:HasTag("tadalin") 
end


local function OnChange(inst)
	local day = TheWorld.state.phase
	if TheWorld:HasTag("cave") then 
		day = "dusk"
	end
	if inst.components.burnable then 
		if (day == "dusk" or day == "night") then 
			inst.components.burnable:SetBurnTime(10)
			inst.components.burnable:Extinguish()
			inst.components.health.fire_damage_scale = 1.5
		else
			inst:DoTaskInTime(math.random() * 2,function()
				if inst.components.health and not inst.components.health:IsDead() then 
					inst.components.health:Kill()
				end 
			end)
		end
	end 
end

local function makeweapon(inst,weapon_name) 
	if inst.components.inventory and inst.components.combat and inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS) == nil  then 
		local weapon = SpawnPrefab(weapon_name)
		local x,y,z = inst:GetPosition():Get()
		weapon.Transform:SetPosition(x,y,z)
		inst.components.inventory:Equip(weapon)
	end 
end 

local function common(prefab,bank,build,anim)
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddDynamicShadow()
    inst.entity:AddLightWatcher()
    inst.entity:AddNetwork()

    MakeCharacterPhysics(inst, 50, .5)

    inst.DynamicShadow:SetSize(1.5, .75)
    inst.Transform:SetFourFaced()

    inst:AddTag("character")
	inst:AddTag("groggy")
    inst:AddTag("scarytoprey")  
	inst:AddTag("hostile")
	inst:AddTag("tadalin")
	inst:AddTag("monster")
	inst:AddTag("infected")
	
    inst.AnimState:SetBank(bank) 
	inst.AnimState:SetBuild(build)
    inst.AnimState:PlayAnimation(anim, true)

    --Sneak these into pristine state for optimization
    inst:AddTag("_named")
    inst.entity:SetPristine()
	
	inst:AddComponent("talker")
    inst.components.talker.fontsize = 35
    inst.components.talker.font = TALKINGFONT
    --inst.components.talker.colour = Vector3(133/255, 140/255, 167/255)
    inst.components.talker.offset = Vector3(0, -400, 0)
    inst.components.talker:MakeChatter()
	inst.components.talker.ontalk = ontalk

    if not TheWorld.ismastersim then
        return inst
    end

	

	inst:AddComponent("combat")
    inst.components.combat:SetTarget(nil)
    inst.components.combat:SetRetargetFunction(3, WerepigRetargetFn)
    inst.components.combat:SetKeepTargetFunction(WerepigKeepTargetFn) 
	inst.components.combat:SetDefaultDamage(20)
    inst.components.combat:SetAttackPeriod(1)
	
    inst:AddComponent("locomotor") -- locomotor must be constructed before the stategraph
    inst.components.locomotor.runspeed = 2
    inst.components.locomotor.walkspeed = 1.5
	
	inst:AddComponent("rider")
	
    inst:AddComponent("bloomer")

    ------------------------------------------
    inst:AddComponent("eater")
    inst.components.eater:SetDiet({ FOODGROUP.OMNI }, { FOODGROUP.OMNI })
    inst.components.eater:SetCanEatHorrible()
    inst.components.eater:SetCanEatRaw()
    inst.components.eater.strongstomach = true -- can eat monster meat!
    inst.components.eater:SetOnEatFn(OnEat)
    ------------------------------------------
    inst:AddComponent("health")
	inst.components.health:SetMaxHealth(100)
	inst.components.health.destroytime = 9.7

    MakeMediumBurnableCharacter(inst, "torso")

    inst:AddComponent("named")
	inst.components.named:SetName("异化作战体")

   
    ------------------------------------------
    inst:AddComponent("follower")
    inst.components.follower.maxfollowtime = TUNING.PIG_LOYALTY_MAXTIME
    ------------------------------------------
    inst:AddComponent("inventory")
	inst.components.inventory.DropEverything = function(self,ondeath, keepequip)
		if self.activeitem ~= nil then
			self:DropItem(self.activeitem)
			self:SetActiveItem(nil)
		end

		for k = 1, self.maxslots do
			local v = self.itemslots[k]
			if v ~= nil then
				v:Remove()
			end
		end

		if not keepequip then
			for k, v in pairs(self.equipslots) do
				if not (ondeath and v.components.inventoryitem.keepondeath) then
					v:Remove()
				end
			end
		end
	
	end 
    ------------------------------------------
    inst:AddComponent("lootdropper")
	inst.components.lootdropper:SetChanceLootTable('infected_people')
	--inst.components.lootdropper:SetLoot({ })--humanmeat
    --inst.components.lootdropper.numrandomloot = 0
    ------------------------------------------
    inst:AddComponent("knownlocations")
    ------------------------------------------

    inst:AddComponent("sanityaura")
    inst.components.sanityaura.aurafn = CalcSanityAura

    ------------------------------------------
    MakeLargeFreezableCharacter(inst, "torso")
	inst.components.freezable:SetDefaultWearOffTime(TUNING.MOONPIG_FREEZE_WEAR_OFF_TIME)
    ------------------------------------------

    inst:AddComponent("inspectable")
    inst.components.inspectable:SetDescription("我会帮你解脱的....")
    ------------------------------------------
	MakeHauntablePanic(inst)
	------------------------------------------
   
	inst:SetBrain(infectedbrain)
    inst:SetStateGraph("SGinfecteds")
	
	OnChange(inst)
	inst:DoTaskInTime(0.1,function()makeweapon(inst,weapon_list[math.random(1,#weapon_list)])end)
	inst:WatchWorldState("startday", OnChange)
    inst:ListenForEvent("attacked", OnAttacked)
    inst:ListenForEvent("newcombattarget", OnNewTarget)

    return inst
end

local ly_people = 
{
	"wilson",
	"wathgrithr",
	"wendy",
	"wes",
	"waxwell",
	"webber",
	"wolfgang",
	"wickerbottom",
	"willow",
	"winona",
	"woodie",
	"wx78",
	"infected_army"------异化作战体大军
}

local prefabs_infected = {}

for k,v in pairs(ly_people) do 
	if v == "infected_army" then 
		local function armys()
			local inst = CreateEntity()
			inst.entity:AddTransform()
			inst.entity:AddNetwork()
			inst.entity:SetPristine()
			
			if not TheWorld.ismastersim then
				return inst
			end
			
			inst:DoTaskInTime(0,function()
				for k,v in pairs(ly_people) do
					if v ~=  "infected_army" then 
						local x,y,z = inst:GetPosition():Get()
						local eny = SpawnPrefab(v.."_infected")
						eny.Transform:SetPosition(x,y,z)
					end 
				end
			inst:Remove()
			end)
			return inst
		end 
		table.insert(prefabs_infected,Prefab(v,armys))
	else
		local function Infecteds()
			local inst = common(v.."_infected","wilson",v,"idle")
			return inst
		end
		table.insert(prefabs_infected,Prefab(v.."_infected", Infecteds, assets))
	end 
end


return unpack(prefabs_infected)
