local assets=
{
	Asset("ANIM", "anim/armor_metalplate.zip"),
	Asset("IMAGE","images/inventoryimages/armor_metalplate.tex"),
	Asset("ATLAS","images/inventoryimages/armor_metalplate.xml"),
    --Asset("INV_IMAGE", "metalplatehat"),
}

local function OnBlocked(owner) 
    owner.SoundEmitter:PlaySound("dontstarve/wilson/hit_armour") 
end

local function onequip(inst, owner) 
    owner.AnimState:OverrideSymbol("swap_body", "armor_metalplate", "swap_body")
    inst:ListenForEvent("blocked", OnBlocked, owner)
end

local function onunequip(inst, owner) 
    owner.AnimState:ClearOverrideSymbol("swap_body")
    inst:RemoveEventCallback("blocked", OnBlocked, owner)
end

local function fn(Sim)
	local inst = CreateEntity()
    
	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddNetwork()
	
    MakeInventoryPhysics(inst)
    
    inst.AnimState:SetBank("armor_metalplate")
    inst.AnimState:SetBuild("armor_metalplate")
    inst.AnimState:PlayAnimation("anim")
	
	inst:AddTag("metal")
	
	inst.entity:SetPristine()
	
    if not TheWorld.ismastersim then
        return inst
    end
   
    inst:AddComponent("inspectable")
    
    inst:AddComponent("inventoryitem")
    inst.components.inventoryitem.foleysound = "dontstarve_DLC003/movement/iron_armor/foley_player"
	inst.components.inventoryitem.imagename = "armor_metalplate"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/armor_metalplate.xml"
    
    inst:AddComponent("armor")
    inst.components.armor:InitCondition(1200,0.90)
    
    inst:AddComponent("equippable")
    inst.components.equippable.equipslot = EQUIPSLOTS.BODY
    --inst.components.equippable.walkspeedmult = 0.90
	inst.components.equippable.stamina_consumerate = 1.50
	inst.components.equippable.stamina_recoverrate = 0.85
    
    inst.components.equippable:SetOnEquip( onequip )
    inst.components.equippable:SetOnUnequip( onunequip )
    


    return inst
end

return Prefab( "armor_metalplate", fn, assets) 
