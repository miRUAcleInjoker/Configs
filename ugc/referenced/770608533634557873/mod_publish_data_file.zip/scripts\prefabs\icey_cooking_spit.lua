require "prefabutil"

local assets =
{
	Asset("ANIM", "anim/cooking_spit.zip"),
	
	Asset( "IMAGE", "images/inventoryimages/icey_cooking_spit.tex" ),
	Asset( "ATLAS", "images/inventoryimages/icey_cooking_spit.xml" ),
}

local prefabs =
{
    -- everything it can "produce" and might need symbol swaps from
    "smallmeat",
    "smallmeat_dried",
    "monstermeat",
    "monstermeat_dried",
    "humanmeat",
    "humanmeat_dried",
    "meat",
    "meat_dried",
    "drumstick", -- uses smallmeat_dried
    "batwing", --uses smallmeat_dried
    "fish", -- uses smallmeat_dried
    "froglegs", -- uses smallmeat_dried
    "eel",
    "collapse_small",
}

local function onhammered(inst, worker)
    if inst.components.burnable ~= nil and inst.components.burnable:IsBurning() then
        inst.components.burnable:Extinguish()
    end
    inst.components.lootdropper:DropLoot()
    if inst.components.dryer ~= nil then
        inst.components.dryer:DropItem()
    end
    local fx = SpawnPrefab("collapse_small")
    fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
    fx:SetMaterial("wood")
    inst:Remove()
end

local function onhit(inst, worker)
    if not inst:HasTag("burnt") then
        if inst.components.dryer ~= nil and inst.components.dryer:IsDrying() then
            inst.AnimState:PlayAnimation("hit_full")
            inst.AnimState:PushAnimation("cooking_pre", false)
            inst.AnimState:PushAnimation("cooking_loop", true)
        elseif inst.components.dryer ~= nil and inst.components.dryer:IsDone() then
            inst.AnimState:PlayAnimation("hit_full")
            inst.AnimState:PushAnimation("idle_full", false)
        else
            inst.AnimState:PlayAnimation("hit_empty")
            inst.AnimState:PushAnimation("idle_empty", false)
        end
    end
end

local function getstatus(inst)
    if inst:HasTag("burnt") then
        return "BURNT"
    elseif inst.components.dryer ~= nil then
        return (inst.components.dryer:IsDone() and "DONE")
            or (inst.components.dryer:IsDrying() and
                (TheWorld.state.israining and "DRYINGINRAIN" or "DRYING"))
            or nil
    end
end

local function onstartdrying(inst, ingredient)
    inst.AnimState:PlayAnimation("cooking_pre")
    inst.AnimState:PushAnimation("cooking_loop", true)
    inst.AnimState:OverrideSymbol("swap_dried", "meat_rack_food", ingredient)
	inst.Light:Enable(true)
end

local function ondonedrying(inst, product)
    inst.AnimState:PlayAnimation("cooking_pst")
    inst.AnimState:PushAnimation("idle_full", false)
    inst.AnimState:OverrideSymbol("swap_dried", "meat_rack_food", product)
	inst.Light:Enable(false)
end

local function onharvested(inst)
    inst.AnimState:PlayAnimation("idle_empty")
	inst.Light:Enable(false)
end

local function onbuilt(inst)
    inst.AnimState:PlayAnimation("place")
    inst.AnimState:PushAnimation("idle_empty", false)
    inst.SoundEmitter:PlaySound("dontstarve/common/meat_rack_craft")
end

local function onsave(inst, data)
    if inst:HasTag("burnt") or (inst.components.burnable ~= nil and inst.components.burnable:IsBurning()) then
        data.burnt = true
    end
end

local function onload(inst, data)
    if data ~= nil and data.burnt then
        inst.components.burnable.onburnt(inst)
    end
end

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddMiniMapEntity()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()
	inst.entity:AddLight()
	
	inst.Light:Enable(false)
    inst.Light:SetRadius(.6)
    inst.Light:SetFalloff(1)
    inst.Light:SetIntensity(.5)
    inst.Light:SetColour(235/255,62/255,12/255)

    inst.MiniMapEntity:SetIcon("meatrack.png")

    inst:AddTag("structure")

    inst.AnimState:SetBank("cookling_spit")
    inst.AnimState:SetBuild("cooking_spit")
    inst.AnimState:PlayAnimation("idle_empty")
    inst.AnimState:Hide("mouseover")

    MakeSnowCoveredPristine(inst)
	MakeObstaclePhysics(inst, .5)
	
	--inst.nameoverride = "meatrack" 

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst:AddComponent("lootdropper")
    inst:AddComponent("workable")
    inst.components.workable:SetWorkAction(ACTIONS.HAMMER) -- should be DRY
    inst.components.workable:SetWorkLeft(4)
    inst.components.workable:SetOnFinishCallback(onhammered)
    inst.components.workable:SetOnWorkCallback(onhit)

    MakeHauntableWork(inst)

    inst:AddComponent("dryer")
    inst.components.dryer:SetStartDryingFn(onstartdrying)
    inst.components.dryer:SetDoneDryingFn(ondonedrying)
    inst.components.dryer:SetOnHarvestFn(onharvested)
	inst.components.dryer.protectedfromrain = true 

    inst:AddComponent("inspectable")
	inst.components.inspectable.nameoverride = "meatrack"
    inst.components.inspectable.getstatus = getstatus
	
    MakeSnowCovered(inst)
    inst:ListenForEvent("onbuilt", onbuilt)

    MakeMediumBurnable(inst, nil, nil, true)
    MakeSmallPropagator(inst)

    inst.OnSave = onsave 
    inst.OnLoad = onload

    return inst
end

return Prefab("icey_cooking_spit", fn, assets, prefabs ),
    MakePlacer("icey_cooking_spit_placer", "cookling_spit", "cooking_spit", "idle_empty",
        nil, nil, nil, nil, nil, nil,
        function(inst)
            inst.AnimState:Hide("mouseover")
        end)
