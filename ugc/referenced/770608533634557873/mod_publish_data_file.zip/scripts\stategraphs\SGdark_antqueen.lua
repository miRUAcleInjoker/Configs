require("stategraphs/commonstates")
local TadalinUtil = require("tadalin_util")

local actionhandlers =
{
}

local events=
{
    --CommonHandlers.OnSleep(),
    --CommonHandlers.OnFreeze(),
    EventHandler("doattack", function(inst,data) 
        if not inst.components.health:IsDead() and not inst.sg:HasStateTag("busy") and not inst.sg:HasStateTag("locomoting")  then 
			if inst.warrior_count <= 2 and inst.skill_summon then
				inst:PushEvent("use_antqueen_skill",{cd = 20,name = "skill_summon"}) 
				inst.sg:GoToState("summon_warriors") 
			elseif inst.skill_music then 
				inst:PushEvent("use_antqueen_skill",{cd = 45,name = "skill_music"}) 
				inst.sg:GoToState("music_attack") 
			elseif inst.skill_jump then 
				inst:PushEvent("use_antqueen_skill",{cd = 5,name = "skill_jump"}) 
				inst.sg:GoToState("jump_attack") 
			else
				inst.sg:GoToState("walk_attack")
			end 
        end 
    end),
	EventHandler("locomote", function(inst) 
            if not inst.sg:HasStateTag("idle") and not inst.sg:HasStateTag("moving") then return end
            
            if not inst.components.locomotor:WantsToMoveForward() then
                if not inst.sg:HasStateTag("idle") and not inst.sg:HasStateTag("moving") then
                    inst.sg:GoToState("idle")
                end
            else
                if not inst.sg:HasStateTag("moving") then
					inst.sg:GoToState("walk")
                end
            end
    end),
    EventHandler("attacked", function(inst,data) 
		if not inst.sg:HasStateTag("busy") and not inst.sg:HasStateTag("locomoting") and data.damage and data.damage >= 34 then
			inst.sg:GoToState("hit")
		end
	end),
    CommonHandlers.OnDeath(),
}

local function sanity_stun(inst) 
			local x,y,z = inst:GetPosition():Get()
			local ents = TheSim:FindEntities(x,y,z,15,{"_combat"})
			for k,v in pairs(ents) do 
				if TadalinUtil.CanAttack(v) then 
					if v.components.sanity then 
						v.components.sanity:DoDelta(-0.75)
					end
					if v.components.combat then 
						v.components.combat:GetAttacked(inst,0.75) 
					end
				end
				inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/taunt")
				ShakeAllCameras(CAMERASHAKE.VERTICAL, .7, .015, .8, inst, 20)
			end
end

local function ShakeIfClose(inst)
    ShakeAllCameras(CAMERASHAKE.FULL, .5, .02, .2, inst, 30)
end

local function ShakePound(inst)
	inst.SoundEmitter:PlaySound("dontstarve/creatures/deerclops/bodyfall_dirt")
    ShakeAllCameras(CAMERASHAKE.FULL, 1.2, .03, .7, inst, 30)
end

local function ShakeRoar(inst)
    ShakeAllCameras(CAMERASHAKE.FULL, 0.8, .03, .5, inst, 30)
end

local function setfires(x,y,z, rad)
    for i, v in ipairs(TheSim:FindEntities(x, 0, z, rad, nil, { "laser", "DECOR", "INLIMBO","player","tadalin" })) do 
        if v.components.burnable and TadalinUtil.CanAttack(v)  then
            v.components.burnable:Ignite()
        end
    end
end
local function DoDamage(inst,pos,rad,damage,nofire)
    local targets = {}
	pos = pos or inst:GetPosition()
	damage = damage or 35
    local x, y, z = pos:Get()
	
	if not nofire then 
		setfires(x,y,z, rad)
	end 
    for i, v in ipairs(TheSim:FindEntities(x, 0, z, rad, nil, { "laser", "DECOR", "INLIMBO" , "tadalin" })) do  --  { "_combat", "pickable", "campfire", "CHOP_workable", "HAMMER_workable", "MINE_workable", "DIG_workable" }
		if TadalinUtil.CanAttack(v) then 
			if not targets[v] and v:IsValid() and not v:IsInLimbo() and not (v.components.health ~= nil and v.components.health:IsDead()) and not v:HasTag("laser_immune") then            
				local vradius = 0
				if v.Physics then
					vradius = v.Physics:GetRadius()
				end

				local range = rad + vradius
				if v:GetDistanceSqToPoint(Vector3(x, y, z)) < range * range then
					local isworkable = false
					if v.components.workable ~= nil then
						local work_action = v.components.workable:GetWorkAction()
						--V2C: nil action for campfires
						isworkable =
							(   work_action == nil and v:HasTag("campfire")    ) or
							
								(   work_action == ACTIONS.CHOP or
									work_action == ACTIONS.HAMMER or
									work_action == ACTIONS.MINE or   
									work_action == ACTIONS.DIG
								)
					end
					if isworkable then
						targets[v] = true
						v:DoTaskInTime(0.6, function() 
							if v.components.workable then
								v.components.workable:Destroy(inst) 
								local vx,vy,vz = v.Transform:GetWorldPosition()
								v:DoTaskInTime(0.3, function() setfires(vx,vy,vz,1) end)
							end
						 end)
						if v:IsValid() and v:HasTag("stump") then
						   -- v:Remove()
						end
					elseif v.components.pickable ~= nil
						and v.components.pickable:CanBePicked()
						and not v:HasTag("intense") then
						targets[v] = true
						local num = v.components.pickable.numtoharvest or 1
						local product = v.components.pickable.product
						local x1, y1, z1 = v.Transform:GetWorldPosition()
						v.components.pickable:Pick(inst) -- only calling this to trigger callbacks on the object
						if product ~= nil and num > 0 then
							for i = 1, num do
								local loot = SpawnPrefab(product)
								loot.Transform:SetPosition(x1, 0, z1)
								targets[loot] = true
							end
						end

					elseif v.components.health and v.components.combat then                    
						--inst.components.combat:DoAttack(v)   
						v.components.combat:GetAttacked(inst,damage)             
						if v:IsValid() then
							if not v.components.health or not v.components.health:IsDead() then
								if v.components.freezable ~= nil then
									if v.components.freezable:IsFrozen() then
										v.components.freezable:Unfreeze()
									elseif v.components.freezable.coldness > 0 then
										v.components.freezable:AddColdness(-2)
									end
								end
								if v.components.temperature ~= nil then
									local maxtemp = math.min(v.components.temperature:GetMax(), 10)
									local curtemp = v.components.temperature:GetCurrent()
									if maxtemp > curtemp then
										v.components.temperature:DoDelta(math.min(10, maxtemp - curtemp))
									end
								end
							end
						end                   
					end
					if v:IsValid() and v.AnimState then
						SpawnPrefab("deerclops_laserhit"):SetTarget(v)
					end
				end
			end
		end
    end
end

local function WalkJumpPound(inst)
	ShakePound(inst)	
	DoDamage(inst,nil,6,12,true)
	local pos = inst:GetPosition()
	for i=1,2+math.random()*3 do 
		local trail = SpawnPrefab("damp_trail")
		local randadd = Vector3(1-math.random()*2,0,1-math.random()*2)
		local spawnpos = pos + randadd
		trail.Transform:SetPosition(spawnpos:Get()) 
		trail:SetVariation(math.random(1,7),1+math.random()*0.55,1.5+math.random()*2)
	end 
end 

local function EarthQuake(inst)
	print("EarthQuake !!")
	local ring = SpawnPrefab("laser_ring")
    ring.Transform:SetPosition(inst.Transform:GetWorldPosition())
    ring.Transform:SetScale(1.22, 1.22, 1.22)
	inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/enemy/metal_robot/head/servo")
	inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/enemy/metal_robot/smash")
	DoDamage(inst,nil,8,25)
	ShakePound(inst)
end 

local states=
{
    State{
        name= "idle",
        tags = {"idle"},
        
        onenter = function(inst)
            inst.Physics:Stop()
            -- inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/crickant/hunger")
            inst.AnimState:PlayAnimation("idle")
        end,
        
        events =
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end ),
        },
    },


    State{
        name= "taunt",
        tags = {"busy"},
        
        onenter = function(inst)
            inst.Physics:Stop()
            inst.AnimState:PlayAnimation("taunt")
        end,
        
        timeline=
        {
            TimeEvent(18*FRAMES, function(inst)inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/taunt")end),
        },

        events =
        {
            EventHandler("animover", function(inst) 
                inst.sg:GoToState("idle") 
            end ),
        },
    },
	
	
	State
    {
        name = "walk",
        tags = { "moving", "canrotate","locomoting" },

        onenter = function(inst)
			inst.Physics:Stop() 
            inst.AnimState:PlayAnimation("atk2",false)
            inst.sg:SetTimeout(inst.AnimState:GetCurrentAnimationLength())
        end,

        timeline = {
			TimeEvent(1*FRAMES, function(inst)inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/atk_2_fly") end),
            TimeEvent(5*FRAMES, function(inst) inst.components.locomotor:WalkForward() end ),
			TimeEvent(7*FRAMES, function(inst)inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/atk_2_VO") end),
            TimeEvent(21*FRAMES, function(inst)inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/land") end),
            TimeEvent(24*FRAMES, function(inst) 
				WalkJumpPound(inst)	
				inst.Physics:Stop() 
			end),
		},

        ontimeout = function(inst)
			inst.Physics:Stop()
			inst.sg:GoToState("idle")
		end,
    },
	
	State
    {
        name = "walk_attack",
        tags = { "moving", "canrotate","locomoting" },

        onenter = function(inst,target)
			inst.Physics:Stop() 
            inst.AnimState:PlayAnimation("atk2",false)
            inst.sg:SetTimeout(inst.AnimState:GetCurrentAnimationLength())
			target = target or inst.components.combat.target 
			if target and target:IsValid() then 
				inst:ForceFacePoint(target:GetPosition():Get())
				inst.Physics:SetMotorVelOverride(8,0,0)
				inst.sg.statemem.jumptarget = target
			end 
        end,

        timeline = {
			TimeEvent(1*FRAMES, function(inst)inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/atk_2_fly") end),
			TimeEvent(7*FRAMES, function(inst)inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/atk_2_VO") end),
            TimeEvent(21*FRAMES, function(inst)inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/land") end),
            TimeEvent(24*FRAMES, function(inst) 
				WalkJumpPound(inst)	
				inst.Physics:Stop() 
			end),
		},
		
		onexit = function(inst)
			inst.sg.statemem.jumptarget = nil 
		end,

        ontimeout = function(inst)
			inst.Physics:Stop()
			inst.sg:GoToState("idle")
		end,
    },

    State{
        name = "jump_attack",
        tags = {"busy"},

        onenter = function (inst,target)
			inst.components.locomotor:StopMoving()
			inst.AnimState:PlayAnimation("atk2", false)
			target = target or inst.components.combat.target 
			if target and target:IsValid() then 
				inst:ForceFacePoint(target:GetPosition():Get())
				inst.Physics:SetMotorVelOverride(20+math.random()*6,0,0)
				--inst.components.locomotor:GoToPoint(target:GetPosition(),nil,true)
				inst.sg.statemem.jumptarget = target
			end 
			if inst.current_jump_count <= 0 then
                inst.current_jump_count = inst.jump_count
            end
        end,
		
		onexit = function(inst)
			inst.sg.statemem.jumptarget = nil 
			inst.Physics:Stop()
			inst.components.locomotor:StopMoving()
		end,
		

        timeline=
        {
            TimeEvent(1*FRAMES, function(inst)inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/atk_2_fly") end),
            TimeEvent(7*FRAMES, function(inst)inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/atk_2_VO") end),
            TimeEvent(21*FRAMES, function(inst)inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/land") end),
            TimeEvent(24*FRAMES, function(inst) 
				EarthQuake(inst)	
				inst.Physics:Stop()
				inst.components.locomotor:StopMoving()
			end),
        },

        events =
        {
            EventHandler("animqueueover", function(inst) 
				inst.current_jump_count = inst.current_jump_count - 1
                if inst.current_jump_count > 0 then
                    inst.sg:GoToState("jump_attack",inst.sg.statemem.jumptarget)
                else
                    inst.sg:GoToState("idle")
                end 
			end ),
        },
    },

    State{
        name = "summon_warriors",
        tags = {"busy"},

        onenter = function (inst)
			inst.components.locomotor:StopMoving()
            inst.AnimState:PlayAnimation("atk1", false)

            if inst.current_summon_count <= 0 then
                inst.current_summon_count = inst.summon_count
            end

        end,

        events =
        {
            EventHandler("animover", function(inst)
                inst.current_summon_count = inst.current_summon_count - 1
                
                if inst.current_summon_count > 0 then
                    inst.sg:GoToState("summon_warriors")
                else
                    inst.sg:GoToState("idle")
                end
            end),
        },

        timeline = 
        {   
            TimeEvent(1*FRAMES, function(inst)inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/atk_1_rumble") end),
            TimeEvent(18*FRAMES, function(inst)inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/atk_1_pre") end),
            TimeEvent(20*FRAMES, function(inst)inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/atk_1") end),
            TimeEvent(20*FRAMES, function(inst)  inst.SpawnWarrior(inst) end),
        },
    },

    State{
        name = "music_attack",
        tags = {"busy"},

        onenter = function (inst)
			inst.components.locomotor:StopMoving()
            inst.AnimState:PlayAnimation("atk3_pre", false)
            inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/atk_3_breath_in")
            
            
            for i=1,4 do
                inst.AnimState:PushAnimation("atk3_loop", false)
            end
            
            inst.AnimState:PushAnimation("atk3_pst", false)
        end,

        timeline = 
        {
			TimeEvent(24*FRAMES, function (inst)
				if inst.music_attack_task then 
					inst.music_attack_task:Cancel()
				end 
				inst.music_attack_task = nil 
				inst.music_attack_task = inst:DoPeriodicTask(0.03,sanity_stun) 
			end),
            TimeEvent(5*FRAMES, function (inst)  inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/atk_3_breath_in") end),
            TimeEvent(22*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/insane_LP","insane") end),
        },

        events =
        {
            EventHandler("animqueueover", function(inst) inst.sg:GoToState("idle") end ),
        },

        onexit = function(inst)
            inst.SoundEmitter:KillSound("insane")
			if inst.music_attack_task then 
				inst.music_attack_task:Cancel()
			end 
			inst.music_attack_task = nil 
            -- TheMixer:PopMix("mute")
            print("mix_off")           
        end,
    },

    State {
        name = "frozen",
        tags = {"busy"},

        onenter = function(inst)
            inst.AnimState:PlayAnimation("frozen")
            inst.Physics:Stop()
        end,
    },
    
    State{
        name = "death",
        tags = {"busy"},
        
        onenter = function(inst)
            inst.AnimState:PlayAnimation("death")
            inst.Physics:Stop()
            RemovePhysicsColliders(inst)
			inst.components.lootdropper:SpawnLootPrefab("dark_antqueen_cinder",inst:GetPosition())
            inst.components.lootdropper:DropLoot(Vector3(inst.Transform:GetWorldPosition()))
        end,

        timeline = 
        {

            TimeEvent(6*FRAMES, function (inst)  inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/death") end),
            TimeEvent(6*FRAMES, function (inst)  inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/explode",nil,.2) end),
            TimeEvent(10*FRAMES, function (inst)  inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/explode",nil,.3) end),
            TimeEvent(14*FRAMES, function (inst)  inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/explode",nil,.4) end),
            TimeEvent(18*FRAMES, function (inst)  inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/explode",nil,.5) end),
            TimeEvent(22*FRAMES, function (inst)  inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/explode",nil,.6) end),
            TimeEvent(26*FRAMES, function (inst)  inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/explode",nil,.7) end),
            TimeEvent(28*FRAMES, function (inst)  inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/explode") end),
            TimeEvent(43*FRAMES, function (inst)  inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/land") end),
            TimeEvent(1*FRAMES, function(inst)
--[[                inst:DoTaskInTime(2, function() 
                    local throne = SpawnPrefab("antqueen_throne")
                    local x,y,z = inst.Transform:GetWorldPosition()
                    throne.Transform:SetPosition( x-0.025, y, z )

                    inst.AnimState:ClearOverrideBuild("throne")
                end)--]]
            end ),
        },
    },
    
    State{
        name = "hit",
        tags = {"busy"},
        
        onenter = function(inst)
            inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/hit")
            inst.AnimState:PlayAnimation("hit")
            inst.Physics:Stop()
        end,
        
        events=
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end ),
        },
    },
}

CommonStates.AddSleepStates(states,
    {
        
        starttimeline = 
        {
            TimeEvent(35*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/breath_out") end),
        },

        sleeptimeline = 
        {
            TimeEvent(6*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/breath_in") end ),
            TimeEvent(36*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/antqueen/breath_out") end ),
        },
    },
    {
        -- The queen always taunts the player after waking up
        onwake = function(inst)
            inst:DoTaskInTime(18*FRAMES, function() inst.sg:GoToState("taunt") end)
        end,
    }
)

CommonStates.AddFrozenStates(states)
return StateGraph("SGdark_antqueen", states, events, "idle", actionhandlers)