IceyAchievementReplica = Class(function(self,inst,name,current,max,bonus)
	self.inst = inst
	self.name = net_string(inst.GUID, "IceyAchievementReplica."..name..".name") 
	self.current = net_ushortint(inst.GUID, "IceyAchievementReplica."..name..".current") 
	self.max = net_ushortint(inst.GUID, "IceyAchievementReplica."..name..".max") 
	
	self.name:set(name)
	self.current:set(current or 0)
	self.max:set(max or 1)
end) 

function IceyAchievementReplica:__tostring()
	local ret = "[IceyAchievementReplica]"
	ret = ret.." Name:"..self.name:value().." Process:"..self.current:value().."/"..self.max:value()
	return ret 
end 

function IceyAchievementReplica:GetProcessDisplay()
	return self.current:value().."/"..self.max:value()
end 

function IceyAchievementReplica:IsAchieved()
	return self.current:value() >= self.max:value()
end 

function IceyAchievementReplica:GetPercent()
	return self.current:value() / self.max:value()
end 

function IceyAchievementReplica:SetVal(val)
	local finalval = val
	finalval = math.max(finalval,0)
	finalval = math.min(finalval,self.max:value())
	
	self.current:set(finalval)
end 

--------------------------------------------------------------------


local IceyAchievementUser = Class(function(self, inst)
	self.inst = inst
	self.achievements = {
		--IceyAchievementReplica(inst,"first_eat"),
		--IceyAchievementReplica(inst,"first_killother"),
	}
	for k,v in pairs(TUNING.ICEY_ALL_ACHIEVEMENTS_LIST) do 
		table.insert(self.achievements,IceyAchievementReplica(inst,v.name,v.current,v.max,v.bonus))
	end 
end)

function IceyAchievementUser:Get(name)
	for k,v in pairs(self.achievements) do 
		if v.name:value() == name then 
			return v
		end
	end
end 

function IceyAchievementUser:GetProcessDisplay(name)
	return self:Get(name):GetProcessDisplay()
end 

function IceyAchievementUser:IsAchieved(name)
	local ache = self:Get(name) 
	return ache and ache:IsAchieved()
end

function IceyAchievementUser:SetVal(name,val)
	print("Replica Ready to update !!!")
	local ache = self:Get(name) 
	ache:SetVal(val) 
end

function IceyAchievementUser:GetDebugString()
	local start = "[IceyAchievementUserReplica]:Debug\n"
	local middle = ""
	
	for k,v in pairs(self.achievements) do 
		middle = middle..tostring(v).."\n"
	end
	
	local ret = start..middle
	
	return ret
end

function IceyAchievementUser:Debug()
	print("[IceyAchievementUserReplica]:Debug")
	for k,v in pairs(self.achievements) do 
		print("   "..tostring(v))
	end
	print("[IceyAchievementUserReplica]:Debug Finished")
end

return IceyAchievementUser