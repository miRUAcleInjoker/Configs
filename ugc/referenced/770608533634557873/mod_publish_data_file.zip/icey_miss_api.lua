--[[AddStategraphPostInit("wilson", function(sg)
	local old_locomote = sg.events["locomote"].fn 
	sg.events["locomote"].fn = function(inst,data,...)
		local is_moving = inst.sg:HasStateTag("moving")
        local should_move = inst.components.locomotor:WantsToMoveForward()
		
		if inst:HasTag("icey_missing") then 
			return 
		end

		return old_locomote(inst,data,...)
	end 
end)

AddStategraphPostInit("wilson_client", function(sg)
	local old_locomote = sg.events["locomote"].fn 
	sg.events["locomote"].fn = function(inst,data,...)
		local is_moving = inst.sg:HasStateTag("moving")
        local should_move = inst.components.locomotor:WantsToMoveForward()
		
		if inst:HasTag("icey_missing") then 
			return 
		end

		return old_locomote(inst,data,...)
	end 
end)--]]