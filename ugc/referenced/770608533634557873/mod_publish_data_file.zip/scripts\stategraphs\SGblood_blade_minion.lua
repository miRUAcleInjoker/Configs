require("stategraphs/commonstates")

local AttackSgs = {
	attack_hop_pre = {rand = 0.25,cd = 5},
	attack_circle_pre = {rand = 0.25,cd = 10},
	attack_charge_pre = {rand = 0.25,cd = 7},
	attack = {rand = 0.25,cd = 0},
}

local function PickAttackSg(inst)
	local all_change = 0
	local probobaly_sg = {} 
	for k,v in pairs(AttackSgs) do 
		local last_cast_time = inst[k.."_lastcasttime"] or 0 
		if GetTime() - last_cast_time >= v.cd then 
			all_change = all_change + v.rand
			table.insert(probobaly_sg,{name = k,rand = v.rand})
		end
	end
	
	local lucknum = math.random()
	for k,v in pairs(probobaly_sg) do 
		lucknum = lucknum - v.rand
		if lucknum <= 0 then 
			return v.name
		end
	end
	
	return "attack"
end 

local function ApplyAttackSg(inst,sgname)
	inst[sgname.."_lastcasttime"] = GetTime() 
end 


local events=
{
    CommonHandlers.OnLocomote(true, true),
	EventHandler("doattack", function(inst,data)
		local target = data.target
		--[[if math.random() <= 0.5 then 
			inst.sg:GoToState("attack_hop_pre",target)
		elseif math.random() <= 0.5 then 
			inst.sg:GoToState("attack_circle_pre",target)
		else
			inst.sg:GoToState("attack",target)
		end --]]
		if not inst.sg:HasStateTag("attack") and not inst.sg:HasStateTag("busy") then 
			local sgname = PickAttackSg(inst)
			ApplyAttackSg(inst,sgname)
			inst.sg:GoToState(sgname,target)
		end 
	end),
}

local function ToggleOffPhysics(inst)
    inst.sg.statemem.isphysicstoggle = true
    inst.Physics:ClearCollisionMask()
    inst.Physics:CollidesWith(COLLISION.GROUND)
end

local function ToggleOnPhysics(inst)
    inst.sg.statemem.isphysicstoggle = nil
    inst.Physics:ClearCollisionMask()
    inst.Physics:CollidesWith(COLLISION.WORLD)
    inst.Physics:CollidesWith(COLLISION.OBSTACLES)
    inst.Physics:CollidesWith(COLLISION.SMALLOBSTACLES)
    inst.Physics:CollidesWith(COLLISION.CHARACTERS)
    inst.Physics:CollidesWith(COLLISION.GIANTS)
end

local function DoLunge(lunger,startingpos,targetpos)
	local mob_index = {}
	for i = 0,10 do
		lunger:DoTaskInTime(FRAMES*math.ceil(1+i/3.5), function()
			local offset = (targetpos - startingpos):GetNormalized()*(i*0.6)
			local fx = SpawnPrefab("spear_gungnir_lungefx")
			fx.Transform:SetPosition((startingpos+offset):Get())
			fx.AnimState:SetAddColour(1, 1, 0, 0.75)
			local x, y, z = (startingpos + offset):Get()
			lunger.Transform:SetPosition(x,y,z)
			lunger.components.combat:EnableAreaDamage(true) 
			lunger.components.combat:DoAreaAttack(lunger,2,nil,nil,nil,{"INLIMBO", "notarget", "noattack", "flight", "invisible", "playerghost"})
			lunger.components.combat:EnableAreaDamage(false) 
		end)
	end
end 


local states = {
	State{
        name = "taunt",
        tags = {"busy", "nointerrupt", "nomorph" },
        
        onenter = function(inst)
            inst.Physics:Stop()
            inst.AnimState:PlayAnimation("emote_fistshake")
			--local sound = math.random() <= 0.5 and "dontstarve/characters/wolfgang/grow_medtolrg" or "dontstarve/characters/wolfgang/shrink_lrgtomed"
			--inst.SoundEmitter:PlaySound(sound)
			--inst.SoundEmitter:PlaySound("dontstarve/sanity/rook/attack_1")
			inst:PlayFunnySound("taunt")
        end,
        
        events=
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end),
        },
    },
	State
    {
        name = "attack",
        tags = {"busy","attack", "notalking", "abouttoattack",},
        
        onenter = function(inst,target)
            inst.Physics:Stop()
			if target and target:IsValid() then 
				inst:ForceFacePoint(target:GetPosition():Get())
			end
			inst.components.combat:StartAttack()
            inst.AnimState:PlayAnimation("atk_pre")
            inst.AnimState:PushAnimation("atk", false)
			inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon", nil, nil, true)
			
			local startingpos = Vector3(inst.Transform:GetWorldPosition())
			local targetpos = Vector3(target.Transform:GetWorldPosition())
			
			inst.sg.statemem.target = target
			inst.sg.statemem.startingpos = startingpos
			inst.sg.statemem.targetpos = targetpos
			--inst.SoundEmitter:PlaySound("dontstarve/sanity/knight/attack_grunt")
			inst:PlayFunnySound("attack")
            inst.Physics:SetMotorVel(math.sqrt(distsq(startingpos.x,startingpos.z,targetpos.x,targetpos.z)) / (12 * FRAMES), 0 ,0)
        end,
		

        timeline = 
        {
			TimeEvent(8 * FRAMES, function(inst)
				inst.Physics:Stop()
                inst.Physics:SetMotorVel(0, 0, 0)
                inst.Physics:Teleport(inst.sg.statemem.targetpos.x, 0, inst.sg.statemem.targetpos.z)
                inst.components.combat:DoAttack() 
				
            end),
		},
        
        events =
        {
            EventHandler("animqueueover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("idle")
                end
            end),
        },
    },
	
	State{
        name = "attack_hop_pre",
        tags = { "aoe", "doing", "busy", "nointerrupt", "nomorph" },

        onenter = function(inst,target)
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("atk_leap_pre")
			if target and target:IsValid() then 
				inst:ForceFacePoint(target:GetPosition():Get())
			end
			inst.components.combat:StartAttack()
			
			inst.sg.statemem.target = target
			--inst.SoundEmitter:PlaySound("dontstarve/sanity/knight/taunt")
			inst.sg:SetTimeout(0.75+0.25*math.random())
        end,
		
		ontimeout = function(inst)
			inst.sg:GoToState("attack_hop",inst.sg.statemem.target)
		end,
		
		timeline = {
			TimeEvent(20 * FRAMES, function(inst)
				inst:PlayFunnySound("attack_hop")
			end) 
		},

        events =
        {
            EventHandler("animover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.AnimState:PlayAnimation("atk_leap_lag")
                end
            end),
        },
    },
	
	State
    {
        name = "attack_hop",
        tags = {"busy","attack", "notalking", "abouttoattack",},
        
        onenter = function(inst,target)
            inst.Physics:Stop()
			inst.Transform:SetEightFaced()
			if target and target:IsValid() then 
				inst:ForceFacePoint(target:GetPosition():Get())
			end
            inst.AnimState:PlayAnimation("atk_leap", false)
			inst.SoundEmitter:PlaySound("dontstarve/common/deathpoof") 
			local startingpos = Vector3(inst.Transform:GetWorldPosition())
			local targetpos = Vector3(target.Transform:GetWorldPosition())
			
			inst.sg.statemem.target = target
			inst.sg.statemem.startingpos = startingpos
			inst.sg.statemem.targetpos = targetpos
			inst.sg.statemem.flash = 0
			
            inst.Physics:SetMotorVel(math.sqrt(distsq(startingpos.x,startingpos.z,targetpos.x,targetpos.z)) / (12 * FRAMES), 0 ,0)
        end,
		
		onupdate = function(inst)
            if inst.sg.statemem.flash > 0 then
                inst.sg.statemem.flash = math.max(0, inst.sg.statemem.flash - .1)
                local c = math.min(1, inst.sg.statemem.flash)
                inst.components.colouradder:PushColour("leap", c, c, 0, 0)
            end
        end,
		
		onexit = function(inst)
			inst.components.combat:EnableAreaDamage(false) 
			inst.Transform:SetFourFaced()
		end,
		

        timeline = 
        {
			TimeEvent(10 * FRAMES, function(inst)
				
            end),
			
			TimeEvent(10 * FRAMES, function(inst)
                inst.components.colouradder:PushColour("leap", .1, .1, 0, 0)
            end),
            TimeEvent(11 * FRAMES, function(inst)
                inst.components.colouradder:PushColour("leap", .2, .2, 0, 0)
            end),
            TimeEvent(12 * FRAMES, function(inst)
                inst.components.colouradder:PushColour("leap", .4, .4, 0, 0)
                --ToggleOnPhysics(inst)
                inst.Physics:Stop()
                inst.Physics:SetMotorVel(0, 0, 0)
                inst.Physics:Teleport(inst.sg.statemem.targetpos.x, 0, inst.sg.statemem.targetpos.z)
            end),
            TimeEvent(13 * FRAMES, function(inst)
				local target = inst.sg.statemem.target
				if target and target:IsValid() then 
					local fx = SpawnPrefab("superjump_fx")
					fx:SetTarget(target)
					fx.Transform:SetScale(1.25,1.25,1.25)
				end
                inst.components.bloomer:PushBloom("leap", "shaders/anim.ksh", -2)
                inst.components.colouradder:PushColour("leap", 1, 1, 0, 0)
                inst.sg.statemem.flash = 1.3
                inst.sg:RemoveStateTag("nointerrupt")
				ShakeAllCameras(CAMERASHAKE.VERTICAL, .7, .015, .8, inst, 20)
				inst.components.combat:EnableAreaDamage(true) 
                inst.components.combat:DoAttack()
				inst.components.combat:EnableAreaDamage(false) 
				inst.SoundEmitter:PlaySound("dontstarve/common/destroy_smoke",nil,nil,true)
            end),
            TimeEvent(25 * FRAMES, function(inst)
                inst.components.bloomer:PopBloom("leap")
            end),
		},
        
        events =
        {
            EventHandler("animqueueover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("idle")
                end
            end),
        },
    },
	
	State{
        name = "attack_circle_pre",
        tags = { "aoe", "doing", "busy", "nointerrupt", "nomorph" },

        onenter = function(inst,target)
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("atk_leap_pre")
			if target and target:IsValid() then 
				inst:ForceFacePoint(target:GetPosition():Get())
			end
			inst.components.combat:StartAttack()
			
			--inst.SoundEmitter:PlaySound("dontstarve/sanity/rook/taunt") 
			inst.sg.statemem.target = target
			inst.CircleLoop = math.random(4,9)
			inst.sg:SetTimeout(0.6)
        end,
		
		ontimeout = function(inst)
			inst:PlayFunnySound("attack_circle")
			inst.sg:GoToState("attack_circle_loop",inst.sg.statemem.target)
		end,

        events =
        {
            EventHandler("animover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.AnimState:PlayAnimation("atk_leap_lag")
                end
            end),
        },
    },
	
	State{
		name = "attack_circle_loop",
        tags = { "attack", "notalking", "abouttoattack", "autopredict" ,"nointerrupt"},
		onenter = function(inst,target)
			inst.components.locomotor:Stop()
			inst.AnimState:SetDeltaTimeMultiplier(2)
            inst.AnimState:PlayAnimation("iceyatk_circle1")
			inst.AnimState:PushAnimation("iceyatk_circle2",false)
			inst.AnimState:PushAnimation("iceyatk_circle3",false)
            inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon",nil,nil,true)
            if target ~= nil and target:IsValid() then
                inst:ForceFacePoint(target.Transform:GetWorldPosition())
            end
			
			inst.SoundEmitter:PlaySound("dontstarve/common/lava_arena/fireball",nil,nil,true)
			
			local startingpos = Vector3(inst.Transform:GetWorldPosition())
			local targetpos = Vector3(target.Transform:GetWorldPosition())
			
			inst.sg.statemem.target = target
			inst.sg.statemem.startingpos = startingpos
			inst.sg.statemem.targetpos = targetpos
			
            inst.Physics:SetMotorVel(math.sqrt(distsq(startingpos.x,startingpos.z,targetpos.x,targetpos.z)) / (12 * FRAMES), 0 ,0)
			
            inst.sg:SetTimeout(8 * FRAMES)
		end,
		
		
		timeline =
		{
			TimeEvent(2 * FRAMES, function(inst)
                inst.components.combat:EnableAreaDamage(true) 
                inst.components.combat:DoAttack()
				inst.components.combat:EnableAreaDamage(false) 
				local fx = inst:SpawnChild("icey_seeleslash")
				fx.AnimState:SetMultColour(.4, .4, 0,0.8)
				fx.Transform:SetScale(0.95,0.95,0.95)
				inst.SoundEmitter:PlaySound("dontstarve/common/destroy_smoke",nil,nil,true)
            end),
		},

		ontimeout = function(inst)
			inst.CircleLoop = inst.CircleLoop - 1 
			local target = inst.sg.statemem.target
			if inst.CircleLoop <= 0 or not (target and target:IsValid() and target.components.health and not target.components.health:IsDead()) then 
				inst.Physics:Stop()
				inst.sg:GoToState("idle", true)
			else
				inst.sg:GoToState("attack_circle_loop",target)
			end 
		end,

		events =
		{
			EventHandler("onhitother", function(inst,data)
				SpawnPrefab("icey_weaponsparks"):SetPosition(inst,data.target)
				local target_pos = data.target:GetPosition()
				local function RotateFX(fx)
					fx.Transform:SetPosition(target_pos:Get())
					fx.Transform:SetRotation(inst.Transform:GetRotation())
				end
				local rand = math.random(1,2)
				if rand == 1 then
					RotateFX(SpawnPrefab("shadowstrike_slash_fx"))
				else
					RotateFX(SpawnPrefab("shadowstrike_slash2_fx"))
				end
			end),
		},

		onexit = function(inst)
			inst.components.combat:EnableAreaDamage(false) 
			inst.AnimState:SetDeltaTimeMultiplier(1)
		end,
			
	},
	
	
	State{
        name = "attack_charge_pre",
        tags = { "aoe", "doing", "busy", "nointerrupt", "nomorph" },

        onenter = function(inst,target)
            inst.components.locomotor:Stop()
			if target and target:IsValid() then 
				inst:ForceFacePoint(target:GetPosition():Get())
			end
			inst.components.combat:StartAttack()
			inst.sg.statemem.target = target
            inst.AnimState:PlayAnimation("lunge_pre")
			
			inst.sg:SetTimeout(math.random(8,12) * FRAMES)
        end,
		
		ontimeout = function(inst)
			inst:PlayFunnySound("attack_charge")
			inst.sg:GoToState("attack_charge",inst.sg.statemem.target)
		end,

        timeline =
        {
            TimeEvent(4 * FRAMES, function(inst)
                inst.SoundEmitter:PlaySound("dontstarve/common/twirl", nil, nil, true)
            end),
        },

        events =
        {
            EventHandler("animover", function(inst)
                if inst.AnimState:AnimDone() then
					inst.AnimState:PlayAnimation("lunge_lag")
                end
            end),
        },
    },
	
	State{
        name = "attack_charge",
        tags = { "aoe", "attack","doing", "busy", "nopredict", "nomorph" },

        onenter = function(inst, target)
            if target ~= nil then
				local pos = inst:GetPosition()
				local targetpos = pos + (target:GetPosition() - pos):GetNormalized()*5
                inst.AnimState:PlayAnimation("lunge_pst")
                inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon")
                
                inst:ForceFacePoint(targetpos:Get())
				DoLunge(inst,pos,targetpos)
                inst.SoundEmitter:PlaySound("dontstarve/common/lava_arena/fireball")
                --inst.Physics:Teleport(targetpos.x, 0, targetpos.z)
                inst.components.bloomer:PushBloom("lunge", "shaders/anim.ksh", -2)
                inst.components.colouradder:PushColour("lunge", 1, 1, 0, 0)
                inst.sg.statemem.flash = 1
                return
            end
            --Failed
            inst.sg:GoToState("idle", true)
        end,

        onupdate = function(inst)
            if inst.sg.statemem.flash > 0 then
                inst.sg.statemem.flash = math.max(0, inst.sg.statemem.flash - .1)
                inst.components.colouradder:PushColour("lunge", inst.sg.statemem.flash, inst.sg.statemem.flash, 0, 0)
            end
        end,

        timeline =
        {
            TimeEvent(12 * FRAMES, function(inst)
                inst.components.bloomer:PopBloom("lunge")
            end),
        },

        events =
        {
            EventHandler("animover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("idle")
                end
            end),
        },

        onexit = function(inst)
            inst.components.bloomer:PopBloom("lunge")
            inst.components.colouradder:PopColour("lunge")
        end,
    },
}

CommonStates.AddIdle(states,"idle_inaction")

CommonStates.AddWalkStates(states, 
	{},
	{
		startwalk = "sand_walk_pre",
		walk = "sand_walk",
		stopwalk = "sand_walk_pst",
	}
)

CommonStates.AddRunStates(states, 
	{},
	{
		startrun = "sand_walk_pre",
		run = "sand_walk",
		stoprun = "sand_walk_pst",
	}
)

return StateGraph("SGblood_blade_minion", states, events, "idle")