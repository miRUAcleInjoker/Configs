local function onname(self,val)
	self.inst.replica.darksouldebuff:SetName(val)
end 

local function ontarget(self,val)
	self.inst.replica.darksouldebuff:SetTarget(val)
end 

local function onpercent(self,val)
	self.inst.replica.darksouldebuff:SetPercent(val)
end 

local function onactivated(self,val)
	self.inst.replica.darksouldebuff:SetActivated(val)
end 

local function ondecrease_rate(self,val)
	self.inst.replica.darksouldebuff:SetDecreaseRate(val)
end 

local function ondecrease_rate_activated(self,val)
	self.inst.replica.darksouldebuff:SetDecreaseRateActivated(val)
end 

local DarkSoulDebuff = Class(function(self, inst)
    self.inst = inst
    --self.name = nil
    --self.target = nil
	
	self.percent = 0
	self.decrease_rate = 0.001
	self.decrease_rate_activated = 0.0005
	
	self.activated = false 
	self.activated_num = 0
	
    self.onattachedfn = nil
    self.ondetachedfn = nil
    self.onextendedfn = nil
	self.onactivatedfn = nil 
    self.keepondespawn = true
	
	
end,nil,{
	name = onname,
	target = ontarget,
	percent = onpercent,
	activated = onactivated,
	decrease_rate = ondecrease_rate,
	decrease_rate_activated = ondecrease_rate_activated,
})

function DarkSoulDebuff:SetAttachedFn(fn)
    self.onattachedfn = fn
end

function DarkSoulDebuff:SetDetachedFn(fn)
    self.ondetachedfn = fn
end

function DarkSoulDebuff:SetExtendedFn(fn)
    self.onextendedfn = fn
end

function DarkSoulDebuff:SetActivatedFn(fn)
	self.onactivatedfn = fn 
end 

function DarkSoulDebuff:IsActivated()
	return self.activated 
end 

function DarkSoulDebuff:GetPercent()
	return self.percent 
end 

--[[function DarkSoulDebuff:DoDelta(delta)
	self.percent = self.percent + delta 
	self.percent = math.max(0,self.percent)
	self.percent = math.min(1,self.percent)
	
	if self.percent >= 1 and not self.activated then 
		self:Activated()
	end
end --]]

function DarkSoulDebuff:Stop()
	self.inst:StopUpdatingComponent(self)
    if self.target ~= nil and self.target.components.darksouldebuffable ~= nil then
        self.target.components.darksouldebuffable:RemoveDebuff(self.name)
    end
end

--Should only be called by darksouldebuffable component
--��darksoulbuff�ո������ʱ����
--�ո������ʱ������������buff���ܶ�Ч��Ҫ��buff���۵�percent >= 1 ʱ��������������
function DarkSoulDebuff:AttachTo(name, target, followsymbol, followoffset)
    self.name = name
    self.target = target
	
    if self.onattachedfn ~= nil then
        self.onattachedfn(self.inst, target, followsymbol, followoffset)
    end
	
	if self.percent >= 1 and not self.activated then 
		self:Activated(followsymbol, followoffset)
	end 
	
	self.inst:StartUpdatingComponent(self)
end

--Should only be called by darksouldebuffable component
--��darksoulbuff����������Ƴ�ʱ����
function DarkSoulDebuff:OnDetach()
    local target = self.target
    --self.name = nil
    self.target = nil
    if self.ondetachedfn ~= nil then
        self.ondetachedfn(self.inst, target)
    end
end

--����������Ѿ���ͬ��darksoulbuff�ּ���һ��ʱ����
function DarkSoulDebuff:Extend(addpercent,followsymbol, followoffset)
	self.percent = self.percent + addpercent
	self.percent = math.min(1,self.percent)
	
    if self.onextendedfn ~= nil then
        self.onextendedfn(self.inst, self.target, followsymbol, followoffset)
    end
	
	if self.percent >= 1 and not self.activated then 
		self:Activated(followsymbol, followoffset)
	end 
end

function DarkSoulDebuff:Activated(followsymbol, followoffset)
	self.activated = true
	self.activated_num = self.activated_num + 1
	if self.onactivatedfn ~= nil then 
		self.onactivatedfn(self.inst, self.target,followsymbol, followoffset,self.activated_num)
	end
end 

function DarkSoulDebuff:OnUpdate(dt)
	self.percent = self.percent - (self.activated and self.decrease_rate_activated or self.decrease_rate)
	if self.percent <= 0 then 
		self:Stop()
		
	end
end

function DarkSoulDebuff:OnSave()
	return {
		percent = self.percent,
		activated = self.activated ,
		activated_num = self.activated_num,
		decrease_rate = self.decrease_rate,
		decrease_rate_activated = self.decrease_rate_activated,
		
	}
end

function DarkSoulDebuff:OnLoad(data)
	if data then 
		self.percent = data.percent
		self.activated = data.activated
		self.activated_num = data.activated_num
		self.decrease_rate = data.decrease_rate
		self.decrease_rate_activated = data.decrease_rate_activated
	end 
	
end

return DarkSoulDebuff
