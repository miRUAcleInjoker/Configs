local assets_line = {
	Asset("ANIM", "anim/xuhua_line.zip"),--------建筑的贴图文件
	--Asset("ANIM", "anim/wall.zip"),
    --Asset("ANIM", "anim/wall_stone.zip"),
	Asset("IMAGE","images/inventoryimages/xuhua_line.tex"),
	Asset("ATLAS","images/inventoryimages/xuhua_line.xml"),
	Asset("IMAGE","images/inventoryimages/power_line.tex"),
	Asset("ATLAS","images/inventoryimages/power_line.xml")
}

-------------------------------------------------------------------------------------------------------------------------

local function OnPowerTrans (inst,data)
	inst:DoTaskInTime(0.3,function()

    if inst.unactivetask ~= nil then 
        inst.unactivetask:Cancel()
        inst.unactivetask = nil
    end 
	
	inst.Light:Enable(true)

	local r,g,b,a = inst.transcolor[1],inst.transcolor[2],inst.transcolor[3],inst.transcolor[4]
	inst.AnimState:SetMultColour(r,g,b,a)
    inst.unactivetask = inst:DoTaskInTime(1,function()
		--inst.AnimState:PlayAnimation("broken") ----------喜闻乐见的动画设置
		inst.Light:Enable(false)
		inst.AnimState:SetMultColour(1,1,1,0)
    end)

    local x,y,z = inst:GetPosition():Get()
    local fromer = data.fromer
    local power  = data.power
	local mult   = inst.mult or 1
    local trans_build = TheSim:FindEntities(x,y,z,inst.trans_dist,{"icey_power_trans"},{"INLIMBO"})
	local use_build = TheSim:FindEntities(x,y,z,inst.use_dist,{"icey_power_use"},{"INLIMBO"})
	local ents = {}
	
	for k, v in pairs(trans_build) do
		table.insert(ents,v)
	end	
	
	for k, v in pairs(use_build) do
		table.insert(ents,v)
	end	
	
	local nums = #ents
	
	for k,v in pairs(ents) do 
		if v == inst or v == fromer then 
			nums = nums - 1
		end
	end 
	
	local trans = mult * (power/(nums))-0.5
	
	trans = math.min(1000,trans)
	
    for k,v in pairs(ents) do 
        if v ~= fromer and v ~= inst and trans > 0 then 
            v:PushEvent("powertrans",{fromer = inst,power = trans })
        end 
    end 
	end)
end

local function onhammered_line(inst)
	inst.components.lootdropper:DropLoot()
	local fx = SpawnPrefab("collapse_small")
    fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
	inst:Remove()
end 
---------------------------------------------------------------------------------
local function common_linefn(bank,build,anim,transcolor,lightcolor,mult,trans_dist,use_dist)
	 local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()
	inst.entity:AddLight()

	--MakeObstaclePhysics(inst, .5)
	
	inst.AnimState:SetOrientation(ANIM_ORIENTATION.OnGround)
    inst.AnimState:SetLayer(LAYER_WORLD_BACKGROUND)
    inst.AnimState:SetSortOrder(3)
	
	inst.Transform:SetEightFaced()
	
    inst.AnimState:SetBank(bank)
    inst.AnimState:SetBuild(build)
    inst.AnimState:PlayAnimation(anim) ----------喜闻乐见的动画设置

	
	--inst.Transform:SetScale(3,3,3)
	
	--[[inst.AnimState:SetBank("wall")
    inst.AnimState:SetBuild("wall_stone")
    inst.AnimState:PlayAnimation("half") ----------喜闻乐见的动画设置--]]
	
	
	inst.AnimState:SetMultColour(1,1,1,0)
	
	inst.Light:SetIntensity(0.7)
	inst.Light:SetRadius(0.2)
	inst.Light:SetFalloff(0.5)
	--inst.Light:SetColour(44/255,143/255,255/255)
	inst.Light:SetColour(lightcolor[1],lightcolor[2],lightcolor[3])
	inst.Light:Enable(false)
	
	inst:AddTag("icey_power_trans")
	inst:AddTag("icey_power_building")
	inst:AddTag("wall")
    inst:AddTag("noauradamage")
    inst:AddTag("nointerpolate")

	
	inst.transcolor = transcolor or {1,1,1,0}
	inst.mult = mult or 1
	inst.trans_dist = trans_dist or 1.2
	inst.use_dist = use_dist or 1.2
	
    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("这是虚化回路") ------------设置可检查组件
	--[[inst.components.inspectable.descriptionfn = function(inst,doer)
		inst:PushEvent("powertrans",{fromer = inst,power = 100 })
	end--]]
	
	inst:AddComponent("lootdropper")
	
	inst:AddComponent("workable")
    inst.components.workable:SetWorkAction(ACTIONS.HAMMER)
    inst.components.workable:SetWorkLeft(1)
    inst.components.workable:SetOnFinishCallback(onhammered_line)
	
    MakeHauntableWork(inst)--------------被作祟时的函数，这里是空的
 
	inst:ListenForEvent("powertrans",OnPowerTrans)
    return inst
end
-----------------------------------------------------------------------------------------------------------------



local function common_itemfn(bank,build,anim,depoyname)
	 local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()
	
	inst.AnimState:SetBank(bank)
    inst.AnimState:SetBuild(build)
    inst.AnimState:PlayAnimation(anim) ----------喜闻乐见的动画设置
	
	--inst:AddTag("wallbuilder")
	inst:AddTag("eyeturret")
	
	local function ondeploywall(inst,pt)
	local wall = SpawnPrefab(depoyname) 
	print("On deploy:",wall)
        if wall ~= nil then 
            local x = math.floor(pt.x) + .5
            local z = math.floor(pt.z) + .5
           --[[ wall.Physics:SetCollides(false)
            wall.Physics:Teleport(x, 0, z)
            wall.Physics:SetCollides(true)--]]
			wall.Transform:SetPosition(x,0,z)
			local ents = TheSim:FindEntities(x,0,z,0.3,{"icey_power_trans"})
			if #ents >= 2 then 
				wall.components.workable:Destroy(inst)
			end 
			inst.components.stackable:Get():Remove()
        end
	end 

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst:AddComponent("inspectable")
	
	inst:AddComponent("inventoryitem")
	
	inst:AddComponent("stackable")
	inst.components.stackable.maxsize = TUNING.STACK_SIZE_SMALLITEM
	
	inst:AddComponent("deployable")
    inst.components.deployable.ondeploy = ondeploywall
	inst.components.deployable:SetDeployMode(DEPLOYMODE.ANYWHERE)
	inst.components.deployable:SetDeploySpacing(DEPLOYSPACING.NONE)
	
    MakeHauntableWork(inst)--------------被作祟时的函数，这里是空的
    return inst
end

local function xuhua_line()
	local inst = common_linefn("xuhua_line","xuhua_line","idle",{44/255,143/255,255/255,0},{44/255,143/255,255/255},1,1.2,1.2)
	if not TheWorld.ismastersim then
        return inst
    end
	inst.components.lootdropper:SetLoot({"xuhua_line_item"})
	inst.components.inspectable:SetDescription("这是虚化回路")
	return inst 
end

local function xuhua_item()
	local inst = common_itemfn("xuhua_line","xuhua_line","item","xuhua_line")
	
	if not TheWorld.ismastersim then
        return inst
    end
	
	inst.components.inspectable:SetDescription("便携式虚化回路组件") ------------设置可检查组件
	inst.components.inventoryitem.imagename = "xuhua_line"
	inst.components.inventoryitem.atlasname = "images/inventoryimages/xuhua_line.xml"
	
	return inst
end 

local function power_line()
	local inst = common_linefn("xuhua_line","xuhua_line","idle",{187/255,0/255,0/255,0},{187/255,0/255,0/255},10,1.2,3)
	if not TheWorld.ismastersim then
        return inst
    end
	inst.components.lootdropper:SetLoot({"power_line_item"})
	inst.components.inspectable:SetDescription("这是强化回路")
	return inst 
end

local function power_item()
	local inst = common_itemfn("xuhua_line","xuhua_line","item_super","power_line")
	
	if not TheWorld.ismastersim then
        return inst
    end
	
	inst.components.inspectable:SetDescription("便携式强化回路组件") ------------设置可检查组件
	inst.components.inventoryitem.imagename = "power_line"
	inst.components.inventoryitem.atlasname = "images/inventoryimages/power_line.xml"
	
	return inst
end 

return Prefab("xuhua_line", xuhua_line, assets_line),
Prefab("xuhua_line_item", xuhua_item, assets_line),
MakePlacer("xuhua_line_item_placer", "xuhua_line", "xuhua_line", "idle"),

Prefab("power_line", power_line, assets_line),
Prefab("power_line_item", power_item, assets_line),
MakePlacer("power_line_item_placer", "xuhua_line", "xuhua_line", "idle")