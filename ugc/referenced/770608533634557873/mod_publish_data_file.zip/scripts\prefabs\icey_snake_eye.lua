local IceyUtil = require("icey_util")

local assets =
{ 
    --Asset("ANIM", "anim/chest_monster_hat.zip"),
    Asset("ANIM", "anim/swap_icey_snake_eye.zip"), 

    Asset("ATLAS", "images/inventoryimages/icey_snake_eye.xml"),
    Asset("IMAGE", "images/inventoryimages/icey_snake_eye.tex"),
}


local function EnableSnakeEye(owner,enable)
	if owner and owner.HUD then 
		--print(string.format("Ready to set owner %s snakeeye to %s",tostring(owmer),tostring(inst._isequipped:value())))
		owner.HUD:EnableSnakeEye(enable)
	end 
end 

local function OnEquip(inst, owner) 
	--swap_icey_hunter_hat1
	--ThePlayer.AnimState:OverrideSymbol("swap_hat", "swap_icey_snake_eye","swap_icey_snake_eye") ThePlayer.AnimState:Show("HAT")
    owner.AnimState:OverrideSymbol("swap_hat", "swap_icey_snake_eye","swap_icey_snake_eye")
    owner.AnimState:Show("HAT")


	
	inst._lastequipper:set(owner) 
	inst._isequipped:set(true)
	
	EnableSnakeEye(owner,true)
end

local function OnUnequip(inst, owner) 
	owner.AnimState:ClearOverrideSymbol("swap_hat")
    owner.AnimState:Hide("HAT")
	
	inst._isequipped:set(false)
	EnableSnakeEye(owner,false)
end

local function OnEquippedDirty(inst)
	local owner = inst._lastequipper:value()
	EnableSnakeEye(owner,inst._isequipped:value())
end 

local function fn()

    local inst = CreateEntity()
    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()  --�������Ҳ����� 
	
    MakeInventoryPhysics(inst)	
	inst.AnimState:SetBank("swap_icey_snake_eye")
    inst.AnimState:SetBuild("swap_icey_snake_eye")
    inst.AnimState:PlayAnimation("idle")
	
	inst:AddTag("hide_percentage")
	inst:AddTag("icey_snake_eye")
	
	inst._isequipped = net_bool(inst.GUID, "icey_snake_eye._isequipped","equippeddirty")
	inst._lastequipper = net_entity(inst.GUID, "icey_snake_eye._lastequipper")
	
	----------------------����Ķ��� ������������Ч
	
	inst.entity:SetPristine()   --���ľ仰 �ŵ����� Ҳ����bank build ��tag֮��ĺ���-��-
	if not TheWorld.ismastersim then
		inst:ListenForEvent("equippeddirty", OnEquippedDirty)
        return inst
    end
	
	----------------------�����ֻ������ִ��
	
    inst:AddComponent("inspectable")
	
	inst:AddComponent("waterproofer")
	inst.components.waterproofer:SetEffectiveness(TUNING.WATERPROOFNESS_SMALL)

    inst:AddComponent("inventoryitem")
    inst.components.inventoryitem.imagename = "icey_snake_eye"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/icey_snake_eye.xml"
	
	inst:AddComponent("armor")
    inst.components.armor:InitIndestructible(0.1)
	
    inst:AddComponent("equippable")
    inst.components.equippable.equipslot = EQUIPSLOTS.HEAD 
    inst.components.equippable:SetOnEquip(OnEquip)
    inst.components.equippable:SetOnUnequip(OnUnequip)
	
	inst:AddComponent("chosenicey")

	
	MakeHauntableLaunch(inst)  --����ź���ͺ���

    return inst
end

return  Prefab("icey_snake_eye", fn, assets, prefabs)