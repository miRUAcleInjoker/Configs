AddStategraphPostInit("wilson", function(sg)
	local old_attacked = sg.events["attacked"].fn 
	sg.events["attacked"].fn = function(inst,data)
		if not inst.components.health:IsDead() then
			if inst:HasTag("icey_exectuer") or inst.sg:HasStateTag("icey_skill_soul_torrent") then 
				return 
			end
		end

		return old_attacked(inst,data)
	end 
end)

--[[AddStategraphPostInit("wilson_client", function(sg)
	local old_attacked = sg.events["attacked"].fn 
	sg.events["attacked"].fn = function(inst)
		if not inst.replica.health:IsDead() then
			if inst:HasTag("icey_exectuer") then 
				return 
			end
		end

		
		return old_attacked(inst)
	end 
end)--]]