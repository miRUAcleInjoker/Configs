--[[--revivable_corpse

GAME_MODES.survival.revivable_corpse = true
GAME_MODES.wilderness.revivable_corpse = true
GAME_MODES.endless.revivable_corpse = true

AddComponentPostInit("revivablecorpse",function(self)
	self.onrevive = nil 
	self.corpse_maintain_time = 10
	
	
	local old_Revive = self.Revive
	self.Revive = function(self,reviver,...)
		if self.onrevive then 
			self.onrevive(self.inst,reviver)
		end
		return old_Revive(self,reviver,...)
	end
	
	self.StartCalcDeathTime = function(self)
		self.CalcDeathTimeTask = self.inst:DoTaskInTime(self.corpse_maintain_time,function()
			self:ReleaseGhost()
		end)
	end 
	
	self.StopCalcDeathTime = function(self)
		if self.CalcDeathTimeTask then 
			self.CalcDeathTimeTask:Cancel()
		end
		self.CalcDeathTimeTask = nil 
	end 
		
		
	self.ReleaseGhost = function(self)
		self:StopCalcDeathTime()
		--self.inst:GoToState("")
	end

end)--]]