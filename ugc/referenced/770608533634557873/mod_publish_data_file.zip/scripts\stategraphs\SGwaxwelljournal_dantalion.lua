require("stategraphs/commonstates")


local events=
{
    CommonHandlers.OnLocomote(false, true),
	EventHandler("doattack", function(inst,data)
		local target = data.target
		if not inst.sg:HasStateTag("attack") and not inst.sg:HasStateTag("busy") then 
			if inst:CanSong() then 
				inst.sg:GoToState("song")
			else
				inst.sg:GoToState("attack",target)
			end
			
		end 
	end),
}

local function ToggleOffPhysics(inst)
    inst.sg.statemem.isphysicstoggle = true
    inst.Physics:ClearCollisionMask()
    inst.Physics:CollidesWith(COLLISION.GROUND)
end

local function ToggleOnPhysics(inst)
    inst.sg.statemem.isphysicstoggle = nil
    inst.Physics:ClearCollisionMask()
    inst.Physics:CollidesWith(COLLISION.WORLD)
    inst.Physics:CollidesWith(COLLISION.OBSTACLES)
    inst.Physics:CollidesWith(COLLISION.SMALLOBSTACLES)
    inst.Physics:CollidesWith(COLLISION.CHARACTERS)
    inst.Physics:CollidesWith(COLLISION.GIANTS)
end




local states = {
	State
    {
        name = "idle",
        tags = {"idle", "canrotate", "canslide"},
        onenter = function(inst)
			inst.Physics:Stop()
            inst.AnimState:PlayAnimation("idle", true)
        end,
    },
	
	
	State
    {
        name = "taunt",
        tags = {"taunt", "canrotate", "canslide","busy"},
        onenter = function(inst)
			inst.Physics:Stop()
            inst.AnimState:PlayAnimation("taunt")
        end,
		
		timeline=
        {
            TimeEvent(0*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/ancient_herald/taunt") end),
        },
		
		events=
        {
            EventHandler("animover", function(inst, data) inst.sg:GoToState("idle") end)
        },
    },
	
	
	State
    {
        name = "attack",
        tags = {"busy","attack", "notalking", "abouttoattack",},
        
        onenter = function(inst,target)
            if inst.components.locomotor ~= nil then
                inst.components.locomotor:StopMoving()
            end
			if target and target:IsValid() then 
				inst:ForceFacePoint(target:GetPosition():Get())
			end
			inst.components.combat:StartAttack()
			inst.sg.statemem.target = target
            inst.AnimState:PlayAnimation("attack")

			
		end,
		
		

        timeline = 
        {
			TimeEvent(0*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/ancient_herald/attack") end),
			TimeEvent(1*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/ancient_herald/attack_2d") end),
			TimeEvent(20 * FRAMES, function(inst)
                --inst.components.combat:DoAttack() 
				if inst.sg.statemem.target and inst.sg.statemem.target:IsValid() then
					local bullet = SpawnAt("blossom_projectile_dark_icey",inst:GetPosition())
					if not bullet.components.weapon then 
						bullet:AddComponent("weapon")
					end 
					bullet.components.weapon:SetDamage(inst.components.combat.defaultdamage)
					bullet.components.projectile:Throw(inst,inst.sg.statemem.target)
									
					bullet:DoTaskInTime(1,function()
						bullet.components.projectile:SetHoming(false)
					end)
				end 
			end),
		},
		
		events=
        {
            EventHandler("animover", function(inst, data) inst.sg:GoToState("idle") end)
        },
    },
	
	State
    {
        name = "song",
        tags = {"busy"},
        onenter = function(inst)
            inst.Physics:Stop()
            inst.AnimState:PlayAnimation("summon")
        end,
        
        timeline=
        {
            TimeEvent(0*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/ancient_herald/summon") end),
            TimeEvent(1*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/ancient_herald/summon_2d") end),
            TimeEvent(30*FRAMES, function(inst)
				if inst:CanSong() then 
					inst:DoSong()
				end
            end)
        },

        events=
        {
            EventHandler("animover", function(inst, data) inst.sg:GoToState("idle") end)
        },
    },
	
}


CommonStates.AddWalkStates(states,
{
    walktimeline = 
    {
        TimeEvent(0*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/ancient_herald/breath_in") end),
        TimeEvent(17*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/ancient_herald/breath_out") end),   
    }
})



return StateGraph("SGwaxwelljournal_dantalion", states, events, "idle")