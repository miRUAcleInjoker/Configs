local ShadowChess = require("stategraphs/SGshadow_chesspieces_my")

--See SGshadow_chesspieces_my.lua for CommonEventList
local NON_COLLAPSIBLE_TAGS = { "stalker", "flying", "shadow", "ghost", "playerghost", "FX", "NOCLICK", "DECOR", "INLIMBO" }
local function CanHitFn(inst,owner,target)
	if not target or not target:IsValid() then 
		return false
	end 
	for k,v in pairs(NON_COLLAPSIBLE_TAGS) do 
		if target:HasTag(v) then 
			return false
		end
	end
	return true
end 

local function DoBallsAttack(inst,target)
	if target and target:IsValid() and target.components.combat then 
		--inst:DoTaskInTime(math.random()*0.3,function()inst.SoundEmitter:PlaySound("dontstarve/sanity/creature1/die")end)
		local bullet = SpawnPrefab("dark_projectile_icey")
		local x,y,z = inst:GetPosition():Get()
		--[[if not bullet.components.weapon then 
			bullet:AddComponent("weapon")
		end 
		bullet.components.weapon:SetDamage(math.random()*5 + 1)
		bullet.Transform:SetPosition(x,y,z)
		
		
		local scaler =  10 * (math.random()*2.5 - 1.25)
		local offset = Vector3(math.random(), 0, math.random()):Normalize()*scaler
		local targetpos = target:GetPosition()
		bullet.components.projectile:Throw(inst,target)
		
		bullet.Transform:SetPosition((inst:GetPosition() + offset):Get())
		
		bullet:DoTaskInTime(0.3,function()
			bullet.components.projectile:SetHoming(false)
		end)--]]
		
		local scaler =  10 * (math.random()*2.5 - 1.25)
		local offset = Vector3(math.random(), 0, math.random()):Normalize()*scaler
		local targetpos = target:GetPosition()
		bullet.components.ly_projectile.damage = math.random()*5 + 1
		bullet.components.ly_projectile:SetCanHit(CanHitFn)
		bullet.components.ly_projectile:Throw(inst,targetpos,true,function()
			local mx,my,mz = (inst:GetPosition() + offset):Get()      
			local fx = SpawnPrefab("icey_shield")
			
			fx.AnimState:SetMultColour(0,0,0,1)
			fx.Transform:SetScale(0.8,0.8,0.8)  
			fx.Transform:SetPosition(mx,my,mz) 
			
			bullet.Transform:SetPosition(mx,my,mz)
		end)
		
	end
end 

local function SpawnSpikes(inst,target,rad)
	local x,y,z = target:GetPosition():Get()
	if math.random() <= 0.25 then 
		for i=0,360,30 do 
			local spike = SpawnPrefab("fossilspike")
			spike:ForceFacePoint(x,y,z)
			spike.AnimState:SetMultColour(0,0,0,1)
			spike.Transform:SetPosition(x+rad*math.cos(i),y,z+rad*math.sin(i))
			spike.Transform:SetScale(1,2,1)
		end
		target:PushEvent("knockback", {knocker = inst, radius = 1})
	elseif math.random() <= 0.25 then  
		rad = 0
		inst:StartThread(function()
			for i=0,720,20 do 
				local spike = SpawnPrefab("fossilspike2")
				spike.AnimState:SetMultColour(0,0,0,1)
				spike.Transform:SetPosition(x+rad*math.cos(i),y,z+rad*math.sin(i))
				rad = rad + 0.5
				Sleep(0.1)
			end
		end)
	else
		for i=1,10 do 
			DoBallsAttack(inst,target)
		end 
	end 
end 

local function CircleNightAttack(inst,target,rad)
	rad = rad or 3
	local x,y,z = target:GetPosition():Get()
	SpawnSpikes(inst,target,rad-1.75)
	--inst.SoundEmitter:PlaySound(math.random() <= 0.5 and "dontstarve/sanity/knight/attack_1" or "dontstarve/sanity/rook/taunt")
	inst:StartThread(function()
		for i=0,360,60 do 
			inst.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/shield")
			local nightmare = SpawnPrefab(math.random() <= 0.25 and "nightmarebeak" or "crawlingnightmare")
			nightmare.Transform:SetPosition(x+rad*math.cos(i),y,z+rad*math.sin(i))
			nightmare:DoTaskInTime(0.2,function()
				nightmare.components.combat:SetTarget(target)
				nightmare.sg:GoToState("attack",target)
				nightmare:DoTaskInTime(1,function()
					--nightmare.sg.mem.soundcache = nil 
					nightmare.sg:GoToState("disappear")
					nightmare:ListenForEvent("animover", nightmare.Remove)
					nightmare:ListenForEvent("entitysleep", nightmare.Remove)
				end)
			end)
			Sleep(0.2)
		end
	end)
end 


local states =
{
    State{
        name = "attack",
        tags = { "attack", "busy" },

        onenter = function(inst, target)
            inst.sg.statemem.target = target
            inst.Physics:Stop()
            inst.components.combat:StartAttack()
            inst.AnimState:PlayAnimation("teleport_pre")
            inst.AnimState:PushAnimation("teleport", false)
			inst:PushEvent("mixture_diasppear")
		
        end,

        timeline =
        {
            ShadowChess.Functions.ExtendedSoundTimelineEvent(0, "attack_grunt"),
            ShadowChess.Functions.ExtendedSoundTimelineEvent(12 * FRAMES, "teleport"),
            TimeEvent(19 * FRAMES, function(inst)
                inst.sg:AddStateTag("noattack")
                inst.components.health:SetInvincible(true)
            end),
        },

        events =
        {
            EventHandler("animqueueover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg.statemem.attack = true
                    inst.sg:GoToState("attack_teleport", inst.sg.statemem.target)
                end
            end),
        },

        onexit = function(inst)
            if not inst.sg.statemem.attack then
                inst.components.health:SetInvincible(false)
            end
        end,
    },

    State{
        name = "attack_teleport",
        tags = { "attack", "busy", "noattack" },

        onenter = function(inst, target)
            inst.components.health:SetInvincible(true)
            if target ~= nil and target:IsValid() then
                inst.sg.statemem.target = target
                inst.Physics:Teleport(target.Transform:GetWorldPosition())
            end
            inst.AnimState:PlayAnimation("teleport_atk")
            inst.AnimState:PushAnimation("teleport_pst", false)
			inst:DoTaskInTime(0.3,function()
				inst:PushEvent("mixture_show")
			end)
        end,

        timeline =
        {
            ShadowChess.Functions.ExtendedSoundTimelineEvent(0, "attack"),
            TimeEvent(17 * FRAMES, function(inst)
                inst.sg:RemoveStateTag("noattack")
                inst.components.health:SetInvincible(false)
                inst.components.combat:DoAreaAttack(inst, inst.components.combat.hitrange, nil, nil, nil, { "INLIMBO", "notarget", "invisible", "noattack", "flight", "playerghost", "shadow", "shadowchesspiece", "shadowcreature" })
            end),
            TimeEvent(34 * FRAMES, function(inst)
                inst.sg:RemoveStateTag("busy")
            end),
        },

        events =
        {
            EventHandler("animqueueover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("idle")
                end
            end),
        },

        onexit = function(inst)
            inst.components.health:SetInvincible(false)
        end,
    },
	
	State
    {
        name = "taunt",
        tags = { "taunt", "busy" },

        onenter = function(inst)
			local taunt_target = inst.components.combat.target or inst:GetNearestPlayer(true)
			print("Try to find taunt_target:",taunt_target)
            inst.Physics:Stop()
            inst.AnimState:PlayAnimation("transform")
			if taunt_target and taunt_target:IsValid() and inst:IsNear(taunt_target,30) then 
				inst.sg.statemem.taunt_target = taunt_target
			end
        end,

        timeline =
        {
            ShadowChess.Functions.ExtendedSoundTimelineEvent(20 * FRAMES, "taunt"), 
            TimeEvent(60 * FRAMES, function(inst)
                ShadowChess.Functions.AwakenNearbyStatues(inst)
                ShadowChess.Functions.TriggerEpicScare(inst)
				local taunt_target = inst.sg.statemem.taunt_target
				if taunt_target and taunt_target:IsValid() then 
					print("taunt_target:",taunt_target)
					CircleNightAttack(inst,taunt_target)
				end
            end),
            TimeEvent(88 * FRAMES, function(inst)
                inst.sg:RemoveStateTag("busy")
            end),
        },
		
		onexit = function(inst)
            inst.sg.statemem.taunt_target = nil 
        end,

        events =
        {
            ShadowChess.Events.IdleOnAnimOver(),
        },
    }
}

ShadowChess.States.AddIdle(states, "idle_loop")
ShadowChess.States.AddLevelUp(states, "transform", 20, 60, 88)
--ShadowChess.States.AddTaunt(states, "transform", 20, 60, 88)
ShadowChess.States.AddHit(states, "hit", 0, 14)
ShadowChess.States.AddDeath(states, "disappear", 10)
ShadowChess.States.AddEvolvedDeath(states, "death", 38,
{
    ShadowChess.Functions.DeathSoundTimelineEvent(45 * FRAMES),
    ShadowChess.Functions.DeathSoundTimelineEvent(64 * FRAMES),
})
ShadowChess.States.AddDespawn(states, "disappear")

CommonStates.AddWalkStates(states)

return StateGraph("SGshadow_mixtures", states, ShadowChess.CommonEventList, "idle")
