AddPrefabPostInit("world", function(inst)
	if not TheWorld.ismastersim then
		return inst
	end
	
	local function OnEntityDeath(inst,data)
		local victim = data.inst
		
		if victim:HasTag("NO_ICEY_EXP") then 
			return 
		end 
		local victim_maxhealth = victim.components.health and victim.components.health.maxhealth or 0
		
		local iceys = {}
		for k,v in pairs(AllPlayers) do 
			if v and v:IsValid() and v:IsNear(victim,20) 
			and victim ~= v and v.components.icey_level and not v.components.icey_level:IsLevelMaxed() then 
				table.insert(iceys,v) 
			end
		end
		
		if #iceys > 0 then 
			local per_exp = victim_maxhealth / (#iceys * 100)
			if victim:HasTag("epic") then 
				per_exp = per_exp * 2
			end 
			if victim:HasTag("tadalin") then 
				per_exp = per_exp * 1.25
			end 
			for k,v in pairs(iceys) do
				v.components.icey_level:ExpDoDelta(per_exp)
			end
		end 
	end
	
	inst:ListenForEvent("entity_death",OnEntityDeath)
end)