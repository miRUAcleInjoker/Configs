local TadalinUtil = require("tadalin_util") 
local IceyUtil = require("icey_util") 
local IceyCommonStates = require("icey_commonstates")

require("stategraphs/commonstates")

local actionhandlers = 
{
	--ActionHandler(ACTIONS.EAT, "eat"),
}

   
local events=
{
	CommonHandlers.OnLocomote(true, false),

    EventHandler("attacked", function(inst, data)
		if not inst.sg:HasStateTag("skilling") and not inst.sg:HasStateTag("parrying") 
			and not inst.sg:HasStateTag("busy") and data.damage and data.damage >= 20 then 
			inst.sg:GoToState("hit")
		end 
	end),

    EventHandler("doattack", function(inst,data)
        if not inst.components.health:IsDead() then
			local target = data.target
			local percent = inst.components.health:GetPercent()
			local dist = math.sqrt(target:GetDistanceSqToInst(inst))
			if not inst.sg:HasStateTag("busy") then 
				if dist >= 10.5  then 					
					if GetTime() - inst.last_laugh_time >= 15 then 
						inst.last_laugh_time = GetTime()
						inst.sg:GoToState("laugh",target)
					else
						inst.sg:GoToState("attack_shoot",target)
					end 
				elseif dist >= 6 then 
					if GetTime() - inst.last_combat_superjump_start_time >= 12 then 
						inst.last_combat_superjump_start_time = GetTime()
						inst.sg:GoToState("combat_superjump_start",target)
					elseif GetTime() - inst.last_dash_attack_time >= 10 then
						inst.last_dash_attack_time = GetTime()
						inst.sg:GoToState("dash_attack",{target = target})
					elseif GetTime() - inst.last_combat_leap_start_time >= 8 then 
						inst.last_combat_leap_start_time = GetTime()
						inst.sg:GoToState("combat_leap_start",target)
					else
						inst.sg:GoToState("attack_shoot",target)
					end 
				elseif dist <= 4 then 
					if GetTime() - inst.last_attack_cricle_time >= 6 then 
						inst.last_attack_cricle_time = GetTime()
						inst.sg:GoToState("attack_circle_pre",target)
					elseif GetTime() - inst.last_dash_attack_time >= 10 then
						inst.last_dash_attack_time = GetTime()
						inst.sg:GoToState("dash_attack",{target = target})
					else
						inst.sg:GoToState("attack_shoot",target)
					end 
				else
					inst.sg:GoToState("attack_shoot",target)
				end
			end
			
        end
    end),
    
    EventHandler("death", function(inst)
		inst.sg:GoToState("death")
    end),
}

local function ToggleOffPhysics(inst)
    inst.sg.statemem.isphysicstoggle = true
    inst.Physics:ClearCollisionMask()
    inst.Physics:CollidesWith(COLLISION.GROUND)
end

local function ToggleOnPhysics(inst)
    inst.sg.statemem.isphysicstoggle = nil
    inst.Physics:ClearCollisionMask()
    inst.Physics:CollidesWith(COLLISION.WORLD)
    inst.Physics:CollidesWith(COLLISION.OBSTACLES)
    inst.Physics:CollidesWith(COLLISION.SMALLOBSTACLES)
    inst.Physics:CollidesWith(COLLISION.CHARACTERS)
    inst.Physics:CollidesWith(COLLISION.GIANTS)
end

local function Shoot(inst,targetpos,nums)
	
	if nums == 1 then
		local projectile = SpawnAt("icey_darts_projectile_alt",inst:GetPosition())
		projectile.components.ly_projectile:SetCanHit(function(proj,owner,target)
			return TadalinUtil.CanAttack(target)
		end)
		projectile.components.ly_projectile:Throw(inst, targetpos,true)
		projectile:ListenForEvent("lyprojectilehit",function(inst,data)
			if data.target then 
				IceyUtil.AddDarkSoulBleedsDebuff(data.target,{percent = 0.05})
			end
		end)
		inst.SoundEmitter:PlaySound("dontstarve_DLC003/common/items/weapon/blunderbuss_shoot")
	else
		inst:StartThread(function()
			for i=1,nums do 
				local projectile = SpawnAt("icey_darts_projectile_alt",inst:GetPosition())
				projectile.components.ly_projectile:SetCanHit(function(proj,owner,target)
					return TadalinUtil.CanAttack(target)
				end)
				projectile:ListenForEvent("lyprojectilehit",function(inst,data)
					if data.target then 
						IceyUtil.AddDarkSoulBleedsDebuff(data.target,{percent = 0.05})
					end
				end)
				local rad = GetRandomMinMax(0.5,0.8)
				local roa = GetRandomMinMax(0,2 * PI)
				local offset = Vector3(rad * math.cos(roa),0,rad * math.sin(roa))
				if i == 1 then
					projectile.components.ly_projectile:Throw(inst, targetpos,true)
				else
					projectile.components.ly_projectile:Throw(inst, targetpos + offset,true)
				end
				inst.SoundEmitter:PlaySound("dontstarve_DLC003/common/items/weapon/blunderbuss_shoot")
				Sleep(0)
			end
		end)
	end 
	
	
end 

local function OnLeapFn(doer,startpos,targetpos)
	SpawnAt("hammer_mjolnir_crackle",targetpos).AnimState:SetAddColour(255/255, 0/255, 0/255, 0.9)
	SpawnAt("hammer_mjolnir_cracklebase",targetpos).AnimState:SetAddColour(255/255, 0/255, 0/255, 0.9)
	SpawnAt("hammer_mjolnir_cracklehit",targetpos).AnimState:SetAddColour(255/255, 0/255, 0/255, 0.9)
	SpawnAt("cracklehitfx",targetpos).AnimState:SetAddColour(255/255, 0/255, 0/255, 0.9)
	
	local dmg = 45
	local radius = 5
		
	local ents  = TheSim:FindEntities(targetpos.x,targetpos.y,targetpos.z,radius, {"_combat"})
	for k,v in pairs(ents) do
		local new_dmg = dmg
		if TadalinUtil.CanAttack(v) then
			v.components.combat:GetAttacked(doer, new_dmg,nil,"electric") 
			--SpawnPrefab("electrichitsparks"):AlignToTarget(v, doer, true)
		end
	end

	--doer:ListenForEvent("animover",onfresh)
		
	doer.SoundEmitter:PlaySound("dontstarve/common/destroy_smoke")
	doer.SoundEmitter:PlaySound("dontstarve/impacts/lava_arena/hammer")
	doer.SoundEmitter:PlaySound("dontstarve/impacts/lava_arena/electric")
	
end 

local function DoHitGround(inst, rad)
	inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/enemy/metal_robot/smash")
	SpawnAt("laser_ring",inst:GetPosition()).Transform:SetScale(1.1,1.1,1.1)
    local targets = {}
    local x, y, z = inst.Transform:GetWorldPosition()
    for i, v in ipairs(TheSim:FindEntities(x, 0, z, rad, nil, { "laser", "DECOR", "INLIMBO"})) do  --  { "_combat", "pickable", "campfire", "CHOP_workable", "HAMMER_workable", "MINE_workable", "DIG_workable" }
        if not targets[v] and v:IsValid() and not v:IsInLimbo() and not (v.components.health ~= nil and v.components.health:IsDead()) and not v:HasTag("laser_immune") then
            local vradius = 0
            if v.Physics then
                vradius = v.Physics:GetRadius()
            end

            local range = rad + vradius
            if v:GetDistanceSqToPoint(Vector3(x, y, z)) < range * range then
                local isworkable = false
                if v.components.workable ~= nil then
                    local work_action = v.components.workable:GetWorkAction()
                    --V2C: nil action for campfires
                    isworkable =
                        (   work_action == nil and v:HasTag("campfire")) or
                        
                            (   work_action == ACTIONS.CHOP or
                                work_action == ACTIONS.HAMMER or
                                work_action == ACTIONS.MINE or
                                work_action == ACTIONS.DIG
                            )
                end
                if isworkable then
                    targets[v] = true
                    v:DoTaskInTime(0.6, function() 
                        if v.components.workable then
                            v.components.workable:Destroy(inst) 
                        end
                     end)
                    if v:IsValid() and v:HasTag("stump") then
                       -- v:Remove()
                    end
                elseif v.components.pickable ~= nil
                    and v.components.pickable:CanBePicked()
                    and not v:HasTag("intense") then
                    targets[v] = true
                    local num = v.components.pickable.numtoharvest or 1
                    local product = v.components.pickable.product
                    local x1, y1, z1 = v.Transform:GetWorldPosition()
                    v.components.pickable:Pick(inst) -- only calling this to trigger callbacks on the object
                    if product ~= nil and num > 0 then
                        for i = 1, num do
                            local loot = SpawnPrefab(product)
                            loot.Transform:SetPosition(x1, 0, z1)
                            targets[loot] = true
                        end
                    end

                elseif v.components.health and TadalinUtil.CanAttack(v) then
                    inst.components.combat:DoAttack(v)            
					IceyUtil.KnockBack(inst,v)     
                end
                if v:IsValid() and v.AnimState then
                    SpawnPrefab("deerclops_laserhit"):SetTarget(v)
                end
            end
        end
    end
end

local function SpawnShadows(inst)
	return inst:DoPeriodicTask(0.3,function()
		local fx = SpawnAt("jack_shadow",inst:GetPosition())
		fx.Transform:SetRotation(inst.Transform:GetRotation())
		fx:FadeOut()
	end)
end 

local function MachineGunShoot(inst,target,angle,nums)
	local mypos = inst:GetPosition()
	local targetpos = target:GetPosition()
	local vec = targetpos - mypos
	local vec_vertical = Vector3(-vec.z,0,vec.x):GetNormalized()
	
	--inst:StartThread(function()
		for i = 1,nums do 
			local extra_length = math.abs(math.tan(0.5 * angle) * vec:Length())
			local offset = vec_vertical * extra_length * (i*2 - nums) / nums
			inst:ForceFacePoint((targetpos+offset):Get())
			Shoot(inst,targetpos+offset,1)
		end 
		--Sleep(0)
	--end )
end 

local states = {
	--[[State{
        name = "taunt",
        tags = {"busy", "nointerrupt", "nomorph" },
        
        onenter = function(inst)
            inst.Physics:Stop()
            inst.AnimState:PlayAnimation("emote_fistshake")
			--local sound = math.random() <= 0.5 and "dontstarve/characters/wolfgang/grow_medtolrg" or "dontstarve/characters/wolfgang/shrink_lrgtomed"
			--inst.SoundEmitter:PlaySound(sound)
			--inst.SoundEmitter:PlaySound("dontstarve/sanity/rook/attack_1")
        end,
        
        events=
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end),
        },
    },--]]
	State{
        name = "death",
        tags = {"busy", "nointerrupt", "death" },
        
        onenter = function(inst)
            inst.Physics:Stop()
            inst.AnimState:PlayAnimation("death")
			inst.SoundEmitter:PlaySound("jack/jack/death"..math.random(1,2))
        end,
    },
	
	--[[
	local start = TheInput:GetWorldPosition() 
	local playerpos = ThePlayer:GetPosition() 
	local vec = playerpos - start 
	local endpos = playerpos + vec  
	c_spawn("jack").sg:GoToState("enter_show",{startpos = start,targetpos = endpos,facetarget = ThePlayer}) --]]
	
	--[[
	
	local playerpos = ThePlayer:GetPosition() 
	local start = playerpos + FindWalkableOffset(playerpos,0,5,6) 
	local vec = playerpos - start 
	local endpos = playerpos + vec  
	c_spawn("jack").sg:GoToState("enter_show",{startpos = start,targetpos = endpos,facetarget = ThePlayer}) --]]
	State{
        name = "enter_show",
        tags = {"busy", "nointerrupt", "nomorph","enter_show" },
        
        onenter = function(inst,data)
            --inst.Physics:Stop()
			inst:AddTag("enter_show")
			inst.Transform:SetPosition(data.startpos:Get())
			
			inst.components.health:SetInvincible(true)
            --inst.AnimState:PlayAnimation("slide_pre")

            --inst.AnimState:PushAnimation("slide_loop")
            --inst.SoundEmitter:PlaySound("dontstarve_DLC003/characters/wheeler/slide")
			
			inst.components.timestoper:TheWorld(data.facetarget and data.facetarget:GetPosition(),45,3.5)
			
			
			inst.sg.statemem.startpos = data.startpos
			inst.sg.statemem.targetpos = data.targetpos
			inst.sg.statemem.facetarget = data.facetarget
			inst.sg.statemem.show_self = false 
			
			inst:Hide()
			inst.DynamicShadow:Enable(false)
			
			inst.sg:SetTimeout(3)
        end,
		
		onupdate = function(inst)
			if inst.sg.statemem.show_self then 
				local all_time = 3 - 1.75
				local time_remain = inst.sg.timeout
				local vec = inst.sg.statemem.targetpos - inst.sg.statemem.startpos
				local percent = (all_time - time_remain) / all_time
				
				
				if percent >= 0 then
					inst.Transform:SetPosition((inst.sg.statemem.startpos + vec * percent):Get())
				end 
			else
				
			end
		end,
		
		ontimeout = function(inst)
			inst.sg:GoToState("enter_show_pst",inst.sg.statemem.facetarget)
		end,
		
		timeline = {
			TimeEvent(0.1, function(inst)
				inst.SoundEmitter:PlaySound("jack/jack/startshow1")
			end),
			TimeEvent(1.7, function(inst)
				local fx = SpawnAt("positronpulse",inst:GetPosition())
				fx:AddTag("NO_TIME_STOP")
				fx:FinishFX()
			end),
			TimeEvent(1.75, function(inst)
				inst:Show()
				inst.DynamicShadow:Enable(true)
				inst.sg.statemem.show_self = true 
				
				inst.SoundEmitter:PlaySound("jack/jack/startshow2")
				inst.AnimState:PlayAnimation("slide_pre")
				inst.AnimState:PushAnimation("slide_loop",true)
	
				inst:ForceFacePoint(inst.sg.statemem.targetpos)
			end),
			TimeEvent(1.8, function(inst)
				Shoot(inst,inst.sg.statemem.facetarget:GetPosition(),math.random(1,3))
			end),
			
			TimeEvent(1.9, function(inst)
				Shoot(inst,inst.sg.statemem.facetarget:GetPosition(),math.random(1,3))
			end),
			
			TimeEvent(2.0, function(inst)
				Shoot(inst,inst.sg.statemem.facetarget:GetPosition(),math.random(1,3))
			end),
			
			TimeEvent(2.2, function(inst)
				Shoot(inst,inst.sg.statemem.facetarget:GetPosition(),math.random(1,3))
			end),
		},
		
		onexit = function(inst)
			inst:RemoveTag("enter_show")
			inst.components.health:SetInvincible(false)
		end,
		
        
        --[[events=
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end),
        },--]]
    },
	
	State{
        name = "enter_show_pst",
        tags = {"busy", "nointerrupt", "nomorph" },
        
        onenter = function(inst,target)
            inst.Physics:Stop()
            inst.AnimState:PlayAnimation("slide_pst")
			inst.AnimState:PushAnimation("idle",true)
			inst:ForceFacePoint(target:GetPosition():Get())
			inst.sg:SetTimeout(1)
        end,
        
		ontimeout = function(inst)
			inst.sg:GoToState("idle")
		end,
		
		onexit = function(inst)
			inst.components.health:SetInvincible(false)
		end,
    },
	
	State{
        name = "attack_shoot",
        tags = {"attack", "notalking", "abouttoattack", "busy"},
        
        onenter = function(inst,target)
			inst.AnimState:SetDeltaTimeMultiplier(2.5)
			IceyCommonStates.SGAttackOnEnterServer(inst,15 * FRAMES,"hand_shoot",true,target)
			

			
			--inst.SoundEmitter:PlaySound(weapon.startgunsound)
        end,
        
        timeline=
        {
			--17
            TimeEvent(7*FRAMES, function(inst) 
				local target = inst.sg.statemem.target
				
				if math.random() <= 0.5 then 
					Shoot(inst,target:GetPosition(),5)
				else
					MachineGunShoot(inst,target,75,10)
				end 
				
				inst.AnimState:SetDeltaTimeMultiplier(1)
                inst.sg:RemoveStateTag("abouttoattack") 
            end),   
			--20         
            TimeEvent(8*FRAMES, function(inst)
                inst.sg:RemoveStateTag("attack")
            end),           
            
        },
		
		onexit = function(inst)
			inst.AnimState:SetDeltaTimeMultiplier(1)
		end,
        
        events=
        {
            EventHandler("animover", function(inst)
                inst.sg:GoToState("idle")
            end ),
        },
    },
	
	
	State{
        name = "laugh",
        tags = {"busy", "nointerrupt", "nomorph" },
        
        onenter = function(inst,target)
            IceyCommonStates.SGAttackOnEnterServer(inst,1.15,nil,true,target)
            inst.AnimState:PlayAnimation("atk_leap_pre")
			inst.AnimState:PushAnimation("atk_leap_lag",false)
			inst.SoundEmitter:PlaySound("jack/jack/hen_hen_hen")
			
			--inst.sg.statemem.SpawnShadowsTask = SpawnShadows(inst)
        end,
		
		ontimeout = function(inst)
			inst.sg:GoToState("jojo_stand",inst.sg.statemem.target)
		end,
		
		onexit = function(inst)
			if inst.sg.statemem.SpawnShadowsTask then 
				inst.sg.statemem.SpawnShadowsTask:Cancel()
			end
			inst.sg.statemem.SpawnShadowsTask = nil 
		end,
    },
	
	State{
        name = "jojo_stand",
        tags = {"busy", "nointerrupt", "nomorph" },
        
        onenter = function(inst,target)
            inst.Physics:Stop()
            inst.AnimState:PlayAnimation("multithrust_yell")
			inst.sg.statemem.target = target
			inst.sg:SetTimeout(1.1)
        end,
		
		timeline = {
			TimeEvent(1*FRAMES, function(inst) 
				inst.SoundEmitter:PlaySound("jack/jack/theworld_pre")
				inst.components.timestoper:TheWorld(nil,45,3.15)
			end)
		},
		
		ontimeout = function(inst)
			inst.sg:GoToState("fly_attack",inst.sg.statemem.target)
		end,
    },
	
	State{
        name = "fly_attack",
        tags = {"busy", "nointerrupt", "nomorph" },
        
        onenter = function(inst,target)
            inst.Physics:Stop()
            inst.AnimState:PlayAnimation("atk_leap_lag")
			inst.sg.statemem.startpos = inst:GetPosition()
			--inst.sg.statemem.targetpos = target:GetPosition()
			local targetpos = target:GetPosition()
			local vec = targetpos - inst.sg.statemem.startpos
			
			for i= 2,0,-0.05 do 
				local testpos = inst.sg.statemem.startpos + vec * i
				local x,y,z = testpos:Get()
				if TheWorld.Map:IsPassableAtPoint(x, y, z,false) then 
					inst.sg.statemem.targetpos = testpos
					break 
				end
			end 
			
			inst.sg.statemem.targetpos = inst.sg.statemem.targetpos or targetpos
			
			inst.sg.statemem.target = target
			inst:StartThread(function()
				Sleep(0.1)
				for i = 1,8 do 
					if target and target:IsValid() then 
						local playerpos = target:GetPosition()
						local bullet = SpawnAt("metal_hulk_bullet",inst:GetPosition())
						local dist = playerpos:Dist(bullet:GetPosition())
						bullet:RemoveTag("tadalin")
						local offset = Vector3(GetRandomMinMax(-1,1),0,GetRandomMinMax(-1,1))
						bullet.components.combat:SetDefaultDamage(20)
						bullet.components.ly_projectile:SetSpeed(dist / 1.5)
						bullet.components.ly_projectile:SetLaunchOffset(Vector3(0,0,0))
						bullet:InitSpeed(Vector3(0,0,0))
						bullet.components.ly_projectile:Throw(inst,target:GetPosition()+offset,true)
					end 
					Sleep(0.25)
				end 
			end)
				
				
			inst.sg:SetTimeout(1.5)
        end,
		
		onupdate = function(inst)
			local time_remain = inst.sg.timeout
			local all_time = 1.5
			local percent = (all_time - time_remain) / all_time
			local startpos = inst.sg.statemem.startpos
			local targetpos = inst.sg.statemem.targetpos
			local vec = targetpos - startpos
			local h_vec = Vector3(0,percent*(1-percent)*20,0)
			
			inst.Transform:SetPosition((startpos + vec*percent + h_vec):Get())
		end,
		
		timeline = {
			TimeEvent(1*FRAMES, function(inst) 
				inst.SoundEmitter:PlaySound("jack/jack/ok_danyou")
			end),
		},
		
		ontimeout = function(inst)
			inst.sg:GoToState("fly_attack_pst",inst.sg.statemem.target)
		end,
    },
	
	State{
        name = "fly_attack_pst",
        tags = {"busy", "nointerrupt", "nomorph" },
        
        onenter = function(inst,target)
            inst.Physics:Stop()
            inst.AnimState:PlayAnimation("atk_leap")
            inst.SoundEmitter:PlaySound("dontstarve/common/deathpoof")
			inst:ForceFacePoint(target:GetPosition():Get())
			inst.sg.statemem.target = target
			inst.sg:SetTimeout(0.75)
        end,
		
		timeline = {
			TimeEvent(0*FRAMES, function(inst) 
				inst.SoundEmitter:PlaySound("jack/jack/theworld_pst")
			end),
			TimeEvent(13 * FRAMES, function(inst)
                ShakeAllCameras(CAMERASHAKE.VERTICAL, .7, .015, .8, inst, 20)
            end),
		},
		
		ontimeout = function(inst)
			inst.sg:GoToState("idle")
		end,
    },
	
	State{
        name = "combat_leap_start",
        tags = { "aoe", "doing", "busy", "nointerrupt", "nomorph" },

        onenter = function(inst,target)
            IceyCommonStates.SGAttackOnEnterServer(inst,0.5,nil,true,target)
            inst.AnimState:PlayAnimation("atk_leap_pre")
			inst.AnimState:PushAnimation("atk_leap_lag",false)
			inst.SoundEmitter:PlaySound("jack/jack/kakada")
			inst.components.timestoper:TheWorld(target and target:GetPosition(),45,0.5)
			
        end,
		
		ontimeout = function(inst)
			inst.sg:GoToState("combat_leap",inst.sg.statemem.target)
		end,

    },

    State{
        name = "combat_leap",
        tags = { "aoe", "doing", "busy", "nointerrupt", "nopredict", "nomorph" },

        onenter = function(inst, target)
			
            inst.Transform:SetEightFaced()
			IceyCommonStates.SGAttackOnEnterServer(inst,nil,"atk_leap",true,target)
            inst.SoundEmitter:PlaySound("dontstarve/common/deathpoof")
			local startingpos = inst:GetPosition()
			local targetpos = target:GetPosition()
            inst.sg.statemem.startingpos = startingpos
            inst.sg.statemem.targetpos = targetpos
            inst.sg.statemem.flash = 0
            if inst.sg.statemem.startingpos.x ~= targetpos.x or inst.sg.statemem.startingpos.z ~= targetpos.z then
                inst:ForceFacePoint(targetpos:Get())
            end
			ToggleOffPhysics(inst)
        end,

        onupdate = function(inst)
            if inst.sg.statemem.flash > 0 then
                inst.sg.statemem.flash = math.max(0, inst.sg.statemem.flash - .1)
                local c = math.min(1, inst.sg.statemem.flash)
                inst.components.colouradder:PushColour("leap", c, 0, 0, 0)
            end
			
			if not inst.sg.statemem.hop_stop then 
				local startingpos = inst.sg.statemem.startingpos  
				local targetpos = inst.sg.statemem.targetpos  
				inst.Physics:SetMotorVel(math.sqrt(distsq(startingpos.x,startingpos.z, targetpos.x, targetpos.z)) / (12 * FRAMES), 0 ,0)
			end 
        end,

        timeline =
        {
            TimeEvent(10 * FRAMES, function(inst)
                inst.components.colouradder:PushColour("leap", .1, 0, 0, 0)
            end),
            TimeEvent(11 * FRAMES, function(inst)
                inst.components.colouradder:PushColour("leap", .2, 0, 0, 0)
            end),
            TimeEvent(12 * FRAMES, function(inst)
                inst.components.colouradder:PushColour("leap", .4, 0, 0, 0)
                inst.Physics:Stop()
                inst.Physics:SetMotorVel(0, 0, 0)
                inst.Physics:Teleport(inst.sg.statemem.targetpos.x, 0, inst.sg.statemem.targetpos.z)
				inst.sg.statemem.hop_stop = true
            end),
            TimeEvent(13 * FRAMES, function(inst)
                ShakeAllCameras(CAMERASHAKE.VERTICAL, .7, .015, .8, inst, 20)
				OnLeapFn(inst,inst.sg.statemem.startingpos,inst.sg.statemem.targetpos)
                inst.components.bloomer:PushBloom("leap", "shaders/anim.ksh", -2)
                inst.components.colouradder:PushColour("leap", 1, 0, 0, 0)
                inst.sg.statemem.flash = 1.3
                inst.sg:RemoveStateTag("nointerrupt")
            end),
            TimeEvent(25 * FRAMES, function(inst)
                inst.components.bloomer:PopBloom("leap")
            end),
        },

        events =
        {
            EventHandler("animover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("idle")
                end
            end),
        },

        onexit = function(inst)
            if inst.sg.statemem.isphysicstoggle then
                inst.Physics:Stop()
                inst.Physics:SetMotorVel(0, 0, 0)
                local x, y, z = inst.Transform:GetWorldPosition()
                if TheWorld.Map:IsPassableAtPoint(x, 0, z) and not TheWorld.Map:IsGroundTargetBlocked(Vector3(x, 0, z)) then
                    inst.Physics:Teleport(x, 0, z)
                else
                    inst.Physics:Teleport(inst.sg.statemem.targetpos.x, 0, inst.sg.statemem.targetpos.z)
                end
            end
            inst.Transform:SetFourFaced()
            inst.components.bloomer:PopBloom("leap")
            inst.components.colouradder:PopColour("leap")
			ToggleOnPhysics(inst)
        end,
    },
	
	State{
        name = "dash_attack",
        tags = {"busy", "nointerrupt", "nomorph" },
        
        onenter = function(inst,data)
            inst.Physics:Stop()
			local facepoint = data.facepoint or data.target:GetPosition()
			IceyCommonStates.SGAttackOnEnterServer(inst,nil,nil,true,data.target)
			
			inst.components.health:SetInvincible(true)
            inst.AnimState:PlayAnimation("slide_pre")
			inst.AnimState:PushAnimation("slide_loop",true)
			inst.SoundEmitter:PlaySound("jack/jack/kulalie")
			inst:ForceFacePoint(facepoint:Get())
			ToggleOffPhysics(inst)
			
			inst.sg:SetTimeout(1)
        end,
		
		onupdate = function(inst)
			inst.Physics:SetMotorVel(20, 0, 0)
		end,
		
		
		ontimeout = function(inst)
			inst.AnimState:PlayAnimation("slide_pst")
			inst.sg:GoToState("idle",true)
		end,
		
		timeline = {
			TimeEvent(0, function(inst)
				Shoot(inst,inst.sg.statemem.target:GetPosition(),math.random(1,3))
			end),
			
			TimeEvent(0.2, function(inst)
				Shoot(inst,inst.sg.statemem.target:GetPosition(),math.random(1,3))
			end),
			
			TimeEvent(0.4, function(inst)
				Shoot(inst,inst.sg.statemem.target:GetPosition(),math.random(1,3))
			end),
			
			TimeEvent(0.5, function(inst)
				Shoot(inst,inst.sg.statemem.target:GetPosition(),math.random(1,3))
			end),
		},
		
		onexit = function(inst)
			ToggleOnPhysics(inst)
			inst.components.health:SetInvincible(false)
		end,
    },
	
	
	
	State{
        name = "combat_superjump_start",
        tags = { "aoe", "doing", "busy", "nointerrupt", "nomorph" },

        onenter = function(inst,target)
			IceyCommonStates.SGAttackOnEnterServer(inst,0.5,{
				superjump_pre = {false,false},
				superjump_lag = {true,false},
			},true,target)
			inst.SoundEmitter:PlaySound("jack/jack/wa_tonga_kakani")
			inst.components.timestoper:TheWorld(target and target:GetPosition(),45,1.25)
        end,
		
		ontimeout = function(inst)
			inst.sg:GoToState("combat_superjump",inst.sg.statemem.target)
		end,
    },

    State{
        name = "combat_superjump",
        tags = { "aoe", "doing", "busy", "nointerrupt", "nopredict", "nomorph" },

        onenter = function(inst, target)
            ToggleOffPhysics(inst)
            inst.AnimState:PlayAnimation("superjump")
			inst.AnimState:SetMultColour(.8, .8, .8, 1)
			inst.components.colouradder:PushColour("superjump", .1, .1, .1, 0)
            inst.sg.statemem.startingpos = inst:GetPosition()
			inst.sg.statemem.targetpos = target:GetPosition()
			inst.sg.statemem.target = target
            inst:ForceFacePoint(target:GetPosition():Get())
            inst.SoundEmitter:PlaySound("dontstarve/movement/bodyfall_dirt", nil, .4)
            inst.SoundEmitter:PlaySound("dontstarve/common/deathpoof")
            inst.sg:SetTimeout(1)
        end,

        onupdate = function(inst)
            if inst.sg.statemem.dalpha ~= nil and inst.sg.statemem.alpha > 0 then
                inst.sg.statemem.dalpha = math.max(.1, inst.sg.statemem.dalpha - .1)
                inst.sg.statemem.alpha = math.max(0, inst.sg.statemem.alpha - inst.sg.statemem.dalpha)
                inst.AnimState:SetMultColour(0, 0, 0, inst.sg.statemem.alpha)
            end
        end,

        timeline =
        {
            TimeEvent(FRAMES, function(inst)
                inst.DynamicShadow:Enable(false)
                inst.sg:AddStateTag("noattack")
                inst.components.health:SetInvincible(true)
                inst.AnimState:SetMultColour(.5, .5, .5, 1)
                inst.components.colouradder:PushColour("superjump", .3, .3, .2, 0)
                inst:PushEvent("dropallaggro")
            end),
            TimeEvent(2 * FRAMES, function(inst)
                inst.AnimState:SetMultColour(0, 0, 0, 1)
                inst.components.colouradder:PushColour("superjump", .6, .6, .4, 0)
            end),
            TimeEvent(3 * FRAMES, function(inst)
                inst.sg.statemem.alpha = 1
                inst.sg.statemem.dalpha = .5
            end),
        },

        events =
        {
            EventHandler("animover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst:Hide()
                    inst.Physics:Teleport(inst.sg.statemem.targetpos.x, 0, inst.sg.statemem.targetpos.z)
                end
            end),
        },

        ontimeout = function(inst)
            inst.sg.statemem.superjump = true
            inst.sg:GoToState("combat_superjump_pst", inst.sg.statemem.target)
        end,

        onexit = function(inst)
            if not inst.sg.statemem.superjump then
                inst.components.health:SetInvincible(false)
                ToggleOnPhysics(inst)
                inst.components.colouradder:PopColour("superjump")
                inst.AnimState:SetMultColour(1, 1, 1, 1)
                inst.DynamicShadow:Enable(true)
            end
            inst:Show()
        end,
    },

    State{
        name = "combat_superjump_pst",
        tags = { "aoe", "doing", "busy", "noattack", "nopredict", "nomorph" },

        onenter = function(inst, target)
            inst.AnimState:PlayAnimation("superjump_land")
            inst.AnimState:SetMultColour(.4, .4, .4, .4)
            inst.sg.statemem.targetpos = target:GetPosition()
            inst.sg.statemem.flash = 0
            ToggleOffPhysics(inst)
            inst.Physics:Teleport(inst.sg.statemem.targetpos.x, 0, inst.sg.statemem.targetpos.z)
            inst.components.health:SetInvincible(true)
            inst.sg:SetTimeout(22 * FRAMES)
			
			--inst.SoundEmitter:PlaySound("jack/jack/kulalie")
        end,

        onupdate = function(inst)
            if inst.sg.statemem.flash > 0 then
                inst.sg.statemem.flash = math.max(0, inst.sg.statemem.flash - .1)
                local c = math.min(1, inst.sg.statemem.flash)
                inst.components.colouradder:PushColour("superjump", c, c, 0, 0)
            end
        end,

        timeline =
        {
            TimeEvent(FRAMES, function(inst)
                inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon")
                inst.AnimState:SetMultColour(.7, .7, .7, .7)
                inst.components.colouradder:PushColour("superjump", .1, .1, 0, 0)
            end),
            TimeEvent(2 * FRAMES, function(inst)
                inst.AnimState:SetMultColour(.9, .9, .9, .9)
                inst.components.colouradder:PushColour("superjump", .2, .2, 0, 0)
            end),
            TimeEvent(3 * FRAMES, function(inst)
                inst.AnimState:SetMultColour(1, 1, 1, 1)
                inst.components.colouradder:PushColour("superjump", .4, .4, 0, 0)
                inst.DynamicShadow:Enable(true)
            end),
            TimeEvent(4 * FRAMES, function(inst)
                inst.components.colouradder:PushColour("superjump", 1, 1, 0, 0)
                inst.components.bloomer:PushBloom("superjump", "shaders/anim.ksh", -2)
                ToggleOnPhysics(inst)
				DoHitGround(inst,4.5)
                ShakeAllCameras(CAMERASHAKE.VERTICAL, .7, .015, .8, inst, 20)
                inst.sg.statemem.flash = 1.3
                inst.sg:RemoveStateTag("noattack")
                inst.components.health:SetInvincible(false)
				
            end),
            TimeEvent(8 * FRAMES, function(inst)
                inst.components.bloomer:PopBloom("superjump")
            end),
            TimeEvent(19 * FRAMES, PlayFootstep),
        },

        ontimeout = function(inst)
            inst.sg:GoToState("idle", true)
        end,

        events =
        {
            EventHandler("animover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("idle")
                end
            end),
        },

        onexit = function(inst)
            ToggleOnPhysics(inst)
            inst.AnimState:SetMultColour(1, 1, 1, 1)
            inst.DynamicShadow:Enable(true)
            inst.components.health:SetInvincible(false)
            inst.components.bloomer:PopBloom("superjump")
            inst.components.colouradder:PopColour("superjump")
        end,
    },
	
	--attack_circle
	State{
        name = "attack_circle_pre",
        tags = {"busy", "nointerrupt", "nomorph"},
        
        onenter = function(inst,target)
            inst.Physics:Stop()
            inst.AnimState:PlayAnimation("multithrust_yell")
			inst.sg.statemem.target = target
			inst.sg:SetTimeout(1.1)
        end,
		
		timeline = {
			TimeEvent(1*FRAMES, function(inst) 
				inst.SoundEmitter:PlaySound("jack/jack/theworld_pre")
				inst.components.timestoper:TheWorld(nil,45,1)
			end)
		},
		
		ontimeout = function(inst)
			inst.sg:GoToState("attack_circle",inst.sg.statemem.target)
		end,
    },
	
	State{
        name = "attack_circle",
        tags = {"busy", "nointerrupt", "nomorph","attack" },
        
        onenter = function(inst,target)
            inst.Physics:Stop()
            inst.AnimState:SetDeltaTimeMultiplier(2)
            inst.AnimState:PlayAnimation("iceyatk_circle1")
			inst.AnimState:PushAnimation("iceyatk_circle2",false)
			inst.AnimState:PushAnimation("iceyatk_circle3",false)
            inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon",nil,nil,true)
			inst.sg.statemem.target = target
			inst:EquipSword()
			
			inst:StartThread(function()
				for i = 0 , PI * 2 , PI * 2 / 15 do 
					local offset = Vector3(math.cos(i),0,math.sin(i)) * 12
					Shoot(inst,inst:GetPosition() + offset,1)
					Sleep(0)
				end
			
			end)
        end,
		
		timeline = {
			TimeEvent(1*FRAMES, function(inst) 
				inst.SoundEmitter:PlaySound("jack/jack/kulalie")
				local target = inst.sg.statemem.target
				inst:StartThread(function()
					for i = 1 , 3 do 
						local roa = math.random() * 2 * PI
						local offset = Vector3(math.cos(roa),0,math.sin(roa)) * GetRandomMinMax(0.2,0.5)
						local fx = SpawnAt("laser_explode_sm",target:GetPosition()+offset)
						fx.Transform:SetScale(1.7,1.7,1.7)
						inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/hulk_metal_robot/explode_small")
						inst.components.combat:DoAttack(target)
						Sleep(0.1)
					end
				end)
				DoHitGround(inst, 4.2)
			end)
		},
		
		events =
        {
            EventHandler("animover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("idle")
                end
            end),
        },
		
		onexit = function(inst)
			inst:EquipHandgun()
			inst.AnimState:SetDeltaTimeMultiplier(1)
		end,
    },
}

local runstate_timeline = {
	starttimeline = {
		TimeEvent(4*FRAMES, function(inst)
            PlayFootstep(inst)
        end),
	},
	runtimeline = {
		TimeEvent(7*FRAMES, function(inst)
            PlayFootstep(inst, .6)
        end),
        TimeEvent(15*FRAMES, function(inst)
            PlayFootstep(inst, 1)
        end),
	},
	endtimeline = {
	
	},
}

CommonStates.AddIdle(states)
CommonStates.AddRunStates(states, runstate_timeline)

return StateGraph("SGjack", states, events, "idle", actionhandlers)