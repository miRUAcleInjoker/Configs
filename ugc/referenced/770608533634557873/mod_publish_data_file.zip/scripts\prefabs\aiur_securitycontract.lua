local assets=
{
	Asset("ANIM", "anim/security_contract.zip"),
	Asset("ATLAS", "images/inventoryimages/aiur_securitycontract.xml"),
    Asset("IMAGE", "images/inventoryimages/aiur_securitycontract.tex"),
}

local function makefn(inst)
    local inst = CreateEntity()
    
    inst.entity:AddTransform()
    inst.entity:AddAnimState()
	inst.entity:AddNetwork()  
	
	
    MakeInventoryPhysics(inst)

    inst.AnimState:SetBank("security_contract")
    inst.AnimState:SetBuild("security_contract")
    inst.AnimState:PlayAnimation("idle")

    inst:AddTag("securitycontract")
	
	inst.entity:SetPristine()
	
    if not TheWorld.ismastersim then
        return inst
    end
    
    inst:AddComponent("tradable")

    inst:AddComponent("inspectable")
    
    inst:AddComponent("inventoryitem")
    inst.components.inventoryitem.foleysound = "dontstarve/movement/foley/jewlery"
    inst.components.inventoryitem.imagename = "aiur_securitycontract"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/aiur_securitycontract.xml"

    return inst
end

return Prefab( "aiur_securitycontract", makefn, assets)