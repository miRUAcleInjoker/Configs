local IceyUtil = require("icey_util")
local IceyWeaponSkillUtil = require("icey_weaponskill_util")

local assets=
{
	Asset("ANIM", "anim/swap_yhorm_blade.zip"),
	
	Asset("IMAGE","images/inventoryimages/yhorm_blade.tex"),
	Asset("ATLAS","images/inventoryimages/yhorm_blade.xml"),
	Asset("IMAGE","images/inventoryimages/yhorm_blade_fire.tex"),
	Asset("ATLAS","images/inventoryimages/yhorm_blade_fire.xml"),
}

local function ChangeState(inst,isfire)
	inst.IsFire = isfire
	local isequipped = inst.components.equippable:IsEquipped()
	local owner = inst.components.inventoryitem:GetGrandOwner() 
	if isfire then 
		if isequipped and owner then 
			owner.AnimState:OverrideSymbol("swap_object", "swap_yhorm_blade", "swap_yhorm_blade_fire")
			owner.AnimState:Show("ARM_carry") 
			owner.AnimState:Hide("ARM_normal") 
		else
			inst.AnimState:PlayAnimation("idle_fire")
		end 
		inst.components.inventoryitem.imagename = "yhorm_blade_fire"
		inst.components.inventoryitem.atlasname = "images/inventoryimages/yhorm_blade_fire.xml"
		inst.components.inventoryitem:ChangeImageName("yhorm_blade_fire")
	else
		if isequipped and owner then 
			owner.AnimState:OverrideSymbol("swap_object", "swap_yhorm_blade", "swap_yhorm_blade")
			owner.AnimState:Show("ARM_carry") 
			owner.AnimState:Hide("ARM_normal") 
		else
			inst.AnimState:PlayAnimation("idle")
		end 
		inst.components.inventoryitem.imagename = "yhorm_blade"
		inst.components.inventoryitem.atlasname = "images/inventoryimages/yhorm_blade.xml"
		inst.components.inventoryitem:ChangeImageName("yhorm_blade")
	end
	
	SpawnAt("firesplash_fx",inst:GetPosition())
end 

local function CanGroundPoundHit(attacker,target)
	print("attacker",attacker,"target",target)
	return IceyUtil.CanAttack(target,attacker)
end 

local function AttackerOverrideFn(inst)
	local isequipped = inst.components.equippable:IsEquipped()
	local owner = inst.components.inventoryitem:GetGrandOwner() 
	
	return isequipped and owner
end 

local function GroundpoundFn(inst)
	inst.SoundEmitter:PlaySound("dontstarve_DLC001/creatures/bearger/groundpound")
	ShakeAllCameras(CAMERASHAKE.FULL, 0.7, .03, .5, inst, 30)
end 

local function OnCQCAttack(inst,data)
	local target = data.target
	local type = data.type 
	local weapon = inst.components.combat:GetWeapon() 
	
	if weapon and weapon.IsFire and target and target:IsValid() and type and type == "hop" 
	and GetTime() - weapon.LastGroundPoundTime >= 5
	then 
		weapon.components.ly_groundpounder:GroundPound(target:GetPosition())
		weapon.LastGroundPoundTime = GetTime()
	end
end 

local function onequip(inst, owner) 
	if inst.IsFire then 
		owner.AnimState:OverrideSymbol("swap_object", "swap_yhorm_blade", "swap_yhorm_blade_fire")
	else
		owner.AnimState:OverrideSymbol("swap_object", "swap_yhorm_blade", "swap_yhorm_blade")
	end 
	owner.AnimState:Show("ARM_carry") 
	owner.AnimState:Hide("ARM_normal") 
	if owner.components.health then 
		owner.components.health.externalfiredamagemultipliers:SetModifier(inst,0,"yhorm_blade")
	end 
	inst:ListenForEvent("icey_cqc_attack",OnCQCAttack,owner)
end

local function onunequip(inst, owner) 
	owner.AnimState:Hide("ARM_carry") 
	owner.AnimState:Show("ARM_normal")
	if owner.components.health then 
		owner.components.health.externalfiredamagemultipliers:RemoveModifier(inst,"yhorm_blade") 
	end 
	inst:RemoveEventCallback("icey_cqc_attack",OnCQCAttack,owner)
end

local function OnDropped(inst)
	if inst.IsFire then 
		inst.AnimState:PlayAnimation("idle_fire")
	else
		inst.AnimState:PlayAnimation("idle")
	end
end 

local function OnHelmSplit(inst,attacker,target)
	--ShakeAllCameras(CAMERASHAKE.VERTICAL, .7, .025, 1.25, inst, 40)
	inst.components.ly_groundpounder:GroundPound(target:GetPosition())
end 

local function onattack(inst,attacker,target)
	local buff = attacker.components.debuffable:GetDebuff("taunt_yhorm_blade")
	if buff and math.random() <= 0.33 then 
		inst.components.helmsplitter.ready = true 
		inst:AddTag("helmsplitter") 
	end 
end 

local function commonfn(Sim)
	local inst = CreateEntity()
	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddSoundEmitter()
	inst.entity:AddNetwork()
	
	MakeInventoryPhysics(inst)
	
	inst.AnimState:SetBank("swap_yhorm_blade")
	inst.AnimState:SetBuild("swap_yhorm_blade")
	inst.AnimState:PlayAnimation("idle")

	inst:AddTag("yhorm_blade")
	inst:AddTag("hop_attack")
	
	IceyWeaponSkillUtil.AddAoetargetingClient(inst,"line",{"iceyweaponskill_taunt"},15)
	
	inst.entity:SetPristine()
    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.LastGroundPoundTime = 0
	inst.IsFire = false 
	inst.ChangeState = ChangeState 
	
	inst:AddComponent("helmsplitter")
	inst.components.helmsplitter:SetOnHelmSplitFn(OnHelmSplit)

	inst:AddComponent("weapon")
	inst.components.weapon:SetOnAttack(onattack)
	inst.components.weapon:SetDamage(68)	
	inst.components.weapon:SetRange(0.5, 0.6)

	inst:AddComponent("inspectable")
	
	inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "yhorm_blade"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/yhorm_blade.xml"
	
	inst:AddComponent("equippable")
	inst.components.equippable:SetOnEquip( onequip )
	inst.components.equippable:SetOnUnequip( onunequip )
	inst.components.equippable.stamina_consumerate = 1.2
	inst.components.equippable.stamina_recoverrate = 0.8
	
	inst:AddComponent("ly_groundpounder")
	inst.components.ly_groundpounder.ignorerange = true 
	inst.components.ly_groundpounder.destroyer = true
    inst.components.ly_groundpounder.damageRings = 2
    inst.components.ly_groundpounder.destructionRings = 2
    inst.components.ly_groundpounder.numRings = 3
    inst.components.ly_groundpounder.burner = true
    inst.components.ly_groundpounder.groundpoundfx = "firesplash_fx"
    inst.components.ly_groundpounder.groundpounddamagemult = 1.0
    inst.components.ly_groundpounder.groundpoundringfx = "firering_fx"
	inst.components.ly_groundpounder.canhitFn = CanGroundPoundHit
	inst.components.ly_groundpounder.get_attacker_override_fn = AttackerOverrideFn
	inst.components.ly_groundpounder.groundpoundFn = GroundpoundFn
	
	IceyWeaponSkillUtil.AddAoetargetingServer(inst,function(inst,doer,pos)
		if IceyUtil.DefaultCostFn(doer,{focus = 8}) then 
			inst.components.rechargeable:StartRecharge()
			doer.components.debuffable:AddDebuff("taunt_yhorm_blade","icey_normal_debuff")
			
			inst.components.helmsplitter.ready = true 
			inst:AddTag("helmsplitter") 
			
			local fx = doer:SpawnChild("battlestandard_buff_fxs")
			fx:Play("attack_fx3")
			local buff = doer.components.debuffable:GetDebuff("taunt_yhorm_blade")
			buff:Init({damage_multi = 1.1,buff_fx = fx,duration = 15})
			
			local battlecryfx = doer:SpawnChild("icey_battlecry_fxs")	
			battlecryfx:DoTaskInTime(2+math.random(),battlecryfx.RemoveBattleCryFX)
			
			ChangeState(inst,true)
			if inst.CancelFireTask then 
				inst.CancelFireTask:Cancel()
				inst.CancelFireTask = nil 
			end 
			inst.CancelFireTask = inst:DoTaskInTime(15,function()
				ChangeState(inst,false)
				inst.CancelFireTask:Cancel()
				inst.CancelFireTask = nil 
			end) 
		end 
	end,nil,25)
	
	inst:ListenForEvent("ondropped",OnDropped)
	
	return inst
end

return Prefab( "yhorm_blade", commonfn, assets)
