local IceyUtil = require("icey_util")


local assets =
{
	Asset("ANIM", "anim/swap_trusty_shooter.zip"),
    Asset("ANIM", "anim/trusty_shooter.zip"),
    --Asset("INV_IMAGE", "trusty_shooter_unloaded"),
	
	Asset("IMAGE","images/inventoryimages/hunter_trusty_shooter.tex"),
	Asset("ATLAS","images/inventoryimages/hunter_trusty_shooter.xml"),
}

local function SpeedChangeFn(inst,attacker,target)
	return (1 - math.random()*2) * 5
end 

local function GetDelayFn(inst,attacker,target)
	return math.random() * 0.4
end 

local function CanAttack(inst,owner,target) ------------���ر��գ��ж�Ŀ���Ƿ���Ŀ��Ա����������Ա��˺�
	return IceyUtil.CanAttack(target,owner)
end 

local function onequip(inst, owner, force)
    owner.AnimState:OverrideSymbol("swap_object", "swap_trusty_shooter", "swap_trusty_shooter")
    owner.AnimState:Show("ARM_carry")
    owner.AnimState:Hide("ARM_normal")
end

local function onunequip(inst,owner)
    owner.AnimState:ClearOverrideSymbol("swap_object")
    owner.AnimState:Hide("ARM_carry")
    owner.AnimState:Show("ARM_normal")
end



local function fn()
    local inst = CreateEntity()
	inst.entity:AddTransform()
	inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
	inst.entity:AddNetwork()

    MakeInventoryPhysics(inst)
	
	inst:AddTag("iceygun")
    inst:AddTag("hand_gun")

    inst.AnimState:SetBank("trusty_shooter")
    inst.AnimState:SetBuild("trusty_shooter")
    inst.AnimState:PlayAnimation("idle")
	
	inst.entity:SetPristine()	
	
    if not TheWorld.ismastersim then
        return inst
    end	  

    inst:AddComponent("inspectable")

    inst:AddComponent("weapon")
    inst.components.weapon:SetRange(12,12)
    inst.components.weapon:SetDamage(5)
	inst.components.weapon:SetProjectile("pod_projectile_fire")
	inst.components.weapon:SetShotgun(true,8,PI/3,SpeedChangeFn,nil,CanAttack)

    inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "hunter_trusty_shooter"
	inst.components.inventoryitem.atlasname = "images/inventoryimages/hunter_trusty_shooter.xml"

    
    inst:AddComponent("equippable")
    inst.components.equippable:SetOnEquip(onequip)
    inst.components.equippable:SetOnUnequip(onunequip)


    return inst
end

return Prefab( "hunter_trusty_shooter", fn, assets)