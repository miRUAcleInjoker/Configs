local IceyUtil = require("icey_util")

local assets=
{
	Asset("ANIM", "anim/trident.zip"),
	Asset("ANIM", "anim/swap_trident.zip"),
	
	Asset("IMAGE","images/inventoryimages/dragonslayer_trident.tex"),
	Asset("ATLAS","images/inventoryimages/dragonslayer_trident.xml"),
}

local function ReticuleTargetFn()
  local player = ThePlayer
  local ground = TheWorld.Map
  local pos = Vector3()
  --Cast range is 8, leave room for error
  --4 is the aoe range
  for r = 7, 0, -.25 do
    pos.x, pos.y, pos.z = player.entity:LocalToWorldSpace(r, 0, 0)
    if ground:IsPassableAtPoint(pos:Get()) and not ground:IsGroundTargetBlocked(pos) then
      return pos
    end
  end
  return pos
end

local function onfinished(inst)
	inst:Remove()
end

local function onequip(inst, owner) 
	owner.AnimState:OverrideSymbol("swap_object", "swap_trident", "swap_trident")
	owner.AnimState:Show("ARM_carry") 
	owner.AnimState:Hide("ARM_normal") 
end

local function onunequip(inst, owner) 
	owner.AnimState:Hide("ARM_carry") 
	owner.AnimState:Show("ARM_normal") 
end



local function oncastfn(inst, doer,pos)
	--SpawnAt("lightning",inst:GetPosition())
	if not IceyUtil.DefaultCostFn(doer,{stamina = 15,focus = 35}) then 
		return 
	end 
		
	
	if  inst.components.finiteuses:GetUses() < 2 then 
		return 
	end 
	inst.components.finiteuses:Use(2)
	local lightning = SpawnPrefab("lightning")
    lightning.entity:AddFollower()
    lightning.Follower:FollowSymbol(doer.GUID, "swap_object", 30,-110,0)

	local shock_fx = SpawnPrefab("shock_fx") 
    shock_fx.entity:AddFollower() 
    shock_fx.Follower:FollowSymbol(doer.GUID, "swap_object", 10,-50,0) 
	inst:DoTaskInTime(0.5,function()
		--doer.AnimState:PlayAnimation("atk")
		local thunder = SpawnAt("tadalin_lava_lightning",pos)
		thunder:SetSize("medium",1.5)
		local ents = TheSim:FindEntities(pos.x,pos.y,pos.z,4,{"_combat"},TUNING.ICEY_NO_TAGS)
		for k,v in pairs(ents) do 
			if IceyUtil.CanAttack(v,doer) and inst.components.finiteuses:GetUses() >= 3 then 
				v.components.combat:GetAttacked(doer,80,nil,"electric")
				inst.components.finiteuses:Use(3)
			end
		end
	end) 
	inst.components.rechargeable:StartRecharge()
end 


local function commonfn(Sim)
	local inst = CreateEntity()
	local trans = inst.entity:AddTransform()
	local anim = inst.entity:AddAnimState()
	inst.entity:AddNetwork()
	
	MakeInventoryPhysics(inst)
	
	anim:SetBank("trident")
	anim:SetBuild("trident")
	anim:PlayAnimation("idle")
	
	inst:AddTag("sharp")
	inst:AddTag("pointy")
	inst:AddTag("rechargeable")
	inst:AddTag("dragonslayer_trident")
	
	
	inst:AddComponent("aoetargeting")
	inst.components.aoetargeting:SetTargetFX("weaponsparks")
	inst.components.aoetargeting.reticule.reticuleprefab = "reticuleaoe"
	inst.components.aoetargeting.reticule.pingprefab = "reticuleaoeping"
	inst.components.aoetargeting.reticule.targetfn = ReticuleTargetFn
	inst.components.aoetargeting.reticule.validcolour = { 1, .75, 0, 1 }
    inst.components.aoetargeting.reticule.invalidcolour = { .5, 0, 0, 1 }
	inst.components.aoetargeting.reticule.ease = true
	inst.components.aoetargeting.reticule.mouseenabled = true
	inst.components.aoetargeting:SetRange(12)
	
	inst.entity:SetPristine()
    if not TheWorld.ismastersim then
        return inst
    end

	inst:AddComponent("weapon")
	--inst.components.weapon:SetOnAttack(onattack)
	inst.components.weapon:SetDamage(34)	
	-------
	
	inst:AddComponent("aoespell")
	inst.components.aoespell:SetOnCastFn(oncastfn)
	
	inst:AddComponent("rechargeable")
	inst.components.rechargeable:SetRechargeTime(3)
	
	inst:AddComponent("finiteuses")
	inst.components.finiteuses:SetMaxUses(200)
	inst.components.finiteuses:SetUses(200)
	
	inst.components.finiteuses:SetOnFinished( onfinished )

	inst:AddComponent("inspectable")
	
	inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "dragonslayer_trident"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/dragonslayer_trident.xml"
	
	inst:AddComponent("equippable")
	inst.components.equippable:SetOnEquip( onequip )
	inst.components.equippable:SetOnUnequip( onunequip )
	
	return inst
end

return Prefab( "dragonslayer_trident", commonfn, assets)
