local IceyUtil = require("icey_util")

local assets =
{
	Asset("IMAGE","images/inventoryimages/pyromancy_flame.tex"),
	Asset("ATLAS","images/inventoryimages/pyromancy_flame.xml"),
}

local prefabs = {
	"eyeflame",
	"eyeflame_net",
}

local FLAMES = {
	torchfire = Vector3(-5,0,4),
	torchfire_shadow = Vector3(0,0,0),
	torchfire_rag = Vector3(0,10,0),
	torchfire_spooky = Vector3(0,0,0),
	eyeflame = Vector3(0,0,0),
	eyeflame_net = Vector3(0,0,0),
}

----------------------------------------------------------------------------------------------
--Line
local function ReticuleTargetFnLine()
    return Vector3(ThePlayer.entity:LocalToWorldSpace(6.5, 0, 0))
end

local function ReticuleMouseTargetFnLine(inst, mousepos)
    if mousepos ~= nil then
        local x, y, z = inst.Transform:GetWorldPosition()
        local dx = mousepos.x - x
        local dz = mousepos.z - z
        local l = dx * dx + dz * dz
        if l <= 0 then
            return inst.components.reticule.targetpos
        end
        l = 6.5 / math.sqrt(l)
        return Vector3(x + dx * l, 0, z + dz * l)
    end
end

local function ReticuleUpdatePositionFnLine(inst, pos, reticule, ease, smoothing, dt)
    local x, y, z = inst.Transform:GetWorldPosition()
    reticule.Transform:SetPosition(x, 0, z)
    local rot = -math.atan2(pos.z - z, pos.x - x) / DEGREES
    if ease and dt ~= nil then
        local rot0 = reticule.Transform:GetRotation()
        local drot = rot - rot0
        rot = Lerp((drot > 180 and rot0 + 360) or (drot < -180 and rot0 - 360) or rot0, rot, dt * smoothing)
    end
    reticule.Transform:SetRotation(rot)
end
----------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------
--Point
local function ReticuleTargetFnPoint()
	local player = ThePlayer
	local ground = TheWorld.Map
	local pos = Vector3()
	  --Cast range is 8, leave room for error
	  --4 is the aoe range
	for r = 7, 0, -.25 do
		pos.x, pos.y, pos.z = player.entity:LocalToWorldSpace(r, 0, 0)
		if ground:IsPassableAtPoint(pos:Get()) and not ground:IsGroundTargetBlocked(pos) then
			return pos
		end
	end
	return pos
end
----------------------------------------------------------------------------------------------

local function ReticuleMouseTargetFnBoth(inst, mousepos)
	local owner = ThePlayer
	local book = owner.replica.inventory and owner.replica.inventory:GetEquippedItem(EQUIPSLOTS.PYROMANCY_SLOT1)
	if book and inst then 
		if book:HasTag("aoe_line") then 
			return ReticuleMouseTargetFnLine(inst, mousepos)
		elseif book:HasTag("aoe_point") then 
			return mousepos
		end
	end 
end 

local function CheckAoeTargetingReplica(inst)
	local owner = ThePlayer
	local book = owner.replica.inventory and owner.replica.inventory:GetEquippedItem(EQUIPSLOTS.PYROMANCY_SLOT1)
	if book and inst then 
		if book:HasTag("aoe_line") then 
			inst.components.aoetargeting:SetAlwaysValid(true)
			inst.components.aoetargeting.reticule.reticuleprefab = "reticulelongmulti"
			inst.components.aoetargeting.reticule.pingprefab = "reticulelongmultiping"
			inst.components.aoetargeting.reticule.targetfn = ReticuleTargetFnLine
			inst.components.aoetargeting.reticule.mousetargetfn = ReticuleMouseTargetFnLine
			inst.components.aoetargeting.reticule.updatepositionfn = ReticuleUpdatePositionFnLine
			
			inst.components.aoetargeting.reticule.ease = true
			inst.components.aoetargeting.reticule.mouseenabled = true
		elseif book:HasTag("aoe_point") then 
			inst.components.aoetargeting:SetAlwaysValid(false)
			inst.components.aoetargeting.reticule.reticuleprefab = "reticuleaoe"
			inst.components.aoetargeting.reticule.pingprefab = "reticuleaoeping"
			inst.components.aoetargeting.reticule.targetfn = ReticuleTargetFnPoint
			inst.components.aoetargeting.reticule.ease = true
			inst.components.aoetargeting.reticule.mouseenabled = true
		end 
	end 
end 

local function CheckAoeTargeting(owner)
	local book = owner.components.inventory:GetEquippedItem(EQUIPSLOTS.PYROMANCY_SLOT1)
	local inst = owner.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
	
	if inst then 
		inst._Type:set(tostring(book))
	end 
end 

local function EnableCastFire(inst,enable)
	local owner = inst.components.inventoryitem:GetGrandOwner()
	if not owner and owner:IsValid() then 
		return 
	end 
	if inst.castfire and inst.castfire:IsValid() then 
		inst.castfire:Remove()
	end 
	inst.castfire = nil 
	if enable then
		local fire = SpawnPrefab(inst.firename)
		local fireoffset = FLAMES[inst.firename] or Vector3(0,0,0)
		fire.entity:SetParent(owner.entity)
		fire.entity:AddFollower()
		fire.Follower:FollowSymbol(owner.GUID, "swap_object",fireoffset:Get())
		inst.castfire = fire
	else
		
	end
end 


local function checkground(inst)
	local owner = inst.components.inventoryitem.owner
	
	for k,v in pairs(inst.groundfires) do 
		if v:IsValid() then 
			v:Remove()
		end
	end 
	inst.groundfires = {}
	
	if  owner and owner:IsValid() then 
		---鍦ㄨ儗鍖呴噷
	else 
		---鍦ㄥ湴闈?
		local flame = inst:SpawnChild(inst.flamename)
		--local fire = inst:SpawnChild(inst.firename)
		table.insert(inst.groundfires,flame)
		--table.insert(inst.groundfires,fire)
	end
end 

local function onequip(inst, owner)
	owner.AnimState:ClearOverrideSymbol("swap_object")
    owner.AnimState:Show("ARM_carry")
    owner.AnimState:Hide("ARM_normal")
	
	local flame = SpawnPrefab(inst.flamename)
	local flameoffset = FLAMES[inst.flamename] or Vector3(0,0,0)
	flame.entity:SetParent(owner.entity)
    flame.entity:AddFollower()
    flame.Follower:FollowSymbol(owner.GUID, "swap_object",flameoffset:Get())

	--local fire = SpawnPrefab(inst.firename)
	--local fireoffset = FLAMES[inst.firename] or Vector3(0,0,0)
	--fire.entity:SetParent(owner.entity)
    --fire.entity:AddFollower()
    --fire.Follower:FollowSymbol(owner.GUID, "swap_object",fireoffset:Get())
	
	
	
	table.insert(inst.fires,flame)
	--table.insert(inst.fires,fire)
	checkground(inst)
	--owner:DoTaskInTime(0,CheckAoeTargeting)
	--inst:ListenForEvent("equip",CheckAoeTargeting,owner)
	--inst:ListenForEvent("unequip",CheckAoeTargeting,owner)
end

local function onunequip(inst, owner)
    owner.AnimState:Hide("ARM_carry")
    owner.AnimState:Show("ARM_normal")
	owner.AnimState:ClearOverrideSymbol("swap_object")
	for k,v in pairs(inst.fires) do 
		if v:IsValid() then 
			v:Remove()
		end
	end 
	inst.fires = {} 
	checkground(inst)
	--owner:DoTaskInTime(0,CheckAoeTargeting)
	--inst:RemoveEventCallback("equip",CheckAoeTargeting,owner)
	--inst:RemoveEventCallback("unequip",CheckAoeTargeting,owner)
	
end

local function canattack(inst,owner,target) ------------澶氶噸淇濋櫓锛氬垽瀹氱洰鏍囨槸鍚︾湡鐨勫彲浠ヨ鏀诲嚮锛屽彲浠ヨ浼ゅ
	return IceyUtil.CanAttack(target,owner)
end 

local function oncastfn(inst,doer,pos)
	--[[local book = doer.components.inventory and doer.components.inventory:FindItem(function(item) 
		return item and item:IsValid() and item:HasTag("pyromancy_book") and item.Pyromancy
	end)--]]
	local book = doer.components.inventory and doer.components.inventory:GetEquippedItem(EQUIPSLOTS.PYROMANCY_SLOT1)
	if book then 
		book.Pyromancy(inst,doer,pos)
	else
		--[[local proj = SpawnAt("fireball_projectile",inst:GetPosition())
		
		proj:AddComponent("ly_projectile")
		proj.components.ly_projectile:CopyFrom()
		proj.components.ly_projectile.damage = 44.5
		proj.components.ly_projectile:SetCanHit(canattack)
		proj.components.ly_projectile:Throw(doer,pos,true)--]]
		if doer.components.talker then 
			doer.components.talker:Say("我必须装备咒术才能发动。")
		end
	end
	inst.components.rechargeable:StartRecharge()
end 


local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()
	inst.entity:AddSoundEmitter()

    MakeInventoryPhysics(inst)

    --inst.AnimState:SetBank("spear")
    --inst.AnimState:SetBuild("swap_spear")
    --inst.AnimState:PlayAnimation("idle")

    inst:AddTag("pyromancy_flame")
	inst:AddTag("rechargeable")
    --inst:AddTag("pointy")
	
	--inst._Type = net_string(inst.GUID, "inst._Type","typedirty")
	
	inst:AddComponent("aoetargeting")
	inst.components.aoetargeting:SetAlwaysValid(true)
	inst.components.aoetargeting.reticule.reticuleprefab = "reticulelongmulti"
	inst.components.aoetargeting.reticule.pingprefab = "reticulelongmultiping"
	inst.components.aoetargeting.reticule.targetfn = ReticuleTargetFnPoint
	inst.components.aoetargeting.reticule.mousetargetfn = ReticuleMouseTargetFnBoth 
	inst.components.aoetargeting.reticule.updatepositionfn = ReticuleUpdatePositionFnLine
			
	inst.components.aoetargeting.reticule.ease = true
	inst.components.aoetargeting.reticule.mouseenabled = true
	inst.components.aoetargeting:SetRange(12)
	inst.components.aoetargeting.reticule.validcolour = { 1, .75, 0, 1 }
    inst.components.aoetargeting.reticule.invalidcolour = { .5, 0, 0, 1 }

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
		--inst:ListenForEvent("typedirty", CheckAoeTargetingReplica)
        return inst
    end
	
	
	inst.fires = {} 
	inst.groundfires = {} 
	inst.castfire = nil 
	inst.flamename = "eyeflame_net"
	inst.firename = "torchfire_rag" --"torchfire" "torchfire_rag" "torchfire_shadow" "torchfire_spooky" "eyeflame"
	inst.checkground = checkground
	inst.EnableCastFire = EnableCastFire
	
	
	
	inst:AddComponent("weapon")
    inst.components.weapon:SetDamage(10)

    inst:AddComponent("inspectable")

    inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "pyromancy_flame"
	inst.components.inventoryitem.atlasname = "images/inventoryimages/pyromancy_flame.xml"

    inst:AddComponent("equippable")
    inst.components.equippable:SetOnEquip(onequip)
    inst.components.equippable:SetOnUnequip(onunequip)
	
	inst:AddComponent("rechargeable")
	inst.components.rechargeable:SetRechargeTime(1)
	
	inst:AddComponent("aoespell")
	inst.components.aoespell:SetOnCastFn(oncastfn)

    MakeHauntableLaunch(inst)
	
	inst:DoTaskInTime(0,checkground)
	inst:ListenForEvent("onputininventory",checkground)
	inst:ListenForEvent("onpickup",checkground)
	inst:ListenForEvent("ondropped",checkground)
	
	
    return inst
end

return Prefab("pyromancy_flame", fn, assets,prefabs)