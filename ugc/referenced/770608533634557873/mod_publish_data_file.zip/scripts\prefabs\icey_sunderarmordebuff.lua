local assets =
{
    Asset("ANIM", "anim/lavaarena_sunder_armor.zip"),
}

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    --inst.entity:AddFollower()
    inst.entity:AddAnimState()
	inst.entity:AddLabel()
    inst.entity:AddNetwork()

    inst:AddTag("DECOR") --"FX" will catch mouseover
    inst:AddTag("NOCLICK")

    inst.AnimState:SetBank("lavaarena_sunder_armor")
    inst.AnimState:SetBuild("lavaarena_sunder_armor")
	inst.AnimState:PlayAnimation("pre")
	inst.AnimState:PushAnimation("loop",true)
	
	inst.Label:SetFontSize(25)
    inst.Label:SetFont(DEFAULTFONT)
    inst.Label:SetWorldOffset(0, 3, 0)
    inst.Label:SetUIOffset(0, 35, 0)
    inst.Label:SetColour(1, 1, 1)
    inst.Label:Enable(false)
    

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.target = nil 
	
	inst.SetTarget = function(self,target,height)
		height = height or 0
		self.target = target 
		self.entity:SetParent(target.entity)         
		self.Transform:SetPosition(0,height,0) 
		
		--self:ListenForEvent("death")
	end
	
	inst.ShowCombatMults = function(self,source,key)
		self.Label:Enable(true)
		if self.ShowCombatMultsTask then 
			self.ShowCombatMultsTask:Cancel()
			self.ShowCombatMultsTask = nil 
		end 
		self.ShowCombatMultsTask = self:DoPeriodicTask(0,function()
			local target = self.target  
			if not (target and target:IsValid() and target.components.combat and target.components.health) then
				return 
			end
			local str = "NIL"
			local Modifier = target.components.combat.externaldamagetakenmultipliers
			local nums = Modifier:CalculateModifierFromSource(source,key)
		
			if source and key and nums then 
				str = "Source:"..tostring(source).."\nKey:"..tostring(key).."\nMults:"..tostring(nums)
			end 
		
			inst.Label:SetText(str)
			
			--[[if nums <= 1 then 
				self:KillFx()
			end--]]
		end)
	end 
	
	inst.KillFx = function(self)
		self.AnimState:PlayAnimation("pst")
		self:ListenForEvent("animover",inst.Remove)
	end 

    --event_server_data("lavaarena", "prefabs/sunderarmordebuff").master_postinit(inst)

    return inst
end

return Prefab("icey_sunderarmordebuff", fn, assets)
