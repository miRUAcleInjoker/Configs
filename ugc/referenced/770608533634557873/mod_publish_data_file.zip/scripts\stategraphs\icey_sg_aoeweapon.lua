--���⹥��
AddStategraphPostInit("wilson", function(sg)
    local old_CASTAOE = sg.actionhandlers[ACTIONS.CASTAOE].deststate
    sg.actionhandlers[ACTIONS.CASTAOE].deststate = function(inst, action)
		local weapon = action.invobject
		local book = inst.components.inventory and inst.components.inventory:GetEquippedItem(EQUIPSLOTS.PYROMANCY_SLOT1)
		if weapon then 
            if weapon:HasTag("dragonslayer_trident") then 
				return "castaoe_dragonslayer_trident"
			elseif weapon:HasTag("axe_victorian") then 
				return "castaoe_axe_victorian"
			elseif weapon:HasTag("shadowmixtures_blade") then 
				return "castaoe_shadowmixtures_blade"
			elseif weapon:HasTag("iceyweaponskill_taunt") then 
				return "iceyweaponskill_taunt"
			elseif weapon:HasTag("iceyweaponskill_pray") then 
				return "iceyweaponskill_pray"	
			elseif weapon:HasTag("iceyweaponskill_shovel") then 
				return "iceyweaponskill_shovel"	
			elseif weapon:HasTag("icey_aoeweapon_leap") then 
				return "icey_combat_leap_start"
			elseif weapon:HasTag("yhorm_shield") then 
				return "yhorm_shield_prop_pre"
			elseif weapon:HasTag("iceygun") then 
                return "iceygun_shoot"
			elseif weapon:HasTag("iceyweaponskill_hammer") then 
                return "hammer_start"
				
			elseif weapon:HasTag("pyromancy_flame") then 
				if book then
					if book:HasTag("quickcast") then
						return "quickcast_pyromancy"
					else
						return "cast_pyromancy"
					end
				else
					return "failed_pyromancy"
				end 
			end
		end 
        return old_CASTAOE(inst, action)
    end
end)
AddStategraphPostInit("wilson_client", function(sg)
    local old_CASTAOE = sg.actionhandlers[ACTIONS.CASTAOE].deststate
    sg.actionhandlers[ACTIONS.CASTAOE].deststate = function(inst, action)
		local weapon = action.invobject
		local book = inst.replica.inventory and inst.replica.inventory:GetEquippedItem(EQUIPSLOTS.PYROMANCY_SLOT1)
		if weapon then 
            if weapon:HasTag("dragonslayer_trident") then 
				return "castaoe_dragonslayer_trident"
			elseif weapon:HasTag("axe_victorian") then 
				return "castaoe_axe_victorian"
			elseif weapon:HasTag("shadowmixtures_blade") then 
				return "castaoe_shadowmixtures_blade"
			elseif weapon:HasTag("iceyweaponskill_taunt") then 
				return "iceyweaponskill_taunt"
			elseif weapon:HasTag("iceyweaponskill_pray") then 
				return "iceyweaponskill_pray"
			elseif weapon:HasTag("iceyweaponskill_shovel") then 
				return "iceyweaponskill_shovel"	
			elseif weapon:HasTag("icey_aoeweapon_leap") then 
				return "icey_combat_leap_start"
			elseif weapon:HasTag("yhorm_shield") then 
				return "yhorm_shield_prop_pre"
			elseif weapon:HasTag("iceygun") then 
                return "iceygun_shoot"
			elseif weapon:HasTag("iceyweaponskill_hammer") then 
                return "hammer_start"
			elseif weapon:HasTag("pyromancy_flame") then 
				if book then
					if book:HasTag("quickcast") then
						return "quickcast_pyromancy"
					else
						return "cast_pyromancy"
					end
				else
					return "failed_pyromancy"		
				end 
			end
		end 
        return old_CASTAOE(inst, action)
    end
end)

local function OnRemoveCleanupTargetFX(inst)
    if inst.sg.statemem.targetfx.KillFX ~= nil then
        inst.sg.statemem.targetfx:RemoveEventCallback("onremove", OnRemoveCleanupTargetFX, inst)
        inst.sg.statemem.targetfx:KillFX()
    else
        inst.sg.statemem.targetfx:Remove()
    end
end

local function ToggleOffPhysics(inst)
    inst.sg.statemem.isphysicstoggle = true
    inst.Physics:ClearCollisionMask()
    inst.Physics:CollidesWith(COLLISION.GROUND)
end

local function ToggleOnPhysics(inst)
    inst.sg.statemem.isphysicstoggle = nil
    inst.Physics:ClearCollisionMask()
    inst.Physics:CollidesWith(COLLISION.WORLD)
    inst.Physics:CollidesWith(COLLISION.OBSTACLES)
    inst.Physics:CollidesWith(COLLISION.SMALLOBSTACLES)
    inst.Physics:CollidesWith(COLLISION.CHARACTERS)
    inst.Physics:CollidesWith(COLLISION.GIANTS)
end

local function DoEmoteFX(inst, prefab)
    local fx = SpawnPrefab(prefab)
    if fx ~= nil then
        if inst.components.rider:IsRiding() then
            fx.Transform:SetSixFaced()
        end
        fx.entity:SetParent(inst.entity)
        fx.entity:AddFollower()
        fx.Follower:FollowSymbol(inst.GUID, "emotefx", 0, 0, 0)
    end
end

local function DoForcedEmoteSound(inst, soundpath)
    inst.SoundEmitter:PlaySound(soundpath)
end

local function DoEmoteSound(inst, soundoverride, loop)
    --NOTE: loop only applies to soundoverride
    loop = loop and soundoverride ~= nil and "emotesoundloop" or nil
    local soundname = soundoverride or "emote"
    local emotesoundoverride = soundname.."soundoverride"
    if inst[emotesoundoverride] ~= nil then
        inst.SoundEmitter:PlaySound(inst[emotesoundoverride], loop)
    elseif not inst:HasTag("mime") then
        inst.SoundEmitter:PlaySound((inst.talker_path_override or "dontstarve/characters/")..(inst.soundsname or inst.prefab).."/"..soundname, loop)
    end
end

AddStategraphState("wilson", 
	State{
		name = "castaoe_dragonslayer_trident",
        tags = { "aoe", "doing", "busy", "nointerrupt", "nomorph" },
		onenter = function(inst)
			inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("multithrust_yell")
		end,
		timeline =
		{
			TimeEvent(5 * FRAMES, function(inst)
				--inst.AnimState:PlayAnimation("atk")
                inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon")
				inst:PerformBufferedAction()
            end),
		},
		events =
		{
			EventHandler("animover", function(inst)
				inst.sg:GoToState("idle")
			end),
		},	
	}
)

AddStategraphState("wilson_client", 
	State{
		name = "castaoe_dragonslayer_trident",
        tags = { "aoe", "doing", "busy", "nointerrupt", "nomorph" },
		onenter = function(inst)
			inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("multithrust_yell")
			inst:PerformPreviewBufferedAction()
		end,
		timeline =
		{
			TimeEvent(5 * FRAMES, function(inst)
				--inst.AnimState:PlayAnimation("atk")
                inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon")
            end),
		},
		events =
		{
			EventHandler("animover", function(inst)
				inst.sg:GoToState("idle")
			end),
		},	
		onexit = function(inst)
			inst:ClearBufferedAction()
		end,
	}
)

AddStategraphState("wilson", 
	State{
		name = "quickcast_pyromancy",
        tags = { "aoe", "doing", "busy", "nointerrupt", "nomorph" },
		onenter = function(inst)
			local weapon = inst.components.combat:GetWeapon()			
			inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("multithrust_yell")
			weapon:EnableCastFire(true)
			inst.sg.statemem.pyromancy_flame = weapon
			
			inst.sg:SetTimeout(17*FRAMES)
			local firepuff = SpawnPrefab("halloween_firepuff_"..math.random(1,3))
			firepuff.Transform:SetScale(0.4,0.4,0.4)
			firepuff.entity:SetParent(inst.entity)
			firepuff.entity:AddFollower()
			firepuff.Follower:FollowSymbol(inst.GUID, "swap_object",0,50,0)
		end,
		
		onexit = function(inst)
			local weapon = inst.sg.statemem.pyromancy_flame
			if weapon and weapon:IsValid() then 
				weapon:EnableCastFire(false)
			end 
			inst.sg.statemem.pyromancy_flame = nil 
		end,
		
		ontimeout = function(inst)
			inst.sg:GoToState("idle",true)
		end,
		
		timeline =
		{
			TimeEvent(8 * FRAMES, function(inst)
				inst.AnimState:PlayAnimation("atk_pre")
                inst.AnimState:PushAnimation("atk", false)
			end),
			TimeEvent(14 * FRAMES, function(inst)
				--inst.AnimState:PlayAnimation("atk")
                inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon")
				inst:PerformBufferedAction()
            end),
		},
		
		events =
        {
            EventHandler("equip", function(inst) inst.sg:GoToState("idle") end),
            EventHandler("unequip", function(inst) inst.sg:GoToState("idle") end),
        },
	}
)

AddStategraphState("wilson_client", 
	State{
		name = "quickcast_pyromancy",
        tags = { "aoe", "doing", "busy", "nointerrupt", "nomorph" },
		onenter = function(inst)
			inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("multithrust_yell")
			
			inst:PerformPreviewBufferedAction()
			inst.sg:SetTimeout(17*FRAMES)
		end,
		
		onexit = function(inst)

		end,
		
		ontimeout = function(inst)
			inst:ClearBufferedAction()
			inst.sg:GoToState("idle",true)
		end,
		
		timeline =
		{
			TimeEvent(8 * FRAMES, function(inst)
				inst.AnimState:PlayAnimation("atk_pre")
                inst.AnimState:PushAnimation("atk", false)
			end),
			TimeEvent(14 * FRAMES, function(inst)
				--inst.AnimState:PlayAnimation("atk")
                inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon")
				inst:PerformPreviewBufferedAction()
            end),
		},
		
		events =
        {
            EventHandler("equip", function(inst) inst.sg:GoToState("idle") end),
            EventHandler("unequip", function(inst) inst.sg:GoToState("idle") end),
        },
	}
)
AddStategraphState("wilson", 
    State{
        name = "cast_pyromancy",
        tags = { "doing", "busy", "canrotate" },

        onenter = function(inst)
            if inst.components.playercontroller ~= nil then
                inst.components.playercontroller:Enable(false)
            end
            inst.AnimState:PlayAnimation("staff_pre")
            inst.AnimState:PushAnimation("staff", false)
            inst.components.locomotor:Stop()

            --Spawn an effect on the player's location
            local staff = inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
			local book = inst.components.inventory:GetEquippedItem(EQUIPSLOTS.PYROMANCY_SLOT1)
			
            local colour = (staff and staff.fxcolour) or (book and book.fxcolour) or { 1, 1, 1 }
			local castsound = (staff and staff.castsound) or (book and book.castsound) or "dontstarve/wilson/use_gemstaff"

            inst.sg.statemem.stafffx = SpawnPrefab(inst.components.rider:IsRiding() and "staffcastfx_mount" or "staffcastfx")
            inst.sg.statemem.stafffx.entity:SetParent(inst.entity)
			inst.sg.statemem.stafffx.Transform:SetPosition(0,-1,0)
            inst.sg.statemem.stafffx.Transform:SetRotation(inst.Transform:GetRotation())
            inst.sg.statemem.stafffx:SetUp(colour)

            inst.sg.statemem.stafflight = SpawnPrefab("staff_castinglight")
            inst.sg.statemem.stafflight.Transform:SetPosition(inst.Transform:GetWorldPosition())
            inst.sg.statemem.stafflight:SetUp(colour, 1.9, .33)

            if staff ~= nil and staff.components.aoetargeting ~= nil and staff.components.aoetargeting.targetprefab ~= nil then
                local buffaction = inst:GetBufferedAction()
                if buffaction ~= nil and buffaction.pos ~= nil then
                    inst.sg.statemem.targetfx = SpawnPrefab(staff.components.aoetargeting.targetprefab)
                    if inst.sg.statemem.targetfx ~= nil then
                        inst.sg.statemem.targetfx.Transform:SetPosition(buffaction.pos:Get())
                        inst.sg.statemem.targetfx:ListenForEvent("onremove", OnRemoveCleanupTargetFX, inst)
                    end
                end
            end

            inst.sg.statemem.castsound = castsound
        end,

        timeline =
        {
            TimeEvent(13 * FRAMES, function(inst)
                inst.SoundEmitter:PlaySound(inst.sg.statemem.castsound)
            end),
			TimeEvent(40 * FRAMES, function(inst)
				--V2C: NOTE! if we're teleporting ourself, we may be forced to exit state here!
                inst:PerformBufferedAction()
			end),
            TimeEvent(53 * FRAMES, function(inst)
                if inst.sg.statemem.targetfx ~= nil then
                    if inst.sg.statemem.targetfx:IsValid() then
                        OnRemoveCleanupTargetFX(inst)
                    end
                    inst.sg.statemem.targetfx = nil
                end
                inst.sg.statemem.stafffx = nil --Can't be cancelled anymore
                inst.sg.statemem.stafflight = nil --Can't be cancelled anymore
                
            end),
        },

        events =
        {
            EventHandler("animqueueover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("idle")
                end
            end),
        },

        onexit = function(inst)
            if inst.components.playercontroller ~= nil then
                inst.components.playercontroller:Enable(true)
            end
            if inst.sg.statemem.stafffx ~= nil and inst.sg.statemem.stafffx:IsValid() then
                inst.sg.statemem.stafffx:Remove()
            end
            if inst.sg.statemem.stafflight ~= nil and inst.sg.statemem.stafflight:IsValid() then
                inst.sg.statemem.stafflight:Remove()
            end
            if inst.sg.statemem.targetfx ~= nil and inst.sg.statemem.targetfx:IsValid() then
                OnRemoveCleanupTargetFX(inst)
            end
        end,
    }
)
AddStategraphState("wilson_client", 
	State
    {
        name = "cast_pyromancy",
        tags = { "doing", "busy", "canrotate" },

        onenter = function(inst)
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("staff_pre")
            inst.AnimState:PushAnimation("staff_lag", false)

            inst:PerformPreviewBufferedAction()
            inst.sg:SetTimeout(TIMEOUT)
        end,

        onupdate = function(inst)
            if inst:HasTag("doing") then
                if inst.entity:FlattenMovementPrediction() then
                    inst.sg:GoToState("idle", "noanim")
                end
            elseif inst.bufferedaction == nil then
                inst.sg:GoToState("idle")
            end
        end,

        ontimeout = function(inst)
            inst:ClearBufferedAction()
            inst.sg:GoToState("idle")
        end,
    }
)

AddStategraphState("wilson", 
    State{
        name = "failed_pyromancy",
        tags = { "idle", "canrotate" },

        onenter = function(inst, pushanim)
            inst.components.locomotor:Stop()
            inst.components.locomotor:Clear()
			inst.AnimState:PlayAnimation("idle_loop")
			inst:PerformBufferedAction()
        end,

        events =
        {
            EventHandler("animover", function(inst, data)
                inst.sg:GoToState("idle",true)
            end),
        },

        ontimeout = function(inst)
            inst.sg:GoToState("idle",true)
        end,
    }
)

AddStategraphState("wilson_client", 
    State{
        name = "failed_pyromancy",
        tags = { "idle", "canrotate" },

        onenter = function(inst, pushanim)
			inst.AnimState:PlayAnimation("idle_loop")
			inst:PerformPreviewBufferedAction()
        end,

        events =
        {
            EventHandler("animover", function(inst, data)
                inst.sg:GoToState("idle",true)
            end),
        },

        ontimeout = function(inst)
            inst.sg:GoToState("idle",true)
        end,
    }
)

AddStategraphState("wilson", 
    State{
        name = "iceyweaponskill_taunt",
        tags = { "aoe", "doing", "busy", "nointerrupt", "nomorph" },
        
        onenter = function(inst)
            inst.Physics:Stop()
            inst.AnimState:PlayAnimation("emote_fistshake")
			DoEmoteFX(inst, "emote_fx")
			DoEmoteSound(inst) 
			inst.sg:SetTimeout(inst.sg:SetTimeout(8 * FRAMES + inst.AnimState:GetCurrentAnimationLength()))
        end,
		
		timeline =
		{
			TimeEvent(8 * FRAMES, function(inst)
				inst:PerformBufferedAction()
            end),
		},
        
        events=
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end),
        },
    }
)

AddStategraphState("wilson_client", 
    State{
        name = "iceyweaponskill_taunt",
        tags = { "aoe", "doing", "busy", "nointerrupt", "nomorph" },
        
        onenter = function(inst)
            inst.Physics:Stop()
            inst.AnimState:PlayAnimation("emote_fistshake")
			DoEmoteSound(inst) 
			inst:PerformPreviewBufferedAction()
			inst.sg:SetTimeout(inst.sg:SetTimeout(8 * FRAMES + inst.AnimState:GetCurrentAnimationLength()))
        end,
        events=
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end),
        },
    }
)

AddStategraphState("wilson", 
	State{
        name = "iceyweaponskill_pray",
        tags = { "aoe", "doing", "busy", "nointerrupt", "nomorph" },
        onenter = function(inst)
            inst.components.playercontroller:Enable(false)
            inst.AnimState:PlayAnimation("emote_swoon")
			DoEmoteSound(inst) 
			inst.sg:SetTimeout(inst.sg:SetTimeout(8 * FRAMES + inst.AnimState:GetCurrentAnimationLength()))
        end,
        
        timeline=
        {
            TimeEvent(8 * FRAMES, function(inst)
				inst:PerformBufferedAction()
            end),
        },
        
        onexit = function(inst)
            inst.components.playercontroller:Enable(true)
        end,
   
        
        events=
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end),
        },

    }
)

AddStategraphState("wilson_client", 
	State{
        name = "iceyweaponskill_pray",
        tags = { "aoe", "doing", "busy", "nointerrupt", "nomorph" },
        onenter = function(inst)
            inst.AnimState:PlayAnimation("emote_swoon")
			inst:PerformPreviewBufferedAction()
			DoEmoteSound(inst) 
			inst.sg:SetTimeout(inst.sg:SetTimeout(8 * FRAMES + inst.AnimState:GetCurrentAnimationLength()))
        end,
        
        events=
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end),
        },

    }
)

AddStategraphState("wilson", 
	State{
        name = "castaoe_axe_victorian",
        tags = { "aoe", "doing", "busy", "nointerrupt", "nomorph","nopredict", },
        onenter = function(inst)
            inst.components.playercontroller:Enable(false)
            inst.AnimState:SetDeltaTimeMultiplier(2)
			inst.AnimState:PlayAnimation("iceyatk_circle1")
			inst.AnimState:PushAnimation("iceyatk_circle2",false)
			inst.AnimState:PushAnimation("iceyatk_circle3",false)
			
			inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon",nil,nil,true)
			inst.SoundEmitter:PlaySound("dontstarve/common/lava_arena/fireball",nil,nil,true)
			
			inst.sg.statemem.last_circle_time = 0
			inst.sg.statemem.circle_hit_targets = {} 
			--inst.sg:SetTimeout(20 * FRAMES)
        end,
		onupdate = function(inst)
			if GetTime() - inst.sg.statemem.last_circle_time >= 0.03 then 
				
				inst.components.combat:DoAreaAttack(inst,2.3, inst.components.combat:GetWeapon(), 
				function(target)
					return not inst.sg.statemem.circle_hit_targets[target]
				end, nil, { "INLIMBO","companion" })
				inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon")
				inst.sg.statemem.last_circle_time = GetTime()
			end 
		end,
        
        timeline=
        {
			TimeEvent(0 * FRAMES, function(inst)
				inst:PerformBufferedAction()
            end),
        },
        
        onexit = function(inst)
			inst.sg.statemem.last_circle_time = nil 
			inst.sg.statemem.circle_hit_targets = nil 
            inst.components.playercontroller:Enable(true)
			inst.AnimState:SetDeltaTimeMultiplier(1)
        end,
   
        
        events=
        {
            EventHandler("animqueueover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("idle")
                end
            end),
			EventHandler("onhitother", function(inst,data)
				local weapon = inst.components.combat:GetWeapon()
				if weapon and weapon:IsValid() and weapon.components.finiteuses then 
					weapon.components.finiteuses:Use(1) 
				end 
				SpawnPrefab("icey_weaponsparks"):SetPosition(inst,data.target)
				local target_pos = data.target:GetPosition()
				local function RotateFX(fx)
					fx.Transform:SetPosition(target_pos:Get())
					fx.Transform:SetRotation(inst.Transform:GetRotation())
				end
				local rand = math.random(1,2)
				if rand == 1 then
					RotateFX(SpawnPrefab("shadowstrike_slash_fx"))
				else
					RotateFX(SpawnPrefab("shadowstrike_slash2_fx"))
				end
				
				inst.sg.statemem.circle_hit_targets[data.target] = true
			end),
        },

    }
)

AddStategraphState("wilson_client", 
	State{
        name = "castaoe_axe_victorian",
        tags = { "aoe", "doing", "busy", "nointerrupt", "nomorph","nopredict", },
        onenter = function(inst)
			inst.components.playercontroller:Enable(false)
            inst.AnimState:SetDeltaTimeMultiplier(2)
			--[[inst.AnimState:PlayAnimation("iceyatk_circle1")
			inst.AnimState:PushAnimation("iceyatk_circle2",false)
			inst.AnimState:PushAnimation("iceyatk_circle3",false)--]]
			
			inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon",nil,nil,true)
			inst.SoundEmitter:PlaySound("dontstarve/common/lava_arena/fireball",nil,nil,true)
			inst:PerformPreviewBufferedAction()
			
			inst.sg:SetTimeout(20 * FRAMES)
        end,
		
		onexit = function(inst)
			inst.AnimState:SetDeltaTimeMultiplier(1)
		end,
        
        events=
        {
            EventHandler("animqueueover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("idle")
                end
            end),
        },

    }
)


AddStategraphState("wilson", 
	State{
        name = "castaoe_shadowmixtures_blade",
        tags = { "aoe", "doing", "busy", "nointerrupt", "nomorph", },
        onenter = function(inst)
			inst.Physics:Stop()
            inst.components.playercontroller:Enable(false)
			inst.AnimState:PlayAnimation("chop_pre")
			inst.AnimState:PushAnimation("chop_loop",false)
			
			inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_nightsword",nil,nil,true)
			--inst.SoundEmitter:PlaySound("dontstarve/common/lava_arena/fireball",nil,nil,true)

        end,
        
        timeline=
        {
			TimeEvent(12 * FRAMES, function(inst)
				inst:PerformBufferedAction()
            end),
        },
        
        onexit = function(inst)
            inst.components.playercontroller:Enable(true)
        end,
   
        
        events=
        {
            EventHandler("animqueueover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("idle")
                end
            end),
        },
    }
)

AddStategraphState("wilson_client", 
	State{
        name = "castaoe_shadowmixtures_blade",
        tags = { "aoe", "doing", "busy", "nointerrupt", "nomorph", },
        onenter = function(inst)
			inst.Physics:Stop()
			inst.components.playercontroller:Enable(false)

			inst.AnimState:PlayAnimation("chop_pre")
			inst.AnimState:PushAnimation("chop_loop",false)
			
			inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_nightsword",nil,nil,true)
			--inst.SoundEmitter:PlaySound("dontstarve/common/lava_arena/fireball",nil,nil,true)
			inst:PerformPreviewBufferedAction()
			
			inst.sg:SetTimeout(12 * FRAMES)
        end,
		
        
        events=
        {
            EventHandler("animqueueover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("idle")
                end
            end),
        },

    }
)

AddStategraphState("wilson", 
	State{
        name = "iceyweaponskill_shovel",
        tags = { "aoe", "doing", "busy", "nointerrupt", "nomorph",},
        onenter = function(inst)
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("shovel_pre")
            inst.AnimState:PushAnimation("shovel_loop", false)
        end,
        
        timeline=
        {
            TimeEvent(25 * FRAMES, function(inst)
                inst:PerformBufferedAction()
                inst.sg:RemoveStateTag("busy")
				inst.sg:RemoveStateTag("nointerrupt")
                inst.SoundEmitter:PlaySound("dontstarve/wilson/dig")
            end),
        },
        
        onexit = function(inst)
            
        end,
   
        
        events=
        {
            EventHandler("unequip", function(inst) inst.sg:GoToState("idle") end),
            EventHandler("animqueueover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.AnimState:PlayAnimation("shovel_pst")
                    inst.sg:GoToState("idle", true)
                end
            end),
        },

    }
)

AddStategraphState("wilson_client", 
	State{
        name = "iceyweaponskill_shovel",
        tags = { "aoe", "doing", "busy", "nointerrupt", "nomorph",},
        onenter = function(inst)
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("shovel_pre")
            inst.AnimState:PushAnimation("shovel_lag", false)

            inst:PerformPreviewBufferedAction()
            inst.sg:SetTimeout(2)
        end,

        onupdate = function(inst)
            if inst:HasTag("busy") then
                if inst.entity:FlattenMovementPrediction() then
                    inst.sg:GoToState("idle", "noanim")
                end
            elseif inst.bufferedaction == nil then
                inst.AnimState:PlayAnimation("shovel_pst")
                inst.sg:GoToState("idle", true)
            end
        end,

        ontimeout = function(inst)
            inst:ClearBufferedAction()
            inst.AnimState:PlayAnimation("shovel_pst")
            inst.sg:GoToState("idle", true)
        end,

    }
)

AddStategraphState("wilson", 
    State{
        name = "icey_combat_leap_start",
        tags = { "aoe", "doing", "busy", "nointerrupt", "nomorph" },

        onenter = function(inst)
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("atk_leap_pre")

            local weapon = inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
            if weapon ~= nil and weapon.components.aoetargeting ~= nil and weapon.components.aoetargeting.targetprefab ~= nil then
                local buffaction = inst:GetBufferedAction()
                if buffaction ~= nil and buffaction.pos ~= nil then
                    inst.sg.statemem.targetfx = SpawnPrefab(weapon.components.aoetargeting.targetprefab)
                    if inst.sg.statemem.targetfx ~= nil then
                        inst.sg.statemem.targetfx.Transform:SetPosition(buffaction:GetActionPoint():Get())
                        inst.sg.statemem.targetfx:ListenForEvent("onremove", OnRemoveCleanupTargetFX, inst)
                    end
                end
            end
        end,

        events =
        {
            EventHandler("combat_leap", function(inst, data)
                inst.sg.statemem.leap = true
                inst.sg:GoToState("icey_combat_leap", {
                    targetfx = inst.sg.statemem.targetfx,
                    data = data,
                })
            end),
            EventHandler("animover", function(inst)
                if inst.AnimState:AnimDone() then
                    if inst.AnimState:IsCurrentAnimation("atk_leap_pre") then
                        inst.AnimState:PlayAnimation("atk_leap_lag")
                        inst:PerformBufferedAction()
                    else
                        inst.sg:GoToState("idle")
                    end
                end
            end),
        },

        onexit = function(inst)
            if not inst.sg.statemem.leap and inst.sg.statemem.targetfx ~= nil and inst.sg.statemem.targetfx:IsValid() then
                OnRemoveCleanupTargetFX(inst)
            end
        end,
    }
)

AddStategraphState("wilson", 
    State{
        name = "icey_combat_leap",
        tags = { "aoe", "doing", "busy", "nointerrupt", "nopredict", "nomorph" },

        onenter = function(inst, data)
            if data ~= nil then
                inst.sg.statemem.targetfx = data.targetfx
                data = data.data
                if data ~= nil and
                    data.targetpos ~= nil and
                    data.weapon ~= nil and
                    data.weapon.components.aoeweapon_leap ~= nil and
                    inst.AnimState:IsCurrentAnimation("atk_leap_lag") then
                    ToggleOffPhysics(inst)
                    inst.Transform:SetEightFaced()
                    inst.AnimState:PlayAnimation("atk_leap")
                    inst.SoundEmitter:PlaySound("dontstarve/common/deathpoof")
                    inst.sg.statemem.startingpos = inst:GetPosition()
                    inst.sg.statemem.weapon = data.weapon
                    inst.sg.statemem.targetpos = data.targetpos
                    inst.sg.statemem.flash = 0
                    if inst.sg.statemem.startingpos.x ~= data.targetpos.x or inst.sg.statemem.startingpos.z ~= data.targetpos.z then
                        inst:ForceFacePoint(data.targetpos:Get())
                        inst.Physics:SetMotorVel(math.sqrt(distsq(inst.sg.statemem.startingpos.x, inst.sg.statemem.startingpos.z, data.targetpos.x, data.targetpos.z)) / (12 * FRAMES), 0 ,0)
                    end
                    return
                end
            end
            --Failed
            inst.sg:GoToState("idle", true)
        end,

        onupdate = function(inst)
            if inst.sg.statemem.flash and inst.sg.statemem.flash > 0 then
                inst.sg.statemem.flash = math.max(0, inst.sg.statemem.flash - .1)
                local c = math.min(1, inst.sg.statemem.flash)
                inst.components.colouradder:PushColour("leap", 0,c,c, 0)
            end
        end,

        timeline =
        {
            TimeEvent(4 * FRAMES, function(inst)
                if inst.sg.statemem.targetfx ~= nil then
                    if inst.sg.statemem.targetfx:IsValid() then
                        OnRemoveCleanupTargetFX(inst)
                    end
                    inst.sg.statemem.targetfx = nil
                end
            end),
            TimeEvent(10 * FRAMES, function(inst)
                inst.components.colouradder:PushColour("leap", 0, .1, .1, 0)
            end),
            TimeEvent(11 * FRAMES, function(inst)
                inst.components.colouradder:PushColour("leap", 0, .2, .2, 0)
            end),
            TimeEvent(12 * FRAMES, function(inst)
                inst.components.colouradder:PushColour("leap", 0, .4, .4, 0)
                ToggleOnPhysics(inst)
                inst.Physics:Stop()
                inst.Physics:SetMotorVel(0, 0, 0)
                inst.Physics:Teleport(inst.sg.statemem.targetpos.x, 0, inst.sg.statemem.targetpos.z)
            end),
            TimeEvent(13 * FRAMES, function(inst)
                ShakeAllCameras(CAMERASHAKE.VERTICAL, .7, .015, .8, inst, 20)
                inst.components.bloomer:PushBloom("leap", "shaders/anim.ksh", -2)
                inst.components.colouradder:PushColour("leap", 0, 1, 1, 0)
                inst.sg.statemem.flash = 1.3
                inst.sg:RemoveStateTag("nointerrupt")
                if inst.sg.statemem.weapon:IsValid() then
                    inst.sg.statemem.weapon.components.aoeweapon_leap:DoLeap(inst, inst.sg.statemem.startingpos, inst.sg.statemem.targetpos)
                end
            end),
            TimeEvent(25 * FRAMES, function(inst)
                inst.components.bloomer:PopBloom("leap")
            end),
        },

        events =
        {
            EventHandler("animover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("idle")
                end
            end),
        },

        onexit = function(inst)
            if inst.sg.statemem.isphysicstoggle then
                ToggleOnPhysics(inst)
                inst.Physics:Stop()
                inst.Physics:SetMotorVel(0, 0, 0)
                local x, y, z = inst.Transform:GetWorldPosition()
                if TheWorld.Map:IsPassableAtPoint(x, 0, z) and not TheWorld.Map:IsGroundTargetBlocked(Vector3(x, 0, z)) then
                    inst.Physics:Teleport(x, 0, z)
                else
                    inst.Physics:Teleport(inst.sg.statemem.targetpos.x, 0, inst.sg.statemem.targetpos.z)
                end
            end
            inst.Transform:SetFourFaced()
            inst.components.bloomer:PopBloom("leap")
            inst.components.colouradder:PopColour("leap")
            if inst.sg.statemem.targetfx ~= nil and inst.sg.statemem.targetfx:IsValid() then
                OnRemoveCleanupTargetFX(inst)
            end
        end,
    }
)

AddStategraphState("wilson_client", 
	State
    {
        name = "icey_combat_leap_start",
        tags = { "doing", "busy", "nointerrupt" },

        onenter = function(inst)
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("atk_leap_pre")
            inst.AnimState:PushAnimation("atk_leap_lag", false)

            inst:PerformPreviewBufferedAction()
            inst.sg:SetTimeout(2)
        end,

        onupdate = function(inst)
            if inst:HasTag("doing") then
                if inst.entity:FlattenMovementPrediction() then
                    inst.sg:GoToState("idle", "noanim")
                end
            elseif inst.bufferedaction == nil then
                inst.sg:GoToState("idle")
            end
        end,

        ontimeout = function(inst)
            inst:ClearBufferedAction()
            inst.sg:GoToState("idle")
        end,
    }
)

AddStategraphState("wilson", 
	State{
        name = "yhorm_shield_prop_pre",
        tags = { "propattack", "doing", "busy", "notalking" },

        onenter = function(inst)
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("atk_prop_pre")

            local buffaction = inst:GetBufferedAction()
            local target = buffaction ~= nil and buffaction.target or nil
            if target ~= nil and target:IsValid() then
                inst:ForceFacePoint(target.Transform:GetWorldPosition())
            end
        end,

        events =
        {
            EventHandler("unequip", function(inst)
                inst.sg:GoToState("idle")
            end),
            EventHandler("animover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("yhorm_shield_prop")
                end
            end),
        },
    }
)

AddStategraphState("wilson_client", 
	State
    {
        name = "yhorm_shield_prop_pre",
        tags = { "propattack", "doing", "busy" },

        onenter = function(inst)
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("atk_prop_pre")
            inst.AnimState:PushAnimation("atk_prop_lag", false)

            inst:PerformPreviewBufferedAction()
            inst.sg:SetTimeout(TIMEOUT)
        end,

        onupdate = function(inst)
            if inst:HasTag("busy") then
                if inst.entity:FlattenMovementPrediction() then
                    inst.sg:GoToState("idle", "noanim")
                end
            elseif inst.bufferedaction == nil then
                inst.sg:GoToState("idle")
            end
        end,

        ontimeout = function(inst)
            inst:ClearBufferedAction()
            inst.sg:GoToState("idle")
        end,
    }
)

AddStategraphState("wilson", 
	State{
        name = "yhorm_shield_prop",
        tags = { "propattack", "doing", "busy", "notalking", "pausepredict" },

        onenter = function(inst)
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("atk_prop")
            inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_whoosh")

            if inst.components.playercontroller ~= nil then
                inst.components.playercontroller:RemotePausePrediction()
            end
        end,

        timeline =
        {
            TimeEvent(FRAMES, function(inst)
                inst:PerformBufferedAction()
                
            end),
            TimeEvent(2 * FRAMES, function(inst)
                if inst.sg.statemem.smashed ~= nil then
                    local smashed = inst.sg.statemem.smashed
                    inst.sg.statemem.smashed = false
                    smashed.prop:PushEvent("propsmashed", smashed.pos)
                end
            end),
            TimeEvent(13 * FRAMES, function(inst)
                inst.sg:GoToState("idle", true)
            end),
        },

        events =
        {
            EventHandler("unequip", function(inst)
                if inst.sg.statemem.smashed == nil then
                    inst.sg:GoToState("idle")
                end
            end),
            EventHandler("animover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("idle")
                end
            end),
        },

        onexit = function(inst)
            if inst.sg.statemem.smashed then --could be false, so don't nil check
                inst.sg.statemem.smashed.prop:PushEvent("propsmashed", inst.sg.statemem.smashed.pos)
            end
        end,
    }
)