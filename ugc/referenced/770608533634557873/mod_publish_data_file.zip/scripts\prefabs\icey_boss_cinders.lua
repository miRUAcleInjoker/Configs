

local JudaGuardBoss = {
	"icey_boarrior",--------��ҵ֮���Ĺ¶�����------������ķ
	"tigershark_duke",------�������ʧ�����------���蹫��
	"dark_antqueen",
	"metal_hulk_merge",-----��ƽ����
}

local assets_merge = {
	Asset("ANIM", "anim/metal_head.zip"),
	Asset("IMAGE","images/inventoryimages/metal_hulk_merge_cinder.tex"),
	Asset("ATLAS","images/inventoryimages/metal_hulk_merge_cinder.xml"),
}

local function MakeCinder(name,scale)
	local prefab_name = name.."_cinder"
	scale = scale or 1 
	local assets ={
		Asset("ANIM", "anim/icey_boss_cinders.zip"),
		Asset("IMAGE","images/inventoryimages/"..prefab_name..".tex"),
		Asset("ATLAS","images/inventoryimages/"..prefab_name..".xml"),
	}
	local function fn()
		local inst = CreateEntity()

		inst.entity:AddTransform()
		inst.entity:AddAnimState()
		inst.entity:AddNetwork()

		MakeInventoryPhysics(inst)

		inst.AnimState:SetBank("icey_boss_cinders")
		inst.AnimState:SetBuild("icey_boss_cinders")
		inst.AnimState:PlayAnimation(name)
		inst.Transform:SetScale(scale,scale,scale)

		inst:AddTag("icey_boss_cinder")
		
		inst.nameoverride = "icey_boss_cinder"
		
		inst.entity:SetPristine()

		if not TheWorld.ismastersim then
			return inst
		end

		inst:AddComponent("inspectable")

		inst:AddComponent("inventoryitem")
		inst.components.inventoryitem.imagename = prefab_name
		inst.components.inventoryitem.atlasname = "images/inventoryimages/"..prefab_name..".xml"

		return inst
	end
	return Prefab(prefab_name,fn,assets)
end

local function MergeHeadFn()
	local inst = CreateEntity()

	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddSoundEmitter()
	inst.entity:AddNetwork()

	MakeInventoryPhysics(inst)

	inst.AnimState:SetBank("metal_head")
    inst.AnimState:SetBuild("metal_head")
    inst.AnimState:PlayAnimation("full")

	inst:AddTag("icey_boss_cinder")
	
	inst.nameoverride = "icey_boss_cinder"

	inst.entity:SetPristine()

	if not TheWorld.ismastersim then
		return inst
	end
	
	inst.DoFall = function(self)
        self.Physics:SetMotorVel(0,-35,0) -- -20+math.random()*10
        self.AnimState:PlayAnimation("idle_fall", true)
		
		self.UpdateTask = self:DoPeriodicTask(0,function()
			local pt = Point(self.Transform:GetWorldPosition())
            if pt.y < 2 then
                self.Physics:SetMotorVel(0,0,0)
            end
            if pt.y <= 0.1 then
                self.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/hulk_metal_robot/explode_small",nil,.25)
                self.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/hulk_metal_robot/head/step")
                pt.y = 0                
                self.Physics:Stop()
                self.Physics:Teleport(pt.x,pt.y,pt.z)     
				self.Transform:SetPosition(pt.x,pt.y,pt.z)         
				self.AnimState:PlayAnimation("separate")
				self.AnimState:PushAnimation("full",true)
                ShakeAllCameras(CAMERASHAKE.FULL, .5, .02, .2, self, 30)
				
				if self.UpdateTask then 
					self.UpdateTask:Cancel()
					self.UpdateTask = nil 
				end 
            end
		end)
	end

	inst:AddComponent("inspectable")

	inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "metal_hulk_merge_cinder"
	inst.components.inventoryitem.atlasname = "images/inventoryimages/metal_hulk_merge_cinder.xml"

	return inst
end

return MakeCinder("icey_boarrior"),
MakeCinder("dark_antqueen",0.8),
MakeCinder("tigershark_duke"),
Prefab("metal_hulk_merge_cinder",MergeHeadFn,assets_merge)
