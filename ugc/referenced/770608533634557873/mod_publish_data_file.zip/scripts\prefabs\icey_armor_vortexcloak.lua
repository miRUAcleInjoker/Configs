local IceyUtil = require("icey_util")

local assets=
{
	Asset("ANIM", "anim/armor_vortex_cloak.zip"),
    Asset("ANIM", "anim/cloak_fx.zip"),
	Asset("ANIM", "anim/vortex_cloak_fx.zip"),
	Asset("ATLAS", "images/inventoryimages/icey_armor_vortexcloak.xml"),
    Asset("IMAGE", "images/inventoryimages/icey_armor_vortexcloak.tex"),
}

--------------------------------------------------------------------
local function UpdateRepel(inst, x, z, creatures,rad)
    for i = #creatures, 1, -1 do
        local v = creatures[i]
        if not (v.inst:IsValid() and v.inst.entity:IsVisible()) then
            table.remove(creatures, i)
        elseif v.speed == nil then
            local distsq = v.inst:GetDistanceSqToPoint(x, 0, z)
            if distsq < rad * rad then
                if distsq > 0 then
                    v.inst:ForceFacePoint(x, 0, z)
                end
                local k = .5 * distsq / (rad * rad) - 1
                v.speed = 25 * k
                v.dspeed = 2
				if v.inst.Physics then 
					v.inst.Physics:SetMotorVelOverride(v.speed, 0, 0)
				end 
            end
        else
            v.speed = v.speed + v.dspeed
            if v.speed < 0 then
                local x1, y1, z1 = v.inst.Transform:GetWorldPosition()
                if x1 ~= x or z1 ~= z then
                    v.inst:ForceFacePoint(x, 0, z)
                end
                v.dspeed = v.dspeed + .25
				if v.inst.Physics then 
					v.inst.Physics:SetMotorVelOverride(v.speed, 0, 0)
				end 
            else
				if v.inst.Physics then 
					v.inst.Physics:ClearMotorVelOverride()
					v.inst.Physics:Stop()
				end 
                table.remove(creatures, i)
            end
        end
    end
end

local function TimeoutRepel(inst, creatures, task)
    task:Cancel()

    for i, v in ipairs(creatures) do
        if v.speed ~= nil and v.inst.Physics ~= nil then
            v.inst.Physics:ClearMotorVelOverride()
            v.inst.Physics:Stop()
        end
    end
end

local function KnockBack(inst,attacker,rad)
	if attacker:IsNear(inst,rad) then 
		local x,y,z = attacker:GetPosition():Get()
		if attacker.components.combat then 
			attacker.components.combat:GetAttacked(inst,math.random(1,10))
		end 
		if attacker:HasTag("player") then 
			attacker:PushEvent("repelled", { repeller = inst, radius = rad })
		else 
			local creatures = {}
			if attacker.Physics then 
				table.insert(creatures,{inst = attacker})
			end 
			if #creatures > 0 then
				inst:DoTaskInTime(10 * FRAMES, TimeoutRepel, creatures,
					inst:DoPeriodicTask(0, UpdateRepel, nil, x, z, creatures,rad)
				)
			end
		end 
	end 
end 
--------------------------------------------------------------------

local function setsoundparam(inst)
    local param = Remap(inst.components.armor.condition, 0, inst.components.armor.maxcondition,0, 1 ) 
    inst.SoundEmitter:SetParameter( "vortex", "intensity", param )
end

local function spawnwisp(owner)
    local wisp = SpawnPrefab("armorvortexcloak_fx")
    local x,y,z = owner.Transform:GetWorldPosition()
    wisp.Transform:SetPosition(x+math.random()*0.25 -0.25/2,y,z+math.random()*0.25 -0.25/2)    
end


local function OnArmorDamaged(inst,damage_amount)
	local owner = inst.components.inventoryitem:GetGrandOwner()
	if owner and owner:IsValid() then 
		if inst.components.armor:GetPercent() > 0 then
			owner:SpawnChild("vortex_cloak_fx")
			local x,y,z = owner:GetPosition():Get()
			local rad = 3
			for k,v in pairs(TheSim:FindEntities(x,y,z,rad,{"_combat"})) do 
				if IceyUtil.CanAttack(v,owner) then 
					KnockBack(owner,v,rad)
				end 
			end 
			ShakeAllCameras(CAMERASHAKE.FULL, .35, .02, 1, owner, 40)
			if owner.components.sanity then 
				owner.components.sanity:DoDelta(-damage_amount/5)
			end
		end        
		--setsoundparam(inst)
		if math.random(1,2) == 1 then 
			inst.SoundEmitter:PlaySound("dontstarve_DLC003/common/crafted/vortex_armour/equip_on")
		else
			inst.SoundEmitter:PlaySound("dontstarve_DLC003/common/crafted/vortex_armour/equip_off")
		end 
	end
end 

local function onequip(inst, owner) 
    owner.AnimState:OverrideSymbol("swap_body", "armor_vortex_cloak", "swap_body")
    owner.SoundEmitter:PlaySound("dontstarve_DLC003/common/crafted/vortex_armour/equip_off")
	inst:ListenForEvent("armordamaged",OnArmorDamaged)
    inst.wisptask = inst:DoPeriodicTask(0.1,function() spawnwisp(owner) end)  
    --inst.SoundEmitter:PlaySound("dontstarve_DLC003/common/crafted/vortex_armour/LP","vortex") 
    setsoundparam(inst)
end

local function onunequip(inst, owner) 
    owner.AnimState:ClearOverrideSymbol("swap_body")
    owner.SoundEmitter:PlaySound("dontstarve_DLC003/common/crafted/vortex_armour/equip_on")
	inst:RemoveEventCallback("armordamaged",OnArmorDamaged)
    if inst.wisptask then
        inst.wisptask:Cancel()
        inst.wisptask= nil
    end
    --inst.SoundEmitter:KillSound("vortex")
	
	inst:DoTaskInTime(0,function()
		inst.components.armor:TakeDamage(99999)
	end) 
end

local function nofuel(inst)

end

local function ontakefuel(inst)
    if inst.components.armor.condition and inst.components.armor.condition < 0 then
        inst.components.armor:SetCondition(0)
    end
    inst.components.armor:SetCondition(inst.components.armor.condition + (inst.components.armor.maxcondition/20))
    
    inst.SoundEmitter:PlaySound("dontstarve_DLC003/common/crafted/vortex_armour/add_fuel")  
end

local function fn()
	local inst = CreateEntity()
    
    inst.entity:AddTransform()
    inst.entity:AddSoundEmitter()
    inst.entity:AddAnimState()
	inst.entity:AddNetwork()  --�������Ҳ����� 
    MakeInventoryPhysics(inst)

    inst:AddTag("vortex_cloak")
	inst:AddTag("CANTUNEQUIP")
    
    inst.AnimState:SetBank("armor_vortex_cloak")
    inst.AnimState:SetBuild("armor_vortex_cloak")
    inst.AnimState:PlayAnimation("anim")
	
	inst.entity:SetPristine()   --���ľ仰 �ŵ����� Ҳ����bank build ��tag֮��ĺ���-��-
	if not TheWorld.ismastersim then
        return inst
    end

        
    inst:AddComponent("inspectable")
    inst:AddComponent("inventoryitem")  
	inst.components.inventoryitem.keepondeath = true  
    inst.components.inventoryitem.foleysound = "dontstarve_DLC003/common/crafted/vortex_armour/foley"
	inst.components.inventoryitem.imagename = "icey_armor_vortexcloak"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/icey_armor_vortexcloak.xml"
	--inst.components.inventoryitem.foleysound = "dontstarve/movement/foley/marblearmour"
	
	--inst:AddComponent("lootdropper")    

    inst:AddComponent("fueled")
    inst.components.fueled.fueltype = FUELTYPE.NIGHTMARE
    inst.components.fueled:InitializeFuelLevel(4 * TUNING.LARGE_FUEL)
    inst.components.fueled:SetTakeFuelFn(ontakefuel) 
    inst.components.fueled.accepting = true
	inst.components.fueled:StopConsuming() 

    inst:AddComponent("armor")
    inst.components.armor:InitCondition(850,1.0)
	inst.components.armor.onfinished = function()
		--inst.components.lootdropper:DropLoot(inst:GetPosition()) 
		SpawnAt("dark_hit_fx_icey",inst:GetPosition()+Vector3(0,0.5,0)).Transform:SetScale(1.5,1.5,1.5)
		SpawnAt("shadow_mixtrues_soul",inst:GetPosition())
	end 
    
    inst:AddComponent("equippable")
    inst.components.equippable.equipslot = EQUIPSLOTS.BODY
    inst.components.equippable:SetOnEquip(onequip)
    inst.components.equippable:SetOnUnequip(onunequip)
    inst.components.equippable.dapperness = TUNING.CRAZINESS_MED 
    
    return inst
end

local function fxfn()
    local inst = CreateEntity()
    
    inst.entity:AddTransform()
    inst.entity:AddSoundEmitter()
    inst.entity:AddAnimState()
	inst.entity:AddNetwork()  --�������Ҳ����� 
	
	
	MakeInventoryPhysics(inst)
    RemovePhysicsColliders(inst)

    inst.AnimState:SetBank("cloakfx")
    inst.AnimState:SetBuild("cloak_fx")
    inst.AnimState:PlayAnimation("idle",true)    

    for i=1,14 do
        inst.AnimState:Hide("fx"..i)
    end
    inst.AnimState:Show("fx"..math.random(1,14))
	
	inst:AddTag("FX")
	
	inst.entity:SetPristine()   --���ľ仰 �ŵ����� Ҳ����bank build ��tag֮��ĺ���-��-
	if not TheWorld.ismastersim then
        return inst
    end

    inst:ListenForEvent("animover",inst.Remove) 

    return inst
end

local function hitfxfn()
	
	local inst = CreateEntity()
    
    inst.entity:AddTransform()
    inst.entity:AddSoundEmitter()
    inst.entity:AddAnimState()
	inst.entity:AddNetwork()  --�������Ҳ����� 

    inst.AnimState:SetBank("vortex_cloak_fx")
    inst.AnimState:SetBuild("vortex_cloak_fx")
    inst.AnimState:PlayAnimation("idle")    
	
	inst.entity:SetPristine()  
	if not TheWorld.ismastersim then
        return inst
    end
	
	inst.SoundEmitter:PlaySound("dontstarve_DLC003/common/crafted/vortex_armour/hit") 
    inst:ListenForEvent("animover",inst.Remove) 

    return inst
end

return Prefab( "icey_armor_vortexcloak", fn, assets),
    Prefab( "armorvortexcloak_fx", fxfn, assets),
	Prefab( "vortex_cloak_fx", hitfxfn, assets)  
