local IceyUtil = require("icey_util")

local DeadCellPassiveFlyHead = Class(function(self, inst)
    self.inst = inst
	
	self.headprefab = "dead_cell_head_marker"
	self.headent = nil  --�ɳ�ȥ��ͷ��ʵ��
	
	self.charging = false --�Ƿ�����ȴ��
	self.current_cd = 0 --��ǰ��ȴ��ʱ
	self.max_cd = 5     --�����ȴʱ��
	
	self.trackedenemy = nil --�ɳ�ȥ��ͷ�ס�ĵ���
	self.current_tracked_time = 0
	self.max_tracked_time = 10
	
	--�ж�һ��Ŀ���ܲ��ܱ��ס
	self.cantractenemytest = function(owner,target)
		return IceyUtil.CanAttack(target,owner)
	end 
	
	--�����˲��ٺϷ�(�����������Ƴ���)ʱ�����ĺ���
	self._onenemyinvalid = function()
		self:StopFlyHead()
	end
	
	--��ͷʱ����ͼ���ͷ��װ��ʱ����
	self._banhatlistenfn = function(owner)
		self:DropHat()
		self:EnableOwnerHead(false)
	end
	
	self._onownerinvalid = function()
		if self.headent then 
			self:StopFlyHead(true)
		end 
	end 
	
	self.is_controling_head = false --�Ƿ��ڿ���ͷ���ж�
	self.is_fying_head = false --�Ƿ��Ѿ��ɳ�ȥ��ͷ
	
	----����4������û�ã��Ժ��ٿ���
	self.on_control_start = nil 
	self.on_control_over = nil 
	self.on_flyhead_start = nil 
	self.on_flyhead_over = nil 
	
	self.inst:ListenForEvent("death",self._onownerinvalid)
	self.inst:ListenForEvent("onremove",self._onownerinvalid)
end)

function DeadCellPassiveFlyHead:HasFlyHeadStone()
	return self.inst.components.inventory:FindItem(function(item)
		return item.prefab == "flyhead_stone"
	end)
end 

--ǿ����ñ����
function DeadCellPassiveFlyHead:DropHat()
	if self.inst.components.inventory then 
		self.inst.components.inventory:DropItem(self.inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HEAD), true, true)
	end 
end 

--�Ƿ�����ͷ��װ��������Ϊ��ͷʱҪ����ͷ��װ������
function DeadCellPassiveFlyHead:EnableHat(enable)
	if not enable then 
		self:DropHat()
		self.inst:ListenForEvent("equip",self._banhatlistenfn)
		self.inst:ListenForEvent("unequip",self._banhatlistenfn)
	else
		self.inst:RemoveEventCallback("equip",self._banhatlistenfn)
		self.inst:RemoveEventCallback("unequip",self._banhatlistenfn)
	end
end 

--��ʼ��ͷ��ȴ����ȴʱ����ʹ�÷�ͷ
function DeadCellPassiveFlyHead:StartCharge()
	self.charging = true
	self.current_cd = self.max_cd
	
	if self.ChargeTask then
		self.ChargeTask:Cancel()
	end 
	self.ChargeTask = nil 
	self.ChargeTask = self.inst:DoPeriodicTask(0,function()
		self.current_cd = self.current_cd - FRAMES
		if self.current_cd <= 0 then 
			self:FinishCharge()
		end
	end)
end 


--������ȴ
function DeadCellPassiveFlyHead:FinishCharge()
	local spark = SpawnPrefab("electrichitsparks")
	spark:AlignToTarget(self.inst,self.inst, true)
	spark.entity:SetParent(self.inst.entity)   
	spark.Transform:SetPosition(0,0.7 + math.random()*0.5 , 0)
	
	self.inst.SoundEmitter:PlaySound("flyhead/flyhead/homunculus_ready")
	
	if self.ChargeTask then
		self.ChargeTask:Cancel()
	end 
	self.ChargeTask = nil 
	
	self.charging = false
	self.current_cd = 0
end 

--�ж��Ƿ�������ȴ
function DeadCellPassiveFlyHead:IsCharging()
	return self.charging
end 

--�ж��Ƿ��ڷ�ͷ
function DeadCellPassiveFlyHead:IsFlyingHead()
	return self.is_fying_head 
end 

--�Ƿ���ʾԭ�������ϵ�ͷ����
function DeadCellPassiveFlyHead:EnableOwnerHead(enable)
	local HeadSymbol = {
		"cheeks",
		"face",
		"hair",
		"hair_hat",
		"hairfront",
		"hairpigtails",
		"headbase",
		"headbase_hat",
	}
	if enable then 
		for k,v in pairs(HeadSymbol) do 
			self.inst.AnimState:ShowSymbol(v)
		end 
	else
		for k,v in pairs(HeadSymbol) do 
			self.inst.AnimState:HideSymbol(v)
		end 
	end
end

--�Ƿ�ʼ���Ʒɳ�ȥ��ͷ
function DeadCellPassiveFlyHead:EnableControlHead(enable)
	if enable then 
		if self.headent and self.headent:IsValid() then 
			self.inst.components.playercontroller.locomotor = self.headent.components.locomotor
		end
	else
		self.inst.components.playercontroller.locomotor = self.inst.components.locomotor
	end 
	self.is_controling_head = enable
end

--���ȥͷ
function DeadCellPassiveFlyHead:StartFlyHead(targetpos)
	if not self:HasFlyHeadStone() then 
		return 
	end 
	if self:IsCharging() then 
		self.inst.SoundEmitter:PlaySound("flyhead/flyhead/intro_slime_move"..math.random(1,3))
		return 
	end 
	if self.headent and self.headent:IsValid() then 
		return 
	else
		self.inst.components.playercontroller:Enable(false)
		local ownerpos = self.inst:GetPosition()
		local ownerroa = self.inst.Transform:GetRotation() * DEGREES
		local rad = 3
		local offset = Vector3(rad*math.cos(ownerroa),0,math.sin(ownerroa))
		
		targetpos = targetpos or ownerpos+offset
		
		self.headent = SpawnAt(self.headprefab,ownerpos)
		--self.headent.head.AnimState:SetBuild(self.inst.prefab)
		
		local fx = self.inst:SpawnChild("blood_hit_fx_icey")
		fx.Transform:SetPosition(0,0,0)
		fx.AnimState:SetMultColour(196/255,0,0,1)
		
		if self.bodyfx and self.bodyfx:IsValid() then
			self.bodyfx:Remove()
		end 
		
		self.bodyfx = SpawnPrefab("metal_hulk_eyeflame")
		self.bodyfx.entity:SetParent(self.inst.entity)
		self.bodyfx.entity:AddFollower()
		self.bodyfx.Follower:FollowSymbol(self.inst.GUID, "torso", 0,-89, 0)
		
		if self.headent.components.complexprojectile then 
			self.headent.components.complexprojectile:SetOnHit(function()
				self.inst.components.playercontroller:Enable(true)
				self:EnableControlHead(true)
				self.headent.SoundEmitter:PlaySound("flyhead/flyhead/intro_slime_land")
			end)
			self.headent.components.complexprojectile:Launch(targetpos, self.inst)
		else
			self.inst.components.playercontroller:Enable(true)
			self:EnableControlHead(true)
		end
		self:EnableOwnerHead(false)
		
		self.inst.SoundEmitter:PlaySound("flyhead/flyhead/homunculus_release")
	end

    self:EnableHat(false)

	self.is_fying_head = true
	
	self.inst:StartUpdatingComponent(self)
end

--�ջ���ͷ
--���instantΪtrue��ͷ��������λ��������ͷ�ɻ����Ķ������䴦��
function DeadCellPassiveFlyHead:StopFlyHead(instant)
	local function handle()
		if self.bodyfx and self.bodyfx:IsValid() then
			self.bodyfx:Remove()
		end 
		self.bodyfx = nil 
		self:EnableOwnerHead(true)
		self:EnableControlHead(false)
		self.headent.components.inventory:TransferInventory(self.inst)
		self.headent.components.inventory:DropEverything()
			
		SpawnAt("pod_projectile_hitfx",self.inst:GetPosition()+Vector3(0,1,0))
		local spark = SpawnPrefab("electrichitsparks")
		spark:AlignToTarget(self.inst,self.inst, true)
		spark.entity:SetParent(self.inst.entity)   
		spark.Transform:SetPosition(0,0.7 + math.random()*0.5 , 0)
			
		self.headent:Remove()
		self.headent = nil
	end 
	
	self.inst:StopUpdatingComponent(self)
	
	if self.headent and self.headent:IsValid() then 
		
		
		if self.trackedenemy then
			self:StopTrack()
		end 
		
		
		
		if instant then 
			local ownerpos = self.inst:GetPosition()
			local headoffset = Vector3(0,1,0)
			self.headent.Transform:SetPosition((ownerpos + headoffset):Get())
			handle()
		else
			local time_to_back = 0.3
			local tick_time = TheSim:GetTickTime()
			
			self.inst:StartThread(function()
				local ticks = 0
				
				while ticks * tick_time < time_to_back do
					local ownerpos = self.inst:GetPosition()
					local headpos =  self.headent:GetPosition()
					local headoffset = Vector3(0,1,0)
					local percent = ticks * tick_time / time_to_back
					local delta = (ownerpos + headoffset - headpos) * percent
					
					self.headent.Transform:SetPosition((headpos + delta):Get())
					
					ticks = ticks + 1
					Yield()
				end
				handle()
			end)
		end 
	end
	
	self:EnableHat(true)
	self.inst.components.playercontroller:Enable(true)
	self.inst.SoundEmitter:PlaySound("flyhead/flyhead/homunculus_comeback")
	self.is_fying_head = false
end

--�Ƿ������ĳ������Ϊ���Ŀ��
function DeadCellPassiveFlyHead:CanTractEnemy(target)
	return self.trackedenemy == nil 
		and target ~= self.inst 
		and self.cantractenemytest and self.cantractenemytest(self.inst,target) 
end 

--�סĿ��
function DeadCellPassiveFlyHead:TractEnemy(target)
	self.trackedenemy = target
	self.headent.entity:SetParent(target.entity)
	self.headent.Transform:SetPosition(0,0.5,0)
	self.inst:ClearBufferedAction()
	self.headent:ClearBufferedAction()
	
	if self.headent.components.complexprojectile then
		self.headent.components.complexprojectile:Hit()
	end 
	self:EnableControlHead(false)
	self.headent.components.locomotor:SetExternalSpeedMultiplier(self.headent,"tracked",0)
	self.headent.components.locomotor:Stop()
	self.headent.Physics:Stop()

	--[[local function ResetHead()
		if self.trackedenemy then 
			self.headent.Transform:SetPosition(0,0.5,0)
			self.headent.components.locomotor:Stop()
			self.headent.Physics:Stop()
		end 
	end 
	
	self.headent:DoTaskInTime(0,ResetHead)
	self.headent:DoTaskInTime(0.1,ResetHead)
	self.headent:DoTaskInTime(0.25,ResetHead)--]]
	
	self.inst:ListenForEvent("onremove",self._onenemyinvalid,target)
	self.inst:ListenForEvent("death",self._onenemyinvalid,target)
	
	self.TractEnemyAndAttackTask = self.headent:DoPeriodicTask(0.25,function()
		self.current_tracked_time = self.current_tracked_time + 0.25 + FRAMES
		if self.current_tracked_time >= self.max_tracked_time then 
			self:StopFlyHead()
			return 
		end 
		
		if target.components.combat and not (target.components.health and target.components.health:IsDead()) then
			target.components.combat:GetAttacked(self.inst,math.random(5,12))
			if not target:HasTag("spider") then 
				self.headent.SoundEmitter:PlaySound("dontstarve/creatures/spider/hit_response")
			end 
			local fx = SpawnAt("impact",target:GetPosition())
			fx.Transform:SetRotation(math.random() * 360)
			local scale = 1.2 + math.random() * 0.3
			fx.Transform:SetScale(scale,scale,scale)
		end
	end) 
end 

--ֹͣ�סĿ��
function DeadCellPassiveFlyHead:StopTrack()
	local x,y,z = self.headent.Transform:GetWorldPosition()
	self.headent.entity:SetParent(nil)
	self.headent.Transform:SetPosition(x,y,z)
	self.headent.components.locomotor:RemoveExternalSpeedMultiplier(self.headent,"tracked")
	if self.TractEnemyAndAttackTask then 
		self.TractEnemyAndAttackTask:Cancel()
		self.TractEnemyAndAttackTask = nil 
	end
	
	self.current_tracked_time = 0
	
	if self.trackedenemy then 
		if not (self.trackedenemy.components.health and self.trackedenemy.components.health:IsDead()) then
			self:StartCharge()
		end 
		self.inst:RemoveEventCallback("onremove",self._onenemyinvalid,self.trackedenemy)
		self.inst:RemoveEventCallback("death",self._onenemyinvalid,self.trackedenemy)
	end 
	
	self.trackedenemy = nil 
end 

--���º���
function DeadCellPassiveFlyHead:OnUpdate(dt)
	if self.headent and self.headent:IsValid() then 
		
		
		if not self.trackedenemy then 
			-------��ͷû���ס���˵�ʱ�򣬿����Զ����ߵ��ϵ���Ʒ
			local item_onground = FindEntity(
				self.headent,
				1.5,
				function(guy)
					return guy.components.inventoryitem 
						and guy.components.inventoryitem.canbepickedup 
						and guy.components.inventoryitem.cangoincontainer
						and not guy.components.inventoryitem:IsHeld()
						and self.headent.components.inventory:CanAcceptCount(guy) > 0 
				end,
				{ "_inventoryitem" }, 
				{ "INLIMBO", "NOCLICK", "knockbackdelayinteraction", "catchable", "fire", "minesprung", "mineactive" }
			)
			
			if item_onground then 
				SpawnPrefab("sand_puff").Transform:SetPosition(item_onground.Transform:GetWorldPosition())
				self.headent.components.inventory:GiveItem(item_onground)
			end
			
			-------��ͷû���ס���˵�ʱ�򣬿����ס����
			local enemy = FindEntity(
				self.headent,
				1.5,
				function(guy)
					return  self:CanTractEnemy(guy)
				end,
				{"_combat"},
				{"FX", "NOCLICK","INLIMBO"}
			)
			
			if enemy then 
				self:TractEnemy(enemy)
			end
			
		end 
	end
end

return DeadCellPassiveFlyHead