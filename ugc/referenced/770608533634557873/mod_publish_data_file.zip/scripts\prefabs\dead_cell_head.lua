local TadalinUtil = require("tadalin_util")

local assets =
{

        Asset( "ANIM", "anim/player_basic.zip" ),
        Asset( "ANIM", "anim/player_idles_shiver.zip" ),
        Asset( "ANIM", "anim/player_actions.zip" ),
        Asset( "ANIM", "anim/player_actions_axe.zip" ),
        Asset( "ANIM", "anim/player_actions_pickaxe.zip" ),
        Asset( "ANIM", "anim/player_actions_shovel.zip" ),
        Asset( "ANIM", "anim/player_actions_blowdart.zip" ),
        Asset( "ANIM", "anim/player_actions_eat.zip" ),
        Asset( "ANIM", "anim/player_actions_item.zip" ),
        Asset( "ANIM", "anim/player_actions_uniqueitem.zip" ),
        Asset( "ANIM", "anim/player_actions_bugnet.zip" ),
        Asset( "ANIM", "anim/player_actions_fishing.zip" ),
        Asset( "ANIM", "anim/player_actions_boomerang.zip" ),
        Asset( "ANIM", "anim/player_bush_hat.zip" ),
        Asset( "ANIM", "anim/player_attacks.zip" ),
        Asset( "ANIM", "anim/player_idles.zip" ),
        Asset( "ANIM", "anim/player_rebirth.zip" ),
        Asset( "ANIM", "anim/player_jump.zip" ),
        Asset( "ANIM", "anim/player_amulet_resurrect.zip" ),
        Asset( "ANIM", "anim/player_teleport.zip" ),
        Asset( "ANIM", "anim/wilson_fx.zip" ),
        Asset( "ANIM", "anim/player_one_man_band.zip" ),
        Asset( "ANIM", "anim/shadow_hands.zip" ),
        Asset( "SOUND", "sound/sfx.fsb" ),
        Asset( "SOUND", "sound/wilson.fsb" ),
        Asset( "ANIM", "anim/beard.zip" ),

        Asset( "ANIM", "anim/icey.zip" ),
        Asset( "ANIM", "anim/ghost_icey_build.zip" ),
		
		
		Asset("SOUNDPACKAGE", "sound/flyhead.fev"),-------���ư�boss��BGM
		Asset("SOUND", "sound/flyhead.fsb"),
}

local HideSymbols = {
	"arm_lower",
	"arm_upper",
	"arm_upper_skin",
	"foot",
	"hand",
	"leg",
	"skirt",
	"SWAP_ICON",
	"tail",
	"torso",
	"torso_pelvis",

}

local function animfn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    --inst.entity:AddDynamicShadow()
    inst.entity:AddNetwork()

    --inst.DynamicShadow:SetSize(1.5, .75)
    inst.Transform:SetFourFaced()

    inst.AnimState:SetBank("wilson") 
	inst.AnimState:SetBuild("icey")
    inst.AnimState:PlayAnimation("idle_loop",true)
	
    inst.AnimState:Hide("ARM_carry")
    inst.AnimState:Hide("HAT")
    inst.AnimState:Hide("HAIR_HAT")
    inst.AnimState:Show("HAIR_NOHAT")
    inst.AnimState:Show("HAIR")
    inst.AnimState:Show("HEAD")
    inst.AnimState:Hide("HEAD_HAT")
	
	for k,v in pairs(HideSymbols) do 
		inst.AnimState:HideSymbol(v)
	end 
	
	inst.AnimState:SetSortOrder(3)
	
	--inst.AnimState:SetSortWorldOffset(0,-10,0)
	--inst.AnimState:SetFloatParams(0,-0.5,0)
	
	--[[inst.AnimState:AddOverrideBuild("player_lunge")
    inst.AnimState:AddOverrideBuild("player_attack_leap")
    inst.AnimState:AddOverrideBuild("player_superjump")
    inst.AnimState:AddOverrideBuild("player_multithrust")
    inst.AnimState:AddOverrideBuild("player_parryblock")--]]
	
	inst:AddTag("NO_TIME_STOP")


    inst.entity:SetPristine()
	

    if not TheWorld.ismastersim then
        return inst
    end

	inst:AddComponent("colouradder")

	
   
    inst:AddComponent("bloomer")


    
	
	--inst:SetStateGraph("SGdead_cell_head")
	
	inst.persists = false 

    return inst
end

local function onlaunch(inst)
	local self = inst.components.complexprojectile
	local targetpos = self.targetpos
	inst:ForceFacePoint(targetpos:Get())
	inst.head.Transform:SetRotation(inst.Transform:GetRotation())
	self.velocity = Vector3(25,8,0)
end 

local function onupdatefn(inst)
	local self = inst.components.complexprojectile
	local targetpos = self.targetpos
	local dt = FRAMES
	
	self.inst.Physics:SetMotorVel(self.velocity:Get())
    self.velocity.y = self.velocity.y + (self.gravity * dt)
    if self.velocity.y < 0 then
        local x, y, z = self.inst.Transform:GetWorldPosition()
        if y <= 0.05 then -- a tiny bit above the ground, to account for collision issues
            self:Hit()
        end
    end
end

local function fakeentfn()
	local inst = CreateEntity()

    inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddDynamicShadow()
	inst.entity:AddSoundEmitter()
	
	inst.DynamicShadow:SetSize(1.5, .75)
	
	MakeInventoryPhysics(inst)
	
	inst:AddTag("icey_others")
	inst:AddTag("NO_TIME_STOP")
	inst:AddTag("NO_ICEY_SWIMMER_JUMP")
	
	TadalinUtil.MakeSwimableCreature(inst,"med",1,Vector3(0.45, 1.0,0.5))

    inst.entity:SetPristine()
	

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.head = inst:SpawnChild("dead_cell_head")
	inst.head.Transform:SetPosition(0,-0.75,0)
	
	inst:AddComponent("combat")
	
	inst:AddComponent("inventory")
	inst.components.inventory.maxslots = 1
	
	inst:AddComponent("complexprojectile")
	--inst.components.complexprojectile:SetHorizontalSpeed(25)
	local old_Launch = inst.components.complexprojectile.Launch
	inst.components.complexprojectile.Launch = function(self,targetpos,...)
		self.targetpos = targetpos
		return old_Launch(self,targetpos,...)
	end
    inst.components.complexprojectile:SetGravity(-45)
	inst.components.complexprojectile:SetOnLaunch(onlaunch)
    inst.components.complexprojectile:SetLaunchOffset(Vector3(.15, 1.2, 0))
	inst.components.complexprojectile.onupdatefn = onupdatefn
	
	inst:AddComponent("locomotor") -- locomotor must be constructed before the stategraph
    inst.components.locomotor.runspeed = 5
    inst.components.locomotor.walkspeed = 7
	
	inst:SetStateGraph("SGdead_cell_head")
	
	inst.persists = false 
	
	return inst
end

return Prefab("dead_cell_head", animfn, assets),
Prefab("dead_cell_head_marker", fakeentfn, assets)
