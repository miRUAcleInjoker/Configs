local IceyUtil = require("icey_util")

local function OnRemoveCleanupTargetFX(inst)
    if inst.sg.statemem.targetfx.KillFX ~= nil then
        inst.sg.statemem.targetfx:RemoveEventCallback("onremove", OnRemoveCleanupTargetFX, inst)
        inst.sg.statemem.targetfx:KillFX()
    else
        inst.sg.statemem.targetfx:Remove()
    end
end

local function Explode(inst,rad,damage)
	local x,y,z = inst.Transform:GetWorldPosition() 
	local fx = SpawnAt("laser_ring",inst:GetPosition())
	fx:AddTag("NO_TIME_STOP")
	fx.Transform:SetScale(1.5,1.5,1.5)
	fx:MakeBlue() 
	local ents = TheSim:FindEntities(x,y,z,rad,{"_combat"})
	local attack_ents = {}
	for k,v in pairs(ents) do 
		if IceyUtil.CanAttack(v,inst) then 
			table.insert(attack_ents,v)
		end
	end
	
	for k,v in pairs(attack_ents) do 
		if IceyUtil.CanAttack(v,inst) then 
			v.components.combat:GetAttacked(inst,damage / (#attack_ents + 1) + damage*math.random()*0.2 )
		end
	end
	
	local explode = SpawnAt("positronpulse",inst:GetPosition()-Vector3(0,1,0))
	explode.Transform:SetScale(1.5,1.5,1.5)
	explode.AnimState:SetMultColour(16/255, 213/255, 220/255,1)
	explode:FinishFX()
	
	inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/enemy/metal_robot/smash")
	ShakeAllCameras(CAMERASHAKE.FULL, .35, .02, 1, inst, 40)
end 

AddStategraphState("wilson", 
	State{
        name = "icey_skill_soul_torrent",
        tags = { "doing", "busy", "canrotate","nopredict","icey_skill_soul_torrent"},

        onenter = function(inst,soulnum)
            if inst.components.playercontroller ~= nil then
                inst.components.playercontroller:Enable(false)
            end
            inst.AnimState:PlayAnimation("staff_pre")
            inst.AnimState:PushAnimation("staff", false)
            inst.components.locomotor:Stop()

            --Spawn an effect on the player's location
            local staff = inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
            local colour = staff ~= nil and staff.fxcolour or { 1, 1, 1 }

            inst.sg.statemem.stafffx = SpawnPrefab(inst.components.rider:IsRiding() and "staffcastfx_mount" or "staffcastfx")
            inst.sg.statemem.stafffx.entity:SetParent(inst.entity)
            inst.sg.statemem.stafffx.Transform:SetRotation(inst.Transform:GetRotation())
            inst.sg.statemem.stafffx:SetUp(colour)

            inst.sg.statemem.stafflight = SpawnPrefab("staff_castinglight")
            inst.sg.statemem.stafflight.Transform:SetPosition(inst.Transform:GetWorldPosition())
            inst.sg.statemem.stafflight:SetUp(colour, 1.9, .33)
			
			inst.sg.statemem.soulnum = soulnum

            if staff ~= nil and staff.components.aoetargeting ~= nil and staff.components.aoetargeting.targetprefab ~= nil then
                local buffaction = inst:GetBufferedAction()
                if buffaction ~= nil and buffaction.pos ~= nil then
                    inst.sg.statemem.targetfx = SpawnPrefab(staff.components.aoetargeting.targetprefab)
                    if inst.sg.statemem.targetfx ~= nil then
                        inst.sg.statemem.targetfx.Transform:SetPosition(buffaction.pos:Get())
                        inst.sg.statemem.targetfx:ListenForEvent("onremove", OnRemoveCleanupTargetFX, inst)
                    end
                end
            end

            inst.sg.statemem.castsound = staff ~= nil and staff.castsound or "dontstarve/wilson/use_gemstaff"
        end,

        timeline =
        {
            TimeEvent(13 * FRAMES, function(inst)
                inst.SoundEmitter:PlaySound(inst.sg.statemem.castsound)
            end),
			TimeEvent(45 * FRAMES, function(inst)
				Explode(inst,12.5,inst.sg.statemem.soulnum * 40)
            end),
            TimeEvent(53 * FRAMES, function(inst)
                if inst.sg.statemem.targetfx ~= nil then
                    if inst.sg.statemem.targetfx:IsValid() then
                        OnRemoveCleanupTargetFX(inst)
                    end
                    inst.sg.statemem.targetfx = nil
                end
                inst.sg.statemem.stafffx = nil --Can't be cancelled anymore
                inst.sg.statemem.stafflight = nil --Can't be cancelled anymore
                --V2C: NOTE! if we're teleporting ourself, we may be forced to exit state here!
            end),
        },

        events =
        {
            EventHandler("animqueueover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("idle")
                end
            end),
        },

        onexit = function(inst)
			inst.sg.statemem.soulnum = nil 
            if inst.components.playercontroller ~= nil then
                inst.components.playercontroller:Enable(true)
            end
            if inst.sg.statemem.stafffx ~= nil and inst.sg.statemem.stafffx:IsValid() then
                inst.sg.statemem.stafffx:Remove()
            end
            if inst.sg.statemem.stafflight ~= nil and inst.sg.statemem.stafflight:IsValid() then
                inst.sg.statemem.stafflight:Remove()
            end
            if inst.sg.statemem.targetfx ~= nil and inst.sg.statemem.targetfx:IsValid() then
                OnRemoveCleanupTargetFX(inst)
            end
        end,
    }
)

AddStategraphState("wilson_client", 
    State
    {
        name = "icey_skill_soul_torrent",
        tags = { "doing", "busy", "canrotate","icey_skill_soul_torrent" },

        onenter = function(inst)
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("staff_pre")
            inst.AnimState:PushAnimation("staff_lag", false)

            inst:PerformPreviewBufferedAction()
            inst.sg:SetTimeout(TIMEOUT)
        end,

        onupdate = function(inst)
            if inst:HasTag("doing") then
                if inst.entity:FlattenMovementPrediction() then
                    inst.sg:GoToState("idle", "noanim")
                end
            elseif inst.bufferedaction == nil then
                inst.sg:GoToState("idle")
            end
        end,

        ontimeout = function(inst)
            inst:ClearBufferedAction()
            inst.sg:GoToState("idle")
        end,
    }
)

AddStategraphState("wilson", 
	State
    {
        name = "icey_miss",
        tags = {"busy", "evade","no_stun","nopredict"},

        onenter = function(inst,targetpos)
            inst.components.locomotor:Stop()
			if not (inst.components.rider and inst.components.rider:IsRiding()) then 
				inst.AnimState:PlayAnimation("atk_leap_lag")
			end 
			
			inst:ForceFacePoint(targetpos:Get())
			inst.AnimState:SetMultColour(17/255,29/255,184/255,0.3)
			inst.Physics:SetMotorVelOverride(40,0,0)
			
            inst.components.locomotor:EnableGroundSpeedMultiplier(false)
            inst.components.health:SetInvincible(true)
			
			if inst.components.iceysneaker:IsSneaking() then 
				inst.components.iceysneaker:StopSneak()
			end 
			
			inst.SoundEmitter:PlaySound("dontstarve/common/staff_blink")
			
			inst.sg:SetTimeout(0.2) -- 0.15
        end,
		
		timeline =
        {
            TimeEvent(0.1, function(inst)
                inst.components.health:SetInvincible(false)
            end),
		},

        ontimeout = function(inst)
            inst.sg:GoToState("idle")
        end,

        onexit = function(inst)
            inst.components.locomotor:EnableGroundSpeedMultiplier(true)
            inst.Physics:ClearMotorVelOverride()
            inst.components.locomotor:Stop()
			inst.components.health:SetInvincible(false)
        end,        
    }
)

AddStategraphState("wilson_client", 
	State
    {
        name = "icey_miss",
        tags = {"busy", "evade","no_stun","nopredict"},

        onenter = function(inst,targetpos)
			if not (inst.replica.rider and inst.replica.rider:IsRiding()) then 
				inst.AnimState:PlayAnimation("atk_leap_lag")
			end 
			inst:ForceFacePoint(targetpos:Get())
			inst.SoundEmitter:PlaySound("dontstarve/common/staff_blink")
			inst.sg:SetTimeout(0.2) -- 0.15
        end,
		
        ontimeout = function(inst)
            inst.sg:GoToState("idle")
        end,   
    }
)