
local assets = {
	Asset("ANIM", "anim/quagmire_park_fence.zip"),--------建筑的贴图文件
	--Asset("ANIM", "anim/quagmire_park_gate.zip"),
	Asset("IMAGE","images/inventoryimages/icey_park_fence_tall.tex"),
	Asset("ATLAS","images/inventoryimages/icey_park_fence_tall.xml"),
	Asset("IMAGE","images/inventoryimages/icey_park_fence_short.tex"),
	Asset("ATLAS","images/inventoryimages/icey_park_fence_short.xml")
}

-----------------------------------------------------------------------------------------------------------------------

local function onhammered_crusher(inst, worker)
    inst.components.lootdropper:DropLoot()
    local fx = SpawnPrefab("collapse_small")
    fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
    fx:SetMaterial("metal")
    inst:Remove()
end

local function onhit_crusher(inst, worker)
	
end

local function dozap_crusher(inst)
	local x,y,z = inst.Transform:GetWorldPosition()
    if inst.zaptask ~= nil then
        inst.zaptask:Cancel()
    end

    inst.SoundEmitter:PlaySound("dontstarve/common/lightningrod")
	local fx = SpawnPrefab("lightning_rod_fx")
	if inst:HasTag("short_fence") then 
		fx.Transform:SetPosition(x,y,z)
		fx.Transform:SetScale(0.7,0.5,0.7)
	else
		fx.Transform:SetPosition(x,y,z)
		fx.Transform:SetScale(0.8,0.8,0.8)
	end 
	--fx.Transform:SetAddColour(161/255,26/255,13/255,1)

    inst.zaptask = inst:DoTaskInTime(math.random(35, 250), dozap_crusher)
end

local function discharge_crusher(inst)
	if inst.zaptask ~= nil then
        inst.zaptask:Cancel()
        inst.zaptask = nil
    end
end 

local function OnAttacked(inst,data)
	if data ~= nil and data.attacker ~= nil then 
		local attacker = data.attacker
		if inst.IsOn  then 
			if attacker:HasTag("player") then 
				attacker.sg:GoToState("electrocute")
			end
			if attacker.components.health and not attacker.components.health:IsDead() then 
				local fx = SpawnPrefab("shock_fx")
				fx.entity:SetParent(attacker.entity)
				attacker.components.combat:GetAttacked(inst,((inst:HasTag("short_fence") and 8) or 15))
			end
			inst:PushEvent("powertrans",{former = inst,power = -10})
		end 
		if data.weapon ~= nil and data.weapon.components.weapon ~= nil and data.weapon.components.weapon.stimuli == "electric" then
            inst:PushEvent("powertrans",{former = inst,power = 50})
        end
	end
end 


local function turnon(inst)
	dozap_crusher(inst)
	if inst.blz_hit_task == nil then 
		inst.blz_hit_task = inst:DoPeriodicTask(3+math.random()*5,function()
			local x,y,z = inst:GetPosition():Get()
			local ents = TheSim:FindEntities(x,y,z,1.5,{"_combat"},{"INLIMBO","icey_power_building","wall","door"})
			if #ents >0 then 
				dozap_crusher(inst)
			end 
			for k,v in pairs(ents) do 
				if v.components.health and not v.components.health:IsDead() and 
				not (v.components.inventory and v.components.inventory:GetEquippedItem(EQUIPSLOTS.HEAD) and v.components.inventory:GetEquippedItem(EQUIPSLOTS.HEAD).prefab == "eyebrellahat")then 
					local fx = SpawnPrefab("shock_fx")
					fx.entity:SetParent(v.entity)
					v.components.combat:GetAttacked(inst,((inst:HasTag("short_fence") and 3) or 5))
					if v:HasTag("player") then 
						v.sg:GoToState("electrocute")
					end
				end
				inst:PushEvent("powertrans",{former = inst,power = -10})
			end
		end)
	end
	
	inst.Light:Enable(true)
end 

local function turnoff(inst)
	discharge_crusher(inst)
	if inst.blz_hit_task ~= nil then 
		inst.blz_hit_task:Cancel()
		inst.blz_hit_task = nil 
	end
	inst.Light:Enable(false)
end 

local function CheckPower(inst,data)
	local power = data.power
	inst.building_power = inst.building_power + power
	inst.building_power = math.max(0,inst.building_power)
	inst.building_power = math.min(inst.max_building_power,inst.building_power)
	if inst.building_power > 0 and not inst.IsOn then 
		print(inst,"Turn on!")
        turnon(inst)
		inst.IsOn = true
    elseif inst.building_power <= 0 and inst.IsOn then
		print(inst,"Turn off!")
        turnoff(inst)
		inst.IsOn = false
    end 
end 

local function onbuilt(inst)
	inst.SoundEmitter:PlaySound("dontstarve/sanity/shadowrock_up")
	inst.built_task_scale = 0.3
	inst.built_task = inst:DoPeriodicTask(0,function()
		inst.Transform:SetScale(inst.built_task_scale,inst.built_task_scale,inst.built_task_scale)
		inst.built_task_scale = inst.built_task_scale + 0.05
		if inst.built_task_scale >= 1 then 
			if inst.built_task then 
				inst.built_task_scale = nil 
				inst.Transform:SetScale(1,1,1)
				inst.built_task:Cancel()
				inst.built_task = nil 
			end
		end
	end)
end 

local function OnSave_crusher(inst,data)
	data.building_power = inst.building_power
	--data.IsOn = inst.IsOn
end 

local function OnLoad_crusher(inst,data)
	if data then 
		if data.building_power then 
			inst.building_power = data.building_power
		end
		--[[if data.IsOn then 
			inst.IsOn = data.IsOn
		end--]]
		CheckPower(inst,{fromer = inst,power = 0})
	end
end 

local function common(bank,build,anim,tags)
	 local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()
	inst.entity:AddLight()

	MakeObstaclePhysics(inst, .5)
	
    inst.AnimState:SetBank("quagmire_park_fence")
    inst.AnimState:SetBuild("quagmire_park_fence")
    inst.AnimState:PlayAnimation(anim) ----------喜闻乐见的动画设置
	
	
	inst.Light:Enable(false)
    inst.Light:SetRadius(0.5)
    inst.Light:SetFalloff(1)
    inst.Light:SetIntensity(.5)
    inst.Light:SetColour(161/255,26/255,13/255)
		
	inst:AddTag("icey_power_use")
	inst:AddTag("icey_power_building")
	inst:AddTag("wall")
	inst:AddTag("alignwall")
    inst:AddTag("noauradamage")
    inst:AddTag("nointerpolate")
	--inst:AddTag("prey")
	inst:AddTag("companion")
	--inst:AddTag("smallcreature")
	
	if tags then 
		for k,v in pairs(tags) do 
			inst:AddTag(v)
		end
	end 

    inst.entity:SetPristine()
	
	
    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.IsOn = false
	inst.building_power = 0
	inst.max_building_power = 500

    inst:AddComponent("inspectable")
	inst.components.inspectable.descriptionfn = function(inst,doer)
		return (inst.IsOn and "安全用电" ) or "它需要充电了!"
	end
	
	
	inst:AddComponent("lootdropper")
	
	inst:AddComponent("health")
	inst.components.health:SetMaxHealth(250)
	
	inst:AddComponent("combat")
	inst.components.combat.hurtsound = "dontstarve/common/place_structure_stone"
	
	inst:AddComponent("workable")
    inst.components.workable:SetWorkAction(ACTIONS.HAMMER)
    inst.components.workable:SetWorkLeft(3)
	inst.components.workable:SetOnFinishCallback(onhammered_crusher)
    inst.components.workable:SetOnWorkCallback(onhit_crusher)
	
    MakeHauntableWork(inst)--------------被作祟时的函数，这里是空的
    MakeSnowCovered(inst)--------------建筑物积雪时的函数，这里是空的
	
	inst.OnLoad = OnLoad_crusher
	inst.OnSave = OnSave_crusher
	
	inst:DoPeriodicTask(1,function()
		inst:PushEvent("powertrans",{former = inst,power = -10})
		if inst.building_power > 10 and inst.components.health:IsHurt() then 
			inst:PushEvent("powertrans",{former = inst,power = -10})
			inst.components.health:DoDelta((inst:HasTag("short_fence") and 4) or 8)
		end
	end)
	inst:ListenForEvent("powertrans",CheckPower)
	inst:ListenForEvent("attacked",OnAttacked)
	inst:ListenForEvent("death",onhammered_crusher)
    return inst
end


local function common_itemfn(bank,build,anim,depoyname,inv_names)
	 local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()
	
	inst.AnimState:SetBank(bank)
    inst.AnimState:SetBuild(build)
    inst.AnimState:PlayAnimation(anim) ----------喜闻乐见的动画设置
	
	inst.Transform:SetScale(0.3,0.3,0.3)

	inst:AddTag("wallbuilder")
	
	local function ondeploywall(inst,pt)
	local wall = SpawnPrefab(depoyname) 
	print("On deploy:",wall)
        if wall ~= nil then 
			local x = math.floor(pt.x) + .5
            local z = math.floor(pt.z) + .5
			wall.Physics:SetCollides(false)
			wall.Physics:Teleport(x,0,z)
			wall.Physics:SetCollides(true)
			inst.components.stackable:Get():Remove()
        end
	end 

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("口袋里的栅栏~")
	
	inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = inv_names
    inst.components.inventoryitem.atlasname = "images/inventoryimages/"..inv_names..".xml"
	
	inst:AddComponent("stackable")
	inst.components.stackable.maxsize = TUNING.STACK_SIZE_MEDITEM
	
	inst:AddComponent("deployable")
    inst.components.deployable.ondeploy = ondeploywall
	inst.components.deployable:SetDeployMode(DEPLOYMODE.WALL)
	--inst.components.deployable:SetDeploySpacing(DEPLOYSPACING.NONE)
	inst.components.deployable:SetDeploySpacing(DEPLOYSPACING.LESS)
	--inst.components.deployable:SetDeployMode(DEPLOYMODE.PLANT)
	--inst.components.deployable:SetDeploySpacing(DEPLOYSPACING.MEDIUM)
	
    MakeHauntableWork(inst)--------------被作祟时的函数，这里是空的
    return inst
end

local function tallfn()
	local inst = common("quagmire_park_fence","quagmire_park_fence","idle")
	return inst 
end 

local function shortfn()
	local inst = common("quagmire_park_fence","quagmire_park_fence","idle_short",{"short_fence"})
	return inst 
end

local function tallfn_item()
	local inst = common_itemfn("quagmire_park_fence","quagmire_park_fence","idle","icey_park_fence_tall","icey_park_fence_tall")
	return inst 
end 

local function shortfn_item()
	local inst = common_itemfn("quagmire_park_fence","quagmire_park_fence","idle_short","icey_park_fence_short","icey_park_fence_short")
	return inst 
end

--[[local function doorfn()
	local inst = common("quagmire_park_gate","quagmire_park_gate","idle",{"door"})
	return inst 
end--]]

return Prefab("icey_park_fence_tall", tallfn, assets),
Prefab("icey_park_fence_tall_item", tallfn_item, assets),
MakePlacer("icey_park_fence_tall_item_placer", "quagmire_park_fence", "quagmire_park_fence", "idle"),

Prefab("icey_park_fence_short", shortfn, assets),
Prefab("icey_park_fence_short_item", shortfn_item, assets),
MakePlacer("icey_park_fence_short_item_placer", "quagmire_park_fence", "quagmire_park_fence", "idle_short")