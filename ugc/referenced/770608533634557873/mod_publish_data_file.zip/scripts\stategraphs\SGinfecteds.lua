require("stategraphs/commonstates")

local function DoFoleySounds(inst)

	for k,v in pairs(inst.components.inventory.equipslots) do
		if v.components.inventoryitem and v.components.inventoryitem.foleysound then
			inst.SoundEmitter:PlaySound(v.components.inventoryitem.foleysound)
		end
	end

end

local function SpawnBloodFx(inst,symbol)
	local fx = SpawnPrefab("blood_hit_fx_icey")
	local x,y,z = inst:GetPosition():Get()
	fx.Transform:SetPosition(x,y,z)
	fx.AnimState:SetMultColour(196/255,0,0,1)
	fx.Transform:SetScale(0.5,0.5,0.5)
end 

local actionhandlers = 
{
	ActionHandler(ACTIONS.EAT, "eat"),
}

   
local events=
{
	CommonHandlers.OnLocomote(true, false),

    EventHandler("attacked", function(inst, data)
		--inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/idle")
		local fx = SpawnPrefab("blood_hit_fx_icey")
		local x,y,z = inst:GetPosition():Get()
		local scale = (data.damage >= 40 and 0.8 or 0.5) + math.random()/10
		fx.Transform:SetScale(0.5,0.5,0.5)
		fx.Transform:SetPosition(x+math.random(-1,1)/10,y+math.random(-3,0)/10,z+math.random(-1,1)/10)
		inst.sg:GoToState("hit")
	end),

    EventHandler("doattack", function(inst)
        if not inst.components.health:IsDead() then
			inst.sg:GoToState("attack")
        end
    end),
    
    EventHandler("death", function(inst)
		print("Preper to go to death sg")
		inst.sg:GoToState("death")
    end),
}

local states= 
{
	
	State{
        name = "infected",
        tags = {"busy"},
        
        onenter = function(inst)
            inst.components.locomotor:Stop()
			print("In infected SG")
			inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/grunt")
            --inst.AnimState:Hide("swap_arm_carry")
            inst.AnimState:PlayAnimation("transform_merm")
			--inst.AnimState:PushAnimation("idle_merm")
            --inst.components.lootdropper:DropLoot(Vector3(inst.Transform:GetWorldPosition()))  
			
        end,
		timeline=
        {
            TimeEvent(1, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/grunt")
				SpawnBloodFx(inst)
            end),
			
			TimeEvent(1.8, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/grunt")
				SpawnBloodFx(inst)
            end),
			
			TimeEvent(3.2, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/grunt")
				SpawnBloodFx(inst)
            end),
			
			TimeEvent(4.9, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/grunt")
				SpawnBloodFx(inst)
            end),
			
			TimeEvent(7.8, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/grunt")
				SpawnBloodFx(inst)
            end),
			
			TimeEvent(9.5, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/grunt")
				SpawnBloodFx(inst)
            end),
        },        
        
        events=
        {
            EventHandler("animover", function(inst) inst.components.lootdropper:DropLoot(Vector3(inst.Transform:GetWorldPosition())) end),
        },
        
        onexit= function(inst)
            
        end,
    },

	

    State{
        name = "death",
        tags = {"busy","death"},
        
        onenter = function(inst)
            inst.components.locomotor:Stop()
			print("In Death SG")
			inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/grunt")
            inst.AnimState:Hide("swap_arm_carry")
			if math.random(1,100) >= 50 then 
				inst.AnimState:PlayAnimation("transform_merm")
			else
				inst.AnimState:PlayAnimation("death")
			end 
            
			
        end,  
		timeline=
        {
            TimeEvent(12*FRAMES, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/grunt")
            end),
			TimeEvent(40*FRAMES, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/grunt")
            end),
        },    
		events=
        {
            EventHandler("animover", function(inst) inst.components.lootdropper:DropLoot(Vector3(inst.Transform:GetWorldPosition())) end),
        },
        
        onexit= function(inst)
            
        end,         
    },

    State{
        name = "idle",
        tags = {"idle", "canrotate"},
        onenter = function(inst, pushanim)     
            inst.components.locomotor:Stop()
			inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/idle")
            local anims = {"idle_groggy_pre","idle_groggy"}                            
            if pushanim then
                for k,v in pairs (anims) do
					inst.AnimState:PushAnimation(v, k == #anims)
				end
            else
                inst.AnimState:PlayAnimation(anims[1], #anims == 1)
                for k,v in pairs (anims) do
					if k > 1 then
						inst.AnimState:PushAnimation(v, k == #anims)
					end
				end
            end  
            inst.sg:SetTimeout(math.random()*4+2)
        end,
    },

    State{
        name = "eat",
        tags ={"busy"},
        onenter = function(inst)
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("quick_eat")
        end,

        timeline=
        {
            TimeEvent(12*FRAMES, function(inst) 
                inst:PerformBufferedAction() 
                inst.sg:RemoveStateTag("busy")
            end),
        },        
        
        events=
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end),
        },
        
        onexit= function(inst)
            inst.SoundEmitter:KillSound("eating")    
        end,
    },    
	
------------------------------------------------------------------------------------------------------------------------------------------------------
    State{
        name = "attack",
        tags = {"attack", "notalking", "abouttoattack", "busy"},
        
        onenter = function(inst)
			local equip = inst.components.combat:GetWeapon()
			inst.sg.statemem.target = inst.components.combat.target
			print(inst.sg.statemem.target)
            inst.components.combat:StartAttack()
            
			inst.components.locomotor:Stop()
		
			if equip ~= nil and equip:HasTag("whip") then
                inst.AnimState:PlayAnimation("whip_pre")
                inst.AnimState:PushAnimation("whip", false)
                inst.sg.statemem.iswhip = true
                inst.SoundEmitter:PlaySound("dontstarve/common/whip_pre", nil, nil, true)
                --cooldown = math.max(cooldown, 17 * FRAMES)
            elseif equip ~= nil and equip:HasTag("book") then
                inst.AnimState:PlayAnimation("attack_book")
                inst.sg.statemem.isbook = true
                inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_whoosh", nil, nil, true)
                --cooldown = math.max(cooldown, 19 * FRAMES)
            elseif equip ~= nil and equip:HasTag("chop_attack") and inst:HasTag("woodcutter") then
                inst.AnimState:PlayAnimation(inst.AnimState:IsCurrentAnimation("woodie_chop_loop") and inst.AnimState:GetCurrentAnimationTime() < 7.1 * FRAMES and "woodie_chop_atk_pre" or "woodie_chop_pre")
                inst.AnimState:PushAnimation("woodie_chop_loop", false)
                inst.sg.statemem.ischop = true
                --cooldown = math.max(cooldown, 11 * FRAMES)
            elseif equip ~= nil and equip.components.weapon ~= nil and not equip:HasTag("punch") then
                inst.AnimState:PlayAnimation("atk_pre")
                inst.AnimState:PushAnimation("atk", false)
                if (equip.projectiledelay or 0) > 0 then
                    --V2C: Projectiles don't show in the initial delayed frames so that
                    --     when they do appear, they're already in front of the player.
                    --     Start the attack early to keep animation in sync.
                    inst.sg.statemem.projectiledelay = 8 * FRAMES - equip.projectiledelay
                    if inst.sg.statemem.projectiledelay > FRAMES then
                        inst.sg.statemem.projectilesound =
                            (equip:HasTag("icestaff") and "dontstarve/wilson/attack_icestaff") or
                            (equip:HasTag("firestaff") and "dontstarve/wilson/attack_firestaff") or
                            "dontstarve/wilson/attack_weapon"
                    elseif inst.sg.statemem.projectiledelay <= 0 then
                        inst.sg.statemem.projectiledelay = nil
                    end
                end
                if inst.sg.statemem.projectilesound == nil then
                    inst.SoundEmitter:PlaySound(
                        (equip:HasTag("icestaff") and "dontstarve/wilson/attack_icestaff") or
                        (equip:HasTag("shadow") and "dontstarve/wilson/attack_nightsword") or
                        (equip:HasTag("firestaff") and "dontstarve/wilson/attack_firestaff") or
                        "dontstarve/wilson/attack_weapon",
                        nil, nil, true
                    )
                end
                --cooldown = math.max(cooldown, 13 * FRAMES)
            elseif equip ~= nil and (equip:HasTag("light") or equip:HasTag("nopunch")) then
                inst.AnimState:PlayAnimation("atk_pre")
                inst.AnimState:PushAnimation("atk", false)
                inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon", nil, nil, true)
               -- cooldown = math.max(cooldown, 13 * FRAMES)
            elseif inst:HasTag("beaver") then
                inst.sg.statemem.isbeaver = true
                inst.AnimState:PlayAnimation("atk_pre")
                inst.AnimState:PushAnimation("atk", false)
                inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_whoosh", nil, nil, true)
                --cooldown = math.max(cooldown, 13 * FRAMES)
            else
                inst.AnimState:PlayAnimation("punch")
                inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_whoosh", nil, nil, true)
                --cooldown = math.max(cooldown, 24 * FRAMES)
            end
			
        end,
		
        timeline=
        {	
            TimeEvent(8*FRAMES, function(inst) 
				inst.components.combat:DoAttack(inst.sg.statemem.target) 
				inst.sg:RemoveStateTag("abouttoattack") 
			end),
            TimeEvent(9*FRAMES, function(inst) 
				inst.sg:RemoveStateTag("busy")
				inst.sg:RemoveStateTag("attack")
			end),				
        },
        
        events=
        {
           EventHandler("animqueueover", function(inst)
                inst.sg:GoToState("idle")
            end),
        },
    },       
   
    State{
        name = "run_start",
        tags = {"moving", "running", "canrotate"},
        
        onenter = function(inst)
			inst.components.locomotor:RunForward()
            inst.AnimState:PlayAnimation("idle_walk_pre")
            inst.sg.mem.foosteps = 0
        end,

        onupdate = function(inst)
            inst.components.locomotor:RunForward()
        end,

        events=
        {   
            EventHandler("animover", function(inst) inst.sg:GoToState("run") end ),        
        },
        
        timeline=
        {
        
            TimeEvent(4*FRAMES, function(inst)
                PlayFootstep(inst)
                DoFoleySounds(inst)
            end),
        },        
        
    },

    State{
        
        name = "run",
        tags = {"moving", "running", "canrotate"},
        
        onenter = function(inst) 
            inst.components.locomotor:RunForward()
            inst.AnimState:PlayAnimation("idle_walk")
        end,
        
        onupdate = function(inst)
            inst.components.locomotor:RunForward()
        end,

        timeline=
        {
            TimeEvent(7*FRAMES, function(inst)
				inst.sg.mem.foosteps = inst.sg.mem.foosteps + 1
                PlayFootstep(inst, inst.sg.mem.foosteps < 5 and 1 or .6)
                DoFoleySounds(inst)
            end),
            TimeEvent(15*FRAMES, function(inst)
				inst.sg.mem.foosteps = inst.sg.mem.foosteps + 1
                PlayFootstep(inst, inst.sg.mem.foosteps < 5 and 1 or .6)
                DoFoleySounds(inst)
            end),
        },
        
        events=
        {   
            EventHandler("animover", function(inst) inst.sg:GoToState("run") end ),        
        },
        
        
    },
    
    State{
        name = "run_stop",
        tags = {"canrotate", "idle"},
        
        onenter = function(inst) 
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("idle_walk_pst")
        end,
        
        events=
        {   
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end ),        
        },       
    },    
	
	State{
        name = "hit",
        tags = { "busy", "pausepredict" },

        onenter = function(inst, frozen)
            inst.components.locomotor:Stop()
            inst:ClearBufferedAction()

            inst.AnimState:PlayAnimation("hit")

            if frozen == "noimpactsound" then
                frozen = nil
            else
                inst.SoundEmitter:PlaySound("dontstarve/wilson/hit")
            end
			inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/hurt")
			
            local stun_frames = frozen and 10 or 6
            inst.sg:SetTimeout(stun_frames * FRAMES)
        end,

        ontimeout = function(inst)
			if inst.components.health:IsDead() then 
				inst.sg:GoToState("death")
			else
				inst.sg:GoToState("idle")
			end 
        end,
    },
}

    
return StateGraph("SGinfecteds", states, events, "idle", actionhandlers)

