

local IceyUtil = require("icey_util")
local assets =
{
    Asset("ANIM", "anim/skulls.zip"),
	Asset("IMAGE","images/inventoryimages/insanity_skull_wilson.tex"),
	Asset("ATLAS","images/inventoryimages/insanity_skull_wilson.xml"),
}

local function OnEquip(inst, owner)
    --owner.AnimState:OverrideSymbol("swap_body", "torso_amulets", "purpleamulet")
    if inst.components.fueled then
        inst.components.fueled:StartConsuming()
    end
    if owner.components.sanity ~= nil then
        owner.components.sanity:SetInducedInsanity(inst, true)
    end
end

local function OnUnequip(inst, owner)
    --owner.AnimState:ClearOverrideSymbol("swap_body")
    if inst.components.fueled then
        inst.components.fueled:StopConsuming()
    end
    if owner.components.sanity ~= nil then
        owner.components.sanity:SetInducedInsanity(inst, false)
    end
end

local function MakeSkull(charactername,animname)
	local function fn()
		local inst = CreateEntity()

		inst.entity:AddTransform()
		inst.entity:AddAnimState()
		inst.entity:AddNetwork()
		
		MakeInventoryPhysics(inst)

		inst.AnimState:SetBank("skulls")
		inst.AnimState:SetBuild("skulls")
		inst.AnimState:PlayAnimation(animname)
		
		inst.nameoverride = "insanity_skull"
		
		inst.entity:SetPristine()	
		if not TheWorld.ismastersim then
			return inst
		end	  

		inst:AddComponent("inspectable")

		inst:AddComponent("inventoryitem")
		inst.components.inventoryitem.imagename = "insanity_skull_"..charactername
		inst.components.inventoryitem.atlasname = "images/inventoryimages/insanity_skull_"..charactername..".xml"
		
		inst:AddComponent("equippable")
		inst.components.equippable.equipslot = EQUIPSLOTS.NECK or EQUIPSLOTS.BODY
		inst.components.equippable:SetOnEquip(OnEquip)
		inst.components.equippable:SetOnUnequip(OnUnequip)

		MakeHauntableLaunch(inst)
		return inst
	end
	return Prefab("insanity_skull_"..charactername, fn,assets)
end 

return MakeSkull("wilson","f1")





