local assets = {
	Asset("ANIM", "anim/waxwell_moon_giaour2.zip"),
}

local brain = require"brains/moon_giaour_minionbrain"

local function OnDeath(inst,data)
	--inst:AddTag("attacked")
	if not inst:HasTag("alreaddead") then 
		print("moon_giaour_minion DEAD!")
		local moonbase = FindEntity(inst, 10000, function(base) return base.prefab == "moonbase" end)
		if moonbase and moonbase:IsValid() and moonbase.components.moon_giaour_spawner then 
			moonbase.components.moon_giaour_spawner:DoDelta(1)
		end
		inst:AddTag("alreaddead")
	end
end 

local function RemeberMoonBase(inst)
	local moonbase = FindEntity(inst, 100, function(base) return base.prefab == "moonbase" end)
	if moonbase and moonbase:IsValid() then 
		inst.components.knownlocations:RememberLocation("moonbase",moonbase:GetPosition())
	end
end 

local function DoEmote(inst)
	if not inst.components.health:IsDead() then 
		inst.sg:GoToState("emote")
	end 
end 

local function fn()
	 local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddDynamicShadow()
    inst.entity:AddNetwork()

    MakeCharacterPhysics(inst, 1, .3)

    inst.DynamicShadow:SetSize(1.5, .75)
    inst.Transform:SetFourFaced()

    inst.AnimState:SetBank("wilson")
    inst.AnimState:SetBuild("waxwell_moon_giaour2")
    inst.AnimState:PlayAnimation("idle")
	
	--inst.AnimState:OverrideSymbol("swap_object", "swap_fireballstaff", "swap_fireballstaff")
	--inst.AnimState:OverrideSymbol("swap_hat", "hat_eyecirclet", "swap_hat")
	--inst.AnimState:OverrideSymbol("swap_body", "armor_hprecharger", "swap_body")
    inst.AnimState:Hide("ARM_carry")
    inst.AnimState:Show("ARM_normal")

    inst:AddTag("hostile")
    inst:AddTag("character")
    inst:AddTag("tadalin")
	

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	

    inst:AddComponent("locomotor") -- locomotor must be constructed before the stategraph
    inst.components.locomotor.walkspeed = 4
    inst.components.locomotor.runspeed = 6

    inst:AddComponent("health")
    inst.components.health:SetMaxHealth(75)

    inst:AddComponent("combat")
	
	inst:AddComponent("inventory")

    inst:AddComponent("lootdropper")
    inst.components.lootdropper:SetLoot({})

    inst:AddComponent("knownlocations")
	--inst.components.knownlocations:RememberLocation("moonbase",)
	
    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("这些异教徒必须被铲除!")
	
	inst:SetStateGraph("SGmoon_giaour")
    inst:SetBrain(brain)
	
	--RemeberMoonBase(inst)
	inst:ListenForEvent("death",OnDeath)
	inst:DoPeriodicTask(8 + math.random()*5,DoEmote)
	
	return inst 
end


return Prefab("moon_giaour_minion", fn, assets)