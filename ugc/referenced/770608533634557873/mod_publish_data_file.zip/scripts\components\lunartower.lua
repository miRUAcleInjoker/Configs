local function OnWake(inst)
	local self = inst.components.lunartower
	self:StartSpawnMinion()
end 

local function OnSleep(inst)
	local self = inst.components.lunartower
	self:StopSpawnMinion()
end 

local function OnDeath(inst)
	local self = inst.components.lunartower
	self:Death()
end 

local function NoHoles(pt)
    return not TheWorld.Map:IsPointNearHole(pt)
end

local tower_anounces = {
	[3] = "你失去了理智.....",
	[2] = "你被剧烈的疼痛所压垮.....",
	[1] = "超凡脱俗的声音在你耳边回响.....",
	[0] = "机械末日即将到来......",
}

local LunarTower = Class(function(self,inst)

	self.inst = inst
	self.maxshield = 10000
	self.shield = self.maxshield
	
	self.fxname = ""
	self.bossname = ""
	self.minionname = {}
	
	self.miniontag = ""
	
	self.hasboss = false 
	
	self.inst:AddTag("lunartower")
	if self.inst.components.health then 
		self.inst.components.health:SetInvincible(true)
	end
	
	--self:StartUpDate()
	self.inst:ListenForEvent("entitywake",OnWake)
	self.inst:ListenForEvent("entitysleep",OnSleep)
	self.inst:ListenForEvent("death",OnDeath)
end)

function LunarTower:Init(fxname,bossname,minionname,miniontag)
	self.fxname = fxname or ""
	self.bossname = bossname or ""
	self.minionname = minionname or {}
	self.miniontag = miniontag or ""
end 

function LunarTower:CanSpawnMinion()
	local x,y,z = self.inst:GetPosition():Get()
	local minions = TheSim:FindEntities(x,y,z,50,{self.miniontag})
	
	return #minions < 10
end 

function LunarTower:ClearLoots(minion)
	if minion and minion:IsValid() and minion.components.lootdropper then 
		local him = minion.components.lootdropper
		him.numrandomloot = nil
		him.randomloot = nil
		him.chancerandomloot = nil
		him.totalrandomweight = nil
		him.chanceloot = nil
		him.ifnotchanceloot = nil
		him.droppingchanceloot = false
		him.loot = nil
		him.chanceloottable = nil
		him.lootfn = nil
		him.flingtargetpos = nil
		him.flingtargetvariance = nil
	end
end 

function LunarTower:SpawnBoss()
	local pos = self.inst:GetPosition()
	local offset = FindWalkableOffset(pos, math.random() * PI * 2, 2 +math.random()*5 + self.inst:GetPhysicsRadius(0), 8, false, true, NoHoles)
	if not offset then 
		return 
	end
	local boss = SpawnPrefab(self.bossname)
	if boss then 
		boss.persists = false
		boss.Transform:SetPosition((pos+offset):Get())
		boss:AddTag(self.miniontag)
		boss:ListenForEvent("death",function()
			self:ShieldDoDelta(-self.maxshield)
			self.inst.components.health:DoDelta(-9999)
		end)
		self.hasboss = true 
	end 
end 

function LunarTower:SpawnMinion()
	if not self:CanSpawnMinion() then 
		return
	end 
	local pos = self.inst:GetPosition()
	local offset = FindWalkableOffset(pos, math.random() * PI * 2, 2 +math.random()*5 + self.inst:GetPhysicsRadius(0), 8, false, true, NoHoles)
	if not offset then 
		return 
	end
	local minion = SpawnPrefab(self.minionname[math.random(1,#self.minionname)])
	if minion then 
		local fx = SpawnPrefab(self.fxname)
		minion.persists = false
		minion.Transform:SetPosition((pos+offset):Get())
		minion:AddTag(self.miniontag)
		self:ClearLoots(minion)
		minion:ListenForEvent("death",function()
			self:ShieldDoDelta(-minion.components.health.maxhealth)
			--self.inst.components.health:DoDelta(-9999)
		end)
		if fx then 
			fx.Transform:SetPosition((pos+offset):Get())
		end
	end 
end 

function LunarTower:StartSpawnMinion()
	self:StopSpawnMinion()
	self.inst.LunarSpawnMinionTask = inst:DoPeriodicTask(3,function()
		self:SpawnMinion()
	end)
end 

function LunarTower:StopSpawnMinion()
	if self.inst.LunarSpawnMinionTask then 
		self.inst.LunarSpawnMinionTask:Cancel()
	end
	self.inst.LunarSpawnMinionTask = nil 
end 

function LunarTower:IsShield()
	return self.shield > 0 
end 

function LunarTower:OnShieldDestroy()
	local str = (STRINGS.NAMES[string.upper(self.inst.prefab)] or "一座时计塔").."的护盾被击破了...."
	TheNet:Announce(str)
end 

function LunarTower:ShieldDoDelta(delta)
	local old = self:IsShield()
	self.shield = self.shield + delta
	self.shield = math.max(0,self.shield)
	self.shield = math.min(self.maxshield,self.shield)
	if self.shield <= 0 and self.inst.components.health then 
		self.inst.components.health:SetInvincible(false)
	end
	local new = self:IsShield()
	if old and not new then 
		self:OnShieldDestroy()
	end
end

function LunarTower:KillMinions()
	local minions = TheSim:FindEntities(x,y,z,10000,{self.miniontag})
	for k,v in pairs(towers) do 
		if v and v:IsValid() and v.components.health and not v.components.health:IsDead() then 
			self:ClearLoots(v)
			v.components.health:Kill()
		end
	end
end 

function LunarTower:Death()
	self:StopSpawnMinion()
	self:KillMinions()
	local towers = TheSim:FindEntities(x,y,z,100000,{"lunartower"})
	local count = 0
	for k,v in pairs(towers) do 
		if not v == self.inst then 
			count = count + 1
		end
	end
	local str = tower_anounces[count] or "......."
	TheNet:Announce(str)
end





return LunarTower