local assets =
{
    --Asset("ANIM", "anim/frog.zip"),
    --Asset("SOUND", "sound/frog.fsb"),
	Asset("ANIM", "anim/waxwell_moon_giaour.zip"),
	Asset("ANIM", "anim/waxwell_moon_giaour2.zip"),
	
	Asset("ANIM", "anim/fireballstaff.zip"),
    Asset("ANIM", "anim/swap_fireballstaff.zip"),
	
	Asset("ANIM", "anim/healingstaff.zip"),
    Asset("ANIM", "anim/swap_healingstaff.zip"),
	
	Asset("ANIM", "anim/armor_hprecharger.zip"),
	Asset("ANIM", "anim/hat_eyecirclet.zip"),
	
	Asset("ANIM", "anim/book_fossil.zip"),
    Asset("ANIM", "anim/swap_book_fossil.zip"),
	
	Asset("ANIM", "anim/book_elemental.zip"),
    Asset("ANIM", "anim/swap_book_elemental.zip"),
	
}

local brain = require "brains/moon_giaourbrain"

local function PushMusic(inst)
    if ThePlayer == nil then
        inst._playingmusic = false
    elseif ThePlayer:IsNear(inst, inst._playingmusic and 40 or 20) then
		--print(inst,ThePlayer,"Push the triggeredevent at",GetTime())
        inst._playingmusic = true
        ThePlayer:PushEvent("triggeredevent", { name = "moon_giaour" ,duration = 3})
    elseif inst._playingmusic and not ThePlayer:IsNear(inst, 50) then
        inst._playingmusic = false
    end
end

local function retargetfn(inst)
    if not inst.components.health:IsDead()  then
        return FindEntity(inst, 30, function(guy) 
			if (guy.components.sleeper or guy.components.grogginess) and FindEntity(guy,4.1,nil,{"healingcircle"}) then 
				return false 
			end 
            if not guy.components.health:IsDead() then
                return true 
            end
        end,
        {"_combat","_health"}, -- see entityreplica.lua,
		{"tadalin","monster","bird","prey","structure"}
        )
    end
end

local function keeptargetfn(inst,target)
	if (target.components.sleeper or target.components.grogginess) and FindEntity(target,4.1,nil,{"healingcircle"}) then 
		return false 
	end 
end 

local function ShouldSleep(inst)
    return false -- frogs either go to their home, or just sit on the ground.
end

local function OnAttacked(inst, data)
    inst.components.combat:SetTarget(data.attacker)
    inst.components.combat:ShareTarget(data.attacker, 30, function(dude) 
		return dude:HasTag("tadalin") and dude.components.health and not dude.components.health:IsDead() 
	end, 5)
end

local function SpawnShadowsAttack(attacker,target)
	if target and target:IsValid() and attacker and attacker:IsValid() then 
		local damage = math.random(10,20)
			
		local fulldamage = damage * math.random(7,12)
		local newnums = math.random(4,6)
		local newdamage = fulldamage / newnums
		local roa_little = math.random()*2*math.pi
			
		local sleeptime = math.min(0.1,0.4/newnums)
		local rad = 4.5
		attacker:StartThread(function()
			for roa = roa_little,2*math.pi + roa_little,2*math.pi/newnums  do
				local pos = target:GetPosition()
				local offset = Vector3(math.cos(roa)*rad,0,math.sin(roa)*rad)
				local shadow = SpawnPrefab("icey_shadow3")
				shadow:SetFx("statue_transition_2",{0,0,0,0.7})
				shadow:SetPosition(pos,offset)
				shadow:SetDamage(newdamage)
				shadow:SetTarget(target)
				shadow:Init(attacker,"waxwell",true,nil,true)
				--shadow.components.colouradder:PushColour("charge2", 0,0,0,1)
				local nx,nv,nz = (pos+offset):Get()
				--print("multhit! roa =",roa,"nx,ny,nz =",nx,nv,nz)
				Sleep(sleeptime)
			end
		end)
	end
end 


local function OnHitOther(inst,data)
	local target = data.target
	local damage = data.damage
	inst.damage_sum = inst.damage_sum + damage
	print("OnHitOther!",inst.damage_sum)
	if inst.damage_sum >= 400 then 
		SpawnShadowsAttack(inst,target)
		inst.damage_sum = 0
	end
end

local function EquipHealthStaff(inst)
	if inst.components.inventory   then
		local now_weapon = inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
		if now_weapon then 
			now_weapon:Remove()
		end
        local weapon = CreateEntity()
        --[[Non-networked entity]]
        weapon.entity:AddTransform()
        weapon:AddComponent("weapon")
        weapon.components.weapon:SetDamage(2)
        weapon.components.weapon:SetRange(10, 20)
        weapon.components.weapon:SetProjectile("blossom_projectile")
        weapon:AddComponent("inventoryitem")
        weapon.persists = false
        weapon.components.inventoryitem:SetOnDroppedFn(weapon.Remove)
        weapon:AddComponent("equippable")
        
        inst.components.inventory:Equip(weapon)
		inst.AnimState:OverrideSymbol("swap_object", "swap_healingstaff", "swap_healingstaff")
		
		inst.attacksound = "dontstarve/common/lava_arena/heal_staff"
		return weapon
    end
end 

local function EquipFireStaff(inst)
    if inst.components.inventory then
		local now_weapon = inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
		if now_weapon then 
			now_weapon:Remove()
		end
        local weapon = CreateEntity()
        --[[Non-networked entity]]
        weapon.entity:AddTransform()
        weapon:AddComponent("weapon")
        weapon.components.weapon:SetDamage(5)
        weapon.components.weapon:SetRange(10, 20)
        weapon.components.weapon:SetProjectile("fireball_projectile")
        weapon:AddComponent("inventoryitem")
        weapon.persists = false
        weapon.components.inventoryitem:SetOnDroppedFn(weapon.Remove)
        weapon:AddComponent("equippable")
        
        inst.components.inventory:Equip(weapon)
		inst.AnimState:OverrideSymbol("swap_object", "swap_fireballstaff", "swap_fireballstaff")
		
		inst.attacksound = "dontstarve/wilson/attack_firestaff"
		return weapon
    end
end

local function GetSuitableAttackWeapon(inst)
	local percent = inst.components.health:GetPercent()
	local weapon = percent <= 0.65 and inst:EquipFireStaff() or inst:EquipHealthStaff()
	inst.Weapon = weapon
	return weapon
end 

local function ShoudlRunAway(inst)
	if not inst.RunAwayTarget or not inst.RunAwayTarget:IsValid() then 
		inst.RunAwayTarget = nil 
	end 
	if not inst.components.health:IsDead()  then
		if inst.components.combat.target and inst.components.combat:InCooldown()  then
			return true
		end 
		local x,y,z = inst:GetPosition():Get()
		local ents = TheSim:FindEntities(x,y,z,20,{"_combat","_health"})
		for k,guy in pairs(ents) do 
			if guy and guy:IsValid() and inst and inst:IsValid() and not guy.components.health:IsDead() and 
			guy.sg and guy.sg:HasStateTag("attack") and 
			guy.components.combat and guy.components.combat:TargetIs(inst) and  
			(math.min(guy.components.combat.hitrange + 5,8) ) >= math.sqrt(inst:GetDistanceSqToInst(guy)) 
			then
				inst.RunAwayTarget = guy
                return true 
            end
		end
    end
	return false
end 

local function onskilluse(inst,data)
	local skillname = data.name
	local skillcd = data.cd
	inst[skillname] = false 
	
	inst.components.timer:StartTimer(skillname,skillcd)
end 

local function ontimerdone(inst,data)
	local skillname = data.name
	inst[skillname] = true 
end 



local function EnterPhase2Trigger(inst) -------寮€濮嬩娇鐢ㄥザ鏉?
	if inst.phaselevel <= 1 then 
		inst.skill_flowers = true 
		inst.phaselevel = 2
	end 
	inst.components.combat:SetAttackPeriod(1)
end 

local function EnterPhase3Trigger(inst) -------寮€濮嬪彫鍞ゅ湴鐙辩伀
	if inst.phaselevel <= 2 then
		inst.skill_fireball = true 
		inst.phaselevel = 3
	end 
	inst.components.combat:SetAttackPeriod(0.5)
end 

local function EnterPhase4Trigger(inst) -------寮€濮嬪彫鍞ゅ個鍎?
	if inst.phaselevel <= 3 then 
		inst.skill_fireman = true 
		inst.phaselevel = 4
	end 
	inst.components.combat:SetAttackPeriod(0)
end 

local function OnGiaourDeath(inst)
    local ground = TheWorld
    local centers = {}
    for i, node in ipairs(ground.topology.nodes) do
        if ground.Map:IsPassableAtPoint(node.x, 0, node.y) then
            table.insert(centers, Vector3(node.x,0,node.y))
        end
    end
	
	local boss_giant = FindEntity(inst, 10000, function(ent) return ent.prefab == "icey_boarrior" end)
	local boss_hulk = FindEntity(inst, 10000, function(ent) return ent.prefab == "metal_hulk_merge" end)
	local boss_shadow = FindEntity(inst, 10000, function(ent) return ent.prefab == "dark_antqueen" end)
	local boss_shark = FindEntity(inst, 10000, function(ent) return ent.prefab == "tigershark_duke" end)
	
	local pos1,pos2,pos3,pos4 
	
	pos1 = centers[math.random(#centers)]
	print("成功找到好的pos1",pos1)
	
	for k,v in pairs(centers) do 
		if not pos2 and pos1:Dist(v) >= 500 then 
			pos2 = v 
			print("成功找到好的pos2",pos2)
		end
		
		if not pos3 and pos2 and pos1:Dist(v) >= 500 and pos2:Dist(v) >= 500 then
			pos3 = v 
			print("成功找到好的pos3",pos3)
		end
		
		if not pos4 and pos2 and pos3 and pos1:Dist(v) >= 500 and pos2:Dist(v) >= 500 and pos3:Dist(v) >= 500 then
			pos4 = v 
			print("成功找到好的pos4",pos4)
		end
	end 
	
	pos2 = pos2 or centers[math.random(#centers)]
	pos3 = pos3 or centers[math.random(#centers)]
	pos4 = pos4 or centers[math.random(#centers)]
	
	if not (boss_giant and boss_giant:IsValid()) then 
		SpawnAt("icey_boarrior",pos1)
		if not TheWorld.components.iceybossworld:IsDefeated("icey_boarrior") then 
			local offset1 = FindWalkableOffset(pos1, 2 * PI * math.random(),7+math.random()*5, 2, true, true) or Vector3(0,0,0)
			SpawnAt("skeleton",pos1+offset1)
			local offset2 = FindWalkableOffset(pos1+offset1, 2 * PI * math.random(),3, 2, true, true) or Vector3(0,0,0)
			SpawnAt("storm_controlor",pos1+offset1+offset2)
			local offset3 = FindWalkableOffset(pos1+offset1+offset2, 2 * PI * math.random(),1, 1, true, true) or Vector3(0,0,0)
			local tip = SpawnAt("expostulations",pos1+offset1+offset2+offset3)
			tip.components.writeable:SetText(math.random() <= 0.5 and "只有风暴才能击倒大树。" or "想要打败巨人，必须持有风暴剑。")
		end 
		---TheNet:Announce("")
	end 
	
	if not (boss_hulk and boss_hulk:IsValid()) then 
		SpawnAt("metal_hulk_merge",pos2)
	end 
	
	if not (boss_shadow and boss_shadow:IsValid()) then 
		SpawnAt("dark_antqueen",pos3)
	end 
	
	if not (boss_shark and boss_shark:IsValid()) then 
		SpawnAt("tigershark_duke",pos4)
	end 
end 

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddDynamicShadow()
    inst.entity:AddNetwork()

    MakeCharacterPhysics(inst, 1, .3)

    inst.DynamicShadow:SetSize(1.5, .75)
    inst.Transform:SetFourFaced()

    inst.AnimState:SetBank("wilson")
    inst.AnimState:SetBuild("waxwell_moon_giaour")
    inst.AnimState:PlayAnimation("idle")
	
	--inst.AnimState:OverrideSymbol("swap_object", "swap_fireballstaff", "swap_fireballstaff")
	inst.AnimState:OverrideSymbol("swap_hat", "hat_eyecirclet", "swap_hat")
	inst.AnimState:OverrideSymbol("swap_body", "armor_hprecharger", "swap_body")
    inst.AnimState:Show("ARM_carry")
    inst.AnimState:Hide("ARM_normal")

    inst:AddTag("noepicmusic")
    inst:AddTag("epic")
    inst:AddTag("hostile")
    inst:AddTag("character")
    inst:AddTag("tadalin")
	
	inst._playingmusic = false
	if not TheNet:IsDedicated() then
        inst:DoPeriodicTask(1, PushMusic,0)
    end

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.damage_sum = 300
	
	inst.phaselevel = 1
	
	inst.skill_ice = true
	inst.skill_fireman = false 
	inst.skill_fireball = false
	inst.skill_flowers = false

    inst:AddComponent("locomotor") -- locomotor must be constructed before the stategraph
    inst.components.locomotor.walkspeed = 4
    inst.components.locomotor.runspeed = 6
	inst.components.locomotor:SetExternalSpeedMultiplier(inst,"magic_hat",1.1)

    inst:SetStateGraph("SGmoon_giaour")

    inst:SetBrain(brain)

    inst:AddComponent("health")
    inst.components.health:SetMaxHealth(2000)
	inst.components.health:SetAbsorptionAmount(0.8)

    inst:AddComponent("combat")
    inst.components.combat:SetDefaultDamage(14)
    inst.components.combat:SetAttackPeriod(1.5)
	--inst.components.combat:SetRange(6, 6)
    inst.components.combat:SetRetargetFunction(1, retargetfn)
	inst.components.combat:SetKeepTargetFunction(keeptargetfn)
    --inst.components.combat.onhitotherfn = OnHitOther
	
	inst:AddComponent("healthtrigger")
	inst.components.healthtrigger:AddTrigger(0.75, EnterPhase2Trigger)
	inst.components.healthtrigger:AddTrigger(0.50, EnterPhase3Trigger)
	inst.components.healthtrigger:AddTrigger(0.25, EnterPhase4Trigger)
	
	inst:AddComponent("inventory")

    inst:AddComponent("lootdropper")
    inst.components.lootdropper:SetLoot({"machine_badge"})

    inst:AddComponent("knownlocations")
    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("浠庡摢鏉ョ殑锛屾粴鍥炲摢鍘?")
	inst:AddComponent("timer")
	
	inst.EquipHealthStaff = EquipHealthStaff
	inst.EquipFireStaff = EquipFireStaff
	inst.GetSuitableAttackWeapon = GetSuitableAttackWeapon
	
	--inst.Weapon = EquipWeaponFireStaff(inst)
	inst.Weapon = inst:EquipHealthStaff()
	inst.ShoudlRunAway = ShoudlRunAway

    inst:ListenForEvent("attacked", OnAttacked)
	inst:ListenForEvent("use_giaour_skill",onskilluse)
	inst:ListenForEvent("timerdone",ontimerdone)
	inst:ListenForEvent("onhitother",OnHitOther)
	inst:ListenForEvent("death",OnGiaourDeath)


    return inst
end

return Prefab("moon_giaour", fn, assets)
