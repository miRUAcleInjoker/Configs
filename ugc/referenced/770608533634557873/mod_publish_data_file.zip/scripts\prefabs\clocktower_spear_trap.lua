--require "prefabutil"
--require "stategraphs/SGspear_trap"

local assets =
{
	Asset("ANIM", "anim/spear_trap.zip"), 
    Asset("MINIMAP_IMAGE", "spear_trap"),
}

local prefabs =
{

}    

local AREA = 1.3

local function inflictdamage(inst)
    local pt = Point(inst.Transform:GetWorldPosition())    
    local ents = TheSim:FindEntities(pt.x,pt.y,pt.z, AREA, nil, {"spear_trap","INTERIOR_LIMBO","clocktowerworks"})
    for i, ent in ipairs(ents)do
        if ent.components.health and not ent.components.health:IsDead() then
            inst.components.combat:DoAttack(ent)
        elseif ent.components.workable and ent.components.workable.workleft > 0 
		and ent.prefab ~= "skeleton" and ent.prefab ~= "skeleton_player" then           
            ent.components.workable:Destroy(inst)                    
        end
    end
end

local function oncollide(inst, other)
    if other and other.components.health and inst.sg:HasStateTag("damage") then
        inst.components.combat:DoAttack(other)
    end    
end

local function setextendeddata(inst, extended)
    if extended then
        inst:RemoveTag("NOCLICK")    
        inst.extended = true
        inst:AddTag("hostile")  
        inst:RemoveTag("fireimmune")
        if inst.components.burnable then
            inst.components.burnable.disabled = nil
        end
        inst.components.health.vulnerabletoheatdamage = true        
        inst.name = STRINGS.NAMES.PIG_RUINS_SPEAR_TRAP_TRIGGERED
        inst.Physics:SetActive(true)       
        if inst.MiniMapEntity then
            inst.MiniMapEntity:SetIcon("spear_trap.png")          
        end
    else
        inst:AddTag("NOCLICK")
        inst.extended = nil
        inst:RemoveTag("hostile")    
        inst:AddTag("fireimmune")
        if inst.components.burnable then
            inst.components.burnable.disabled = true    
        end
        inst.components.health.vulnerabletoheatdamage = false     
        inst.name = STRINGS.NAMES.PIG_RUINS_SPEAR_TRAP       
        inst.Physics:SetActive(false)         
        if inst.MiniMapEntity then
            inst.MiniMapEntity:SetIcon("")          
        end        
    end
end

local function onsave(inst, data)    
    if inst.extended then
        data.extended = true
    end

	data.uptime = inst.uptime
	data.downtime = inst.downtime
	data.delaytime = inst.delaytime 
	data.timed = inst.timed 
	data.cycled = inst.cycled
	data.player_close_trigger = inst.player_close_trigger

end

local function onload(inst, data)
    if data then
        
		--inst.uptime = data.uptime
		--inst.downtime = data.downtime
		--inst.delaytime = data.delaytime  
		inst.cycled = data.cycled 
		--inst.timed = data.timed 
		inst:SetTime(data.uptime,data.downtime,data.delaytime,data.timed)
		inst.player_close_trigger = data.player_close_trigger 
		
		if data.extended and not inst.cycled then      
            inst.sg:GoToState("extended")
        end
    end
end

local function disarm(inst, doer)    
    local pt = Point(inst.Transform:GetWorldPosition())
    inst.components.lootdropper:SpawnLootPrefab("blowdart_pipe", pt)
end

local function OnKilled(inst)
    inst:PushEvent("dead")

    local debris = SpawnPrefab("clocktower_spear_trap_broken")
    debris.AnimState:PlayAnimation("breaking")
    debris.AnimState:PushAnimation("broken",true)
    debris.Transform:SetPosition(inst.Transform:GetWorldPosition())
    debris.SoundEmitter:PlaySound("dontstarve_DLC003/common/traps/speartrap_break")    

    inst:Remove()
end

local function burnt(inst)
    local debris = SpawnPrefab("clocktower_spear_trap_broken")
    debris.AnimState:PlayAnimation("burnt")
    debris.Transform:SetPosition(inst.Transform:GetWorldPosition())    

    inst:Remove()
end

local function OnHit(inst)
    inst:PushEvent("hit")
end

local function cycletrap(inst)
    if not inst:HasTag("burnt") and not inst:HasTag("dead") then

        if inst.sg:HasStateTag("extended") then
            inst:PushEvent("reset")
        elseif inst.sg:HasStateTag("retracted") then
			--spring
			--triggertrap
            inst:PushEvent("spring")
        end
    end
end



local function returntointeriorscene(inst)
    inst.components.cycletimer:Resume()
end

local function removefrominteriorscene(inst)
    inst.components.cycletimer:Pause()
end

local function canbeattackedfn(inst)
    local canbeattacked = true

    if inst:HasTag("burnt") or inst:HasTag("dead") then
        canbeattacked = false
    end

    return canbeattacked
end

local function onnear(inst)
	if inst.player_close_trigger and not inst.triggertask then 
		inst:PushEvent("triggertrap")
	end
end 

local function ApplyTime(inst)
	local time1 = inst.uptime or 1
    local time2 = inst.downtime or 3
    inst.components.cycletimer:setup(time1,time2,cycletrap,cycletrap)
    if inst.timed then
		local initialdelay = inst.delaytime or 3                
        inst.components.cycletimer:start(initialdelay)
		inst.cycled = true 
    end
end 

local function SetTime(inst,uptime,downtime,delaytime,timed)
	inst.uptime = uptime
	inst.downtime = downtime
	inst.delaytime = delaytime
	inst.timed = timed
end 

local function fn(Sim)

    local inst = CreateEntity()
    local trans = inst.entity:AddTransform()
    local anim = inst.entity:AddAnimState()
	local minimap = inst.entity:AddMiniMapEntity()
	inst.entity:AddSoundEmitter()    
	inst.entity:AddNetwork()
    
    MakeObstaclePhysics(inst, .5)
    
	minimap:SetIcon("")
	
	anim:SetBank("spear_trap")
    anim:SetBuild("spear_trap")
    anim:PlayAnimation("idle_retract")
    inst:AddTag("spear_trap")
    inst:AddTag("tree")
    inst:AddTag("structure")
	inst:AddTag("clocktowerworks")
    
    
    --inst.Physics:SetCollisionCallback(oncollide)   

    
	
	inst.entity:SetPristine()
    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.uptime = nil 
	inst.downtime = nil 
	inst.delaytime = nil 
	inst.cycled = false 
	
	inst.SetTime = SetTime
	inst.ApplyTime = ApplyTime 
	--inst.cycleup = cycleup
    --inst.cycledown = cycledown
	inst.setextendeddata = setextendeddata
	inst.inflictdamage = inflictdamage
	inst.player_close_trigger = false 
	
	inst.Physics:SetActive(false)
	
	inst:AddComponent("playerprox")
    inst.components.playerprox:SetDist(1,3)
    inst.components.playerprox.onnear = onnear

    inst:AddComponent("combat")
    inst.components.combat:SetOnHit(OnHit)
    inst.components.combat:SetDefaultDamage(100)
	inst.components.combat:SetHurtSound("dontstarve_DLC003/common/traps/spear")
    

    inst:AddComponent("health")
    inst.components.health:SetMaxHealth(300)

    inst:AddComponent("inspectable")

    inst:SetStateGraph("SGspear_trap")

    MakeSmallBurnable(inst)
    inst.components.burnable.disabled = true
    MakeSmallPropagator(inst)
    inst.components.burnable:SetFXLevel(2)
    inst.components.burnable:SetOnBurntFn(burnt)

    inst.OnLoad = onload
    inst.OnSave = onsave

    inst:AddComponent("cycletimer")
	
	inst:DoTaskInTime(0,ApplyTime) 
	inst:ListenForEvent("death", OnKilled)
    inst:ListenForEvent("triggertrap", function(inst, data)
        inst.triggertask = inst:DoTaskInTime(math.random()*0.25,function()
            inst:PushEvent("spring")
        end)
    end)

    return inst
end

local function debrisfn(Sim)

    local inst = CreateEntity()
    local trans = inst.entity:AddTransform()
    local anim = inst.entity:AddAnimState()
	inst.entity:AddSoundEmitter()   
	inst.entity:AddNetwork()

    anim:SetBank("spear_trap")
    anim:SetBuild("spear_trap")
    anim:PlayAnimation("broken")
	
	inst.entity:SetPristine()
    if not TheWorld.ismastersim then
        return inst
    end
    
    inst:AddComponent("inspectable")

    return inst
end

return  Prefab( "common/objects/clocktower_spear_trap", fn, assets, prefabs),
        Prefab( "common/objects/clocktower_spear_trap_broken", debrisfn, assets, prefabs)