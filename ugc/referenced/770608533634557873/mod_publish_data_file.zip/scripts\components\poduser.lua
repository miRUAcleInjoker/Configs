local PodUser = Class(function(self,inst)
	self.inst = inst
	
	--self.enable = true 
	self.temperature = 0
	self.overheat_temperature = 35
	self.max_temperature = 40
	
	self.switch = true
	self.podname = "icey_pod"
	self.bulletdamage_min = 3
	self.bulletdamage_max = 5
	self.bulletspeed = 35
	self.bulletname = "pod_projectile"--"fireball_projectile"
	self.offset = Vector3(0,0,0)
	self.position = Vector3(-1,0,0)
	self.shootsound = "dontstarve/creatures/rook/land" --"dontstarve/creatures/rook/pawground"--"dontstarve/forge2/beetletaur/step"--"dontstarve/wilson/attack_firestaff"--"dontstarve/common/lava_arena/heal_staff"--
	self.overheatsound = "dontstarve/forge2/beetletaur/chain_hit"
	
	self.canhit = nil 
	self.pod = nil 
	
	self.inst:AddTag("poduser")
	self:SpawnPod()
	self.inst:StartUpdatingComponent(self) 
end)

local brain = require("brains/iceypodbrain")

local function onthrown(pod)
	--local x,y,z = inst.Transform:GetWorldPosition()
	--local cast = SpawnPrefab("pod_projectile_hitfx")
	--cast.Transform:SetPosition(x,y+2.25,z)
	--cast.Transform:SetScale(0.2,0.2,0.2)
	--local fx = pod:SpawnChild("pod_projectile_hitfx")
	--fx.Transform:SetPosition(0.3,2.25,0)
	--fx.Transform:SetScale(0.2,0.2,0.2)
	local fx = SpawnPrefab("pod_projectile_hitfx")
	fx.entity:AddFollower()
	fx.Follower:FollowSymbol(pod.GUID, "mouse", 0,0, 0)
	fx.Transform:SetScale(0.3,0.3,0.3)
end 

function PodUser:SetCanHit(fn)
	self.canhit = fn
end 

function PodUser:SetVisiable(enable)
	if self.pod and self.pod:IsValid() then 
		if enable then 
			self.pod:Show()
		else
			self.pod:Hide()
		end
	end 
end 

function PodUser:Switch()
	self.switch = not self.switch
	if self.switch then 
		self.pod.SoundEmitter:PlaySound("dontstarve/HUD/get_gold")
	else
		self.pod.SoundEmitter:PlaySound("dontstarve_DLC001/common/firesupressor_craft")
	end 
end 

function PodUser:IsOverHeat()
	return self.temperature >= self.overheat_temperature 
end 

function PodUser:OnOverHeat()
	if self.pod and self.pod:IsValid() then 
		self.pod.AnimState:SetMultColour(255/255,0/255,0/255,1)
		local fx = SpawnPrefab("lantern_tesla_fx_ground")
		fx.entity:AddFollower()
		fx.Follower:FollowSymbol(self.pod.GUID, "icey_pod", 0,0, 0)
		--fx.Transform:SetScale(0.3,0.3,0.3)
		
	end 
end

function PodUser:OnCoolDown()
	if self.pod and self.pod:IsValid() then 
		self.pod.AnimState:SetMultColour(1,1,1,1)
	end 
end 

function PodUser:TemperatureDoDelta(val)
	local old_isheat = self:IsOverHeat()
	self.temperature = self.temperature + val
	self.temperature = math.max(self.temperature,0)
	self.temperature = math.min(self.temperature,self.max_temperature)
	local new_isheat = self:IsOverHeat()
	if not old_isheat and new_isheat then -------------�������
		self:OnOverHeat()
	elseif old_isheat and not new_isheat then ------------�뿪����
		self:OnCoolDown()
	end
end 

function PodUser:SpawnPod()
	if self.pod and self.pod:IsValid() then 
		return 
	end 
	self.pod = self.inst:SpawnChild(self.podname) 
	--self.pod = SpawnPrefab(self.podname) 
	if self.pod.components.health then 
		self.pod.components.health:SetInvincible(true)
	end 
	
	RemovePhysicsColliders(self.pod)
	
	self.pod.persists = false 
	
	--self.pod.components.locomotor.walkspeed = 8
	--self.pod.components.locomotor.runspeed = 8 
	
	self:StartFaceMe()
	
	self.pod:DoTaskInTime(0,function()
		--self.pod.Transform:SetPosition(self.inst:GetPosition():Get())
		self.position = Vector3(-1,0,1-math.random()*2)
		self.pod.Transform:SetPosition(self.position:Get())
		--[[if self.pod.components.follower then 
			self.pod.components.follower:SetLeader(self.inst)
		end
		self.pod:SetBrain(brain)--]]
	end)
	
	self.pod:ListenForEvent("onremove",function() self:RemovePod() end,self.inst)
	self.pod:ListenForEvent("playerexited",function(world,player) 
		if player == self.inst then 
			self:RemovePod()
		end 
	end,TheWorld)
end 

function PodUser:RemovePod()
	self.pod:Remove() 
	self.pod = nil 
end 

function PodUser:FaceMe()
	if not (self.pod and self.pod:IsValid()) then 
		return 
	end 
	local x,y,z = self.inst:GetPosition():Get()
	self.pod:ForceFacePoint(x,y,z)
end 

function PodUser:StartFaceMe()
	if not (self.pod and self.pod:IsValid()) then 
		return 
	end 
	self:StopFaceMe()
	self.pod.FaceLeaderTask = self.pod:DoPeriodicTask(0,function()
		self:FaceMe()
	end)
end 

function PodUser:StopFaceMe()
	if not (self.pod and self.pod:IsValid()) then 
		return 
	end 
	if self.pod.FaceLeaderTask then 
		self.pod.FaceLeaderTask:Cancel()
	end
	self.pod.FaceLeaderTask = nil 
end

function PodUser:FaceIn(time)
	if not (self.pod and self.pod:IsValid()) then 
		return 
	end 
	time = time or 0.7
	if self.pod.FaceLeaderInTask then 
		self.pod.FaceLeaderInTask:Cancel()
		self.pod.FaceLeaderInTask = nil 
	end 
	self.pod.FaceLeaderInTask = self.pod:DoTaskInTime(time,function()
		self:StartFaceMe()
	
	end)
end 

function PodUser:CanShoot()
	return self.pod and self.pod:IsValid() and self.switch
end 

function PodUser:Shoot(pos,target)
	if not (self.pod and self.pod:IsValid()) then 
		self:SpawnPod()
	end 
	if not (pos or target) then 
		return 
	end 
	self.pod.Transform:SetPosition(self.position:Get())
	if not self:CanShoot() then 
		return 
	end 
	local x,y,z = 0,0,0
	if pos then 
		x,y,z = pos:Get()
	elseif target then 
		x,y,z = target:GetPosition():Get()
	end 
	--print("PodUser:Shoot ",x,y,z)
	self:StopFaceMe()
	self.pod:ForceFacePoint(x,y,z)
	self:FaceIn()
	if self:IsOverHeat() then 
		self.pod.SoundEmitter:PlaySound(self.overheatsound)
		self:TemperatureDoDelta(5)
		return false 
	else
		local bullet = SpawnPrefab(self.bulletname)
		if not bullet.components.ly_projectile then 
			bullet:AddComponent("ly_projectile")
		end 
		onthrown(self.pod)
		bullet.AnimState:SetMultColour(20/255,242/255,245/255,1)
		bullet.components.ly_projectile:CopyFrom()
		bullet.components.ly_projectile.damage = (self.bulletdamage_min + (self.bulletdamage_max - self.bulletdamage_min) * math.random())--self.bulletdamage
		--bullet.components.ly_projectile:SetOnHitFn(OnBulletHit)
		bullet.components.ly_projectile:SetSpeed(self.bulletspeed)
		bullet.components.ly_projectile:SetCanHit(self.canhit)
		bullet.components.ly_projectile:SetLaunchOffset(self.offset)
		--bullet.Transform:SetScale(0.5,0.5,0.5)
		bullet.Transform:SetPosition(self.pod:GetPosition():Get()) 
		bullet.components.ly_projectile:Throw(self.pod,Vector3(x,y,z),true)
		bullet.components.ly_projectile.owner = self.inst
		self.pod.SoundEmitter:PlaySound(self.shootsound)
		self:TemperatureDoDelta(1)
		
		self.inst:PushEvent("podshoot",{pod = self.pod,projectile = bullet,pos = pos})
		return true 
	end 
end

function PodUser:OnUpdate(dt)
	if self:IsOverHeat() then 
		self:TemperatureDoDelta(-dt*1.5)
	else
		self:TemperatureDoDelta(-dt*3)
	end 
end

return PodUser