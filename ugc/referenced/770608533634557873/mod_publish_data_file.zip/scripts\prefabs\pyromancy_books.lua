local IceyUtil = require("icey_util")

local function canattack(inst,owner,target) ------------多重保险：判定目标是否真的可以被攻击，可以被伤害
	return IceyUtil.CanAttack(target,owner)
end 

local function keepTwoDecimalPlaces(decimal)-----------------------四舍五入保留两位小数的代码
    decimal = math.floor((decimal * 100)+0.5)*0.01       
    return  decimal 
end

local function OnStoneHit(inst, attacker, target)
    local x, y, z = inst.Transform:GetWorldPosition()
    inst.Physics:Stop()
    inst.Physics:Teleport(x, 0, z)
    inst.Transform:SetRotation(inst.direction:value())
    inst.AnimState:PlayAnimation("impact")
    inst:ListenForEvent("animover", inst.Remove)

    inst.hideanim:set(true)
    if inst.animent ~= nil then
        inst.animent:Remove()
        inst.animent = nil
    end

    local hit = false
    for i, v in ipairs(TheSim:FindEntities(x, y, z, 4, { "_combat" })) do
        if canattack(inst,attacker,v) then
            v.components.combat:GetAttacked(attacker,GetRandomMinMax(40,60))
            hit = true
        end
    end

    inst.SoundEmitter:PlaySound("dontstarve/common/together/catapult/rock_hit", nil, hit and .5 or nil)
end

local function OnAcidHit(inst,data)
	print("OnAcidHit")
	local x,y,z = inst:GetPosition():Get()
	
	local ents = TheSim:FindEntities(x,y,z,4)
	for k,v in pairs(ents) do 
		if v and v.components then 
			local inventory_owner = v.components.inventoryitem and v.components.inventoryitem:GetGrandOwner()
			if not (inventory_owner and inventory_owner:IsValid()) or IceyUtil.CanAttack(inventory_owner,data.owner) then 
				if v.components.finiteuses then 
					local use_num = math.max(v.components.finiteuses.total * 0.2,30)
					v.components.finiteuses:Use(use_num)
				end
				if v.components.perishable then 
					v.components.perishable:ReducePercent(0.2)
				end
				if v.components.armor and not v.components.armor:IsIndestructible() then 
					local current = v.components.armor.condition
					local use_num = math.max(v.components.armor.maxcondition * 0.2,300)
					v.components.armor:SetCondition(current - use_num)
				end
				if v.components.fueled and v.components.fueled.fueltype == FUELTYPE.USAGE then 
					local cosume = math.max(v.components.fueled.maxfuel * 0.2,300) 
					v.components.fueled:DoDelta(-cosume)
				end
			end 
		end
	end
	
end 


local function DefaultCostFn(inst,doer,pos,cost)
	return IceyUtil.DefaultCostFn(doer,cost,true)
end 

local PyromancyFns = {
	--火球
	pyromancy_fireball = function(inst,doer,pos)
		local can_cast = DefaultCostFn(inst,doer,pos,{focus = 2,stamina = 5})
		if not can_cast then 
			return 
		end
		
		local proj = SpawnAt("fireball_projectile",inst:GetPosition())
		proj:AddComponent("ly_projectile")
		proj.components.ly_projectile:CopyFrom()
		proj.components.ly_projectile.damage = 34
		proj.components.ly_projectile:SetCanHit(canattack)
		proj.components.ly_projectile:Throw(doer,pos,true)
	end,
	
	--火焰霰弹
	pyromancy_bursting_fireball = function(inst,doer,pos)
		local can_cast = DefaultCostFn(inst,doer,pos,{focus = 6,stamina = 8})
		if not can_cast then 
			return 
		end
		for i=1,11 do 
			local radius = 1 + math.random()
			local rotation = math.random() * 2 * math.pi
			local proj = SpawnAt("pod_projectile_fire",inst:GetPosition())
			local offset = Vector3(radius*math.cos(rotation),0,radius*math.sin(rotation))
			proj:AddComponent("ly_projectile")
			proj.components.ly_projectile:CopyFrom()
			proj.components.ly_projectile:SetSpeed(proj.components.ly_projectile.speed + GetRandomMinMax(-5,5))
			
			proj.components.ly_projectile.damage = 8 + math.random()*3
			proj.components.ly_projectile:SetCanHit(canattack)
			proj.components.ly_projectile:Throw(doer,pos+offset,true,function()
				proj.Transform:SetPosition(inst:GetPosition():Get())
			end)
		end
	end,
	
	pyromancy_acid_surge = function(inst,doer,pos)
		local can_cast = DefaultCostFn(inst,doer,pos,{focus = 6,stamina = 8})
		if not can_cast then 
			return 
		end
		
		local proj = SpawnAt("gooball_projectile",inst:GetPosition())
		proj:AddComponent("ly_projectile")
		proj.components.ly_projectile:CopyFrom()
		proj.components.ly_projectile.damage = 30
		proj.components.ly_projectile:SetCanHit(canattack)
		proj.components.ly_projectile:Throw(doer,pos,true)
		
		proj:ListenForEvent("lyprojectilehit",OnAcidHit)
	end,
	
	--吐岩
	pyromancy_boulder_heave = function(inst,doer,pos)
		local can_cast = DefaultCostFn(inst,doer,pos,{focus = 8,stamina = 10})
		if not can_cast then 
			return 
		end
		
		local proj = SpawnAt("winona_catapult_projectile",inst:GetPosition())
		proj.components.complexprojectile:SetHorizontalSpeed(20)
		proj.components.complexprojectile:SetGravity(-60)
		proj.components.complexprojectile:SetLaunchOffset(Vector3(1.25,1, 0))
		proj.components.complexprojectile:SetOnHit(OnStoneHit)
		proj.components.complexprojectile:Launch(pos,doer)
	end,
	
	--铁身躯
	pyromancy_iron_flesh = function(inst,doer,pos)
		if doer.components.debuffable and doer.components.debuffable:GetDebuff("pyromancy_iron_flesh_debuff") then 
			if doer.components.talker then 
				doer.components.talker:Say("我已经释放过铁身躯了。")
			end
			return 
		end 
		local can_cast = DefaultCostFn(inst,doer,pos,{focus = 10,stamina = 11})
		if not can_cast then 
			return 
		end
		
		if doer.components.combat and doer.components.locomotor and doer.components.debuffable then 
			doer.components.debuffable:AddDebuff("pyromancy_iron_flesh_debuff", "pyromancy_iron_flesh_debuff")
		end
	end,
	
	--魅惑
	pyromancy_rapport = function(inst,doer,pos)
		local can_cast = DefaultCostFn(inst,doer,pos,{focus = 10,stamina = 25})
		if not can_cast then 
			return 
		end

		local success = false 
		local ents = TheSim:FindEntities(pos.x,pos.y,pos.z,4,{"_combat"},{"player","guard"})
		for k,v in pairs(ents) do 
			v.components.combat:SetTarget(nil)
			if v and v:IsValid() and v.components.follower then 
				doer.components.focus:DoDelta(-4)
				doer.components.leader:AddFollower(v)
				if v.components.follower.maxfollowtime then 
					v.components.follower:AddLoyaltyTime(30)
				end
				--v.components.follower:SetLeader(doer)
				success = true
			end
		end
		
		local explode = SpawnAt("positronpulse",pos)
		if success then 
			explode.SoundEmitter:PlaySound("dontstarve/common/makeFriend") 
		end 
		explode.AnimState:SetMultColour(255/255, 128/255, 235/255,1)
		explode:FinishFX()
	end,
	
	--浮空混沌
	pyromancy_floating_chaos = function(inst,doer,pos)
		local can_cast = DefaultCostFn(inst,doer,pos,{focus = 35,stamina = 32})
		if not can_cast then 
			return 
		end
		
		local chaos = SpawnAt("stafflight",pos)
		chaos.persists = false

		chaos:DoTaskInTime(0,function()
			chaos.components.timer:SetTimeLeft("extinguish",10)
		end)
		
		chaos:AddComponent("follower")
		chaos.components.follower:KeepLeaderOnAttacked()
        chaos.components.follower.keepdeadleader = true
        chaos.components.follower.keepleaderduringminigame = true
		chaos.components.follower:SetLeader(doer)
		
		chaos:AddComponent("combat")
		chaos.components.combat:SetRange(15)
		chaos.components.combat:SetDefaultDamage(55)
		chaos.components.combat:SetAttackPeriod(1)
		chaos.components.combat.battlecryenabled = false 
		
		chaos.AttackTask = chaos:DoPeriodicTask(0.5,function()
			local target = chaos.components.combat.target 
			if not inst.AnimState:IsCurrentAnimation("disappear") and target and target:IsValid() then 
				local targetpos = target:GetPosition()
				local fireball = SpawnAt("fireball_projectile",chaos:GetPosition())
				chaos.components.combat:StartAttack()
				print(chaos,"Shoot Fireball To",target)
				fireball:AddComponent("ly_projectile")
				fireball.components.ly_projectile:CopyFrom()
				fireball.components.ly_projectile.damage = chaos.components.combat.defaultdamage 
				fireball.components.ly_projectile:SetCanHit(canattack)
				fireball.components.ly_projectile:Throw(doer,targetpos,true,function()
					fireball.Transform:SetPosition(chaos:GetPosition():Get())
				end)
			end 
		end)
		
		IceyUtil.MakeIceyAlly(chaos)
	end,
	
	--火焰风暴
	pyromancy_firestorm = function(inst,doer,pos)
		local can_cast = DefaultCostFn(inst,doer,pos,{focus = 65,stamina = 60})
		if not can_cast then 
			return 
		end
		
		inst:StartThread(function()
			inst.SoundEmitter:PlaySound("dontstarve/cave/earthquake", "firestorm_quake")
			inst.SoundEmitter:SetParameter("firestorm_quake", "intensity", 2)
			for i=1,20 do 
				local mypos = doer:GetPosition() 
				local radius = GetRandomMinMax(5,15)
				local rotation = math.random() * 2 * math.pi
				local offset = FindWalkableOffset(mypos,rotation,radius,nil,nil,true) 
				local staytime = 5 + math.random()
				
				if offset then 
					for k=1,3 do 
						local smalloffset = Vector3(GetRandomMinMax(-1,1),0,GetRandomMinMax(-1,1))
						SpawnAt("halloween_firepuff_"..math.random(1,3),mypos+offset+smalloffset).Transform:SetScale(1.3,3,1)
					end 
					SpawnAt("halloween_firepuff_"..math.random(1,3),mypos+offset).Transform:SetScale(1.5,4,1)
					local circle = SpawnAt("deer_fire_circle",mypos+offset)
					circle:DoTaskInTime(staytime,circle.KillFX)
					circle.SoundEmitter:PlaySound("dontstarve/creatures/together/toad_stool/spore_explode")
					local x,y,z = (mypos+offset):Get()
					for i, v in ipairs(TheSim:FindEntities(x,y,z,4, { "_combat" })) do
						if canattack(inst,doer,v) then
							v.components.combat:GetAttacked(doer,GetRandomMinMax(80,120))
						end
					end
					ShakeAllCameras(CAMERASHAKE.VERTICAL, .7, .025, 1.25, inst, 40)
				end 
				Sleep(GetRandomMinMax(0.3,0.4))
			end
			inst.SoundEmitter:KillSound("firestorm_quake")
		end)
	end,

}
local function MakeBook(prefabname,tags,fxcolour,castsound)
	local assets ={
		Asset("ANIM", "anim/pyromancy_books.zip"),
		Asset("IMAGE","images/inventoryimages/"..prefabname..".tex"),
		Asset("ATLAS","images/inventoryimages/"..prefabname..".xml"),
	}
	local function fn()
		local inst = CreateEntity()

		inst.entity:AddTransform()
		inst.entity:AddAnimState()
		inst.entity:AddSoundEmitter()
		inst.entity:AddNetwork()

		inst.AnimState:SetBank("pyromancy_books")
		inst.AnimState:SetBuild("pyromancy_books")
		inst.AnimState:PlayAnimation(prefabname)

		MakeInventoryPhysics(inst)
		
		inst:AddTag("pyromancy_book")
		if tags then 
			for k,v in pairs(tags) do 
				inst:AddTag(v)
			end 
		end 

		inst.entity:SetPristine()

		if not TheWorld.ismastersim then
			return inst
		end
		
		inst.fxcolour = fxcolour
		inst.castsound = castsound
		inst.Pyromancy = PyromancyFns[prefabname]

		inst:AddComponent("inventoryitem")
		inst.components.inventoryitem.imagename = prefabname
		inst.components.inventoryitem.atlasname = "images/inventoryimages/"..prefabname..".xml" 
		-----------------------------------

		inst:AddComponent("equippable")
		inst.components.equippable.equipslot = EQUIPSLOTS.PYROMANCY_SLOT1
		-----------------------------------

		inst:AddComponent("inspectable")


		MakeHauntableLaunch(inst)

		return inst
	end 
	
	return Prefab(prefabname,fn,assets)
end

return MakeBook("pyromancy_fireball",{"quickcast","aoe_line"}),
MakeBook("pyromancy_bursting_fireball",{"quickcast","aoe_line"}),
MakeBook("pyromancy_acid_surge",{"quickcast","aoe_point"}),
MakeBook("pyromancy_boulder_heave",{"quickcast","aoe_point"}),
MakeBook("pyromancy_iron_flesh",{"aoe_point"},{14/255, 97/255, 175/255},"dontstarve/common/lava_arena/spell/heal"),
MakeBook("pyromancy_rapport",{"aoe_point"},{255/255, 128/255, 235/255},"dontstarve/common/lava_arena/spell/heal"),
MakeBook("pyromancy_floating_chaos",{"aoe_point"},{223/255, 208/255, 69/255},"dontstarve/common/staffteleport"),
MakeBook("pyromancy_firestorm",{"aoe_point"},{223/255, 208/255, 69/255},"dontstarve/common/lava_arena/spell/meteor")
