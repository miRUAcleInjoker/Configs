local IceyUtil = require("icey_util")
local IceyWeaponSkillUtil = require("icey_weaponskill_util")
local SourceModifierList = require("util/sourcemodifierlist")

local function GetKeyFromConfigString(config)
	local key_str = TUNING[string.upper(config).."_KEY_STRING"] or ""
	if key_str and string.find(key_str,"KEY_") then 
		local finds = string.find(key_str,"KEY_")
		key_str = string.sub(key_str,finds + 4)
	end
	return key_str
end


--GLOBAL.FE_MUSIC = "music_mod/music/mainmenutheme"


local DarkSoulWeapons = {
	"spear",
	"pyromancy_flame",
}

local PropertyStrings = {
	fire = "火焰",
}

--[[AddPrefabPostInit("chester",function(inst)
	if not TheWorld.ismastersim then
		return inst
	end
	inst.enablemap = IceyUtil.EnableDrawOverFogOfWar
	IceyUtil.EnableDrawOverFogOfWar(inst,true) 
end) --]]

--[[local function AddPlayerSelectedTheme(self)
	local old_StartLobbyMusic = self.StartLobbyMusic 
	self.StartLobbyMusic = function(self)
		old_StartLobbyMusic(self)
		TheFrontEnd:GetSound():KillSound("PortalMusic")
        TheFrontEnd:GetSound():PlaySound(GetGameModeProperty("override_lobby_music") or "icey_bgms_remaster/bgms/metal_gear_theme", "PortalMusic")
	end 
end 

AddClassPostConstruct("screens/lobbyscreen", AddPlayerSelectedTheme)
AddClassPostConstruct("screens/redux/lobbyscreen", AddPlayerSelectedTheme)--]]

AddPrefabPostInit("gunpowder",function(inst)
	if not TheWorld.ismastersim then
		return inst
	end
	inst:AddComponent("tradable")
end) 

GAME_MODES.survival.override_lobby_music = "icey_bgms_remaster/bgms/metal_gear_theme"
GAME_MODES.wilderness.override_lobby_music = "icey_bgms_remaster/bgms/metal_gear_theme"
GAME_MODES.endless.override_lobby_music = "icey_bgms_remaster/bgms/metal_gear_theme"




AddComponentPostInit("weapon",function(self)
	local old_OnAttack = self.OnAttack 
	self.OnAttack = function(self,attacker, target, projectile,...)
		old_OnAttack(self,attacker, target, projectile,...)
		if self.inst.components.darksoulweapon then 
			self.inst:PushEvent("darksoulweapon_onattack",{attacker = attacker,target = target,projectile = projectile})
		end 
	end
end)

AddComponentPostInit("fueled",function(self)
	local old_StartConsuming = self.StartConsuming
	self.StartConsuming = function(self,...)
		if self.unlimited_fuel then 
			self:StopConsuming() 
		else
			old_StartConsuming(self,...)
		end
	end
end)

AddComponentPostInit("weapon",function(self)
	self.is_shotgun = false
	self.extra_bullet_num = 0
	self.max_shotgun_rotation = 0
	self.can_shotgun_attack = nil 
	self.shotgun_bullet_delayfn = nil 
	self.shotgun_bullet_speedchangefn = nil 
	
	self.SetShotgun = function(self,is_shotgun,bulletnum,rotation,speedchangefn,getdelayfn,canattack)
		if is_shotgun and bulletnum and bulletnum > 0 and rotation and rotation > 0 then 
			self.is_shotgun = is_shotgun
			self.extra_bullet_num = bulletnum
			self.max_shotgun_rotation = rotation
		else
			self.is_shotgun = false
			self.extra_bullet_num = 0
			self.max_shotgun_rotation = 0
		end
		
		self.can_shotgun_attack = canattack 
		self.shotgun_bullet_delayfn = getdelayfn
		self.shotgun_bullet_speedchangefn = speedchangefn
	end 
	
	self.LaunchShotgunProjectile = function(self,attacker,target)
		if self.projectile ~= nil and self.is_shotgun then
			for i = 1,self.extra_bullet_num do 
				local delay = self.shotgun_bullet_delayfn and self.shotgun_bullet_delayfn(self.inst,attacker,target) or 0 
				local speedchange = self.shotgun_bullet_speedchangefn and self.shotgun_bullet_speedchangefn(self.inst,attacker,target) or 0 
				local mypos = attacker:GetPosition()
				local targetpos = target:GetPosition()
					
				local vec = targetpos - mypos
				local vec_vertical = Vector3(-vec.z,0,vec.x):GetNormalized()
				local extra_length = math.abs(math.tan(0.5 * self.max_shotgun_rotation) * vec:Length())
				local offset = vec_vertical * extra_length
				
				local shootpos = targetpos + offset * (1 - 2 * math.random())
				local function Shot()
					local proj = SpawnAt(self.projectile,mypos)
					if proj.components.projectile ~= nil and attacker and attacker:IsValid() then
						proj:AddComponent("ly_projectile")
						proj.components.ly_projectile.damage = self.damage 
						proj.components.ly_projectile:CopyFrom()
						if self.can_shotgun_attack then 
							proj.components.ly_projectile:SetCanHit(self.can_shotgun_attack)
						end 
						proj.components.ly_projectile:Throw(attacker,shootpos,true)
						proj.components.ly_projectile:SetSpeed(proj.components.ly_projectile.speed+speedchange)
					else
						proj:Remove() 
					end
				end 
				
				if delay and delay > 0 then
					self.inst:DoTaskInTime(delay,Shot)	
				else
					Shot()
				end 

			end
		end
	end 
	
	local old_self_LaunchProjectile = self.LaunchProjectile
	self.LaunchProjectile = function(self,attacker,target,...)
		local ret = old_self_LaunchProjectile(self,attacker,target,...)
		self:LaunchShotgunProjectile(attacker,target)
		return ret 
	end
	
end)

AddComponentPostInit("health",function(self)
	self.externalhealthregenmultipliers = SourceModifierList(self.inst)
	local old_DoDelta = self.DoDelta
	self.DoDelta = function(self,amount, overtime, cause, ignore_invincible, afflicter, ignore_absorb,...)
		if amount > 0 then 
			amount = amount * self.externalhealthregenmultipliers:Get()
		end
		return old_DoDelta(self,amount, overtime, cause, ignore_invincible, afflicter, ignore_absorb,...)
	end 
end)

AddReplicableComponent("darksoulweapon")
AddReplicableComponent("stamina")
AddReplicableComponent("focus")
AddReplicableComponent("icey_hunter")
--AddReplicableComponent("darksouldebuffable")
AddReplicableComponent("darksouldebuff")

for k,v in pairs(DarkSoulWeapons) do 
	AddPrefabPostInit(v,function(inst)
	
		
		
		if not TheWorld.ismastersim then
			return inst
		end
		
		inst:AddComponent("darksoulweapon")
	end)
end

local DeathShow = require("widgets/death_show")
AddClassPostConstruct("screens/playerhud",function(self)
	self.death_show = self:AddChild(DeathShow(self.owner))
	
	local old_SetMainCharacter = self.SetMainCharacter
	self.SetMainCharacter = function(self,maincharacter,...)
		old_SetMainCharacter(self,maincharacter,...)
		if maincharacter then 
			self.death_show.owner = maincharacter
		end
	end 
end)

local UIAnim = require "widgets/uianim"
AddClassPostConstruct("widgets/healthbadge",function(self)
	--if self.owner.prefab == "woodie" then 
	self.hunter_health_anim = self.anim:AddChild(UIAnim())
	self.hunter_health_anim:GetAnimState():SetBank("status_meter")
	self.hunter_health_anim:GetAnimState():SetBuild("status_meter")
	self.hunter_health_anim:GetAnimState():PlayAnimation("anim")
	--[[self.hunter_health_anim:GetAnimState():Hide("bg")
	self.hunter_health_anim:GetAnimState():Hide("bg2")
	self.hunter_health_anim:GetAnimState():Hide("heart")
	self.hunter_health_anim:GetAnimState():Hide("frame_circle")--]]
	self.hunter_health_anim:GetAnimState():SetMultColour(213/255,90/255,57/255,0.7)
	self.hunter_health_anim:SetClickable(false)
	self.hunter_health_anim:MoveToFront() 
		
		--self.hunter_health_anim:MoveToFront() 
		
	local old_OnUpdate = self.OnUpdate 
	self.OnUpdate = function(self,dt,...)
		old_OnUpdate(self,dt,...)
		if self.owner.replica.icey_hunter then 
			local percent = self.owner.replica.icey_hunter:GetCurrent() / self.owner.replica.health:Max() 
			self.hunter_health_anim:GetAnimState():SetPercent("anim",1 - percent)
			self.hunter_health_anim:Show() 
		else
			self.hunter_health_anim:Hide() 
		end 
	end
	
	
	--end 
end) 

AddPrefabPostInit("player_classified", function(inst)
	inst:ListenForEvent("isghostmodedirty", function(inst,data)
		if inst._parent ~= nil and inst._parent.HUD ~= nil then 
			if inst.isghostmode:value() then 
				local anim = "death"
				if TUNING.BT_MOD_ENABLED then 
					anim = "vegetable"
				elseif TUNING.ICEY_DLCS ~= "none" then 
					--anim = "fuck"
				end
				inst._parent.HUD.death_show:FadeIn(anim)
			else
				inst._parent.HUD.death_show:FadeOut()
			end
		end
	end)
end )



local Image = require "widgets/image"
local ExtraText = {
	CHINESE = {
		icey_blade = {
			strings = 
			"仿制“雷电”的武器制作的刀具.\n"..
			"通过刀刃向被切割物体施加极高的频率,\n"..
			"使不匀震动积累,引发材质疲劳,\n"..
			"进而瞬间斩断敌人.\n"..
			STRINGS.RMB..":战技·突围冲击:\n"..
			"将刀刃压下,积蓄力量,\n"..
			"然后奋力跃向目标地点,\n"..
			"释放由高频震荡产生的强大电流.\n",	
			position = Vector3(0,36,0),
			scale = Vector3(1.25,0.64,1),
		},
		icey_armor = {
			strings = 
			"以魔力花为原型制作的护盾组件.\n"..
			"能够省去动手的繁琐,自动使用护盾电池.\n"..
			"虽然本身防御力不足,\n"..
			"但可借由极限闪避的充能,\n"..
			"在短时间内大大提升防御性能.\n"..
			"是敏捷型人造人的泛用防具.\n",	
			position = Vector3(0,36,0),
			scale = Vector3(1.25,0.64,1),
		},
		icey_armor2 = {
			strings = 
			"参考灵魂剥离的理论打造的防具,\n"..
			"通过装备者持续攻击敌人,积攒动能,\n"..
			"在动能打达到阈值后,\n"..
			"即可剥离装备者的灵魂,\n"..
			"形成动能残影,冲向目标.\n"..
			"所幸这种剥离对使用者没有副作用.\n",
			position = Vector3(0,36,0),
			scale = Vector3(1.25,0.64,1),
		},
		icey_snake_eye = {
			strings = 
			"“老蛇”斯内克曾经佩戴的眼罩,\n"..
			"能够将身边的重要实体显示在屏幕上.\n"..
			"蛇总是盘踞在暗处,紧盯自己的猎物,\n"..
			"是以警惕性闻名的生物.\n"..
			"如果缺乏基本的洞察力,\n"..
			"就连普通的潜行也做不成.\n",
			position = Vector3(0,36,0),
			scale = Vector3(1.25,0.64,1),
		},
		gestalt_report = {
			strings = 
			"记录「盖什塔尔」计划的简书.\n"..
			"将灵魂强制从身体中剥离,\n"..
			"加以改造,注入机械当中,\n"..
			"进而强化机械,使其获得等同于人的智力.\n"..
			"机械教为此四处抓捕无辜者投入计划,\n"..
			"但是成功转化的却屈指可数.\n"..
			"  \n"..
			"  \n"..
			"  \n",
			position = Vector3(0,36,0),
			scale = Vector3(1.25,0.64,1),
		},
		icey_armor_vortexcloak = {
			strings = 
			"盖什塔尔实验的失败品----崩坏体们,\n"..
			"其残念编制而成的斗篷.\n"..
			"由于长期失去肉体,\n"..
			"崩坏体的残念中,\n"..
			"铭刻着对生体的畸形渴望.\n"..
			"以这种残念编织的斗篷,\n"..
			"会紧紧裹在身体上,\n"..
			"无论受到什么攻击,\n"..
			"都会纹丝不动,不愿与身体分离.",
			position = Vector3(0,36,0),
			scale = Vector3(1.45,0.64,1),
		},
		shadowmixtures_blade = {
			strings = 
			"盖什塔尔实验的失败品----崩坏体们,\n"..
			"其领袖生前使用的大剑.\n"..
			"因为与主人一同沉入黑暗,\n"..
			"剑身已全部受到侵蚀,\n"..
			"无法猜测其原本的样貌.\n"..
			STRINGS.RMB..":战技·魔天陇月:\n"..
			"以双手共持大剑,使出威力巨大的回旋斩.\n"..
			"由于遭受深渊侵蚀,更是不可阻挡.\n",
			position = Vector3(0,36,0),
			scale = Vector3(1.45,0.64,1),
		},
		axe = {
			strings = 
			"普通的斧头.\n"..
			"不限当作武器,有各种用途的道具,\n"..
			"咒术师们常用这种斧头作武器.\n"..
			"虽然攻击距离短,但有恰好的重量与攻击力.\n"..
			"是比外表看起来强力,易于使用的武器.\n"..
			STRINGS.RMB..":战技·战吼:\n"..
			"借由大吼振奋自己,\n"..
			"可以暂时提升攻击力.\n",	
			position = Vector3(0,36,0),
			scale = Vector3(1.27,0.73,1),
		},
		goldenaxe = {
			strings = 
			"金子制成的斧头.\n"..
			"不限当作武器,有各种用途的道具,\n"..
			"金通常质地较软,不适合做锻材.\n"..
			"但是永恒领域的金却十分坚硬.\n"..
			"以这种金打造的斧头,经久耐用.\n"..
			STRINGS.RMB..":战技·战吼:\n"..
			"借由大吼振奋自己,\n"..
			"可以暂时提升攻击力.\n",	
			position = Vector3(0,36,0),
			scale = Vector3(1.27,0.68,1),
		},
		pickaxe = {
			strings = 
			"矿工用来挖土的道具.\n"..
			"原来不是用于战斗的物品.\n"..
			"但既然使出全力一击能凿开巨岩,\n"..
			"不够坚固的铠甲应该也会被轻易贯穿吧.\n"..
			STRINGS.RMB..":战技·一鼓作气:\n"..
			"借由一鼓作气,可以暂时提升精力恢复速度,\n"..
			"要是做不到,连矿工都当不成.\n",	
			position = Vector3(0,36,0),
			scale = Vector3(1.3,0.63,1),
		},
		goldenpickaxe = {
			strings = 
			"拥有大型坚硬喙状尖刺的镐.\n"..
			"使用硬质金进行了改良.\n"..
			"虽然构造简单,却是耐用的工具,\n"..
			"也能用攻击贯穿金属铠甲.\n"..
			STRINGS.RMB..":战技·一鼓作气:\n"..
			"借由一鼓作气,可以暂时提升精力恢复速度,\n"..
			"这可能是挥动十字镐的矿工留下的产物.\n",	
			position = Vector3(0,36,0),
			scale = Vector3(1.3,0.63,1),
		},
		hambat = {
			strings = 
			"用火腿肉制成的棍棒.\n"..
			"虽然听起来不可思议,\n"..
			"但以非刀刃的打击武器而言,\n"..
			"是个出奇好用的武器.\n"..
			"拥有击溃盾防御的力量.\n"..
			STRINGS.RMB..":战技·食欲:\n"..
			"借由对食物的渴望,提高自己的攻击力,\n"..
			"但同时也增加饥饿速度.\n"..
			"在饥饿的时代,肉是如此鲜美.\n",	
			position = Vector3(0,36,0),
			scale = Vector3(1.25,0.64,1),
		},
		nightstick = {
			strings = 
			"手柄顶端有尖刺的战锤.\n"..
			"圣职武器中比较血腥的一种.\n"..
			"因为电羊角的关系,\n"..
			"虽然是打击武器,却也带有电的效果.\n"..
			"对潮湿的敌人极为有效.\n"..
			STRINGS.RMB..":战技·忍耐:\n"..
			"借由意志坚定的祈祷,暂时提升强韧度,\n"..
			"同时减少受到的伤害.\n",	
			position = Vector3(0,36,0),
			scale = Vector3(1.25,0.64,1),
		},
		torch = {
			strings = 
			"能照亮暗处的火把.\n"..
			"棒子前端缠布,沾满油脂的物品.\n"..
			"需要以单手持拿,\n"..
			"是最简单的照明方法.\n"..
			"也可以作为给予火属性伤害的武器,\n"..
			"但因为原来就不是武器,故没有战技.\n",	
			position = Vector3(0,36,0),
			scale = Vector3(1.25,0.60,1),
		},
		spear = {
			strings = 
			"具有长柄的枪,长枪.\n"..
			"能从远处进行突刺.\n"..
			"攻击距离较长,是使用普及的武器,\n"..
			"但也是因为过长,有时反而难用.\n"..
			STRINGS.RMB..":战技·突击:\n"..
			"挥动长矛,摆出攻击架势,\n"..
			"一口气展开无情的突击.\n",	
			position = Vector3(0,36,0),
			scale = Vector3(1.25,0.64,1),
		},
		spear_wathgrithr = {
			strings = 
			"女武神使用的战斗矛.\n"..
			"长枪头为其特征.\n"..
			"主要是用于突刺,\n"..
			"因此如果普通人想要使用,\n"..
			"必须拥有相当的力气及敏捷.\n"..
			STRINGS.RMB..":战技·天空突刺:\n"..
			"抓紧武器,高高跃起\n"..
			"自上而下发动不可阻挡的突击.\n",	
			position = Vector3(0,36,0),
			scale = Vector3(1.25,0.64,1),
		},
		machine_badge = {
			strings = 
			"从巨擘的残骸中捡拾的徽章.\n"..
			"上面刻有骷髅形状的装饰,\n"..
			"应该是机械神教的教徽.\n"..
			"机械神教相信机械里寄宿着神圣的机魂,\n"..
			"由于机魂的存在,机器才能被使用.\n"..
			"但如今整个机械教被犹大架空.\n"..
			"魂已尽失,机械已然扭曲.\n",
			position = Vector3(0,36,0),
			scale = Vector3(1.3,0.64,1),
		},
		clocktower_key = {
			strings = 
			"利用柴薪中残存的力量,\n"..
			"打造出的时计塔的钥匙.\n"..
			"带着对黑星的期盼,\n"..
			"犹大独自倒吊于塔顶,\n"..
			"随后整座塔便被吸入混沌之中,\n"..
			"唯有这钥匙能让高塔重现.\n"..
			"由于作者咕咕咕的原因,\n"..
			"本道具暂时无实际用途.\n"..
			"  \n"..
			"  \n"..
			"  \n",
			position = Vector3(0,36,0),
			scale = Vector3(1.3,0.64,1),
		},
		chest_monster_hat = {
			strings = 
			"模仿宝箱的贪欲者头部,\n"..
			"如果你愿意的话,可以戴在头上.\n"..
			"能增加打倒敌人后获得的生命精华,\n"..
			"也能提升寻宝能力,\n"..
			"但是因为烙印的诅咒,生命值会持续降低.\n"..
			"贪欲者的样貌就是罪恶的烙印吧.\n",
			position = Vector3(0,36,0),
			scale = Vector3(1.3,0.64,1),
		},
		dark_halberd = {
			strings = 
			"以战斗用途为目的制作出的斧.\n"..
			"普通属性不会有相克问题,通用性高.\n"..
			"利用重量的攻击虽然攻击力高,\n"..
			"但是攻击间的空档大,是个重判断力的武器.\n"..
			"由于本质过于深邃黑暗,所以并没有战技.\n",	
			position = Vector3(0,33,0),
			scale = Vector3(1.3,0.44,1),
		},
		icey_axe_victorian = {
			strings = 
			"部分佣兵使用的轻便手斧.\n"..
			"刻有维多利亚风格的装饰,\n"..
			"佣兵们认为这装饰可以带来好运,\n"..
			"是胜利的象征.\n"..
			STRINGS.RMB..":战技·回旋斩:\n"..
			"侧身移动,切入敌军,\n"..
			"顺势使出极快的回旋斩.\n",	
			position = Vector3(0,36,0),
			scale = Vector3(1.25,0.6,1),
		},
		dragonslayer_trident = {
			strings = 
			"知名猎龙者“园丁”的草叉.\n"..
			"带有雷电的力量,是神的时代的武器.\n"..
			"以两手持叉使出浑身的力量,\n"..
			"能将武器深深刺入龙的身体里,\n"..
			"如果对方是人类,则会被贯穿.\n"..
			STRINGS.RMB..":战技·风暴落雷:\n"..
			"将草叉举至腰的高度,\n"..
			"在指定地点引出猛烈落雷.\n",	
			position = Vector3(0,36,0),
			scale = Vector3(1.25,0.6,1),
		},
		spider_higher_spear = {
			strings = 
			"缠绕主宰畸形身体的刃镰.\n"..
			"主宰的一生充斥着侵略,\n"..
			"这份执念在它死后也不曾停息.\n"..
			"用这具尸体改装成的刃镰,\n"..
			"能够收割敌人的生命,\n"..
			"也拥有强大的威慑力量.\n"..
			STRINGS.RMB..":战技·随兴狂王:\n"..
			"将畸形尸体敲向地面,使其暂时苏醒.\n"..
			"再以震地刺激苏醒的畸形物.\n"..
			"在畸形物咆哮之余,恐吓周围的生物.\n",
			position = Vector3(0,42,0),
			scale = Vector3(1.45,0.64,1),
		},
		yhorm_blade = {
			strings = 
			"通过灵魂炼成的轻量级尤姆柴刀.\n"..
			"据说尤姆常位于前锋,\n"..
			"而且装备一对大柴刀与大盾,\n"..
			"但是在他舍弃盾后,便在左手多拿一把.\n"..
			"那独特的击溃剑术与他晚年令人畏惧的战法,\n"..
			"随后成为众人传诵的话题.\n"..
			STRINGS.RMB..":战技·战吼:\n"..
			"借由大吼振奋自己,\n"..
			"可以暂时提升攻击力.\n"..
			"重劈攻击则会转变成溃击剑术.\n",
			position = Vector3(0,42,0),
			scale = Vector3(1.45,0.64,1),
		},
		yhorm_shield = {
			strings = 
			"过去巨人尤姆使用过的大盾.\n"..
			"可以提升装备者的强韧度.\n"..
			"据说为王的尤姆常独自位于前锋,\n"..
			"挥舞他的大柴刀,屹立不摇.\n"..
			"然而在他失去该守护的人之后,他舍弃了盾.\n"..
			STRINGS.RMB..":战技·盾牌冲击:\n"..
			"用全身的重量向敌人砸去,\n"..
			"将敌人砸开或使其失去平衡.\n",
			position = Vector3(0,42,0),
			scale = Vector3(1.45,0.64,1),
		},
		beeguard = {
			strings = 
			"跟随在女王蜂身边,\n"..
			"保护女王的守卫蜂.\n"..
			"其本性非常暴躁,富有攻击性,\n"..
			"但是倘若能够紧握其尾刺,\n"..
			"就能使其保持安静.\n"..
			STRINGS.RMB..":战技·毒刺导弹:\n"..
			"使劲摇晃抱怨之蜂,\n"..
			"趁其晕头转向之际,\n"..
			"丢给面前的敌人.\n",	
			position = Vector3(0,40,0),
			scale = Vector3(1.25,0.75,1),
		},
		armor_metalplate = {
			strings = 
			"下级骑士的铠甲,\n"..
			"以坚固的铁制成.\n"..
			"在铁铠甲之中属于厚重的一种,\n"..
			"具有高物理减伤率,但是非常重.\n"..
			"如果要佩戴,需以拥有高体力为前提.\n",	
			position = Vector3(0,35,0),
			scale = Vector3(1.25,0.6,1),
		},
		hat_metalplate = {
			strings = 
			"下级骑士的头盔,\n"..
			"以坚固的铁制成.\n"..
			"在铁头盔之中属于厚重的一种,\n"..
			"具有高物理减伤率,但是非常重.\n"..
			"如果要佩戴,需以拥有高体力为前提.\n",	
			position = Vector3(0,35,0),
			scale = Vector3(1.25,0.6,1),
		},
		knight_cutlass = {
			strings = 
			"以腌制的鱼为材料制作的短剑.\n"..
			"虽然听起来十分滑稽可笑,\n"..
			"但是由于用上等金属加工,\n"..
			"突刺的攻击力出奇的高,\n"..
			"是轻武器里比较好上手的一种.\n"..
			STRINGS.RMB..":战技·咸鱼突刺:\n"..
			"旋转短剑,摆出“咸鱼”的姿势.\n"..
			"猛地冲向面前的敌人.\n",	
			position = Vector3(0,36,0),
			scale = Vector3(1.25,0.6,1),
		},
		insanity_skull_wilson = {
			strings = 
			"受到启发的疯子的头骨,\n"..
			"佩戴在身上,可以提高洞察力.\n"..
			"  \n"..
			"  \n"..
			"  \n",
			position = Vector3(0,36,0),
			scale = Vector3(1.25,0.4,1),
		},
		storm_controlor = {
			strings = 
			"拥有“巨人杀手”别名的大剑.\n"..
			"剑身如今仍存有风暴的力量,\n"..
			"据说能将巨人打倒在地.\n"..
			"巨人尤姆拥有两把风暴管束者,\n"..
			"其中一把给予不信任他的人们,\n"..
			"另外一把在他成为薪王以前,\n"..
			"就托付给他的一位朋友.\n"..
			STRINGS.RMB..":战技·风暴之王:\n"..
			"进入准备攻击架势后,剑会带有风暴.\n"..
			"直到面对巨人时,才能理解它真正的价值.\n",	
			position = Vector3(0,42,0),
			scale = Vector3(1.45,0.64,1),
		},
		hunter_trusty_shooter = {
			strings = 
			"治愈教会猎人使用的特殊枪械.\n"..
			"通过专注力作为媒介,\n"..
			"无限制的喷射出碎裂火焰.\n"..
			"虽然不是最厉害的武器,\n"..
			"但是却十分轻便,射击速度也很快.\n"..
			"而速攻正是狩猎的一大解决方案.\n",	
			position = Vector3(0,42,0),
			scale = Vector3(1.45,0.64,1),
		},
		hunter_blunderbuss = {
			strings = 
			"工厂专门为猎人设计的喇叭枪,\n"..
			"享有“手持加农炮”的美名,\n"..
			"其巨大威力可想而知.\n"..
			"庞大的射击范围似乎能保证弹无虚发.\n"..
			"但是由于是落后的火药填充,\n"..
			"填充期间应该有被攻击的风险.\n",	
			position = Vector3(0,42,0),
			scale = Vector3(1.45,0.64,1),
		},
		useless_pegleg = {
			strings = 
			"一般的木制棍棒.\n"..
			"以野蛮的跳跃攻击为特征.\n"..
			"虽然很粗劣,但以非刀刃的打击武器而言,\n"..
			"是个方便的武器.\n"..
			"拥有击溃盾防御的力量.\n"..
			STRINGS.RMB..":战技·战吼:\n"..
			"借由大吼振奋自己,\n"..
			"可以暂时提升攻击力,\n"..
			"重攻击能使出专属的跳劈.\n",	
			position = Vector3(0,36,0),
			scale = Vector3(1.3,0.68,1),
		},
		useless_corkbat = {
			strings = 
			"大型的木制棍棒.\n"..
			"使用时需要有一定程度的臂力.\n"..
			"以野蛮的跳跃攻击为特征,\n"..
			"因为重量够重,容易击溃敌人的防御.\n"..
			STRINGS.RMB..":战技·战吼:\n"..
			"借由大吼振奋自己,\n"..
			"可以暂时提升攻击力,\n"..
			"重攻击能使出专属的跳劈.\n",	
			position = Vector3(0,36,0),
			scale = Vector3(1.25,0.64,1),
		},
		shovel = {
			strings = 
			"饥荒世界的农作器具之一.\n"..
			"有半身高的粗制铲子.\n"..
			"虽然说原来不是战斗用的道具,\n"..
			"但是尖锐边缘也能化为凶器.\n"..
			"只是制作工艺粗糙,难以长久使用.\n"..
			STRINGS.RMB..":战技·掘地求升:\n"..
			"紧握铲子铲入地下,\n"..
			"掀起厚实土块攻击敌人.\n",
			position = Vector3(0,36,0),
			scale = Vector3(1.3,0.68,1),
		},
		goldenshovel = {
			strings = 
			"饥荒世界的农作器具之一.\n"..
			"用黄金加工的豪华铁铲.\n"..
			"虽然说原来不是战斗用的道具,\n"..
			"但是居然有骑士将其作为武器,\n"..
			STRINGS.RMB..":战技·掘地求升:\n"..
			"紧握铲子铲入地下,\n"..
			"掀起厚实土块攻击敌人.\n",
			position = Vector3(0,36,0),
			scale = Vector3(1.3,0.68,1),
		},
		
		
		purging_stone = {
			strings = 
			"与小型头骨融为一体的灰色石块.\n"..
			"可以减少诅咒状态累积,恢复生命上限.\n"..
			"这是游魂之国隆道尔的宝藏,\n"..
			"他们会为了隐藏身份而使用.\n"..
			"据说有时也会出现选择伪装的身分,\n"..
			"放弃作为游魂的背叛者.\n",
			position = Vector3(0,36,0),
			scale = Vector3(1.3,0.68,1),
		},
		
		moss_clump_blue = {
			strings = 
			"具有发热效用的蓝色苔藓球.\n"..
			"可以减少寒气状态累积,解除冻伤状态.\n"..
			"如果寒气超过累积上限时,\n"..
			"将会受到伤害,也会陷入冻伤状态.\n"..
			"而冻伤状态会持续一段时间,\n"..
			"减伤率、精力恢复速度也会下降.\n"..
			"带有寒气的武器非常稀少,\n"..
			"据说大多数是来自冷冽谷.\n",
			position = Vector3(0,40,0),
			scale = Vector3(1.4,0.68,1),
		},
		
		moss_clump_purple = {
			strings = 
			"具有药效的紫色苔藓球.\n"..
			"可以减少毒素累积,解除中毒状态.\n"..
			"毒素超过累积上限后,便会陷入中毒状态,\n"..
			"而中毒状态会持续一段时间.\n"..
			"同时血量会持续减少.\n"..
			"毒非常地棘手,\n"..
			"如果要前往可能会中毒的地方,\n"..
			"先准备好这种苔藓球绝对不会吃亏.\n",
			position = Vector3(0,40,0),
			scale = Vector3(1.4,0.68,1),
		},
		
		moss_clump_purple_flower = {
			strings = 
			"具有强烈药效的带花苔藓球.\n"..
			"能够减少毒素与剧毒素累积,\n"..
			"并解除上述两种状态.\n"..
			"剧毒属于毒的一种,\n"..
			"除会大量减少血量以外,致死的危险性也高.\n"..
			"未带花的苔藓球对剧毒完全无效,\n"..
			"是否持有带花苔藓球,可能会影响生死.\n",
			position = Vector3(0,40,0),
			scale = Vector3(1.4,0.68,1),
		},
		
		moss_clump_red = {
			strings = 
			"用于除蛆的红色苔藓球.\n"..
			"可以减少出血状态累积.\n"..
			"出血状态会因受到利刃或刺针攻击而累积,\n"..
			"一旦超过累积上限,便会受到巨大伤害.\n"..
			"在陷入这种窘境前,最好先使用这种苔藓球.\n",
			position = Vector3(0,36,0),
			scale = Vector3(1.4,0.68,1),
		},
		
		handgun_albert = {
			strings = 
			"安布雷拉臭名昭著的管理者,\n"..
			"阿尔伯特·威斯克的武器.\n"..
			"枪膛可自动为子弹灌注特殊血清,\n"..
			"因此对B.O.W有强大杀伤力,\n"..
			"但是威斯克却在用来对付人类.\n"..
			STRINGS.RMB..":战技·速效灭菌弹:\n"..
			"发射一枚特殊的灭菌弹,\n"..
			"其成份能暂时阻断敌人的生命恢复.\n",
			
			position = Vector3(0,36,0),
			scale = Vector3(1.3,0.68,1),
		},
		
		hammer = {
			strings = 
			"饥荒世界的工作器具之一,\n"..
			"石制的大型槌.\n"..
			"原来是用来砸建筑的道具,\n"..
			"并不是战斗用品.\n"..
			STRINGS.RMB..":战技·追地:\n"..
			"用锤子狠狠砸向地面,\n"..
			"制造大范围的冲击.\n",
			
			position = Vector3(0,36,0),
			scale = Vector3(1.3,0.68,1),
		},
		
		cursed_blade = {
			strings = 
			"传闻属于众神的财宝之一,\n"..
			"却被神亲手降下诅咒的剑.\n"..
			"持有这把剑的凡人,\n"..
			"一旦受伤就会死去,\n"..
			"也无法在闪避中反击对手.\n"..
			STRINGS.RMB..":战技·赎罪:\n"..
			"从剑身释放出诅咒灵魂的气息,\n"..
			"吸引周围的敌人蜂拥而至.\n",
			
			position = Vector3(0,36,0),
			scale = Vector3(1.3,0.68,1),
		},
		
		hat_icey_chicken = {
			strings = 
			"生动仿造小鸡头部的帽子,\n"..
			"是制作出来的物品.\n"..
			
			"戴上这帽子之后.\n"..
			"能够周期性产生保护.\n"..
			"同时即使被敌人发现,\n"..
			"它们也会假装没看见.\n"..
			
			"此帽将授予菜鸡至极的玩家,\n"..
			"戴上这顶帽子的人会被残酷嘲弄,\n"..
			"自贬者,人恒贬之.\n",
			"  \n"..
			"  \n",
			
			position = Vector3(0,36,0),
			scale = Vector3(1.2,0.6,1),
		},
		
		flyhead_stone = {
			strings = 
			"在未知孤岛上冒险的狂妄者,\n"..
			"在岛之王座下找到的符文,\n"..
			"那人后来借此成为岛上国王.\n"..
			
			"将符文拿在身上,\n"..
			"按下 "..GetKeyFromConfigString("icey_flyhead").." 键即可发射头部.\n"..
			"可以用来拾取远处物品,\n"..
			"或者打乱敌人的攻势.\n"..
			"不知为何,符文的印记看着十分眼熟.\n"..
			"  \n"..
			"  \n"..
			"  \n",
			position = Vector3(0,45,0),
			scale = Vector3(1.22,0.68,1),
		},
		
		
		
		icey_boarrior_cinder = {
			strings = 
			"巨人尤姆残存的薪王柴薪.\n"..
			
			"薪王不肯回到王位,\n"..
			"那么,将柴薪拿回来就行.\n"..
			
			"孤独的巨人为了压制罪业火焰而成为薪王,\n"..
			"就算明白众人并不是真心唤他为王.\n"..
			"  \n"..
			"  \n"..
			"  \n",
			position = Vector3(0,45,0),
			scale = Vector3(1.28,0.4,1),
		},
		
		dark_antqueen_cinder = {
			strings = 
			"人脓们残余的薪王柴薪.\n"..
			
			"薪王不肯回到王位,\n"..
			"那么,将柴薪拿回来就行.\n"..
			
			"数千年前,黑色中庭的大门突然打开,\n"..
			"以人为名的脓包自深渊涌出.\n"..
			"  \n"..
			"  \n"..
			"  \n",
			position = Vector3(0,45,0),
			scale = Vector3(1.25,0.4,1),
		},
		
		metal_hulk_merge_cinder = {
			strings = 
			"和平行者残余的薪王柴薪.\n"..
			
			"薪王不肯回到王位,\n"..
			"那么,将柴薪拿回来就行.\n"..
			
			"和平行者因为抵抗末日\n"..
			"而得到成为薪王的资格.\n"..
			"却最终失去自我\n"..
			"将炮口对准了本该守护的人.\n"..
			"  \n"..
			"  \n"..
			"  \n",
			position = Vector3(0,45,0),
			scale = Vector3(1.25,0.5,1),
		},
		
		tigershark_duke_cinder = {
			strings = 
			"虎鲨公爵残余的薪王柴薪.\n"..
			
			"薪王不肯回到王位,\n"..
			"那么,将柴薪拿回来就行.\n"..
			
			"水本是与火相违背之物,\n"..
			"然而海洋的统治者的确是成为了薪王.\n"..
			"  \n"..
			"  \n"..
			"  \n",
			position = Vector3(0,45,0),
			scale = Vector3(1.25,0.5,1),
		},
		
		icey_forge_armorlight = {
			strings = 
			"用普通的芦苇编制成的羽衣,\n"..
			"芦苇带有略微的魔力.\n"..
			"能够稍微加快技能冷却速率,\n"..
			"重量也很轻,可以降低体力值消耗.\n"..
			"但是不能指望抵挡太多攻击.\n",	
			position = Vector3(0,35,0),
			scale = Vector3(1.25,0.6,1),
		},
		
		icey_forge_armorlightspeed = {
			strings = 
			"用芦苇精编而成的羽衣,\n"..
			"耐穿并且方便行动.\n"..
			"能穿梭于各个战场,撑过征战旅途.\n"..
			"深受广大佣兵们的喜爱.\n",	
			position = Vector3(0,35,0),
			scale = Vector3(1.25,0.6,1),
		},
		
		icey_forge_armormedium = {
			strings = 
			"用硬木制成的精美盔甲,\n"..
			"虽然普通,但是泛用性高,\n"..
			"是较为均衡的盔甲之一.\n"..
			"据说其灵感来源于藤甲.\n",	
			position = Vector3(0,35,0),
			scale = Vector3(1.25,0.6,1),
		},
		
		icey_forge_armormediumdamager = {
			strings = 
			"以硬质木甲为基础,\n"..
			"添加尖牙装饰而成的铠甲.\n"..
			"尖牙象征着斗士,\n"..
			"能够鼓舞士气,激发战斗潜能.\n"..
			"为此牺牲了部分防御性能.\n",	
			position = Vector3(0,35,0),
			scale = Vector3(1.25,0.6,1),
		},
		
		icey_forge_armormediumrecharger = {
			strings = 
			"以硬质木甲为基础,\n"..
			"添加缎带装饰而成的铠甲.\n"..
			"缎带象征着魔法,\n"..
			"能够提升魔力,加快冷却速率.\n"..
			"为此牺牲了部分防御性能.\n",	
			position = Vector3(0,35,0),
			scale = Vector3(1.25,0.6,1),
		},
		
		icey_forge_armorheavy = {
			strings = 
			"用细长的石片编成的锁子铠甲,\n"..
			"在制作难度、减伤率、重量之间有良好平衡.\n"..
			"是相当普及的防具,\n"..
			"骑士喜欢华而不实的盔甲.\n"..
			"但对于战场上的战士而言就无关紧要了.\n",
			position = Vector3(0,35,0),
			scale = Vector3(1.25,0.6,1),
		},
		
		icey_forge_armorextraheavy = {
			strings = 
			"被比喻成巨岩的重装盔甲,\n"..
			"以极高防御力受到称赞,但非常沉重.\n"..
			"信奉“坚石”哈维尔的战士们,\n"..
			"绝对不会害怕、不会退缩.\n"..
			"一定会将为敌者全部粉碎.",
			position = Vector3(0,35,0),
			scale = Vector3(1.25,0.6,1),
		},
		
		icey_forge_armor_hprecharger = {
			strings = 
			"来自熔炉的魔法师高级服装.\n"..
			"使用被魔法强化的金色材料制成,\n"..
			"同时兼顾了防御力与轻便性.\n"..
			"也可以加深穿戴者对“法”的认知.\n",
			position = Vector3(0,35,0),
			scale = Vector3(1.25,0.6,1),
		},
		
		icey_forge_armor_hpdamager = {
			strings = 
			"装点着豪华锯齿的金色盔甲,\n"..
			"戴上这铠甲后将变得情绪高昂.\n"..
			"会有拼死战斗的渴望.\n"..
			"攻击也好战技也罢,\n"..
			"一定会将为敌者全部撕碎.",
			position = Vector3(0,35,0),
			scale = Vector3(1.25,0.6,1),
		},
		
		icey_forge_feathercrown = {
			strings = 
			"使用轻羽制作的头饰,\n"..
			"顾名思义,重量非常的轻.\n"..
			"穿戴者能像鸟一样速度飞快.\n",
			position = Vector3(0,35,0),
			scale = Vector3(1.25,0.6,1),
		},
		
		icey_forge_lightdamager = {
			strings = 
			"装饰有双角的斗士头盔,\n"..
			"能够给予穿戴者一些勇气.\n"..
			"因此能稍微提高攻击力,\n",
			position = Vector3(0,35,0),
			scale = Vector3(1.25,0.6,1),
		},
		
		icey_forge_recharger = {
			strings = 
			"用漂亮的水晶打造的头饰.\n"..
			"熔炉的法师习惯佩戴水晶饰物,\n"..
			"其特征是法术冷却时间更短.\n",
			position = Vector3(0,35,0),
			scale = Vector3(1.25,0.6,1),
		},
		
		--icey_forge_healingflower
		--icey_forge_tiaraflowerpetals
		
		icey_forge_strongdamager = {
			strings = 
			"熔炉的工匠打造的高级战术头盔,\n"..
			"盔甲覆盖面变大,提供了更好的防护.\n"..
			"造型也更加孔武有力.\n"..
			"是为角斗士中的佼佼者量身打造的.\n",
			position = Vector3(0,35,0),
			scale = Vector3(1.25,0.6,1),
		},
		
		icey_forge_crowndamager = {
			strings = 
			"装饰极其豪华的战斗头盔,\n"..
			"与其说是头盔,不如说是皇冠.\n"..
			"在战斗性能与美观之间有着卓越的平衡.\n"..
			"只有王牌竞技者才配戴上这副头盔.\n",
			position = Vector3(0,35,0),
			scale = Vector3(1.25,0.6,1),
		},
		
		icey_forge_healinggarland = {
			strings = 
			"用盛开的绿花草编成的花冠,\n"..
			"可以赋予穿戴者勃勃生机.\n"..
			"无论背负的伤有多么重,\n"..
			"只要时间允许,花环就能治愈.\n",
			position = Vector3(0,35,0),
			scale = Vector3(1.25,0.6,1),
		},
		
		icey_forge_eyecirclet = {
			strings = 
			"来自熔炉的大贤者头饰,\n"..
			"熔炉崇尚钢铁与火一般角斗.\n"..
			"因此熔炉的魔法师并不能算多,\n"..
			"能被称作大贤者的人,更是少之又少.\n",
			position = Vector3(0,35,0),
			scale = Vector3(1.25,0.6,1),
		},
		
	},
	ENGLISH = {},
}



AddClassPostConstruct("widgets/hoverer",function(self)
	self.background = self.text:AddChild(Image("images/fepanels.xml", "panel_topmods.tex"))
	self.background:SetPosition(Vector3(0,0,0))
	self.background:SetTint(1,1,1,0.5)
	self.background:SetScale(1.5,0.6,1)
	self.background:SetClickable(false) 
	self.background:MoveToBack() 
	
	local function ShowMoreDetials(str,target)
		if target and target.prefab and ExtraText[string.upper(TUNING.ICEY_LANGUAGE)][target.prefab] then 
			if ExtraText[string.upper(TUNING.ICEY_LANGUAGE)][target.prefab].strings then 
				str = str.."\n"..ExtraText[string.upper(TUNING.ICEY_LANGUAGE)][target.prefab].strings
			end
			if ExtraText[string.upper(TUNING.ICEY_LANGUAGE)][target.prefab].position then 
				self.background:SetPosition(ExtraText[string.upper(TUNING.ICEY_LANGUAGE)][target.prefab].position)
			else
				self.background:SetPosition(Vector3(0,0,0))
			end
			if ExtraText[string.upper(TUNING.ICEY_LANGUAGE)][target.prefab].scale then 
				self.background:SetScale(ExtraText[string.upper(TUNING.ICEY_LANGUAGE)][target.prefab].scale:Get())
			else
				self.background:SetScale(1,1,1)
			end
		end
		return str
	end 

	local old_SetString = self.text.SetString
	self.text.SetString = function(text,str)
		local player = self.owner
		local target = TheInput:GetHUDEntityUnderMouse()
		if target ~= nil then
			target = target.widget ~= nil and target.widget.parent ~= nil and target.widget.parent.item 
		else
			target = TheInput:GetWorldEntityUnderMouse()
		end
		if target and target.replica and target.replica.darksoulweapon then 
			local property = target.replica.darksoulweapon:GetProperty()
			local level = target.replica.darksoulweapon:GetLevel()
			if property and PropertyStrings[property] then 
				str = str.."\n"..PropertyStrings[property].."质变\n"
			end
			if level and level > 0 then 
				str = str.."等级:"..level.."\n"
			end
		end
		
		if target 
			and ExtraText[string.upper(TUNING.ICEY_LANGUAGE)][target.prefab] 
			and target.replica.inventoryitem 
			and target.replica.inventoryitem:IsHeldBy(player) then 
		
			if TheInput:IsKeyDown(KEY_LCTRL) then 
				str = ShowMoreDetials(str,target)
				self.background:Show()
			else
				str = str.."\n左CTRL:详细查看\n"
				self.background:Hide()
			end 
			self.text:SetPosition(Vector3(0,80,0))
		else
			self.background:Hide()
		end
		
		return old_SetString(text,str)
	end
end) 
--c_findnext("spear").components.darksoulweapon:SetLevel(5) 
--c_findnext("spear").components.darksoulweapon:SetProperty("fire") 

------------------For Player----------------

local MaxStamina = {
	icey = 200,
	
	wilson = 250,
	willow = 225,
	wes = 175,
	waxwell = 200,
	wendy = 225,
	wickerbottom = 225,
	webber = 275,
	winona = 250,
	woodie = 250,
	wx78 = 250,
	wolfgang = 275,
	wathgrithr = 280,
	wortox = 250,
	warly = 260,
}

local function CanStamina(inst)
	if inst.components.stamina and inst.components.stamina:GetPercent() <= 0.2 then 
		return false
	else
		return true 
	end 
end 

local function DoToolWorkWothMulti(act, workaction,multi,numoverride)
    if act.target.components.workable ~= nil and
        act.target.components.workable:CanBeWorked() and
        act.target.components.workable:GetWorkAction() == workaction then
        act.target.components.workable:WorkedBy(
            act.doer,
            numoverride or ((   act.invobject ~= nil and
                act.invobject.components.tool ~= nil and
                act.invobject.components.tool:GetEffectiveness(workaction)
            ) or
            (   act.doer ~= nil and
                act.doer.components.worker ~= nil and
                act.doer.components.worker:GetEffectiveness(workaction)
            ) or
            1) * multi
        )
        return true
    end
    return false
end

local old_CHOP_fn = ACTIONS.CHOP.fn
ACTIONS.CHOP.fn = function(act)
	if act.doer and CanStamina(act.doer) then 
		return old_CHOP_fn(act)
	else
		return DoToolWorkWothMulti(act, ACTIONS.CHOP,1,1) 
	end
end 

local old_MINE_fn = ACTIONS.MINE.fn
ACTIONS.MINE.fn = function(act)
	if act.doer and CanStamina(act.doer) then 
		return old_MINE_fn(act)
	else
		return DoToolWorkWothMulti(act, ACTIONS.MINE,0.1)  
	end
end 

local old_HAMMER_fn = ACTIONS.HAMMER.fn
ACTIONS.HAMMER.fn = function(act)
	if act.doer and CanStamina(act.doer) then 
		return old_HAMMER_fn(act)
	else
		return DoToolWorkWothMulti(act, ACTIONS.HAMMER,0.5)   
	end
end 

local old_DIG_fn = ACTIONS.DIG.fn
ACTIONS.DIG.fn = function(act)
	if act.doer and CanStamina(act.doer) then 
		return old_DIG_fn(act)
	else
		return false 
	end
end 

--CANTUNEQUIP
local old_UNEQUIP_fn = ACTIONS.UNEQUIP.fn  
ACTIONS.UNEQUIP.fn = function(act)
	if act.invobject and not act.invobject:HasTag("CANTUNEQUIP") then 
		return old_UNEQUIP_fn(act)
	else
		return false 
	end
end 


local MaxFocus = {
	icey = 200,
	
	wilson = 225,
	willow = 200,
	wes = 175,
	waxwell = 250,
	wendy = 225,
	wickerbottom = 250,
	webber = 180,
	winona = 200,
	woodie = 200,
	wx78 = 200,
	wolfgang = 200,
	wathgrithr = 200,
	wortox = 275,
	warly = 225,
}



--stamina
AddPlayerPostInit(function(inst)
	
	inst.AnimState:AddOverrideBuild("player_pistol")
	inst.AnimState:AddOverrideBuild("player_actions_speargun")
	inst.AnimState:AddOverrideBuild("player_mount_actions_speargun")
	inst.AnimState:AddOverrideBuild("player_actions_roll")
	

	
	
	if not TheWorld.ismastersim then
		
		return inst
	end
	
	--inst:AddComponent("darksouldebuffable")
	
	

	
	inst:AddComponent("stamina")
	if MaxStamina[inst.prefab] then 
		inst.components.stamina:SetMax(MaxStamina[inst.prefab])
	end
	
	inst:AddComponent("focus")
	if MaxFocus[inst.prefab] then 
		inst.components.focus:SetMax(MaxFocus[inst.prefab])
	end
	
	inst:ListenForEvent("attacked",function(inst,data)
		local redirected = data.redirected
		local dmg = data.damage or 0
		
		if not redirected then  
			if inst.components.stamina then 
				if inst.components.inventory and inst.components.inventory:EquipHasTag("hat_icey_chicken") then 
					return 
				end 
				if inst.prefab == "icey" and inst.harvell_coser == 1 then 
					inst.components.stamina:DoDelta(-dmg*0.3)
					inst.components.stamina:Pause(0.5) 
				else
					inst.components.stamina:DoDelta(-dmg)
					inst.components.stamina:Pause(2) 
				end 
			end
		end 
	end)
	
	--wortox是一名咒术师
	if inst.prefab == "wortox" then 
		inst:AddTag("pyromancy_master")
		local old_OnNewSpawn = inst.OnNewSpawn or function()  end 
		inst.OnNewSpawn = function(self)
			old_OnNewSpawn(self) 
            self.components.inventory:GiveItem(SpawnPrefab("pyromancy_flame"))
			self.components.inventory:GiveItem(SpawnPrefab("pyromancy_fireball"))
			self.components.inventory:GiveItem(SpawnPrefab("axe"))
		end 
		
		inst:ListenForEvent("oneatsoul",function(self,data)
			local soul = data.soul
			if soul and soul:IsValid() then 
				if self.components.focus then 
					self.components.focus:DoDelta(25)
				end
				if soul:HasTag("icey_boss_soul") then 
					self:DoTaskInTime(0,function()
						if self.components.health then 
							self.components.health:DoDelta(200)
						end
						if self.components.sanity then 
							self.components.sanity:DoDelta(200)
						end
						if self.components.hunger then 
							self.components.hunger:DoDelta(200)
						end
						if self.components.stamina then 
							self.components.stamina:DoDelta(200)
						end
						if self.components.focus then 
							self.components.focus:DoDelta(200)
						end
					end) 
				end
			end 
		end)	
	end
	
	--wilson是一名骑士
	if inst.prefab == "wilson" then 
		inst:AddTag("knight_master")
		local old_OnNewSpawn = inst.OnNewSpawn or function()  end 
		inst.OnNewSpawn = function(self)
			old_OnNewSpawn(self) 
            self.components.inventory:GiveItem(SpawnPrefab("armor_metalplate"))
			self.components.inventory:GiveItem(SpawnPrefab("hat_metalplate"))
			self.components.inventory:GiveItem(SpawnPrefab("halberd"))
		end 
	end
	
	--woodie是一名猎人
	if inst.prefab == "woodie" then 
		inst:AddTag("hunter_master")
		inst:AddComponent("icey_hunter")
		--inst.AnimState:AddOverrideBuild("icey_hunter_override")
		--inst.AnimState:OverrideSkinSymbol("arm_lower","icey_hunter_override","arm_lower")
		--inst.AnimState:OverrideSkinSymbol("arm_upper","icey_hunter_override","arm_upper")
		--inst.AnimState:OverrideSkinSymbol("torso","icey_hunter_override","torso")
		local old_OnNewSpawn = inst.OnNewSpawn or function()  end 
		inst.OnNewSpawn = function(self)
			old_OnNewSpawn(self) 
            self.components.inventory:GiveItem(SpawnPrefab("hunter_trusty_shooter"))
			self.components.inventory:GiveItem(SpawnPrefab("icey_hunter_hat1"))
			self.components.inventory:GiveItem(SpawnPrefab("icey_hunter_clothing1"))
		end 
		
	end
	
	--warly是一个垃圾
	if inst.prefab == "warly" then 
		local function CheckPrefers(inst,food)
			return food and (string.find(food.prefab,"dried") or string.find(food.prefab,"cooked"))
				and not food:HasTag("monstermeat")
				and food.components.edible.foodtype ~= FOODTYPE.RAW
		end 
		inst.components.eater:SetCheckPrefersToEat(CheckPrefers)
	end
	
end)

AddPrefabPostInitAny(function(inst)
	if not TheWorld.ismastersim then
		return inst
	end
	
	if inst.components.combat and not inst.components.darksouldebuffable then 
		inst:AddComponent("darksouldebuffable")
	end 
end)

local StaminaBadge = require("widgets/staminabadge")
local FocusBadge = require("widgets/focusbadge")
local IceyIronLordBadge = require("widgets/iceyironlordbadge")
local DarkSoulDebuffList = require("widgets/darksouldebufflist")

local function CloseTo(underHUD,TargetHUD,dist)
	dist = dist or 1 
	return Vector3(underHUD.UITransform:GetWorldPosition()):Dist(TargetHUD:GetWorldPosition()) <= dist
end 

AddClassPostConstruct("widgets/statusdisplays",function(self)
	self.staminabadge = self:AddChild(StaminaBadge(self.owner))
    self.staminabadge:SetPosition(-62,-52, 0)
	self.staminabadge:SetTooltip("鼠标放在本控件上\n鼠标按住拖动位置\n按空格键复位")
	
	self.focusbadge = self:AddChild(FocusBadge(self.owner))
    self.focusbadge:SetPosition(0,-52, 0)
	self.focusbadge:SetTooltip("鼠标放在本控件上\n鼠标按住拖动位置\n按空格键复位")
	
	self.iceyironlordbadge = self:AddChild(IceyIronLordBadge(self.owner))
    self.iceyironlordbadge:SetPosition(-62,-139, 0)
	self.iceyironlordbadge:SetTooltip("鼠标放在本控件上\n鼠标按住拖动位置\n按空格键复位")
	
	TheInput:AddKeyDownHandler(KEY_SPACE, function()
		local underHUD = TheInput:GetHUDEntityUnderMouse() 
		if underHUD and underHUD.GUID then 
			if CloseTo(underHUD,self.staminabadge) then 
				if self.beaverness then 
					self.staminabadge:SetPosition(-124,35, 0)
				else
					self.staminabadge:SetPosition(-62,-52, 0)
				end
			elseif CloseTo(underHUD,self.focusbadge) then
				self.focusbadge:SetPosition(0,-52, 0)
			elseif CloseTo(underHUD,self.iceyironlordbadge) then
				self.iceyironlordbadge:SetPosition(-62,-139, 0)
			end
		end
	end)
	
	if self.beaverness then 
		self.staminabadge:SetPosition(-124,35, 0)
		self.moisturemeter:SetPosition(-124,-52,0)
	else
		self.moisturemeter:SetPosition(-124,-8.5,0)
	end 
end)
--c_posion(ThePlayer)
AddClassPostConstruct("widgets/controls",function(self,owner)
	self.DarkSoulDebuffList = self:AddChild(DarkSoulDebuffList(self.owner))
	self.DarkSoulDebuffList:SetPosition(200,125)
end)


AddPrefabPostInit("explosivehit", function(inst)
	inst:DoTaskInTime(3, inst.Remove)
end)

local function AddAoetargetingClient(...)
	return IceyWeaponSkillUtil.AddAoetargetingClient(...)
end

local function AddAoetargetingServer(...)
	return IceyWeaponSkillUtil.AddAoetargetingServer(...)
end



AddPrefabPostInit("axe", function(inst)
	AddAoetargetingClient(inst,"line",{"iceyweaponskill_taunt"},15)
	if not TheWorld.ismastersim then
		return inst
	end
	
	inst.components.weapon:SetDamage(30)
	
	AddAoetargetingServer(inst,function(inst,doer,pos)
		if IceyUtil.DefaultCostFn(doer,{focus = 5}) then 
			inst.components.rechargeable:StartRecharge()
			doer.components.debuffable:AddDebuff("taunt_axe","icey_normal_debuff")
			
			local fx = doer:SpawnChild("battlestandard_buff_fxs")
			fx:Play("attack_fx3")
			local buff = doer.components.debuffable:GetDebuff("taunt_axe")
			buff:Init({damage_multi = 1.10,buff_fx = fx,duration = 10})
			
			local battlecryfx = doer:SpawnChild("icey_battlecry_fxs")	
			battlecryfx:DoTaskInTime(2+math.random(),battlecryfx.RemoveBattleCryFX)		
		end 
	end,nil,15)
end) 

AddPrefabPostInit("goldenaxe", function(inst)
	AddAoetargetingClient(inst,"line",{"iceyweaponskill_taunt"},15)
	if not TheWorld.ismastersim then
		return inst
	end
	
	inst.components.weapon:SetDamage(34)
	
	AddAoetargetingServer(inst,function(inst,doer,pos)
		if IceyUtil.DefaultCostFn(doer,{focus = 8}) then 
			inst.components.rechargeable:StartRecharge()
			doer.components.debuffable:AddDebuff("taunt_goldenaxe","icey_normal_debuff")
			
			local fx = doer:SpawnChild("battlestandard_buff_fxs")
			fx:Play("attack_fx3")
			local buff = doer.components.debuffable:GetDebuff("taunt_goldenaxe")
			buff:Init({damage_multi = 1.15,buff_fx = fx,duration = 15})
			
			local battlecryfx = doer:SpawnChild("icey_battlecry_fxs")	
			battlecryfx:DoTaskInTime(2+math.random(),battlecryfx.RemoveBattleCryFX)
		end 
	end,nil,25)
end)

AddPrefabPostInit("pickaxe", function(inst)
	AddAoetargetingClient(inst,"line",{"iceyweaponskill_taunt"},15)
	if not TheWorld.ismastersim then
		return inst
	end
	
	inst.components.weapon:SetDamage(30)
	
	AddAoetargetingServer(inst,function(inst,doer,pos)
		if IceyUtil.DefaultCostFn(doer,{focus = 5}) then 
			inst.components.rechargeable:StartRecharge()
			doer.components.debuffable:AddDebuff("taunt_pickaxe","icey_normal_debuff")
			
			local fx = doer:SpawnChild("battlestandard_buff_fxs")
			fx:Play("heal_fx")
			local buff = doer.components.debuffable:GetDebuff("taunt_pickaxe")
			buff:Init({stamina_consume_multi = 0.90,stamina_recover_multi = 1.10,buff_fx = fx,duration = 10})		
		end 
	end,nil,15)
end) 

AddPrefabPostInit("goldenpickaxe", function(inst)
	AddAoetargetingClient(inst,"line",{"iceyweaponskill_taunt"},15)
	if not TheWorld.ismastersim then
		return inst
	end
	
	inst.components.weapon:SetDamage(34)
	
	AddAoetargetingServer(inst,function(inst,doer,pos)
		if IceyUtil.DefaultCostFn(doer,{focus = 8}) then 
			inst.components.rechargeable:StartRecharge()
			doer.components.debuffable:AddDebuff("taunt_goldenpickaxe","icey_normal_debuff")
			
			local fx = doer:SpawnChild("battlestandard_buff_fxs")
			fx:Play("heal_fx")
			local buff = doer.components.debuffable:GetDebuff("taunt_goldenpickaxe")
			buff:Init({stamina_consume_multi = 0.75,stamina_recover_multi = 1.25,buff_fx = fx,duration = 10})		
		end 
	end,nil,25)
end)

AddPrefabPostInit("hambat", function(inst)
	AddAoetargetingClient(inst,"line",{"iceyweaponskill_taunt"},15)
	if not TheWorld.ismastersim then
		return inst
	end
	AddAoetargetingServer(inst,function(inst,doer,pos)
		if IceyUtil.DefaultCostFn(doer,{focus = 8}) then 
			inst.components.rechargeable:StartRecharge()
			doer.components.debuffable:AddDebuff("taunt_hambat","icey_normal_debuff")
			
			local fx = doer:SpawnChild("battlestandard_buff_fxs")
			fx:Play("attack_fx3")
			local buff = doer.components.debuffable:GetDebuff("taunt_hambat")
			buff:Init({damage_multi = 1.20,hunger_multi = 10.00,buff_fx = fx,duration = 10})	
			
			local battlecryfx = doer:SpawnChild("icey_battlecry_fxs")	
			battlecryfx:DoTaskInTime(2+math.random(),battlecryfx.RemoveBattleCryFX)	
		end 
	end,nil,25)
end)

AddPrefabPostInit("nightstick", function(inst)
	AddAoetargetingClient(inst,"line",{"iceyweaponskill_pray"},15)
	if not TheWorld.ismastersim then
		return inst
	end
	AddAoetargetingServer(inst,function(inst,doer,pos)
		if IceyUtil.DefaultCostFn(doer,{focus = 8}) then 
			inst.components.rechargeable:StartRecharge()
			doer.components.debuffable:AddDebuff("pray_nightstick","icey_normal_debuff")
			
			local fx = doer:SpawnChild("battlestandard_buff_fxs")
			fx:Play("defend_fx")
			local buff = doer.components.debuffable:GetDebuff("pray_nightstick")
			buff:Init({stamina_consume_multi = 0.75,damagetaken_multi = 0.75,buff_fx = fx,duration = 10})	
		end 
	end,nil,25)
end)

AddPrefabPostInit("spear", function(inst)
	AddAoetargetingClient(inst,"line",{"aoeweapon_lunge"},6)
	inst.components.aoetargeting:SetAlwaysValid(false)
	if not TheWorld.ismastersim then
		return inst
	end
	AddAoetargetingServer(inst,function(inst,doer,pos)
		if IceyUtil.DefaultCostFn(doer,{stamina = 20,focus = 10}) then 
			inst.components.rechargeable:StartRecharge()
			doer:PushEvent("combat_lunge",{targetpos = pos,weapon = inst})
		end 
	end,"lunge",15)
end)

AddPrefabPostInit("spear_wathgrithr", function(inst)
	AddAoetargetingClient(inst,"point",{"aoeweapon_leap","superjump"},15)
	if not TheWorld.ismastersim then
		return inst
	end
	AddAoetargetingServer(inst,function(inst,doer,pos)
		local multi = doer:HasTag("valkyrie") and 1 or 3
		if IceyUtil.DefaultCostFn(doer,{stamina = 20 * multi,focus = 12 * multi}) then 
			inst.components.rechargeable:StartRecharge()
			doer:PushEvent("combat_superjump", {targetpos = pos,weapon = inst})
		end 
	end,"leap",20)
end)

AddPrefabPostInit("beeguard", function(inst)
	AddAoetargetingClient(inst,"line",{"throw_line"},12)
	
	MakeFeedableSmallLivestockPristine(inst)
	
	if not TheWorld.ismastersim then
		return inst
	end
	
	inst:AddComponent("inventoryitem")
    inst.components.inventoryitem.nobounce = true
    inst.components.inventoryitem.canbepickedup = false
    inst.components.inventoryitem.canbepickedupalive = true
	inst.components.inventoryitem.imagename = "beeguard"
	inst.components.inventoryitem.atlasname = "images/inventoryimages/beeguard.xml"
	
	inst:AddComponent("equippable")
    inst.components.equippable:SetOnEquip(function(inst,owner)
		owner.AnimState:OverrideSymbol("swap_object", "swap_beeguard", "swap_beeguard")
		owner.AnimState:Show("ARM_carry")
		owner.AnimState:Hide("ARM_normal")
		inst:EnableBuzz(true) 
	end)
    inst.components.equippable:SetOnUnequip(function(inst,owner)
		owner.AnimState:Hide("ARM_carry")
		owner.AnimState:Show("ARM_normal")
		inst:EnableBuzz(false) 
	end)
	
	inst:AddComponent("weapon")
    inst.components.weapon:SetDamage(34)
	inst.components.weapon:SetOnAttack(function(inst,attacker,target)
		inst.SoundEmitter:PlaySound(inst.sounds.hit)
	end) 
	
	inst:AddComponent("lootdropper")
    --inst.components.lootdropper:AddRandomLoot("honey", 1)
    --inst.components.lootdropper:AddRandomLoot("stinger", 5)   
    --inst.components.lootdropper.numrandomloot = 1
	
	inst:AddComponent("workable")
    inst.components.workable:SetWorkAction(ACTIONS.NET)
    inst.components.workable:SetWorkLeft(1)
    inst.components.workable:SetOnFinishCallback(function(inst, worker)
		inst:PushEvent("detachchild")
		inst:EnableBuzz(false) 
		if worker.components.inventory ~= nil then
			worker.components.inventory:GiveItem(inst, nil, inst:GetPosition())
		end 
    end)
	
	inst:AddComponent("ly_projectile")
	inst.components.ly_projectile.damage = 0
	inst.components.ly_projectile:SetRange(math.random()*5 + 10)
	inst.components.ly_projectile:SetSpeed(15)
	inst.components.ly_projectile:SetCanHit(function(inst,owner,target)
		return IceyUtil.CanAttack(target,owner) and target ~= inst
	end)
	inst.components.ly_projectile:SetOnThrownFn(function(inst)
		inst.AnimState:PlayAnimation("walk_pre")
		inst.AnimState:PushAnimation("walk_loop",true)
	end)
	inst.components.ly_projectile:SetOnHitFn(function(inst,owner,target)
		inst:RestartBrain()
		target.components.combat:GetAttacked(owner,34)
		inst.components.combat:GetAttacked(target,34)
		inst.components.locomotor.walkspeed = TUNING.BEEGUARD_SPEED
		SpawnAt("bee_poof_big",inst:GetPosition())
	end)
	inst.components.ly_projectile:SetOnMissFn(function(inst)
		inst:RestartBrain()
		inst.components.locomotor.walkspeed = TUNING.BEEGUARD_SPEED
		SpawnAt("bee_poof_small",inst:GetPosition())
	end)
	
	MakeFeedableSmallLivestock(inst, TUNING.TOTAL_DAY_TIME*2, 
	function(inst)
		inst.sg:GoToState("idle")
		inst:EnableBuzz(false) 
	end, 
	function(inst)
		inst.sg:GoToState("idle")
		if inst.components.workable ~= nil then
			inst.components.workable:SetWorkLeft(1)
		end
		if inst.brain ~= nil then
			inst.brain:Start()
		end
		if inst.sg ~= nil then
			inst.sg:Start()
		end
		inst:EnableBuzz(true) 
	end)
	
	AddAoetargetingServer(inst,function(inst,doer,pos)
		if IceyUtil.DefaultCostFn(doer,{stamina = 12}) then 
			doer.components.inventory:DropItem(inst)
			inst:StopBrain()
			inst.components.locomotor.walkspeed = 15		
			inst.components.ly_projectile:Throw(doer,pos,true,nil,true)
			inst:EnableBuzz(true) 
			inst.components.rechargeable:StartRecharge()
		end 
	end,nil,1)
	
	--inst.SoundEmitter:KillAllSounds()
end) 


AddPrefabPostInit("glasscutter", function(inst)
	inst:AddTag("vacuum_sword")
	
	if not TheWorld.ismastersim then
		return inst
	end
	
	if inst.components.finiteuses then 
		inst.components.finiteuses:SetMaxUses(200)
		inst.components.finiteuses:SetUses(200)
	end 
	inst.components.weapon:SetDamage(4)
end) 

AddPrefabPostInit("lucy", function(inst)

	inst.Transform:SetSixFaced()
	
	inst.nameoverride = "lavaarena_lucy"
    inst.AnimState:SetBank("lavaarena_lucy")
    inst.AnimState:SetBuild("lavaarena_lucy")
    inst.AnimState:PlayAnimation("idle")

	AddAoetargetingClient(inst,"line",{"throw_line","sharp","chop_attack"})

	if not TheWorld.ismastersim then
        return inst
    end
	
	local function MakeNormal(inst)
		inst:RemoveTag("NOCLICK")
		inst.AnimState:SetBank("lavaarena_lucy")
		inst.AnimState:SetBuild("lavaarena_lucy")
		inst.Physics:Stop()
		MakeInventoryPhysics(inst)
		inst.components.inventoryitem.canbepickedup = true
		inst.components.talker:StopIgnoringAll(inst) 
		inst.AnimState:SetMultColour(1,1,1,1)
		inst.LastAttackTarget = nil 
		inst.MultiHitTime = 0
	end
	
	local function Return(inst, attacker, inocean)
		attacker.components.combat.ignorehitrange = false
		if not inocean then inst.Physics:SetMotorVel(5, 0, 0) end
		inst:DoTaskInTime(FRAMES*15, function()
			--if (inocean and not inst:IsOnValidGround()) or inst:IsOnValidGround() then
				if attacker and attacker.prefab == "woodie" then
					inst.Physics:Stop()
					inst.AnimState:SetMultColour(0,0,0,0)
					inst.returnfrompos = inst:GetPosition()
					if not inocean then SpawnPrefab("lucy_transform_fx").Transform:SetPosition(inst:GetPosition():Get()) end
					inst.projectileowner = nil
					inst:DoTaskInTime(FRAMES*12, function()
						--if (inocean and not inst:IsOnValidGround()) or inst:IsOnValidGround() then
							if attacker and attacker.entity and attacker.entity:IsValid() and attacker.entity:IsVisible() then
								if attacker.sg:HasStateTag("idle") then inst.projectileowner = attacker end
								if attacker.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS) then 
									attacker.components.inventory:GiveItem(inst)
								else
									attacker.components.inventory:Equip(inst)
								end 
									
								local origin_pos = inst.returnfrompos or inst:GetPosition() or Vector3(0,0,0)
								attacker:SpawnChild("riledlucyspin_fx"):SetOrigin(origin_pos:Get())
								if not attacker.sg.statemem.playedfx then
									SpawnPrefab("lucy_transform_fx").entity:AddFollower():FollowSymbol(attacker.GUID, "swap_object", 50, -25, -1)
								end
							else
								if inocean then
									inst:DoTaskInTime(2, function(inst)
										inst:PutBackOnGround()
										local pos = inst:GetPosition()
										inst.Transform:SetPosition(pos.x, 12, pos.z)
										MakeNormal(inst)
									end)
								else
									SpawnPrefab("lucy_transform_fx").Transform:SetPosition(inst:GetPosition():Get())
								end
							end
							MakeNormal(inst)
						--end
						inst.returnfrompos = nil
					end)
				else
					if inocean then
						inst:DoTaskInTime(3, function(inst)
							inst:PutBackOnGround()
							local pos = inst:GetPosition()
							inst.Transform:SetPosition(pos.x, 12, pos.z)
							MakeNormal(inst)
						end)
					else
						inst:DoTaskInTime(FRAMES*12, function() MakeNormal(inst) end)
					end
				end
			--end
		end)
	end
	
	inst.LastAttackTarget = nil 
	inst.MultiHitTime = 0 
	
	inst.components.weapon:SetDamage(33.3)
	
	inst:AddComponent("ly_projectile")
	inst.components.ly_projectile.damage = 27.5
	--inst.components.ly_projectile:SetHitDist(3)
	inst.components.ly_projectile:SetLaunchOffset(Vector3(0.5,0.5,0))
	inst.components.ly_projectile:SetRange(12)
	inst.components.ly_projectile:SetSpeed(15)
	inst.components.ly_projectile:SetCanHit(function(inst,owner,target)
		return target ~= inst.LastAttackTarget and IceyUtil.CanAttack(target,owner) and target ~= inst
	end)
	inst.components.ly_projectile:SetOnThrownFn(function(inst)
		inst:AddTag("NOCLICK")
		--inst.Physics:ClearCollisionMask()
		RemovePhysicsColliders(inst)
		inst.components.inventoryitem.canbepickedup = false
		inst.components.talker:IgnoreAll(inst) 
		inst.components.talker:ShutUp() 
		inst.AnimState:PlayAnimation("spin_loop", true)
	end)
	inst.components.ly_projectile:SetOnHitFn(function(inst,owner,target)
		inst.LastAttackTarget = target 
		SpawnPrefab("icey_weaponsparks"):SetPiercing(inst, target)
		local nowpos = inst:GetPosition()
		inst:DoTaskInTime(0,function()
		
			local otherent = FindEntity(inst, 12,function(guy)
				return guy ~= target and inst.components.ly_projectile.canhit(inst,owner,guy)
			end, {"_combat"}, {"INLIMBO"})
			
			print("Lucy OnHit,LastAttackTarget,",inst.LastAttackTarget,"otherent:",otherent)
			
			if target.components.health and not target.components.health:IsDead() and otherent and inst.MultiHitTime > 0 then 
				inst.components.ly_projectile:Throw(owner,otherent:GetPosition(),true,nil,true)
				inst.Transform:SetPosition(nowpos:Get())
				inst.MultiHitTime = inst.MultiHitTime - 1 
			else
				inst.AnimState:PlayAnimation("bounce")
				inst.AnimState:PushAnimation("idle")		
				Return(inst, owner)
			end 
		end)
	end)
	inst.components.ly_projectile:SetOnMissFn(function(inst,owner)
		inst.LastAttackTarget = nil 
		SpawnPrefab("icey_weaponsparks"):SetBounce(inst)
		inst.AnimState:PlayAnimation("bounce")
		inst.AnimState:PushAnimation("idle")
		
		Return(inst, owner)
	end)
	
	inst.components.inventoryitem.imagename = "lucy"
	
	AddAoetargetingServer(inst,function(inst,doer,pos)
		if IceyUtil.DefaultCostFn(doer,{stamina = 5}) then 
			doer.components.inventory:DropItem(inst)
			inst.MultiHitTime = 5
			inst.components.ly_projectile:Throw(doer,pos,true,nil,true)
			inst.components.rechargeable:StartRecharge()
		end 
	end,nil,3)

end) 

for k,v in pairs({"shovel","goldenshovel"}) do 
	AddPrefabPostInit(v, function(inst)

		AddAoetargetingClient(inst,"line",{"iceyweaponskill_shovel"},8)
		inst.components.aoetargeting:SetAlwaysValid(true)

		if not TheWorld.ismastersim then
			return inst
		end
		
		inst.components.weapon:SetDamage(30)		
		
		AddAoetargetingServer(inst,function(inst,doer,pos)
			if IceyUtil.DefaultCostFn(doer,{stamina = 25}) then 
				
				local proj = SpawnAt("shovel_dirt_projectile",inst:GetPosition())
				proj.components.complexprojectile:Launch(pos,doer)
				--proj:FacePoint(pos:Get())
				SpawnAt("shovel_dirt",doer:GetPosition())
				inst.components.rechargeable:StartRecharge()
				
				if inst.components.finiteuses then
					local use = inst.components.finiteuses.consumption[ACTIONS.DIG] or 1
					inst.components.finiteuses:Use(use)
				end
				
				
			end 
		end,nil,3)
	end)
end 

AddPrefabPostInit("portablecookpot", function(inst)
	if not TheWorld.ismastersim then
        return inst
    end
	
	local function ShowProduct(inst)    
		if not inst:HasTag("burnt") then
			local product = inst.components.stewer.product
			--print("Show Product:"..product) 
			if IceyUtil.IsIceyCookingProduct(product) then 
				inst.AnimState:OverrideSymbol("swap_cooked", "cook_pot_food_icey", product)    
				return 
			end 
			if IsModCookingProduct("cookpot", product) then   
				inst.AnimState:OverrideSymbol("swap_cooked", product, product)    			
			else         
				inst.AnimState:OverrideSymbol("swap_cooked", "cook_pot_food", product)    
			end 
		end 
	end  
	
	
	
	local old_ondonecooking = inst.components.stewer.ondonecooking
	inst.components.stewer.ondonecooking = function(inst)
		old_ondonecooking(inst)
		ShowProduct(inst) 
	end 
	
	local old_oncontinuedone = inst.components.stewer.oncontinuedone 
	inst.components.stewer.oncontinuedone = function(inst)
		old_oncontinuedone(inst)
		ShowProduct(inst) 
	end   

end)

AddPrefabPostInit("portablecookpot_item", function(inst)
	inst:AddTag("book")

	if not TheWorld.ismastersim then
        return inst
    end
	
	local function supercrack(inst)
		local x,y,z = inst.Transform:GetWorldPosition()
		local ents = TheSim:FindEntities(x,y,z, 1.5, { "_combat" }, { "player", "epic", "shadow", "shadowminion", "shadowchesspiece" })
		for i,v in ipairs(ents) do

			if v.sg ~= nil and v.sg:HasState("hit")
				and v.components.health ~= nil and not v.components.health:IsDead()
				and not v.sg:HasStateTag("transform")
				and not v.sg:HasStateTag("nointerrupt")
				and not v.sg:HasStateTag("frozen") then

				if v.components.sleeper ~= nil then
					v.components.sleeper:WakeUp()
				end
				v.sg:GoToState("hit")
			end
		end
	end
	
	--ThePlayer.AnimState:OverrideSymbol("book_closed", "swap_warly_cookpot", "book_closed")
	local function onequip(inst,owner)
		owner.AnimState:OverrideSymbol("book_closed", "swap_warly_cookpot", "book_closed")
	end
	
	local function onunequip(inst,owner)
		owner.AnimState:ClearOverrideSymbol("book_closed")
	end
	
	local function onattack(inst,attacker,target)
		local snap = SpawnPrefab("impact")
        local x, y, z = inst.Transform:GetWorldPosition()
        local x1, y1, z1 = target.Transform:GetWorldPosition()
        local angle = -math.atan2(z1 - z, x1 - x)
        snap.Transform:SetPosition(x1, y1, z1)
        snap.Transform:SetRotation(angle * RADIANS)
		snap.Transform:SetScale(1+math.random()*0.5,1+math.random()*0.5,1+math.random()*0.5)
		supercrack(inst)
		if target.SoundEmitter ~= nil then
			--inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/trails/hide_pre",nil,0.5)
            target.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/trails/hide_hit")
        end
	end
	
	local function onchose(inst,owner)
		local is_equip = inst.components.equippable:IsEquipped()
		if is_equip then 
			return owner.prefab == "warly"
		end 
		
		return true 
	end
	
	
	
	inst:AddComponent("weapon")
    inst.components.weapon:SetDamage(64)
	inst.components.weapon:SetOnAttack(onattack)
	
	inst:AddComponent("equippable")
    inst.components.equippable:SetOnEquip(onequip)
    inst.components.equippable:SetOnUnequip(onunequip)
	
	inst:AddComponent("chosenpeople")
	inst.components.chosenpeople:SetChosenFn(onchose)

end)

AddPrefabPostInit("hammer", function(inst)

	AddAoetargetingClient(inst,"parry",{"iceyweaponskill_hammer"},8)
	
	if not TheWorld.ismastersim then
		return inst
	end
	
	local function CanGroundPoundHit(attacker,target)
		return target.components.workable or IceyUtil.CanAttack(target,attacker)
	end 
	
	local function AttackerOverrideFn(inst)
		local isequipped = inst.components.equippable:IsEquipped()
		local owner = inst.components.inventoryitem:GetGrandOwner() 
		
		return isequipped and owner
	end 
	
	local function GroundpoundFn(inst)
		inst.SoundEmitter:PlaySound("dontstarve_DLC001/creatures/bearger/groundpound")
		ShakeAllCameras(CAMERASHAKE.FULL, 0.7, .03, .5, inst, 30)
	end 
	
	inst.components.weapon:SetDamage(30)
	
	inst:AddComponent("ly_groundpounder")
	inst.components.ly_groundpounder.ignorerange = true 
	inst.components.ly_groundpounder.destroyer = true
	inst.components.ly_groundpounder.destroy_strength = 1
    inst.components.ly_groundpounder.damageRings = 2
    inst.components.ly_groundpounder.destructionRings = 2
    inst.components.ly_groundpounder.numRings = 3
    inst.components.ly_groundpounder.groundpounddamagemult = 1.0
	inst.components.ly_groundpounder.canhitFn = CanGroundPoundHit
	inst.components.ly_groundpounder.get_attacker_override_fn = AttackerOverrideFn
	inst.components.ly_groundpounder.groundpoundFn = GroundpoundFn
	
	AddAoetargetingServer(inst,function(inst,doer,pos)
		if IceyUtil.DefaultCostFn(doer,{stamina = 25}) then 
			
			inst.components.rechargeable:StartRecharge()
			
			inst.components.ly_groundpounder:GroundPound(doer:GetPosition())

			--[[if inst.components.finiteuses then
				inst.components.finiteuses:Use(1)
			end--]]
			
			
		end 
	end,nil,10)
end) 


--[[AddPlayerPostInit(function(inst)
	if not TheWorld.ismastersim then
        return inst
    end

	if inst.prefab == "warly" then 
		inst.components.eater.preferseatingtags = nil 
	end 
end)--]]

--c_poison(ThePlayer)
--c_poison(ThePlayer,false,{percent = 0.8})

--c_poison(ThePlayer,true)
--c_poison(ThePlayer,true,{percent = 0.8})
AddPrefabPostInit("spider_warrior", function(inst)
	if not TheWorld.ismastersim then
        return inst
    end
	
	inst.IsPoison = false 
	--spider_tropical_build
	inst.EnablePoison = function(inst,enable)
		if enable then 
			inst.AnimState:SetBuild("spider_tropical_build")
		else
			inst.AnimState:SetBuild("spider_warrior_build")
		end
		
		inst.IsPoison = enable
	end 
	
	local function OnSpiderHitOther(inst,data)
		if inst.IsPoison then 
			local target = data.target
			IceyUtil.AddDarkSoulPoisonDebuff(target,false,{percent = 0.75})
			
		end 
	end
	
	inst:ListenForEvent("onhitother",OnSpiderHitOther)
	
	if math.random() <= 0.5 then 
		inst:EnablePoison(true)
	else
		inst:EnablePoison(false)
	end
end)

--AddDarkSoulPoisonDebuff = AddDarkSoulPoisonDebuff,
--AddDarkSoulBleedsDebuff = AddDarkSoulBleedsDebuff,
--AddDarkSoulFreezeDebuff = AddDarkSoulFreezeDebuff,
--AddDarkSoulCurseDeathDebuff = AddDarkSoulCurseDeathDebuff,
GLOBAL.c_poison = IceyUtil.AddDarkSoulPoisonDebuff
GLOBAL.c_bleeds = IceyUtil.AddDarkSoulBleedsDebuff
GLOBAL.c_freeze = IceyUtil.AddDarkSoulFreezeDebuff
GLOBAL.c_curse = IceyUtil.AddDarkSoulCurseDeathDebuff

--F:\games\steamapps\common\Don't Starve Together\data\databundles\scripts\screens\consolescreen.lua
AddClassPostConstruct("screens/consolescreen",function(self,owner)
	local prediction_command_old = {"spawn", "save", "gonext", "give", "mat", "list", "findnext", "countprefabs", "selectnear", "removeall", "shutdown", "regenerateworld", "reset", "despawn", "godmode", "supergodmode", "armor", "makeboat", "makeboatspiral", "autoteleportplayers", "gatherplayers" }
	
	local prediction_command = {"poison","bleeds","freeze","curse"}
	
	for k,v in pairs(prediction_command_old) do 
		table.insert(prediction_command,v)
	end
	self.console_edit:AddWordPredictionDictionary({words = prediction_command, delim = "c_", num_chars = 0})
end)

--[[AddClassPostConstruct("widgets/boatmeter",function(self)
	IceyUtil.MakeDragableUI(self)
end)--]]