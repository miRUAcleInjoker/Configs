
local data = {
	feathercrown = {
		prefab = "featheredwreath",
		masterfn = function(inst)
			inst.components.equippable.walkspeedmult = 1.2
			
			inst:AddComponent("fueled")
			inst.components.fueled.fueltype = FUELTYPE.USAGE
			inst.components.fueled:InitializeFuelLevel(TUNING.TOTAL_DAY_TIME * 3)
			inst.components.fueled:SetDepletedFn(inst.Remove)
		end
	},
	
	lightdamager = {
		prefab = "barbedhelm",
		hidesymbols = true,
		damage_multi = 1.10,
		masterfn = function(inst)
			inst:AddComponent("armor")
			inst.components.armor:InitCondition(450,0.55)
		end,
	},
	
	recharger = {
		prefab = "crystaltiara",
		cooldown_rate = 0.85,
		masterfn = function(inst)
			inst:AddComponent("fueled")
			inst.components.fueled.fueltype = FUELTYPE.USAGE
			inst.components.fueled:InitializeFuelLevel(TUNING.TOTAL_DAY_TIME * 3)
			inst.components.fueled:SetDepletedFn(inst.Remove)
		end
	},
	
	healingflower = {
		prefab = "flowerheadband",
		masterfn = function(inst)
			inst.components.equippable.dapperness = TUNING.DAPPERNESS_SMALL
			inst:AddComponent("fueled")
			inst.components.fueled.fueltype = FUELTYPE.USAGE
			inst.components.fueled:InitializeFuelLevel(TUNING.TOTAL_DAY_TIME * 5)
			inst.components.fueled:SetDepletedFn(inst.Remove)
		end
	},
	
	tiaraflowerpetals = {
		prefab = "wovengarland",
		masterfn = function(inst)
			inst.components.equippable.dapperness = TUNING.DAPPERNESS_SMALL
			inst:AddComponent("fueled")
			inst.components.fueled.fueltype = FUELTYPE.USAGE
			inst.components.fueled:InitializeFuelLevel(TUNING.TOTAL_DAY_TIME * 5)
			inst.components.fueled:SetDepletedFn(inst.Remove)
		end
	},
	
	strongdamager = {
		prefab = "noxhelm",
		hidesymbols = true,
		damage_multi = 1.20,
		masterfn = function(inst)
			inst:AddComponent("armor")
			inst.components.armor:InitCondition(600,0.60)
		end
	},
	
	crowndamager = {
		prefab = "resplendentnoxhelm",
		hidesymbols = true,
		damage_multi = 1.25,
		cooldown_rate = 0.90,
		masterfn = function(inst)
			inst:AddComponent("armor")
			inst.components.armor:InitCondition(700,0.65)
		end
	},
	
	healinggarland = {
		prefab = "blossomedwreath",
		masterfn = function(inst)
			inst.HealOwner = function(inst, owner)
				inst.heal_task = inst:DoTaskInTime(0.33, function(inst)
					if inst.components.equippable:IsEquipped() and not owner.components.health:IsDead() then
						if owner.components.health:GetPercent() < 0.85 then
							if not inst:HasTag("regen") then inst:AddTag("regen") end
							owner.components.health:DoDelta(1, true, "regen", true)
						else
							inst:RemoveTag("regen")
						end 
						inst:HealOwner(owner)
					else
						inst:RemoveTag("regen")
					end
				end)
			end
            inst:ListenForEvent("equipped", function(inst, data)
                inst:HealOwner(data.owner)
                inst._deathfunction = function(owner)
                    if inst.heal_task then
                        inst.heal_task:Cancel()
                        inst.heal_task = nil
                    end
                    inst:RemoveTag("regen")
                    owner.components.health:Kill()
                end
                inst._revivefunction = function(owner)
                    inst:HealOwner(owner)
                end
                data.owner:ListenForEvent("ms_respawnedfromghost", inst._revivefunction)
                data.owner:ListenForEvent("death", inst._deathfunction)
            end)
            inst:ListenForEvent("unequipped", function(inst, data)
                if inst.heal_task then
                    inst.heal_task:Cancel()
                    inst.heal_task = nil
                end
                inst:RemoveTag("regen")
                data.owner:RemoveEventCallback("ms_respawnedfromghost", inst._revivefunction)
                inst._revivefunction = nil
                data.owner:RemoveEventCallback("death", inst._deathfunction)
                inst._deathfunction = nil
            end)
			inst.components.equippable.walkspeedmult = 1.1
			
			inst:AddComponent("fueled")
			inst.components.fueled.fueltype = FUELTYPE.USAGE
			inst.components.fueled:InitializeFuelLevel(TUNING.TOTAL_DAY_TIME * 5)
			inst.components.fueled:SetDepletedFn(inst.Remove)
		end
	},
	
	eyecirclet = {
		prefab = "clairvoyantcrown",
		cooldown_rate = 0.80,
		masterfn = function(inst)
			inst.components.equippable.walkspeedmult = 1.1
			
			inst:AddComponent("fueled")
			inst.components.fueled.fueltype = FUELTYPE.USAGE
			inst.components.fueled:InitializeFuelLevel(TUNING.TOTAL_DAY_TIME * 5)
			inst.components.fueled:SetDepletedFn(inst.Remove)
		end
	}
}

local function MakeHat(name)
    local build = "hat_"..name
    local symbol = name.."hat"

    local assets = {
        Asset("ANIM", "anim/"..build..".zip"),
    }
	
	local function onequip(inst, owner)
        owner.AnimState:OverrideSymbol("swap_hat", build, "swap_hat")
		owner.AnimState:Show("HAT")
		
		if inst.components.fueled ~= nil then
            inst.components.fueled:StartConsuming()
        end
		
		if data[name].hidesymbols then
			owner.AnimState:Show("HAIR_HAT")
			owner.AnimState:Show("HEAD_HAT")
			owner.AnimState:Hide("HAIR_NOHAT")
			owner.AnimState:Hide("HAIR")
			owner.AnimState:Hide("HEAD")
		end
		
		if data[name].damage_multi then 
			owner.components.combat.externaldamagemultipliers:SetModifier(inst,data[name].damage_multi,inst.prefab)
		end
    end

    local function onunequip(inst, owner)
        owner.AnimState:ClearOverrideSymbol("swap_hat")
		owner.AnimState:Hide("HAT")
		
		if inst.components.fueled ~= nil then
            inst.components.fueled:StopConsuming()
        end
		
		if data[name].hidesymbols then
			owner.AnimState:Hide("HAIR_HAT")
			owner.AnimState:Hide("HEAD_HAT")
			owner.AnimState:Show("HAIR_NOHAT")
			owner.AnimState:Show("HAIR")
			owner.AnimState:Show("HEAD")
		end
		
		if data[name].damage_multi then 
			owner.components.combat.externaldamagemultipliers:RemoveModifier(inst,inst.prefab)
		end
    end

    local function fn()
        local inst = CreateEntity()

        inst.entity:AddTransform()
        inst.entity:AddAnimState()
        inst.entity:AddNetwork()

        MakeInventoryPhysics(inst)
		
		inst.nameoverride = "lavaarena_"..name.."hat"

        inst.AnimState:SetBank(symbol)
        inst.AnimState:SetBuild(build)
        inst.AnimState:PlayAnimation("anim")

        inst:AddTag("hat")

        inst.entity:SetPristine()

        if not TheWorld.ismastersim then
            return inst
        end

        inst:AddComponent("inventoryitem")
		inst.components.inventoryitem.imagename = "lavaarena_"..name.."hat"
		
        inst:AddComponent("inspectable")

        inst:AddComponent("equippable")
        inst.components.equippable.equipslot = EQUIPSLOTS.HEAD
        inst.components.equippable:SetOnEquip(onequip)
        inst.components.equippable:SetOnUnequip(onunequip)
		inst.components.equippable.cooldown_rate = data[name].cooldown_rate
		
		data[name].masterfn(inst)

        return inst
    end

    return Prefab("icey_forge_"..name,fn,assets)
end

local hats = {}
for k,v in pairs(data) do
	table.insert(hats, MakeHat(k))
end
return unpack(hats)