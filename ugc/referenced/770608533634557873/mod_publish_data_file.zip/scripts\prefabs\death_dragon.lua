local TadalinUtil = require("tadalin_util")
local IceyUtil = require("icey_util")

local assets =
{
    --Asset("ANIM", "anim/frog.zip"),
    --Asset("SOUND", "sound/frog.fsb"),
	Asset("ANIM", "anim/death_dragon.zip"),
	Asset("ANIM", "anim/death_dragon_atk.zip"),
	Asset("ANIM", "anim/death_dragon_ball.zip"),
	Asset("ANIM", "anim/death_dragon_background.zip"),
	
	Asset("ANIM", "anim/pod_projectile.zip"),
	Asset("ANIM", "anim/fireball_2_fx.zip"),
	Asset("ANIM", "anim/deer_ice_charge.zip"),
	
}

local prefabs =
{
    "froglegs",
    "frogsplash",
}

local brain = require "brains/deathdragonbrain"
local SCALE = 15
local SCALE_higher = 3

local PAD_DURATION = .1
local FLASH_TIME = .3

--------------------------------------------------------------------------

local function OnCameraFocusDirty(inst)
    if inst._camerafocus:value() then
        TheFocalPoint.components.focalpoint:StartFocusSource(inst, nil, nil, 14, 15, 3)
		--TheCamera:SetTarget(inst) 
    else
        TheFocalPoint.components.focalpoint:StopFocusSource(inst)
		--TheCamera:SetTarget(ThePlayer) 
    end
end

local function EnableCameraFocus(inst, enable)
    if enable ~= inst._camerafocus:value() then
        inst._camerafocus:set(enable)
        if not TheNet:IsDedicated() then
            OnCameraFocusDirty(inst)
        end
    end
end

--------------------------------------------------------------------------

local function PushMusic(inst)
	if inst:HasTag("background") then 
		return 
	end 
    if ThePlayer == nil then
        inst._playingmusic = false
    elseif ThePlayer:IsNear(inst, inst._playingmusic and 40 or 20) then
        inst._playingmusic = true
        ThePlayer:PushEvent("triggeredevent", { name = "machine_god_judas_final" })
    elseif inst._playingmusic and not ThePlayer:IsNear(inst, 50) then
        inst._playingmusic = false
    end
end
--------------------------------------------------------------------------
local function UpdatePing(inst, s0, s1, t0, duration, multcolour, addcolour)
    if next(multcolour) == nil then
        multcolour[1], multcolour[2], multcolour[3], multcolour[4] = inst.AnimState:GetMultColour()
    end
    if next(addcolour) == nil then
        addcolour[1], addcolour[2], addcolour[3], addcolour[4] = inst.AnimState:GetAddColour()
    end
    local t = GetTime() - t0
    local k = 1 - math.max(0, t - PAD_DURATION) / duration
    k = 1 - k * k
    local s = Lerp(s0, s1, k)
    local c = Lerp(1, 0, k)
    inst.Transform:SetScale(s, s, s)
    inst.AnimState:SetMultColour(c * multcolour[1], c * multcolour[2], c * multcolour[3], c * multcolour[4])

    k = math.min(FLASH_TIME, t) / FLASH_TIME
    c = math.max(0, 1 - k * k)
    inst.AnimState:SetAddColour(c * addcolour[1], c * addcolour[2], c * addcolour[3], c * addcolour[4])
end

local function FadeOut(inst,startscale,adds)
	if inst.fadetask then 
		inst.fadetask:Cancel()
		inst.fadetask = nil 
	end
	startscale = startscale or SCALE_higher
	adds = adds or 1 
	inst.fadetask = inst:DoPeriodicTask(0, UpdatePing, nil, startscale, startscale + adds, GetTime(), 0.5, {}, {})
	inst:DoTaskInTime(0.5,inst.Hide) 
end 

local function FadeIn(inst)
	if inst.fadetask then 
		inst.fadetask:Cancel()
		inst.fadetask = nil 
	end
	inst:Show()
	inst.Transform:SetScale(SCALE, SCALE, SCALE)
	inst.AnimState:SetMultColour(1,1,1,1)
	inst.AnimState:SetAddColour(0,0,0,0)
end 

local function EnterHigher(inst,height)
	local x,y,z = inst:GetPosition():Get()
	height = height or 0
	inst.Transform:SetScale(SCALE_higher, SCALE_higher, SCALE_higher)
	inst.Transform:SetPosition(x,height,z)
	inst.components.health:SetInvincible(true)
end 

local function EnterLower(inst)
	local x,y,z = inst:GetPosition():Get()
	inst.Transform:SetScale(SCALE, SCALE, SCALE)
	inst.Transform:SetPosition(x,0,z)
	inst.components.health:SetInvincible(false)
end 

local function HasPlayer(list,player)
	for k,v in pairs(list) do 
		if v and v:IsValid() and v == player then 
			return true 
		end
	end
end 

local function onnear(inst,player)
	--inst:EnableCameraFocus(true) 

end 

local function onfar(inst)
	--inst:EnableCameraFocus(false) 
	
end 

local function EnableFocus(inst,player,enable)
	if enable then
		player.player_classified._camera_focus_target:set(inst)
		player.player_classified._camera_heading:set(45)
		player.player_classified._camera_controllable:set(false)
	else
		player.player_classified._camera_focus_target:set(player)
		player.player_classified._camera_heading:set(0)
		player.player_classified._camera_controllable:set(true)
	end
end 

local function CheckFocus(inst)
	local last_focus_players = inst.FocusPlayers
	
	local x,y,z = inst.Transform:GetWorldPosition()
	local players = TheSim:FindEntities(x,y,z,15,{"player"},{"playerghost"})
	
	for k,v in pairs(players) do 
		EnableFocus(inst,v,true)
	end
	
	for k,v in pairs(last_focus_players) do 
		if v:IsValid() and not HasPlayer(players,v) then 
			EnableFocus(inst,v,false)
		end
	end

	inst.FocusPlayers = players
end 

local function onremove(inst)
	for k,v in pairs(inst.FocusPlayers) do 
		EnableFocus(inst,v,false)
	end
end 

local function ChangeBuild(inst,build)
	build = build or "death_dragon"
	--inst.AnimState:SetBank(build)
	inst.AnimState:SetBuild(build)
end 

local function onskilluse(inst,data)
	local skillname = data.name
	local skillcd = data.cd
	inst[skillname] = false 
	
	inst.components.timer:StartTimer(skillname,skillcd)
end 

local function ontimerdone(inst,data)
	local skillname = data.name
	inst[skillname] = true 
end 

local function DoBallAttack(inst,target,pos)
	if not inst.components.health:IsDead() and not inst:IsAsleep() and inst.canballattack then 
		inst.components.combat:StartAttack()
		pos = pos or (target and target:IsValid() and target:GetPosition()) or inst:GetPosition()
		local ball = SpawnPrefab("death_dragon_ball")
		ball.Transform:SetPosition(pos.x,pos.y+12,pos.z)
		ball.target = target 
		ball.master = inst
		--inst.components.combat:SetAttackPeriod(0.5 + math.random()*0.1 - math.random()*0.2)
    end 
end 

local function OnEntitySleep(inst)
	inst:RemoveFromScene()
end 

local function OnEntityWake(inst)
	inst:ReturnToScene()
end 

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddDynamicShadow()
    inst.entity:AddNetwork()
	inst.entity:AddLight()
	
	
	inst.Light:SetIntensity(.5)
    inst.Light:SetColour(119 / 255, 234 / 255, 245 / 255)
    inst.Light:SetFalloff(.6)
    inst.Light:SetRadius(15)
    inst.Light:Enable(true)

    MakeGiantCharacterPhysics(inst, 1000, 2.5)
	RemovePhysicsColliders(inst)

    --inst.DynamicShadow:SetSize(6, 3)
    --inst.Transform:SetSixFaced()
	
	inst.Transform:SetScale(SCALE,SCALE,SCALE)
	
	--[[ThePlayer.AnimState:SetBank("death_dragon_atk") 
	ThePlayer.AnimState:SetBuild("death_dragon_atk") 
    ThePlayer.AnimState:PlayAnimation("atk",true)  --]]
	
	--[[ThePlayer.AnimState:SetBank("wilson") 
	ThePlayer.AnimState:SetBuild("icey") 
    ThePlayer.AnimState:PlayAnimation("atk",true)  --]]

    inst.AnimState:SetBank("death_dragon")
    inst.AnimState:SetBuild("death_dragon")
	--inst.AnimState:PlayAnimation("flyin2") 
    inst.AnimState:PlayAnimation("idle",true) 
	inst.AnimState:SetLightOverride(1)
	inst.AnimState:SetSortOrder(0)
	
	inst:AddTag("NOCLICK")
    inst:AddTag("hostile")
    inst:AddTag("mech")
	inst:AddTag("epic")
	inst:AddTag("noepicmusic")
	inst:AddTag("lightningrod")
	inst:AddTag("judas")
	
	--inst:AddTag("CAMERAFOCUS")
	inst:AddTag("NODARKCHARGE")
	
	inst._camerafocus = net_bool(inst.GUID, "death_dragon._camerafocus", "camerafocusdirty")
	
	inst._playingmusic = false
	if not TheNet:IsDedicated() then
        inst:DoPeriodicTask(1, PushMusic,0)
    end

    inst.entity:SetPristine()
    if not TheWorld.ismastersim then
		inst:ListenForEvent("camerafocusdirty", OnCameraFocusDirty)
        return inst
    end
	
	inst.canballattack = true 
	inst.FocusPlayers = {} 
	inst.EnableCameraFocus = EnableCameraFocus
	inst.ChangeBuild = ChangeBuild
	
	inst.FadeIn = FadeIn
	inst.FadeOut = FadeOut
	inst.EnterHigher = EnterHigher
	inst.EnterLower = EnterLower
	
	inst.DoBallAttack = DoBallAttack 


    inst:AddComponent("locomotor") -- locomotor must be constructed before the stategraph
    inst.components.locomotor.walkspeed = 8
    inst.components.locomotor.runspeed = 8
	
	
    --inst:AddComponent("playerprox")
    --inst.components.playerprox:SetDist(15, 15)
    --inst.components.playerprox.onnear = onnear
    --inst.components.playerprox.onfar = onfar
   

    inst:AddComponent("health")
    inst.components.health:SetMaxHealth(4444)
	inst.components.health.destroytime = 8

    inst:AddComponent("combat")
	inst.components.combat:SetAttackPeriod(0.4)
    inst.components.combat:SetDefaultDamage(160)
	inst.components.combat:SetRange(15)
	--inst.components.combat:SetHurtSound("dontstarve_DLC003/creatures/enemy/metal_robot/electro")


    inst:AddComponent("lootdropper")
    --inst.components.lootdropper:SetLoot({"froglegs"})

    inst:AddComponent("knownlocations")
    inst:AddComponent("inspectable")
	inst:AddComponent("timer")
	inst:AddComponent("explosiveresist")
	
	inst.OnEntitySleep = OnEntitySleep
    inst.OnEntityWake = OnEntityWake
	
	inst:SetStateGraph("SGdeath_dragon")
    inst:SetBrain(brain)
	
	TadalinUtil.MakeNormalTadalin(inst)
	
	--inst:DoPeriodicTask(1,CheckFocus)
	inst:ListenForEvent("onremove",onremove)
    return inst
end


local function StartFall(inst)
	local target = inst.target 
	local y_speed = 10 + 5*math.random() 
	inst.Physics:SetMass(99999)
	
	inst.AnimState:PlayAnimation("fall",true)
	
	if not (target and target:IsValid()) then 
		--inst.Physics:SetMotorVel(0,-y_speed,0)
		inst:DoPeriodicTask(0,function()
			inst.y_speed = inst.y_speed + 0.6
			inst.y_speed = math.min(y_speed,inst.y_speed)
			inst.Physics:SetMotorVel(0,-inst.y_speed,0)
		end)
	else
		--inst.Physics:SetMass(1)
		local targetpos = target:GetPosition()
		local mypos = inst:GetPosition()
		
		local targetpos_ground = Vector3(targetpos.x,0,targetpos.z)
		local mypos_ground = Vector3(mypos.x,0,mypos.z)
		
		local height = mypos.y 
		local droptime = height / y_speed
		local foraward_speed = (targetpos_ground - mypos_ground):Length() / droptime
		
		
		inst:DoPeriodicTask(0,function()
			inst.y_speed = inst.y_speed + 0.6
			inst.y_speed = math.min(y_speed,inst.y_speed)
			--inst.Physics:SetMotorVel(0,-inst.y_speed,0)
			
			
		
			inst:ForceFacePoint(targetpos:Get())
			inst.Physics:SetMotorVel(foraward_speed * inst.y_speed/y_speed,-inst.y_speed,0)
		end)
		
	end 
end 

local function Explode(inst)
	local x,y,z = inst.Transform:GetWorldPosition()
	local ents = TheSim:FindEntities(x,y,z,4,{"_combat"},{"tadalin"})
	for k,v in pairs(ents) do 
		if TadalinUtil.CanAttack(v) then 
			if inst.master and inst.master:IsValid() then 
				v.components.combat:GetAttacked(inst.master,math.random(20,40))
			else
				inst.components.combat:DoAttack(v)
			end
		end
	end
	inst:DestroyWorks(4) 
	
	SpawnAt("halloween_firepuff_cold_"..math.random(1,3),Vector3(x,y,z)).Transform:SetScale(2,2,2)
	for i=1,5 do 
		SpawnAt("halloween_firepuff_cold_"..math.random(1,3),Vector3(x+2-4*math.random(),0,z+2-4*math.random()))
	end 
	
	inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/enemy/metal_robot/smash") 
	inst:Hide() 
	inst:DoTaskInTime(3,inst.Remove) 
end 

local function TryAttack(inst)
	local x,y,z = inst.Transform:GetWorldPosition()
	local ents = TheSim:FindEntities(x,y,z,4,{"_combat"},{"tadalin"})
	if y <= 0.3 then 
		Explode(inst)
		inst.TryAttackTask:Cancel()
	end
end 

local function CreateTail(bank, build, anim,lightoverride, addcolour, multcolour,scale)
  local inst = CreateEntity()
  scale = scale or 1

  inst:AddTag("FX")
  inst:AddTag("NOCLICK")
  --[[Non-networked entity]]
  inst.entity:SetCanSleep(false)
  inst.persists = false

  inst.entity:AddTransform()
  inst.entity:AddAnimState()

  MakeInventoryPhysics(inst)
  inst.Physics:ClearCollisionMask()

  inst.AnimState:SetBank(bank)
  inst.AnimState:SetBuild(build)
  inst.AnimState:PlayAnimation(anim)

  inst.Transform:SetScale(scale,scale,scale)
  if addcolour ~= nil then
    inst.AnimState:SetAddColour(unpack(addcolour))
  end
  if multcolour ~= nil then
    inst.AnimState:SetMultColour(unpack(multcolour))
  end
  if lightoverride > 0 then
    inst.AnimState:SetLightOverride(lightoverride)
  end
  inst.AnimState:SetFinalOffset(2)

  inst:ListenForEvent("animover", inst.Remove)

  return inst
end

local function OnUpdateProjectileTail(inst, bank, build, anim,speed, lightoverride, addcolour, multcolour, hitfx, tails,rad,scale,finaloffset)
	if inst:HasTag("time_stopped") then 
		return 
	end
  local x, y, z = inst.Transform:GetWorldPosition()
  y = y + 0.3
  rad = rad or 0.1 
  for tail, _ in pairs(tails) do
    tail:ForceFacePoint(x, y, z)
  end
  if inst.entity:IsVisible() then
    local tail = CreateTail(bank, build,anim ,lightoverride, addcolour, multcolour,scale)
    local rot = inst.Transform:GetRotation()
    tail.Transform:SetRotation(rot)
    rot = rot * DEGREES
    local offsangle = math.random() * 2 * PI
    local offsradius = math.random() * rad + rad
    local hoffset = math.cos(offsangle) * offsradius
    local voffset = math.sin(offsangle) * offsradius
	--tail.entity:SetParent(inst.entity)         
	--v.hunterfx.Transform:SetPosition(0,2.5,0) 
    tail.Transform:SetPosition(x + math.sin(rot) * hoffset+finaloffset.x, y + voffset+finaloffset.y, z + math.cos(rot) * hoffset+finaloffset.z)
	--tail.Transform:SetPosition(math.sin(rot) * hoffset,voffset + 2.1 ,math.cos(rot) * hoffset)
    tail.Physics:SetMotorVel(-speed * (rad + math.random() * (rad+0.1)), 0, 0)
    tails[tail] = true
    inst:ListenForEvent("onremove", function(tail) tails[tail] = nil end, tail)
    tail:ListenForEvent("onremove", function(inst)
      tail.Transform:SetRotation(tail.Transform:GetRotation() + math.random() * 30 - 15)
    end, inst)
  end
end


local function DestroyWorks(inst,rad)
	local x,y,z = inst:GetPosition():Get()
	for k,v in pairs(TheSim:FindEntities(x,y,z,rad)) do 
		if v and v:IsValid() and v.components.workable then 
			v.components.workable:Destroy(inst) 
		end
	end
end 

local function ballfn()
	local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddPhysics()
    inst.entity:AddNetwork()
	
	inst.Transform:SetScale(2,2,2)

    inst.AnimState:SetBank("death_dragon_ball")
    inst.AnimState:SetBuild("death_dragon_ball")
    inst.AnimState:PlayAnimation("spawn")
    inst.AnimState:SetFinalOffset(1)
	inst.AnimState:SetLightOverride(1)

	inst.Physics:SetMass(0)
    --inst.Physics:SetFriction(0)
    inst.Physics:SetDamping(0)
    inst.Physics:SetCollisionGroup(COLLISION.CHARACTERS)
    inst.Physics:ClearCollisionMask()
    inst.Physics:CollidesWith(COLLISION.WORLD)
    --inst.Physics:CollidesWith(COLLISION.OBSTACLES)
    inst.Physics:CollidesWith(COLLISION.ITEMS)
    inst.Physics:SetCapsule(.2, .2)

    inst:AddTag("notarget")
	inst:AddTag("tadalin")
	
	if not TheNet:IsDedicated() then
      inst:DoPeriodicTask(0, OnUpdateProjectileTail, nil, "pod_projectile", "pod_projectile","grow" ,3, 1, nil, nil, nil, {},0.5,1,Vector3(0,-2,0))
    end


    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst.persists = false
	inst.y_speed = 0
	inst.master = nil 
	inst.DestroyWorks = DestroyWorks
	
	inst:AddComponent("combat")
    inst.components.combat:SetDefaultDamage(75)
	inst.components.combat.playerdamagepercent = .5
	inst.components.combat:SetRange(4)
	inst.components.combat:SetAttackPeriod(0)

	inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/enemy/metal_robot/laser_pre")

	IceyUtil.ListenForEventOnce(inst,"animover",StartFall)
	inst.TryAttackTask = inst:DoPeriodicTask(0.1,TryAttack)
	
    return inst
end

return Prefab("death_dragon", fn, assets, prefabs),
Prefab("death_dragon_ball", ballfn, assets, prefabs)
