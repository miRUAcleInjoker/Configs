local assets = {
    Asset("ANIM", "anim/lavaarena_attack_buff_effect.zip"),
	Asset("ANIM", "anim/lavaarena_attack_buff_effect2.zip"),
}
local function fn()
	local inst = CreateEntity()
	
    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()

    inst.AnimState:SetBank("lavaarena_attack_buff_effect")
    inst.AnimState:SetBuild("lavaarena_attack_buff_effect")
    inst.AnimState:PlayAnimation("in")
	inst.AnimState:SetMultColour(.5, .5, .5, .5)

    inst.Transform:SetScale(1.4, 1.4, 1.4)

    inst:AddTag("DECOR")
    inst:AddTag("NOCLICK")
		
	inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.persists = false 
	
	--heal_fx defend_fx attack_fx3
	inst.Init = function(self,build,scale)
		scale = scale or 1.4 
		inst.AnimState:SetBank(build)
		inst.AnimState:SetBuild(build)
		inst.AnimState:PlayAnimation("in")
	end 
	
	inst.RemoveBattleCryFX = function()		
		inst.AnimState:PlayAnimation("out")
	end
		
	inst:ListenForEvent("animover", function(inst)
		if inst.AnimState:IsCurrentAnimation("out") then
			inst:Remove()
		else
			inst.AnimState:PlayAnimation("idle")
		end
	end)
	
	inst:DoTaskInTime(0,function()
		inst.SoundEmitter:PlaySound("dontstarve/common/lava_arena/spell/battle_cry")	
	end) 
	
	return inst
end

return Prefab("icey_battlecry_fxs", fn,assets)
