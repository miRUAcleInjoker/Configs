local IceyUtil = require("icey_util")
local IceyWeaponSkillUtil = require("icey_weaponskill_util")

local assets =
{
    Asset("ANIM", "anim/swap_shadowmixtures_blade.zip"),
	Asset("IMAGE","images/inventoryimages/shadowmixtures_blade.tex"),
	Asset("ATLAS","images/inventoryimages/shadowmixtures_blade.xml"),
}

local function EnableSmoke(inst,enable,type)
	if inst._smoke then 
		inst._smoke:Remove()
		inst._smoke = nil 
	end
	
	if enable and type then 
		inst._smoke = SpawnPrefab("shadowmixtures_blade_smoke")
		inst._smoke.entity:AddFollower()
		if type == "equip" then 
			local owner = inst.components.inventoryitem.owner
			if owner then 
				inst._smoke.Follower:FollowSymbol(owner.GUID, "swap_object",75,-25, 0)
			end
		elseif type == "ground" then 
			inst._smoke.Follower:FollowSymbol(inst.GUID, "shadowmixtures_blade",25,-75, 0)
		else
			inst._smoke:Remove()
			inst._smoke = nil 
		end
	end
end 

local function DoCircleAttack(inst,doer,basedamage)
	local x,y,z = inst:GetPosition():Get()
	for k,v in pairs(TheSim:FindEntities(x,y,z,6.5,{"_combat"})) do 
		if v and IceyUtil.CanAttack(v,doer) then 
			v.components.combat:GetAttacked(doer,math.random(basedamage,basedamage*2))
			SpawnAt("dark_hit_fx_icey",v:GetPosition()+Vector3(0,0.5,0)).Transform:SetScale(1.5,1.5,1.5)

			--[[local spark = SpawnPrefab("icey_weaponsparks")
			spark:SetPosition(doer,v)
			spark.AnimState:SetMultColour(0,0,0,0.8)
			local target_pos = v:GetPosition()
			local function RotateFX(fx)
				fx.Transform:SetPosition(target_pos:Get())
				fx.Transform:SetRotation(doer.Transform:GetRotation())
			end
			local rand = math.random(1,2)
			if rand == 1 then
				RotateFX(SpawnPrefab("shadowstrike_slash_fx"))
			else
				RotateFX(SpawnPrefab("shadowstrike_slash2_fx"))
			end--]]
		end
	end 
	
	local fx = SpawnAt("icey_seeleslash",doer:GetPosition())
	fx.AnimState:SetMultColour(0,0,0,0.8)
			
	
			
	ShakeAllCameras(CAMERASHAKE.FULL, .35, .02, 1, doer, 40)
end 

local function OnCQCAttack(inst,data)
	local target = data.target
	local type = data.type 
	local weapon = inst.components.combat:GetWeapon() 
	
	if weapon and target and target:IsValid() and type and type == "circle" 
	and GetTime() - weapon.LastCircleTime >= 0
	then 
		DoCircleAttack(weapon,inst,15)
		inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_nightsword",nil,nil,true)
		inst.SoundEmitter:PlaySound("dontstarve_DLC003/common/crafted/vortex_armour/equip_off")
		weapon.LastCircleTime = GetTime()
	end
end 

local function onequip(inst, owner)
    owner.AnimState:OverrideSymbol("swap_object", "swap_shadowmixtures_blade", "swap_shadowmixtures_blade")
    owner.AnimState:Show("ARM_carry")
    owner.AnimState:Hide("ARM_normal")

	inst:EnableSmoke(true,"equip") 
	inst:ListenForEvent("icey_cqc_attack",OnCQCAttack,owner)
end

local function onunequip(inst, owner)
    owner.AnimState:Hide("ARM_carry")
    owner.AnimState:Show("ARM_normal")
	
	inst:EnableSmoke(false) 
	inst:RemoveEventCallback("icey_cqc_attack",OnCQCAttack,owner)
end

local function topocket(inst)
	inst:EnableSmoke(false) 
end 

local function toground(inst)
	inst:EnableSmoke(true,"ground") 
end 

local function common_fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()

    MakeInventoryPhysics(inst)

    inst.AnimState:SetBank("swap_shadowmixtures_blade")
    inst.AnimState:SetBuild("swap_shadowmixtures_blade")
    inst.AnimState:PlayAnimation("idle")

	
	IceyWeaponSkillUtil.AddAoetargetingClient(inst,"line",{"shadow","shadowmixtures_blade"},9)
	
    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

	inst.EnableSmoke = EnableSmoke 
	inst.LastCircleTime = 0 

    inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "shadowmixtures_blade"
	inst.components.inventoryitem.atlasname = "images/inventoryimages/shadowmixtures_blade.xml"
	

    inst:AddComponent("weapon")
    inst.components.weapon:SetDamage(42.5)
	
    inst:AddComponent("inspectable")
	--inst.components.inspectable.nameoverride = "axe"

    inst:AddComponent("equippable")
    inst.components.equippable:SetOnEquip(onequip)
    inst.components.equippable:SetOnUnequip(onunequip)
	inst.components.equippable.dapperness = TUNING.CRAZINESS_MED
	
    MakeHauntableLaunch(inst)


	IceyWeaponSkillUtil.AddAoetargetingServer(inst,function(inst,doer,pos)
		if IceyUtil.DefaultCostFn(doer,{stamina = 20,focus = 8}) then 
			inst.components.rechargeable:StartRecharge()
			doer:ForceFacePoint(pos:Get())
			
			--fx:DoAoeAttack(doer)
			
			DoCircleAttack(inst,doer,62)
			inst.SoundEmitter:PlaySound("dontstarve/sanity/rook/taunt")
			inst.SoundEmitter:PlaySound("dontstarve_DLC003/common/crafted/vortex_armour/equip_off")
		else
			doer.sg:GoToState("idle")
		end 
	end,nil,30)
	
	inst:ListenForEvent("onpickup",topocket)
	inst:ListenForEvent("ondropped",toground)
	
	inst:DoTaskInTime(0,function()
		if inst.components.inventoryitem.owner == nil then 
			toground(inst) 
		end
	end)
	
    return inst
end



return Prefab("shadowmixtures_blade", common_fn, assets)
