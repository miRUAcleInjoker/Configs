local DarkSoulDebuff = Class(function(self, inst)
    self.inst = inst
    self._name = net_string(inst.GUID,"DarkSoulDebuff._name")
    self._target = net_entity(inst.GUID,"DarkSoulDebuff._target","ontargetdirty")
	
	self._percent = net_float(inst.GUID,"DarkSoulDebuff._percent","onpercentdirty")
	self._decrease_rate = net_float(inst.GUID,"DarkSoulDebuff._decrease_rate")
	self._decrease_rate_activated = net_float(inst.GUID,"DarkSoulDebuff._decrease_rate_activated")
	
	self._activated = net_bool(inst.GUID,"DarkSoulDebuff._activated","onactivateddirty")
end)

function DarkSoulDebuff:SetName(name)
	self._name:set(name)
end

function DarkSoulDebuff:SetTarget(target)
	self._target:set(target)
end

function DarkSoulDebuff:SetPercent(val)
	self._percent:set(val)
end

function DarkSoulDebuff:SetActivated(val)
	self._activated:set(val)
end

function DarkSoulDebuff:SetDecreaseRate(val)
	self._decrease_rate:set(val)
end 

function DarkSoulDebuff:SetDecreaseRateActivated(val)
	self._decrease_rate_activated:set(val)
end 

function DarkSoulDebuff:GetName()
	return self._name:value()
end

function DarkSoulDebuff:GetTarget()
	return self._target:value()
end

function DarkSoulDebuff:GetPercent()
	return self._percent:value()
end

function DarkSoulDebuff:IsActivated()
	return self._activated:value()
end

function DarkSoulDebuff:GetTimeRemain()
	local is_activated = self:IsActivated()
	local rate = self:IsActivated() and self._decrease_rate_activated:value() or self._decrease_rate:value()
	
	if rate and rate > 0 then 
		local decrease_in_per_second = rate * 1 / FRAMES
		
		return self:GetPercent() / decrease_in_per_second
	end 
end

return DarkSoulDebuff