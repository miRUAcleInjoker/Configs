AddStategraphState("wilson", 
 State{
		name = "icey_kill_sg",
        tags ={ "aoe", "doing", "busy", "nointerrupt", "nomorph" },
		onenter = function(inst)
			local mouse = Vector3(x,y,z)
			local a,b,c = inst:GetPosition():Get()
			local eny = nil 
			local ents = TheSim:FindEntities(a, b, c, 5, {"_combat"})
			inst.components.playercontroller:Enable(false)
			inst.Physics:ClearMotorVelOverride() 
			inst.components.locomotor:Stop()
			inst.Physics:Stop()
			inst.components.health:SetAbsorptionAmount(1.0)
		
			inst.SoundEmitter:PlaySound("dontstarve/common/staff_blink")
			inst.AnimState:PlayAnimation("atk_leap_lag")
			inst:ForceFacePoint(mouse:Get())
			inst.Physics:SetMotorVelOverride(40,0,0)
			inst.AnimState:SetMultColour(17/255,29/255,184/255,0.3)
			inst.sg:SetTimeout(0.2)
		end,
		    timeline =
    {
       TimeEvent(0.2, function(inst)
                inst.Physics:ClearMotorVelOverride() 
				inst.Physics:Stop() 
				inst.AnimState:SetMultColour(1,1,1,1)
				inst.components.playercontroller:Enable(true)
				inst.sg:GoToState("idle")
            end),
       
    },

    ontimeout = function(inst)
        inst.sg:RemoveStateTag("attack")
        inst.sg:AddStateTag("idle")
    end,

    events =
    {
        EventHandler("equip", function(inst) inst.sg:GoToState("idle") end),
        EventHandler("unequip", function(inst) inst.sg:GoToState("idle") end),
    },

    onexit = function(inst)
        inst.components.combat:SetTarget(nil)
        if inst.sg:HasStateTag("abouttoattack") then
            inst.components.combat:CancelAttack()
        end
    end,
		
}
)