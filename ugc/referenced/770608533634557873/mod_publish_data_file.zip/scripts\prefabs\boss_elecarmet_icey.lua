local assets =
{
	--正常状态的贴图
    Asset("ANIM", "anim/elecarmet_normal1.zip"),
    Asset("ANIM", "anim/elecarmet_normal2.zip"),
    Asset("ANIM", "anim/elecarmet_normal3.zip"),
    --Asset("ANIM", "anim/elecarmet_normal4.zip"),	--这部分是完全没修改过的贴图，不需要重新导入

    --激怒状态的贴图
    --Asset("ANIM", "anim/elecarmet_irritated1.zip"),
    --Asset("ANIM", "anim/elecarmet_irritated2.zip"),
    --Asset("ANIM", "anim/elecarmet_irritated3.zip"),
    --Asset("ANIM", "anim/elecarmet_irritated4.zip"),	--不必要的贴图

    Asset("ANIM", "anim/lavaarena_boarrior_basic.zip"),	--必须注册这个官方的boss动画压缩包才行
}

local prefabs =
{
	"sandspike_short",
}

SetSharedLootTable( "lavaarena_boarrior",
{
})

local targetDist = 25

local BossSpeech = {
	spawn = {"融合....完成...."},
	chat = {
		"我们...在燃烧....",
		"我们需要....目标....",
		"我们需要...专注...",
	},
	help = {
		"就要....消亡.....",
		"快要...消散....",
	},
	newcombattarget = {
		"统御....",
		"毁灭.....",
		"杀戮.....",
		"蒸腾....",
		"势不...可挡....",
		"摧毁...",
		"歼灭...",
		"淹没.....",
		"掘除....",
		"Mok'taridan....",
	},
}

local function PickSpeechAndSay(inst,type)
	local speech = BossSpeech[type]
	local say = speech[math.random(1,#speech)]
	inst.components.talker:Say(say)
end 

local function OnDoneTalking(inst)
    if inst.talktask ~= nil then
        inst.talktask:Cancel()
        inst.talktask = nil
    end
    inst.SoundEmitter:KillSound("talk")
end

local function OnTalk(inst)
    OnDoneTalking(inst)
    inst.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/talk_LP", "talk")
    inst.talktask = inst:DoTaskInTime(0.5 + math.random() * .5, OnDoneTalking)
end

local function NormalChat(inst)
	inst:PickSpeechAndSay("chat")
	inst.NormalChatTask = inst:DoTaskInTime(math.random()*8 + 5,NormalChat)
end 

local function PushMusic(inst)
    if ThePlayer == nil then
        inst._playingmusic = false
    elseif ThePlayer:IsNear(inst, inst._playingmusic and 40 or 20) then
		--print(inst,ThePlayer,"Push the triggeredevent at",GetTime())
        inst._playingmusic = true
        ThePlayer:PushEvent("triggeredevent", { name = "machine_god_judas" ,duration = 3})
    elseif inst._playingmusic and not ThePlayer:IsNear(inst, 50) then
        inst._playingmusic = false
    end
end

local function ListenForEventOnce(inst, event, fn, source)
    -- Currently, inst2 is the source, but I don't want to make that assumption.
    local function gn(inst2, data)
        inst:RemoveEventCallback(event, gn, source) --as you can see, it removes the event listener even before firing the function
        return fn(inst2, data)
    end
     
    return inst:ListenForEvent(event, gn, source)
end

local function IsEntityOnLine(ent, pt1, pt2) -- not net, geometry
	local xe, _, ye = ent.Transform:GetWorldPosition() 
    local radius = ent:GetPhysicsRadius(0) or 0.5

    local p1, p2 = {}, {}
    p1.x = pt1.x - xe
    p1.y = pt1.y - ye
    p2.x = pt2.x - xe
    p2.y = pt2.y - ye
    local dx = (p2.x - p1.x)
    local dy = (p2.y - p1.y)
    local a = dx * dx + dy * dy;
    local b = 2 * ( p1.x * dx + p1.y * dy);
    local c = p1.x * p1.x + p1.y * p1.y - radius * radius;

    if -b < 0 then return c < 0 end
    if -b < 2 * a then return 4 * a * c - b * b < 0 end
    return ((a + b + c < 0))
end

local function IsEntityInside(polygon, ent)
	local pt = {}
	pt.x, pt.o, pt.y = ent.Transform:GetWorldPosition() -- "_" does't work, let it be pt.o
	local radius = ent:GetPhysicsRadius(0) or 0.5
	local intersections = 0
	local prev = #polygon
	local prevUnder = polygon[prev].y < pt.y
	for i = 1, #polygon do
		local currUnder = polygon[i].y < pt.y
		local p1, p2 = {}, {}
		p1.x = polygon[prev].x - pt.x
		p1.y = polygon[prev].y - pt.y
        p2.x = polygon[i].x - pt.x
		p2.y = polygon[i].y - pt.y
		local dx = (p2.x - p1.x)
		local dy = (p2.y - p1.y)
		local t = (p1.x * dy - p1.y * dx)
		
		local a = dx * dx + dy * dy;
        local b = 2 * ( p1.x * dx + p1.y * dy);
        local c = p1.x * p1.x + p1.y * p1.y - radius * radius;

        if -b < 0 and c < 0 then return true end
        if -b < 2 * a and 4 * a * c - b * b < 0  then return true end
        if (a + b + c < 0) then return true end
		
		if currUnder and not prevUnder then
            if (t > 0) then
                intersections = intersections + 1
			end
		end
        
        if not currUnder and prevUnder then
            if (t < 0) then
                intersections = intersections + 1
			end
		end
		
		prev = i
        prevUnder = currUnder
	end
	return not IsNumberEven(intersections)
end

local function OnTimerDone(inst, data)
	if data.name == "regen_bossboar" then
		if inst._spawntask ~= nil then
			inst._spawntask:Cancel()
			inst._spawntask = nil
		end
		inst:Show()
		inst.DynamicShadow:Enable(true)
		SoftColorChange(inst, {0, 0, 0, 1}, {0, 0, 0, 0}, 2, 0.1)
		inst:DoTaskInTime(2, function(inst) SoftColorChange(inst, {1, 1, 1, 1}, {0, 0, 0, 1}, 2, 0.1) end)
		inst:DoTaskInTime(4, function(inst) 
			inst.brain:Start() 
			inst:SetEngaged()
			inst:ReTarget()
		end)
	end
end


local function ReTarget(inst)
	inst:SetEngaged()
	local player, distsq = inst:GetNearestPlayer()
    return (player and not player.components.health:IsDead()) and player or FindEntity(inst, 255, function(guy) return inst.components.combat:CanTarget(guy) and not guy.components.health:IsDead() end,nil, { "tadalin","wall", "LA_mob", "battlestandard" })
end

local function FindPlayerTarget(inst)
	local player, distsq = inst:GetNearestPlayer()
	if player then
		return not (player:HasTag("notarget") or player:HasTag("LA_mob")) and (player and not player.components.health:IsDead()) and player
	end
end

local function AttemptNewTarget(inst, target)
	local player, distsq = inst:GetNearestPlayer()
    if target ~= nil and inst:IsNear(target, 20) and player then
		return target
	else
		return not (player:HasTag("notarget") or player:HasTag("LA_mob")) and (player and not player.components.health:IsDead()) and player and player
	end
end


local function KeepTarget(inst, target)
    return inst.components.combat:CanTarget(target) and (target.components.health and not target.components.health:IsDead()) and not target:HasTag("tadalin")
end

local function OnAttacked(inst, data)
    local foe = data.attacker or nil
    local target = inst.components.combat.target or nil
    if foe and not foe:HasTag("notarget") and not (inst.aggrotimer and inst.components.combat.lastwasattackedtime <= inst.aggrotimer) then
		inst.aggrotimer = nil
        local hands = foe.components.inventory and foe.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS) or nil
        local thands = target and target.components.inventory and target.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS) or nil
        if target and not foe:HasTag("lessaggro") and not (hands and (hands:HasTag("rangedweapon") or hands:HasTag("blowdart"))) then
            if data.stimuli and data.stimuli == "electric" then
				inst.aggrotimer = GetTime() + 2
                inst.components.combat:SetTarget(foe)
			elseif foe:HasTag("grabaggro") then
				inst.aggrotimer = GetTime() + 2
				inst.components.combat:SetTarget(foe)
			elseif hands and hands:HasTag("hammer") and not target:HasTag("companion") and not (target:HasTag("moreaggro") or foe:HasTag("lessaggro")) and not inst.sg:HasStateTag("attack") then
				--print("OnAttacked melee check PASSED")
				inst.components.combat:SetTarget(foe)
			elseif hands and (hands:HasTag("sharp") or hands:HasTag("pointy") or hands:HasTag("book")) and not (target:HasTag("moreaggro") or foe:HasTag("lessaggro")) and not (thands and thands:HasTag("hammer")) and not inst.sg:HasStateTag("attack") then
				--print("OnAttacked melee check PASSED")
				inst.components.combat:SetTarget(foe)
			elseif not hands and not (target:HasTag("moreaggro") or foe:HasTag("lessaggro")) and not inst.sg:HasStateTag("attack") then	
				inst.components.combat:SetTarget(foe)	
            end 
        elseif target and target:HasTag("moreaggro") and math.random(1, 100) > 90 then
            inst.components.combat:SetTarget(foe)   
        elseif not target then
            inst.components.combat:SetTarget(foe)
        end             
    end
	inst.components.combat:ShareTarget(data.attacker, 30, function(dude)
        return  (dude:HasTag("tadalin"))
            and not dude.components.health:IsDead()
    end, 10)
	if inst.components.health and inst.components.health:GetPercent() <= 0.1 and GetTime() - inst.lasthelptime >= 10 then 
		inst:PickSpeechAndSay("help")
		inst.lasthelptime = GetTime()
	end
end

local function OnNewTarget(inst, data)
	inst:DoTaskInTime(math.random(),function()
		--inst.components.talker:Say(speech_infected[math.random(1,#speech_infected)])
		if GetTime() - inst.lasttargettime >= 8 then 
			inst:PickSpeechAndSay("newcombattarget")
			inst.lasttargettime = GetTime()
		end 
	end)
end

local function OnDeath(inst)
	local moonbase = FindEntity(inst, 10000, function(base) return base.prefab == "moonbase" end)
	if moonbase and moonbase:IsValid() and moonbase.components.moon_giaour_spawner then 
		moonbase.components.moon_giaour_spawner:SpawnMinions()
	end
end 

local function ChangeRageMult(inst)
	inst.sg:GoToState("taunt")
	if inst.components.health:GetPercent() <= 0.76 then
		--inst.rageMult = 1.25
	elseif inst.components.health:GetPercent() <= 0.51 then
		--inst.rageMult = 1.5
	elseif inst.components.health:GetPercent() <= 0.26 then
		--inst.rageMult = 2
		--[[ inst._mtask = inst:DoPeriodicTask(3, function(inst)
			local obj = SpawnPrefab("bossboarmeteor")
			local radius = math.random(5, 40)
			local angle = math.random(360) * DEGREES
			local x, y, z = inst.Transform:GetWorldPosition()
			obj.Transform:SetPosition(x + math.cos(angle) * radius, y, z + math.sin(angle))
			obj:StartMeteor(0.8, math.random(360))
		end) ]]
	end
end

local function SetEngaged(inst)
	if not inst.engaged then
		--print("pulled")
		--inst.components.health:
		--(1000 + 100 * #AllPlayers)
		inst.engaged = true
		inst.lastWirlWind = GetTime()
		inst.lastGroundSlam = GetTime()
		inst.lastGroundBurn = GetTime()
		inst.lastCombo = GetTime()

		--inst.components.timer:StartTimer("whirlwindcd", TUNING.CCW.BOSSBOAR.WHIRLWINDCD)
		--inst.components.timer:StartTimer("groundslamcd", inst:CalculateGroundSlamCD(inst))
		--inst.components.timer:StartTimer("meteorshowercd", TUNING.CCW.BOSSBOAR.METEORCD)
		--inst.components.timer:StartTimer("comboattack", inst:CalculateComboCD(inst))

		inst:ChangeRageMult(inst)
		--inst._rtask = inst:DoPeriodicTask(1, function(inst) 
			--inst.rageCount = inst.rageCount < 100 and inst.rageCount + 25 * inst.rageMult or 100
		--end)
	end
end

local function SetEvaded(inst)
	if inst.engaged then
		--inst.components.health:SetMaxHealth(1000)
		--print("evaded")
		inst.engaged = false
		--inst.components.health:SetPercent(100)
		--inst._rtask:Cancel()
		if inst._mtask ~= nil then
			inst._mtask:Cancel()
			inst._mtask = nil
		end

		if inst._rtask ~= nil then
			inst._rtask:Cancel()
			inst._rtask = nil
		end

		inst.engagedUnits = {}
	end
end

local function CalculateComboCD(inst)
	return math.max(5, math.modf(inst.components.health:GetPercent() * 20))
end

local function CalculateGroundSlamCD(inst)
	local cd = 2
	if inst.components.health:GetPercent() > 0.75 then
		cd = 20
	elseif inst.components.health:GetPercent() > 0.5 then
		cd = 12
	elseif inst.components.health:GetPercent() > 0.3 then
		cd = 8
	--elseif inst.components.health:GetPercent() > 0.15 then
		--cd = 2
	end
	--print("slam cd: " .. cd)
	return cd
end

--groundslam-----------------------------------
-----------------------------------------------
local function GroundSlamTargets(inst, polygon)
	local x, y, z = inst.Transform:GetWorldPosition()
	local ents = TheSim:FindEntities(x, y, z, 16, nil, { "NOCLICK", "FX", "shadow", "playerghost", "INLIMBO" })
	for _, ent in pairs(ents) do
		if ent ~= inst and ent:IsValid() and ent.entity:IsVisible()  then
			local entPoint = {}
			entPoint[1], _, entPoint[2] = ent.Transform:GetWorldPosition()
			--local str = "checking " .. ent.prefab or "something" .. " x: " .. entPoint[1] .. " y:" .. entPoint[2] .. "... "
			if IsEntityInside(polygon, ent) then
				--str = str .. "is in!"
				if ent.components.workable 
					and ent.components.workable:CanBeWorked() 
					and not (ent.sg ~= nil and ent.sg:HasStateTag("busy")) 
				then
					--print("digging", ent)
                    if ent.components.workable:GetWorkAction() == ACTIONS.DIG then
						ent.components.workable:WorkedBy(inst, 1)
                    end
				elseif ent.components.combat ~= nil then
					ent.components.combat:GetAttacked(inst, 10, nil)
				end
			--else
				--str = str .. "nope"
			end
			--print(str)
		end
	end
end

local function GroundSlam(inst, target)
	local points = {}
	local polygon = {}
	local x, y, z = inst.Transform:GetWorldPosition() 
	--local target = FindClosestPlayerInRange(x, y, z, 20, true)
	if target == nil and not target:IsValid() and not target.entity:IsVisible() then return end
	local tx, ty, tz = target.Transform:GetWorldPosition()
	inst:ForceFacePoint(tx, ty, tz)
	local angle = (inst.Transform:GetRotation())
	local angle1 = (angle - 60) * DEGREES
	local angle2 = (angle + 60) * DEGREES
	angle = angle * DEGREES
	local x1 = x + math.cos(angle1) * 2 
	local z1 = z - math.sin(angle1) * 2 
	local x2 = x + math.cos(angle2) * 2 
	local z2 = z - math.sin(angle2) * 2 
	local maxDistance = 15
	local minDistance = 1
	for i = minDistance, maxDistance, 2 do
		local tile = nil
		local pt1 = {x + math.cos(angle) * i, y, z - math.sin(angle) * i}
		local pt2 = {x1 + math.cos(angle) * i, y, z1 - math.sin(angle) * i}
		local pt3 = {x2 + math.cos(angle) * i, y, z2 - math.sin(angle) * i}
		tile = TheWorld.Map:GetTileAtPoint(pt1[1], pt1[2], pt1[3])
		if tile ~= GROUND.IMPASSABLE and tile ~= GROUND.INVALID then
			table.insert(points, pt1)
		end
		tile = TheWorld.Map:GetTileAtPoint(pt2[1], pt2[2], pt2[3])
		if tile ~= GROUND.IMPASSABLE and tile ~= GROUND.INVALID then
			table.insert(points, pt2)
		end
		tile = TheWorld.Map:GetTileAtPoint(pt3[1], pt3[2], pt3[3])
		if tile ~= GROUND.IMPASSABLE and tile ~= GROUND.INVALID then
			table.insert(points, pt3)
		end
		if i == minDistance then
			table.insert(polygon, { x = pt3[1], y = pt3[3] })
			table.insert(polygon, { x = pt2[1], y = pt2[3] })
		end
		if i == maxDistance then
			table.insert(polygon, { x = pt2[1], y = pt2[3] })
			table.insert(polygon, { x = pt3[1], y = pt3[3] })
		end
	end
	-------------------------------------
	--[[for k, v in pairs(polygon) do
		print("x: ".. k .. v[1] .. " y: " .. k .. " " .. v[2])
	end]]
	GroundSlamTargets(inst, polygon)
	--------------------------------------
	
	inst:DoTaskInTime(0.5, function(inst, points, polygon)
		for i, pt in pairs(points) do
			local obj = SpawnPrefab("sandspike_short")
			if i == 2 or i == 8 or i == 20 then
				--obj.entity:AddSoundEmitter()
				--obj.SoundEmitter:PlaySound("dontstarve/common/fireBurstSmall")
			end
			--obj.Transform:SetPosition(pt[1], pt[2], pt[3])	
		end
		GroundSlamTargets(inst, polygon)
	end, points, polygon)
end

--------New groundslam--------------------------
------------------------------------------------

local function SpawnFireSpike(pos,name) ---halloween_firepuff_1 halloween_firepuff_2 halloween_firepuff_3
	local fx = SpawnPrefab(name or "halloween_firepuff_cold_1")
	fx.Transform:SetPosition(pos:Get())
end 

local function DoTrail(inst, targetposx, targetposz, trailend)
	inst.stopslam = nil --might fix no slam bug?
	local startingpos = inst:GetPosition()
	inst:ForceFacePoint(targetposx, 0, targetposz)
	--if TheWorld.Map:IsAboveGroundAtPoint(targetposx, 0, targetposz) and TheWorld.Pathfinder:IsClear(startingpos.x, startingpos.y, startingpos.z, targetposx, 0, targetposz, {ignorewalls = false, ignorecreep = true}) then
		local targetpos = {x = targetposx, y = 0, z = targetposz}
		local found_players = {}
		
		local angle = -inst.Transform:GetRotation() * DEGREES
		local angled_offset = {x = 1.25 * math.cos(angle+90), y = 0, z = 1.25 * math.sin(angle+90)}
		local angled_offset2 = {x = 1.25 * math.cos(angle), y = 0, z = 1.25 * math.sin(angle)}
		local angled_offset3 = {x = 1.25 * math.cos(angle-90), y = 0, z = 1.25 * math.sin(angle-90)}
		local impact_distance = 36
					
		local maxtrails = 15
		for i = 1, maxtrails do
			inst:DoTaskInTime(FRAMES*math.ceil(1+i/ (trailend and 1.5 or 3.5)), function()
				local offset = (targetpos - startingpos):GetNormalized()*(i)
				local x, y, z = (startingpos + offset):Get()
				if TheWorld.Map:IsAboveGroundAtPoint((startingpos+offset):Get()) and not inst.stopslam then
					if i > 6 then
						local bluecolour = {0/255,255/255,255/255,1}
						local fx1 = SpawnPrefab(trailend ~= nil and "lavaarena_groundlift" or "lavaarena_groundliftrocks")
						fx1.AnimState:SetMultColour(unpack(bluecolour))
						fx1.Transform:SetPosition((startingpos+offset+angled_offset):Get())
						local fx2 = SpawnPrefab(trailend ~= nil and "lavaarena_groundlift" or "lavaarena_groundliftrocks")
						fx2.AnimState:SetMultColour(unpack(bluecolour))
						fx2.Transform:SetPosition((startingpos+offset+angled_offset2):Get())
						local fx3 = SpawnPrefab(trailend ~= nil and "lavaarena_groundlift" or "lavaarena_groundliftrocks")
						fx3.AnimState:SetMultColour(unpack(bluecolour))
						fx3.Transform:SetPosition((startingpos+offset+angled_offset3):Get())
						SpawnFireSpike(startingpos+offset+angled_offset,"halloween_firepuff_cold_"..tostring(math.random(1,3)))
						SpawnFireSpike(startingpos+offset+angled_offset2,"halloween_firepuff_cold_"..tostring(math.random(1,3)))
						SpawnFireSpike(startingpos+offset+angled_offset3,"halloween_firepuff_cold_"..tostring(math.random(1,3)))
						if not inst:HasTag("groundspike") then
							inst:AddTag("groundspike")
						end
					end
					local ents = TheSim:FindEntities(x, y, z, 2.5, { "locomotor" }, { "LA_mob", "shadow", "playerghost", "INLIMBO","tadalin" })
					for _,ent in ipairs(ents) do
						if ent ~= inst and inst.components.combat:IsValidTarget(ent) and ent.components.health and not ent.hasbeenhit then
							inst:PushEvent("onareaattackother", { target = ent--[[, weapon = self.inst, stimuli = self.stimuli]] })
							--Leo:Temporary fix for preventing multiple hits.
							ent.components.combat:GetAttacked(inst, i < 6 and 150 or (150 * 0.75 * (not trailend and 0.5 or 1)))
							ent.hasbeenhit = true
							ent:DoTaskInTime(0.25, function(inst) inst.hasbeenhit = nil end)
						--SpawnPrefab("forgespear_fx"):SetTarget(ent)
						end
					end
				else
					inst.stopslam = true
				end	
				if i == maxtrails then
					inst.stopslam = nil
				end
			end)
		end
	--end
end

--meteors-----------------------------------
-----------------------------------------------
local function GroundBurn(inst)
	--[[local pos = Vector3(inst.Transform:GetWorldPosition())
	local victims = FindPlayersInRangeSq(pos.x, pos.y, pos.z, 400, true)
	if not victims or #victims == 0 then return end
	if #victims > 1 and inst.components.combat ~= nil and inst.components.combat.target ~= nil then -- we dont want use shower on current tank, if there are other targets
		RemoveByValue(victims, inst.components.combat.target)
	end
	local victim = victims[math.random(#victims)]
	
	if victim and victim:IsValid() then
		local metAngle = math.random(360)
		for i = 1, 10 do
			inst:DoTaskInTime(0.2 * i, function(inst, victim) 
				if victim and victim:IsValid() then
					local obj = SpawnPrefab("shadowmeteor")
					obj.Transform:SetPosition(victim.Transform:GetWorldPosition()) 
					--obj:StartBurst(inst, 0.7)
				end
			end, victim)
		end
	end--]]
	if inst.GroundBurnTask then 
		inst.GroundBurnTask:Cancel()
		inst.GroundBurnTask = nil 
	end
	inst.GroundBurnTask = inst:DoPeriodicTask(math.random()*0.1 + 0.1,function()
		local rad = math.random(7,15)
		local roa = math.random() * math.pi * 2
		local pos = inst:GetPosition()
		local offset = Vector3(rad*math.cos(roa),0,rad*math.sin(roa))
		local meteor = SpawnPrefab("boss_elecarmet_meteor")
		meteor.Transform:SetPosition((pos+offset):Get())
	end)
end

local function StopGroundBurn(inst)
	if inst.GroundBurnTask then 
		inst.GroundBurnTask:Cancel()
		inst.GroundBurnTask = nil 
	end
end 

--whirldwind-----------------------------------
-----------------------------------------------
local knockbackSpeedNoLoco = 5
local wwRadius = 5
local wwDamage = 50

local function WhirlWind(inst)
	--local creatures = {}
	--[[local x1, y1, z1 = inst.Transform:GetWorldPosition()
	local x2, y2, z2 = nil, nil, nil
	local ents = TheSim:FindEntities(x1, y1, z1, wwRadius, nil, { "NOCLICK", "FX", "shadow", "playerghost", "INLIMBO" })
	for i, ent in pairs(ents) do
		if ent ~= inst and ent:IsValid() 
			and ent.entity:IsVisible() 
			and not table.contains(inst.wwHitList, ent) 
		then
			--print(ent.prefab .. " knocked")
			table.insert(inst.wwHitList, ent)
			x2, y2, z2 = ent.Transform:GetWorldPosition()
			if ent.components.inventoryitem ~= nil then
				local str = ent:HasTag("heavy") and knockbackSpeedNoLoco / 2 or knockbackSpeedNoLoco
				ent.Physics:Teleport(x2, 0.5, z2)
				local vec = Vector3(x2 - x1, y2 - y1, z2 - z1):Normalize()
				ent.Physics:SetVel(vec.x * str, str, vec.z * str)
			elseif ent.components.locomotor ~= nil and not ent:HasTag("player") then
				--TODO
				--rework knockback for non-players cretures
			end

			if ent.components.combat ~= nil 
				and not ent.components.health:IsInvincible() then

				if ent:HasTag("player") then
					ent.sg:GoToState("knockback", { knocker = inst, radius = 8 })
					ent.sg:AddStateTag("nointerrupt")
					ent.components.combat:GetAttacked(inst, wwDamage, nil)
					ent.sg:RemoveStateTag("noiterrupt")
				else 
					ent.components.combat:GetAttacked(inst, wwDamage, nil)
				end
			end
		end
	end--]]
	inst.components.combat:DoAreaAttack(inst, 6.2, nil, nil, nil, {"battlestandard", "LA_mob", "shadow", "playerghost", "FX", "DECOR","tadalin"})
end

--combo----------------------------------------
-----------------------------------------------
local function ComboHit(inst, target)
	if not target then return end
	local damage = 50
	if target:IsValid() and target.entity:IsVisible() 
		and inst:GetDistanceSqToInst(target) <= 7 * 7 + 4
	then
		if target:HasTag("player") then
			--target.sg:GoToState("knockback", { knocker = inst, radius = 8 })
			target:PushEvent("knockback",{ knocker = inst, radius = 8 })
			target.sg:AddStateTag("nointerrupt")
			target.components.combat:GetAttacked(inst, damage, nil)
			target.sg:RemoveStateTag("noiterrupt")
		else
			damage = 200
			target.components.combat:GetAttacked(inst, damage, nil)
		end
	end
end


local function OnSave(inst, data)
	data.engaged = inst.engaged
	if inst.engaged then
		data.rageCount = inst.rageCount
	end
end

local function OnLoad(inst, data)
	if data ~= nil then
		if data.engaged then
			SetEngaged(inst)
			--inst.rageCount = data.rageCount
			ReTarget(inst)
		end
	end
end

local function GetDebugString(inst)
	return string.format("WW: %.2f, GS: %.2f, GB: %.2f, CA: %.2f",
		math.max(12 - (GetTime() - inst.lastWirlWind), 0),
		math.max(inst:CalculateGroundSlamCD() - (GetTime() - inst.lastGroundSlam), 0),
		math.max(12 - (GetTime() - inst.lastGroundBurn), 0),
		math.max(inst:CalculateComboCD() - (GetTime() - inst.lastCombo), 0)
	)
end



local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddDynamicShadow()
    inst.entity:AddNetwork()
	inst.entity:AddLight()

    inst.DynamicShadow:SetSize(4, 2)
    --inst.DynamicShadow:Enable(false)
	
	inst.Light:SetIntensity(0.7)
	inst.Light:SetRadius(7)
	inst.Light:SetFalloff(0.5)
	inst.Light:SetColour(44/255,143/255,255/255)
	inst.Light:Enable(true)

    inst.Transform:SetFourFaced()
    inst.Transform:SetScale(1.4, 1.4, 1.4)

    inst:SetPhysicsRadiusOverride(2)
    --MakeGiantCharacterPhysics(inst, 1000, 1.2)
    MakeFlyingGiantCharacterPhysics(inst, 500, 1.4)
    inst.Physics:SetCapsule(2, 2)

    inst.AnimState:SetBank("boarrior")
    inst.AnimState:SetBuild("lavaarena_boarrior_basic")
    inst.AnimState:PlayAnimation("idle_loop", true)

    -------------
    
    inst.AnimState:OverrideSymbol("arm", "elecarmet_normal1", "arm")
    inst.AnimState:OverrideSymbol("chest", "elecarmet_normal1", "chest")

    inst.AnimState:OverrideSymbol("eyes", "elecarmet_normal2", "eyes")
    inst.AnimState:OverrideSymbol("rock2", "elecarmet_normal2", "rock2")
    inst.AnimState:OverrideSymbol("shoulder", "elecarmet_normal2", "shoulder")
    inst.AnimState:OverrideSymbol("swap_weapon", "elecarmet_normal2", "swap_weapon")

    inst.AnimState:OverrideSymbol("hand", "elecarmet_normal3", "hand")
    inst.AnimState:OverrideSymbol("head", "elecarmet_normal3", "head")
    inst.AnimState:OverrideSymbol("mouth", "elecarmet_normal3", "mouth")
    inst.AnimState:OverrideSymbol("nose", "elecarmet_normal3", "nose")
    inst.AnimState:OverrideSymbol("pelvis", "elecarmet_normal3", "pelvis")
    inst.AnimState:OverrideSymbol("rock", "elecarmet_normal3", "rock")
    inst.AnimState:OverrideSymbol("swap_weapon_spin", "elecarmet_normal3", "swap_weapon_spin")
    
    --inst.AnimState:OverrideSymbol("spark", "elecarmet_normal4", "spark")
    --inst.AnimState:OverrideSymbol("splash", "elecarmet_normal4", "splash")
    --inst.AnimState:OverrideSymbol("swipes", "elecarmet_normal4", "swipes")

    -------------

    inst:AddTag("hostile")	--敌对标签
    inst:AddTag("scarytoprey")	--吓跑小动物标签
    inst:AddTag("largecreature")
    inst:AddTag("epic")
    inst:AddTag("flying")
    inst:AddTag("electrified")
	inst:AddTag("tadalin")
	inst:AddTag("noepicmusic")
	
	inst._playingmusic = false
	if not TheNet:IsDedicated() then
        inst:DoPeriodicTask(1, PushMusic,0)
    end
	
	inst:AddComponent("spawnfader")
	
	inst:AddComponent("talker")
    inst.components.talker.fontsize = 40
    inst.components.talker.font = TALKINGFONT
    inst.components.talker.colour = Vector3(0 / 255, 126 / 255, 255 / 255)
    inst.components.talker.offset = Vector3(0, -1000, 0)
    inst.components.talker.symbol = "fossil_chest"
    inst.components.talker:MakeChatter()

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

	inst:AddComponent("locomotor") -- locomotor must be constructed before the stategraph
	inst.components.locomotor:EnableGroundSpeedMultiplier(false)
	inst.components.locomotor.runspeed = 12
	inst.components.locomotor.walkspeed = 4

	--local sg = require "stategraphs/SGlavaarena_boarrior"
	inst:SetStateGraph("SGboss_elecarmet")

	local brain = require "brains/boss_elecarmetbrain"
	inst:SetBrain(brain)

	inst:AddComponent("knownlocations")

	inst:AddComponent("health")
	inst.components.health:SetMaxHealth(22500)
	inst.components.health.destroytime = 20
	
	inst:AddComponent("healthtrigger")
	inst.components.healthtrigger:AddTrigger(0.75, ChangeRageMult)
	inst.components.healthtrigger:AddTrigger(0.50, ChangeRageMult)
	inst.components.healthtrigger:AddTrigger(0.25, ChangeRageMult)
	--inst.components.health.poison_damage_scale = 0 -- immune to poison

	inst:AddComponent("combat")
	inst.components.combat.playerdamagepercent = 0.5 
	inst.components.combat:SetDefaultDamage(100)--(100)
	inst.components.combat:SetAttackPeriod(4)
	inst.components.combat:SetRetargetFunction(5, ReTarget)
	inst.components.combat:SetKeepTargetFunction(KeepTarget)
	
	inst.components.combat:SetRange(7, 7 + 2)
	inst.components.combat.battlecryenabled = false
	inst.components.combat.hiteffectsymbol = "pelvis"
	inst.components.combat:SetHurtSound("dontstarve/forge2/beetletaur/chain_hit")

	inst:AddComponent("lootdropper")
	inst.components.lootdropper:SetChanceLootTable("lavaarena_boarrior")

	inst:AddComponent("inspectable")
	inst:AddComponent("sanityaura")
	inst:AddComponent("explosiveresist")
	
	--inst:AddComponent("sleeper")
	--inst.components.sleeper:SetResistance(99999)
    --inst.components.sleeper.diminishingreturns = true
	
	inst:AddComponent("timer")
	
	inst.OnSave = OnSave
    inst.OnLoad = OnLoad
	inst.ReTarget = ReTarget
	--pull/evade
	inst.engaged = false
	inst.engagedUnits = {}
	inst.SetEngaged = SetEngaged
	inst.SetEvaded = SetEvaded

	inst.lastWirlWind = GetTime()
	inst.lastGroundSlam = GetTime()
	inst.lastGroundBurn = GetTime()
	inst.lastCombo = GetTime()

	inst.ChangeRageMult = ChangeRageMult
	inst.CalculateComboCD = CalculateComboCD
	inst.CalculateGroundSlamCD = CalculateGroundSlamCD
	
	--spells
	inst._rtask = nil
	inst._mtask = nil

	inst.rageCount = 0
	inst.rageMult = 1
	
	inst.lasthelptime = 0
	inst.lasttargettime = 0

	inst.DoTrail = DoTrail
	inst.GroundSlam = GroundSlam
	inst.GroundBurn = GroundBurn
	inst.StopGroundBurn = StopGroundBurn
	inst.WhirlWind = WhirlWind
	inst.ComboHit = ComboHit

	inst.showerHittedList = {}
	inst.wwHitList = {}
	
	inst.PickSpeechAndSay = PickSpeechAndSay

	--inst:ListenForEvent("death", OnDeath)
	inst:ListenForEvent("attacked", OnAttacked)
	inst:ListenForEvent("timerdone", OnTimerDone)
	inst:ListenForEvent("ontalk", OnTalk)
	inst:ListenForEvent("newcombattarget", OnNewTarget)
	
	--inst:ListenForEvent("death",OnDeath)
	
	inst.NormalChatTask =  inst:DoTaskInTime(math.random()*3 + 3,NormalChat)
	

	--MakeMediumFreezableCharacter(inst, "hound_body")
	--MakeMediumBurnableCharacter(inst, "body")

	inst.debugstringfn = GetDebugString

    return inst
end

return Prefab("boss_elecarmet", fn, assets, prefabs)
