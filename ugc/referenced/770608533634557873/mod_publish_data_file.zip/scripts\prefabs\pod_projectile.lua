local assets =
{
    Asset("ANIM", "anim/pod_projectile.zip"),
	Asset("ANIM", "anim/fireball_2_fx.zip"),
	Asset("ANIM", "anim/deer_ice_charge.zip"),
}

local assets_fx = {
	Asset("ANIM", "anim/deer_ice_charge.zip"),
}

local function CreateTail(bank, build, anim,lightoverride, addcolour, multcolour,scale)
  local inst = CreateEntity()
  scale = scale or 1

  inst:AddTag("FX")
  inst:AddTag("NOCLICK")
  --[[Non-networked entity]]
  inst.entity:SetCanSleep(false)
  inst.persists = false

  inst.entity:AddTransform()
  inst.entity:AddAnimState()

  MakeInventoryPhysics(inst)
  inst.Physics:ClearCollisionMask()

  inst.AnimState:SetBank(bank)
  inst.AnimState:SetBuild(build)
  inst.AnimState:PlayAnimation(anim)

  inst.Transform:SetScale(scale,scale,scale)
  if addcolour ~= nil then
    inst.AnimState:SetAddColour(unpack(addcolour))
  end
  if multcolour ~= nil then
    inst.AnimState:SetMultColour(unpack(multcolour))
  end
  if lightoverride > 0 then
    inst.AnimState:SetLightOverride(lightoverride)
  end
  inst.AnimState:SetFinalOffset(-1)

  inst:ListenForEvent("animover", inst.Remove)

  return inst
end

local function OnUpdateProjectileTail(inst, bank, build, anim,speed, lightoverride, addcolour, multcolour, hitfx, tails,rad,scale)
	if inst:HasTag("time_stopped") then 
		return 
	end
  local x, y, z = inst.Transform:GetWorldPosition()
  y = y + 0.3
  rad = rad or 0.1 
  for tail, _ in pairs(tails) do
    tail:ForceFacePoint(x, y, z)
  end
  if inst.entity:IsVisible() then
    local tail = CreateTail(bank, build,anim ,lightoverride, addcolour, multcolour,scale)
    local rot = inst.Transform:GetRotation()
    tail.Transform:SetRotation(rot)
    rot = rot * DEGREES
    local offsangle = math.random() * 2 * PI
    local offsradius = math.random() * rad + rad
    local hoffset = math.cos(offsangle) * offsradius
    local voffset = math.sin(offsangle) * offsradius
	--tail.entity:SetParent(inst.entity)         
	--v.hunterfx.Transform:SetPosition(0,2.5,0) 
    tail.Transform:SetPosition(x + math.sin(rot) * hoffset, y + voffset, z + math.cos(rot) * hoffset)
	--tail.Transform:SetPosition(math.sin(rot) * hoffset,voffset + 2.1 ,math.cos(rot) * hoffset)
    tail.Physics:SetMotorVel(-speed * (rad + math.random() * (rad+0.1)), 0, 0)
    tails[tail] = true
    inst:ListenForEvent("onremove", function(tail) tails[tail] = nil end, tail)
    tail:ListenForEvent("onremove", function(inst)
      tail.Transform:SetRotation(tail.Transform:GetRotation() + math.random() * 30 - 15)
    end, inst)
  end
end

local function OnHit(inst,attacker,target)
	local x,y,z = target.Transform:GetWorldPosition()
	local cast = SpawnPrefab("pod_projectile_hitfx")
	cast.Transform:SetPosition(x,y+1.5,z)
	cast.Transform:SetScale(0.8,0.8,0.8)
	inst:Hide()
	inst:DoTaskInTime(2,inst.Remove)
end 

local function OnHitFire(inst,attacker,target)
	local x,y,z = target.Transform:GetWorldPosition()
	local cast = SpawnPrefab("fireball_hit_fx")
	local scale = inst.Transform:GetScale()
	cast.Transform:SetPosition(x,y,z)
	cast.Transform:SetScale(scale,scale,scale)
	if cast and cast:IsAsleep() then
	    cast:Remove()
	end
	inst:Remove()
end 



local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()

    MakeInventoryPhysics(inst)
    RemovePhysicsColliders(inst)

    inst.AnimState:SetBank("pod_projectile")
    inst.AnimState:SetBuild("pod_projectile")
    inst.AnimState:PlayAnimation("ice", true)
    --inst.AnimState:SetBloomEffectHandle("shaders/anim.ksh")
	
	inst.AnimState:SetLightOverride(1)
	--inst.AnimState:SetFinalOffset(-1)

    --projectile (from projectile component) added to pristine state for optimization
    inst:AddTag("projectile")
	
	if not TheNet:IsDedicated() then
      inst:DoPeriodicTask(0, OnUpdateProjectileTail, nil, "pod_projectile", "pod_projectile","grow" ,3, 1, nil, nil, nil, {},0.1,1)
    end

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst:AddComponent("projectile")
    inst.components.projectile:SetSpeed(50)
    inst.components.projectile:SetOnHitFn(OnHit)
    inst.components.projectile:SetOnMissFn(inst.Remove)
	inst.components.projectile:SetHitDist(1.5)
	
	--[[local fx = SpawnPrefab("icey_pod_projectile_smoke")
    fx.entity:AddFollower()
    fx.Follower:FollowSymbol(inst.GUID, "projectile01", 0,0, 0)--]]
	
	--inst:ListenForEvent("onthrown",onthrown)

    return inst
end

local function firefn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()

    MakeInventoryPhysics(inst)
    RemovePhysicsColliders(inst)

    inst.AnimState:SetBank("pod_projectile")
    inst.AnimState:SetBuild("pod_projectile")
    inst.AnimState:PlayAnimation("fire", true)
    --inst.AnimState:SetBloomEffectHandle("shaders/anim.ksh")
	
	inst.AnimState:SetLightOverride(1)
	--inst.AnimState:SetFinalOffset(-1)

    --projectile (from projectile component) added to pristine state for optimization
    inst:AddTag("projectile")
	
	if not TheNet:IsDedicated() then
      inst:DoPeriodicTask(0, OnUpdateProjectileTail, nil, "pod_projectile", "pod_projectile","grow_fire" ,3, 1, nil, nil, nil, {},0.1,1)
    end

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst:AddComponent("projectile")
    inst.components.projectile:SetSpeed(50)
    inst.components.projectile:SetOnHitFn(OnHitFire)
    inst.components.projectile:SetOnMissFn(inst.Remove)
	inst.components.projectile:SetHitDist(1.5)
	inst.components.projectile:SetLaunchOffset(Vector3(0.5,0,0))
	
	
	--inst:ListenForEvent("onthrown",onthrown)

    return inst
end

local function fxfn()
	local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
	inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()

    inst.AnimState:SetBank("deer_ice_charge")
    inst.AnimState:SetBuild("deer_ice_charge")
    inst.AnimState:PlayAnimation("blast")
    --inst.AnimState:SetBloomEffectHandle("shaders/anim.ksh")
	inst.SoundEmitter:PlaySound("dontstarve/creatures/rook/pawground")
	inst:AddTag("FX")
	
	inst.AnimState:SetLightOverride(1)
	
	inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst:ListenForEvent("animover",inst.Remove)
	
	return inst
end


return Prefab("pod_projectile", fn, assets),
Prefab("pod_projectile_fire", firefn, assets),
Prefab("pod_projectile_hitfx", fxfn, assets_fx)
