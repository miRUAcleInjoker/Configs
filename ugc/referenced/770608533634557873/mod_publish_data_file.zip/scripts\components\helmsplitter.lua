

local function onready(self, ready, _ready)
    if _ready == true and ready == true then
        self.inst:AddTag("helmsplitter")
    elseif _ready == true and ready == false then
        self.inst:RemoveTag("helmsplitter")
    end
end

local HelmSplitter = Class(function(self, inst)
    self.inst = inst
    self.ready = true
    self.onhelmsplit = nil
end,
nil,
{
    ready = onready
})

function HelmSplitter:SetOnHelmSplitFn(fn)
    self.onhelmsplit = fn
end

-- Starts the helm split attack
function HelmSplitter:StartHelmSplitting(player)
    if player.sg then
        player.sg:PushEvent("start_helmsplit")
        return true
    end
    
    return false
end

--Creates a helmsplit that hits the given target
function HelmSplitter:DoHelmSplit(player, target)
    if player.sg then
        player.sg:PushEvent("do_helmsplit")
    end

    local damage_mult = player.components.combat.damagemultiplier
    
    --Each thrust should have the bonus from Battle Cry, add the bonus if it was removed
    --[[if not player.battlecry_fx then
        damage_mult = damage_mult + TUNING.FORGE.BATTLECRY.DAMAGE_MULTIPLIER_INCREASE - 1
    end
    player.components.combat:DoSpecialAttack(self.damage, target, "strong", damage_mult)--]]
	if target and target:IsValid() then 
		player.components.combat:DoAttack()
		player.components.combat:DoAreaAttack(target,3,self.inst, nil, nil, { "INLIMBO" ,"companion"})
		print(self.inst,"DoHelmSplit:",player,target)
		if self.onhelmsplit then self.onhelmsplit(self.inst, player, target) end
	end
end

-- Stop helmsplitting and reset it
function HelmSplitter:StopHelmSplitting(player)
    if player.sg then
        player.sg:PushEvent("stop_helmsplit")
    end

    self.ready = false
end

return HelmSplitter