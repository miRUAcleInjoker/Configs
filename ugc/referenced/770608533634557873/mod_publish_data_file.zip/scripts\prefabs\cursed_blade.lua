local IceyUtil = require("icey_util")
local IceyWeaponSkillUtil = require("icey_weaponskill_util")

local assets =
{
	Asset("ANIM", "anim/cursed_blade.zip"),
	Asset("ANIM", "anim/cursed_blade_eye.zip"),
	Asset("ANIM", "anim/swap_cursed_blade.zip"),
	Asset("IMAGE","images/inventoryimages/cursed_blade.tex"),
	Asset("ATLAS","images/inventoryimages/cursed_blade.xml"),
}

local function EnableEye(inst,enable,type)
	if inst.cursed_eye then 
		inst.cursed_eye:Remove()
		inst.cursed_eye = nil 
	end
	--[[
	
	c_findnext("cursed_blade").cursed_eye.Follower:FollowSymbol(ThePlayer.GUID, "swap_object",5,-130, 0) 
	c_findnext("cursed_blade").cursed_eye.Follower:FollowSymbol(c_findnext("cursed_blade").GUID, "cursed_blade",-4,-95, 0) 
	
	
	--]]
	
	if enable and type then 
		inst.cursed_eye = SpawnPrefab("cursed_blade_eye")
		inst.cursed_eye.entity:AddFollower()
		if type == "equip" then 
			local owner = inst.components.inventoryitem.owner
			if owner then 
				inst.cursed_eye.Follower:FollowSymbol(owner.GUID, "swap_object",inst.equip_offset:Get())
			end
		elseif type == "ground" then 
			inst.cursed_eye.Follower:FollowSymbol(inst.GUID, "cursed_blade",inst.ground_offset:Get())
		else
			inst.cursed_eye:Remove()
			inst.cursed_eye = nil 
		end
	end
end 

local function onequip(inst,owner)	
	inst:EnableEye(true,"equip") 
	inst:ListenForEvent("attacked",inst._on_owner_attacked,owner)
end 

local function onunequip(inst,owner)
	inst:EnableEye(false) 
	inst:RemoveEventCallback("attacked",inst._on_owner_attacked,owner)
end 

local function topocket(inst)
	inst:EnableEye(false) 
end 

local function toground(inst)
	inst:EnableEye(true,"ground") 
end 

local function clientfn(inst)
	IceyWeaponSkillUtil.AddAoetargetingClient(inst,"line",{"iceyweaponskill_taunt"},15)
end 

local function serverfn(inst)
	if not TheWorld.ismastersim then
		return inst
	end	  
	
	inst.equip_offset = Vector3(6.5,-132, -0.1)
	inst.ground_offset = Vector3(-1,-92.5, 0)
	
	inst.EnableEye = EnableEye
	inst._on_owner_attacked = function(owner,data)
		if data and data.damage >= 0 and not (owner.components.health and owner.components.health:IsDead()) then 
			IceyUtil.AddDarkSoulCurseDeathDebuff(owner,{percent = 1.0})
		end 
	end 
	
	
	IceyWeaponSkillUtil.AddAoetargetingServer(inst,function(inst,doer,pos)
		if IceyUtil.DefaultCostFn(doer,{focus = 5}) then 
			inst.components.rechargeable:StartRecharge()
			doer:SpawnChild("sanity_lower")
			doer.SoundEmitter:PlaySound("dontstarve/cave/nightmare_warning")
			local x,y,z = doer.Transform:GetWorldPosition()
			local ents = TheSim:FindEntities(x,y,z,25,{"_combat","hostile"})
			for k,v in pairs(ents) do 
				v:DoTaskInTime(math.random()*0.6,function()
					if v.components.combat then 
						local scale = v:HasTag("largecreature") and 2 or 1
						v:SpawnChild("sanity_raise").Transform:SetScale(scale,scale,scale)
						v.components.combat:SuggestTarget(doer)
						if v.SoundEmitter then 
							v.SoundEmitter:PlaySound("dontstarve/sanity/shadowrock_up")
						end
					end
				end)
			end 
		end 
	end,nil,15)
	
	
	inst:ListenForEvent("onpickup",topocket)
	inst:ListenForEvent("ondropped",toground)
	
	inst:DoTaskInTime(0,function()
		if inst.components.inventoryitem.owner == nil then 
			toground(inst) 
		end
	end)
end

local DATA = {
	prefabname = "cursed_blade",
	assets = assets,
	tags = {"no_icey_miss","lunge_attack","hop_attack"},
	bank = "cursed_blade",
	build = "cursed_blade",
	anim = "idle",
	swapanims = {"swap_cursed_blade","swap_cursed_blade"},
	damage = 168,
	ranges = 0.2,
	onequip = onequip,
	onunequip = onunequip,
	clientfn = clientfn,
	serverfn = serverfn,
}

---------------------------------------------------------------------

local function eyefn()
	local inst = CreateEntity()
	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddSoundEmitter() 
	inst.entity:AddNetwork()
		
	inst.AnimState:SetBank("cursed_blade_eye")
	inst.AnimState:SetBuild("cursed_blade_eye")
		
	inst.AnimState:PlayAnimation("idle",true)
	
	inst.AnimState:SetFinalOffset(-1)

		
	inst.entity:SetPristine()
	
	if not TheWorld.ismastersim then
		return inst
	end
	
	inst.persists = false
	
	return inst
end

return IceyUtil.CreateNormalWeapon(DATA),Prefab("cursed_blade_eye", eyefn, assets) 