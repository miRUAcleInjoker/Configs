local IceyUtil = require("icey_util")
local assets =
{
	Asset("ANIM", "anim/vacuum_sword_fx.zip"),
	Asset("ANIM", "anim/lavaarena_shadow_lunge_fx.zip"),
} 

local function DoSound(inst)
	--inst.SoundEmitter:PlaySound("turnoftides/creatures/together/spider_moon/break")
	--inst.SoundEmitter:PlaySoundWithParams("turnoftides/common/together/moon_glass/break",{intensity=999})
	--"dontstarve/creatures/together/stalker/fossil_spike"
	inst.SoundEmitter:PlaySound("turnoftides/common/together/moon_glass/mine")
end 

local function extrafn(inst)
	inst.DoSound = DoSound 
	inst.AnimState:SetOrientation(ANIM_ORIENTATION.OnGround)
    inst.AnimState:SetLayer(LAYER_WORLD_BACKGROUND)
    inst.AnimState:SetSortOrder(2)
    inst.AnimState:SetScale(2.5,4,2.5)
	inst.AnimState:SetDeltaTimeMultiplier(1.8)
	inst.AnimState:SetLightOverride(1)
	inst.AnimState:SetFinalOffset(1)
	
	DoSound(inst)
	inst:DoTaskInTime(0,inst.DoSound)
	inst:DoTaskInTime(FRAMES,inst.DoSound)
end 

local function slashfn(inst)
	inst.Transform:SetEightFaced()
	inst.AnimState:SetLightOverride(1)
	inst.AnimState:SetFinalOffset(1)
end

return IceyUtil.CreateNormalFx("vacuum_sword_fx",assets,"vacuum_sword_fx","vacuum_sword_fx","idle",false,extrafn),
IceyUtil.CreateNormalFx("vacuum_sword_slash_fx1",assets,"lavaarena_shadow_lunge_fx","lavaarena_shadow_lunge_fx","line",false,slashfn),
IceyUtil.CreateNormalFx("vacuum_sword_slash_fx2",assets,"lavaarena_shadow_lunge_fx","lavaarena_shadow_lunge_fx","curve",false,slashfn)