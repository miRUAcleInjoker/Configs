local assets=
{
    Asset("ANIM", "anim/venus_stalk.zip"),
	Asset("IMAGE","images/inventoryimages/venus_stalk.tex"),
	Asset("ATLAS","images/inventoryimages/venus_stalk.xml"),
}
local function common(inst)
	local inst = CreateEntity()
	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddNetwork()
    
    MakeInventoryPhysics(inst)
    
    inst:AddTag("meat")
	
	inst.AnimState:SetBank("stalk")
    inst.AnimState:SetBuild("venus_stalk")
    inst.AnimState:PlayAnimation("idle")
	
	inst.entity:SetPristine()	
	
    if not TheWorld.ismastersim then
        return inst
    end	  

	
    inst:AddComponent("edible")
	inst.components.edible.healthvalue = 0
    inst.components.edible.hungervalue = TUNING.CALORIES_SMALL
    inst.components.edible.sanityvalue = -TUNING.SANITY_SMALL
	inst.components.edible.foodtype = FOODTYPE.VEGGIE
    
    inst:AddComponent("inspectable")
    
    inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "venus_stalk"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/venus_stalk.xml"
	
	inst:AddComponent("stackable")
	
    --inst:AddComponent("bait")
    
    inst:AddComponent("tradable")
    inst.components.tradable.goldvalue = TUNING.GOLD_VALUES.MEAT

	inst:AddComponent("perishable")
	inst.components.perishable:SetPerishTime(TUNING.PERISH_FAST)
	inst.components.perishable:StartPerishing()
	inst.components.perishable.onperishreplacement = "spoiled_food"

    return inst
end


 return Prefab("common/inventory/venus_stalk", common, assets)