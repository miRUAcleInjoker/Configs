--local Tadalin = require ("tadalin_util")

local haojie_assets = 
{
	Asset("ANIM", "anim/spider_haojie.zip"),---BUILD
	Asset("SOUND", "sound/spider.fsb"),
}

local dragoon_assets =
{
    --Asset("ANIM", "anim/spider_dragoon_0.zip"),
	Asset("ANIM", "anim/ds_spider_basic.zip"),
    Asset("ANIM", "anim/spider_dragoon_1.zip"),---BUILD
    Asset("SOUND", "sound/spider.fsb"),
}

local chaser_assets =
{	
	Asset("ANIM", "anim/ds_spider_basic.zip"),
	Asset("ANIM", "anim/ds_spider_warrior.zip"),
    Asset("ANIM", "anim/spider_chaser_0.zip"),---BUILD
    --Asset("ANIM", "anim/spider_chaser_1.zip"),
    --Asset("ANIM", "anim/spider_white.zip"),
    Asset("SOUND", "sound/spider.fsb"),
}

local xianfeng_assets = 
{
	Asset("ANIM", "anim/ds_spider_basic.zip"),
    Asset("ANIM", "anim/ds_spider_warrior.zip"),
	Asset("ANIM", "anim/spider_xianfeng_0.zip"),---BUILD
	--Asset("ANIM", "anim/spider_xianfeng_1.zip"),
    Asset("SOUND", "sound/spider.fsb"),
}

local bomb_assets =
{
	Asset("ANIM", "anim/spider_bomb_0.zip"),
    Asset("ANIM", "anim/spider_bomb_1.zip"),-----BUILD
	Asset("ANIM", "anim/spider_bomb_2.zip"),
	--Asset("ANIM", "anim/spider_bomb_2.zip"),
    --Asset("ANIM", "anim/spider_white.zip"),
    Asset("SOUND", "sound/spider.fsb"),
}

local function onattack_haojie (inst,data)
	local target = data.target
	if target ~= nil   and target.components.burnable ~= nil  then 
		print("浩劫烈焰")
		target.components.burnable:Ignite(true)
	end 
end

local function onattack_xianfeng(inst,data)
	local target=data.target
	if target and target.components.inventory then 
		local absorbers = {}
		local armor = 0
			for k, v in pairs(target.components.inventory.equipslots) do
				if v.components.armor and v.components.armor ~= nil then
					armor = 1
				end
			end			
		print("先锋破甲攻击")
		print(armor)
		if target ~= nil and armor ~= 0 then 
			target.components.health:DoDelta(-5)
		end
	end	
	if target then 
			local pos = target:GetPosition()
			local ents = TheSim:FindEntities(pos.x, pos.y, pos.z, 3, {"_combat"},{"spider","tadalin"})
				for k,v in pairs(ents) do 
					if v ~= target then 
						target.components.health:DoDelta(-5) 
					end 
				end
	end
end

local function OnAttacked_haojie(inst, data)
    inst.components.combat:SetTarget(data.attacker)
    inst.components.combat:ShareTarget(data.attacker, 30, function(dude)
        return  (dude:HasTag("spider") or dude:HasTag("tadalin"))
			and dude.components.health
            and not dude.components.health:IsDead()
            and dude.components.follower ~= nil
            and dude.components.follower.leader == inst.components.follower.leader
    end, 10)
	local pos = inst:GetPosition()
	local ents = TheSim:FindEntities(pos.x, pos.y, pos.z, 15, {"_combat","tadalin"})
		for k,v in pairs(ents) do 
			if v.oldDMT == nil and v.components and v.components.combat then 
					if v.components.combat.damagemultiplier then                 
						v.oldDMT = v.components.combat.damagemultiplier             
						else                
						v.oldDMT = 1 
					end
					local x, y, z = v.Transform:GetWorldPosition()
					local spell = SpawnPrefab("deer_fire_charge")
					spell.Transform:SetPosition(x, y+3, z)
					spell:DoTaskInTime(1, spell.KillFX)
					v.components.combat.damagemultiplier =2.0*v.oldDMT
					v:DoTaskInTime(10, function()                 
						v.components.combat.damagemultiplier = v.oldDMT                 
						v.oldDMT = nil             end)            
			end	
		end
end

local function OnAttacked_xianfeng(inst, data)
    inst.components.combat:SetTarget(data.attacker)
    inst.components.combat:ShareTarget(data.attacker, 30, function(dude)
        return  (dude:HasTag("spider") or dude:HasTag("tadalin"))
			and dude.components.health
            and not dude.components.health:IsDead()
    end, 10)
end

local function ondeath_dragoon(inst)
	local pos = inst:GetPosition()
	local ents = TheSim:FindEntities(pos.x, pos.y, pos.z, 50,  {"battle_screaming"})
	for k,v in pairs(ents) do
		if v.battle_screamfn and v.battle_screamer then
				v.battle_screamfn:Cancel()
				v.battle_screamfn = nil 
				v.battle_screamer = nil
				v:RemoveTag("battle_screaming")
		end
	end
end 

local function running(inst) -------------------------检测到身边有攻击意图的生物后回避的代码
	local my = inst:GetPosition()
	local ents = TheSim:FindEntities(my.x, my.y, my.z, 5, {"_combat"})
	local flag = 0 
	for k,v in pairs(ents) do 
		if v:IsValid() and v.components.combat and v.components.combat.target == inst and v.sg and v.sg:HasStateTag("attack") then 
			if inst.components.combat and inst:IsValid() then 
				inst.components.combat:SetTarget(v)
				inst.components.combat:ShareTarget(v, 30, function(dude)
					return (dude:HasTag("spider") or dude:HasTag("tadalin"))
					and not dude.components.health:IsDead()
					and dude.components.follower ~= nil
					and dude.components.follower.leader == inst.components.follower.leader
				end, 10)
			end
			flag = 1
			break
		end
	end 
	
	if inst  and GetTime() - inst.runningcd > 1.5 and flag == 1 and not inst.sg:HasStateTag("busy") then 
		inst.runningcd = GetTime()
		local spell1 = SpawnPrefab("deer_ice_charge")
		local spell2 = SpawnPrefab("deer_ice_charge")
		spell1.Transform:SetPosition(my.x, my.y, my.z)
		spell1:DoTaskInTime(1, spell1.KillFX)
		local max_tries = 5
		for k = 1, max_tries do
            local offset = 15
            my.x = my.x + math.random(2 * offset) - offset
            my.z = my.z + math.random(2 * offset) - offset
            if TheWorld.Map:IsPassableAtPoint(my.x, my.y,my.z) then
                inst.Physics:Teleport(my.x,my.y,my.z)
				spell2.Transform:SetPosition(my.x,my.y,my.z)
				spell2:DoTaskInTime(1, spell2.KillFX)
				break
            end
        end
	end
end 

local function BigBang(inst)
	local target = inst.sg.statemem.target
	if  target == nil  then return end 
		
	local my = inst:GetPosition()
	local pos = (target and target:IsValid()) and target:GetPosition()
	local delx = my.x - pos.x
	local delz = my.z - pos.z
	local dist = math.sqrt(delx*delx+delz*delz)
	
	if dist > 2.5 then return end 
		
	local bomb = SpawnPrefab("tadalin_meteor_splash")
	bomb.Transform:SetPosition(my.x,my.y,my.z)
	bomb.AnimState:SetMultColour(0/255,197/255,4/255,1)
	
	inst.SoundEmitter:PlaySound("dontstarve_DLC001/common/HUD_hot_level4")
	local ents = TheSim:FindEntities(my.x, my.y, my.z, 5)
	for k,v in pairs(ents) do 
		local armor = 1
		if v and v.components.inventory then 
			for i, j in pairs(v.components.inventory.equipslots) do
				if j.components.armor and j.components.armor ~= nil then
					armor = 0
					break
				end
			end	
		end 		
		if v.components.health and v ~= inst then 
			if v:HasTag("tadalin")  then 
				v.components.health:DoDelta(300)
			else
				v.components.combat:GetAttacked(inst,inst.components.combat.defaultdamage * (1+armor))
				if v:HasTag("spider") then 
					inst.components.combat:SetTarget(nil)
				end
			end
		end 
	end
	inst.components.health:Kill()
	--inst:Remove()
end 

local function ShouldAcceptItem(inst, item, giver)
    return giver:HasTag("spiderwhisperer") and inst.components.eater:CanEat(item)
end

function GetOtherSpiders(inst)
    local x, y, z = inst.Transform:GetWorldPosition()
    return TheSim:FindEntities(x, y, z, 15,  { "spider" }, { "FX", "NOCLICK", "DECOR", "INLIMBO" })
end

local function OnGetItemFromPlayer(inst, giver, item)
    if inst.components.eater:CanEat(item) then  
        inst.sg:GoToState("eat", true)

        local playedfriendsfx = false
        if inst.components.combat.target == giver then
            inst.components.combat:SetTarget(nil)
        elseif giver.components.leader ~= nil and
            inst.components.follower ~= nil then
            giver:PushEvent("makefriend")
            playedfriendsfx = true
            giver.components.leader:AddFollower(inst)
            inst.components.follower:AddLoyaltyTime(item.components.edible:GetHunger() * TUNING.SPIDER_LOYALTY_PER_HUNGER)
        end

        if giver.components.leader ~= nil then
            local spiders = GetOtherSpiders(inst)
            local maxSpiders = 3

            for i, v in ipairs(spiders) do
                if maxSpiders <= 0 then
                    break
                end

                if v.components.combat.target == giver then
                    v.components.combat:SetTarget(nil)
                elseif giver.components.leader ~= nil and
                    v.components.follower ~= nil and
                    v.components.follower.leader == nil then
                    if not playedfriendsfx then
                        giver:PushEvent("makefriend")
                        playedfriendsfx = true
                    end
                    giver.components.leader:AddFollower(v)
                    v.components.follower:AddLoyaltyTime(item.components.edible:GetHunger() * TUNING.SPIDER_LOYALTY_PER_HUNGER)
                end
                maxSpiders = maxSpiders - 1

                if v.components.sleeper:IsAsleep() then
                    v.components.sleeper:WakeUp()
                end
            end
        end
    end
end

local function OnRefuseItem(inst, item)
    inst.sg:GoToState("taunt")
    if inst.components.sleeper:IsAsleep() then
        inst.components.sleeper:WakeUp()
    end
end

local function FindTarget(inst, radius)
    return FindEntity(
        inst,
        SpringCombatMod(radius),
        function(guy)
            return inst.components.combat:CanTarget(guy)
                and not (inst.components.follower ~= nil and inst.components.follower.leader == guy)
        end,
        { "_combat", "character" },
        { "monster", "INLIMBO","tadalin" }
    )
end

local function Retarget(inst)
    return FindTarget(inst, TUNING.SPIDER_WARRIOR_TARGET_DIST)
end

local function NormalRetarget(inst)
    return FindTarget(inst, inst.components.knownlocations:GetLocation("investigate") ~= nil and TUNING.SPIDER_INVESTIGATETARGET_DIST or TUNING.SPIDER_TARGET_DIST)
end

local function WarriorRetarget(inst)
    return FindTarget(inst, TUNING.SPIDER_WARRIOR_TARGET_DIST)
end

local function keeptargetfn(inst, target)
   return target ~= nil
        and target.components.combat ~= nil
        and target.components.health ~= nil
        and not target.components.health:IsDead()
        and not (inst.components.follower ~= nil and
                (inst.components.follower.leader == target or inst.components.follower:IsLeaderSame(target)))
end

local function BasicWakeCheck(inst)
    return inst.components.combat:HasTarget()
        or (inst.components.homeseeker ~= nil and inst.components.homeseeker:HasHome())
        or inst.components.burnable:IsBurning()
        or inst.components.freezable:IsFrozen()
        or inst.components.health.takingfiredamage
        or inst.components.follower:GetLeader() ~= nil
end

local function ShouldSleep(inst)
    return false
end

local function ShouldWake(inst)
    return true
end

local function SummonFriends(inst, attacker)
    local den = GetClosestInstWithTag("spiderden", inst, SpringCombatMod(TUNING.SPIDER_SUMMON_WARRIORS_RADIUS))
    if den ~= nil and den.components.combat ~= nil and den.components.combat.onhitfn ~= nil then
        den.components.combat.onhitfn(den, attacker)
    end
	
end


local function CalcSanityAura(inst, observer)
    return  inst.components.sanityaura.aura
end

local function create_common(bank,build, tag)
    local inst = CreateEntity()
    
    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddLightWatcher()
    inst.entity:AddDynamicShadow()
    inst.entity:AddNetwork()

    MakeCharacterPhysics(inst, 10, .5)

    inst.DynamicShadow:SetSize(1.5, .5)
    inst.Transform:SetFourFaced()
	
    inst:AddTag("cavedweller")
    inst:AddTag("monster")
    inst:AddTag("hostile")
    inst:AddTag("scarytoprey")
    inst:AddTag("smallcreature")
    inst:AddTag("spider")
	inst:AddTag("tadalin")
	
    if tag ~= nil then
        inst:AddTag(tag)
    end


    inst.AnimState:SetBank(bank)
    inst.AnimState:SetBuild(build)
    inst.AnimState:PlayAnimation("idle")

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
    -- locomotor must be constructed before the stategraph!
    inst:AddComponent("locomotor")
    inst.components.locomotor:SetSlowMultiplier( 1 )
    inst.components.locomotor:SetTriggersCreep(false)
    inst.components.locomotor.pathcaps = { ignorecreep = true }

    --inst:SetStateGraph("SGhaojie")

    inst:AddComponent("lootdropper")
    inst.components.lootdropper:AddRandomLoot("monstermeat", 1)
    inst.components.lootdropper:AddRandomLoot("silk", .5)
    inst.components.lootdropper:AddRandomLoot("spidergland", .5)
    inst.components.lootdropper:AddRandomHauntedLoot("spidergland", 1)
    inst.components.lootdropper.numrandomloot = 1

    ---------------------        
    MakeMediumBurnableCharacter(inst, "body")
    MakeMediumFreezableCharacter(inst, "body")
    inst.components.burnable.flammability = TUNING.SPIDER_FLAMMABILITY
    ---------------------       

    inst:AddComponent("health")
    inst:AddComponent("combat")
    inst.components.combat.hiteffectsymbol = "body"
    inst.components.combat:SetKeepTargetFunction(keeptargetfn)
    inst.components.combat:SetOnHit(SummonFriends)

    inst:AddComponent("follower")
    inst.components.follower.maxfollowtime = TUNING.TOTAL_DAY_TIME

    ------------------

    inst:AddComponent("sleeper")
    inst.components.sleeper:SetResistance(2)
    inst.components.sleeper:SetSleepTest(ShouldSleep)
    inst.components.sleeper:SetWakeTest(ShouldWake)
    ------------------

    inst:AddComponent("knownlocations")

    ------------------

    inst:AddComponent("eater")
    inst.components.eater:SetDiet({ FOODTYPE.MEAT }, { FOODTYPE.MEAT })
    inst.components.eater:SetCanEatHorrible()
    inst.components.eater.strongstomach = true -- can eat monster meat!

    ------------------

    inst:AddComponent("inspectable")
	

    inst:AddComponent("sanityaura")
    inst.components.sanityaura.aurafn = CalcSanityAura

    MakeHauntablePanic(inst)
    --inst:SetBrain(brain)
    return inst
end



local function create_haojie()
    local inst = create_common("spider","spider_haojie")
	
	inst.Transform:SetScale(1.1,1.1,1.1)
	
    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.components.inspectable:SetDescription("军团的支援兵器")
	
	inst:SetStateGraph("SGhaojie")
	inst:SetBrain(require "brains/haojiebrain")
	
    inst.components.health:SetMaxHealth(150)
    inst.components.health.fire_damage_scale = 0
    inst.components.combat:SetDefaultDamage(20)
    inst.components.combat:SetAttackPeriod(TUNING.SPIDER_ATTACK_PERIOD)
    inst.components.combat:SetRetargetFunction(1, NormalRetarget)

    inst.components.locomotor.walkspeed = TUNING.SPIDER_WALK_SPEED
    inst.components.locomotor.runspeed = TUNING.SPIDER_RUN_SPEED

    inst.components.sanityaura.aura = -TUNING.SANITYAURA_SMALL
	
	inst:ListenForEvent("attacked", OnAttacked_haojie)
    inst:ListenForEvent("onhitother", onattack_haojie)

    return inst
end

local function create_dragoon()
    local inst = create_common("spider_hider", "spider_dragoon_1", "spider_hider")
	
	inst.Transform:SetScale(1.1,1.1,1.1)
	
    if not TheWorld.ismastersim then
        return inst
    end
	inst:SetStateGraph("SGspider_dragoon")
	inst:SetBrain(require "brains/spiderbrain")
	
	inst.components.inspectable:SetDescription("重回战场的改造战士")
    
    inst.components.combat:SetDefaultDamage(20)
    inst.components.combat:SetAttackPeriod(TUNING.SPIDER_HIDER_ATTACK_PERIOD)
    inst.components.combat:SetRetargetFunction(1, Retarget)
	
	inst.components.health:SetAbsorptionAmount(0.2)
	inst.components.health:SetMaxHealth(300)
	
    inst.components.locomotor.walkspeed = TUNING.SPIDER_HIDER_WALK_SPEED * 0.7
    inst.components.locomotor.runspeed = TUNING.SPIDER_HIDER_RUN_SPEED * 0.7

    inst.components.sanityaura.aura = -TUNING.SANITYAURA_MED
	
	inst:ListenForEvent("death", ondeath_dragoon)
    return inst
end

local function create_chaser()
    local inst = create_common("spider", "spider_chaser_0", "spider_warrior")
	
	--inst.Transform:SetScale(1.3,1.3,1.3)
	
    if not TheWorld.ismastersim then
        return inst
    end
	inst.chasingcd = 0
	inst.runningcd = 0
	
	inst:SetStateGraph("SGchaser")
	inst:SetBrain(require "brains/spiderbrain")
	
	inst.components.inspectable:SetDescription("装备有相位转移技术的器械")
	
    inst.components.health:SetMaxHealth(100)

    inst.components.combat:SetDefaultDamage(15)
    inst.components.combat:SetAttackPeriod(TUNING.SPIDER_WARRIOR_ATTACK_PERIOD )
    inst.components.combat:SetRange(TUNING.SPIDER_WARRIOR_ATTACK_RANGE*1.1, TUNING.SPIDER_WARRIOR_HIT_RANGE*1.1)
    inst.components.combat:SetRetargetFunction(2, NormalRetarget)

    inst.components.locomotor.walkspeed = TUNING.SPIDER_WARRIOR_WALK_SPEED*1.1
    inst.components.locomotor.runspeed = TUNING.SPIDER_WARRIOR_RUN_SPEED*1.1

    inst.components.sanityaura.aura = -TUNING.SANITYAURA_MED
	
	
	--inst:DoPeriodicTask(0.1,chasing)
	inst:DoPeriodicTask(0.1,running)
	
    return inst
end

local function create_xianfeng()
    local inst = create_common("spider","spider_xianfeng_0", "spider_warrior")
	
	inst.Transform:SetScale(1.1,1.1,1.1)
	
    if not TheWorld.ismastersim then
        return inst
    end
	inst.components.inspectable:SetDescription("由蜘蛛战士改造成的突袭机械")
	
	inst:SetStateGraph("SGxianfeng")
	inst:SetBrain(require "brains/spiderbrain")
	
    inst.components.health:SetMaxHealth(400)

    inst.components.combat:SetDefaultDamage(25)
    inst.components.combat:SetAttackPeriod(TUNING.SPIDER_WARRIOR_ATTACK_PERIOD + math.random() * 2)
    inst.components.combat:SetRange(TUNING.SPIDER_WARRIOR_ATTACK_RANGE, TUNING.SPIDER_WARRIOR_HIT_RANGE)
    inst.components.combat:SetRetargetFunction(2, WarriorRetarget)
    inst.components.locomotor.walkspeed = TUNING.SPIDER_WARRIOR_WALK_SPEED
    inst.components.locomotor.runspeed = TUNING.SPIDER_WARRIOR_RUN_SPEED

    inst.components.sanityaura.aura = -TUNING.SANITYAURA_MED
	
	inst:ListenForEvent("attacked", OnAttacked_xianfeng)
	inst:ListenForEvent("onhitother", onattack_xianfeng)
	
    return inst
end

local function create_bomb()
    local inst = create_common("spider_bomb", "spider_bomb_1", "spider_warrior")

    if not TheWorld.ismastersim then
        return inst
    end
	inst:SetStateGraph("SGbomb")
	inst:SetBrain(require "brains/spiderbrain")
	
    inst.components.health:SetMaxHealth(100)

    inst.components.combat:SetDefaultDamage(80)
    inst.components.combat:SetAttackPeriod(TUNING.SPIDER_WARRIOR_ATTACK_PERIOD )
    inst.components.combat:SetRange(TUNING.SPIDER_WARRIOR_ATTACK_RANGE*1.1, TUNING.SPIDER_WARRIOR_HIT_RANGE*1.1)
    inst.components.combat:SetRetargetFunction(2, NormalRetarget)

    inst.components.locomotor.walkspeed = TUNING.SPIDER_WARRIOR_WALK_SPEED*1.1
    inst.components.locomotor.runspeed = TUNING.SPIDER_WARRIOR_RUN_SPEED*1.1

    inst.components.sanityaura.aura = -TUNING.SANITYAURA_MED
	inst.components.inspectable:SetDescription("别靠近我!")
	--inst.Transform:SetScale(1.3,1.3,1.3)
	inst:DoPeriodicTask(0.1,BigBang)
	--inst:DoPeriodicTask(0.1,running)
	
    return inst
end

return Prefab("spider_haojie", create_haojie, haojie_assets),
Prefab("spider_dragoon", create_dragoon, dragoon_assets),
Prefab("spider_chaser", create_chaser, chaser_assets),
Prefab("spider_xianfeng", create_xianfeng,xianfeng_assets),
Prefab("spider_bomb", create_bomb, bomb_assets)

