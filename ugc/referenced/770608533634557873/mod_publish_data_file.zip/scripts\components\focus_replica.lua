local Focus = Class(function(self, inst)
	self.inst = inst 
	self._current = net_ushortint(inst.GUID, "focus._current", "focusdirty")
    self._max = net_ushortint(inst.GUID, "focus._max", "focusdirty")
end)

function Focus:SetMax(max)
	self._max:set(max)
end

function Focus:SetCurrent(current)
	current = math.max(0,current)
	current = math.min(self._max:value(),current)
	self._current:set(current)
end

function Focus:GetCurrent()
	return self._current:value()
end

function Focus:GetMax()
	return self._max:value()
end 

function Focus:GetPercent()
	return self:GetCurrent() / self:GetMax()
end


return Focus