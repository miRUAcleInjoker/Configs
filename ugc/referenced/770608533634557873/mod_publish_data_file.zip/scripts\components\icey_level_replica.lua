local IceyLevel = Class(function(self, inst)
    self.inst = inst
    self._exp = net_shortint(inst.GUID,"IceyLevel._exp")
	self._max_exp = net_shortint(inst.GUID,"IceyLevel._max_exp")
	self._level = net_shortint(inst.GUID,"IceyLevel._level")
	self._max_level = net_shortint(inst.GUID,"IceyLevel._max_level") 
end)

function IceyLevel:SetExp(val)
	self._exp:set(val)
end

function IceyLevel:SetMaxExp(val)
	self._max_exp:set(val)
end

function IceyLevel:SetLevel(val)
	self._level:set(val)
end

function IceyLevel:SetMaxLevel(val)
	self._max_level:set(val)
end
-----------------------------------------------------
function IceyLevel:GetExp()
	return self._exp:value()
end

function IceyLevel:GetMaxExp()
	return self._max_exp:value()
end

function IceyLevel:GetLevel()
	return self._level:value()
end

function IceyLevel:GetMaxLevel()
	return self._max_level:value()
end



return IceyLevel