--[[
	--- This is Wilson's speech file for Don't Starve Together ---
	Write your character's lines here.
	If you want to use another speech file as a base, or use a more up-to-date version, get them from data\scripts\
	
	If you want to use quotation marks in a quote, put a \ before it.
	Example:
	"Like \"this\"."
]]
return {
	ACTIONFAIL =
	{
		SHAVE =
		{
			AWAKEBEEFALO = "牛牛还醒着呢",
			GENERIC = "来不及了",
			NOBITS = "连渣都没剩下",
		},
		STORE =
		{
			GENERIC = "塞满了",
			NOTALLOWED = "这个东西不应该放在这里的说",
			INUSE = "得等别人先用完再说",
		},
		RUMMAGE =
		{	
			GENERIC = "不行哦",
			INUSE = "等别人先用完再说",	
		},
        COOK =
        {
            GENERIC = "这样不行",
            INUSE = "等别人先用完再说",
            TOOFAR = "我办不到",
        },
        GIVE =
        {
            DEAD = "她死了···",
            SLEEPING = "她在碎觉ing",
            BUSY = "等会试试？",
        },
        GIVETOPLAYER = 
        {
        	FULL = "他们也背不动了",
            DEAD = "好可怜···",
            SLEEPING = "等他们睡醒吧",
            BUSY = "待会试试？",
    	},
    	GIVEALLTOPLAYER = 
        {
        	FULL = "他们也背不动了",
            DEAD = "好可怜···",
            SLEEPING = "等他们睡醒吧",
            BUSY = "待会试试？",
    	},
        WRITE =
        {
            GENERIC = "超出我的能力范围了呢",
            INUSE = "等会试试",
        },
        CHANGEIN =
        {
            GENERIC = "我办不到",
            BURNING = "呜哇，烧起来了!",
            INUSE = "别人还在用它···",
        },
        ATTUNE =
        {
            NOHEALTH = "我感觉不舒服···",
        },
	},
	ACTIONFAIL_GENERIC = "不可以哦···",
	
	ANNOUNCE_DEATH = "唔···",
	ANNOUNCE_DEATH_RUSSIAN = "呜啊····",
	ANNOUNCE_COMRADE_DEATH = "不!",
	ANNOUNCE_COMRADE_DEATH_RUSSIAN = "唔唔···",
	
	ANNOUNCE_LEVELUP_1 = "感觉好多了",
	ANNOUNCE_LEVELUP_2 = "今天，我学到了一种新剑法",
	ANNOUNCE_LEVELUP_3 = "舰长补给全保底，舰长副本零掉落",
	ANNOUNCE_LEVELUP_4 = "即使空间毁灭，我依然重生",
	ANNOUNCE_LEVELUP_5 = "...",
	ANNOUNCE_LEVELUP_6 = "不小心伤到了呢",
	ANNOUNCE_LEVELUP_7 = "我与泰坦谈笑风生",
	ANNOUNCE_LEVELUP_8 = "逆熵黑科技发来贺电",
	ANNOUNCE_LEVELUP_9 = "我还有未完成的夙愿",
	ANNOUNCE_VERNIY = "Horosho. I can trust in this form...",
	
	ANNOUNCE_ADVENTUREFAIL = "Mission failed. ...I'll try again.",
	ANNOUNCE_BEES = "Bees!?",
	ANNOUNCE_BOOMERANG = "回旋镖飞回来.....啊!!!",
	ANNOUNCE_CHARLIE = "谁在那儿!!!",
	ANNOUNCE_CHARLIE_ATTACK = "可恶！好痛！",
	ANNOUNCE_COLD = "警告：恶劣天气！",
	ANNOUNCE_HOT = "警告：系统过热！",
	ANNOUNCE_CRAFTING_FAIL = "材料不够了....",
	ANNOUNCE_DEERCLOPS = "湮灭在等待.....",
	ANNOUNCE_DUSK = "夜幕降临！",
	ANNOUNCE_EAT =
	{
		GENERIC = "唔~",
		PAINFUL = "我感觉不舒服···",
		SPOILED = "好难吃啊····",
		STALE = "感觉要烂掉了",
		INVALID = "我才不吃呢",
		YUCKY = "我要吃电池!",
	},
	ANNOUNCE_ENTER_DARK = "好黑啊！",
	ANNOUNCE_ENTER_LIGHT = "光！",
	ANNOUNCE_FREEDOM = "我自由了！",
	ANNOUNCE_HIGHRESEARCH = "Intel obtained.",
	ANNOUNCE_HOUNDS = "侦测到在途的猎犬突袭!",
	ANNOUNCE_WORMS = "虫子来了!",
	ANNOUNCE_HUNGRY = "警告：电能不足！",
	ANNOUNCE_HUNT_BEAST_NEARBY = "永恒的狩猎开始了!",
	ANNOUNCE_HUNT_LOST_TRAIL = "脚印不见了",
	ANNOUNCE_HUNT_LOST_TRAIL_SPRING = "湿地上不会有脚印的",
	ANNOUNCE_INV_FULL = "塞满了",
	ANNOUNCE_KNOCKEDOUT = "呃....",
	ANNOUNCE_LOWRESEARCH = "Failed to obtain intel...",
	ANNOUNCE_MOSQUITOS = "吵吵闹闹的",
    ANNOUNCE_NOWARDROBEONFIRE = "我不想钻进火里....",
    ANNOUNCE_NODANGERGIFT = "附近还很危险呢....",
	ANNOUNCE_NODANGERSLEEP = "在排除敌人之前不能休息哦....",
	ANNOUNCE_NODAYSLEEP = "外面太亮了...",
	ANNOUNCE_NODAYSLEEP_CAVE = "我还不困....",
	ANNOUNCE_NOHUNGERSLEEP = "没电的时候睡下去的话就醒不过来了！",
	ANNOUNCE_NOSLEEPONFIRE = "我不想在火里睡觉！",
	ANNOUNCE_NODANGERSIESTA = "附近还有敌人....",
	ANNOUNCE_NONIGHTSIESTA = "我要钻进帐篷的被窝里！",
	ANNOUNCE_NONIGHTSIESTA_CAVE = "我才没这个闲工夫呢！",
	ANNOUNCE_NOHUNGERSIESTA = "快没电了....",
	ANNOUNCE_NODANGERAFK = "无路可逃了！",
	ANNOUNCE_NO_TRAP = "小菜一碟！",
	ANNOUNCE_PECKED = "呃!",
	ANNOUNCE_QUAKE = "地震!?",
	ANNOUNCE_RESEARCH = "Gathering intel.",
	ANNOUNCE_SHELTER = "是大树。",
	ANNOUNCE_THORNS = "唔咿....",
	ANNOUNCE_BURNT = "烧的连渣都不剩了...",
	ANNOUNCE_TORCH_OUT = "燃料耗尽！",
	ANNOUNCE_FAN_OUT = "我的扇子罢工了！",
    ANNOUNCE_COMPASS_OUT = "指南针坏掉了...果然还是得靠导航系统吗？",
	ANNOUNCE_TRAP_WENT_OFF = "啊！",
	ANNOUNCE_UNIMPLEMENTED = "还没做完....",
	ANNOUNCE_WORMHOLE = "我不喜欢丸吞Play.....",
	ANNOUNCE_CANFIX = "\n我可以修好它！",
	ANNOUNCE_ACCOMPLISHMENT = "没事，俺不累！(Mission Complete).",
	ANNOUNCE_ACCOMPLISHMENT_DONE = "呼哈。",	
	ANNOUNCE_INSUFFICIENTFERTILIZER = "哎呀，我把肥料用完了！",
	ANNOUNCE_TOOL_SLIP = "唔!? 哦不...!",
	ANNOUNCE_LIGHTNING_DAMAGE_AVOIDED = "闪电回避！",

	ANNOUNCE_DAMP = "湿了···",
	ANNOUNCE_WET = "看来我的衣服并不防水···",
	ANNOUNCE_WETTER = "再这样下去要短路了！",
	ANNOUNCE_SOAKED = "啊！走光了！旁白你在看哪里？！！",
	
	ANNOUNCE_BECOMEGHOST = "唔",
	ANNOUNCE_GHOSTDRAIN = "嗯···",

	DESCRIBE_SAMECHARACTER = "另一个我？",
	
	BATTLECRY =
	{
		GENERIC = "我们是幻影的利刃!",
		PIG = "这是迫不得已...",
		PREY = "灭绝!",
		SPIDER = "拥抱战斗的荣耀!",
		SPIDER_WARRIOR = "此战必胜!",
		DEERCLOPS = "势不可挡!",
		BEARGER = "我们的敌人将分崩离析!",
		MOOSE = "敌人的命运只有灭亡!",
		DRAGONFLY = "纷争之火，炽烈燃烧",
	},
	COMBAT_QUIT =
	{
		GENERIC = "Drove away the enemy.",
		PIG = "Enemy escaped...",
		PREY = "Enemy escaped...",
		SPIDER = "Drove away the enemy.",
		SPIDER_WARRIOR = "Drove away the enemy.",
	},
	DESCRIBE =
	{

		BERNIE_INACTIVE =
		{
			BROKEN = "它快散架了....",
			GENERIC = "一只可爱的泰迪熊玩偶！",
		},
		BERNIE_ACTIVE = "泰迪熊自己动了起来...因缺思厅....",
		

        PLAYER =
        {
            GENERIC = "这是%s.",
            ATTACKER = "侦测到%s有敌意...",
            MURDERER = "你这个杀人犯！",
            REVIVER = "%s, 你对我真好！",
            GHOST = "%s?是你吗?",
        },
		HIBIKI =
        {
            GENERIC = "A comrade. Horosho.",
            ATTACKER = "My other self seems suspicious.",
            MURDERER = "Why did you murder them...?",
            REVIVER = "Horosho. Thanks, me.",
            GHOST = "There's something very wrong with this sight...",
        },
		INAZUMA = 
		{
			GENERIC = "I'm glad you're here with me, Inazuma.",
            ATTACKER = "Inazuma, what are you doing...?",
            MURDERER = "Inazuma's hands are trembling... It can't be...?",
            REVIVER = "Inazuma, you're truly an angel.",
            GHOST = "Inazuma? Oh no, not again...",
		},
		IKAZUCHI = 
		{
			GENERIC = "Ikazuchi. You're handy to have around.",
            ATTACKER = "Ikazuchi!? What are you doing...?",
            MURDERER = "Ikazuchi, why did you...?",
            REVIVER = "I can always rely on you.",
            GHOST = "Ikazuchi...? What happened?",
		},
		AKATSUKI = 
		{
			GENERIC = "Ah, big sister Akatsuki. I hope you're doing well.",
            ATTACKER = "Akatsuki!? What are you doing...?",
            MURDERER = "Akatsuki, why did you...?",
            REVIVER = "Thanks for helping out, Akatsuki.",
            GHOST = "Akatsuki...? Oh no...",
		},
		SHIRANUI = 
		{
			GENERIC = "Shiranui, watch my back.",
            ATTACKER = "Shiranui seems more silent than usual today.",
            MURDERER = "Shiranui is covered in blood...",
            REVIVER = "Shiranui, thanks for helping out.",
            GHOST = "Shiranui...? Is that you?",
		},
		SHIGURE = 
		{
			GENERIC = "Pleased to be here with you, Shigure.",
            ATTACKER = "Shigure's smile is a little off today...",
            MURDERER = "Shigure's a little red...",
            REVIVER = "Shigure, thanks for helping out.",
            GHOST = "Shigure...? Is that you?",
		},
		SATSUKI = 
		{
			GENERIC = "Hello there, Satsuki.",
            ATTACKER = "Satsuki is scheming something...",
            MURDERER = "Satsuki, what did you do!?",
            REVIVER = "Satsuki, thanks for helping out.",
            GHOST = "Satsuki...? Is that you?",
		},
		WILSON = 
		{
			GENERIC = "It's Wilson.",
            ATTACKER = "I feel like Wilson is scheming something...",
            MURDERER = "What are you doing!?",
            REVIVER = "Wilson, that was very nice of you.",
            GHOST = "Wilson? Is that you?",
		},
		WOLFGANG = 
		{
			GENERIC = "It's Wolfgang.",
            ATTACKER = "I feel like Wolfgang is scheming something...",
            MURDERER = "What are you doing!?",
            REVIVER = "Wolfgang, that was very nice of you.",
            GHOST = "Wolfgang? Is that you?",
		},
		WAXWELL = 
		{
			GENERIC = "It's Waxwell.",
            ATTACKER = "I feel like Waxwell is scheming something...",
            MURDERER = "What are you doing!?",
            REVIVER = "Waxwell, that was very nice of you.",
            GHOST = "Waxwell? Is that you?",
		},
		WX78 = 
		{
			GENERIC = "It's WX78.",
            ATTACKER = "I feel like WX78 is scheming something...",
            MURDERER = "What are you doing!?",
            REVIVER = "WX78, that was very nice of you.",
            GHOST = "WX78? Is that you?",
		},
		WILLOW = 
		{
			GENERIC = "It's Willow.",
            ATTACKER = "I feel like Willow is scheming something...",
            MURDERER = "What are you doing!?",
            REVIVER = "Willow, that was very nice of you.",
            GHOST = "Willow? Is that you?",
		},
		WENDY = 
		{
			GENERIC = "It's Wendy.",
            ATTACKER = "I feel like Wendy is scheming something...",
            MURDERER = "What are you doing!?",
            REVIVER = "Wendy, that was very nice of you.",
            GHOST = "Wendy? Is that you?",
		},
		WOODIE = 
		{
			GENERIC = "It's Woodie.",
            ATTACKER = "I feel like Woodie is scheming something...",
            MURDERER = "What are you doing!?",
            REVIVER = "Woodie, that was very nice of you.",
            GHOST = "Woodie? Is that you?",
		},
		WICKERBOTTOM = 
		{
			GENERIC = "It's Wickerbottom.",
            ATTACKER = "I feel like Wickerbottom is scheming something...",
            MURDERER = "What are you doing!?",
            REVIVER = "Wickerbottom, that was very nice of you.",
            GHOST = "Wickerbottom? Is that you?",
		},
		WES = 
		{
			GENERIC = "It's Wes.",
            ATTACKER = "I feel like Wes is scheming something...",
            MURDERER = "What are you doing!?",
            REVIVER = "Wes, that was very nice of you.",
            GHOST = "Wes? Is that you?",
		},
		MULTIPLAYER_PORTAL = "建议改造成折跃门。",
        MIGRATION_PORTAL = {
            GENERIC = "这是通往另一个世界的入口！",
            OPEN = "也许我应该去另一个世界看一看？",
            FULL = "我进不去...",
        },
		GLOMMER = "这是一只咕噜喵。",
		GLOMMERFLOWER = 
		{
			GENERIC = "咕噜喵的可爱的花！",
			DEAD = "它死了...",
		},
		GLOMMERWINGS = "可爱的小翅膀！",
		GLOMMERFUEL = "闻起来好奇怪。",
		BELL = "叮咚~~~",
		STATUEGLOMMER = 
		{	
			GENERIC = "咕噜喵的雕像吗？",
			EMPTY = "被毁掉了...",
		},

		WEBBERSKULL = "...安息吧",
		WORMLIGHT = "是会发光的浆果！",
		WORMLIGHT_LESSER = "发光浆果...小小的！",
		WORM =
		{
		    PLANT = "这是蠕虫假扮的！",
		    DIRT = "掘进的土堆！",
		    WORM = "是坑道虫！",
		},
        WORMLIGHT_PLANT = "这应该是真的发光浆果！",
		MOLE =
		{
			HELD = "你回不去了！",
			UNDERGROUND = "是鼹鼠在地下挖洞！",
			ABOVEGROUND = "是可爱的鼹鼠！",
		},
		MOLEHILL = "鼹鼠的窝。",
		MOLEHAT = "是夜视仪吗？",

		EEL = "拿回去做烤鳗鱼！",
		EEL_COOKED = "好香啊！.",
		UNAGI = "我自己做的！",
		EYETURRET = "我想...这是一种新式光子炮塔....",
		EYETURRET_ITEM = "我该把它放在哪儿好呢？",
		MINOTAURHORN = "守护者的角！",
		MINOTAURCHEST = "能找到什么样的宝藏呢？",
		THULECITE_PIECES = "一些铥矿的碎片。",
		POND_ALGAE = "池塘边的草",
		GREENSTAFF = "分解用的法杖！",
		POTTEDFERN = "蕨菜盆栽，还可行。",

		THULECITE = "真是神奇的矿物，它从哪儿来的？",
		ARMORRUINS = "这副盔甲的制作工艺非常古老，但是依然很先进。",
		RUINS_BAT = "用起来没有我的光剑顺手....",
		RUINSHAT = "这是皇冠吗？",
		NIGHTMARE_TIMEPIECE =
		{
            CALM = "一切正常。",
            WARN = "这是...暗瘴气吗？",
            WAXING = "暗瘴气变得更浓了！",
            STEADY = "敌人越发大胆了！",
            WANING = "黑暗能量开始消退了。",
            DAWN = "敌人撤回阴影中去了。",
            NOMAGIC = "这东西在这没用。",
		},
		BISHOP_NIGHTMARE = "它开始散架了。",
		ROOK_NIGHTMARE = "有点可怕。",
		KNIGHT_NIGHTMARE = "活尸化的骑士！",
		MINOTAUR = "啊！是雷兽！",
		SPIDER_DROPPER = "休想捉到我！",
		NIGHTMARELIGHT = "我能在它旁边感受到强大的暗瘴气",
		NIGHTSTICK = "磁暴步兵！",
		GREENGEM = "绿色的，绿帽子！",
		RELIC = "远古的遗迹。",
		RUINS_RUBBLE = "还能修好吗？",
		MULTITOOL_AXE_PICKAXE = "万用工具的开拓者！",
		ORANGESTAFF = "没我快！",
		YELLOWAMULET = "这是魔力之光！",
		GREENAMULET = "双倍材料，双倍快乐！",
		SLURPERPELT = "舔食者的毛皮，咿.....",	

		SLURPER = "危险的小毛球",
		SLURPER_PELT = "舔食者的毛皮，咿......",
		ARMORSLURPER = "唔！给我下来！滚开！唔...不要...不要插进嘴巴里...啊...咿.....",
		ORANGEAMULET = "我懒的捡东西了....",
		YELLOWSTAFF = "出现了！唤星者！",
		YELLOWGEM = "一颗很H的宝石。",
		ORANGEGEM = "橙黄色的宝石。",
		TELEBASE = 
		{
			VALID = "这个设备已经可以运作了！",
			GEMS = "它需要紫宝石插槽！",
		},
		GEMSOCKET = 
		{
			VALID = "这样差不多了。",
			GEMS = "它需要一个紫宝石！",
		},
		STAFFLIGHT = "一颗小恒星！",
	
        ANCIENT_ALTAR = "谜一样的远古建筑！",

        ANCIENT_ALTAR_BROKEN = "快要坏掉了。",

        ANCIENT_STATUE = "这种雕像...不像是这个世界的东西....",

        LICHEN = "只有苔藓才能在这种无光环境下生长。",
		CUTLICHEN = "黏糊糊的苔藓。",

		CAVE_BANANA = "好闻的香蕉！",
		CAVE_BANANA_COOKED = "为什么要把香蕉烤熟了吃呢？",
		CAVE_BANANA_TREE = "长相怪异的香蕉树！",
		ROCKY = "你是克苏鲁的子裔吗！",
		
		COMPASS =
		{
			GENERIC="我面向哪里？",
			N = "北",
			S = "南",
			E = "东",
			W = "西",
			NE = "东北",
			SE = "东南",
			NW = "西北",
			SW = "西南",
		},

		NIGHTMARE_TIMEPIECE =
		{
            CALM = "一切正常。",
            WARN = "这是...暗瘴气吗？",
            WAXING = "暗瘴气变得更浓了！",
            STEADY = "敌人越发大胆了！",
            WANING = "黑暗能量开始消退了。",
            DAWN = "敌人撤回阴影中去了。",
            NOMAGIC = "这东西在这没用。",
		},

		HOUNDSTOOTH="尖尖的！",
		ARMORSNURTLESHELL="我不是蜗牛！",
		BAT="一只蝙蝠",
		BATBAT = "拿上两个蝙蝠翅膀，我可以飞起来吗？",
		BATWING="一个蝙蝠翅膀",
		BATWING_COOKED="出人意料的好吃！",
        BATCAVE = "一个满是蝙蝠的洞穴！",
		BEDROLL_FURRY="又舒服又暖和！",
		BUNNYMAN="兔子人，emmmm.....",
		FLOWER_CAVE="好奇的萤根草",
		FLOWER_CAVE_DOUBLE="好奇的萤根草X2",
		FLOWER_CAVE_TRIPLE="好奇的萤根草X3",
		GUANO="没错，另一种屎。",
		LANTERN="提灯啊提灯~~",
		LIGHTBULB="萤根草的发光果!",
		MANRABBIT_TAIL="兔子尾巴~~",
		MUSHTREE_TALL = {
            GENERIC = "好大的蘑菇树！",
            BLOOM = "闻起来很奇怪！",
        },
		MUSHTREE_MEDIUM = {
            GENERIC = "又是这些巨大的蘑菇树！",
            BLOOM = "它在...发光吗?",
        },
		MUSHTREE_SMALL = {
            GENERIC = "一个神奇的小蘑菇树。",
            BLOOM = "它正在努力长大！",
        },
        MUSHTREE_TALL_WEBBED = "被蜘蛛网缠绕着...",
        SPORE_TALL = "孢子飘啊飘~",
        SPORE_MEDIUM = "孢子飘啊飘~",
        SPORE_SMALL = "孢子飘啊飘~",
        SPORE_TALL_INV = "它在我口袋里发光.",
        SPORE_MEDIUM_INV = "它在我口袋里发光",
        SPORE_SMALL_INV = "它在我口袋里发光",
		RABBITHOUSE=
		{
			GENERIC = "这不是一个真正的萝卜，它不能吃....",
			BURNT = "烤熟了也不能吃.....",
		},
		SLURTLE="呵~",
		SLURTLE_SHELLPIECES="一个破碎的谜题。",
		SLURTLEHAT="我希望它别弄乱我的头发。",
		SLURTLEHOLE="咕啾",
		SLURTLESLIME="黏糊糊的不可名状液体。",
		SNURTLE="一只蜗牛！",
		SPIDER_HIDER="别躲躲藏藏的了，面对我吧！",
		SPIDER_SPITTER="吐出腐蚀性液体的蜘蛛。",
		SPIDERHOLE="沾满了蛛网。",
		STALAGMITE="对我来说就是块石头！",
		STALAGMITE_FULL="对我来说就是块石头！",
		STALAGMITE_LOW="对我来说就是块石头！",
		STALAGMITE_MED="对我来说就是块石头！",
		STALAGMITE_TALL="石笋...石笋...石笋....石笋.....",
		STALAGMITE_TALL_FULL="石笋...石笋...石笋....石笋.....",
		STALAGMITE_TALL_LOW="石笋...石笋...石笋....石笋.....",
		STALAGMITE_TALL_MED="石笋...石笋...石笋....石笋.....",

		TURF_CARPETFLOOR = "是地皮！",
		TURF_CHECKERFLOOR = "是地皮！",
		TURF_DIRT = "是地皮！",
		TURF_FOREST = "是地皮！",
		TURF_GRASS = "是地皮！",
		TURF_MARSH = "是地皮！",
		TURF_ROAD = "是地皮！",
		TURF_ROCKY = "是地皮！",
		TURF_SAVANNA = "是地皮！",
		TURF_WOODFLOOR = "是地皮！",

		TURF_CAVE="是地皮！",
		TURF_FUNGUS="是地皮！",
		TURF_SINKHOLE="是地皮！",
		TURF_UNDERROCK="是地皮！",
		TURF_MUD="是地皮！",

		TURF_DECIDUOUS = "是地皮！",
		TURF_SANDY = "是地皮！",
		TURF_BADLANDS = "是地皮！",

		POWCAKE = "我不想吃它...",
        CAVE_ENTRANCE = "我必须把这些石头弄开！",
        CAVE_ENTRANCE_RUINS = "好像里面藏着什么...",
        CAVE_ENTRANCE_OPEN = {
            GENERIC = "去地下探险吧！",
            OPEN = "去地下探险吧！",
            FULL = "进不去了！",
        },
        CAVE_EXIT = {
            GENERIC = "我会呆在这的。",
            OPEN = "我已经探索的够多了。",
            FULL = "出口被堵住了！",
        },
		MAXWELLPHONOGRAPH = "这就是播放BGM的地方！",
		BOOMERANG = "回旋镖！",
		PIGGUARD = "它是一个保卫者！",
		ABIGAIL = "姐姐你好！",
		ADVENTURE_PORTAL = "我渴望冒险！",
		AMULET = "生命之光喷薄而出。",
		ANIMAL_TRACK = "一个动物留下的脚印。",
		ARMORGRASS = "落后的防御装备。",
		ARMORMARBLE = "好重啊....",
		ARMORWOOD = "硬邦邦的...",
		ARMOR_SANITY = "这盔甲让我头晕...",
		ASH =
		{
			GENERIC = "灰烬大人，你还听得到吗？",
			REMAINS_GLOMMERFLOWER = "The flower was consumed by fire when I teleported.",
			REMAINS_EYE_BONE = "The eyebone was consumed by fire when I teleported.",
			REMAINS_THINGIE = "无火的余烬，终究是成不了薪的....",
		},
		AXE = "大斧头飞过来啦！",
		BABYBEEFALO = "一头小牛，蛋白质含量是大牛的五倍！",
		BACKPACK = "用来负重的背包",
		BACONEGGS = "我更喜欢吃培根炒饭！",
		BANDAGE = "急救！",
		BASALT = "坚不可摧！",
		BATBAT = "拿上两个蝙蝠翅膀，我可以飞起来吗？",	-- Duplicated
		BEARDHAIR = "某人的胡子！",
		BEARGER = "是苏维埃的战熊！",
		BEARGERVEST = "暖和的熊皮大衣！",
		ICEPACK = "隔热的小巧背包！",
		BEARGER_FUR = "一大块熊皮！",
		BEDROLL_STRAW = "一小块熊皮。",
		BEE =
		{
			GENERIC = "2B or not 2B",
			HELD = "嗡嗡嗡...",
		},
		BEEBOX =
		{
			READY = "有一些蜂蜜！",
			FULLHONEY = "全都是蜂蜜！",
			GENERIC = "全是蜜蜂！",
			NOHONEY = "空了。",
			SOMEHONEY = "等一会就有蜂蜜了。",
			BURNT = "我怎么能把它烧焦了呢？",
		},
		BEEFALO =
		{
			FOLLOWER = "牛牛乖....",
			GENERIC = "一头牛！",
			NAKED = "哈，他看起来很忧桑！",
			SLEEPING = "睡得真香！",
		},
		BEEFALOHAT = "多好的牛角帽啊！",
		BEEFALOWOOL = "暖和的牛毛！",
		BEEHAT = "防止我被蜜蜂叮咬！",
		BEEHIVE = "里面全是蜜蜂！",
		BEEMINE = "Be mine with Yuri!",
		BEEMINE_MAXWELL = "这是个陷阱！",
		BERRIES = "我更喜欢蓝莓！",
		BERRIES_COOKED = "可是我还是喜欢蓝莓！",
		BERRYBUSH =
		{
			BARREN = "我应该给它施肥了！",
			WITHERED = "它凋零了...",
			GENERIC = "浆果最好吃了！",
			PICKED = "快点长出来啊！",
		},
		BIGFOOT = "所到之处，寸草不生。",
		BIRDCAGE =
		{
			GENERIC = "我应该放只鸽子进去？",
			OCCUPIED = "这是我的鸟！",
			SLEEPING = "它在碎觉！",
			HUNGRY = "它看起来很饿。",
			STARVING = "它快要饿死了，我得找点东西喂它！",
			DEAD = "哦不....",
			SKELETON = "安息吧....",
		},
		BIRDTRAP = "拿去抓鸟，耶！",
		BIRD_EGG = "一颗鸡蛋。",
		BIRD_EGG_COOKED = "我喜欢吃煎鸡蛋！",
		BISHOP = "幽邃的大主教！",
		BLOWDART_FIRE = "以火制火！",
		BLOWDART_SLEEP = "昏睡红茶（物理）",
		BLOWDART_PIPE = "一根口欠箭，嗯。",
		BLUEAMULET = "好冷！",
		BLUEGEM = "就像凯达琳的水晶！",
		BLUEPRINT = "蓝图！",
		BELL_BLUEPRINT = "大钟的蓝图！",
		BLUE_CAP = "闻起来很奇怪的蓝蘑菇。",
		BLUE_CAP_COOKED = "闻起来更奇怪了。",
		BLUE_MUSHROOM =
		{
			GENERIC = "这是个蘑菇！",
			INGROUND = "它缩回去了",
			PICKED = "等着它长出来吗？",
		},
		BOARDS = "木板！",
		BOAT = "船！",
		BONESHARD = "一些骨头！",
		BONESTEW = "美味的大碗肉汤！",
		BUGNET = "拿去捉虫子！",
		BUSHHAT = "做成拟态虫！",
		BUTTER = "我家里有很多小黄油！",
		BUTTERFLY =
		{
			GENERIC = "蝴蝶飞啊飞。",
			HELD = "抓住你了！",
		},
		BUTTERFLYMUFFIN = "蝴蝶小蛋糕！",
		BUTTERFLYWINGS = "蝴蝶这么可爱，干脆杀掉好了qwq",
		BUZZARD = "光头吴克！",
		CACTUS = 
		{
			GENERIC = "群主快乐球！",
			PICKED = "啊哈！",
		},
		CACTUS_MEAT_COOKED = "我还是自己吃吧！",
		CACTUS_MEAT = "群主最喜欢吃了！",
		CACTUS_FLOWER = "仙人掌的花超漂亮的！",

		COLDFIRE =
		{
			EMBERS = "火快要灭了，我得加点燃料进去！",
			GENERIC = "呼唔，蓝色的火！",
			HIGH = "火焰更加猛烈了！",
			LOW = "火焰好像在变小！",
			NORMAL = "这就很舒服了。",
			OUT = "火焰熄灭了！",
		},
		CAMPFIRE =
		{
			EMBERS = "我需要助燃剂！",
			GENERIC = "温暖的火！",
			HIGH = "火焰太大了，会引起火灾的！",
			LOW = "火焰开始变小了！",
			NORMAL = "舒服的火！",
			OUT = "火焰熄灭了！",
		},
		CANE = "疾如岛风！",
		CATCOON = "吸猫时间到！",
		CATCOONDEN = 
		{
			GENERIC = "猫猫的窝。",
			EMPTY = "猫有九条命，可惜它都用完了。",
		},
		CATCOONHAT = "云吸猫。",
		COONTAIL = "猫尾巴。",
		CARROT = "胡萝北。",
		CARROT_COOKED = "烤胡萝北。",
		CARROT_PLANTED = "拔胡萝北。",
		CARROT_SEEDS = "是种子！",
		WATERMELON_SEEDS = "西瓜子！",
		CAVE_FERN = "小叶子！",
		CHARCOAL = "闻起来像烧焦的木头。",
        CHESSJUNK1 = "棋子的碎片。",
        CHESSJUNK2 = "又是棋子的碎片。",
        CHESSJUNK3 = "还是棋子的碎片。",
		CHESTER = "苟箱！",
		CHESTER_EYEBONE =
		{
			GENERIC = "一根骨头上面连着眼珠子。",
			WAITING = "它的眼睛闭上了。",
		},
		COOKEDMANDRAKE = "可怜的曼德拉娘....",
		COOKEDMEAT = "烤肉BBQ",
		COOKEDMONSTERMEAT = "比生的的怪物肉好一点，但是还是很难吃....",
		COOKEDSMALLMEAT = "把肉烤熟，可以杀死寄生虫。",
		COOKPOT =
		{
			COOKING_LONG = "烹饪时间较长，需要等一会。",
			COOKING_SHORT = "就快好了",
			DONE = "窝要开动啦！",
			EMPTY = "揭不开锅...",
			BURNT = "锅烧焦了。",
		},
		ICEY_COOKPOT =
		{
			COOKING_LONG = "烹饪时间较长，需要等一会。",
			COOKING_SHORT = "就快好了",
			DONE = "窝要开动啦！",
			EMPTY = "揭不开锅...",
			BURNT = "锅烧焦了。",
		},
		CORN = "营养价值很高！",
		CORN_COOKED = "营养价值很高！",
		CORN_SEEDS = "种子",
		CROW =
		{
			GENERIC = "可爱。",
			HELD = "他看起来很不开心。",
		},
		CUTGRASS = "可以给竹鼠做窝。",
		CUTREEDS = "收集到的芦苇，不知道拿去做什么。",
		CUTSTONE = "一块大石砖。",
		DEADLYFEAST = "最后的晚餐。",
		DEERCLOPS = "我要切碎你！",
		DEERCLOPS_EYEBALL = "好大的眼球啊",
		EYEBRELLAHAT =	"它望着天空。",
		DEPLETED_GRASS =
		{
			GENERIC = "草吗？",
		},
		DEVTOOL = "闻起来像培根一样。",
		DEVTOOL_NODEV = "我没有足够的力量去驾驭它。",
		DIRTPILE = "一小块土？",
		DIVININGROD =
		{
			COLD = "信号很微弱。",
			GENERIC = "有一点信号了。",
			HOT = "这东西发疯了！",
			WARM = "我猜的没错，就是这个方向！",
			WARMER = "一定很近了！",
		},
		DIVININGRODBASE =
		{
			GENERIC = "我不知道这是干什么的。",
			READY = "看起来它需要一个钥匙！",
			UNLOCKED = "现在它能工作了！",
		},
		DIVININGRODSTART = "这个装置看起来挺有用的。",
		DRAGONFLY = "接下来，落下攻击很有用！",
		ARMORDRAGONFLY = "猎龙铠甲！",
		DRAGON_SCALES = "一片龙鳞！",
		DRAGONFLYCHEST = "龙鳞做的宝箱！",
		LAVASPIT = 
		{
			HOT = "热乎乎的唾液。",
			COOL = "它冷却了。",
		},

		LAVAE = "烫手的山芋。",
		LAVAE_PET = 
		{
			STARVING = "他看起来很饿。",
			HUNGRY = "他的肚子已经开始咕咕叫了。",
			CONTENT = "有趣的小家伙。",
			GENERIC = "哇，可爱！",
		},
		LAVAE_EGG = 
		{
			GENERIC = "我可以感觉到火的能量。",
		},
		LAVAE_EGG_CRACKED =
		{
			COLD = "太冷了，他会死的。",
			COMFY = "开心的蛋！",
		},
		LAVAE_TOOTH = "一个小牙齿吗？",

		DRAGONFRUIT = "火龙果！",
		DRAGONFRUIT_COOKED = "烤火龙果！",
		DRAGONFRUIT_SEEDS = "火龙果的种子！",
		DRAGONPIE = "我超喜欢吃火龙果π！",
		DRUMSTICK = "生鸡腿，带点腥味。",
		DRUMSTICK_COOKED = "肯德基爷爷！",
		DUG_BERRYBUSH = "种浆果！",
		DUG_GRASS = "种草！",
		DUG_MARSH_BUSH = "我可以移植它！",
		DUG_SAPLING = "我可以移植它！",
		DURIAN = "恶臭榴莲，噫.....",
		DURIAN_COOKED = "现在它更臭了....",
		DURIAN_SEEDS = "是种子。",
		EARMUFFSHAT = "可爱的耳罩。",
		EGGPLANT = "一二三，茄子！",
		EGGPLANT_COOKED = "一二三，烤茄子！",
		EGGPLANT_SEEDS = "茄子种子！",
		DECIDUOUSTREE = 
		{
			BURNING = "真是浪费木材！",
			BURNT = "现在只能做木炭了。",
			CHOPPED = "尝尝这个，大树！",
			POISON = "哇啊！咒蚀的大树！",
			GENERIC = "是落叶树。",
		},
		ACORN = "是橡树果！",
        ACORN_SAPLING = "你马上就会长成大树了。",
		ACORN_COOKED = "看起来很美味！",
		BIRCHNUTDRAKE = "胡桃妖精！",
		EVERGREEN =
		{
			BURNING = "啊！着火了！",
			BURNT = "已经烧焦了！",
			CHOPPED = "又一棵大树倒下了！",
			GENERIC = "是一颗松树！",
		},
		EVERGREEN_SPARSE =
		{
			BURNING = "森林火灾的产物。",
			BURNT = "弄点木炭回去！",
			CHOPPED = "接招吧，大自然！",
			GENERIC = "这种树没有果实。",
		},
		EYEPLANT = "它在看着我。",
		FARMPLOT =
		{
			GENERIC = "农耕生活。",
			GROWING = "快长大啊，快长大。",
			NEEDSFERTILIZER = "我想我应该给它施肥了。",
			BURNT = "不！我的农场！",
		},
		FEATHERHAT = "羽毛帽子！",
		FEATHER_CROW = "乌鸦的羽毛。",
		FEATHER_ROBIN = "红色的羽毛。",
		FEATHER_ROBIN_WINTER = "雪中的羽毛。",
		FEM_PUPPET = "捉住她了！",
		FIREFLIES =
		{
			GENERIC = "萤火虫飞啊飞~",
			HELD = "它们在我口袋里发光！",
		},
		FIREHOUND = "热气满满的猎犬。",
		FIREPIT =
		{
			EMBERS = "火快要熄灭了！",
			GENERIC = "击败黑暗的方式不止一种！",
			HIGH = "好大的火焰！",
			LOW = "火焰正在变小。",
			NORMAL = "舒服的火堆。",
			OUT = "火完全灭掉了。",
		},
		COLDFIREPIT =
		{
			EMBERS = "火快要熄灭了！",
			GENERIC = "击败黑暗的方式不止一种！",
			HIGH = "好大的火焰！",
			LOW = "火焰正在变小。",
			NORMAL = "舒服的火堆。",
			OUT = "火完全灭掉了。",
		},
		FIRESTAFF = "世界在我脚下燃烧。",
		FIRESUPPRESSOR = 
		{	
			ON = "开启！",
			OFF = "关闭！",
			LOWFUEL = "燃料不足！",
		},

		FISH = "一条大鱼！",
		FISHINGROD = "放长线，钓大鱼！",
		FISHSTICKS = "我自己做的！",
		FISHTACOS = "这是我自己烧的！",
		FISH_COOKED = "烤鱼！",
		FLINT = "一块锋利的石头。",
		FLOWER = "一朵花花。",
        FLOWER_WITHERED = "它凋零了。",
		FLOWERHAT = "花花花环",
		FLOWER_EVIL = "唔...好恶心的花...",
		FOLIAGE = "小叶子...",
		FOOTBALLHAT = "哈，看起来够硬！",
		FROG =
		{
			DEAD = "他死掉了...",
			GENERIC = "一个可爱的小长者。",
			SLEEPING = "小长者在睡觉。",
		},
		FROGGLEBUNWICH = "我自己做的！",
		FROGLEGS = "长者的腿。",
		FROGLEGS_COOKED = "熟长者的腿。",
		FRUITMEDLEY = "我自己做的！",
		FURTUFT = "黑白相间。", 
		GEARS = "Metal....Gear ?",
		GHOST = "妖魔鬼怪快离开。",
		GOLDENAXE = "金斧子真是棒极了！",
		GOLDENPICKAXE = "不是说金是软的吗？",
		GOLDENPITCHFORK = "额，金色草叉？",
		GOLDENSHOVEL = "让我们来挖点什么！",
		GOLDNUGGET = "金闪闪！",
		GRASS =
		{
			BARREN = "它需要施肥！",
			WITHERED = "太热了，它枯萎了！",
			BURNING = "烧起来了！",
			GENERIC = "这是一棵草。",
			PICKED = "我已经采集了能用的干草。",
		},
		GREEN_CAP = "象征原谅的蘑菇。",
		GREEN_CAP_COOKED = "看起来更加原谅了。",
		GREEN_MUSHROOM =
		{
			GENERIC = "原谅色的蘑菇。",
			INGROUND = "他睡着了。",
			PICKED = "什么时候能长回来呢？",
		},
		GUNPOWDER = "炮火轰鸣！",
		HAMBAT = "大♂肉♂棒",
		HAMMER = "战锤40000英镑。",
		HEALINGSALVE = "The secret of the Phoenix is the timing of her repairs.",
		HEATROCK =
		{
			FROZEN = "比冰还冷！",
			COLD = "石头变冷了。",
			GENERIC = "可以用来储存热量。",
			WARM = "很温暖的石头。",
			HOT = "摸起来很烫手。",
		},
		HOME = "有人住在这里！",
		HOMESIGN =
		{
			GENERIC = "上面写着什么乱七八糟的？",
            UNWRITTEN = "上面什么也没写。",
			BURNT = "\"禁止玩火！\"",
		},
		ARROWSIGN_POST =
		{
			GENERIC = "上面写着“朝着走”",
            UNWRITTEN = "路标上面什么也没有。",
			BURNT = "\"禁止玩火！\"",
		},
		ARROWSIGN_PANEL =
		{
			GENERIC = "上面写着“朝着走”",
            UNWRITTEN = "路标上面什么也没有。",
			BURNT = "\"禁止玩火！\"",
		},
		HONEY = "甜蜜蜜。",
		HONEYCOMB = "小蜜蜂在哪睡？",
		HONEYHAM = "我自己做的！",
		HONEYNUGGETS = "我自己做的！",
		HORN = "残留着牛牛的味道。",
		HOUND = "杀不尽的欧洲狗。",
		HOUNDBONE = "欧洲狗的骨头。",
		HOUNDMOUND = "欧洲狗的家！",
		ICEBOX = "掌握冷的力量。",
		ICEHAT = "让我想起了俄罗斯。",
		ICEHOUND = "欧洲狗在这种天气也出来活动吗？",
		INSANITYROCK =
		{
			ACTIVE = "尝尝这个！",
			INACTIVE = "神奇的石头！",
		},
		JAMMYPRESERVES = "我自己做的！",
		KABOBS = "骨肉相连！",
		KILLERBEE =
		{
			GENERIC = "是一只杀人蜂！",
			HELD = "看起来很危险！",
		},
		KNIGHT = "骑士，传火吗？",
		KOALEFANT_SUMMER = "肥嘟嘟的大象！",
		KOALEFANT_WINTER = "看起来又大又暖又好吃！",
		KRAMPUS = "站住！小偷！",
		KRAMPUS_SACK = "叮当叮当！",
		LEIF = "大自然的守护者！",
		LEIF_SPARSE = "大自然的守护者！",
		LIGHTNING_ROD =
		{
			CHARGED = "雷电被囚禁在这里。",
			GENERIC = "你不怕天打雷劈吗？",
		},
		LIGHTNINGGOAT = 
		{
			GENERIC = "咩？咩！咩月~",
			CHARGED = "它全身都是电！",
		},
		LIGHTNINGGOATHORN = "就像一根避雷针！",
		GOATMILK = "新鲜的羊奶！",
		LITTLE_WALRUS = "小海象！",
		LIVINGLOG = "它看起来愁眉苦脸的！",
		LOG =
		{
			BURNING = "热乎乎的木头！",
			GENERIC = "又大又重的木头！",
		},
		LUREPLANT = "食人草的球状根茎。",
		LUREPLANTBULB = "现在我可以制造自己的农场了？",
		MALE_PUPPET = "他被困住了。",

		MANDRAKE_ACTIVE = "烦死了，离我远点！",
		MANDRAKE_PLANTED = "听到曼德拉草叫声的人会死。",
		MANDRAKE = "曼德拉草根有一种特殊的魔力。",

		MANDRAKESOUP = "曼德拉草汤....嗯....",
		MANDRAKE_COOKED = "这真的能吃吗？",
		MARBLE = "硬邦邦的大理石。",
		MARBLEPILLAR = "这看起来还有点用。",
		MARBLETREE = "太硬了！",
		MARSH_BUSH =
		{
			BURNING = "烧起来了！",
			GENERIC = "好多刺啊。",
			PICKED = "刺痛我了。",
		},
		BURNT_MARSH_BUSH = "全部烧焦了！",
		MARSH_PLANT = "只是草而已。",
		MARSH_TREE =
		{
			BURNING = "着火了！",
			BURNT = "全部烧焦了。",
			CHOPPED = "光秃秃的。",
			GENERIC = "这些刺看起来很尖！",
		},
		MAXWELL = "向旧日支配者致敬。",
		MAXWELLHEAD = "麦克斯韦的大头。",
		MAXWELLLIGHT = "一种奇怪的光源。",
		MAXWELLLOCK = "看起来像一个钥匙孔。",
		MAXWELLTHRONE = "那看起来一点也不舒服。",
		MEAT = "一大块肉！",
		MEATBALLS = "红烧狮子头。",
		MEATRACK =
		{
			DONE = "风干啦！",
			DRYING = "还需要一段时间才能风干。",
			DRYINGINRAIN = "湿度会使风干的时间变长。",
			GENERIC = "我应该放一些肉上去。",
			BURNT = "晒肉架被“风干”了",
		},
		MEAT_DRIED = "很硬，很好吃！",
		MERM = "一只鱼男！",
		MERMHEAD = 
		{
			GENERIC = "鱼男真可怜...",
			BURNT = "鱼男被烧焦了...",
		},
		MERMHOUSE = 
		{
			GENERIC = "鱼男的家。",
			BURNT = "鱼男的家没了...",
		},
		MINERHAT = "可是我已经有手电筒了啊。",
		MONKEY = "好奇的小家伙。",
		MONKEYBARREL = "它刚刚动了吗？",
		MONSTERLASAGNA = "噫，我才不要！",
		FLOWERSALAD = "一碗叶子！",
        ICECREAM = "很高兴冰到你。",
        WATERMELONICLE = "西瓜冰淇淋，mua~",
        TRAILMIX = "干果？",
        HOTCHILI = "辣辣辣~",
        GUACAMOLE = "鼹鼠做的沙拉？",
		MONSTERMEAT = "这块肉的成色很不好。",
		MONSTERMEAT_DRIED = "我还是不想吃它...",
		MOOSE = "四不像。",
		MOOSEEGG = "这是什么？",
		MOSSLING = "这是啥？",
		FEATHERFAN = "让我感觉很cooooooool！",
        MINIFAN = "小扇子！",
		GOOSE_FEATHER = "毛绒绒。",
		STAFF_TORNADO = "龙卷风摧毁停车场！",
		MOSQUITO =
		{
			GENERIC = "蚊子！",
			HELD = "我身上可没有血。",
		},
		MOSQUITOSACK = "里面应该是其他人的血。",
		MOUND =
		{
			DUG = "对此我很抱歉....",
			GENERIC = "倒斗吗？",
		},
		NIGHTLIGHT = "黯影中的光明。",
		NIGHTMAREFUEL = "San Check，请。",
		NIGHTSWORD = "深邃黑暗的幻想之剑。",
		NITRE = "我不是一个地质学家。",
		ONEMANBAND = "好戏开演。",
		PANDORASCHEST = "里面可能是宝物。",
		PANFLUTE = "哦♂卖萧的♂卖萧的！",
		PAPYRUS = "一些纸。",
		PENGUIN = "一定是冬天到了。",
		PERD = "我需要一只采摘火鸡。",
		PEROGIES = "我自己做的。",
		PETALS = "花？闻起来很香。",
		PETALS_EVIL = "我拿着这些做什么。",
		PHLEGM = "一口浓痰，噫....",
		PICKAXE = "救赎之道，就在其中。",
		PIGGYBACK = "这让我感到罪恶深重。",
		PIGEON = "一只鸽里。",
		QUAGMIRE_PIGEON =
        {
            DEAD = "它死了。",
            GENERIC = "一只鸽里。",
            SLEEPING = "鸽里又在偷懒了。",
        },
		PIGHEAD = 
		{	
			GENERIC = "感觉怪怪的....",
			BURNT = "乌黑乌黑的。",
		},
		PIGHOUSE =
		{
			FULL = "有人在房子里。",
			GENERIC = "为什么是个猪都住的比我好？",
			LIGHTSOUT = "灯灭了，但是里面绝对有人！",
			BURNT = "完全烧焦了。",
		},
		PIGKING = "好大一只猪。",
		PIGMAN =
		{
			DEAD = "他...死了....",
			FOLLOWER = "我的伙伴！",
			GENERIC = "猪人曾经有过辉煌的文明。",
			GUARD = "这是一个守卫。",
			WEREPIG = "他疯了！",
		},
		PIGSKIN = "上面还有猪尾巴。",
		PIGTENT = "闻起来像培根一样。",
		PIGTORCH = "滑稽的火炬。",
		PINECONE = "小松果耶！",
        PINECONE_SAPLING = "他很快就会长大的！",
        LUMPY_SAPLING = "这种树没有果实，那么它的树苗是怎么来的呢？",
		PITCHFORK = "可以铲起地皮的草叉。",
		PLANTMEAT = "多汁的叶肉。",
		PLANTMEAT_COOKED = "多汁可口。",
		PLANT_NORMAL =
		{
			GENERIC = "Leafy.",
			GROWING = "Guh. It's growing so slowly.",
			READY = "Mmmm. Ready to harvest.",
			WITHERED = "The heat killed it.",
		},
		POMEGRANATE = "It looks like the inside of an alien's brain.",
		POMEGRANATE_COOKED = "Haute Cuisine.",
		POMEGRANATE_SEEDS = "It's a seed.",
		POND = "I can see small little fish. Cute.",
		POOP = "I should fill my pockets.",
		FERTILIZER = "A bucket filled with excrement.",
		PUMPKIN = "It's as big as my head.",
		PUMPKINCOOKIE = "I cooked it myself.",
		PUMPKIN_COOKED = "How did it not turn into a pie?",
		PUMPKIN_LANTERN = "Spooky.",
		PUMPKIN_SEEDS = "It's a seed.",
		PURPLEAMULET = "It's whispering to me...",
		PURPLEGEM = "It contains the mysteries of the universe.",
		RABBIT =
		{
			GENERIC = "He's looking for carrots.",
			HELD = "Is the order a rabbit?",
		},
		RABBITHOLE = 
		{
			GENERIC = "I wonder where how deep the rabbit hole goes.",
			SPRING = "It seems to be closed.",
		},
		RAINOMETER = 
		{	
			GENERIC = "It measures cloudiness.",
			BURNT = "It burnt down...",
		},
		RAINCOAT = "Keeps the rain where it ought to be. Outside my body.",
		RAINHAT = "It'll mess up my hair, but I'll stay nice and dry.",
		RATATOUILLE = "I cooked it myself.",
		RAZOR = "A sharpened rock tied to a stick. Hygienic.",
		REDGEM = "It sparkles with inner warmth.",
		RED_CAP = "It smells funny.",
		RED_CAP_COOKED = "It's different now...",
		RED_MUSHROOM =
		{
			GENERIC = "It's a mushroom.",
			INGROUND = "It's sleeping.",
			PICKED = "I wonder if it will come back?",
		},
		REEDS =
		{
			BURNING = "It's on fire.",
			GENERIC = "It's a clump of reeds.",
			PICKED = "I picked all the useful reeds.",
		},
        RELIC = 
        {
            GENERIC = "Ancient household goods.",
            BROKEN = "Nothing to work with here.",
        },
        RUINS_RUBBLE = "This can be fixed.",
        RUBBLE = "Just bits and pieces of rock.",
		RESEARCHLAB = 
		{	
			GENERIC = "It breaks down objects into their scientific components.",
			BURNT = "It won't be doing much science now.",
		},
		RESEARCHLAB2 = 
		{
			GENERIC = "It's even more science-y than the last one.",
			BURNT = "The extra science didn't keep it alive.",
		},
		RESEARCHLAB3 = 
		{
			GENERIC = "...What is this?",
			BURNT = "Whatever it was, it's burnt now.",
		},
		RESEARCHLAB4 = 
		{
			GENERIC = "That's a funny name.",
			BURNT = "Fire doesn't really solve naming issues...",
		},
		RESURRECTIONSTATUE = 
		{
			GENERIC = "A statue that can revive ghosts.",
			BURNT = "Not much use anymore.",
		},		RESURRECTIONSTONE = "I can feel warmth coming from this stone.",
		ROBIN =
		{
			GENERIC = "Does that mean winter is gone?",
			HELD = "He likes my pocket.",
		},
		ROBIN_WINTER =
		{
			GENERIC = "Life in the frozen wastes.",
			HELD = "It's so soft.",
		},
		ROBOT_PUPPET = "It's trapped.",
		ROCK_LIGHT =
		{
			GENERIC = "A crusted-over lava pit.",
			OUT = "Looks fragile.",
			LOW = "The lava's crusting over.",
			NORMAL = "Nice and comfy.",
		},
		ROCK = "It wouldn't fit in my pocket.",
		ROCK_ICE = 
		{
			GENERIC = "A very isolated glacier.",
			MELTED = "Nothing useful until it freezes again.",
		},
		ROCK_ICE_MELTED = "Nothing useful until it freezes again.",
		ICE = "Useful for cooling drinks.",
		ROCKS = "I can build things with these.",
        ROOK = "Storm the castle.",
		ROPE = "Some short lengths of rope.",
		ROTTENEGG = "It's rotten...",
		SANITYROCK =
		{
			ACTIVE = "That's a strange-looking rock...",
			INACTIVE = "Where did the rest of it go?",
		},
		SAPLING =
		{
			BURNING = "That's burning fast.",
			WITHERED = "It's dying...",
			GENERIC = "It's slowly growing.",
			PICKED = "I needed the twigs.",
		},
		SEEDS = "Plant seeds. It's a mystery what it'll grow into.",
		SEEDS_COOKED = "I don't think this will grow into anything.",
		SEWING_KIT = "Sewing, huh. Reminds me of the olden days.",
		SHOVEL = "Let's start digging, shall we?",
		SILK = "It's silk. Maybe it can be used as a string.",
		SKELETON = "...Rest in peace.",
		SCORCHED_SKELETON = "Spooky.",
		SKULLCHEST = "I'm not sure if I want to open it.",
		SMALLBIRD =
		{
			GENERIC = "That's a rather small bird.",
			HUNGRY = "It looks hungry.",
			STARVING = "It must be starving.",
		},
		SMALLMEAT = "A tiny chunk of meat.",
		SMALLMEAT_DRIED = "A little jerky.",
		SPAT = "It's a crusty-looking animal.",
		SPEAR = "That's one pointy stick.",
		SPIDER =
		{
			DEAD = "这是一只死蜘蛛。",
			GENERIC = "毛绒绒的蜘蛛。",
			SLEEPING = "他睡着了。",
		},
		SPIDERDEN = "Sticky.",
		SPIDEREGGSACK = "Hopefully these don't hatch while I'm carrying them.",
		SPIDERGLAND = "It has a tangy, antiseptic smell.",
		SPIDERHAT = "I hope I got all of the spider goo out of it.",
		SPIDERQUEEN = "Is that the queen...!? It's huge...",
		SPIDER_WARRIOR =
		{
			DEAD = "去死去死去死！",
			GENERIC = "蜘蛛战士显得更加强大。",
			SLEEPING = "小心接近。",
		},
		SPOILED_FOOD = "It's a furry ball of rotten food.",
		STATUEHARP = "What has happened to the head?",
		STATUEMAXWELL = "It really captures his personality.",
		STEELWOOL = "Scratchy metal fibers.",
		STINGER = "Looks sharp.",
		STRAWHAT = "What a nice hat.",
		STUFFEDEGGPLANT = "I cooked it myself.",
		SUNKBOAT = "Rest in peace, comrade.",
		SWEATERVEST = "This vest is dapper as all get-out.",
		REFLECTIVEVEST = "Keep off, evil sun.",
		HAWAIIANSHIRT = "It's not lab-safe.",
		TAFFY = "I cooked it myself.",
		TALLBIRD = "很高很高的鸟。",
		TALLBIRDEGG = "它会孵化吗？",
		TALLBIRDEGG_COOKED = "美味又营养。",
		TALLBIRDEGG_CRACKED =
		{
			COLD = "看起来有点冷。",
			GENERIC = "在孵化了。",
			HOT = "这只蛋中暑了，不如....",
			LONG = "距离孵化还有很长时间....",
			SHORT = "快好了！",
		},
		TALLBIRDNEST =
		{
			GENERIC = "里面有一个蛋！",
			PICKED = "鸟巢是空的。",
		},
		TEENBIRD =
		{
			GENERIC = "不算高的鸟。",
			HUNGRY = "他看起来很饿。",
			STARVING = "他的眼神十分饥渴！",
		},
		TELEBASE = 
		{
			VALID = "这个设备已经可以运作了！",
			GEMS = "它需要紫宝石插槽！",
		},
		GEMSOCKET = 
		{
			VALID = "这样差不多了。",
			GEMS = "它需要一个紫宝石！",
		},
		TELEPORTATO_BASE =
		{
			ACTIVE = "我可以用这个来打破时间与空间的限制！",
			GENERIC = "这是到达另一个世界的关键！",
			LOCKED = "缺少一些...零件！",
			PARTIAL = "很快就行了！",
		},
		TELEPORTATO_BOX = "This may control the polarity of the whole universe.",
		TELEPORTATO_CRANK = "Tough enough to handle the most intense experiments.",
		TELEPORTATO_POTATO = "This metal potato contains great and fearful power...",
		TELEPORTATO_RING = "A ring that could focus dimensional energies.",
		TELESTAFF = "传送门！",
		TENT = 
		{
			GENERIC = "所有人都需要睡觉。",
			BURNT = "烧得连渣也不剩。",
		},
		SIESTAHUT = 
		{
			GENERIC = "用来午休很不错。",
			BURNT = "没法遮阴了...",
		},
		TENTACLE = "魔法少女的好朋友。",
		TENTACLESPIKE = "触手用它的尖刺来XXXXXX",
		TENTACLESPOTS = "我还以为触手没有皮呢！",
		TENTACLE_PILLAR = "魔法少女的好朋友。",
        TENTACLE_PILLAR_HOLE = "下面一定是触手的洞窟了...",
		TENTACLE_PILLAR_ARM = "黏糊糊的小触手。",
		TENTACLE_GARDEN = "又一个洞窟。",
		TOPHAT = "绅士的帽子。",
		TORCH = "我希望贝尔蒙特不要突然出现，然后用鞭子将它抽熄。",
		TRANSISTOR = "它的击穿电压很高。",
		TRAP = "抓小动物！",
		TRAP_TEETH = "牙齿做的陷阱！",
		TRAP_TEETH_MAXWELL = "我可不想踩到它！",
		TREASURECHEST = 
		{
			GENERIC = "一个储物箱！",
			BURNT = "烧焦的储物箱...",
		},
		TREASURECHEST_TRAP = "哇！",
		TREECLUMP = "好像过不去诶！",
		
		TRINKET_1 = "They are all melted together.", --Melty Marbles
		TRINKET_2 = "It's just a cheap replica.", --Fake Kazoo
		TRINKET_3 = "The knot is stuck. Forever.", --Gord's Knot
		TRINKET_4 = "It must be some kind of religious artifact.", --Gnome
		TRINKET_5 = "Sadly, it's too small for me to escape on.", --Tiny Rocketship
		TRINKET_6 = "Their electricity carrying days are over.", --Frazzled Wires
		TRINKET_7 = "I have no time for fun and games.", --Ball and Cup
		TRINKET_8 = "Great. All of my tub stopping needs are met.", --Hardened Rubber Bung
		TRINKET_9 = "I'm more of a zipper person, myself.", --Mismatched Buttons
		TRINKET_10 = "I hope I get out of here before I need these.", --Second-hand Dentures
		TRINKET_11 = "He whispers beautiful lies to me.", --Lying Robot
		TRINKET_12 = "I'm not sure what I should do with a dessicated tentacle.", --Dessicated Tentacle
		TRINKET_13 = "It must be some kind of religious artifact.", --Gnomette
		TRINKET_14 = "Now if I only had some tea...", -- Leaky Teacup
		TRINKET_15 = "The king's bishop.", -- White Bishop
		TRINKET_16 = "This is the wrong bishop.", -- Black Bishop
		TRINKET_17 = "An ice cream fork.", -- Bent Spork
		TRINKET_18 = "I wonder what it's hiding?", -- Toy Trojan Horse
		TRINKET_19 = "It doesn't spin very well.", -- Unbalanced Top
		TRINKET_20 = "Now I can scratch my back; all my problems are solved.", -- Back Scratcher
		TRINKET_21 = "This egg beater is all bent out of shape.", -- Beaten Beater
		TRINKET_22 = "Sadly, it's not strong enough to be useful for anything.", -- Frayed Yarn
		TRINKET_23 = "I can put my shoes on without help, thanks.", -- Shoe Horn
		TRINKET_24 = "Is it really lucky?", -- Lucky Cat Jar
		TRINKET_25 = "It smells kind of stale.", -- Air Unfreshener
		TRINKET_26 = "Food and a cup. The ultimate survival container.", -- Potato Cup
		TRINKET_27 = "Good, I can hang my clothes up if I ever find a hook.", -- Wire Hanger
		
		TRUNKVEST_SUMMER = "不怎么保暖的小背心。",
		TRUNKVEST_WINTER = "冬季必备！",
		TRUNK_COOKED = "香喷喷的烤象鼻！",
		TRUNK_SUMMER = "红色的象鼻！",
		TRUNK_WINTER = "肉乎乎的象鼻！",
		TUMBLEWEED = "站着别动！",
		TURF_CARPETFLOOR = "是地皮！",
		TURF_CHECKERFLOOR = "是地皮！",
		TURF_DIRT = "是地皮！",
		TURF_FOREST = "是地皮！",
		TURF_GRASS = "是地皮！",
		TURF_MARSH = "是地皮！",
		TURF_ROAD = "是地皮！",
		TURF_ROCKY = "是地皮！",
		TURF_SAVANNA = "是地皮！",
		TURF_WOODFLOOR = "是地皮！",
		TURKEYDINNER = "Emmmm....",
		TWIGS = "一捆小树枝！",
		UMBRELLA = "别淋湿了。",
		GRASS_UMBRELLA = "花里胡哨的。",
		UNIMPLEMENTED = "指令无法接收！",
		WAFFLES = "我自己做的菜！",
		WALL_HAY = 
		{	
			GENERIC = "看起来很不结实....",
			BURNT = "烧焦了...",
		},
		WALL_HAY_ITEM = "草墙真的可以吗？",
		WALL_STONE = "不错的石墙！",
		WALL_STONE_ITEM = "这让我有安全感。",
		WALL_RUINS = "上古时期的墙壁。",
		WALL_RUINS_ITEM = "历史的碎片。",
		WALL_WOOD = 
		{
			GENERIC = "尖尖的！",
			BURNT = "烧焦了...",
		},
		WALL_WOOD_ITEM = "一些小木墙。",
		WALL_MOONROCK = "一股满满的外太空气息！",
		WALL_MOONROCK_ITEM = "这下够硬了吧！",
		WALRUS = "海象是冬季的先驱者！",
		WALRUSHAT = "苏格兰分格的帽子！",
		WALRUS_CAMP =
		{
			EMPTY = "有人曾经在这里扎营，会是谁呢？",
			GENERIC = "里面看起来很温暖，但是我进不去...",
		},
		WALRUS_TUSK = "我该拿这个海象牙做什么呢？",
		WARDROBE = 
		{
			GENERIC = "我可不需要这个，我自己的衣服够漂亮了。",
            BURNING = "烧的好快！",
			BURNT = "已经烧焦了...",
		},
		WARG = "座狼探子！",
		WASPHIVE = "杀人蜂的巢穴！",
		WATERMELON = "甜甜大西瓜！",
		WATERMELON_COOKED = "多汁可口！",
		WATERMELONHAT = "果汁会溅到脸上的！",
		WETGOOP = "黑暗料理。",
		WINTERHAT = "暖乎乎的帽子！",
		WINTEROMETER = 
		{
			GENERIC = "它是....什么东西。",
			BURNT = "烧焦了....",
		},
		WORMHOLE =
		{
			GENERIC = "一条坑道虫！",
			OPEN = "底下一定有无数触手在等着我....",
		},
		WORMHOLE_LIMITED = "他看起来生病了...",
		ACCOMPLISHMENT_SHRINE = "一场华丽的大冒险吗？",        
		LIVINGTREE = "一棵枯树！",
		ICESTAFF = "冻住！不洗澡！",
		REVIVER = "重生吧！我的盟友！",
		LIFEINJECTOR = "Ura-!",
		SKELETON_PLAYER =
		{
			MALE = "%s被%s杀死了...",
			FEMALE = "%s被%s杀死了...",
			ROBOT = "%s被%s杀死了...",
			DEFAULT = "%s被%s杀死了...",
		},
		HUMANMEAT = "人肉吗？噫.....",
		HUMANMEAT_COOKED = "烤熟的人肉是粉红色的....",
		HUMANMEAT_DRIED = "好恶心，不想吃它....",
		MOONROCKNUGGET = "来自月球的石头！",
	},
	DESCRIBE_GENERIC = "我认不出它来...",
	DESCRIBE_TOODARK = "太黑了！",
	DESCRIBE_SMOLDERING = "快着火了！",
	EAT_FOOD =
	{
		TALLBIRDEGG_CRACKED = "嗯...好吃！",
	},
}
