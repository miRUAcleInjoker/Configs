local function createprefabs(customprefabs)
    local prefabs =
    {
        "nightmarefuel",
        "shadowheart",
        "armor_sanity",
        "nightsword",
    }

    for i, v in ipairs(customprefabs) do
        if not table.contains(prefabs, v) then
            table.insert(prefabs, v)
        end
    end
    return prefabs
end

local function createassets(name)
    return
    {
        Asset("ANIM", "anim/shadow_rook.zip"),
        Asset("ANIM", "anim/shadow_rook_upg_build.zip"),
		Asset("ANIM", "anim/shadow_bishop.zip"),
        Asset("ANIM", "anim/shadow_bishop_upg_build.zip"),
		Asset("ANIM", "anim/shadow_knight.zip"),
        Asset("ANIM", "anim/shadow_knight_upg_build.zip"),
    }
end

local bishopfxassets =
{
    Asset("ANIM", "anim/shadow_bishop_fx.zip"),
}

local brains =
{
    ["shadow_rook"] = require("brains/shadow_rookbrain"),
    ["shadow_knight"] = require("brains/shadow_knightbrain"),
    ["shadow_bishop"] = require("brains/shadow_bishopbrain"),
}

local PHYS_RADIUS =
{
    ["shadow_rook"] = 1.6,
    ["shadow_knight"] = .25,
    ["shadow_bishop"]  = .3,
}

--------------------------------------------------------------------------

local function lootsetfn(lootdropper)
    local loot = {}

    if lootdropper.inst.level >= 2 then
        for i = 1, math.random(2, 3) do
            table.insert(loot, "nightmarefuel")
        end

        if lootdropper.inst.level >= 3 then
            table.insert(loot, "shadowheart")
            table.insert(loot, "nightmarefuel")
            --TODO: replace with shadow equipment drops
            table.insert(loot, "armor_sanity")
            table.insert(loot, "nightsword")
        end
    end
	
	if lootdropper.inst.prefab == "shadow_mixtrues" then 
		table.insert(loot, "gestalt_report")
	end

    lootdropper:SetLoot(loot)
end

SetSharedLootTable("shadow_chesspiece",
{
    { "nightmarefuel",  1.0 },
    { "nightmarefuel",  0.5 },
})

--------------------------------------------------------------------------

local function retargetfn(inst)
    --retarget nearby players if current target is fleeing or not a player
    local target = inst.components.combat.target
    if target ~= nil then
        local dist = 8
        if target:HasTag("player") and inst:IsNear(target, dist) or not inst:IsNearPlayer(dist, true) then
            return
        end
        target = nil
    end

    local x, y, z = inst.Transform:GetWorldPosition()
    local players = FindPlayersInRange(x, y, z, TUNING.SHADOWCREATURE_TARGET_DIST, true)
    local rangesq = math.huge
    for i, v in ipairs(players) do
        local distsq = v:GetDistanceSqToPoint(x, y, z)
        if distsq < rangesq and inst.components.combat:CanTarget(v) then
            rangesq = distsq
            target = v
        end
    end
    return target, true
end

local function ShareTargetFn(dude)
    return dude:HasTag("shadowchesspiece") and not dude.components.health:IsDead()
end

local function OnAttacked(inst, data)
    inst.components.combat:SetTarget(data.attacker)
    inst.components.combat:ShareTarget(data.attacker, 30, ShareTargetFn, 1)
end

--------------------------------------------------------------------------

local function PushMusic(inst)
    if ThePlayer ~= nil and ThePlayer:IsNear(inst, 30) then
        ThePlayer:PushEvent("triggeredevent", { name = "shadow_mixtures" })
    end
end

local function OnMusicDirty(inst)
    --Dedicated server does not need to trigger music
    if not TheNet:IsDedicated() then
        if inst._music:value() then
            if inst._musictask == nil then
                inst._musictask = inst:DoPeriodicTask(1, PushMusic, 0)
            end
        elseif inst._musictask ~= nil then
            inst._musictask:Cancel()
            inst._musictask = nil
        end
    end
end

local function StartMusic(inst)
    if not (inst._music:value() or inst.components.health:IsDead()) then
        inst._music:set(true)
        OnMusicDirty(inst)
    end
end

local function StopMusic(inst)
    if inst._music:value() then
        inst._music:set(false)
        OnMusicDirty(inst)
    end
end

--------------------------------------------------------------------------

local function OnLevelUp(inst, data)
    if inst.level < 3 and
        data ~= nil and
        data.source ~= nil and
        data.source.prefab ~= inst.prefab and
        -- only level up if the source's level is equal or greater then this inst's level
        -- (test #inst.levelupsource because there may be some queued)
        data.source.level > #inst.levelupsource and
        not table.contains(inst.levelupsource, data.source.prefab) then
        table.insert(inst.levelupsource, data.source.prefab)
    end
end

local function WantsToLevelUp(inst)
    return inst.level < #inst.levelupsource + 1
end

local function nodmglevelingup(inst, amount, overtime, cause, ignore_invincible, afflicter, ignore_absorb)
    return WantsToLevelUp(inst) and amount <= 0 and not ignore_absorb
end

--------------------------------------------------------------------------

local MAX_LEVEL = 3

local function IsMaxLevel(inst)
    return inst.level == MAX_LEVEL
end

local function commonlevelup(inst, overridelevel)
    if inst.components.health:IsDead() then
        return
    end
    local level = math.min(overridelevel or (inst.level + 1), MAX_LEVEL)
    if level ~= inst.level then
        inst.level = level

        local tunings = TUNING[string.upper("shadow_rook")]
        local scale = tunings.LEVELUP_SCALE[level]

        local x, y, z = inst.Transform:GetWorldPosition()
        inst.Transform:SetScale(scale, scale, scale)
        inst.Physics:SetCapsule(PHYS_RADIUS["shadow_rook"] * scale, 1)
        inst.Physics:Teleport(x, y, z)

        inst.AnimState:SetMultColour(1, 1, 1, 0.5 + (0.12*(level-1)))

        inst.components.health:SetMaxHealth(tunings.HEALTH[level])
        
        if level > 1 then
            inst:AddTag("epic")
            inst:AddTag("noepicmusic")
            StartMusic(inst)
            inst.sounds.levelup = "dontstarve/sanity/transform/three"
        else
            inst:RemoveTag("epic")
            inst:RemoveTag("noepicmusic")
            StopMusic(inst)
            inst.sounds.levelup = "dontstarve/sanity/transform/two"
        end

        return level, scale
    end
end

local function rooklevelup(inst, overridelevel)
    local level, scale = commonlevelup(inst, overridelevel)
    if level ~= nil then
        inst.components.combat:SetDefaultDamage(TUNING.SHADOW_ROOK.DAMAGE[level])
        inst.components.combat:SetRange(TUNING.SHADOW_ROOK.ATTACK_RANGE * scale, TUNING.SHADOW_ROOK.HIT_RANGE * scale)
        inst.components.combat:SetAttackPeriod(TUNING.SHADOW_ROOK.ATTACK_PERIOD[level])

        if level > 1 then
            local suffix = tostring(level - 1)
            inst.AnimState:OverrideSymbol("base",           "shadow_rook_upg_build", "base"..suffix)
            inst.AnimState:OverrideSymbol("big_horn",       "shadow_rook_upg_build", "big_horn"..suffix)
            inst.AnimState:OverrideSymbol("bottom_head",    "shadow_rook_upg_build", "bottom_head"..suffix)
            inst.AnimState:OverrideSymbol("small_horn_lft", "shadow_rook_upg_build", "small_horn_lft"..suffix)
            inst.AnimState:OverrideSymbol("small_horn_rgt", "shadow_rook_upg_build", "small_horn_rgt"..suffix)
            inst.AnimState:OverrideSymbol("top_head",       "shadow_rook_upg_build", "top_head"..suffix)
        else
            inst.AnimState:ClearAllOverrideSymbols()
        end

        inst.sounds.attack = "dontstarve/sanity/rook/attack_"..tostring(level)
    end
end




--------------------------------------------------------------------------

local function onsave(inst, data)
    data.level = inst.level > 1 and inst.level or nil
    data.levelupsource = #inst.levelupsource > 0 and inst.levelupsource or nil
end

local function onpreload(inst, data)
    while #inst.levelupsource > 0 do
        table.remove(inst.levelupsource)
    end
    if data ~= nil then
        if data.levelupsource ~= nil then
            for i, v in ipairs(data.levelupsource) do
                table.insert(inst.levelupsource, v)
            end
        end
        if data.level ~= nil then
            inst:LevelUp(data.level)
        end
    end
end

--------------------------------------------------------------------------

local function OnEntityWake(inst)
    if inst._despawntask ~= nil then
        inst._despawntask:Cancel()
        inst._despawntask = nil
    end
end

local function OnDespawn(inst)
    inst._despawntask = nil
    if inst:IsAsleep() and not inst.components.health:IsDead() then
        inst:Remove()
    end
end

local function OnEntitySleep(inst)
    if inst._despawntask ~= nil then
        inst._despawntask:Cancel()
    end
    inst._despawntask = inst:DoTaskInTime(TUNING.SHADOW_CHESSPIECE_DESPAWN_TIME, OnDespawn)
end

--------------------------------------------------------------------------

 

local function commonfn(name, sixfaced)
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()

    MakeCharacterPhysics(inst, 10, PHYS_RADIUS[name])
    RemovePhysicsColliders(inst)
    inst.Physics:SetCollisionGroup(COLLISION.SANITY)
    --inst.Physics:CollidesWith(COLLISION.SANITY)
    inst.Physics:CollidesWith(COLLISION.WORLD)

    if sixfaced then
        inst.Transform:SetSixFaced()
    else
        inst.Transform:SetFourFaced()
    end

    inst:AddTag("monster")
    inst:AddTag("hostile")
    inst:AddTag("notraptrigger")
    inst:AddTag("shadowchesspiece")
	inst:AddTag("shadow")
	--inst:AddTag("NOCLICK")
	inst:AddTag("shadow_mixtrues")
	inst:AddTag("_named")

    inst.AnimState:SetBank(name)
    inst.AnimState:SetBuild(name)
    inst.AnimState:PlayAnimation("idle_loop")
    inst.AnimState:SetMultColour(1, 1, 1, .5)
    inst.AnimState:SetFinalOffset(1)

    inst._music = net_bool(inst.GUID, "shadowchesspiece._music", "musicdirty")

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        inst:ListenForEvent("musicdirty", OnMusicDirty)

        return inst
    end

    inst:AddComponent("locomotor") -- locomotor must be constructed before the stategraph

    inst:AddComponent("health")
    inst.components.health.nofadeout = true

    inst:AddComponent("combat")
    inst.components.combat:SetRetargetFunction(3, retargetfn)
    inst.components.health.redirect = nodmglevelingup

    inst:AddComponent("explosiveresist")

    inst:AddComponent("lootdropper")
    inst.components.lootdropper:SetChanceLootTable("shadow_chesspiece")
    inst.components.lootdropper:SetLootSetupFn(lootsetfn)

    inst:AddComponent("sanityaura")
	inst.components.sanityaura.aura = -TUNING.SANITYAURA_LARGE
    

    inst:AddComponent("epicscare")
    inst.components.epicscare:SetRange(TUNING.SHADOW_CHESSPIECE_EPICSCARE_RANGE)

    inst:ListenForEvent("attacked", OnAttacked)
    inst:ListenForEvent("death", StopMusic)
    inst:ListenForEvent("levelup", OnLevelUp)

    inst.OnSave = onsave
    inst.OnPreLoad = onpreload

    inst.WantsToLevelUp = WantsToLevelUp

    inst.OnEntityWake = OnEntityWake
    inst.OnEntitySleep = OnEntitySleep

    inst.level = 1
    inst.levelupsource = {}
    inst.sounds =
    {
        --common sounds
        death = "dontstarve/sanity/death_pop",
        levelup = "dontstarve/sanity/transform/two",
    }

    inst:SetStateGraph("SGshadow_mixtures")
    inst:SetBrain(brains[name])

    return inst
end

local function EquipWeapon(inst)
    if inst and inst:IsValid() and inst.components.inventory and not inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS) then
        local weapon = CreateEntity()
        --[[Non-networked entity]]
        weapon.entity:AddTransform()
        weapon:AddComponent("weapon")
        weapon.components.weapon:SetDamage(inst.components.combat.defaultdamage)
        weapon.components.weapon:SetRange(inst.components.combat.attackrange, inst.components.combat.attackrange+4)
        weapon.components.weapon:SetProjectile("blossom_projectile_dark_icey")
        weapon:AddComponent("inventoryitem")
        weapon.persists = false
        weapon.components.inventoryitem:SetOnDroppedFn(weapon.Remove)
        weapon:AddComponent("equippable")
        
        inst.components.inventory:Equip(weapon)
    end
end

local function InitChilds(inst,isfullhealth)
	local level = 3
	local suffix = tostring(level - 1)
	
	if inst.knight and inst.knight:IsValid() then 
		inst.knight:AddTag("_named")
		inst.knight:AddTag("shadow")
		inst.knight.Transform:SetPosition(0,1,0) 
		inst.knight.Transform:SetRotation(0)
		inst.knight.rook = inst
		inst.knight:SetPrefabNameOverride("shadow_mixtrues")
		
		--[[if not inst.knight.components.inspectable then 
			inst.knight:AddComponent("inspectable")
		end 
		inst.knight.components.inspectable.nameoverride = "shadow_mixtrues"--]]
	end 
	
	if inst.horse then 
		inst.horse.level = level
		inst.horse:AddTag("_named")
		inst.horse:AddTag("shadow")
		inst.horse:SetPrefabNameOverride("shadow_mixtrues")
		--[[if not inst.horse.components.inspectable then 
			inst.horse:AddComponent("inspectable")
		end 
		inst.horse.components.inspectable.nameoverride = "shadow_mixtrues"--]]
		if not inst.horse.components.named then 
			inst.horse:AddComponent("named")
			inst.horse.components.named:SetName("噩梦融合体")
		end 
		if isfullhealth then 
			inst.horse.components.locomotor.walkspeed = TUNING.SHADOW_KNIGHT.SPEED[2]
			inst.horse.components.health:SetMaxHealth(TUNING.SHADOW_KNIGHT.HEALTH[3])
			inst.horse.components.combat:SetDefaultDamage(TUNING.SHADOW_KNIGHT.DAMAGE[2])
			inst.horse.components.combat:SetAttackPeriod(TUNING.SHADOW_KNIGHT.ATTACK_PERIOD[2])
			inst.horse.components.combat:SetRange(TUNING.SHADOW_KNIGHT.ATTACK_RANGE, TUNING.SHADOW_KNIGHT.ATTACK_RANGE_LONG)
			inst:AddTag("_named")
		end 
		inst.horse.AnimState:OverrideSymbol("arm",       "shadow_knight_upg_build", "arm"..suffix)
		inst.horse.AnimState:OverrideSymbol("ear",       "shadow_knight_upg_build", "ear"..suffix)
		inst.horse.AnimState:OverrideSymbol("face",      "shadow_knight_upg_build", "face"..suffix)
		inst.horse.AnimState:OverrideSymbol("head",      "shadow_knight_upg_build", "head"..suffix)
		inst.horse.AnimState:OverrideSymbol("leg_low",   "shadow_knight_upg_build", "leg_low"..suffix)
		inst.horse.AnimState:OverrideSymbol("neck",      "shadow_knight_upg_build", "neck"..suffix)
		inst.horse.AnimState:OverrideSymbol("spring",    "shadow_knight_upg_build", "spring"..suffix)
		inst.horse.AnimState:Hide("leg_low")
		inst.horse.AnimState:OverrideSymbol("arm", "swap_alex_blade", "swap_alex_blade")
	
		inst.horse.Transform:SetPosition(2,2,1) 
		inst.horse.Transform:SetRotation(0)
		inst.horse.rook = inst
		inst.horse.AnimState:SetMultColour(0,0,0,1)
		--inst.horse:AddTag("NOCLICK")
	end 
	
	if inst.bishop then 
		inst.bishop:AddTag("_named")
		inst.bishop:AddTag("shadow")
		inst.bishop:SetPrefabNameOverride("shadow_mixtrues")
		--[[if not inst.bishop.components.inventory then 
			inst.bishop:AddComponent("inventory")
		end --]]
		--[[if not inst.bishop.components.inspectable then 
			inst.bishop:AddComponent("inspectable")
		end 
		inst.bishop.components.inspectable.nameoverride = "shadow_mixtrues"--]]
		if not inst.bishop.components.named then 
			inst.bishop:AddComponent("named")
			inst.bishop.components.named:SetName("噩梦融合体")
		end 
		inst.bishop.level = level
		if isfullhealth then 
			inst.bishop.components.locomotor.walkspeed = TUNING.SHADOW_BISHOP.SPEED
			inst.bishop.components.health:SetMaxHealth(TUNING.SHADOW_BISHOP.HEALTH[3])
			inst.bishop.components.combat:SetDefaultDamage(TUNING.SHADOW_BISHOP.DAMAGE[2])
			inst.bishop.components.combat:SetAttackPeriod(math.random(3,10))
			inst.bishop.components.combat:SetRange(10,10)
			inst.bishop:SetStateGraph("SGmy_shadow_bishop")
		end 
	
		inst.bishop.AnimState:OverrideSymbol("body_mid",           "shadow_bishop_upg_build", "body_mid"..suffix)
		inst.bishop.AnimState:OverrideSymbol("body_upper",         "shadow_bishop_upg_build", "body_upper"..suffix)
		inst.bishop.AnimState:OverrideSymbol("head",               "shadow_bishop_upg_build", "head"..suffix)
		inst.bishop.AnimState:OverrideSymbol("sharp_feather_a",    "shadow_bishop_upg_build", "sharp_feather_a"..suffix)
		inst.bishop.AnimState:OverrideSymbol("sharp_feather_b",    "shadow_bishop_upg_build", "sharp_feather_b"..suffix)
		inst.bishop.AnimState:OverrideSymbol("wing",               "shadow_bishop_upg_build", "wing"..suffix)
		inst.bishop.AnimState:OverrideSymbol("body_mid", "swap_alex_blade", "swap_alex_blade")
		--inst.bishop.AnimState:OverrideSymbol("wing", "swap_alex_blade", "swap_alex_blade")
	
		inst.bishop.Transform:SetPosition(-2,2,1) 
		inst.bishop.Transform:SetRotation(0)
		inst.bishop.rook = inst
		inst.bishop.AnimState:SetMultColour(0,0,0,1)	
		--inst.bishop:AddTag("NOCLICK")
		
		--inst.bishop:DoTaskInTime(1,function()EquipWeapon(inst.bishop)end)
	
		
	end 
end 

local function AddChilds(inst)
	if not inst.knight then 
		inst.knight = SpawnPrefab("webber_deathknight")
		inst:AddChild(inst.knight)
	end       
	if not inst.horse then 
		inst.horse = SpawnPrefab("shadow_knight")
		inst:AddChild(inst.horse)   
		inst.horse:SetBrain(require "brains/deathknightbrain")
	end  
	if not inst.bishop then 
		inst.bishop = SpawnPrefab("shadow_bishop")
		inst:AddChild(inst.bishop)  
		inst.bishop:SetBrain(require "brains/deathknightbrain")
	end 
	InitChilds(inst,true)
end 

local function OnFinishDisappear(inst)
	inst:Hide()
	--inst:RemoveEventCallback("animover",OnFinishDisappear)
end 

local function OnStartDisappear(inst,isremove)
	inst.components.health:SetInvincible(true)
	inst.Transform:SetFourFaced()
	inst.AnimState:SetBank("shadow_rook") 
	inst.AnimState:SetBuild("shadow_rook")
    inst.AnimState:PlayAnimation("teleport",false)
	--inst.Transform:SetPosition(0,5,0)
	inst.Transform:SetScale(0.5,0.5,0.5)
	if isremove then 
		if not inst.components.health:IsDead() then 
			inst:ListenForEvent("animover",inst.Remove)
		end 
	else 
		inst:DoTaskInTime(0.3,OnFinishDisappear)
	end
end 

local function OnChildShow(inst)
	inst.components.health:SetInvincible(false)
	inst:Show()
	inst.Transform:SetScale(1,1,1)
	inst.Transform:SetFourFaced()
	inst.AnimState:SetBank(inst.prefab)
	inst.AnimState:SetBuild(inst.prefab)
	local target = inst.rook.components.combat.target or inst.components.combat.target or FindEntity(inst, 10, function() return true end, { "player" }, { "INLIMBO" }) or nil 
	if target and inst.prefab ~= "shadow_bishop" then 
		inst.sg:GoToState("attack",target)
	else 
		inst.sg:GoToState("taunt")
	end 
	
	inst.shield = SpawnPrefab("icey_shield")
	inst.shield.entity:SetParent(inst.entity)         
	inst.shield.Transform:SetPosition(0,2,0) 
	inst.shield.AnimState:SetMultColour(0,0,0,0.8)
	inst.shield.Transform:SetScale(1.3,1.3,1.3)  
	
	local fxs = SpawnPrefab("shadow_bishop_fx")
	fxs.Transform:SetPosition(inst.Transform:GetWorldPosition())
	
end 

local function OnChildDeath(child)
	local rook = child.rook
	local name = child.prefab
	if rook then 
		if name == "webber_deathknight" then 
			rook.knight = nil 
			rook:DoTaskInTime(0.3,function()
				if not rook.InDespawn then 
					rook.components.health:Kill()
				end 
			end)
		elseif name == "shadow_knight" then 
			rook.horse = nil 
		elseif name == "shadow_bishop" then 
			rook.bishop = nil 
		end
	end
end 

local function OnKill(inst,data)
	local victim = data.victim
	if victim and not victim:HasTag("maxture_chaos") and not victim:HasTag("epic") and not victim:HasTag("player") then 
		local name = victim.prefab
		local x,y,z = victim.Transform:GetWorldPosition()
		inst:DoTaskInTime(2,function()
			local prefab = SpawnPrefab(name)
			if prefab then 
				SpawnPrefab("statue_transition").Transform:SetPosition(x,y,z)
				SpawnPrefab("statue_transition_2").Transform:SetPosition(x,y,z)
				prefab.Transform:SetPosition(x,y,z)
				if prefab.AnimState then 
					prefab.AnimState:SetMultColour(0,0,0,0.8)
				end
				if prefab.components.lootdropper then
					local self = prefab.components.lootdropper --------------------鍘熸湰鎺夎惤鐗╁叏缁欐垜娓呭共鍑€锛?
					self.numrandomloot = nil
					self.randomloot = nil
					self.chancerandomloot = nil
					self.totalrandomweight = nil
					self.chanceloot = nil
					self.ifnotchanceloot = nil
					self.droppingchanceloot = false
					self.loot = nil
					self.chanceloottable = nil
					--self:SetChanceLootTable('undeads')
				end 
				--prefab.components.health:SetMaxHealth(1)
				prefab.persists = false
				prefab:AddTag("maxture_chaos")
				prefab.components.combat:SetRetargetFunction(3, retargetfn)
			end 
		end)
	end 
end 

local function ListenForAllChild(inst)
	
	inst:ListenForEvent("newcombattarget",function(inst,data)
		if inst.knight and inst.knight.components.combat and not inst.knight.components.health:IsDead()  then
			inst.knight.components.combat:SetTarget(data.target)
		end
		if inst.horse and inst.horse.components.combat and not inst.horse.components.health:IsDead()  then
			inst.horse.components.combat:SetTarget(data.target)
		end
		if inst.bishop and inst.bishop.components.combat and not inst.bishop.components.health:IsDead()  then
			inst.bishop.components.combat:SetTarget(data.target)
		end
	end)
	
	inst:ListenForEvent("death",function()
		if inst.knight and not inst.knight.components.health:IsDead() then 
			inst.knight.OnDisAppear(inst.knight,true) 
		end 
		if inst.horse and not inst.horse.components.health:IsDead() then 
			--inst.knight.OnDisAppear(inst.knight,true) 
			inst.horse.components.health:Kill()
		end 
		if inst.bishop and not inst.bishop.components.health:IsDead() then 
			--inst.knight.OnDisAppear(inst.knight,true) 
			inst.bishop.components.health:Kill()
		end 
	end)
	inst:ListenForEvent("despawn",function()
		inst.InDespawn = true 
		if inst.knight and not inst.knight.components.health:IsDead() then 
			inst.knight.OnDisAppear(inst.knight,true) 
		end 
		if inst.horse and not inst.horse.components.health:IsDead() then 
			inst.horse:PushEvent("despawn")
		end 
		if inst.bishop and not inst.bishop.components.health:IsDead() then 
			inst.bishop:PushEvent("despawn")
		end 
	end)
	inst:ListenForEvent("mixture_diasppear",function(inst,data)
		if inst.knight then 
			inst.knight:OnDisAppear()
		end
		if inst.horse then 
			OnStartDisappear(inst.horse)
		end
		if inst.bishop then 
			OnStartDisappear(inst.bishop)
		end
	end)
	inst:ListenForEvent("mixture_show",function(inst,data)
		if inst.knight then
			inst.knight:OnShow()
		end
		if inst.horse then 
			OnChildShow(inst.horse)
		end
		if inst.bishop then 
			OnChildShow(inst.bishop)
		end
		InitChilds(inst)
	end)
	
	inst:ListenForEvent("death",OnChildDeath,inst.knight)
	inst:ListenForEvent("death",OnChildDeath,inst.horse)
	inst:ListenForEvent("death",OnChildDeath,inst.bishop)
	--inst:ListenForEvent("killed",OnKill)
	--inst:ListenForEvent("killed",OnKill,inst.knight)
	--inst:ListenForEvent("killed",OnKill,inst.horse)
	--inst:ListenForEvent("killed",OnKill,inst.bishop)
	inst:ListenForEvent("onremove",OnChildDeath,inst.knight)
	inst:ListenForEvent("onremove",OnChildDeath,inst.horse)
	inst:ListenForEvent("onremove",OnChildDeath,inst.bishop)
end 

local function OnMixtureDeath(inst)
	local moonbase = FindEntity(inst, 10000, function(base) return base.prefab == "moonbase" end)
	if moonbase and moonbase:IsValid() and moonbase.components.moon_giaour_spawner then 
		moonbase.components.moon_giaour_spawner:SpawnMinions()
	end
end 

local function rookfn()
    local inst = commonfn("shadow_rook")
	

    if not TheWorld.ismastersim then
        return inst
    end

	--[[inst:AddComponent("named")
	inst.components.named:SetName("缂佷胶鍋熷▓鎴炵閸偆鐟㈠☉鏂款儓閻?)--]]
	
	AddChilds(inst)
	ListenForAllChild(inst)
	
	inst.AnimState:SetMultColour(0,0,0,1)	
	inst.Transform:SetScale(1.3,1.3,1.3)
	
	inst.AnimState:OverrideSymbol("base",           "shadow_rook_upg_build", "base2")
    inst.AnimState:OverrideSymbol("big_horn",       "shadow_rook_upg_build", "big_horn2")
	inst.AnimState:OverrideSymbol("bottom_head",    "shadow_rook_upg_build", "bottom_head2")
    inst.AnimState:OverrideSymbol("small_horn_lft", "shadow_rook_upg_build", "small_horn_lft2")
    inst.AnimState:OverrideSymbol("small_horn_rgt", "shadow_rook_upg_build", "small_horn_rgt2")
    inst.AnimState:OverrideSymbol("top_head",       "shadow_rook_upg_build", "top_head2") 
	--inst.AnimState:OverrideSymbol("big_horn", "swap_alex_blade", "swap_alex_blade")
	
	
	--[[inst.fire = SpawnPrefab("torchfire_shadow")
	--inst.fire.Transform:SetScale(0.3,0.3,0.3)
    inst.fire.entity:AddFollower()
    inst.fire.Follower:FollowSymbol(inst.GUID, "top_head", 0, -300, 0)--]]
	
    inst.components.locomotor.walkspeed = TUNING.SHADOW_ROOK.SPEED
    inst.components.health:SetMaxHealth(TUNING.SHADOW_ROOK.HEALTH[3])
    inst.components.combat:SetDefaultDamage(TUNING.SHADOW_ROOK.DAMAGE[3])
    inst.components.combat:SetAttackPeriod(TUNING.SHADOW_ROOK.ATTACK_PERIOD[3])
    inst.components.combat:SetRange(TUNING.SHADOW_ROOK.ATTACK_RANGE, TUNING.SHADOW_ROOK.HIT_RANGE)

    inst.sounds.attack = "dontstarve/sanity/rook/attack_1"
    inst.sounds.attack_grunt = "dontstarve/sanity/rook/attack_grunt"
    inst.sounds.die = "dontstarve/sanity/rook/die"
    inst.sounds.idle = "dontstarve/sanity/rook/idle"
    inst.sounds.taunt = "dontstarve/sanity/rook/taunt"
    inst.sounds.disappear = "dontstarve/sanity/rook/dissappear"
    inst.sounds.hit = "dontstarve/sanity/rook/hit_response"
    inst.sounds.teleport = "dontstarve/sanity/rook/teleport"
	
	
	 
    inst.LevelUp = rooklevelup
	
	inst:ListenForEvent("death",OnMixtureDeath)
	
	inst.level = 3
	inst:AddTag("epic")
    inst:AddTag("noepicmusic")
    StartMusic(inst)
	

    return inst
end

STRINGS.NAMES.SHADOW_MIXTRUES = "噩梦融合体"

return Prefab("shadow_mixtrues", rookfn, createassets("shadow_rook"), createprefabs({ --[["shadow_lance"]] }))
