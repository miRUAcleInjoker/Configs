local TadalinUtil = require("tadalin_util")

require("stategraphs/commonstates")

local actionhandlers = 
{
}


local events=
{
    
    
    EventHandler("attacked", function(inst,data) 
	end),
    EventHandler("doattack", function(inst) 
        if not inst.components.health:IsDead() and not inst.sg:HasStateTag("busy") then 
			inst.sg:GoToState("attack") 
        end 
    end),
    EventHandler("death", function(inst) inst.sg:GoToState("death") end),
    CommonHandlers.OnLocomote(false,true),
}

local function ShakeIfClose(inst)
    ShakeAllCameras(CAMERASHAKE.FULL, .5, .02, .2, inst, 30)
end

local function ShakePound(inst)
	inst.SoundEmitter:PlaySound("dontstarve/creatures/deerclops/bodyfall_dirt")
    ShakeAllCameras(CAMERASHAKE.FULL, 1.2, .03, .7, inst, 30)
end

local function ShakeRoar(inst)
    ShakeAllCameras(CAMERASHAKE.FULL, 0.8, .03, .5, inst, 30)
end

local function setfires(x,y,z, rad)
    for i, v in ipairs(TheSim:FindEntities(x, 0, z, rad, nil, { "laser", "DECOR", "INLIMBO","player","tadalin" })) do 
        if v.components.burnable and TadalinUtil.CanAttack(v)  then
            v.components.burnable:Ignite()
        end
    end
end
local function DoDamage(inst,pos,rad,damage)
    local targets = {}
	pos = pos or inst:GetPosition()
	damage = damage or 35
    local x, y, z = pos:Get()
  
    setfires(x,y,z, rad)
    for i, v in ipairs(TheSim:FindEntities(x, 0, z, rad, nil, { "laser", "DECOR", "INLIMBO" , "tadalin" })) do  --  { "_combat", "pickable", "campfire", "CHOP_workable", "HAMMER_workable", "MINE_workable", "DIG_workable" }
		if TadalinUtil.CanAttack(v) then 
			if not targets[v] and v:IsValid() and not v:IsInLimbo() and not (v.components.health ~= nil and v.components.health:IsDead()) and not v:HasTag("laser_immune") then            
				local vradius = 0
				if v.Physics then
					vradius = v.Physics:GetRadius()
				end

				local range = rad + vradius
				if v:GetDistanceSqToPoint(Vector3(x, y, z)) < range * range then
					local isworkable = false
					if v.components.workable ~= nil then
						local work_action = v.components.workable:GetWorkAction()
						--V2C: nil action for campfires
						isworkable =
							(   work_action == nil and v:HasTag("campfire")    ) or
							
								(   work_action == ACTIONS.CHOP or
									work_action == ACTIONS.HAMMER or
									work_action == ACTIONS.MINE or   
									work_action == ACTIONS.DIG
								)
					end
					if isworkable then
						targets[v] = true
						v:DoTaskInTime(0.6, function() 
							if v.components.workable then
								v.components.workable:Destroy(inst) 
								local vx,vy,vz = v.Transform:GetWorldPosition()
								v:DoTaskInTime(0.3, function() setfires(vx,vy,vz,1) end)
							end
						 end)
						if v:IsValid() and v:HasTag("stump") then
						   -- v:Remove()
						end
					elseif v.components.pickable ~= nil
						and v.components.pickable:CanBePicked()
						and not v:HasTag("intense") then
						targets[v] = true
						local num = v.components.pickable.numtoharvest or 1
						local product = v.components.pickable.product
						local x1, y1, z1 = v.Transform:GetWorldPosition()
						v.components.pickable:Pick(inst) -- only calling this to trigger callbacks on the object
						if product ~= nil and num > 0 then
							for i = 1, num do
								local loot = SpawnPrefab(product)
								loot.Transform:SetPosition(x1, 0, z1)
								targets[loot] = true
							end
						end

					elseif v.components.health and v.components.combat then                    
						--inst.components.combat:DoAttack(v)   
						v.components.combat:GetAttacked(inst,damage)             
						if v:IsValid() then
							if not v.components.health or not v.components.health:IsDead() then
								if v.components.freezable ~= nil then
									if v.components.freezable:IsFrozen() then
										v.components.freezable:Unfreeze()
									elseif v.components.freezable.coldness > 0 then
										v.components.freezable:AddColdness(-2)
									end
								end
								if v.components.temperature ~= nil then
									local maxtemp = math.min(v.components.temperature:GetMax(), 10)
									local curtemp = v.components.temperature:GetCurrent()
									if maxtemp > curtemp then
										v.components.temperature:DoDelta(math.min(10, maxtemp - curtemp))
									end
								end
							end
						end                   
					end
					if v:IsValid() and v.AnimState then
						SpawnPrefab("deerclops_laserhit"):SetTarget(v)
					end
				end
			end
		end
    end
end

local function SetLightRadius(inst, radius)
    inst.Light:SetRadius(radius)
end

local function DisableLight(inst)
    inst.Light:Enable(false)
end

local function DoAnim(inst)
	local x, y, z = inst.Transform:GetWorldPosition()
	if inst.AnimState ~= nil then
        inst.AnimState:PlayAnimation("hit_"..tostring(math.random(5)))
        inst:Show()
        inst:DoTaskInTime(inst.AnimState:GetCurrentAnimationLength() + 2 * FRAMES, inst.Remove)

        inst.Light:Enable(true)
        inst:DoTaskInTime(4 * FRAMES, SetLightRadius, .5)
        inst:DoTaskInTime(5 * FRAMES, DisableLight)

        SpawnPrefab("deerclops_laserscorch").Transform:SetPosition(x, 0, z)
        local fx = SpawnPrefab("deerclops_lasertrail")
        fx.Transform:SetPosition(x, 0, z)
        fx:FastForward(GetRandomMinMax(.3, .7))
    else
        inst:DoTaskInTime(2 * FRAMES, inst.Remove)
    end
end 



local states=
{
	State
    {
        name = "attack",
        tags = { "attack", "busy" },

        onenter = function(inst, target)
            if inst.components.locomotor ~= nil then
                inst.components.locomotor:StopMoving()
            end
            inst.AnimState:PlayAnimation("atk_pre")
			inst.AnimState:PushAnimation("atk_loop",false)
			inst.AnimState:PushAnimation("atk_pst",false)
            inst.components.combat:StartAttack()

            --V2C: Cached to force the target to be the same one later in the timeline
            --     e.g. combat:DoAttack(inst.sg.statemem.target)
            inst.sg.statemem.target = target
        end,

        timeline = {
			TimeEvent(25*FRAMES, function(inst)
				inst.components.combat:DoAreaAttack(inst,6) 
				local ring = SpawnPrefab("laser_ring")
				ring.Transform:SetPosition(inst.Transform:GetWorldPosition())
				ring.Transform:SetScale(1.1, 1.1, 1.1)
				DoDamage(inst,inst:GetPosition(),6,10)
			end)
		},

        events =
        {
            EventHandler("animqueueover", function(inst)
				if inst.AnimState:AnimDone() then
					inst.sg:GoToState("idle")
				end
			end),
        },
    },
	
	State
    {
        name = "death",
        tags = { "death", "busy" },

        onenter = function(inst)
            inst.AnimState:PlayAnimation("death",false)
        end,

        timeline = {
			
		},
    },
	
	State
    {
        name = "walk_start",
        tags = { "moving", "canrotate" },

        onenter = function(inst)
            --inst.components.locomotor:WalkForward()
            --inst.AnimState:PlayAnimation("walk_pre")
			--inst.AnimState:PushAnimation("idle",false)
        end,

        timeline = {
			--TimeEvent(0*FRAMES, ShakeIfClose),
			TimeEvent(1*FRAMES, function(inst)
				inst.sg:GoToState("walk")
			end),
		},
    },
	
	
	State
    {
        name = "walk",
        tags = { "moving", "canrotate" },

        onenter = function(inst)
            inst.components.locomotor:WalkForward()
            inst.AnimState:PushAnimation("idle",false)
            inst.sg:SetTimeout(inst.AnimState:GetCurrentAnimationLength())
        end,

        timeline = {
			
		},

        ontimeout = function(inst)
			inst.sg:GoToState("walk")
			--inst.Physics:Stop()
		end,
    },
	
	State
    {
        name = "walk_stop",
        tags = { "canrotate" },

        onenter = function(inst)
            inst.components.locomotor:StopMoving()
            inst.AnimState:PushAnimation("idle",false)
        end,

        --timeline = timelines ~= nil and timelines.endtimeline or nil,

        events =
        {
            EventHandler("animqueueover", function(inst)
				if inst.AnimState:AnimDone() then
					inst.sg:GoToState("idle")
				end
			end),
        },
    },
    
}

CommonStates.AddIdle(states,nil,"idle",{
	--[[TimeEvent(2*FRAMES, function(inst) 
        inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/enemy/metal_robot/electro",nil,0.5)
    end),--]]
})




return StateGraph("SGdeath_legion", states, events, "idle", actionhandlers)

