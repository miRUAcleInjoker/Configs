local IceyUtil = require("icey_util")

local RESISTANCES =
{
    "_combat",
    "explosive",
    "quakedebris",
    "caveindebris",
    "trapdamage",
}

local function onequip(inst,owner)	
	if not inst.components.fueled:IsEmpty() then
		for i, v in ipairs(RESISTANCES) do
			inst.components.resistance:AddResistance(v)
		end
	end 
end 

local function onunequip(inst,owner)
	for i, v in ipairs(RESISTANCES) do
        inst.components.resistance:RemoveResistance(v)
    end
end 

local function clientfn(inst)
	inst.Transform:SetScale(1.4,1.4,1.4)
end 

local function ShouldResistFn(inst)
	if not inst.components.equippable:IsEquipped() then
        return false
    end
	local owner = inst.components.inventoryitem.owner
	
	return inst.components.fueled:GetPercent() >= 0.33
	
end 

local function OnResistDamage(inst)
	inst.components.fueled:DoDelta(-100)
	inst.SoundEmitter:PlaySound("dontstarve/characters/woodie/moose/hurt")
	local fx = SpawnAt(math.random() <= 0.5 and "weremoose_transform_fx" or "weremoose_transform2_fx",inst:GetPosition())
	fx.Transform:SetScale(0.75,0.75,0.75)
	--fx.AnimState:SetAddColour(1,1,1,0.8)
end 



local function OnFuelChange(inst,data)
	local percent = data.percent
	if percent >= 0.33 then 
		for i, v in ipairs(RESISTANCES) do
			inst.components.resistance:AddResistance(v)
		end
	else
		for i, v in ipairs(RESISTANCES) do
			inst.components.resistance:RemoveResistance(v)
		end
	end
	
	if percent >= 1 then 
		inst:AddTag("hat_icey_chicken_full")
	else
		inst:RemoveTag("hat_icey_chicken_full")
	end
end 

local function serverfn(inst)
	if not TheWorld.ismastersim then
		return inst
	end	 
	
	inst:AddComponent("chosenicey")
	
	inst:AddComponent("resistance")
    inst.components.resistance:SetShouldResistFn(ShouldResistFn)
    inst.components.resistance:SetOnResistDamageFn(OnResistDamage)
	
	inst:AddComponent("fueled")
    inst.components.fueled:InitializeFuelLevel(300)
    inst.components.fueled.accepting = false
	
	inst:DoPeriodicTask(6,function()
		inst.components.fueled:DoDelta(100)
	end)
	
	inst:ListenForEvent("percentusedchange",OnFuelChange)
end 


local DATA = {
	prefabname = "hat_icey_chicken",
	--assets = assets,
	tags = {"hat_icey_chicken"},
	bank = "hat_icey_chicken",
	build = "hat_icey_chicken",
	anim = "idle",
	--swapanims = {"swap_cursed_blade","swap_cursed_blade"},
	onequip = onequip,
	onunequip = onunequip,
	clientfn = clientfn,
	serverfn = serverfn,
}

return IceyUtil.CreateNormalHat(DATA)