local IceyUtil = require("icey_util")

local assets =
{
    Asset("ANIM", "anim/icey_hunter_clothing1.zip"),
	Asset("ANIM", "anim/swap_icey_hunter_clothing1.zip"),
	Asset("IMAGE","images/inventoryimages/icey_hunter_clothing1.tex"),
	Asset("ATLAS","images/inventoryimages/icey_hunter_clothing1.xml"),
}



local function onequip(inst, owner)
    owner.AnimState:OverrideSymbol("arm_lower","swap_icey_hunter_clothing1","arm_lower")
	owner.AnimState:OverrideSymbol("arm_upper","swap_icey_hunter_clothing1","arm_upper")
	owner.AnimState:OverrideSymbol("torso","swap_icey_hunter_clothing1","torso")
end

local function onunequip(inst, owner) 
	owner.AnimState:ClearOverrideSymbol("arm_lower")
	owner.AnimState:ClearOverrideSymbol("arm_upper")
	owner.AnimState:ClearOverrideSymbol("torso")
	IceyUtil.ReloadSkin(owner)
end

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()

    MakeInventoryPhysics(inst)

    inst.AnimState:SetBank("icey_hunter_clothing1")
    inst.AnimState:SetBuild("icey_hunter_clothing1")
    inst.AnimState:PlayAnimation("idle")

    --inst.foleysound = "dontstarve/movement/foley/logarmour"

    --MakeInventoryFloatable(inst, "small", 0.2, 0.80)
	
	inst:AddTag("hide_percentage")

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst:AddComponent("inspectable")

    inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "icey_hunter_clothing1"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/icey_hunter_clothing1.xml"
	
    inst:AddComponent("armor")
    inst.components.armor:InitIndestructible(0.2)

    inst:AddComponent("equippable")
    inst.components.equippable.equipslot = EQUIPSLOTS.BODY
    inst.components.equippable:SetOnEquip(onequip)
    inst.components.equippable:SetOnUnequip(onunequip)
	inst.components.equippable.stamina_recoverrate = 1.10
	inst.components.equippable.stamina_consumerate = 0.85

    MakeHauntableLaunch(inst)

    return inst
end

return Prefab("icey_hunter_clothing1", fn, assets)
