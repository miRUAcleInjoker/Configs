local IceyUtil = require("icey_util")

local assets =
{
    --Asset("ANIM", "anim/spear.zip"),
    --Asset("ANIM", "anim/swap_spear.zip"),
	--Asset("ANIM", "anim/sword_buster.zip"),
    Asset("ANIM", "anim/swap_storm_controlor.zip"),
	Asset("IMAGE","images/inventoryimages/storm_controlor.tex"),
	Asset("ATLAS","images/inventoryimages/storm_controlor.xml"),
	
}

local prefabs =
{
    "weaponsparks",
    "sunderarmordebuff",
    "superjump_fx",
    "reticulearc",
    "reticulearcping",
}

local hitrange = 0.5 

local function clearFxs(inst)
	for k,v in pairs(inst.storm_fxs) do 
		if v and v:IsValid() then 
			v:Remove()
		end
	end
	inst.storm_fxs = {} 
end 

local function addFxs(inst,owner,num)
	owner = owner or inst.components.inventoryitem:GetGrandOwner()
	if owner and owner:IsValid() then 
		for i = 1,num do 
			local fx = SpawnPrefab("storm_controlor_stormfx")
			fx.entity:SetParent(owner.entity)
			fx.entity:AddFollower()
			fx.Follower:FollowSymbol(owner.GUID, "swap_object", 0,-50-90*(#inst.storm_fxs), 0)
			table.insert(inst.storm_fxs,fx) 
		end
	else
		clearFxs(inst)
	end 
end 

local function CheckFxs(inst,owner)
	clearFxs(inst)
	if inst.StormLevel > 0 then 
		if not inst.SoundEmitter:PlayingSound("spinLoop") then 
			inst.SoundEmitter:PlaySound("dontstarve_DLC001/common/tornado", "spinLoop")
		end
		inst:AddTag("storm_controlor")
		addFxs(inst,owner,inst.StormLevel)
	else
		inst.SoundEmitter:KillSound("spinLoop")
		inst:RemoveTag("storm_controlor")
	end
end 

local function KillFXs(inst)
	clearFxs(inst)
	inst.SoundEmitter:KillSound("spinLoop")
end 

local function onequip(inst, owner)
    owner.AnimState:OverrideSymbol("swap_object", "swap_storm_controlor", "swap_storm_controlor")
    owner.AnimState:Show("ARM_carry")
    owner.AnimState:Hide("ARM_normal")
	CheckFxs(inst,owner)
end

local function onunequip(inst, owner)
    owner.AnimState:Hide("ARM_carry")
    owner.AnimState:Show("ARM_normal")
	KillFXs(inst,owner)
end

local function OnStormLevelChange(inst)
	inst.components.weapon:SetRange(0.5 + inst.StormLevel * 8,hitrange)
	print("OnStormLevelChange:",inst.StormLevel)
	CheckFxs(inst)
end 

local function StormLevelDelta(inst,delta)
	inst.StormLevel = inst.StormLevel + delta 
	inst.StormLevel = math.max(inst.StormLevel,0)
	inst.StormLevel = math.min(inst.StormLevel,3)
	OnStormLevelChange(inst)
end 

local function SetStormLevel(inst,set)
	StormLevelDelta(inst,set - inst.StormLevel)
end 

local function OnSpell(inst,target,pos)
	local owner = inst.components.inventoryitem:GetGrandOwner()
	if owner and owner:HasTag("player") and owner:IsValid() then 
		StormLevelDelta(inst,1)
	end
end 

local function StormAttack(inst,doer,target)
	if target and target:IsValid() then 
		print(inst,target,"StormAttack!")
		local owner = inst.components.inventoryitem:GetGrandOwner()
		if owner and owner:IsValid() and owner:HasTag("player") and target and target:IsValid() then 
			
			local ownerpos = owner:GetPosition()
			local targetpos = target:GetPosition()
			local deltapos = targetpos - ownerpos
			local one_deltapos = deltapos / deltapos:Length()
			local nums = inst.StormLevel * 9
			
			inst:StartThread(function()
				local startscale = 0.25 + inst.StormLevel * 0.15
				local finalscale = 0.75 + inst.StormLevel * 0.15
				for i = 1,nums do 
					local spawnpos = ownerpos + one_deltapos * i 
					local x,y,z = spawnpos:Get()
					local storm = SpawnPrefab("deer_ice_fx")
					local crackfx = SpawnPrefab("lavaarena_groundliftrocks")
					local nowscale = startscale + (finalscale - startscale) * i /nums
					crackfx.Transform:SetPosition(x,y,z)
					storm.Transform:SetPosition(x,y,z)
					storm.Transform:SetScale(nowscale,nowscale,nowscale)
					storm:KillFX()
					storm.SoundEmitter:PlaySound("dontstarve/common/destroy_smoke")
					--storm:DoTaskInTime(0,storm.KillFX)
					--storm.AnimState:SetMultColour(133/255, 135/255, 133/255,0.5)
					local ents = TheSim:FindEntities(x,y,z,2.5,{"_combat"},TUNING.ICEY_NO_TAGS)
					for k,v in pairs(ents) do 
						if IceyUtil.CanAttack(v,inst) then 
							local damage = 40 * inst.StormLevel 
							if v:HasTag("giant") then 
								damage = 10000 * inst.StormLevel + 1000 * inst.StormLevel * inst.StormLevel
							end
							if not v:HasTag("storm_attacked") and  v.components.health and not v.components.health:IsDead() then 
								v.components.combat:GetAttacked(owner,damage)
								if v:HasTag("giant") then 
									v.SoundEmitter:PlaySound("dontstarve/forge2/beetletaur/attack")
									local fx = SpawnPrefab("dark_hit_fx_icey")
									fx.AnimState:SetMultColour(133/255, 135/255, 133/255,0.5)
									fx.Transform:SetPosition(x,y+2,z)
									fx.Transform:SetScale(2.5,2.5,2.5)
									if v.sg and not v.sg:HasStateTag("nointerrupt") then 
										v.sg:GoToState("hit")
									end
								end 
								v:AddTag("storm_attacked")
								v:DoTaskInTime(0.2,function()
									v:RemoveTag("storm_attacked")
								end)
							end 
						end 
					end 
					Sleep(0)
				end
				SetStormLevel(inst,0)
			end)
		end 
	end
	
	--print("",inst.StormLevel)
end 

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
	inst.entity:AddNetwork()

    MakeInventoryPhysics(inst)

    inst.AnimState:SetBank("swap_storm_controlor")
    inst.AnimState:SetBuild("swap_storm_controlor")
    inst.AnimState:PlayAnimation("idle")

    --inst:AddTag("heavy_blade")
	
	inst.StormLevel = 0 

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.storm_fxs = {} 
	inst.fxcolour = {133/255, 135/255, 133/255}
    inst.castsound = "dontstarve/common/staffteleport"--"dontstarve_DLC001/common/tornado"

    inst:AddComponent("weapon")
    inst.components.weapon:SetDamage(40)
	inst.components.weapon:SetRange(0.5,hitrange)

    inst:AddComponent("inspectable")
	--inst.components.inspectable:SetDescription("鍙湁椋庢毚鎵嶈兘鍑诲€掑ぇ鏍?")

    inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "storm_controlor"
	inst.components.inventoryitem.atlasname = "images/inventoryimages/storm_controlor.xml"
	
    inst:AddComponent("equippable")
    inst.components.equippable:SetOnEquip(onequip)
    inst.components.equippable:SetOnUnequip(onunequip)
	
	inst:AddComponent("spellcaster")
    inst.components.spellcaster:SetSpellFn(OnSpell)
    inst.components.spellcaster.canuseonpoint = true
	
	inst.OnStormLevelChange = OnStormLevelChange
	inst.StormLevelDelta = StormLevelDelta
	inst.StormAttack = StormAttack
	
    MakeHauntableLaunch(inst)
	StormLevelDelta(inst,0)
    return inst
end

return Prefab("storm_controlor", fn, assets,prefabs)