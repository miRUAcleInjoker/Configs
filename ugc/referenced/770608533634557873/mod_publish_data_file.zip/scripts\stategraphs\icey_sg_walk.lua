local SpecialTags = {
	"icey_sneaking", -----Ǳ��
	"icey_were",   	 -----�����ܲ�
	"icey_swimming", -----��Ӿ
}

local function HasOneOfTags(inst,tags)
	if not (inst and inst:IsValid()) then 
		return false 
	end 
	for k,v in pairs(tags) do 
		if inst:HasTag(v) then 
			return true
		end
	end
end 

local function ConfigureRunState(inst)
	--[[inst.sg.statemem.riding = false 
    inst.sg.statemem.groggy = false
	inst.sg.statemem.heavy = false
	inst.sg.statemem.normal = false
	inst.sg.statemem.sandstorm = false
	inst.sg.statemem.careful = false
	inst.sg.statemem.sneaking = false
	inst.sg.statemem.wererunning = false--]]
	
    if (inst.components.rider and inst.components.rider:IsRiding()) or (inst.replica.rider ~= nil and inst.replica.rider:IsRiding()) then
        inst.sg.statemem.riding = true
        inst.sg.statemem.groggy = inst:HasTag("groggy")
        inst.sg:AddStateTag("nodangle")
    elseif (inst.replica.inventory and inst.replica.inventory:IsHeavyLifting()) or ( inst.components.inventory and inst.components.inventory:IsHeavyLifting()) then
        inst.sg.statemem.heavy = true
    elseif inst:HasTag("beaver") then
        if inst:HasTag("groggy") then
            inst.sg.statemem.groggy = true
        else
            inst.sg.statemem.normal = true
        end
    elseif inst:GetSandstormLevel() >= TUNING.SANDSTORM_FULL_LEVEL and not inst.components.playervision:HasGoggleVision() then
        inst.sg.statemem.sandstorm = true
    elseif inst:HasTag("groggy") then
        inst.sg.statemem.groggy = true
    elseif inst:IsCarefulWalking() then
        inst.sg.statemem.careful = true
	else
        inst.sg.statemem.normal = true
    end
	
	if inst:HasTag("icey_swimming") then  
		inst.sg.statemem.swimming = true
	elseif inst:HasTag("icey_sneaking") then 
		inst.sg.statemem.sneaking = true
	elseif inst:HasTag("icey_were") then 
		inst.sg.statemem.wererunning = true
    end  
	
	if HasOneOfTags(inst,SpecialTags) then 
		inst.sg.statemem.normal = false 
	end
end

local function GetRunStateAnim(inst)
    return (inst.sg.statemem.heavy and "heavy_walk")
        or (inst.sg.statemem.sandstorm and "sand_walk")
        or (inst.sg.statemem.groggy and "idle_walk")
        or (inst.sg.statemem.careful and "careful_walk")
		or ((inst.sg.statemem.swimming and inst.sg.statemem.riding) and "walk")
		or (inst.sg.statemem.swimming and "careful_walk")
		or ((inst.sg.statemem.sneaking and inst.sg.statemem.riding) and "walk")
		or (inst.sg.statemem.sneaking and "careful_walk")
		or (inst.sg.statemem.wererunning and "run_werewilba")
        or "run"
end

local function DoEquipmentFoleySounds(inst)
	local inventory = inst.components.inventory or inst.replica.inventory
	if inventory.equipslots then 
		for k, v in pairs(inventory.equipslots) do
			if v.foleysound ~= nil then
				inst.SoundEmitter:PlaySound(v.foleysound, nil, nil, true)
			end
		end
	end 
end

local function DoFoleySounds(inst)
    DoEquipmentFoleySounds(inst)
    if inst.foleysound ~= nil then
        inst.SoundEmitter:PlaySound(inst.foleysound, nil, nil, true)
    end
end

local function DoMountedFoleySounds(inst)
    DoEquipmentFoleySounds(inst)
	local rider = inst.components.rider or inst.replica.rider
    local saddle = rider:GetSaddle()
    if saddle ~= nil and saddle.mounted_foleysound ~= nil then
        inst.SoundEmitter:PlaySound(saddle.mounted_foleysound, nil, nil, true)
    end
end

local function PlayWaterSound(inst)
	inst.SoundEmitter:PlaySound("turnoftides/common/together/water/splash/small",nil,nil,true)
end 

local DoRunSounds = function(inst)
    if inst.sg.mem.footsteps > 3 then
        PlayFootstep(inst, .6, true)
    else
        inst.sg.mem.footsteps = inst.sg.mem.footsteps + 1
        PlayFootstep(inst, 1, true)
    end
end


AddStategraphPostInit("wilson", function(sg)
	local old_locomote = sg.events["locomote"].fn 
	sg.events["locomote"].fn = function(inst,data)
		if inst.sg:HasStateTag("busy") then
			return
		end
		local is_moving = inst.sg:HasStateTag("moving")
        local should_move = inst.components.locomotor:WantsToMoveForward()

		
		if HasOneOfTags(inst,SpecialTags) then 
			if inst.sg:HasStateTag("bedroll") or inst.sg:HasStateTag("tent") or inst.sg:HasStateTag("waking") then -- wakeup on locomote

			elseif is_moving and not should_move then
				inst.sg:GoToState("icey_specialrun_stop")
			elseif not is_moving and should_move then
				inst.sg:GoToState("icey_specialrun_start")
			elseif data.force_idle_state and not (is_moving or should_move or inst.sg:HasStateTag("idle")) then
		
			end
		end 

		return old_locomote(inst,data)
	end 
end)

AddStategraphPostInit("wilson_client", function(sg)
	local old_locomote = sg.events["locomote"].fn 
	sg.events["locomote"].fn = function(inst)
		if inst.sg:HasStateTag("busy") or inst:HasTag("busy") then
            return
        end
		local is_moving = inst.sg:HasStateTag("moving")
        local should_move = inst.components.locomotor:WantsToMoveForward()

		if HasOneOfTags(inst,SpecialTags) then 
			if inst:HasTag("sleeping") then

			elseif not inst.entity:CanPredictMovement() then

			elseif is_moving and not should_move then
				inst.sg:GoToState("icey_specialrun_stop")
			elseif not is_moving and should_move then
				inst.sg:GoToState("icey_specialrun_start")
			end
		end 
		
		return old_locomote(inst)
	end 
end)

AddStategraphState("wilson", 
	State{
        name = "icey_specialrun_start",
        tags = { "moving","running", "canrotate", "autopredict" },

        onenter = function(inst)
            ConfigureRunState(inst)
            inst.components.locomotor:RunForward()
            inst.AnimState:PlayAnimation(GetRunStateAnim(inst).."_pre")
            inst.sg.mem.footsteps = 0
        end,

        onupdate = function(inst)
            inst.components.locomotor:RunForward()
        end,

        timeline =
        {
           
        },

        events =
        {
            EventHandler("animover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("icey_specialrun_loop")
                end
            end),
        },
    }
)

AddStategraphState("wilson", 
	State{
        name = "icey_specialrun_loop",
        tags = { "moving","runing" , "canrotate", "autopredict" },

        onenter = function(inst)
            ConfigureRunState(inst)
            inst.components.locomotor:RunForward()

            local anim = GetRunStateAnim(inst)
            if anim == "run" then
                anim = "run_loop"
            end
			if anim == "run_werewilba" then
                anim = "run_werewilba_loop"
            end
			if anim == "walk" then
                anim = "walk_loop"
            end
            if not inst.AnimState:IsCurrentAnimation(anim) then
                inst.AnimState:PlayAnimation(anim, true)
            end

            inst.sg:SetTimeout(inst.AnimState:GetCurrentAnimationLength())
        end,

        onupdate = function(inst)
            inst.components.locomotor:RunForward()
        end,

        timeline =
        {
			--unmounted
            TimeEvent(7 * FRAMES, function(inst)
                if inst.sg.statemem.normal or inst.sg.statemem.wererunning then
                    DoRunSounds(inst)
                    DoFoleySounds(inst)
                end
            end),
            TimeEvent(15 * FRAMES, function(inst)
                if inst.sg.statemem.normal or inst.sg.statemem.wererunning then
                    DoRunSounds(inst)
                    DoFoleySounds(inst)
                end
            end),
			
            --careful
            --Frame 11 shared with heavy lifting below
            TimeEvent(11 * FRAMES, function(inst)
                if inst.sg.statemem.careful or inst.sg.statemem.sneaking then
                    DoRunSounds(inst)
                    DoFoleySounds(inst)
				elseif inst.sg.statemem.swimming then
					PlayWaterSound(inst)
					DoFoleySounds(inst)
                end
            end),
            TimeEvent(26 * FRAMES, function(inst)
                if inst.sg.statemem.careful or inst.sg.statemem.sneaking then
                    DoRunSounds(inst)
                    DoFoleySounds(inst)
				elseif inst.sg.statemem.swimming then
					PlayWaterSound(inst)
					DoFoleySounds(inst)
                end
            end),
        },

        ontimeout = function(inst)
            inst.sg:GoToState("icey_specialrun_loop")
        end,
    }
)

AddStategraphState("wilson", 
    State{
        name = "icey_specialrun_stop",
        tags = { "canrotate", "idle", "autopredict" },

        onenter = function(inst)
            ConfigureRunState(inst)
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation(GetRunStateAnim(inst).."_pst")
        end,

        events =
        {
            EventHandler("animover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("idle")
                end
            end),
        },
    }	
)

AddStategraphState("wilson_client", 
	State{
        name = "icey_specialrun_start",
        tags = { "moving" ,"running", "canrotate", "autopredict" },

        onenter = function(inst)
            ConfigureRunState(inst)
            inst.components.locomotor:RunForward()
            inst.AnimState:PlayAnimation(GetRunStateAnim(inst).."_pre")
            inst.sg.mem.footsteps = 0
        end,

        onupdate = function(inst)
            inst.components.locomotor:RunForward()
        end,

        timeline =
        {
           
        },

        events =
        {
            EventHandler("animover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("icey_specialrun_loop")
                end
            end),
        },
    }
)

AddStategraphState("wilson_client", 
	State{
        name = "icey_specialrun_loop",
        tags = { "moving", "running", "canrotate", "autopredict" },

        onenter = function(inst)
            ConfigureRunState(inst)
            inst.components.locomotor:RunForward()

			local anim = GetRunStateAnim(inst)
            if anim == "run" then
                anim = "run_loop"
            end
			if anim == "run_werewilba" then
                anim = "run_werewilba_loop"
            end
			if anim == "walk" then
                anim = "walk_loop"
            end
            if not inst.AnimState:IsCurrentAnimation(anim) then
                inst.AnimState:PlayAnimation(anim, true)
            end

            inst.sg:SetTimeout(inst.AnimState:GetCurrentAnimationLength())
        end,

        onupdate = function(inst)
            inst.components.locomotor:RunForward()
        end,

        timeline =
        {
			--unmounted
            TimeEvent(7 * FRAMES, function(inst)
                if inst.sg.statemem.normal or inst.sg.statemem.wererunning then
                    DoRunSounds(inst)
                    DoFoleySounds(inst)
                end
            end),
            TimeEvent(15 * FRAMES, function(inst)
                if inst.sg.statemem.normal or inst.sg.statemem.wererunning then
                    DoRunSounds(inst)
                    DoFoleySounds(inst)
                end
            end),
			
			TimeEvent(11 * FRAMES, function(inst)
                if inst.sg.statemem.careful or inst.sg.statemem.sneaking then
                    DoRunSounds(inst)
                    DoFoleySounds(inst)
				elseif inst.sg.statemem.swimming then
					PlayWaterSound(inst)
					DoFoleySounds(inst)
                end
            end),
            TimeEvent(26 * FRAMES, function(inst)
                if inst.sg.statemem.careful or inst.sg.statemem.sneaking then
                    DoRunSounds(inst)
                    DoFoleySounds(inst)
				elseif inst.sg.statemem.swimming then
					PlayWaterSound(inst)
					DoFoleySounds(inst)
                end
            end),
        },

        ontimeout = function(inst)
            inst.sg:GoToState("icey_specialrun_loop")
        end,
    }
)

AddStategraphState("wilson_client", 
    State{
        name = "icey_specialrun_stop",
        tags = { "canrotate", "idle", "autopredict" },

        onenter = function(inst)
            ConfigureRunState(inst)
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation(GetRunStateAnim(inst).."_pst")
        end,

        events =
        {
            EventHandler("animover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("idle")
                end
            end),
        },
    }	
)



   