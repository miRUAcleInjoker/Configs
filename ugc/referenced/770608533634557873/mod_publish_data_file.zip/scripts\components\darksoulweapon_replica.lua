local DarkSoulWeapon = Class(function(self, inst)
	self.inst = inst
	self.level = net_ushortint(inst.GUID, "darksoulweapon.level")
	self.maxlevel = net_ushortint(inst.GUID, "darksoulweapon.maxlevel") 
	self.property = net_string(inst.GUID, "darksoulweapon.property") 
end)

function DarkSoulWeapon:SetLevel(level)
	self.level:set(level)
end

function DarkSoulWeapon:SetMaxLevel(max)
	self.maxlevel:set(max)
end 

function DarkSoulWeapon:SetProperty(property)
	if property then 
		self.property:set(property)
	end 
end

function DarkSoulWeapon:GetLevel()
	return self.level:value()
end

function DarkSoulWeapon:GetMaxLevel()
	return self.maxlevel:value()
end

function DarkSoulWeapon:GetProperty()
	return self.property:value()
end

return DarkSoulWeapon