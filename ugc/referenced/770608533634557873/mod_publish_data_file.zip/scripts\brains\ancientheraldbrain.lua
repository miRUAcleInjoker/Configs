require "behaviours/follow"
require "behaviours/wander"
require "behaviours/standstill"

local MIN_FOLLOW_DIST = 0
local MAX_FOLLOW_DIST = 10
local TARGET_FOLLOW_DIST = 10

local MAX_CHASE_TIME = 30

local MAX_WANDER_DIST = 10

local AncientHeraldBrain = Class(Brain, function(self, inst)
    Brain._ctor(self, inst)
end)


local function GetFollowTarget(inst)
    if inst.brain.followtarget then
        if (not inst.brain.followtarget.components.health or inst.brain.followtarget.components.health:IsDead()) or
            inst:GetDistanceSqToInst(inst.brain.followtarget) > 15*15 then
            inst.brain.followtarget = nil
        end
    end
    
    if not inst.brain.followtarget then
        inst.brain.followtarget = FindEntity(inst, 10, function(target)
            return target:HasTag("player") and not (target.components.health and target.components.health:IsDead() )
        end)
    end
    
    return inst.brain.followtarget
end

local function TargetInDistance(inst)
    local target = GetFollowTarget(inst)
    
    if target then
        local dist = inst:GetDistanceSqToInst(target) 
        return dist/10 <= TARGET_FOLLOW_DIST
    end
    return false
end

local function NightmaresNearby(inst)
	local target = inst.components.combat.target
	if not target then 
		return false 
	end
    local x,y,z = target.Transform:GetWorldPosition()
    local ents = TheSim:FindEntities(x, y, z, MAX_FOLLOW_DIST, {"shadowcreature"})

    return #ents > 0
end

local function CanSpawnSpikes(inst)
	local target = inst.components.combat.target
	if not (target and target:IsValid()) or inst.sg:HasStateTag("busy") then 
		return false 
	end
	local dist = math.sqrt(inst:GetDistanceSqToInst(target)) 
	return dist >= 6 and dist <= 20 
end 



function AncientHeraldBrain:OnStart()

    --local clock = GetClock()
    
    local root = PriorityNode(
    {
       --Follow(self.inst, function() return GetFollowTarget(self.inst) end, MIN_FOLLOW_DIST, TARGET_FOLLOW_DIST, MAX_FOLLOW_DIST),
		WhileNode(function() return self.inst.SummonSpikes and CanSpawnSpikes(self.inst) end, "Summon Spikes", 
			ActionNode(function() self.inst:PushEvent("summon_spikes",{target = self.inst.components.combat.target}) end)
		),
		ChaseAndAttack(self.inst, MAX_CHASE_TIME),
		Wander(self.inst),
		StandStill(self.inst, function() return self.inst.sg:HasStateTag("idle") end),
        --IfNode(function() return TargetInDistance(self.inst) and not NightmaresNearby(self.inst) end, "TargetInDistance",
            --DoAction(self.inst, function() self.inst:PushEvent("summon",inst.components.combat.target) end, "SpawnNightmares")),

    }, 0.2)
        
    self.bt = BT(self.inst, root)
         
end

return AncientHeraldBrain
