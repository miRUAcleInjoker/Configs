local TadalinUtil = require("tadalin_util")

local assets =
{
        Asset( "ANIM", "anim/player_basic.zip" ),
        Asset( "ANIM", "anim/player_idles_shiver.zip" ),
        Asset( "ANIM", "anim/player_actions.zip" ),
        Asset( "ANIM", "anim/player_actions_axe.zip" ),
        Asset( "ANIM", "anim/player_actions_pickaxe.zip" ),
        Asset( "ANIM", "anim/player_actions_shovel.zip" ),
        Asset( "ANIM", "anim/player_actions_blowdart.zip" ),
        Asset( "ANIM", "anim/player_actions_eat.zip" ),
        Asset( "ANIM", "anim/player_actions_item.zip" ),
        Asset( "ANIM", "anim/player_actions_uniqueitem.zip" ),
        Asset( "ANIM", "anim/player_actions_bugnet.zip" ),
        Asset( "ANIM", "anim/player_actions_fishing.zip" ),
        Asset( "ANIM", "anim/player_actions_boomerang.zip" ),
        Asset( "ANIM", "anim/player_bush_hat.zip" ),
        Asset( "ANIM", "anim/player_attacks.zip" ),
        Asset( "ANIM", "anim/player_idles.zip" ),
        Asset( "ANIM", "anim/player_rebirth.zip" ),
        Asset( "ANIM", "anim/player_jump.zip" ),
        Asset( "ANIM", "anim/player_amulet_resurrect.zip" ),
        Asset( "ANIM", "anim/player_teleport.zip" ),
        Asset( "ANIM", "anim/wilson_fx.zip" ),
        Asset( "ANIM", "anim/player_one_man_band.zip" ),
        Asset( "ANIM", "anim/shadow_hands.zip" ),
		
		Asset( "ANIM", "anim/player_transform_merm.zip" ),
		
        Asset( "SOUND", "sound/sfx.fsb" ),
        Asset( "SOUND", "sound/wilson.fsb" ),
        Asset( "ANIM", "anim/beard.zip" ),
		Asset("SOUND", "sound/pig.fsb"),
		
		Asset("ANIM", "anim/book_time.zip"),
		Asset("ANIM", "anim/swap_book_time.zip"),
		Asset("IMAGE","images/inventoryimages/book_time.tex"),
		Asset("ATLAS","images/inventoryimages/book_time.xml"),
		
		Asset("ANIM", "anim/blowdart_lava2.zip"),
		Asset("ANIM", "anim/swap_blowdart_lava2.zip"),
		
		Asset("ANIM", "anim/sword_buster.zip"),
		Asset("ANIM", "anim/swap_sword_buster.zip"),
}

local function PushMusic(inst)
    if ThePlayer == nil then
        inst._playingmusic = false
    elseif ThePlayer:IsNear(inst, inst._playingmusic and 40 or 20) then
		--print(inst,ThePlayer,"Push the triggeredevent at",GetTime())
        inst._playingmusic = true
        ThePlayer:PushEvent("triggeredevent", { name = "moon_giaour" ,duration = 3})
    elseif inst._playingmusic and not ThePlayer:IsNear(inst, 50) then
        inst._playingmusic = false
    end
end

SetSharedLootTable('time_demon',
{
    --{'humanmeat',  0.5},
    --{'humanmeat',  0.25},
})

local brain = require "brains/timedemonbrain"

local function ontalk(inst, script)
    inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/idle")
end

local function CalcSanityAura(inst, observer)
    return 0
end

local function EquipBook(inst)
	inst.AnimState:Show("ARM_normal")
	inst.AnimState:Hide("ARM_carry")
	inst.AnimState:OverrideSymbol("book_open", "swap_book_time", "book_open")
    inst.AnimState:OverrideSymbol("book_closed", "swap_book_time", "book_closed")
    inst.AnimState:OverrideSymbol("book_open_pages", "swap_book_time", "book_open_pages")
	
	inst.components.combat:SetRange(2.5,2.5)
	inst.components.combat:SetDefaultDamage(10)
end 

local function EquipSpear(inst)
	inst.AnimState:Show("ARM_carry")
    inst.AnimState:Hide("ARM_normal")
	inst.AnimState:OverrideSymbol("swap_object", "swap_spear_gungnir", "swap_spear_gungnir")
	
	inst.components.combat:SetRange(3,3)
	inst.components.combat:SetDefaultDamage(25)
end 

local function EquipBlowdarts(inst)
	inst.AnimState:Show("ARM_carry")
    inst.AnimState:Hide("ARM_normal")
	inst.AnimState:OverrideSymbol("swap_object", "swap_blowdart_lava2", "swap_blowdart_lava2")
	
	inst.components.combat:SetRange(15,3)
	inst.components.combat:SetDefaultDamage(34)
	inst.components.combat:SetAttackPeriod(0)
end 

local function EquipHeavyBlade(inst)
	inst.AnimState:Show("ARM_carry")
    inst.AnimState:Hide("ARM_normal")

	inst.AnimState:OverrideSymbol("swap_object", "swap_sword_buster", "swap_sword_buster")
end 

local function CheckWeapons(inst)
	local percent = inst.components.health:GetPercent()
	if 0.75 <= percent then 
		EquipBook(inst)
	elseif 0.50 <= percent then 
		EquipSpear(inst)
	elseif 0.25 <= percent then 
		EquipBlowdarts(inst)
	end 
end 

local function EquipHat(inst)
	inst.AnimState:Show("HAT")
    inst.AnimState:Show("HAIR_HAT")
    inst.AnimState:Hide("HAIR_NOHAT")
    inst.AnimState:Hide("HAIR")
    inst.AnimState:Hide("HEAD")
    inst.AnimState:Show("HEAD_HAT")
	inst.AnimState:OverrideSymbol("swap_hat","hat_desert","swap_hat")
end 

local TimeStopAddColour = {34/255,0/255,57/255,1}
local TimeStopMultColour = {124/255,0/255,255/255,1}

local function OnSingleStopTime(inst,target,delay,stopped_components,isTheWorld)
	if target and target:IsValid() and not target:HasTag("shadow") then 
		if target.AnimState then 
			target.oldMultColour_timestop = {target.AnimState:GetMultColour()}
			target.AnimState:SetMultColour(unpack(TimeStopMultColour))
		end 
		if isTheWorld then
			local mytarget = inst.components.combat.target 
			if mytarget and mytarget:IsValid() then 
				if target.components.projectile then 
					target.components.projectile.target = mytarget
					target:FacePoint(mytarget.Transform:GetWorldPosition())
				end
				if target.components.ly_projectile then 
					target.components.ly_projectile.owner = inst
					target.components.ly_projectile.target = mytarget
					target.components.ly_projectile:SetCanHit(function(pro,owner,v)
						return not v:HasTag("tadalin")
					end)
					target:FacePoint(mytarget.Transform:GetWorldPosition())
				end
			end 
		end
	end
end 

local function OnSingleResumeTime(inst,target,delay,stopped_components)
	if target and target:IsValid() and not target:HasTag("shadow") then 
		if target.AnimState then 
			if target.oldMultColour_timestop then 
				target.AnimState:SetMultColour(unpack(target.oldMultColour_timestop))
			else
				target.AnimState:SetMultColour(1,1,1,1)
			end
		end 
	end
end 

local function OnTheWorld(inst,pos,radius,delay)
	local scale = radius / 10 + 1
	local timecrack = SpawnPrefab("timecrack")
	timecrack.AnimState:SetAddColour(unpack(TimeStopAddColour))
	timecrack.Transform:SetScale(scale,scale,scale)
	timecrack.Transform:SetPosition(pos:Get())
	timecrack:DoTaskInTime(delay,timecrack.KillFx)
	
	if inst.SoundEmitter then 
		inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/enemy/metal_robot/smash")
	end 
	local fx = SpawnPrefab("laser_ring")
	local ring_scale = radius / 40 + 0.75
	fx:AddTag("NO_TIME_STOP")
	fx.Transform:SetPosition(pos:Get())
	fx.Transform:SetScale(ring_scale,ring_scale,ring_scale)
	ShakeAllCameras(CAMERASHAKE.FULL, .35, .02, 1, inst, 40)
end 

local function TimeStoperTest(inst,target)
	return not target:HasTag("tadalin") 
end 

local function TargetIsAggressive(inst,target)
    return target and
           target.components.combat and
           target.components.combat.defaultdamage > 0 and
           target.components.combat.target == inst and 
		   target.sg and target.sg:HasStateTag("attack") and not target:HasTag("time_stopped")
end

local function IsAggressiveProjectile(inst,proj)
	return proj and (
		(proj.components.projectile and proj.components.projectile.target == inst) or 
		(proj.components.ly_projectile and proj.components.ly_projectile:ProbalyHit(inst))
	)
end 

local function SmallTheWorld(inst,target)
	inst.components.timestoper:TheWorld(target:GetPosition(),8,3)
	inst:PushEvent("use_time_demon_skill",{name = "skill_smalltheworld",cd = 12})
end 

local function SpawnFrogs(inst,target)
	if not (target and target:IsValid()) then 
		return 
	end 
	for i=1,math.random(8,12) do 
		local frog = SpawnPrefab("time_demon_frog")  
		local pos = target:GetPosition() 
		local offset = (FindWalkableOffset(pos, math.random(0,360), math.random()*3 + 4, 2, true, true) or Vector3(0,0,0))+Vector3(0,20,0)
		frog.Transform:SetPosition((pos+offset):Get()) 
		frog.sg:GoToState("fall") 
		--frog.components.combat:SetTarget(target)
	end
	inst:PushEvent("use_time_demon_skill",{name = "skill_frogs",cd = 120})
end 

local function MissAndLock(inst,target)
	local pos = inst:GetPosition()
	local offset = FindWalkableOffset(pos, math.random(0,360), math.random()*3 + 3, 2, true, true) or Vector3(0,0,0)
	SpawnPrefab("statue_transition").Transform:SetPosition(target:GetPosition():Get())
	SpawnPrefab("statue_transition_2").Transform:SetPosition(target:GetPosition():Get())
	SpawnPrefab("maxwell_smoke").Transform:SetPosition(pos:Get())
	SpawnPrefab("maxwell_smoke").Transform:SetPosition((pos+offset):Get())
	if target.SoundEmitter then 
		--target.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/enemy/metal_robot/smash")
		target.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/enemy/metal_robot/arm/servo")
	end 
	inst.Transform:SetPosition((pos+offset):Get())
	inst.components.timestoper:SingleStopTime(target,3)
	inst.sg:GoToState("taunt_2")
	inst:PushEvent("use_time_demon_skill",{name = "skill_miss",cd = 7})
end 

local function BigTheWorld(inst)
	inst.components.timestoper:TheWorld()
end 

local function TryDefendProjectile(inst,data)
	if not inst.skill_smalltheworld or inst.sg:HasStateTag("parrying") then 
		return 
	end 
	local target = FindEntity(inst,3, function(projectile) return IsAggressiveProjectile(inst,projectile) end)
	if (target and target:IsValid()) or data then 
		--SmallTheWorld(inst,inst)
		inst.sg:GoToState("parry")
	end
end 

local function TryMissAttacker(inst)
	if not inst.skill_miss then 
		return 
	end 
	local target = FindEntity(inst,3, function(attacker) return TargetIsAggressive(inst,attacker) end)
	if target and target:IsValid() then 
		MissAndLock(inst,target)
	end
end 

local function onskilluse(inst,data)
	local skillname = data.name
	local skillcd = data.cd
	inst[skillname] = false 
	
	inst.components.timer:StartTimer(skillname,skillcd)
end 

local function ontimerdone(inst,data)
	local skillname = data.name
	inst[skillname] = true 
end 



local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddDynamicShadow()
    inst.entity:AddLightWatcher()
    inst.entity:AddNetwork()

    MakeCharacterPhysics(inst, 50, .5)

    inst.DynamicShadow:SetSize(1.5, .75)
    inst.Transform:SetFourFaced()

    inst:AddTag("character")
    inst:AddTag("scarytoprey")  
	inst:AddTag("hostile")
	inst:AddTag("tadalin")
	inst:AddTag("monster")
	inst:AddTag("epic")
	inst:AddTag("noepicmusic")
	
    inst.AnimState:SetBank("wilson") 
	inst.AnimState:SetBuild("wilson")
    inst.AnimState:PlayAnimation("idle", true)	
	
	inst._playingmusic = false
	if not TheNet:IsDedicated() then
        inst:DoPeriodicTask(1, PushMusic,0)
    end
	
    inst.entity:SetPristine()
	
	inst:AddComponent("talker")
    inst.components.talker.fontsize = 35
    inst.components.talker.font = TALKINGFONT
    --inst.components.talker.colour = Vector3(133/255, 140/255, 167/255)
    inst.components.talker.offset = Vector3(0, -400, 0)
    inst.components.talker:MakeChatter()
	inst.components.talker.ontalk = ontalk

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.skill_miss = true
	inst.skill_smalltheworld = true 
	inst.skill_frogs = true
	inst.skill_bigtheworld = false
	--inst.skill_flowers = false
	
	inst.CheckWeapons = CheckWeapons
	inst.EquipHeavyBlade = EquipHeavyBlade
	inst.SmallTheWorld = SmallTheWorld
	inst.SpawnFrogs = SpawnFrogs
	inst.BigTheWorld = BigTheWorld

	inst:AddComponent("combat")
    inst.components.combat:SetTarget(nil)
	inst.components.combat:SetDefaultDamage(10)
    inst.components.combat:SetAttackPeriod(1)
	
    inst:AddComponent("locomotor") -- locomotor must be constructed before the stategraph
    inst.components.locomotor.runspeed = 8
    inst.components.locomotor.walkspeed = 8
	
	
    inst:AddComponent("bloomer")

    inst:AddComponent("health")
	inst.components.health:SetMaxHealth(2000)

    inst:AddComponent("inventory")

    inst:AddComponent("lootdropper")
	inst.components.lootdropper:SetChanceLootTable('time_demon')

    inst:AddComponent("knownlocations")

    inst:AddComponent("sanityaura")
    inst.components.sanityaura.aurafn = CalcSanityAura

    inst:AddComponent("inspectable")
    inst.components.inspectable:SetDescription("恶膜某民命秒没!")
	
	inst:AddComponent("timestoper")
	inst.components.timestoper:SetOnSingleStopTime(OnSingleStopTime)
	inst.components.timestoper:SetOnSingleResumeTime(OnSingleResumeTime)
	inst.components.timestoper:SetOnTheWorld(OnTheWorld)
	inst.components.timestoper:SetTimeStoperTest(TimeStoperTest)
	
	inst:AddComponent("timer")
   
	inst:SetBrain(brain)
    inst:SetStateGraph("SGtime_demon")
	--inst:ListenForEvent("newcombattarget", OnNewTarget)
	
	TadalinUtil.MakeNormalTadalin(inst)
	EquipHat(inst)
	CheckWeapons(inst)
	
	inst:DoPeriodicTask(0.3,TryMissAttacker)
	inst:DoPeriodicTask(0.1,TryDefendProjectile)
	
	inst:ListenForEvent("use_time_demon_skill",onskilluse)
	inst:ListenForEvent("timerdone",ontimerdone)
	inst:ListenForEvent("hostileprojectile",TryDefendProjectile)
	
	if c_findnext("time_demon") then 
		inst:Remove()
	end

    return inst
end

return Prefab("time_demon", fn, assets)
