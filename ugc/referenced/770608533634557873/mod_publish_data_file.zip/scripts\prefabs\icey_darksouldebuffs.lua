local IceyUtil = require("icey_util")
local IceyDebuffs = require("darksouldebuffs_icey")

local function DefaultReplicaFn(inst)
	local parent = inst.entity:GetParent() 
	if parent and parent:IsValid() and parent.HUD and parent.HUD.controls and parent.HUD.controls.DarkSoulDebuffList then 
		local name = inst.replica.darksouldebuff:GetName()
		local percent = inst.replica.darksouldebuff:GetPercent()
		local activated = inst.replica.darksouldebuff:IsActivated()
		parent.HUD.controls.DarkSoulDebuffList:AddBuff(name,inst,percent,activated)
	end
end 


local function MakeDarkSoulDebuff(prefabname,data)
	
	
	local function TickTask(inst)
		local target = inst.components.darksouldebuff.target
		local buffname = inst.components.darksouldebuff.name
		if target and target:IsValid() then 
			if target.components.hunger and data.hunger_delta_tick then 
				target.components.hunger:DoDelta(data.hunger_delta_tick,true)
			end
			
			if target.components.health and not target.components.health:IsDead() and data.health_delta_tick then 
				target.components.health:DoDelta(data.health_delta_tick,true,buffname,nil,nil,true)
			end
			
			if target.components.sanity and data.sanity_delta_tick then 
				target.components.sanity:DoDelta(data.sanity_delta_tick,true)
			end
			
			if target.components.stamina and data.stamina_delta_tick then 
				target.components.stamina:DoDelta(data.stamina_delta_tick)
			end
			
			if target.components.focus and data.focus_delta_tick then 
				target.components.focus:DoDelta(data.focus_delta_tick)
			end
		end
	end 


	local function ApplyDebuff(inst,target)
		local buffname = inst.components.darksouldebuff.name
		if target.components.combat then
			target.components.combat.externaldamagemultipliers:SetModifier(inst,data.damage_multi or 1,buffname)
			target.components.combat.externaldamagetakenmultipliers:SetModifier(inst,data.damagetaken_multi or 1,buffname)
		end 
		
		if target.components.health then
			target.components.health.externalhealthregenmultipliers:SetModifier(inst,data.healthregen_multi or 1,buffname)
		end 
				
		if target.components.hunger then
			target.components.hunger.burnratemodifiers:SetModifier(inst,data.hunger_multi or 1,buffname)
		end 
				
		if target.components.sanity then 
			target.components.sanity.externalmodifiers:SetModifier(inst,data.sanity_additive or 0,buffname)
		end 
				
		if target.components.locomotor then 
			target.components.locomotor:SetExternalSpeedMultiplier(inst,buffname,data.speed_multi or 1)
		end 
				
		if target.components.stamina then 
			target.components.stamina.externalrecoverratemultipliers:SetModifier(inst,data.stamina_recover_multi or 1,buffname)
			target.components.stamina.externalconsumeratemultipliers:SetModifier(inst,data.stamina_consume_multi or 1,buffname)
		end 
			
		if target.components.focus then 
			target.components.focus.externalmodifiers:SetModifier(inst,data.focus_additive or 0,buffname)
		end 	
		
		if inst.ticktask then 
			inst.ticktask:Cancel()
			inst.ticktask = nil 
		end
		inst.ticktask = inst:DoPeriodicTask(0,TickTask)
	end 

	local function RemoveDebuff(inst,target)
		local buffname = inst.components.darksouldebuff.name
		if target.components.combat then
			target.components.combat.externaldamagemultipliers:RemoveModifier(inst,buffname)
			target.components.combat.externaldamagetakenmultipliers:RemoveModifier(inst,buffname)
		end 
		
		if target.components.health then
			target.components.health.externalhealthregenmultipliers:RemoveModifier(inst,buffname)
		end 
		
		if target.components.hunger then
			target.components.hunger.burnratemodifiers:RemoveModifier(inst,buffname)
		end 
		
		if target.components.sanity then 
			target.components.sanity.externalmodifiers:RemoveModifier(inst,buffname)
		end 
		
		if target.components.locomotor then 
			target.components.locomotor:RemoveExternalSpeedMultiplier(inst,buffname)
		end 
		
		if target.components.stamina then 
			target.components.stamina.externalrecoverratemultipliers:RemoveModifier(inst,buffname)
			target.components.stamina.externalconsumeratemultipliers:RemoveModifier(inst,buffname)
		end 
		
		if target.components.focus then 
			target.components.focus.externalmodifiers:RemoveModifier(inst,buffname)
		end 	

		
		if inst.ticktask then 
			inst.ticktask:Cancel()
			inst.ticktask = nil 
		end
	end 

	----------------------------------------------------------------------------------------


	local function OnAttached(inst, target)
		inst.entity:SetParent(target.entity)
		
		if not data.NotRemoveOnDeath then 
			inst:ListenForEvent("death", function()
				inst.components.darksouldebuff:Stop()
			end, target)
		end 
		
		if data.OnAttached then 
			data.OnAttached(inst,target)
		end 
	end

	local function OnDetached(inst, target)
		RemoveDebuff(inst,target)
		if data.OnDetached then 
			data.OnDetached(inst,target)
		end 
		inst:Remove()
	end


	local function OnExtended(inst, target)
		if inst.components.darksouldebuff:IsActivated() then 
			RemoveDebuff(inst,target)
			inst:DoTaskInTime(0,function()
				ApplyDebuff(inst,target)
			end)
		end 
		if data.OnExtended then 
			data.OnExtended(inst,target)
		end 
	end

	local function OnActivated(inst,target,followsymbol, followoffset,activated_num)
		inst:DoTaskInTime(0,function()
			ApplyDebuff(inst,target)
		end)
		if data.OnActivated then 
			data.OnActivated(inst,target,activated_num)
		end 
	end 
	
	
	----------------------------------------------------------------------------------------
	
	
	local function OnTargetDirty(inst)
		DefaultReplicaFn(inst)
		if data.OnTargetDirty then 
			data.OnTargetDirty(inst)
		end 
	end 

	local function OnPercentDirty(inst)
		DefaultReplicaFn(inst)
		if data.OnPercentDirty then 
			data.OnPercentDirty(inst)
		end 
	end 

	local function OnActivatedDirty(inst)
		DefaultReplicaFn(inst)
		if data.OnActivatedDirty then 
			data.OnActivatedDirty(inst)
		end 	
	end 
	
		
	local function fn(inst)
		local inst = CreateEntity()
		local trans = inst.entity:AddTransform()
		inst.entity:AddNetwork()
		inst.entity:AddAnimState()
		inst.entity:AddSoundEmitter()

		inst:AddTag("CLASSIFIED")

		if not TheNet:IsDedicated() then 
			inst:ListenForEvent("ontargetdirty",OnTargetDirty)
			inst:ListenForEvent("onpercentdirty",OnPercentDirty)
			inst:ListenForEvent("onactivateddirty",OnActivatedDirty)
		end 
		
		
		inst.entity:SetPristine()

		if not TheWorld.ismastersim then
			return inst
		end
		
		inst:AddComponent("darksouldebuff")
		inst.components.darksouldebuff:SetAttachedFn(OnAttached)
		inst.components.darksouldebuff:SetDetachedFn(OnDetached)
		inst.components.darksouldebuff:SetExtendedFn(OnExtended)
		inst.components.darksouldebuff:SetActivatedFn(OnActivated)
		inst.components.darksouldebuff.keepondespawn = data.keepondespawn
		
		if data.decrease_rate then 
			inst.components.darksouldebuff.decrease_rate = data.decrease_rate --��������(δ����ʱ)
		end 
			
		if data.decrease_rate_activated then 
			inst.components.darksouldebuff.decrease_rate_activated = data.decrease_rate_activated --��������(����ʱ)
		end 
		
		--inst.OnSave = OnSave
		--inst.OnLoad = OnLoad

		
		return inst
		
	end
	return Prefab(prefabname,fn)
end 

local rets = {}
for prefabname,data in pairs(IceyDebuffs) do 
	table.insert(rets,MakeDarkSoulDebuff(prefabname,data))
end

return unpack(rets) 