local IceyUtil = require("icey_util")


local function OnAttached(inst, target)
    inst.entity:SetParent(target.entity)
	--[[if target.sg then 
		target.sg:GoToState("powerup")
	end --]]
	if target.components.combat and target.components.locomotor then 
		target.components.combat.externaldamagetakenmultipliers:SetModifier(inst,0.5,"iron_flesh")
		target.components.locomotor:SetExternalSpeedMultiplier(inst,"iron_flesh",0.75)
	end 
    inst:ListenForEvent("death", function()
        inst.components.debuff:Stop()
    end, target)
	
	inst.buff_fx = target:SpawnChild("battlestandard_buff_fxs")
	inst.buff_fx:Play("defend_fx")
end

local function OnDetached(inst, target)
	if target.components.combat and target.components.locomotor then 
		target.components.combat.externaldamagetakenmultipliers:RemoveModifier(inst,"iron_flesh")
		target.components.locomotor:RemoveExternalSpeedMultiplier(inst,"iron_flesh")
	end 
	if inst.buff_fx and inst.buff_fx:IsValid() then 
		inst.buff_fx:Remove() 
	end
	inst:Remove()
end

local function OnTimerDone(inst, data)
    if data.name == "startiron" then
        inst.components.debuff:Stop()
    end
end

local function OnExtended(inst, target)
    inst.components.timer:StopTimer("startiron")
    inst.components.timer:StartTimer("startiron", inst.duration)
end


local function fn(inst)
	local inst = CreateEntity()
	local trans = inst.entity:AddTransform()
	inst.entity:AddNetwork()
	inst.entity:AddAnimState()
	inst.entity:AddSoundEmitter()

	inst:AddTag("CLASSIFIED")

	
	inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
    inst:AddComponent("debuff")
    inst.components.debuff:SetAttachedFn(OnAttached)
    inst.components.debuff:SetDetachedFn(OnDetached)
    inst.components.debuff:SetExtendedFn(OnExtended)
    --inst.components.debuff.keepondespawn = true
	
	inst.duration = 15
	
    inst:AddComponent("timer")
	inst:DoTaskInTime(0, function() -- in case we want to change duration
		inst.components.timer:StartTimer("startiron", inst.duration)
	end)
    inst:ListenForEvent("timerdone", OnTimerDone)

	return inst
	
end
--ThePlayer.components.debuffable:AddDebuff("pyromancy_iron_flesh_debuff", "pyromancy_iron_flesh_debuff")
return Prefab("pyromancy_iron_flesh_debuff", fn)