local assets =
{ 
    Asset("ANIM", "anim/icey_armor.zip"),
    --Asset("ANIM", "anim/icey_armor_swap.zip"), 

    Asset("ATLAS", "images/inventoryimages/icey_armor.xml"),
    Asset("IMAGE", "images/inventoryimages/icey_armor.tex"),
}


local function OnEquip(inst, owner) 

end

local function OnUnequip(inst, owner) 

end

local function fn()

    local inst = CreateEntity()
    local trans = inst.entity:AddTransform()
	
    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()  --这个联机也必须加 
	
    MakeInventoryPhysics(inst)
	inst.entity:AddMiniMapEntity()
	
    inst:AddTag("ocean_seeker")
	inst:AddTag("hide_percentage")
	--inst:AddTag("anti_radiation")
	
	inst.AnimState:SetBank("icey_armor")
    inst.AnimState:SetBuild("icey_armor")
    inst.AnimState:PlayAnimation("idle")
	
	
	----------------------上面的东西 对主副机都有效
	
	inst.entity:SetPristine()   --这四句话 放到这里 也就是bank build 和tag之类的后面-。-
	if not TheWorld.ismastersim then
        return inst
    end
	
	----------------------下面的只对主机执行
	inst:AddComponent("chosenicey")
	
    inst:AddComponent("inspectable")
	
    inst:AddComponent("inventoryitem")
    inst.components.inventoryitem.imagename = "icey_armor"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/icey_armor.xml"
	--inst.components.inventoryitem:SetRadiationAbsorb(1)
	
    inst:AddComponent("equippable")
    inst.components.equippable.equipslot = EQUIPSLOTS.BODY
    inst.components.equippable:SetOnEquip(OnEquip)
    inst.components.equippable:SetOnUnequip(OnUnequip)
	
	MakeHauntableLaunch(inst)  --这个放后面就好了

    return inst
end

return  Prefab("icey_sikushui", fn, assets, prefabs)