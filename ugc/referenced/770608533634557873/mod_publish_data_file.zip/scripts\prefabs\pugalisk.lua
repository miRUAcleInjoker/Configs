require("brains/pugalisk_headbrain")
require("brains/pugalisk_tailbrain")
require "stategraphs/SGpugalisk_head"

local pu = require ("prefabs/pugalisk_util")

local assets =
{	
    Asset("ANIM", "anim/python.zip"),
    Asset("ANIM", "anim/python_test.zip"),
    Asset("ANIM", "anim/python_segment_broken02_build.zip"),    
    Asset("ANIM", "anim/python_segment_broken_build.zip"),    
    Asset("ANIM", "anim/python_segment_build.zip"),                            
    Asset("ANIM", "anim/python_segment_tail02_build.zip"), 
    Asset("ANIM", "anim/python_segment_tail_build.zip"),     
}

local prefabs =
{
    "snake_bone",
    "monstermeat",
    "groundpound_fx",
    "pugalisk_body",
}

SetSharedLootTable( 'pugalisk',
{
    {'monstermeat',             1.00},
    {'monstermeat',             1.00},
    {'monstermeat',             1.00},
})

local function oncollapse(inst, other)
    if other:IsValid() and other.components.workable ~= nil and other.components.workable:CanBeWorked() then
        SpawnPrefab("collapse_small").Transform:SetPosition(other.Transform:GetWorldPosition())
        other.components.workable:Destroy(inst)
    end
end

local function DoFriendlyAreaAttack(inst)
	local x,y,z = inst:GetPosition():Get()
	local ents = TheSim:FindEntities(x,y,z,4,nil,{"pugalisk","tadalin"})
	for k,v in pairs(ents) do 
		if v and v:IsValid() and v ~= inst   then 
			if v:HasTag("structure") and v.components.health then 
				v.components.health:DoDelta(-math.random(10,40))
				--v:PushEvent("attacked")
			end 
			if v.components.combat and  (v.components.combat.target and v.components.combat.target:HasTag("pugalisk")) or v:HasTag("player")  then 
				v.components.combat:GetAttacked(inst,math.random(10,40))
			end 
			if v.components.workable then 
				oncollapse(inst, v)
			end
		end
	end
end 

local function dogroundpound(inst)
	print(inst,"dogroundpound!")
	ShakeAllCameras(CAMERASHAKE.VERTICAL, .7, .025, 1.25, inst, 40)
	inst.SoundEmitter:PlaySound("dontstarve/tentacle/tentapiller_hurt_VO")
	DoFriendlyAreaAttack(inst)
	local fx = SpawnPrefab("groundpound_fx")
	fx.Transform:SetPosition(inst:GetPosition():Get())
end
 
local SHAKE_DIST = 40

local function redirecthealth(inst, amount, overtime, cause, ignore_invincible)

    local originalinst = inst

    if inst.startpt then
        inst = inst.startpt
    end

    if amount < 0 and( (inst.components.segmented and inst.components.segmented.vulnerablesegments == 0) or inst:HasTag("tail") or inst:HasTag("head") ) then
        --[[print("invulnerable",cause,GetPlayer().prefab)
        if cause == GetPlayer().prefab then
            GetPlayer().components.talker:Say(GetString(GetPlayer().prefab, "ANNOUNCE_PUGALISK_INVULNERABLE"))        
        end--]]
        inst.SoundEmitter:PlaySound("dontstarve/common/destroy_metal",nil,.25)
        inst.SoundEmitter:PlaySound("dontstarve/wilson/hit_metal")
		
		local fx = SpawnPrefab("snake_scales_fx")
        fx.Transform:SetScale(1.5,1.5,1.5)
        local pt= Vector3(originalinst.Transform:GetWorldPosition())
        fx.Transform:SetPosition(pt.x,pt.y + 2 + math.random()*2,pt.z)

    elseif amount and amount < 0 and inst.host then
		
		if not inst.host.components.health:IsInvincible() then 
			local fx = SpawnPrefab("blood_hit_fx_icey")
			--fx.Transform:SetScale(3,3,3)
			local pt= Vector3(originalinst.Transform:GetWorldPosition())
			fx.Transform:SetPosition(pt.x,pt.y,pt.z)
		end 

        inst:PushEvent("dohitanim")
        inst.host.components.health:DoDelta(amount, overtime, cause, ignore_invincible, true)
        inst.host:PushEvent("attacked")
    end    
	--[[if not inst:HasTag("head") then 
		inst:DoTaskInTime(0,function()
			inst.components.health.absorb = 1.0
		end)
	end--]]
	--inst.components.health.absorb = 1.0
end

local function redirectdamagefn(inst, attacker, damage, weapon, stimuli)
	local originalinst = inst

    if inst.startpt then
        inst = inst.startpt
    end

    if ( (inst.components.segmented and inst.components.segmented.vulnerablesegments == 0) or inst:HasTag("tail") or inst:HasTag("head") ) then
        inst.SoundEmitter:PlaySound("dontstarve/common/destroy_metal",nil,.25)
        inst.SoundEmitter:PlaySound("dontstarve/wilson/hit_metal")
		
		local fx = SpawnPrefab("snake_scales_fx")
        fx.Transform:SetScale(1.5,1.5,1.5)
        local pt= Vector3(originalinst.Transform:GetWorldPosition())
        fx.Transform:SetPosition(pt.x,pt.y + 2 + math.random()*2,pt.z)

    elseif  inst.host then
		
		if not inst.host.components.health:IsInvincible() then 
			local fx = SpawnPrefab("blood_hit_fx_icey")
			--fx.Transform:SetScale(3,3,3)
			local pt= Vector3(originalinst.Transform:GetWorldPosition())
			fx.Transform:SetPosition(pt.x,pt.y,pt.z)
		end 

        inst:PushEvent("dohitanim")
        --inst.host.components.health:DoDelta(amount, overtime, cause, ignore_invincible, true)
        --inst.host:PushEvent("attacked")
		return inst.host 
    end  
end 

local function keeptargetfn(inst,target)    
    return target 
		  and not target:HasTag("pugalisk")
          and target.components.combat
          and target.components.health
          and not target.components.health:IsDead()
end



local function RetargetTailFn(inst)  

    local targetDist = TUNING.PUGALISK_TAIL_TARGET_DIST

    local notags = {"FX", "NOCLICK","INLIMBO","pugalisk","monster"}
    return FindEntity(inst, targetDist, function(guy)
        return (not guy:HasTag("pugalisk")) 
               and inst.components.combat:CanTarget(guy)
    end, nil, notags)
end

local function RetargetFn(inst)  

    local targetDist = TUNING.PUGALISK_TARGET_DIST

    local notags = {"FX", "NOCLICK","INLIMBO","pugalisk","monster"}
    return FindEntity(inst, targetDist, function(guy)
        return ( not guy:HasTag("pugalisk")) 
               and inst.components.combat:CanTarget(guy)
    end, nil, notags)

end

local function OnHit(inst, attacker)    
    local host = inst
    if inst.host then
        host = inst.host      
    end    

    if attacker  then
        host.target = attacker 
		host.components.combat:SetTarget(attacker)
    end
	
	if host and host:IsValid() then 
		if not host.components.health:IsInvincible() then 
			host.components.health:SetInvincible(true)
			host:DoTaskInTime(0,function()
				host.components.health:SetInvincible(false)
			end)
		end 
	end 
end



local function segmentfn(Sim)
    local inst = CreateEntity()
    local trans = inst.entity:AddTransform()
    local anim = inst.entity:AddAnimState()
    local sound = inst.entity:AddSoundEmitter()
	inst.entity:AddNetwork()

    local s = 1.5
    trans:SetScale(s,s,s)
    inst.Transform:SetEightFaced()

    inst.AnimState:SetFinalOffset( -10 )
    
    anim:SetBank("giant_snake")
    anim:SetBuild("python_test")
    anim:PlayAnimation("test_segment")

    inst:AddTag("pugalisk")
    inst:AddTag("groundpoundimmune")
    inst:AddTag("noteleport")
	inst:AddTag("prey")
	inst:AddTag("tadalin")
	inst:AddTag("NOSHIELDCRUSH")
	inst:AddTag("NO_ICEY_EXP")
	
	inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst:AddComponent("combat")
    inst.components.combat:SetDefaultDamage(0)
    inst.components.combat.hiteffectsymbol = "test_segments"-- "wormmovefx"
    inst.components.combat.onhitfn = OnHit 
	inst.components.combat.redirectdamagefn = redirectdamagefn   

    inst:AddComponent("health")
    inst.components.health:SetMaxHealth(9999)
    inst.components.health.destroytime = 5
	--inst.components.health:SetInvincible(true)
    --inst.components.health.redirect = redirecthealth
	inst.components.health.absorb = 1.0 
	inst.components.health:StartRegen(9999,1)
	
    --inst.components.health:StartRegen(1, 2)
--[[
    inst:ListenForEvent("death", function(inst, data)
        onhostdeath(inst.playerpickerproxy.host)
    end)
]]
    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("一定能找到它的弱点的") 
    inst.name = STRINGS.NAMES.PUGALISK  

    inst:AddComponent("lootdropper")
    inst.components.lootdropper.lootdropangle = 360
    inst.components.lootdropper.speed = 3 + (math.random()*3)

    inst.AnimState:Hide("broken01")
    inst.AnimState:Hide("broken02")

    inst.persists = false

    return inst
end

--======================================================================

local function segment_deathfn(segment)

    --segment.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/pugalisk/explode")
	segment.SoundEmitter:PlaySound("dontstarve/common/blackpowder_explo")

    local pt= Vector3(segment.Transform:GetWorldPosition())

    local bone = segment.components.lootdropper:SpawnLootPrefab("snake_bone",pt)
       
    if math.random()<0.6 then
        local bone = segment.components.lootdropper:SpawnLootPrefab("boneshard",pt)
    end        
    if math.random()<0.2 then
        local bone = segment.components.lootdropper:SpawnLootPrefab("monstermeat",pt)
    end
    if math.random()<0.005 then
        local bone = segment.components.lootdropper:SpawnLootPrefab("redgem", pt)
    end
    if math.random()<0.005 then
        local bone = segment.components.lootdropper:SpawnLootPrefab("bluegem", pt)
    end
    if math.random()<0.05 then
        local bone = segment.components.lootdropper:SpawnLootPrefab("spoiled_fish", pt)
    end
    
    local fx = SpawnPrefab("blood_hit_fx_icey")    
    --fx.Transform:SetScale(3,3,3)
    fx.Transform:SetPosition(pt.x,pt.y,pt.z)
	
	local fx2 = SpawnPrefab("snake_scales_fx")
    fx2.Transform:SetScale(1.5,1.5,1.5)
    fx2.Transform:SetPosition(pt.x,pt.y + 2 + math.random()*2,pt.z)
end

local function bodyfn(Sim)

    local inst = CreateEntity()
    local trans = inst.entity:AddTransform()
    local anim = inst.entity:AddAnimState()
    local sound = inst.entity:AddSoundEmitter()
	inst.entity:AddNetwork()

    inst.Transform:SetSixFaced()
    
    local s = 1.5
    trans:SetScale(s,s,s)
    
    MakeObstaclePhysics(inst, 1)

    anim:SetBank("giant_snake") 
    anim:SetBuild("python_test")
    anim:PlayAnimation("dirt_static")

    anim:Hide("broken01")
    anim:Hide("broken02")

    inst.AnimState:SetFinalOffset( 0 )

    inst.name = STRINGS.NAMES.PUGALISK
    inst.invulnerable = true

    ------------------------------------------
	inst:AddTag("pugalisk_body")
    inst:AddTag("epic")
	inst:AddTag("noepicmusic")
    inst:AddTag("monster")
    inst:AddTag("hostile")
    inst:AddTag("pugalisk")
    inst:AddTag("scarytoprey")
    inst:AddTag("largecreature")
    inst:AddTag("groundpoundimmune")
    inst:AddTag("noteleport")
	inst:AddTag("tadalin")
	inst:AddTag("prey")
	inst:AddTag("NOSHIELDCRUSH")
	inst:AddTag("NO_ICEY_EXP")
	
    ------------------
    

	inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end	
	
    inst:AddComponent("health")
    inst.components.health:SetMaxHealth(9999)
    inst.components.health.destroytime = 5
    --inst.components.health.redirect = redirecthealth
	--inst.components.health:SetInvincible(true)
	inst.components.health.absorb = 1.0 


    inst:ListenForEvent("death", function(inst, data)
        
    end)

    ------------------

    inst:AddComponent("combat")
    inst.components.combat:SetDefaultDamage(TUNING.PUGALISK_DAMAGE)
    inst.components.combat.playerdamagepercent = 0.75
	inst.components.combat.redirectdamagefn = redirectdamagefn

    inst.components.combat.hiteffectsymbol = "hit_target"
    inst.components.combat.onhitfn = OnHit
    
    ------------------------------------------

    inst:AddComponent("lootdropper")

    ------------------------------------------

    inst:AddComponent("inspectable")
    inst.components.inspectable:SetDescription("它的身躯非常坚硬")
    ------------------------------------------

    inst:AddComponent("knownlocations")

    ------------------------------------------

    inst:AddComponent("groundpounder")
    inst.components.groundpounder.destroyer = true
    inst.components.groundpounder.damageRings = 2
    inst.components.groundpounder.destructionRings = 1
    inst.components.groundpounder.numRings = 2
    inst.components.groundpounder.groundpounddamagemult = 30/TUNING.PUGALISK_DAMAGE
    inst.components.groundpounder.groundpoundfx= "groundpound_fx"

    ------------------------------------------

    inst:AddComponent("segmented")
    inst.components.segmented.segment_deathfn = segment_deathfn

    inst:ListenForEvent("bodycomplete", function() 
                if inst.exitpt then
                    inst.exitpt.AnimState:SetBank("giant_snake")
                    inst.exitpt.AnimState:SetBuild("python_test")
                    inst.exitpt.AnimState:PlayAnimation("dirt_static")  
					dogroundpound(inst)
                    --TheCamera:Shake("VERTICAL", 0.5, 0.05, 0.1)
                    inst.exitpt.Physics:SetActive(true)
                    --inst.exitpt.components.groundpounder:GroundPound()   

                    inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/pugalisk/emerge","emerge")
                    inst.SoundEmitter:SetParameter( "emerge", "start", math.random() )

                    if inst.host then   
                        inst.host:PushEvent("bodycomplete",{ pos=Vector3(inst.exitpt.Transform:GetWorldPosition()), angle = inst.angle })                            
                    end                                     
                end
            end) 

    inst:ListenForEvent("bodyfinished", function() 
                if inst.host then  
                    inst.host:PushEvent("bodyfinished",{ body=inst })                                                
                end                      
                inst:Remove()               
            end)

    inst.persists = false

    --inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/pugalisk/movement_LP", "speed")
    inst.SoundEmitter:SetParameter("speed", "intensity", 0)

    ------------------------------------------

    return inst
end

--===========================================================

local function tailfn(Sim)

    local inst = CreateEntity()
    local trans = inst.entity:AddTransform()
    local anim = inst.entity:AddAnimState()
    local sound = inst.entity:AddSoundEmitter()
	inst.entity:AddNetwork()

    inst.Transform:SetSixFaced()
    
    local s = 1.5
    trans:SetScale(s,s,s)
    
    MakeObstaclePhysics(inst, 1)

    anim:SetBank("giant_snake")
    anim:SetBuild("python_test") 
    anim:PlayAnimation("tail_idle_loop", true)

    anim:Hide("broken01")
    anim:Hide("broken02")

    inst.AnimState:SetFinalOffset( 0 )

    inst.name = STRINGS.NAMES.PUGALISK
    inst.invulnerable = true

    ------------------------------------------
	inst:AddTag("pugalisk_tail")
    inst:AddTag("tail")
    inst:AddTag("epic")
	inst:AddTag("noepicmusic")
    inst:AddTag("monster")
    inst:AddTag("hostile")
    inst:AddTag("pugalisk")
    inst:AddTag("scarytoprey")
    inst:AddTag("largecreature")
    inst:AddTag("groundpoundimmune")
    inst:AddTag("noteleport")
	inst:AddTag("tadalin")
	inst:AddTag("prey")
	inst:AddTag("NOSHIELDCRUSH")
	inst:AddTag("NO_ICEY_EXP")
    ------------------------------------------
	
	inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
    
    inst:AddComponent("health")
    inst.components.health:SetMaxHealth(9999)
    inst.components.health.destroytime = 5
    --inst.components.health.redirect = redirecthealth
	--inst.components.health:SetInvincible(true)
	inst.components.health.absorb = 1.0 
	inst.components.health:StartRegen(9999,1)

    ------------------------------------------  

    inst:AddComponent("combat")
    inst.components.combat:SetDefaultDamage(TUNING.PUGALISK_DAMAGE/2)
    inst.components.combat.playerdamagepercent = 0.5
    inst.components.combat:SetRange(TUNING.PUGALISK_MELEE_RANGE, TUNING.PUGALISK_MELEE_RANGE)
	--inst.components.combat:SetAreaDamage(TUNING.BEARGER_ATTACK_RANGE, TUNING.DEERCLOPS_AOE_SCALE)
    inst.components.combat.hiteffectsymbol = "hit_target" -- "wormmovefx"
    inst.components.combat:SetAttackPeriod(TUNING.PUGALISK_ATTACK_PERIOD/2)
    inst.components.combat:SetRetargetFunction(0.5, RetargetTailFn)
	inst.components.combat:SetKeepTargetFunction(keeptargetfn)
    inst.components.combat.onhitfn = OnHit
	inst.components.combat.redirectdamagefn = redirectdamagefn
	inst.components.combat.StopTrackingTarget = function(self,target)
		if self.losetargetcallback and type(self.losetargetcallback) == "function" then 
			self.inst:RemoveEventCallback("enterlimbo", self.losetargetcallback, target)
			self.inst:RemoveEventCallback("onremove", self.losetargetcallback, target)
		end 
	end

    ------------------------------------------

    inst:AddComponent("locomotor")

    ------------------------------------------

    inst:AddComponent("lootdropper")

    ------------------------------------------

    inst:AddComponent("inspectable")
    inst.components.inspectable:SetDescription("灵活而又致命的尾部")

    ------------------------------------------

    inst.persists = false

    ------------------------------------------
    inst:SetStateGraph("SGpugalisk_head")

    local brain = require "brains/pugalisk_tailbrain"
    inst:SetBrain(brain)    

    return inst
end

--===========================================================


local function CalcSanityAura(inst, observer)
    return -TUNING.SANITYAURA_LARGE
end

local function onhostdeath(inst)

    --TheCamera:Shake("FULL",3, 0.05, .2)
    local mb = inst.components.multibody
    for i,body in ipairs(mb.bodies)do
		body.components.health:SetInvincible(false) 
        body.components.health:Kill()
		body.SoundEmitter:PlaySound("dontstarve/common/blackpowder_explo")
    end
    if mb.tail and mb.tail:IsValid() then
		if mb.tail.components.health and not mb.tail.components.health:IsDead() then 
			mb.tail.components.health:SetInvincible(false) 
			mb.tail.components.health:Kill()
			mb.tail.SoundEmitter:PlaySound("dontstarve/common/blackpowder_explo")
		end 
    end 

    if inst.home and inst.home.reactivate then
        inst.home.reactivate(inst.home)
    end    
    mb:Kill()

    local ent = TheSim:FindFirstEntityWithTag("pugalisk_trap_door")
    if ent and ent.reactivate then
        ent.reactivate(ent)
    end
end

local function onhostremove(inst)
	local mb = inst.components.multibody
    for i,body in ipairs(mb.bodies)do
        body:Remove()
    end
    if mb.tail and mb.tail:IsValid() then
		mb.tail:Remove()
    end 

    if inst.home and inst.home.reactivate then
        inst.home.reactivate(inst.home)
    end    
    mb:Kill()

    local ent = TheSim:FindFirstEntityWithTag("pugalisk_trap_door")
    if ent and ent.reactivate then
        ent.reactivate(ent)
    end
end 

local function OnSave(inst, data)
    
    local refs = {} 
    if inst.home then
        data.home = inst.home.GUID
        table.insert(refs,inst.home.GUID)
    end
    return refs
end

local function OnLoadPostPass(inst, newents, data)
    if data and data.home then
        local home = newents[data.home].entity
        if home then
            print("FOUND HOME, RELOADING IT")
            inst.home = home
        end
    end
end

local function PushMusic(inst)
    if ThePlayer == nil then
        inst._playingmusic = false
    elseif ThePlayer:IsNear(inst, inst._playingmusic and 40 or 20) then
		--print(inst,ThePlayer,"Push the triggeredevent at",GetTime())
        inst._playingmusic = true
        ThePlayer:PushEvent("triggeredevent", { name = "pugalisk" ,duration = 3})
    elseif inst._playingmusic and not ThePlayer:IsNear(inst, 50) then
        inst._playingmusic = false
    end
end

local function EquipWeapon(inst)
    if inst.components.inventory and not inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS) then
        local weapon = CreateEntity()
        --[[Non-networked entity]]
        weapon.entity:AddTransform()
        weapon:AddComponent("weapon")
        weapon.components.weapon:SetDamage(3)
        weapon.components.weapon:SetRange(30, 34)
        weapon.components.weapon:SetProjectile("fireball_projectile")
        weapon:AddComponent("inventoryitem")
        weapon.persists = false
        weapon.components.inventoryitem:SetOnDroppedFn(weapon.Remove)
        weapon:AddComponent("equippable")
        
        inst.components.inventory:Equip(weapon)
		
		return weapon
    end
end

local function RemoveWeapon(inst)
	local weapon = inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
	if weapon  then 
		weapon:Remove()
	end
end 

local function fn(Sim)
    local inst = CreateEntity()
    local trans = inst.entity:AddTransform()
    local anim = inst.entity:AddAnimState()
    local sound = inst.entity:AddSoundEmitter()
	inst.entity:AddNetwork()

    inst.Transform:SetSixFaced()

    MakeObstaclePhysics(inst, 1)

    local s = 1.5
    trans:SetScale(s,s,s)

    anim:SetBank("giant_snake")
    anim:SetBuild("python_test") --"python"
    anim:PushAnimation("head_idle_loop", true)

    inst.AnimState:SetFinalOffset( 0 )

    ------------------------------------------

    inst:AddTag("epic")
	inst:AddTag("noepicmusic")
    inst:AddTag("monster")
    inst:AddTag("hostile")
    inst:AddTag("pugalisk")
    inst:AddTag("scarytoprey")
    inst:AddTag("largecreature")
    inst:AddTag("groundpoundimmune")    
    inst:AddTag("head")    
    inst:AddTag("noflinch")
    inst:AddTag("noteleport")
	inst:AddTag("tadalin")
	inst:AddTag("prey")

    ------------------------------------------  
	
	inst._playingmusic = false
	if not TheNet:IsDedicated() then
        inst:DoPeriodicTask(1, PushMusic,0)
    end
	
	inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.GazeNum = 0
	
	inst:AddComponent("inventory")
	
    inst:AddComponent("sanityaura")
    inst.components.sanityaura.aurafn = CalcSanityAura

    ------------------------------------------   

    inst:AddComponent("combat")
    inst.components.combat:SetDefaultDamage(TUNING.PUGALISK_DAMAGE)
    inst.components.combat.playerdamagepercent = 0.75
    inst.components.combat:SetRange(TUNING.BEARGER_ATTACK_RANGE, TUNING.PUGALISK_MELEE_RANGE)
	--inst.components.combat:SetAreaDamage(TUNING.BEARGER_ATTACK_RANGE, TUNING.DEERCLOPS_AOE_SCALE)
    inst.components.combat.hiteffectsymbol = "hit_target" -- "wormmovefx"
    inst.components.combat:SetAttackPeriod(TUNING.PUGALISK_ATTACK_PERIOD)
    inst.components.combat:SetRetargetFunction(0.5, RetargetFn)
	inst.components.combat:SetKeepTargetFunction(keeptargetfn)
    inst.components.combat.onhitfn = OnHit
	local old_StopTrackingTarget = inst.components.combat.StopTrackingTarget
	inst.components.combat.StopTrackingTarget = function(self,target)
		if self.losetargetcallback and type(self.losetargetcallback) == "function" then 
			return old_StopTrackingTarget(self,target)
		end 
	end

    ------------------------------------------

    inst:AddComponent("lootdropper")
    
    ------------------------------------------    
--[[    
    inst:AddComponent("sleeper")
    inst.components.sleeper:SetResistance(4)
    ]]
    ------------------------------------------       

    inst:AddComponent("inspectable")
    inst.components.inspectable.nameoverride = "pugalisk"
	inst.components.inspectable:SetDescription("这就是世界吞噬者")
    inst.name = STRINGS.NAMES.PUGALISK
    
    ------------------------------------------

    inst:AddComponent("health")
    inst.components.health:SetMaxHealth(TUNING.PUGALISK_HEALTH)
    inst.components.health.destroytime = 5
    inst.components.health:StartRegen(1, 2)
    --inst.components.health.redirect = redirecthealth

    ------------------------------------------

    inst:AddComponent("knownlocations")
    
    ------------------------------------------
    
    inst:AddComponent("locomotor")

    ------------------------------------------

    inst:AddComponent("groundpounder")
    inst.components.groundpounder.destroyer = true
    inst.components.groundpounder.damageRings = 2
    inst.components.groundpounder.destructionRings = 1
    inst.components.groundpounder.numRings = 2
    inst.components.groundpounder.groundpounddamagemult = 30/TUNING.PUGALISK_DAMAGE
    inst.components.groundpounder.groundpoundfx= "groundpound_fx"

    ------------------------------------------
    
    inst:AddComponent("multibody")    
    inst.components.multibody:Setup(8,"pugalisk_body")   
    
    ------------------------------------------    

    inst:ListenForEvent("healthdelta", function(inst, data)
        print("TOOK DAMAGE",inst.components.health.currenthealth)
    end)

    inst:ListenForEvent("bodycomplete", function(inst, data) 
        local pt = pu.findsafelocation( data.pos , data.angle/DEGREES )
        inst.Transform:SetPosition(pt.x,0,pt.z)
        inst:DoTaskInTime(0.75, function() 

            dogroundpound(inst)
            
            inst.SoundEmitter:PlaySound("dontstarve_DLC003/creatures/boss/pugalisk/emerge","emerge")
            inst.SoundEmitter:SetParameter( "emerge", "start", math.random() )
            
            pu.DetermineAction(inst)
        end)
    end)     
    
    inst:ListenForEvent("bodyfinished", function(inst, data) 
            inst.components.multibody:RemoveBody(data.body)
        end)

    inst:ListenForEvent("death", function(inst, data)        
        onhostdeath(inst)        
    end)
	
	--[[inst:ListenForEvent("onremove", function(inst, data)        
        onhostremove(inst)  
    end)
--]]
    inst.spawntask = inst:DoTaskInTime(0,function() 
            inst.spawned = true
        end)
    
    inst:SetStateGraph("SGpugalisk_head")

    local brain = require "brains/pugalisk_headbrain"
    inst:SetBrain(brain)

    inst.OnSave = OnSave 
    --inst.OnLoad = onload
    inst.OnLoadPostPass = OnLoadPostPass
	inst.EquipWeapon = EquipWeapon
	inst.RemoveWeapon = RemoveWeapon

    return inst
end

return  Prefab( "common/monsters/pugalisk", fn, assets, prefabs),
        Prefab( "common/monsters/pugalisk_body", bodyfn, assets, prefabs),
        Prefab( "common/monsters/pugalisk_tail", tailfn, assets, prefabs),
        Prefab( "common/monsters/pugalisk_segment", segmentfn, assets, prefabs)