require("stategraphs/commonstates")

local actionhandlers =
{

}

local events =
{
    EventHandler("attacked", function(inst) 
        if not inst.components.health:IsDead() 
            and not inst.sg:HasStateTag("hit") 
            and not inst.sg:HasStateTag("attack") 
            and not inst.sg:HasStateTag("casting") 
        then inst.sg:GoToState("hit") 
        end 
    end),
    EventHandler("death", function(inst) inst.sg:GoToState("death", inst.sg.statemem.dead) end),
    EventHandler("doattack", function(inst, data) if not inst.components.health:IsDead() and (inst.sg:HasStateTag("hit") or not inst.sg:HasStateTag("busy")) then inst.sg:GoToState("attack", data.target) end end),
	EventHandler("comboattack", function(inst, target) 
		if not inst.components.health:IsDead() 
			and (inst.sg:HasStateTag("hit") 
			    or not inst.sg:HasStateTag("busy")) 
        then 
            inst.sg:GoToState("combofirsthit", target) 
		end 
	end),
    EventHandler("meteorshower", function(inst) 
		if not inst.components.health:IsDead() 
			and (inst.sg:HasStateTag("hit") 
			or not inst.sg:HasStateTag("busy")) 
        then 
            inst.sg:GoToState("cast") 
		end 
	end),
	EventHandler("whirlwind", function(inst) 
		if not inst.components.health:IsDead() 
			and (inst.sg:HasStateTag("hit") 
			or not inst.sg:HasStateTag("busy")) 
        then 
            inst.sg:GoToState("whirlwind") 
		end 
	end),
	EventHandler("groundslam", function(inst) 
		if not inst.components.health:IsDead() 
			and (inst.sg:HasStateTag("hit") 
			or not inst.sg:HasStateTag("busy")) 
        then 
            inst.sg:GoToState("groundslam") 
		end 
	end),
    --CommonHandlers.OnSleep(),
    CommonHandlers.OnLocomote(false, true),
    --CommonHandlers.OnFreeze(),
	--CommonHandlers.OnAttacked(),
}

local function ShakeIfClose(inst)
    ShakeAllCameras(CAMERASHAKE.FULL, .5, .02, .2, inst, 30)
end

local function ShakeIfCloseSlam(inst)
    ShakeAllCameras(CAMERASHAKE.FULL, .7, .04, .2, inst, 30)
end

local function ShakeRoar(inst)
    ShakeAllCameras(CAMERASHAKE.FULL, 0.7, .03, .5, inst, 30)
end

local function Explode(inst)
	local pos = inst:GetPosition()
	inst:StartThread(function()
		for i = 1,25 do 
			for i = 1,25 do 
				local rad = math.random(0.3,10)
				local roa = math.random()*2*math.pi
				local offset = Vector3(rad*math.cos(roa),0,rad*math.sin(roa))
				local nx,ny,nz = (pos+offset):Get()
				local fx = SpawnPrefab("halloween_firepuff_cold_"..tostring(math.random(1,3)))
				local ents = TheSim:FindEntities(nx,ny,nz, 2, { "_combat" }, {"playerghost", "INLIMBO","tadalin" })
				local scale = 0.7 + math.random() * 2 
				fx.Transform:SetPosition(nx,ny,nz)
				fx.Transform:SetScale(scale,scale,scale)
				for k,v in pairs(ents) do 
					if v and v:IsValid() and v.components.health and not v.components.health:IsDead() and v.components.combat then 
						v.components.combat:GetAttacked(inst,math.random()*1000)
					end
				end
			end 
			Sleep(math.random()*0.1)
		end
	end)
end 

local function oncast(inst)
	local impactfx1 = SpawnPrefab("deer_ice_charge")
	if impactfx1 ~= nil then
		impactfx1.Transform:SetScale(2,2,2)
		local follower1 = impactfx1.entity:AddFollower()
		follower1:FollowSymbol(inst.GUID,"head", 0, 0, 0)
		impactfx1:DoTaskInTime(2,impactfx1.KillFX)
	end
end 

local function onexitcast(inst)
	
end 

local states =
{

    State{
        name = "idle",
        tags = { "idle", "canrotate" },
        onenter = function(inst, playanim)
            --inst.SoundEmitter:PlaySound("dontstarve/creatures/hound/pant")
            inst.Physics:Stop()
            if playanim then
                inst.AnimState:PlayAnimation(playanim)
                inst.AnimState:PushAnimation("idle_loop", true)
            else
                inst.AnimState:PlayAnimation("idle_loop", true)
            end
            inst.sg:SetTimeout(2 * math.random() + .5)
			inst.SoundEmitter:PlaySound("dontstarve/forge2/beetletaur/step")
        end,
		
		events =
        {
            EventHandler("animover", function(inst)
                inst.sg:GoToState("idle")
            end),
        },
    },

    State{
        name = "attack",
        tags = { "attack", "busy" },

        onenter = function(inst, target)
            inst.sg.statemem.target = target
            inst.Physics:Stop()
            --inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/grunt")
			inst.SoundEmitter:PlaySound("dontstarve/forge2/beetletaur/swipe")
            inst.components.combat:StartAttack()
			if (math.random(1, 2) == 1) then
                inst.sg.statemem.attackAnim = 1
				inst.AnimState:PlayAnimation("attack1")
				inst.AnimState:PushAnimation("attack1_pst", false)
			else
                inst.sg.statemem.attackAnim = 2
				inst.AnimState:PlayAnimation("attack3")
			end
            --inst.AnimState:PushAnimation("attack", false)
        end,
		
		onexit = function(inst)
			inst.SoundEmitter:KillSound("talk")
		end,

        timeline =
        {
            TimeEvent(3 * FRAMES, function(inst) 
				if inst.sg.statemem.attackAnim == 2 then
					inst.components.combat:DoAttack(inst.sg.statemem.target) 
					inst.SoundEmitter:PlaySound("dontstarve/forge2/beetletaur/swipe")
					inst.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/fossil_spike")
                end
			end),
			TimeEvent(5 * FRAMES, function(inst) 
				--inst.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/taunt_short")
				inst.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/talk_LP","talk")
			end),
			TimeEvent(11*FRAMES, function(inst)
				if inst.sg.statemem.attackAnim == 1 then
					inst.components.combat:DoAttack()
					inst.components.combat:DoAreaAttack(inst.components.combat.target or inst, 3, nil, nil, nil, {"LA_mob", "shadow", "INLIMBO", "playerghost", "battlestandard","tadalin"}) 
					inst.SoundEmitter:PlaySound("dontstarve/forge2/beetletaur/swipe")
				end 
			end),
        },

        events =
        {
            EventHandler("animover", function(inst) 
				inst.sg:GoToState("idle")
			end),
        },
    },
	
    State{
        name = "hit",
        tags = { "busy", "hit" },

        onenter = function(inst)
            inst.Physics:Stop()
            --inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/hit")
			--inst.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/hit")
			inst.SoundEmitter:PlaySound("dontstarve/forge2/beetletaur/chain_hit")
            inst.AnimState:PlayAnimation("hit")
        end,

        events =
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end),
        },
    },

    State{
        name = "taunt",
        tags = { "busy" },

        onenter = function(inst)
            inst.Physics:Stop()
            inst.AnimState:PlayAnimation("taunt")
        end,

        timeline =
        {
			TimeEvent(13 * FRAMES, function(inst) 
				inst.taunt_shield_fx = SpawnPrefab("icey_shield")
				inst.taunt_shield_fx.AnimState:SetMultColour(0/255,218/255,164/255,0.8)
				inst.taunt_shield_fx.entity:SetParent(inst.entity)  
				inst.taunt_shield_fx.Transform:SetScale(3,3,3)       
				inst.taunt_shield_fx.Transform:SetPosition(0,-1,0) 
			end),
            TimeEvent(13 * FRAMES, function(inst) 
				--inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/taunt") 
				inst.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/taunt")
			end),
        },

        events =
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end),
        },
    },

    State{
        name = "death",
        tags = { "busy" },

        onenter = function(inst)

            inst.Physics:Stop()
            inst.AnimState:PlayAnimation("taunt")
            --inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/death") 
           
        end,

        timeline =
        {
			TimeEvent(13 * FRAMES, function(inst) 
				inst.taunt_shield_fx = SpawnPrefab("icey_shield")
				inst.taunt_shield_fx.AnimState:SetMultColour(0/255,218/255,164/255,0.8)
				inst.taunt_shield_fx.entity:SetParent(inst.entity)  
				inst.taunt_shield_fx.Transform:SetScale(3,3,3)       
				inst.taunt_shield_fx.Transform:SetPosition(0,-1,0) 
			end),
            TimeEvent(13 * FRAMES, function(inst) 
				--inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/taunt") 
				inst.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/taunt")
			end),
        },
		
		events =
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("death_attack") end),
        },
    },
	
	State{
        name = "death_attack", --------------��ת
        tags = { "busy", "casting" },
        onenter = function(inst)
			inst.Physics:Stop()
			inst.AnimState:PlayAnimation("attack4") 
            --inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/spin")
			--inst.SoundEmitter:PlaySound("dontstarve/forge2/beetletaur/attack")
			inst.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/talk_LP","talk")
			inst.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/taunt")
            inst.lastWirlWind = GetTime()
        end,

        onexit = function(inst)
            inst.wwHitList = {}
			inst.SoundEmitter:KillSound("talk")
        end,
		
		timeline =
        {
            TimeEvent(13 * FRAMES, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve/common/fishingpole_lostrod") 
				inst.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/fossil_spike")
                inst:WhirlWind(inst) 
            end),
			TimeEvent(16 * FRAMES, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve/common/fishingpole_lostrod") 
				inst.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/fossil_spike")
                inst:WhirlWind(inst) 
            end),
			TimeEvent(19 * FRAMES, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve/common/fishingpole_lostrod") 
				inst.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/fossil_spike")
                inst:WhirlWind(inst) 
            end),
            TimeEvent(24 * FRAMES, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve/common/fishingpole_lostrod") 
				inst.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/fossil_spike")
                inst:WhirlWind(inst) 
            end),
			
        },

		events =
        {
            EventHandler("animover", function(inst)
                inst:ReTarget(inst)
                inst.sg:GoToState("death_final")
            end),
        },
    },
	
	State{
        name = "death_final",
        tags = { "busy" },

        onenter = function(inst)

            inst.Physics:Stop()
            inst.AnimState:PlayAnimation("death2")
            --inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/death") 
            RemovePhysicsColliders(inst)

            inst.components.lootdropper:DropLoot(inst:GetPosition())
        end,

        timeline =
        {
		
			TimeEvent(0*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/taunt") end),
            TimeEvent(FRAMES * 7, function(inst)
                inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/bone_drop_stick")
            end),
            TimeEvent(FRAMES * 8, function(inst)
                inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/bone_drop_stick")
            end),
            TimeEvent(FRAMES * 16, function(inst)
                inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/death_bodyfall")
            end),
			
			TimeEvent(30*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/bonehit1") end),
			TimeEvent(50*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/bonehit1") end),
			TimeEvent(55*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/death_bodyfall") end),
			TimeEvent(70*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/bonehit2") end),
			TimeEvent(55*FRAMES, ShakeRoar),
			TimeEvent(300*FRAMES, Explode),
			TimeEvent(320*FRAMES, ErodeAway),
			
        },
    },

    State{
        name = "forcesleep",
        tags = { "busy", "sleeping" },

        onenter = function(inst)
            inst.components.locomotor:StopMoving()
            inst.AnimState:PlayAnimation("sleep_loop", true)
        end,
    },
	
	State{
        name = "cast",
        tags = { "busy", "casting" },
        onenter = function(inst)
			inst.Physics:Stop()
			inst.AnimState:PlayAnimation("banner_pre", false)
            inst.AnimState:PushAnimation("banner_loop", false)
            --inst.sg:SetTimeout(5)
            inst.sg.statemem.loops = 0
            
            inst.lastGroundBurn = GetTime()
            inst.sg.statemem.gbdone = false
			inst.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/taunt")
			oncast(inst)
        end,
		
		onexit = function(inst)
			onexitcast(inst)
			inst:StopGroundBurn()
		end,

        events = {
            EventHandler("animover", function(inst)
                if inst.AnimState:IsCurrentAnimation("banner_loop") and inst.sg.statemem.loops <= 3 then
                    --print("need to play sound")
                    if not inst.sg.statemem.gbdone then
                        inst:GroundBurn()
                        inst.sg.statemem.gbdone = true
                    end
                    inst.AnimState:PlayAnimation("banner_loop", false)
                    inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/bone_drop_stick")
					inst.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/fossil_spike")
                    inst.sg.statemem.loops = inst.sg.statemem.loops + 1
                else
                    inst.AnimState:PlayAnimation("banner_pst")
			        inst.sg:GoToState("idle")
                end
            end)
        },
    },
	
	State{
        name = "whirlwind", --------------��ת
        tags = { "busy", "casting" },
        onenter = function(inst)
			inst.Physics:Stop()
			inst.AnimState:PlayAnimation("attack4") 
            --inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/spin")
			--inst.SoundEmitter:PlaySound("dontstarve/forge2/beetletaur/attack")
			inst.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/talk_LP","talk")
			inst.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/taunt")
            inst.lastWirlWind = GetTime()
        end,

        onexit = function(inst)
            inst.wwHitList = {}
			inst.SoundEmitter:KillSound("talk")
        end,
		
		timeline =
        {
            TimeEvent(13 * FRAMES, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve/common/fishingpole_lostrod") 
				inst.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/fossil_spike")
                inst:WhirlWind(inst) 
            end),
            TimeEvent(24 * FRAMES, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve/common/fishingpole_lostrod") 
				inst.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/fossil_spike")
                inst:WhirlWind(inst) 
            end),
        },

		events =
        {
            EventHandler("animover", function(inst)
                inst:ReTarget(inst)
                inst.sg:GoToState("idle")
            end),
        },
    },
	
	State{
        name = "groundslam",
        tags = { "casting", "busy" },

        onenter = function(inst)
            inst.Physics:Stop()

            local x, y, z = inst.Transform:GetWorldPosition()
			inst.Transform:SetEightFaced()
			local target = FindClosestPlayerInRange(x, y, z, 20, true)
            if target ~= nil then
                inst.AnimState:PlayAnimation("attack5")
				inst.sg.mem.slamTarget = target
				local tx, ty, tz = target.Transform:GetWorldPosition()
				inst:ForceFacePoint(tx, ty, tz)
                inst.components.combat.laststartattacktime = GetTime()
			else
				inst.sg:GoToState("idle")
			end
        end,
		
		onexit = function(inst)
			inst.Transform:SetFourFaced()
		end,

        timeline =
        {
			TimeEvent(10 * FRAMES, function(inst) 
				inst:GroundSlam(inst.sg.mem.slamTarget)
                inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/bonehit2")
                inst.lastGroundSlam = GetTime()
                inst.components.combat.laststartattacktime = GetTime()
            end),
			
			TimeEvent(16*FRAMES, function(inst) 
				inst.sg:AddStateTag("nocancel")
				local target = inst.components.combat.target
				if target and target:IsValid() then
					local x,y,z  = target.Transform:GetWorldPosition()
					inst:FacePoint(x,y,z)
					inst:DoTrail(x, z)
					inst.targetx,inst.targety,inst.targetz = x,y,z 
				end
			end),
			
			TimeEvent(35*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve/forge2/beetletaur/chain_hit") end),
			TimeEvent(37*FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve/forge2/beetletaur/chain_hit") end),
			TimeEvent(37*FRAMES, ShakeIfClose),
			TimeEvent(37*FRAMES, function(inst) 
				--inst.components.combat:DoAreaAttack(inst, 5, nil, nil, nil, {"LA_mob", "battlestandard", "shadow", "INLIMBO", "playerghost"}) 
				if inst.targetx and inst.targetz then	 
					inst:DoTrail(inst.targetx, inst.targetz, true)
				end	
				inst.sg:RemoveStateTag("nocancel")
			end),

            TimeEvent(40 * FRAMES, function(inst) 
				--inst.sg:RemoveStateTag("attack")
                --inst.sg:RemoveStateTag("busy")
			end),
        },

        events =
        {
            EventHandler("animqueueover", function(inst) 
				if math.random() < 0.8 then 
					inst.sg:GoToState("taunt") 
				else 
					inst.sg:GoToState("idle")
				end
			end),
        },
    },

    State{
        name = "dash",
        tags = { "busy", "attack" },
        onenter = function(inst)
            inst.components.locomotor:Stop()
            inst:ClearBufferedAction()

			inst.AnimState:PlayAnimation("dash") 
            inst.sg.statemem.dashspeed = 1
            inst.Physics:SetMotorVel(inst.sg.statemem.dashspeed, 0, 0)
        end,

        onupdate = function(inst)
            inst.Physics:SetMotorVel(inst.sg.statemem.dashspeed, 0, 0)
        end,
		
		timeline =
        {
            TimeEvent(3 * FRAMES, function(inst) 
                inst.sg.statemem.dashspeed = 12
            end),
            TimeEvent(3 * FRAMES, function(inst) 
                inst.sg.statemem.dashspeed = 20
            end),
            TimeEvent(3 * FRAMES, function(inst) 
                inst.sg.statemem.dashspeed = 12
            end),
            TimeEvent(9 * FRAMES, function(inst)
                inst.sg.statemem.dashspeed = 0 
            end),
        },

		events =
        {
            EventHandler("animover", function(inst)
                inst.Physics:ClearMotorVelOverride()
                inst.sg:GoToState("combothirdhit")
            end),
        },

        onexit = function(inst)
            inst.components.locomotor:Stop()
            inst.Physics:ClearMotorVelOverride()
        end,
    },
	
	State{
        name = "combofirsthit",
        tags = { "busy", "attack" },
        onenter = function(inst, target)
            inst.Physics:Stop()
            if target and target:IsValid() then 
                inst.sg.statemem.target = target
                inst:ForceFacePoint(target.Transform:GetWorldPosition())
                --inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/stun")
				--inst.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/taunt_short")
				inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/swipe_pre")
                inst.AnimState:PlayAnimation("attack1") 
                inst.lastCombo = GetTime()
            end
        end,
		
		timeline =
        {
            TimeEvent(12 * FRAMES, function(inst) --20 frames total
                inst.components.combat:DoAttack(inst.sg.statemem.target) 
				inst.components.combat:DoAreaAttack(inst.components.combat.target or inst, 3, nil, nil, nil, {"LA_mob", "shadow", "INLIMBO", "playerghost", "battlestandard","tadalin"}) 
				inst.SoundEmitter:PlaySound("dontstarve/forge2/beetletaur/swipe")
				inst.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/taunt_short")
            end), 
        },

		events =
        {
            EventHandler("animover", function(inst)
                inst.sg:GoToState("combosecondhit", inst.sg.statemem.target)
            end),
        },
    },
	
	State{
        name = "combosecondhit",
        tags = { "busy", "attack" },
        onenter = function(inst, target)
            if target and target:IsValid() then --inst.components.combat:CanAttack(inst.sg.statemem.target) then
                inst.sg.statemem.target = target
                inst.Physics:Stop()
                inst.AnimState:PlayAnimation("attack2") 
            else
                inst.sg:GoToState("idle")
            end
        end,
		
		timeline =
        {
            TimeEvent(3 * FRAMES, function(inst) -- 9 frames total
                inst.components.combat:DoAttack(inst.sg.statemem.target) 
            end), 
        },

		events =
        {
            EventHandler("animover", function(inst)
                inst.sg:GoToState("combothirdhit", inst.sg.statemem.target)
                --inst.sg:GoToState("dash")
            end),
        },
    },
	
	State{
        name = "combothirdhit",
        tags = { "busy", "attack" },
        onenter = function(inst, target)
            if target and target:IsValid()
                and not target.components.health:IsDead() 
            then
                inst.Physics:Stop()
                inst.sg.statemem.target = target
                --inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/stun")
                inst:ForceFacePoint(target.Transform:GetWorldPosition())
                inst.AnimState:PlayAnimation("attack3") 
            else
                inst.sg:GoToState("idle")
            end
        end,
		
		timeline =
        {
            TimeEvent(7 * FRAMES, function(inst) --25 frames total
                local sm = inst.sg.statemem
                if sm.target and sm.target:IsValid()
                    and not sm.target.components.health:IsDead() 
                then
                    inst:ComboHit(sm.target)
                end
                inst:ReTarget(inst)
                inst.components.combat.laststartattacktime = GetTime()
            end), 
        },

		events =
        {
            EventHandler("animover", function(inst)
                inst.sg:GoToState("idle")
            end),
        },
    },

}

--[[CommonStates.AddSleepStates(states,
{
    sleeptimeline = {
        --TimeEvent(0, function(inst) inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/sleep_out") end),
        --TimeEvent(9 * FRAMES, function(inst) inst.SoundEmitter:PlaySound("dontstarve/creatures/lava_arena/boarrior/sleep_in") end),
		TimeEvent(0, function(inst) inst.SoundEmitter:PlaySound("dontstarve/forge2/beetletaur/step")  end),
		
    },
})--]]

CommonStates.AddWalkStates(states,
{
    walktimeline =
    {
        TimeEvent(0, function(inst) 
            --ShakeAllCameras(CAMERASHAKE.VERTICAL, .5, .03, 1, inst, 30)
            --inst.SoundEmitter:PlaySound("dontstarve/common/dust_blowaway") 
			inst.SoundEmitter:PlaySound("dontstarve/forge2/beetletaur/step")
        end),
		TimeEvent(5, function(inst) 
            --ShakeAllCameras(CAMERASHAKE.VERTICAL, .5, .03, 1, inst, 30)
            --inst.SoundEmitter:PlaySound("dontstarve/common/dust_blowaway") 
			inst.SoundEmitter:PlaySound("dontstarve/forge2/beetletaur/step")
        end),
		TimeEvent(10, function(inst) 
            --ShakeAllCameras(CAMERASHAKE.VERTICAL, .5, .03, 1, inst, 30)
            --inst.SoundEmitter:PlaySound("dontstarve/common/dust_blowaway") 
			inst.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/taunt")
			inst.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/out")
			inst.SoundEmitter:PlaySound("dontstarve/forge2/beetletaur/step")
        end),
		TimeEvent(15, function(inst) 
            --ShakeAllCameras(CAMERASHAKE.VERTICAL, .5, .03, 1, inst, 30)
            --inst.SoundEmitter:PlaySound("dontstarve/common/dust_blowaway") 
			inst.SoundEmitter:PlaySound("dontstarve/forge2/beetletaur/step")
        end),
        TimeEvent(18, function(inst) 
            --ShakeAllCameras(CAMERASHAKE.VERTICAL, .5, .03, 1, inst, 30)
            --inst.SoundEmitter:PlaySound("dontstarve/common/dust_blowaway") 
			inst.SoundEmitter:PlaySound("dontstarve/creatures/together/stalker/out")
			inst.SoundEmitter:PlaySound("dontstarve/forge2/beetletaur/step")
        end),
		TimeEvent(25, function(inst) 
            --ShakeAllCameras(CAMERASHAKE.VERTICAL, .5, .03, 1, inst, 30)
            --inst.SoundEmitter:PlaySound("dontstarve/common/dust_blowaway") 
			inst.SoundEmitter:PlaySound("dontstarve/forge2/beetletaur/step")
        end),
    },
})

CommonStates.AddFrozenStates(states)

return StateGraph("SGboss_elecarmet", states, events, "taunt", actionhandlers)
