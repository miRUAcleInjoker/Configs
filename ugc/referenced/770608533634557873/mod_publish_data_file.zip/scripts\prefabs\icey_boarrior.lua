--[[
Copyright (C) 2018 Forged Forge

This file is part of Forged Forge.

The source code of this program is shared under the RECEX
SHARED SOURCE LICENSE (version 1.0).
The source code is shared for referrence and academic purposes
with the hope that people can read and learn from it. This is not
Free and Open Source software, and code is not redistributable
without permission of the author. Read the RECEX SHARED
SOURCE LICENSE for details 
The source codes does not come with any warranty including
the implied warranty of merchandise. 
You should have received a copy of the RECEX SHARED SOURCE
LICENSE in the form of a LICENSE file in the root of the source
directory. If not, please refer to 
<https://raw.githubusercontent.com/Recex/Licenses/master/SharedSourceLicense/LICENSE.txt>
]]
--------以下代码由熔炉mod制作组编写
--------至此向他们表示崇高的敬意
local TadalinUtil = require("tadalin_util")

local assets =
{
    Asset("ANIM", "anim/lavaarena_boarrior_basic.zip"),
	--Asset("ANIM", "anim/lavaarena_boarrior_fx.zip"),
	Asset("ANIM", "anim/lavaarena_boarrior_alt1.zip"),
	Asset("ANIM", "anim/lavaarena_boarrior_alt2.zip"),
	
	Asset("ANIM", "anim/icey_boarrior_weaponswap.zip"),
	Asset("ANIM", "anim/icey_boarrior_weaponswap_fire.zip"),
	
}

local prefabs =
{

}

local brain = require("brains/boarriorbrain")

SetSharedLootTable( 'icey_boarrior',
{
	--{'icey_boarrior_cinder',  1.0},
})

	

local WAKE_TO_FOLLOW_DISTANCE = 8
local SLEEP_NEAR_HOME_DISTANCE = 10
local SHARE_TARGET_DIST = 30
local HOME_TELEPORT_DIST = 30

local NO_TAGS = { "FX", "NOCLICK", "DECOR", "INLIMBO" }

local function PushMusic(inst)
    if ThePlayer == nil then
        inst._playingmusic = false
    elseif ThePlayer:IsNear(inst, inst._playingmusic and 40 or 20) then
		--print(inst,ThePlayer,"Push the triggeredevent at",GetTime())
        inst._playingmusic = true
        ThePlayer:PushEvent("triggeredevent", { name = "icey_boarrior" ,duration = 3})
    elseif inst._playingmusic and not ThePlayer:IsNear(inst, 50) then
        inst._playingmusic = false
    end
end

local function SpawnFireSpike(pos,name) ---halloween_firepuff_1 halloween_firepuff_2 halloween_firepuff_3
	local fx = SpawnPrefab(name or "halloween_firepuff_1")
	fx.Transform:SetPosition(pos:Get())
end 

local function oncollapse(inst, other)
    if other:IsValid() and other.components.workable ~= nil and other.components.workable:CanBeWorked() then
        SpawnPrefab("collapse_small").Transform:SetPosition(other.Transform:GetWorldPosition())
        other.components.workable:Destroy(inst)
    end
end

local function oncollide(inst, other)
    if other ~= nil and --HasTag implies IsValid
        Vector3(inst.Physics:GetVelocity()):LengthSq() >= 1 then
        inst:DoTaskInTime(2 * FRAMES, oncollapse, other)
    end
end

local function OnNewTarget(inst, data)
    if inst.components.sleeper:IsAsleep() then
        inst.components.sleeper:WakeUp()
    end
end

local function FindPlayerTarget(inst)
	local player, distsq = inst:GetNearestPlayer()
	if player then
		if not inst.components.follower.leader then --Don't attempt to find a target that isn't the leader's target. 
			return not (player:HasTag("notarget") or player:HasTag("LA_mob")) and (player and not player.components.health:IsDead()) and player
		end
	end
end

local function AttemptNewTarget(inst, target)
	local player, distsq = inst:GetNearestPlayer()
    if target ~= nil and inst:IsNear(target, 20) and player then
		return target
	else
		return not (player:HasTag("notarget") or player:HasTag("LA_mob")) and (player and not player.components.health:IsDead()) and player and player
	end
end

local function retargetfn(inst)
    local player, distsq = inst:GetNearestPlayer()
    return (player and not player.components.health:IsDead()) and player or FindEntity(inst, 255, function(guy) return inst.components.combat:CanTarget(guy) and not guy.components.health:IsDead() and inst.components.follower.leader ~= guy end, nil, { "tadalin","wall", "LA_mob", "battlestandard" })
end

-------------------------------------------------------
--Knockback--
local REPEL_RADIUS = 5
local REPEL_RADIUS_SQ = REPEL_RADIUS * REPEL_RADIUS

local function OnHitOther(inst, other) --knockback
	oncollide(inst, other)
	if not inst.is_doing_special then
	if other.sg and other.sg.sg.events.knockback then
		other:PushEvent("knockback", {knocker = inst, radius = 5})
	else
	--this stuff below is mostly left here for creatures in basegame. For modders that are reading this, use the knockback event above.
	if other ~= nil and not (other:HasTag("epic") or other:HasTag("largecreature")) then
		
		if other:IsValid() and other.entity:IsVisible() and not (other.components.health ~= nil and other.components.health:IsDead()) then
            if other.components.combat ~= nil then
                --other.components.combat:GetAttacked(inst, 10)
                if other.Physics ~= nil then
					local x, y, z = inst.Transform:GetWorldPosition()
                    local distsq = other:GetDistanceSqToPoint(x, 0, z)
					--if distsq < REPEL_RADIUS_SQ then
						if distsq > 0 then
							other:ForceFacePoint(x, 0, z)
						end
						local k = .5 * distsq / REPEL_RADIUS_SQ - 1
						other.speed = 60 * k
						other.dspeed = 2
						other.Physics:ClearMotorVelOverride()
						other.Physics:Stop()
						
						if other.components.inventory and other.components.inventory:ArmorHasTag("heavyarmor") or other:HasTag("heavybody") then 
						--Leo: Need to change this to check for bodyslot for these tags.
						other:DoTaskInTime(0.1, function(inst) 
							other.Physics:SetMotorVelOverride(-2, 0, 0) 
						end)
						else
						other:DoTaskInTime(0, function(inst) 
							other.Physics:SetMotorVelOverride(-20, 0, 0) 
						end)
						end
						other:DoTaskInTime(0.4, function(inst) 
						other.Physics:ClearMotorVelOverride()
						other.Physics:Stop()
						end)
					--end
                end
            end
        end
	end
	end
	end
end

-----------------------------------------------------

local function EnterPhase2Trigger(inst)
	inst.level = 1
	inst.altattack = true
	inst.sg:GoToState("taunt")
end

local function EnterPhase3Trigger(inst)
	if inst.level < 2 then
		inst.level = 2
		inst.altattack = true
		inst.sg.statemem.wants_to_banner = true 
		inst.sg:GoToState("taunt_banner_pre") 
	end
end

local function EnterPhase4Trigger(inst)
	inst.level = 3
	inst.components.combat:SetAttackPeriod(3)
end

-------------------------------------------------------
--Slam Attack Functions--

local groundlifts =
{
}

local function DoTrail(inst, targetposx, targetposz, trailend)
	inst.stopslam = nil --might fix no slam bug?
	local startingpos = inst:GetPosition()
	inst:ForceFacePoint(targetposx, 0, targetposz)
	--if TheWorld.Map:IsAboveGroundAtPoint(targetposx, 0, targetposz) and TheWorld.Pathfinder:IsClear(startingpos.x, startingpos.y, startingpos.z, targetposx, 0, targetposz, {ignorewalls = false, ignorecreep = true}) then
		local targetpos = {x = targetposx, y = 0, z = targetposz}
		local found_players = {}
		
		local angle = -inst.Transform:GetRotation() * DEGREES
		local angled_offset = {x = 1.25 * math.cos(angle+90), y = 0, z = 1.25 * math.sin(angle+90)}
		local angled_offset2 = {x = 1.25 * math.cos(angle), y = 0, z = 1.25 * math.sin(angle)}
		local angled_offset3 = {x = 1.25 * math.cos(angle-90), y = 0, z = 1.25 * math.sin(angle-90)}
		local impact_distance = 36
					
		local maxtrails = 12 + 5
		for i = 1, maxtrails do
			inst:DoTaskInTime(FRAMES*math.ceil(1+i/ (trailend and 1.5 or 3.5)), function()
				local offset = (targetpos - startingpos):GetNormalized()*(i)
				local x, y, z = (startingpos + offset):Get()
				local is_ground = TheWorld.Map:IsAboveGroundAtPoint((startingpos+offset):Get())
				if  not inst.stopslam then
					if i > 6 then
						local stonefx = "lavaarena_groundliftrocks"
						if is_ground then 
							if trailend ~= nil then 
								stonefx = "lavaarena_groundlift"
							end
						else
							stonefx = "splash_sink"
						end 
						SpawnAt(stonefx,startingpos+offset+angled_offset).Transform:SetScale(1.4,1.4,1.4)
						SpawnAt(stonefx,startingpos+offset+angled_offset2).Transform:SetScale(1.4,1.4,1.4)
						SpawnAt(stonefx,startingpos+offset+angled_offset3).Transform:SetScale(1.4,1.4,1.4)
						--[[SpawnPrefab(stonefx).Transform:SetPosition((startingpos+offset+angled_offset2):Get())
						SpawnPrefab(stonefx).Transform:SetPosition((startingpos+offset+angled_offset3):Get())--]]
							
						SpawnFireSpike(startingpos+offset+angled_offset,"halloween_firepuff_"..tostring(math.random(1,3)))
						SpawnFireSpike(startingpos+offset+angled_offset2,"halloween_firepuff_"..tostring(math.random(1,3)))
						SpawnFireSpike(startingpos+offset+angled_offset3,"halloween_firepuff_"..tostring(math.random(1,3)))
							
						if not inst:HasTag("groundspike") then
							inst:AddTag("groundspike")
						end
					end
					local ents = TheSim:FindEntities(x, y, z, 2.5, { "locomotor" }, { "LA_mob", "shadow", "playerghost", "INLIMBO","tadalin" })
					for _,ent in ipairs(ents) do
						if ent ~= inst and inst.components.combat:IsValidTarget(ent) and ent.components.health and not ent.hasbeenhit then
							inst:PushEvent("onareaattackother", { target = ent--[[, weapon = self.inst, stimuli = self.stimuli]] })
							--Leo:Temporary fix for preventing multiple hits.
							ent.components.combat:GetAttacked(inst, i < 6 and 150 or (150 * 0.75 * (not trailend and 0.5 or 1)))
							ent.hasbeenhit = true
							ent:DoTaskInTime(0.25, function(inst) inst.hasbeenhit = nil end)
						--SpawnPrefab("forgespear_fx"):SetTarget(ent)
						end
					end
				else
					inst.stopslam = true
				end	
				if i == maxtrails then
					inst.stopslam = nil
				end
			end)
		end
	--end
end
--[[
inst:DoTaskInTime(FRAMES*math.ceil(1+i/ (trailend and 1.5 or 3.5)), function()
	local angle = -inst.Transform:GetRotation() * DEGREES
	local angled_offset = {x = 1.25 * math.cos(angle+90), y = 0, z = 1.25 * math.sin(angle+90)}
	local angled_offset2 = {x = 1.25 * math.cos(angle-90), y = 0, z = 1.25 * math.sin(angle-90)}
	local offset = (targetpos - startingpos):GetNormalized()*(6+i*1.1)
	if TheWorld.Map:IsAboveGroundAtPoint((startingpos+offset):Get()) and not inst.stopslam then
		SpawnPrefab(trailend ~= nil and "lavaarena_groundlift" or "lavaarena_groundliftrocks").Transform:SetPosition((startingpos+offset+angled_offset):Get()) 
		SpawnPrefab(trailend ~= nil and "lavaarena_groundlift" or "lavaarena_groundliftrocks").Transform:SetPosition((startingpos+offset+angled_offset2):Get()) 
		local x, y, z = (startingpos + offset):Get()
		local ents = TheSim:FindEntities(x, y, z, 2.5, { "locomotor" }, { "LA_mob", "shadow", "playerghost", "INLIMBO" })
		for _,ent in ipairs(ents) do
			if ent ~= inst and inst.components.combat:IsValidTarget(ent) and ent.components.health then
				inst:PushEvent("onareaattackother", { target = ent--, weapon = self.inst, stimuli = self.stimuli })
				--Leo:Temporary fix for preventing multiple hits.
				if not ent.hasbeenhit then
				ent.components.combat:GetAttacked(inst, 200)
				ent.hasbeenhit = true
				ent:DoTaskInTime(0.25, function(inst) inst.hasbeenhit = nil end)
				end
			--SpawnPrefab("forgespear_fx"):SetTarget(ent)
			end
		end


--]]
-------------------------------------------------------

local function KeepTarget(inst, target)
    return inst.components.combat:CanTarget(target) and (target.components.health and not target.components.health:IsDead()) and not target:HasTag("tadalin")
end

local function OnAttacked(inst, data)
    local foe = data.attacker or nil
    local target = inst.components.combat.target or nil
    if foe and not foe:HasTag("notarget") and not (inst.aggrotimer and inst.components.combat.lastwasattackedtime <= inst.aggrotimer) then
		inst.aggrotimer = nil
        local hands = foe.components.inventory and foe.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS) or nil
        local thands = target and target.components.inventory and target.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS) or nil
        if target and not foe:HasTag("lessaggro") and not (hands and (hands:HasTag("rangedweapon") or hands:HasTag("blowdart"))) then
            if data.stimuli and data.stimuli == "electric" then
				inst.aggrotimer = GetTime() + 2
                inst.components.combat:SetTarget(foe)
			elseif foe:HasTag("grabaggro") then
				inst.aggrotimer = GetTime() + 2
				inst.components.combat:SetTarget(foe)
			elseif hands and hands:HasTag("hammer") and not target:HasTag("companion") and not (target:HasTag("moreaggro") or foe:HasTag("lessaggro")) and not inst.sg:HasStateTag("attack") then
				--print("OnAttacked melee check PASSED")
				inst.components.combat:SetTarget(foe)
			elseif hands and (hands:HasTag("sharp") or hands:HasTag("pointy") or hands:HasTag("book")) and not (target:HasTag("moreaggro") or foe:HasTag("lessaggro")) and not (thands and thands:HasTag("hammer")) and not inst.sg:HasStateTag("attack") then
				--print("OnAttacked melee check PASSED")
				inst.components.combat:SetTarget(foe)
			elseif not hands and not (target:HasTag("moreaggro") or foe:HasTag("lessaggro")) and not inst.sg:HasStateTag("attack") then	
				inst.components.combat:SetTarget(foe)	
            end 
        elseif target and target:HasTag("moreaggro") and math.random(1, 100) > 90 then
            inst.components.combat:SetTarget(foe)   
        elseif not target then
            inst.components.combat:SetTarget(foe)
        end             
    end
	inst.components.combat:ShareTarget(data.attacker, 30, function(dude)
        return  (dude:HasTag("tadalin"))
            and not dude.components.health:IsDead()
            and dude.components.follower ~= nil
            and dude.components.follower.leader == inst.components.follower.leader
    end, 10)
end

local function CanGroundPoundHit(inst,target)
	return TadalinUtil.CanAttack(target) 
end 

local function DoOverrideWeapon(inst)
	local percent = inst.components.health:GetPercent()  
	inst.AnimState:ClearOverrideBuild("icey_boarrior_weaponswap")
	inst.AnimState:ClearOverrideBuild("icey_boarrior_weaponswap_fire")
	if percent >= 0.5 then 
		inst.AnimState:SetBuild("lavaarena_boarrior_alt1")
		inst.AnimState:AddOverrideBuild("icey_boarrior_weaponswap") 
	else
		inst.AnimState:SetBuild("lavaarena_boarrior_alt2")
		inst.AnimState:AddOverrideBuild("icey_boarrior_weaponswap_fire") 
	end 
end 

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddDynamicShadow()
    inst.entity:AddNetwork()

    --MakeCharacterPhysics(inst, 500, 1.5)

	inst.DynamicShadow:SetSize(5.25, 1.75)
    inst.Transform:SetFourFaced()

    inst:AddTag("hostile")
    inst:AddTag("epic")
    inst:AddTag("LA_mob")
	inst:AddTag("tadalin")
	inst:AddTag("noepicmusic")
	inst:AddTag("giant")
	inst:AddTag("NO_ICEY_SWIMMER_JUMP")
	
    --inst:AddTag("fossilizable")

    inst.AnimState:SetBank("boarrior")
    inst.AnimState:SetBuild("lavaarena_boarrior_alt1")
    inst.AnimState:PlayAnimation("idle_loop", true)
	
	--inst.AnimState:AddOverrideBuild("icey_boarrior_weaponswap") 
	
	inst.Transform:SetScale(1.3,1.3,1)
	
	inst.AnimState:AddOverrideBuild("fossilized")
	
	--inst.nameoverride = "boarrior" --So we don't have to make the describe strings.
	
	MakeCharacterPhysics(inst, 500, 1.5)
	--[[MakeInventoryFloatable(inst, "large", 1)	
	
	inst:AddComponent("icey_swimmer")
	inst.components.icey_swimmer:SetFloatParams(0.15, 1.0,0.5)--]]
	
	TadalinUtil.MakeSwimableCreature(inst,"large",0,Vector3(0.05, 1.0,0.5))
	
	if TheWorld.components.lavaarenamobtracker ~= nil then
        TheWorld.components.lavaarenamobtracker:StartTracking(inst)
    end
	
	inst._playingmusic = false
	if not TheNet:IsDedicated() then
        inst:DoPeriodicTask(1, PushMusic,0)
    end

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	--inst:AddComponent("fossilizable")
	
	inst.Physics:SetCollisionCallback(oncollide)
	
	

    inst:AddComponent("locomotor") -- locomotor must be constructed before the stategraph
	inst.components.locomotor.walkspeed = 6
    inst.components.locomotor.runspeed = 20
    inst:SetStateGraph("SGicey_boarrior")

    inst:SetBrain(brain)

    inst:AddComponent("follower")

    inst:AddComponent("health")
    inst.components.health:SetMaxHealth(34000)
	inst.components.health:SetAbsorptionAmount(0.90)
	--inst.components.health.nofadeout = true 
	inst.components.health.destroytime = 8

    inst:AddComponent("sanityaura")
    inst.components.sanityaura.aura = -TUNING.SANITYAURA_MED
	
	inst.damagetaken = 0
	inst.altattack = true
	inst.altattack2 = true
	inst.altattack3 = true
	inst.level = 0
	inst.knockback = 20
	inst.DoOverrideWeapon = DoOverrideWeapon 

    inst:AddComponent("combat")
    inst.components.combat:SetDefaultDamage(300)
	inst.components.combat:SetRange(4,6.5)
	inst.components.combat.playerdamagepercent = 0.5
    inst.components.combat:SetAttackPeriod(3)
    inst.components.combat:SetRetargetFunction(2, retargetfn)
    inst.components.combat:SetKeepTargetFunction(KeepTarget)
	inst.components.combat.battlecryenabled = false
    --inst.components.combat:SetHurtSound("dontstarve/creatures/hound/hurt")
	
	inst:AddComponent("colouradder")
	
	--inst:AddComponent("colourfader")
	
	--[[inst:AddComponent("armorbreak_debuff")
	inst.components.armorbreak_debuff:SetFollowSymbol("head")--]]
	
    inst:AddComponent("lootdropper")
    inst.components.lootdropper:SetChanceLootTable('icey_boarrior')

    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("只有风暴才能击倒大树!")

    inst:AddComponent("sleeper")
	
	inst:AddComponent("debuffable")
	
    MakeHauntablePanic(inst)
	
	--MakeMediumBurnableCharacter(inst, "bod")

	--inst.StartTrail = StartTrail
	--inst.EndTrail = EndTrail
	inst.DoTrail = DoTrail
	
	inst.components.combat.onhitotherfn = OnHitOther
	
	inst:AddComponent("healthtrigger")
	inst.components.healthtrigger:AddTrigger(0.75, EnterPhase2Trigger)
	inst.components.healthtrigger:AddTrigger(0.5, EnterPhase3Trigger)
	inst.components.healthtrigger:AddTrigger(0.25, EnterPhase4Trigger)
	
	inst:AddComponent("ly_groundpounder")
	inst.components.ly_groundpounder.destroyer = true
    inst.components.ly_groundpounder.damageRings = 2
    inst.components.ly_groundpounder.destructionRings = 2
    inst.components.ly_groundpounder.numRings = 3
    inst.components.ly_groundpounder.burner = true
    inst.components.ly_groundpounder.groundpoundfx = "firesplash_fx"
    inst.components.ly_groundpounder.groundpounddamagemult = 1.0
    inst.components.ly_groundpounder.groundpoundringfx = "firering_fx"
	inst.components.ly_groundpounder.canhitFn = CanGroundPoundHit
	
	inst.hit_recovery = 0.75
	
	inst.AttemptNewTarget = AttemptNewTarget

	inst:DoTaskInTime(0.5, function(inst)
		local target = FindPlayerTarget(inst) or nil
		inst.components.combat:SetTarget(target)
	end)
    inst:ListenForEvent("attacked", OnAttacked)
    --inst:ListenForEvent("onattackother", OnAttackOther)
	
	inst:DoTaskInTime(0,DoOverrideWeapon) 

    return inst
end

return Prefab("icey_boarrior", fn, assets, prefabs)