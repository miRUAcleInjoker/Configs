local assets = {
    Asset("ANIM", "anim/blowdart_lava.zip"),
    Asset("ANIM", "anim/swap_blowdart_lava.zip"),
}

local assets_projectile = {
    Asset("ANIM", "anim/lavaarena_blowdart_attacks.zip"),
}

local prefabs = {
    "forgedarts_projectile",
    "forgedarts_projectile_alt",
    "reticulelongmulti",
    "reticulelongmultiping",
}

local prefabs_projectile = {
    "weaponsparks_piercing",
}

--------------------------------------------------------------------------

local FADE_FRAMES = 5

local function CreateTail()
    local inst = CreateEntity()

    inst:AddTag("FX")
    inst:AddTag("NOCLICK")
    --[[Non-networked entity]]
    inst.entity:SetCanSleep(false)
    inst.persists = false

    inst.entity:AddTransform()
    inst.entity:AddAnimState()

    inst.AnimState:SetBank("lavaarena_blowdart_attacks")
    inst.AnimState:SetBuild("lavaarena_blowdart_attacks")
    inst.AnimState:PlayAnimation("tail_1")
    inst.AnimState:SetOrientation(ANIM_ORIENTATION.OnGround)

    inst:ListenForEvent("animover", inst.Remove)

    return inst
end

local function OnUpdateProjectileTail(inst)
    local c = (not inst.entity:IsVisible() and 0) or (inst._fade ~= nil and (FADE_FRAMES - inst._fade:value() + 1) / FADE_FRAMES) or 1
    if c > 0 then
        local tail = CreateTail()
        tail.Transform:SetPosition(inst.Transform:GetWorldPosition())
        tail.Transform:SetRotation(inst.Transform:GetRotation())
        if c < 1 then
            tail.AnimState:SetTime(c * tail.AnimState:GetCurrentAnimationLength())
        end
    end
end

local function OnHit(inst,owner, target)
	SpawnPrefab("icey_weaponsparks"):SetPiercing(inst, target)
	inst:Remove()
end

local function OnMiss(inst, owner)
	inst:Remove()
end

local function commonprojectilefn(alt)
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()

    MakeInventoryPhysics(inst)
    RemovePhysicsColliders(inst)

    inst.AnimState:SetBank("lavaarena_blowdart_attacks")
    inst.AnimState:SetBuild("lavaarena_blowdart_attacks")
    inst.AnimState:PlayAnimation("attack_3", true)
    inst.AnimState:SetOrientation(ANIM_ORIENTATION.OnGround)
    inst.AnimState:SetAddColour(1, 1, 0, 0)
    inst.AnimState:SetBloomEffectHandle("shaders/anim.ksh")

    --projectile (from projectile component) added to pristine state for optimization
    inst:AddTag("projectile")

    if not TheNet:IsDedicated() then
        inst:DoPeriodicTask(0, OnUpdateProjectileTail)
    end

    if alt then
        inst._fade = net_tinybyte(inst.GUID, "blowdart_lava_projectile_alt._fade")
    end

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

	if not alt then
		inst:AddComponent("projectile")
		inst.components.projectile:SetSpeed(35)
		inst.components.projectile:SetRange(20)
		inst.components.projectile:SetHitDist(0.5)
		inst.components.projectile:SetOnHitFn(OnHit)
		inst.components.projectile:SetOnMissFn(inst.Remove)
		inst.components.projectile:SetLaunchOffset(Vector3(1.2, 0, 0))
	else
		inst:AddComponent("ly_projectile")
		inst.components.ly_projectile.damage = 8
		inst.components.ly_projectile:SetSpeed(35)
		inst.components.ly_projectile:SetRange(20)
		inst.components.ly_projectile:SetOnHitFn(OnHit)
		inst.components.ly_projectile:SetOnMissFn(OnMiss)
		inst.components.ly_projectile:SetLaunchOffset(Vector3(1.2, 0, 0))
	end
	
	--inst:DoTaskInTime(0, function(inst) inst.SoundEmitter:PlaySound("dontstarve/common/lava_arena/blow_dart") end)
	
    return inst
end

local function projectilefn()
    return commonprojectilefn(false)
end

local function projectilealtfn()
    return commonprojectilefn(true)
end

return Prefab("icey_darts_projectile", projectilefn, assets_projectile, prefabs_projectile),
    Prefab("icey_darts_projectile_alt", projectilealtfn, assets_projectile, prefabs_projectile)