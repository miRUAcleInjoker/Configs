local TadalinUtil = require("tadalin_util")

local assets =
{
    --Asset("ANIM", "anim/frog.zip"),
    --Asset("SOUND", "sound/frog.fsb"),
	Asset("ANIM", "anim/mutsuki_ai.zip"),
	Asset("ANIM", "anim/mutsuki_ai_backpack.zip"),
	Asset("ANIM", "anim/mutsuki_ai_hat.zip"),
	Asset("IMAGE","images/inventoryimages/mutsuki_ai.tex"),
	Asset("ATLAS","images/inventoryimages/mutsuki_ai.xml"),
	Asset("IMAGE","images/map_icons/mutsuki_ai.tex"),
	Asset("ATLAS","images/map_icons/mutsuki_ai.xml"),
	
}

local brain = require "brains/mutsuki_ai_brain"

local WAKE_TO_FOLLOW_DISTANCE = 6
local SLEEP_NEAR_LEADER_DISTANCE = 7

local containers = require("containers")
local widgetsetup_old = containers.widgetsetup

local function pickupchangefn(doer, inst)
	inst.ShouldPickUp = not inst.ShouldPickUp
	if not inst.ShouldPickUp and inst:GetBufferedAction() and inst:GetBufferedAction().action == ACTIONS.PICKUP then 
		inst:ClearBufferedAction()
	end
	inst.components.talker:Say("自动拾取:"..(inst.ShouldPickUp and "开" or "关"))
end 
AddModRPCHandler("mutsuki_ai", "mutsuki_ai_pickupchange", pickupchangefn)

local mutsuki_ai = --------全局变量
{
 widget =
    {
		--slotpos = {},
        animbank = "ui_bundle_2x2",
        animbuild = "ui_bundle_2x2",
        pos = Vector3(200,0,0),
        buttoninfo =
        {
            text = "拾取功能",
            position = Vector3(0, 0, 0),
			fn = function(inst) 
				if inst.components.container then 
					pickupchangefn(inst.components.container.opener, inst)
				elseif inst.replica.container then 
					SendModRPCToServer(MOD_RPC["mutsuki_ai"]["mutsuki_ai_pickupchange"], inst)
				end
			end ,
        }
    },
    acceptsstacks = false,
    type = "chest",
}


function containers.widgetsetup(container, prefab, data, ...)
	if container.inst.prefab == "mutsuki_ai" or prefab == "mutsuki_ai" then
		for k, v in pairs(mutsuki_ai) do
            container[k] = v
        end
        container:SetNumSlots(container.widget.slotpos ~= nil and #container.widget.slotpos or 0)
        return
	end
    return widgetsetup_old(container, prefab, data, ...)
end

local function OnOpen(inst)
	inst:StopBrain()
	inst.components.locomotor:Stop()
end 

local function OnClose(inst)
	inst:RestartBrain()
	--inst.components.locomotor:Stop()
end 

local function IsLeaderSleeping(inst)
    return inst.components.follower.leader and inst.components.follower.leader:HasTag("sleeping")
end

local function ShouldWakeUp(inst)
    return (DefaultWakeTest(inst) and not IsLeaderSleeping(inst)) or not inst.components.follower:IsNearLeader(WAKE_TO_FOLLOW_DISTANCE)
end

local function ShouldSleep(inst)
	--local leader = inst.components.follower.leader
    return (DefaultSleepTest(inst) 
            or IsLeaderSleeping(inst))
            and inst.components.follower:IsNearLeader(SLEEP_NEAR_LEADER_DISTANCE)
			and TheWorld.Map:IsPassableAtPoint(inst.Transform:GetWorldPosition())
			and not inst.ShouldChop and not inst.ShouldMine 
end

local function EquipTools(inst)
	local IsEquiped = false 
	if inst.sg:HasStateTag("prechop") then 
		inst.AnimState:Show("ARM_carry")
		inst.AnimState:Hide("ARM_normal")
		inst.AnimState:OverrideSymbol("swap_object", "swap_axe", "swap_axe")
		IsEquiped = true 
	elseif inst.sg:HasStateTag("prehammer") then 
		inst.AnimState:Show("ARM_carry")
		inst.AnimState:Hide("ARM_normal")
		inst.AnimState:OverrideSymbol("swap_object", "swap_hammer", "swap_hammer")
		IsEquiped = true 
	elseif inst.sg:HasStateTag("predig") then 
		inst.AnimState:Show("ARM_carry")
		inst.AnimState:Hide("ARM_normal")
		inst.AnimState:OverrideSymbol("swap_object", "swap_shovel", "swap_shovel")
		IsEquiped = true 
	elseif inst.sg:HasStateTag("premine") then 
		inst.AnimState:Show("ARM_carry")
		inst.AnimState:Hide("ARM_normal")
		inst.AnimState:OverrideSymbol("swap_object", "swap_pickaxe", "swap_pickaxe")
		IsEquiped = true  
	else 
		inst.AnimState:Hide("ARM_carry")
		inst.AnimState:Show("ARM_normal")
		inst.AnimState:ClearOverrideSymbol("swap_object")
		IsEquiped = false 
	end
	
	inst.IsEquiped = IsEquiped
end 

local function OnPet(inst)
	local leader = inst.components.follower:GetLeader()
	if leader and leader.components.inventory then
		for k,v in pairs(inst.components.inventory.itemslots) do 
			if v and v:IsValid() and leader.components.inventory:CanAcceptCount(v) > 0 then 
				leader.components.inventory:GiveItem(v) 
			end
		end
	end
	if inst.components.container and leader and leader:IsValid() then 
		if inst.components.container:IsOpen() then 
			inst.components.container:Close()
		else
			inst.components.container:Open(leader)
		end
	end
end 

local function OnRemove(pet)
	print(pet,"Pet OnAbandoned !!!!")
	SpawnPrefab(pet:HasTag("flying") and "spawn_fx_small_high" or "spawn_fx_small").Transform:SetPosition(pet.Transform:GetWorldPosition())
	pet.components.inventory:DropEverything()
	--pet.components.lootdropper:DropLoot()
	SpawnAt("icey_sans_soul",pet:GetPosition())
end 

local function init(inst)
	if inst.icon == nil then
        inst.icon = SpawnPrefab("globalmapicon")
        inst.icon:TrackEntity(inst)
    end
end

local function OnSave(inst,data)
	data.ShouldPickUp = inst.ShouldPickUp
end 

local function OnLoad(inst,data)
	if data then 
		inst.ShouldPickUp = data.ShouldPickUp
	end
end 

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddDynamicShadow()
    inst.entity:AddNetwork()
	inst.entity:AddMiniMapEntity()
	
	inst.MiniMapEntity:SetIcon("mutsuki_ai.tex")
    inst.MiniMapEntity:SetPriority(10)
    inst.MiniMapEntity:SetCanUseCache(false)
    inst.MiniMapEntity:SetDrawOverFogOfWar(true)

    MakeCharacterPhysics(inst, 1, .3)

    inst.DynamicShadow:SetSize(1.5, .75)
    inst.Transform:SetFourFaced()

    inst.AnimState:SetBank("wilson")
    inst.AnimState:SetBuild("mutsuki_ai")
    inst.AnimState:PlayAnimation("idle",true)
	
	inst.AnimState:Hide("ARM_carry")
    inst.AnimState:Hide("HAT")
    inst.AnimState:Hide("HAIR_HAT")
    inst.AnimState:Show("HAIR_NOHAT")
    inst.AnimState:Show("HAIR")
    inst.AnimState:Show("HEAD")
    inst.AnimState:Hide("HEAD_HAT")

    inst.AnimState:OverrideSymbol("fx_wipe", "wilson_fx", "fx_wipe")
    inst.AnimState:OverrideSymbol("fx_liquid", "wilson_fx", "fx_liquid")
    inst.AnimState:OverrideSymbol("shadow_hands", "shadow_hands", "shadow_hands")

    --Additional effects symbols for hit_darkness animation
    inst.AnimState:AddOverrideBuild("player_hit_darkness")
    inst.AnimState:AddOverrideBuild("player_receive_gift")
    inst.AnimState:AddOverrideBuild("player_actions_uniqueitem")
    inst.AnimState:AddOverrideBuild("player_wrap_bundle")
    inst.AnimState:AddOverrideBuild("player_lunge")
    inst.AnimState:AddOverrideBuild("player_attack_leap")
    inst.AnimState:AddOverrideBuild("player_superjump")
    inst.AnimState:AddOverrideBuild("player_multithrust")
    inst.AnimState:AddOverrideBuild("player_parryblock")
    inst.AnimState:AddOverrideBuild("player_emote_extra")
	
	inst.AnimState:OverrideSymbol("swap_hat", "mutsuki_ai_hat", "swap_hat")
	inst.AnimState:OverrideSymbol("backpack", "mutsuki_ai_backpack", "backpack")
    inst.AnimState:OverrideSymbol("swap_body", "mutsuki_ai_backpack", "swap_body")
	inst.AnimState:OverrideSymbol("swap_bedroll", "swap_bedroll_furry", "bedroll_furry")
	
	inst.AnimState:Show("HAT")
    inst.AnimState:Show("HAIR_HAT")
    inst.AnimState:Hide("HAIR_NOHAT")
    inst.AnimState:Hide("HAIR")
	
	inst.AnimState:Hide("HEAD")
    inst.AnimState:Show("HEAD_HAT")
	
	
    inst.AnimState:Hide("ARM_carry")
    inst.AnimState:Show("ARM_normal")
	
    inst:AddTag("character")
	inst:AddTag("critter")
    inst:AddTag("companion")
    inst:AddTag("notraptrigger")
    inst:AddTag("noauradamage")
    inst:AddTag("small_livestock")
    inst:AddTag("NOBLOCK")
	inst:AddTag("NO_ICEY_SWIMMER_JUMP")
	
	
	inst:AddComponent("talker")
	
	
	TadalinUtil.MakeSwimableCreature(inst,"small",0,Vector3(0,0,0))
	inst.components.icey_swimmer.wave_offset = 0
	inst.components.icey_swimmer.swimming_scale = 1
	
    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	
	
	inst.IsEquiped = false 
	inst.EquipTools = EquipTools 
	inst.LastGiveItemTime = GetTime()
	inst.ShouldPickUp = false   
	inst.ShouldChop = false 
	inst.ShouldMine = false 
	
    inst:AddComponent("locomotor") -- locomotor must be constructed before the stategraph
    inst.components.locomotor.walkspeed = 4
    inst.components.locomotor.runspeed = 6
	inst.components.locomotor.softstop = true
	inst.components.locomotor.pathcaps = { allowocean = true }

    ---inst:AddComponent("health")
    ---inst.components.health:SetMaxHealth(150)
	---inst.components.health:SetInvincible(true)

    ---inst:AddComponent("combat")
    ---inst.components.combat:SetDefaultDamage(14)
    ---inst.components.combat:SetAttackPeriod(0.3)
	--inst.components.combat:SetRange(6, 6)
    --inst.components.combat:SetRetargetFunction(1, retargetfn)
	--inst.components.combat:SetKeepTargetFunction(keeptargetfn)
    --inst.components.combat.onhitotherfn = OnHitOther
	
	inst:AddComponent("sleeper")
    inst.components.sleeper:SetResistance(3)
    inst.components.sleeper.testperiod = GetRandomWithVariance(6, 2)
    inst.components.sleeper:SetSleepTest(ShouldSleep)
    inst.components.sleeper:SetWakeTest(ShouldWakeUp)
	
	inst:AddComponent("eater")
    inst.components.eater:SetDiet({ FOODGROUP.OMNI }, { FOODGROUP.OMNI })
	
	inst:AddComponent("follower")
	inst.components.follower:KeepLeaderOnAttacked()
    inst.components.follower.keepdeadleader = true
    inst.components.follower.keepleaderduringminigame = true

	inst:AddComponent("inventory")

    inst:AddComponent("lootdropper")
	
	inst:AddComponent("container")
	--inst.components.container.widgetsetup = containers_widgetsetup_hack
	inst.components.container:WidgetSetup("mutsuki_ai",mutsuki_ai)
	inst.components.container.onopenfn = OnOpen 
	inst.components.container.onclosefn = OnClose
	
	inst:AddComponent("crittertraits")
	inst.components.crittertraits:SetOnAbandonedFn(OnRemove)
	local old_OnPet = inst.components.crittertraits.OnPet
	inst.components.crittertraits.OnPet = function(self,petter)
		self.inst:PushEvent("pre_critter_onpet")
		if self.inst.sg:HasStateTag("sleeping") 
		or not ( 
			self.inst.sg:HasStateTag("busy") 
			or self.inst.sg:HasStateTag("working")
			or (self.inst:GetBufferedAction() and self.inst:GetBufferedAction():IsValid())
		) then 
			old_OnPet(self,petter)
		end 
	end 
	
	inst:AddComponent("age")
    inst:AddComponent("knownlocations")
    inst:AddComponent("inspectable")
	inst:AddComponent("timer")
	inst:AddComponent("bloomer")
    inst:AddComponent("colouradder")
	inst:AddComponent("rider")
	inst:AddComponent("debuffable")
    inst.components.debuffable:SetFollowSymbol("headbase", 0, -200, 0)
	
	inst:SetStateGraph("SGmutsuki_ai")
    inst:SetBrain(brain)
	
	inst.sounds = {
		hit = "dontstarve/characters/wendy/hurt",
		death = "dontstarve/characters/wendy/death_voice",
	}
	
	--inst:DoTaskInTime(0, init)
	inst:ListenForEvent("newstate",EquipTools)
	inst:ListenForEvent("pre_critter_onpet",OnPet)
	--inst:ListenForEvent("onremove",OnRemove)
    return inst
end
-------------------------------------------------------------------------------
local function builder_onbuilt(inst, builder)
    local theta = math.random() * 2 * PI
    local pt = builder:GetPosition()
    local radius = 1
    local offset = FindWalkableOffset(pt, theta, radius, 6, true)
    if offset ~= nil then
        pt.x = pt.x + offset.x
        pt.z = pt.z + offset.z
    end
    builder.components.petleash:SpawnPetAt(pt.x, 0, pt.z, inst.pettype, inst.linked_skinname)
    inst:Remove()
end

local function MakeBuilder(prefab)
    local function fn()
        local inst = CreateEntity()

        inst.entity:AddTransform()

        inst:AddTag("CLASSIFIED")

        --[[Non-networked entity]]
        inst.persists = false

        --Auto-remove if not spawned by builder
        inst:DoTaskInTime(0, inst.Remove)

        if not TheWorld.ismastersim then
            return inst
        end

        inst.pettype = prefab
        inst.OnBuiltFn = builder_onbuilt

        return inst
    end

    return Prefab(prefab.."_builder", fn, nil, { prefab })
end
-------------------------------------------------------------------------------

return Prefab("mutsuki_ai", fn, assets),
MakeBuilder("mutsuki_ai")

--local x,y,z = ThePlayer:GetPosition():Get()ThePlayer.components.petleash:SpawnPetAt(x,0,z,"mutsuki_ai")
--c_findnext(""):SetBrain(require "brains/mutsuki_ai_brain")