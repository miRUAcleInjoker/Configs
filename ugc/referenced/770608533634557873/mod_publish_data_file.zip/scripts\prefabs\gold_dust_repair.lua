local assets=
{
	Asset("ANIM", "anim/gold_dust.zip"),
	Asset("IMAGE","images/inventoryimages/gold_dust_repair.tex"),
	Asset("ATLAS","images/inventoryimages/gold_dust_repair.xml"),
}

local function shine(inst)
    inst.task = nil
	if inst.onwater then
		inst.AnimState:PlayAnimation("sparkle_water")
		inst.AnimState:PushAnimation("idle_water")
	else
		inst.AnimState:PlayAnimation("sparkle")
		inst.AnimState:PushAnimation("idle")
    end
	inst.task = inst:DoTaskInTime(4+math.random()*5, function() shine(inst) end)
end

local function fn(Sim)
    
	local inst = CreateEntity()
	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddSoundEmitter()
	inst.entity:AddPhysics()
	inst.entity:AddNetwork()
	
    MakeInventoryPhysics(inst)

	inst.AnimState:SetBloomEffectHandle( "shaders/anim.ksh" )
	
    inst.AnimState:SetBank("gold_dust")
    inst.AnimState:SetBuild("gold_dust")
    inst.AnimState:PlayAnimation("idle")
	
	inst.entity:SetPristine()
    if not TheWorld.ismastersim then
        return inst
    end	  

	inst.onwater = false 

    inst:AddComponent("tradable")
    
    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("金闪闪！")
    
    inst:AddComponent("stackable")
	
	inst:AddComponent("weaponrepairer")
	inst.components.weaponrepairer.repairvalue = 50
	inst.components.weaponrepairer.repairvalue_armor = 200
	
	inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "gold_dust_repair"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/gold_dust_repair.xml"

    shine(inst)
	return inst
end

return Prefab( "gold_dust_repair", fn, assets) 
