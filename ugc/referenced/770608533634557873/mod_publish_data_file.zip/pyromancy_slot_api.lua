local IsServer = TheNet:GetIsServer()
local Inv = require "widgets/inventorybar"

EQUIPSLOTS.PYROMANCY_SLOT1 = "pyromancy_slot1"
EQUIPSLOT_IDS = {}
local slot = 0
for k, v in pairs(EQUIPSLOTS) do
    slot = slot + 1
    EQUIPSLOT_IDS[v] = slot
end
slot = nil


AddGlobalClassPostConstruct("widgets/inventorybar", "Inv", function()
    local Inv_Refresh_base = Inv.Refresh or function() return "" end
    local Inv_Rebuild_base = Inv.Rebuild or function() return "" end
	--local Inv_LoadExtraSlots = Inv.LoadExtraSlots or function() return "" end

    function Inv:LoadPyromancySlots(self)
		--print("Inv:LoadPyromancySlots(self)")
		if self.addextraslots then 
			self.bg:SetScale(1.4,1,1.25)
			self.bgcover:SetScale(1.4,1,1.25)
		end 

        if self.AddPyromancy == nil then
            self.AddPyromancy = 1

            self:AddEquipSlot(EQUIPSLOTS.PYROMANCY_SLOT1, "images/pyromancy_slot1.xml", "pyromancy_slot1.tex")
			
            if self.inspectcontrol then
                local W = 68
                local SEP = 12
                local INTERSEP = 28
                local inventory = self.owner.replica.inventory
                local num_slots = inventory:GetNumSlots()
                local num_equip = #self.equipslotinfo
                local num_buttons = self.controller_build and 0 or 1
                local num_slotintersep = math.ceil(num_slots / 5)
                local num_equipintersep = num_buttons > 0 and 1 or 0
                local total_w = (num_slots + num_equip + num_buttons) * W + (num_slots + num_equip + num_buttons - num_slotintersep - num_equipintersep - 1) * SEP + (num_slotintersep + num_equipintersep) * INTERSEP
            	self.inspectcontrol.icon:SetPosition(-4, 6)
            	self.inspectcontrol:SetPosition((total_w - W) * .5 + 3, -6, 0)
            end
        end
    end

    function Inv:Refresh()
        Inv_Refresh_base(self)
        Inv:LoadPyromancySlots(self)
    end

    function Inv:Rebuild()
        Inv_Rebuild_base(self)
        Inv:LoadPyromancySlots(self)
    end
end)

