local IceyUtil = require("icey_util")
local IceyWeaponSkillUtil = require("icey_weaponskill_util")

local assets = {
	
	Asset("ANIM", "anim/yhorm_shield.zip"),
	Asset("ANIM", "anim/swap_yhorm_shield_in.zip"),
	Asset("IMAGE","images/inventoryimages/yhorm_shield.tex"),
	Asset("ATLAS","images/inventoryimages/yhorm_shield.xml"),
}


local function onequip(inst,owner)
	inst:ListenForEvent("newcombattarget",inst._OnNewCombatTarget,owner)
end 

local function onunequip(inst,owner)
	inst:RemoveEventCallback("newcombattarget",inst._OnNewCombatTarget,owner)
end 

local function clientfn(inst)
	
	inst.Transform:SetScale(0.8,0.8,0.8)
	
	IceyWeaponSkillUtil.AddAoetargetingClient(inst,"line",{"yhorm_shield"},15)
end 

local function serverfn(inst)
	inst:AddComponent("armor")
    inst.components.armor:InitCondition(7500, 0.95)
	
	inst._OnNewCombatTarget = function(owner,data)
		inst.components.armor:SetAbsorption(0.25)
		if inst.ResumeShieldTask then 
			inst.ResumeShieldTask:Cancel()
		end 
		inst.ResumeShieldTask = nil 
		inst.ResumeShieldTask = inst:DoTaskInTime(2,function()
			inst.components.armor:SetAbsorption(0.95)
			inst.ResumeShieldTask = nil 
		end)
	end 
	
	IceyWeaponSkillUtil.AddAoetargetingServer(inst,function(inst,doer,pos)
		if IceyUtil.DefaultCostFn(doer,{stamina = 25}) then 
			inst.components.rechargeable:StartRecharge()
			local dist = .8
            local radius = 1.7
            doer.components.combat.ignorehitrange = true
            local x0, y0, z0 = doer.Transform:GetWorldPosition()
            local angle = (doer.Transform:GetRotation() + 90) * DEGREES
            local sinangle = math.sin(angle)
            local cosangle = math.cos(angle)
            local x = x0 + dist * sinangle
            local z = z0 + dist * cosangle
            for i, v in ipairs(TheSim:FindEntities(x, y0, z, radius + 3, { "_combat" }, { "FX", "NOCLICK", "DECOR", "INLIMBO", "playerghost" })) do
                if v:IsValid() and not v:IsInLimbo() and
                    not (v.components.health ~= nil and v.components.health:IsDead()) then
                    local range = radius + v:GetPhysicsRadius(.5)
                    if v:GetDistanceSqToPoint(x, y0, z) < range * range and doer.components.combat:CanTarget(v) and IceyUtil.CanAttack(v,doer) then

						doer.components.combat:DoAttack(v)
						if v.sg and v.sg:HasStateTag("attack") then 
							doer.components.combat:DoAttack(v)
						end
                        --v:PushEvent("knockback", { knocker = doer, radius = radius + dist, propsmashed = true })
						IceyUtil.KnockBack(doer,v)
                        doer.sg.statemem.smashed = true
                    end
                end
            end
            doer.components.combat.ignorehitrange = false
            if doer.sg.statemem.smashed then
                local prop = doer.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
                if prop ~= nil then
                    dist = dist + radius - .5
                    doer.sg.statemem.smashed = { prop = prop, pos = Vector3(x0 + dist * sinangle, y0, z0 + dist * cosangle) }
                else
                    doer.sg.statemem.smashed = nil
                end
            end
		end 
	end,nil,3)
	
end

local DATA = {
	prefabname = "yhorm_shield",
	assets = assets,
	tags = {"yhorm_shield"},
	bank = "yhorm_shield",
	build = "yhorm_shield",
	anim = "idle",
	swapanims = {"swap_yhorm_shield_in","swap_yhorm_shield_in"},
	damage = 45,
	--ranges = 0,
	--maxuse = 75,
	clientfn = clientfn,
	serverfn = serverfn,
	
	onequip = onequip,
	onunequip = onunequip,
}


return IceyUtil.CreateNormalWeapon(DATA)