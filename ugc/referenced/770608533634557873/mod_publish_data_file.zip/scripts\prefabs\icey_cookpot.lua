require "prefabutil"  
local cooking = require("cooking")  
local preparedfoods_icey = require("preparedfoods_icey")

local assets = { 
	--Asset("ANIM", "anim/cook_pot_warly.zip"), 
	Asset("ANIM", "anim/icey_cook_pot.zip"), 
	--Asset("ANIM", "anim/cook_pot_food.zip"), 
	Asset("IMAGE", "images/inventoryimages/icey_cookpot.tex"), 
	Asset("ATLAS", "images/inventoryimages/icey_cookpot.xml"), 
}  

local prefabs =  { 
	"collapse_small", 
	"snakebonesoup",
}  

for k,v in pairs(cooking.recipes.cookpot) do 
	table.insert(prefabs, v.name) 
end 

--cookerrecipes[cooker][recipe.name] = recipe
--local foods = require("preparedfoods") 
local cookpot_recipes = cooking.recipes["cookpot"]
--local all_recipes = cookerrecipes["cookpot"]

for k,recipe in pairs (cookpot_recipes) do 
	AddCookerRecipe("icey_cookpot", recipe) 
end  

local containers = require("containers")
local widgetsetup_old = containers.widgetsetup

local icey_cookpot =
{
    widget =
    {
        slotpos =
        {
            Vector3(0, 64 + 32 + 8 + 4, 0), 
            Vector3(0, 32 + 4, 0),
            Vector3(0, -(32 + 4), 0), 
            Vector3(0, -(64 + 32 + 8 + 4), 0),
        },
        animbank = "ui_cookpot_1x4",
        animbuild = "ui_cookpot_1x4",
        pos = Vector3(200, 0, 0),
        side_align_tip = 100,
        buttoninfo =
        {
            text = STRINGS.ACTIONS.COOK,
            position = Vector3(0, -165, 0),
        }
    },
    acceptsstacks = true,
    type = "cooker",
}

--[[local function ArrangeContainer(inst)
	if not inst.components.container:IsFull() then 
		local empty_slot = nil 
		for i=1,#inst.components.container:GetNumSlots() do 
			if inst.components.container.slots[i] == nil then 
				empty_slot = inst.components.container.slots[i]
				break 
			end
		end
		if 
	end 
end --]]

function icey_cookpot.itemtestfn(container, item, slot)
    return cooking.IsCookingIngredient(item.prefab) and not container.inst:HasTag("burnt")
end

function icey_cookpot.widget.buttoninfo.fn(inst)
    if inst.components.container ~= nil then
        BufferedAction(inst.components.container.opener, inst, ACTIONS.COOK):Do()
    elseif inst.replica.container ~= nil and not inst.replica.container:IsBusy() then
        SendRPCToServer(RPC.DoWidgetButtonAction, ACTIONS.COOK.code, inst, ACTIONS.COOK.mod_name)
    end
end

function icey_cookpot.widget.buttoninfo.validfn(inst)
    return inst.replica.container ~= nil and inst.replica.container:IsFull()
--[[	if not inst.replica.container then 
		return false 
	end 
	local nums = 0
	for k,v in pairs(inst.replica.container:GetItems()) do 
		if v and v:IsValid() then 
			local stacksize = 0
			if v.replica.stackable then 
				stacksize = v.replica.stackable:StackSize() 
			else
				stacksize = 1 
			end
			nums = nums + stacksize
		end 
	end
	return nums >= 4 --]]
end

function containers.widgetsetup(container, prefab, data, ...)
	if container.inst.prefab == "icey_cookpot" or prefab == "icey_cookpot" then
		for k, v in pairs(icey_cookpot) do
            container[k] = v
        end
        container:SetNumSlots(container.widget.slotpos ~= nil and #container.widget.slotpos or 0)
        return
	end
    return widgetsetup_old(container, prefab, data, ...)
end

local function ondeploy(inst, pt, deployer) 
	local pot = SpawnPrefab("icey_cookpot")  
	if pot ~= nil then  
		pt = Vector3(pt.x, 0, pt.z) 
		pot.Physics:SetCollides(false) 
		pot.Physics:Teleport(pt.x, pt.y, pt.z)  
		pot.Physics:SetCollides(true) 
		pot.AnimState:PlayAnimation("place")         
		pot.AnimState:PlayAnimation("idle_empty", false) 
		pot.SoundEmitter:PlaySound("dontstarve/common/place_structure_stone") 
		inst:Remove() 
	end         
end  

local function item_droppedfn(inst) 
	if inst.components.deployable and inst.components.deployable:CanDeploy(inst:GetPosition()) then
		inst.components.deployable:Deploy(inst:GetPosition(), inst) 
	end 
end  

local function storeincontainer(inst, container)     
	if container ~= nil and container.components.container ~= nil then         
		inst:ListenForEvent("onputininventory", inst._oncontainerownerchanged, container)         
		inst:ListenForEvent("ondropped", inst._oncontainerownerchanged, container)         
		inst._container = container     
	end 
end  

local function unstore(inst)     
	if inst._container ~= nil then         
		inst:RemoveEventCallback("onputininventory", inst._oncontainerownerchanged, inst._container)         
		inst:RemoveEventCallback("ondropped", inst._oncontainerownerchanged, inst._container)         
		inst._container = nil     
	end 
end  

local function topocket(inst, owner)     
	if inst._container ~= owner then         
		unstore(inst)         
		storeincontainer(inst, owner)     
	end 
end  

local function toground(inst)     
	unstore(inst) 
end  

local function itemfn(Sim) 
	local inst = CreateEntity() 
	inst.entity:AddTransform() 
	inst.entity:AddAnimState()     
	inst.entity:AddNetwork() 
	inst.entity:AddMiniMapEntity()  
	
	MakeInventoryPhysics(inst) 
	--MakeObstaclePhysics(inst, .6)  
	
	inst.AnimState:SetBank("icey_cook_pot") 
	inst.AnimState:SetBuild("icey_cook_pot") 
	inst.AnimState:PlayAnimation("idle_drop")  
	
	--inst.MiniMapEntity:SetIcon("rikocookpot.tex")  
	
	if not TheWorld.ismastersim then         
		return inst     
	end      
	
	inst.nameoverride = "icey_cookpot"
	inst._container = nil          
	inst._oncontainerownerchanged = function(container)         
		topocket(inst, container)     
	end      
	
	inst._oncontainerremoved = function()         
		unstore(inst)     
	end              
	
	--inst:AddComponent("chosenowner")     
	--inst.components.chosenowner:SetOwner("riko")      
	
	inst:ListenForEvent("onputininventory", topocket)     
	inst:ListenForEvent("ondropped", toground)      
	
	inst.entity:SetPristine()  
	
	--inst:AddComponent("chosenicey")
	
	inst:AddComponent("inspectable")  
	
	inst:AddComponent("inventoryitem") 
	--inst.components.inventoryitem:SetOnDroppedFn(item_droppedfn) 
	inst.components.inventoryitem.imagename = "icey_cookpot" 
	inst.components.inventoryitem.atlasname = "images/inventoryimages/icey_cookpot.xml"  
	
	inst:AddComponent("deployable") 
	inst.components.deployable:SetDeployMode(DEPLOYMODE.DEFAULT) 
	inst.components.deployable.ondeploy = ondeploy  
	
	MakeHauntableLaunch(inst)  
	return inst 
end  

local function onhammered(inst, worker) 
	if inst.components.stewer.product ~= nil and inst.components.stewer:IsDone() then 
		inst.components.lootdropper:AddChanceLoot(inst.components.stewer.product, 1) 
	end 
	inst.components.lootdropper:AddChanceLoot("icey_cookpot_item", 1) 
	inst.components.lootdropper:DropLoot() 
	local fx = SpawnPrefab("collapse_small")     
	fx.Transform:SetPosition(inst.Transform:GetWorldPosition())     
	fx:SetMaterial("metal")     
	inst:Remove() 
end  

local function onhit(inst, worker) 
	if inst.components.container then 
		inst.components.container:DropEverything()  
	end
	--inst.AnimState:PlayAnimation("hit_empty")      
	--inst.AnimState:PushAnimation((inst.components.stewer:IsCooking() and "cooking_loop") or (inst.components.stewer:IsDone() and "idle_full") or "idle_empty") 
end  

local function startcookfn(inst) 
	if not inst:HasTag("iscooking") then 
		inst:AddTag("iscooking") 
	end     
	inst.AnimState:PlayAnimation("cooking_loop", true)     
	inst.SoundEmitter:KillSound("snd")     
	inst.SoundEmitter:PlaySound("dontstarve/common/cookingpot_rattle", "snd")     
	inst.Light:Enable(true) 
end  

local function onopen(inst) 
	if not inst:HasTag("isopen") then 
		inst:AddTag("isopen") 
	end     
	inst.AnimState:PlayAnimation("cooking_pre_loop", true)     
	inst.SoundEmitter:KillSound("snd")     
	inst.SoundEmitter:PlaySound("dontstarve/common/cookingpot_open")     
	inst.SoundEmitter:PlaySound("dontstarve/common/cookingpot", "snd")     
	--[[if inst.components.container.opener and not inst.components.container.opener:HasTag("riko") then  
		inst.components.container:DropEverything()     
		inst.components.container:Close()     
	end --]]
end  

local function onclose(inst) 
	if inst:HasTag("isopen") then
		inst:RemoveTag("isopen") 
	end     
	if not inst.components.stewer:IsCooking() then    
	    inst.AnimState:PlayAnimation("idle_empty")         
		inst.SoundEmitter:KillSound("snd")     
	end     
	inst.SoundEmitter:PlaySound("dontstarve/common/cookingpot_close") 
end  

local function spoilfn(inst)     
	inst.components.stewer.product = inst.components.stewer.spoiledproduct     
	inst.AnimState:OverrideSymbol("swap_cooked", "cook_pot_food", inst.components.stewer.product) 
end  

local function IsIceyCookingProduct(product)
	--print(product,"IsIceyCookingProduct?")
	for k,v in pairs(preparedfoods_icey) do 
		--print("遍历preparedfoods_icey的v.name:",v.name)
		if v.name == product then 
			return true 
		end
	end
	return false
end 

local function ShowProduct(inst)     
	local product = inst.components.stewer.product
	--print("Show Product:"..product) 
	if IsIceyCookingProduct(product) then 
		inst.AnimState:OverrideSymbol("swap_cooked", "cook_pot_food_icey", product)    
		return 
	end 
	if IsModCookingProduct("cookpot", product) then   
		inst.AnimState:OverrideSymbol("swap_cooked", product, product)    			
	else         
		inst.AnimState:OverrideSymbol("swap_cooked", "cook_pot_food", product)    
	end 
end  



local function donecookfn(inst) 
	if inst:HasTag("iscooking") then 
		inst:RemoveTag("iscooking") 
	end     
	inst.AnimState:PlayAnimation("cooking_pst")     
	inst.AnimState:PushAnimation("idle_full",false)  
	ShowProduct(inst)    
	inst.SoundEmitter:KillSound("snd")     
	inst.SoundEmitter:PlaySound("dontstarve/common/cookingpot_finish")     
	inst.Light:Enable(false) 
end  

local function continuedonefn(inst) 
	inst.AnimState:PlayAnimation("idle_full") 
	ShowProduct(inst) 
end  

local function continuecookfn(inst)     
	inst.AnimState:PlayAnimation("cooking_loop", true)  
	inst.Light:Enable(true)     
	inst.SoundEmitter:KillSound("snd")     
	inst.SoundEmitter:PlaySound("dontstarve/common/cookingpot_rattle", "snd") 
end  

local function harvestfn(inst) 
	inst.AnimState:PlayAnimation("idle_empty") 
end  

local function getstatus(inst) 
	if inst.components.stewer:IsCooking() and inst.components.stewer:GetTimeToCook() > 15 then
		return "COOKING_LONG" 
	elseif inst.components.stewer:IsCooking() then 
		return "COOKING_SHORT" 
	elseif inst.components.stewer:IsDone() then 
		return "DONE" 
	else 
		return "EMPTY" 
	end 
end  
	
local function onfar(inst)     
	if inst.components.container ~= nil then         
		inst.components.container:Close()     
	end 
end  

local function onbuilt(inst) 
	if inst.components.workable ~= nil then 
		inst:RemoveComponent("workable") 
	end 
	inst.AnimState:PlayAnimation("place")     
	inst.AnimState:PushAnimation("idle_empty") 
end  

local function OnHaunt(inst, haunter)     
	local ret = false     
	if inst.components.stewer ~= nil and inst.components.stewer.product ~= "wetgoop" and math.random() <= TUNING.HAUNT_CHANCE_ALWAYS then  
		if inst.components.stewer:IsCooking() then             
			inst.components.stewer.product = "wetgoop"             
			inst.components.hauntable.hauntvalue = TUNING.HAUNT_MEDIUM             
			ret = true         
		elseif inst.components.stewer:IsDone() then             
			inst.components.stewer.product = "wetgoop"             
			inst.components.hauntable.hauntvalue = TUNING.HAUNT_MEDIUM             
			continuedonefn(inst)             
			ret = true        
		end     
	end     
	return ret 
end  

local function pickupfn(inst, guy) 
	if guy.components.inventory ~= nil then 
		inst.components.container:DropEverything()
		local potitem = SpawnPrefab("icey_cookpot_item") 
		guy.components.inventory:GiveItem(potitem) 
		inst:Remove() 
		return true 
	end 
end  

local function fn(Sim)  
	local inst = CreateEntity()      
	inst.entity:AddTransform()     
	inst.entity:AddAnimState()     
	inst.entity:AddSoundEmitter()     
	inst.entity:AddMiniMapEntity()     
	inst.entity:AddLight()     
	inst.entity:AddNetwork()  
	
	MakeObstaclePhysics(inst, .6)  
	
	--inst.MiniMapEntity:SetIcon("rikocookpot.tex") 
	 
	inst.Light:Enable(false)     
	inst.Light:SetRadius(.6)     
	inst.Light:SetFalloff(1)     
	inst.Light:SetIntensity(.5)     
	inst.Light:SetColour(0/255,79/255,255/255)  
	
	inst:AddTag("structure")  
	inst:AddTag("pickupable")
	inst:AddTag("multfoods_cookpot")
	
	inst.AnimState:SetBank("icey_cook_pot") 
	inst.AnimState:SetBuild("icey_cook_pot") 
	inst.AnimState:PlayAnimation("idle_empty")  
	
	MakeSnowCoveredPristine(inst)  
	
	if not TheWorld.ismastersim then 
		return inst 
	end  
	inst.entity:SetPristine()  
	
	inst:AddComponent("lootdropper")
	
    inst:AddComponent("workable")
    inst.components.workable:SetWorkAction(ACTIONS.HAMMER)
    inst.components.workable:SetWorkLeft(4)
    inst.components.workable:SetOnFinishCallback(onhammered)
    inst.components.workable:SetOnWorkCallback(onhit)
	
	inst:AddComponent("stewer")     
	inst.components.stewer.onstartcooking = startcookfn 
	inst.components.stewer.oncontinuecooking = continuecookfn     
	inst.components.stewer.oncontinuedone = continuedonefn     
	inst.components.stewer.ondonecooking = donecookfn     
	inst.components.stewer.onharvest = harvestfn    
	inst.components.stewer.onspoil = spoilfn  
	
	inst:AddComponent("container")    
	--inst.components.container:WidgetSetup("cookpot")   
	inst.components.container:WidgetSetup("icey_cookpot",icey_cookpot)  
	inst.components.container.onopenfn = onopen     
	inst.components.container.onclosefn = onclose  
	
	--[[inst:AddComponent("inventoryitem") 
	inst.components.inventoryitem.imagename = "icey_cookpot" 
	inst.components.inventoryitem.atlasname = "images/inventoryimages/icey_cookpot.xml" 
	inst.components.inventoryitem.canbepickedup = false  --]]
	
	inst:AddComponent("pickupable") 
	inst.components.pickupable:SetOnPickupFn(pickupfn)  
	
	inst:AddComponent("inspectable") 
	inst.components.inspectable.getstatus = getstatus  
	
	inst:AddComponent("playerprox") 
	inst.components.playerprox:SetDist(3,5) 
	inst.components.playerprox:SetOnPlayerFar(onfar)  
	
	inst:AddComponent("hauntable")     
	inst.components.hauntable:SetOnHauntFn(OnHaunt)  
	
	MakeSnowCovered(inst, .01)     
	inst:ListenForEvent("onbuilt", onbuilt)  
	return inst 
end 

return Prefab( "icey_cookpot", fn, assets, prefabs), 
Prefab("icey_cookpot_item", itemfn, assets, prefabs), 
MakePlacer( "icey_cookpot_item_placer", "icey_cook_pot", "icey_cook_pot", "idle_empty" )

