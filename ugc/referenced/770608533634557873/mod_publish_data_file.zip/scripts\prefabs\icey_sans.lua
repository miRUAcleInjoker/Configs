local assets =
{
        Asset( "ANIM", "anim/player_basic.zip" ),
        Asset( "ANIM", "anim/player_idles_shiver.zip" ),
        Asset( "ANIM", "anim/player_actions.zip" ),
        Asset( "ANIM", "anim/player_actions_axe.zip" ),
        Asset( "ANIM", "anim/player_actions_pickaxe.zip" ),
        Asset( "ANIM", "anim/player_actions_shovel.zip" ),
        Asset( "ANIM", "anim/player_actions_blowdart.zip" ),
        Asset( "ANIM", "anim/player_actions_eat.zip" ),
        Asset( "ANIM", "anim/player_actions_item.zip" ),
        Asset( "ANIM", "anim/player_actions_uniqueitem.zip" ),
        Asset( "ANIM", "anim/player_actions_bugnet.zip" ),
        Asset( "ANIM", "anim/player_actions_fishing.zip" ),
        Asset( "ANIM", "anim/player_actions_boomerang.zip" ),
        Asset( "ANIM", "anim/player_bush_hat.zip" ),
        Asset( "ANIM", "anim/player_attacks.zip" ),
        Asset( "ANIM", "anim/player_idles.zip" ),
        Asset( "ANIM", "anim/player_rebirth.zip" ),
        Asset( "ANIM", "anim/player_jump.zip" ),
        Asset( "ANIM", "anim/player_amulet_resurrect.zip" ),
        Asset( "ANIM", "anim/player_teleport.zip" ),
        Asset( "ANIM", "anim/wilson_fx.zip" ),
        Asset( "ANIM", "anim/player_one_man_band.zip" ),
        Asset( "ANIM", "anim/shadow_hands.zip" ),
		
		Asset( "ANIM", "anim/player_transform_merm.zip" ),
		
        Asset( "SOUND", "sound/sfx.fsb" ),
        Asset( "SOUND", "sound/wilson.fsb" ),
		Asset( "ANIM", "anim/icey_sans_basic.zip" ),
        Asset( "ANIM", "anim/icey.zip" ),

}


local MAX_TARGET_SHARES = 5
local SHARE_TARGET_DIST = 30

local moonbeastbrain = require "brains/moonbeastbrain"
local werepigbrain = require "brains/werepigbrain"
local infectedbrain = require "brains/infectedbrain"

local skilllist = {
	{name = "icey_miss",cd = 2.5},--闪避
	{name = "icey_ds",cd = 5.5},----死亡进击
	{name = "icey_h",cd = 60},------死亡舰队
	{name = "icey_lance",cd = 35},------天空突刺
	{name = "icey_boom",cd = 35},------boom
}


local function PushMusic(inst)
    if ThePlayer == nil then
        inst._playingmusic = false
    elseif ThePlayer:IsNear(inst, inst._playingmusic and 40 or 20) then
		--print(inst,ThePlayer,"Push the triggeredevent at",GetTime())
        inst._playingmusic = true
        ThePlayer:PushEvent("triggeredevent", { name = "icey_sans" ,duration = 3})
    elseif inst._playingmusic and not ThePlayer:IsNear(inst, 50) then
        inst._playingmusic = false
    end
end

local function ontalk(inst, script)
    --inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/idle")
end

local function CalcSanityAura(inst, observer)
    return 0
end

local function OnEat(inst, food)
    if food.components.edible ~= nil then
        if food.components.edible.foodtype == FOODTYPE.VEGGIE then
            --SpawnPrefab("poop").Transform:SetPosition(inst.Transform:GetWorldPosition())
        elseif food.components.edible.foodtype == FOODTYPE.MEAT and
            inst.components.werebeast ~= nil and
            not inst.components.werebeast:IsInWereState() and
            food.components.edible:GetHealth(inst) < 0 then
            inst.components.werebeast:TriggerDelta(1)
        end
    end
end


local function OnAttacked(inst, data)
    --print(inst, "OnAttacked")
    local attacker = data.attacker
	inst.components.combat:SetTarget(attacker)
	inst.components.combat:ShareTarget(attacker, 30, function(dude)
        return  (dude:HasTag("tadalin"))
            and not dude.components.health:IsDead()
    end, 10)
end

local function OnHealthDoDelta(inst)
	if inst.components.health and not inst.components.health:IsDead() then 
		local percent = inst.components.health:GetPercent()
		if inst.components.locomotor and inst.components.combat then 
			inst.components.locomotor.runspeed = 5 + 4 * (1 - percent)
			inst.components.locomotor.walkspeed = 7 + 4 * (1 - percent)
			inst.components.combat:SetAttackPeriod(0.5 * percent)
			--print("On sans healthdelta:",inst.components.locomotor.runspeed,inst.components.locomotor.walkspeed)
		end
	end
end 

local function CheckRange(inst)
	if not inst.components.health or not inst.components.combat then 
		return
	end
	
	local dis = 2
	if inst._icey_ds and  inst.components.health:GetPercent() <= 0.75 then 
		dis = 5
	elseif inst._icey_lance and  inst.components.health:GetPercent() <= 0.5 then 
		dis = 15
	elseif inst._icey_boom and  inst.components.health:GetPercent() <= 0.3 then 
		dis = 5
	else 
		dis = 2
	end
	inst.components.combat:SetRange(dis,dis+0.2)
end

local function OnNewTarget(inst, data)
	CheckRange(inst)
end

local function OnAttack(inst,data)
	local target = data.target
	local x,y,z = target:GetPosition():Get()
	if target:HasTag("wall") then 
		local fx = SpawnPrefab("collapse_small")
		fx.Transform:SetPosition(x,y,z)
		if target.components.lootdropper then 
			target.components.lootdropper:DropLoot()
		end
		target:Remove()
	end
end 

local function OnDeath(inst)
	
end 

 

local function OnTimerDone(inst,data)
	local name = data.name
	inst["_"..name] = true
	CheckRange(inst)
end 

local function OnSpawn(inst)
	inst.AnimState:OverrideSymbol("swap_object", "swap_icey_bluerose", "swap_icey_bluerose")
    inst.AnimState:Show("ARM_carry")
    inst.AnimState:Hide("ARM_normal")
	inst.AnimState:Show("HEAD")
	inst.AnimState:Hide("HEAD_HAT")
	inst.AnimState:OverrideSymbol("swap_body", "swap_krampus_sack", "backpack")
    inst.AnimState:OverrideSymbol("swap_body", "swap_krampus_sack", "swap_body")
	
	
	CheckRange(inst)
end 

local function WerepigRetargetFn(inst)
    return FindEntity(
        inst,
        30,
        function(guy)
            return inst.components.combat:CanTarget(guy)
        end,
        { "_combat" }, --See entityreplica.lua (re: "_combat" tag)
        { "monster","tadalin","structure","prey","smallcreature"}
    )
end

local function WerepigKeepTargetFn(inst, target)
    return inst.components.combat:CanTarget(target)
           and not target:HasTag("tadalin") 
end


------------------------Skills----------------------------------------
local function Miss(inst)
	if not inst._icey_miss or inst.sg:HasStateTag("icey_skill") or (inst.brain and inst.brain.stopped) or inst.components.health:IsDead() then 
		return
	end 
	local my = inst:GetPosition()
	local ents = TheSim:FindEntities(my.x, my.y, my.z, 5, {"_combat"})
	local flag = 0 
	local attacker = nil 
	for k,v in pairs(ents) do 
		if v:IsValid() and v.components.combat and v.components.combat.target == inst and v.sg and v.sg:HasStateTag("attack") then 
			if inst.components.combat and inst:IsValid() then 
				inst.components.combat:SetTarget(v)
				inst.components.combat:ShareTarget(v, 30, function(dude)
					return  dude:HasTag("tadalin")
					and not dude.components.health:IsDead()
					and dude.components.follower ~= nil
					and dude.components.follower.leader == inst.components.follower.leader
				end, 10)
			end
			flag = 1
			attacker = v
			break
		end
	end 
	if flag == 1 and not inst.sg:HasStateTag("busy") then 
		inst.sg:GoToState("icey_miss",{attacker = attacker})
		inst._icey_miss = false
		inst.components.timer:StartTimer("icey_miss",2.5)
	end
end 


local AnimList = {
	"atk_leap_lag",
	"atk_leap",
	"atk",
	"atk_leap",
	"transform_merm",
	"death",
	"idle_loop",
	"quick_eat",
	"superjump_pre",
	"superjump_lag",
	"superjump",
	"superjump_land",
	"atk_pre",
	"run_bronya_pre",
	"run_bronya_loop",
	"run_bronya_pst",
	"hit",
}

local function GetCurrentAnimation(inst)
	for k,v in pairs(AnimList) do 
		if inst.AnimState:IsCurrentAnimation(v) then 
			return v
		end
	end
	return "run_bronya_loop"
end 

local function CreatShadow(inst)
	if inst.components.health:IsDead() 
	or inst.sg:HasStateTag("icey_skill") 
	or inst.sg:HasStateTag("death")
	--or inst.sg:HasStateTag("attack") 
	or inst.sg:HasStateTag("idle") 
	or inst.sg:HasStateTag("hit") 
	then 
		return
	end 
	
	local x,y,z = inst:GetPosition():Get()
	local CurrentAnimation = GetCurrentAnimation(inst)
	local Percent = inst.AnimState:GetCurrentAnimationTime() / inst.AnimState:GetCurrentAnimationLength()
	
	inst:DoTaskInTime(0,function()
		local shadow = SpawnPrefab("icey_sans_shadow")
		shadow:Hide()
		shadow.Transform:SetPosition(x,y,z)
		local nx,ny,nz = inst:GetPosition():Get()
		shadow:ForceFacePoint(nx,ny,nz)
		shadow.AnimState:SetPercent(CurrentAnimation,Percent)
		shadow:DoTaskInTime(0,shadow.Show)
	end)
end 

local function onfuse(inst,another)
	print("Try OnFuse!",inst,another)
	if not inst:HasTag("fused") and not another:HasTag("fused") then 
		local x,y,z = inst:GetPosition():Get()
		local pre = SpawnPrefab("boss_elecarmet_prefx")
		pre.Transform:SetPosition(x,y,z)
		inst:AddTag("fused")
		another:AddTag("fused")
		ErodeAway(inst)
		ErodeAway(another)
	end 
	--inst:Remove()
end 

local function CheckFuse(inst)
	local another = FindEntity(inst, 2.5, function(guy) return guy ~= inst and guy.prefab == "icey_sans" end)
	if another and another ~= nil then 
		onfuse(inst,another)
	end
end 


--------------------------------------------------------------------------------------------------------
local function common()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddDynamicShadow()
	inst.entity:AddLight()
    inst.entity:AddNetwork()

    MakeCharacterPhysics(inst, 50, .5)

    inst.DynamicShadow:SetSize(1.5, .75)
    inst.Transform:SetFourFaced()
	
	inst:AddTag("epic")
	inst:AddTag("noepicmusic")
    inst:AddTag("character")
	inst:AddTag("groggy")
    inst:AddTag("scarytoprey")  
	inst:AddTag("hostile")
	inst:AddTag("tadalin")
	inst:AddTag("monster")
	inst:AddTag("flying")
	
    inst.AnimState:SetBank("wilson") 
	inst.AnimState:SetBuild("icey")
    inst.AnimState:PlayAnimation("idle", true)
	
	inst.Light:SetIntensity(0.7)
	inst.Light:SetRadius(2)
	inst.Light:SetFalloff(0.5)
	inst.Light:SetColour(44/255,143/255,255/255)
	inst.Light:Enable(true)
	
	for k,v in pairs(skilllist) do 
		inst["_"..v.name] = true
	end 
	
	inst.CheckRange = CheckRange

    --Sneak these into pristine state for optimization
    inst:AddTag("_named")
    inst.entity:SetPristine()
	
	inst:AddComponent("talker")
    inst.components.talker.fontsize = 35
    inst.components.talker.font = TALKINGFONT
    --inst.components.talker.colour = Vector3(133/255, 140/255, 167/255)
    inst.components.talker.offset = Vector3(0, -400, 0)
    inst.components.talker:MakeChatter()
	inst.components.talker.ontalk = ontalk
	
	inst._playingmusic = false
	if not TheNet:IsDedicated() then
        inst:DoPeriodicTask(1, PushMusic,0)
    end
	

    if not TheWorld.ismastersim then
        return inst
    end

	inst:AddComponent("combat")
    inst.components.combat:SetRetargetFunction(0, WerepigRetargetFn)
    inst.components.combat:SetKeepTargetFunction(WerepigKeepTargetFn) 
	inst.components.combat:SetDefaultDamage(45)
    inst.components.combat:SetAttackPeriod(0.5)
	inst.components.combat:SetRange(2)
	
    inst:AddComponent("locomotor") -- locomotor must be constructed before the stategraph
    inst.components.locomotor.runspeed = 5
    inst.components.locomotor.walkspeed = 7
	
	inst:AddComponent("rider")
	
    inst:AddComponent("bloomer")

    ------------------------------------------
    inst:AddComponent("eater")
    inst.components.eater:SetDiet({ FOODGROUP.OMNI }, { FOODGROUP.OMNI })
    inst.components.eater:SetCanEatHorrible()
    inst.components.eater:SetCanEatRaw()
    inst.components.eater.strongstomach = true -- can eat monster meat!
    inst.components.eater:SetOnEatFn(OnEat)
    ------------------------------------------
    inst:AddComponent("health")
	inst.components.health:SetMaxHealth(3000)
	inst.components.health:StartRegen(1, 1)

    MakeMediumBurnableCharacter(inst, "torso")

    inst:AddComponent("named")

   
    ------------------------------------------
    inst:AddComponent("follower")
    inst.components.follower.maxfollowtime = TUNING.PIG_LOYALTY_MAXTIME
    ------------------------------------------
    inst:AddComponent("inventory")
    ------------------------------------------
    inst:AddComponent("lootdropper")
	inst.components.lootdropper:SetLoot({ 
		"krampus_sack",
		"icey_blade",
		"icey_ball",
		"icey_ball",
		"icey_ball",
		"gears",
		"gears",
		"bluegem",
		"bluegem",
		"shadow_seed",
	})
    inst.components.lootdropper.numrandomloot = 0
    ------------------------------------------
    inst:AddComponent("knownlocations")
    ------------------------------------------

    inst:AddComponent("sanityaura")
    inst.components.sanityaura.aurafn = CalcSanityAura

    ------------------------------------------
    MakeLargeFreezableCharacter(inst, "torso")
	inst.components.freezable:SetDefaultWearOffTime(TUNING.MOONPIG_FREEZE_WEAR_OFF_TIME)
    ------------------------------------------

    inst:AddComponent("inspectable")
    inst.components.inspectable:SetDescription("这不是我....")
    ------------------------------------------
	inst:AddComponent("timer")
	------------------------------------------
	inst:AddComponent("fuseable")
	inst.components.fuseable:SetOnMateCallback(onfuse)
	------------------------------------------
	MakeHauntablePanic(inst)
	------------------------------------------
	
	inst:SetBrain(infectedbrain)
    inst:SetStateGraph("SGicey_sans")
	
	
	
	OnSpawn(inst)
	inst:DoPeriodicTask(0.1,Miss)
	inst:DoPeriodicTask(0.2,CreatShadow)
	--inst:DoPeriodicTask(0.1,CheckFuse)
	inst:ListenForEvent("healthdelta", OnHealthDoDelta)
	inst:ListenForEvent("attacked", OnAttacked)
	inst:ListenForEvent("onhitother", OnAttack)
	inst:ListenForEvent("death", OnDeath)
    inst:ListenForEvent("newcombattarget", OnNewTarget)
	inst:ListenForEvent("timerdone", OnTimerDone)
    return inst
end

local function Disapperaing(inst)
	local r,g,b,a = inst.AnimState:GetMultColour()
	if a <= 0.1 then 
		inst:Remove()
	else
		inst.AnimState:SetMultColour(r,g,b,a-0.01)
	end
	
end 

local function shadow_fn()
	local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddDynamicShadow()
	inst.entity:AddLight()
    inst.entity:AddNetwork()
	
	inst.Transform:SetFourFaced()

	inst.AnimState:SetBank("wilson") 
	inst.AnimState:SetBuild("icey")
    --inst.AnimState:PlayAnimation("idle", true)
	inst.AnimState:SetMultColour(34/255,0/255,0/255,0.3)
	
	inst:AddTag("FX")
	inst:AddTag("NOCLICK")
	
	inst.persists = false

	inst.entity:SetPristine()

	
	if not TheWorld.ismastersim then
        return inst
    end
	
	OnSpawn(inst)
	--inst:SetStateGraph("SGicey_sans")
	inst:DoPeriodicTask(0,Disapperaing)
	
	return inst

end

return Prefab("icey_sans", common, assets),
Prefab("icey_sans_shadow", shadow_fn, assets)