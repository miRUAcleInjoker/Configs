local IceyUtil = require("icey_util")

local assets =
{ 
    --Asset("ANIM", "anim/chest_monster_hat.zip"),
    Asset("ANIM", "anim/swap_icey_hunter_hat1.zip"), 

    Asset("ATLAS", "images/inventoryimages/icey_hunter_hat1.xml"),
    Asset("IMAGE", "images/inventoryimages/icey_hunter_hat1.tex"),
}




local function OnEquip(inst, owner) 
    owner.AnimState:OverrideSymbol("swap_hat", "swap_icey_hunter_hat1","swap_icey_hunter_hat1")
    owner.AnimState:Show("HAT")
    owner.AnimState:Show("HAIR_HAT")
    owner.AnimState:Hide("HAIR_NOHAT")
    owner.AnimState:Hide("HAIR")

    if owner:HasTag("player") then
        owner.AnimState:Hide("HEAD")
        owner.AnimState:Show("HEAD_HAT")
    end
end

local function OnUnequip(inst, owner) 
	owner.AnimState:ClearOverrideSymbol("swap_hat")
    owner.AnimState:Hide("HAT")
    owner.AnimState:Hide("HAIR_HAT")
    owner.AnimState:Show("HAIR_NOHAT")
    owner.AnimState:Show("HAIR")

    if owner:HasTag("player") then
        owner.AnimState:Show("HEAD")
        owner.AnimState:Hide("HEAD_HAT")
    end
end

local function fn()

    local inst = CreateEntity()
    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()  --�������Ҳ����� 
	
    MakeInventoryPhysics(inst)	
	inst.AnimState:SetBank("swap_icey_hunter_hat1")
    inst.AnimState:SetBuild("swap_icey_hunter_hat1")
    inst.AnimState:PlayAnimation("idle",true)
	
	inst:AddTag("hide_percentage")
	
	
	----------------------����Ķ��� ������������Ч
	
	inst.entity:SetPristine()   --���ľ仰 �ŵ����� Ҳ����bank build ��tag֮��ĺ���-��-
	if not TheWorld.ismastersim then
        return inst
    end
	
	----------------------�����ֻ������ִ��
	
    inst:AddComponent("inspectable")
	
	inst:AddComponent("waterproofer")
	inst.components.waterproofer:SetEffectiveness(TUNING.WATERPROOFNESS_SMALL)

    inst:AddComponent("inventoryitem")
    inst.components.inventoryitem.imagename = "icey_hunter_hat1"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/icey_hunter_hat1.xml"
	
	inst:AddComponent("armor")
    inst.components.armor:InitIndestructible(0.1)
	
    inst:AddComponent("equippable")
    inst.components.equippable.equipslot = EQUIPSLOTS.HEAD 
    inst.components.equippable:SetOnEquip(OnEquip)
    inst.components.equippable:SetOnUnequip(OnUnequip)
	inst.components.equippable.dapperness = TUNING.DAPPERNESS_MED
	inst.components.equippable.stamina_recoverrate = 1.05
	inst.components.equippable.stamina_consumerate = 0.95
	
	MakeHauntableLaunch(inst)  --����ź���ͺ���

    return inst
end

return  Prefab("icey_hunter_hat1", fn, assets, prefabs)