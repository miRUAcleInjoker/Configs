local IceyWhiteSprite = Class(function(self, inst)
	self.inst = inst 
	self.currenttime = 0 
	self.maxtime = 360
	self.ishelping = false 
	
	self.canstart = nil 
	self.onstart = nil 
	self.onfinish = nil 
end)

function IceyWhiteSprite:SetCanStartFn(fn)
	self.canstart = fn 
end 

function IceyWhiteSprite:SetOnStartFn(fn)
	self.onstart = fn 
end 

function IceyWhiteSprite:SetOnFinishFn(fn)
	self.onfinish = fn 
end 

function IceyWhiteSprite:CanStart()
	return not self.inst:HasTag("darkspirit") and (self.canstart == nil or self.canstart(self.inst))
end 

function IceyWhiteSprite:Start(leader)
	self.currenttime = self.maxtime 
	self.ishelping = true 
	self.inst:AddTag("whitespirit")
	if self.inst.components.follower and leader and leader:IsValid() then 
		self.inst.components.follower:SetLeader(leader)
	end
	if self.onstart then 
		self.onstart(self.inst,leader)
	end
	self.inst:StartUpdatingComponent(self)
end

function IceyWhiteSprite:Finish()
	self.inst:StopUpdatingComponent(self)
	self.currenttime = 0
	self.ishelping = false 
	self.inst:RemoveTag("whitespirit")
	if self.onfinish then 
		local leader = self.inst.components.follower and self.inst.components.follower.leader
		self.onfinish(self.inst,leader)
	end
	if self.inst.components.follower then 
		self.inst.components.follower:SetLeader(nil)
	end
end

function IceyWhiteSprite:OnUpdate(dt)
	self.currenttime = self.currenttime - dt 
	if self.currenttime <= 0 then 
		self:Finish()
	end
end


return IceyWhiteSprite