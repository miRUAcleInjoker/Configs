local IceyUtil = require("icey_util")
local assets=
{
	Asset("ANIM", "anim/halberd.zip"),
	Asset("ANIM", "anim/swap_halberd.zip"),
	
	Asset("IMAGE","images/inventoryimages/dark_halberd.tex"),
	Asset("ATLAS","images/inventoryimages/dark_halberd.xml"),
	
	Asset("ANIM", "anim/halloween_embers.zip")

}

local function onfinished(inst)
	inst:Remove()
end

local function canattack(v,inst) ------------多重保险：判定目标是否真的可以被攻击，可以被伤害
	return IceyUtil.CanAttack(v,inst)
end

local function onequip(inst, owner)
	owner.AnimState:OverrideSymbol("swap_object", "swap_halberd", "swap_halberd")
	owner.AnimState:Show("ARM_carry")
	owner.AnimState:Hide("ARM_normal")
	
	--[[if not inst.LocomoteFxTask and owner:HasTag("player") then 
		inst.LocomoteFxTask = inst:DoPeriodicTask(0.2,function()
			if owner.sg and owner.sg:HasStateTag("moving") then 
				SpawnPrefab("cane_ancient_fx").Transform:SetPosition(inst:GetPosition():Get())
			end 
		end)
	end --]]
end

local function onunequip(inst, owner)
	owner.AnimState:Hide("ARM_carry")
	owner.AnimState:Show("ARM_normal")
	
--[[	if inst.LocomoteFxTask then 
		inst.LocomoteFxTask:Cancel()
		inst.LocomoteFxTask = nil 
	end--]]
end

local function DoAeraAttack(owner,pos,rad)
	local x,y,z = pos:Get()
	local ents = TheSim:FindEntities(x,y,z,rad,{"_combat"})
	for k,v in pairs(ents) do 
		if canattack(v,owner) then 
			v.components.combat:GetAttacked(owner,math.random(30,55))
		end
	end 
end 

local function SpawnFireFlames(inst,attacker,target)
	local ownerpos = attacker:GetPosition()
	local targetpos = target:GetPosition()
	local vector = (targetpos - ownerpos) 
	local vector_single = vector:GetNormalized() 
	local cross_single = vector_single:Cross(Vector3(0,1,0)):GetNormalized() 
	local firenum = 7
	local perdist = 2 
	
	inst:StartThread(function()
		for i=1,firenum do
			local spawnpos = ownerpos + vector_single * perdist * i
			local spawnpos2 = ownerpos + vector_single * perdist * i + cross_single * (i-1)
			local spawnpos3 = ownerpos + vector_single * perdist * i - cross_single * (i-1) 
			local fx = SpawnPrefab("dark_halberd_fx")
			fx.Transform:SetScale(1.5,1.5,1.5)
			fx.Transform:SetPosition(spawnpos:Get()) 
			local trail = SpawnPrefab("damp_trail")
			trail.Transform:SetPosition(spawnpos:Get()) 
			trail:SetVariation(math.random(1,7),0.8,1.5+math.random())
			DoAeraAttack(attacker,spawnpos,1.5)
			local fx2 = SpawnPrefab("dark_halberd_fx")
			fx2.Transform:SetScale(1.5,1.5,1.5)
			fx2.Transform:SetPosition(spawnpos2:Get())
			local trail2 = SpawnPrefab("damp_trail")
			trail2.Transform:SetPosition(spawnpos2:Get()) 
			trail2:SetVariation(math.random(1,7),0.8,1.5+math.random())
			DoAeraAttack(attacker,spawnpos2,1.5)
			local fx3 = SpawnPrefab("dark_halberd_fx")
			fx3.Transform:SetScale(1.5,1.5,1.5)
			fx3.Transform:SetPosition(spawnpos3:Get())
			local trail3 = SpawnPrefab("damp_trail")
			trail3.Transform:SetPosition(spawnpos3:Get()) 
			trail3:SetVariation(math.random(1,7),0.8,1.5+math.random())
			DoAeraAttack(attacker,spawnpos3,1.5)
			Sleep(0.05)
		end 
	end)
end 

local function onattack(inst,attacker,target)
	inst.DarkDamages = inst.DarkDamages + 40
	if inst.DarkDamages >= 700 then 
		SpawnFireFlames(inst,attacker,target)
		inst.DarkDamages = 0
	end 
end 

local function normalfn()
	local inst = CreateEntity()
	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddSoundEmitter()
	inst.entity:AddNetwork()
	
	MakeInventoryPhysics(inst)

	inst.AnimState:SetBank("halberd")
	inst.AnimState:SetBuild("halberd")
	inst.AnimState:PlayAnimation("idle")

	inst:AddTag("halberd")

	inst:AddTag("sharp")
	
	inst.entity:SetPristine()
    if not TheWorld.ismastersim then
        return inst
    end	  
	
	
	inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "dark_halberd"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/dark_halberd.xml"

	inst:AddComponent("weapon")
	inst.components.weapon:SetDamage(44.5)

	-----
	inst:AddComponent("tool")
	inst.components.tool:SetAction(ACTIONS.CHOP)
	-------
	inst:AddComponent("finiteuses")
	inst.components.finiteuses:SetMaxUses(100)
	inst.components.finiteuses:SetUses(100)
	inst.components.finiteuses:SetOnFinished( onfinished)
	inst.components.finiteuses:SetConsumption(ACTIONS.CHOP, 1)

	inst:AddComponent("inspectable")

	inst:AddComponent("equippable")
	inst.components.equippable:SetOnEquip( onequip )
	inst.components.equippable:SetOnUnequip( onunequip)

	return inst
end 

local function fn()
	local inst = CreateEntity()
	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddSoundEmitter()
	inst.entity:AddNetwork()
	
	MakeInventoryPhysics(inst)

	inst.AnimState:SetBank("halberd")
	inst.AnimState:SetBuild("halberd")
	inst.AnimState:PlayAnimation("idle")

	inst:AddTag("halberd")

	inst:AddTag("sharp")
	
	inst.entity:SetPristine()
    if not TheWorld.ismastersim then
        return inst
    end	  
	
	inst.DarkDamages = 0
	
	inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "dark_halberd"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/dark_halberd.xml"

	inst:AddComponent("weapon")
	inst.components.weapon:SetDamage(44.5)
	inst.components.weapon:SetOnAttack(onattack)

	-----
	inst:AddComponent("tool")
	inst.components.tool:SetAction(ACTIONS.CHOP)
	-------
	inst:AddComponent("finiteuses")
	inst.components.finiteuses:SetMaxUses(300)
	inst.components.finiteuses:SetUses(300)
	inst.components.finiteuses:SetOnFinished( onfinished)
	inst.components.finiteuses:SetConsumption(ACTIONS.CHOP, 1)
	-------

	inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("充满了深邃黑暗的气息!")

	inst:AddComponent("equippable")
	inst.components.equippable:SetOnEquip( onequip )
	inst.components.equippable:SetOnUnequip( onunequip)

	return inst
end

local function fxfn()
	local inst = CreateEntity()--以下这三句都是默认要添加的，这里就不解释那么多了
	local trans = inst.entity:AddTransform()
	local anim = inst.entity:AddAnimState()
	inst.entity:AddSoundEmitter()
	inst.entity:AddNetwork()
	
	inst:AddTag("NO_TIME_STOP")
	inst:AddTag("FX")
	
	anim:SetBank("halloween_embers")-----前面两句是指定timecrack的图片边界和材质，在特效中作用不大，只是必写。
	anim:SetBuild("halloween_embers")
	anim:PlayAnimation("puff_"..tostring(math.random(1,3)))
	
	anim:SetMultColour(0,0,0,0.7)
	
	inst.AnimState:SetFinalOffset(3)
	inst.AnimState:SetBloomEffectHandle("shaders/anim.ksh")
	
	inst.persists = false
	
	inst.entity:SetPristine()
    if not TheWorld.ismastersim then
        return inst
    end	  
	
	inst.SoundEmitter:PlaySound("dontstarve/common/fireAddFuel")
	inst:ListenForEvent("animover", inst.Remove)
	
	return inst
end



return Prefab( "dark_halberd", fn, assets),
Prefab( "dark_halberd_fx", fxfn, assets),
Prefab( "halberd", normalfn, assets)

