local IceyUtil = require("icey_util")
local assets =
{
    Asset("ANIM", "anim/icey_blade.zip"),
	Asset("ANIM", "anim/icey_bluerose.zip"),
    Asset("ANIM", "anim/swap_icey_blade.zip"),
	Asset("ANIM", "anim/swap_icey_blade2.zip"),
	Asset("ANIM", "anim/swap_icey_bluerose.zip"),
	Asset("ANIM", "anim/swap_icey_bluerose_max.zip"),
	--Asset("ANIM", "anim/swap_icey_blade_circle.zip"),
	--Asset("ANIM", "anim/swap_icey_heavyblade.zip"),
	Asset("IMAGE","images/inventoryimages/icey_bluerose.tex"),
	Asset("ATLAS","images/inventoryimages/icey_bluerose.xml"),
	--Asset("ANIM", "anim/swap_bb_blade1.zip"),
	
	--Asset("IMAGE","images/inventoryimages/icey_heavyblade.tex"),
	--Asset("ATLAS","images/inventoryimages/icey_heavyblade.xml"),
}

local assets_crackle = {
  Asset("ANIM", "anim/lavaarena_hammer_attack_fx.zip"),
}

local prefabs = {
	"hammer_mjolnir_crackle",
	"hammer_mjolnir_cracklehit",
	"hammer_mjolnir_cracklebase",
	"cracklehitfx",
	"reticuleaoe",
	"reticuleaoeping",
	"reticuleaoehostiletarget",
	"weaponsparks",
	"sunderarmordebuff",
}

local prefabs_crackle = {
  "hammer_mjolnir_cracklebase",
}


local max_level = 20
local ly_preatk = 35

local function canattack(v,inst) ------------多重保险：判定目标是否真的可以被攻击，可以被伤害
	return IceyUtil.CanAttack(v,inst)
end  

local function setname(inst)
	local name = STRINGS.NAMES.ICEY_BLADE
	if inst.components and inst.components.named then 
		inst.components.named:SetName(name.."\n阶级:"..inst.ly_level.."/"..max_level)
	end
end 

local function applyupgrades(inst)
    inst.ly_level = math.min(inst.ly_level, max_level)
	setname(inst)
	inst.components.weapon:SetDamage(ly_preatk + inst.ly_level * 1)
	if inst.ly_level >= max_level then 
		inst.components.weapon:SetRange(0.5, 0.6)
	else
		inst.components.weapon:SetRange(nil,nil)
	end 
	if inst.ly_level >= max_level and inst.components.equippable:IsEquipped() then 
		local owner = inst.components.inventoryitem.owner
		if owner then 
			owner.AnimState:OverrideSymbol("swap_object", "swap_icey_bluerose_max", "swap_icey_bluerose_max")
		end
	end
end

local function onlevelup(inst)
	inst.SoundEmitter:PlaySound("dontstarve/characters/wx78/levelup")
	if	inst.ly_level < max_level then  inst.ly_level = inst.ly_level + 1 end 
	applyupgrades(inst)
end



local function onsave(inst, data)
    data.ly_level = inst.ly_level > 0 and inst.ly_level or nil
end

local function onpreload(inst, data)
    if data ~= nil and data.ly_level ~= nil then
      inst.ly_level = data.ly_level
      applyupgrades(inst)
	end
end

--------------------------------------------------------------------------

local function ReticuleTargetFn()
  local player = ThePlayer
  local ground = TheWorld.Map
  local pos = Vector3()
  --Cast range is 8, leave room for error
  --4 is the aoe range
  for r = 7, 0, -.25 do
    pos.x, pos.y, pos.z = player.entity:LocalToWorldSpace(r, 0, 0)
    if ground:IsPassableAtPoint(pos:Get()) and not ground:IsGroundTargetBlocked(pos) then
      return pos
    end
  end
  return pos
end

local function ondrop(inst)
	if inst.fire == nil then
        inst.fire = SpawnPrefab("icey_blade_fx")
		inst.fire.entity:SetParent(inst.entity)         
		inst.fire.Transform:SetPosition(0,0,0) 
		inst.fire.owner = inst
    end
end 

local function onpick(inst,owner)
	if inst.fire ~= nil then
        inst.fire:Remove()
        inst.fire = nil
    end
end 

local function OnCQCAttack(inst,data)
	local target = data.target
	local type = data.type 
	local weapon = inst.components.combat:GetWeapon() 
	
	if weapon and target and target:IsValid() and type  and type ~= "circle" then 
		SpawnPrefab("electrichitsparks"):AlignToTarget(target, inst, true)
		if type == "hop" then 
			for i = 1,3 do 
				local fx = SpawnPrefab("electrichitsparks")
				local targetpos = target:GetPosition()
				local rota = PI * math.random() * 2
				local offset = Vector3(math.random()*2*math.cos(rota),0,math.random()*2*math.sin(rota))
				fx:AlignToTarget(target, inst, true)
				fx.Transform:SetPosition((targetpos+offset):Get())
			end
		elseif type == "multithrust" then 
			inst:StartThread(function()
				for i = 1,5 do 
					SpawnPrefab("electrichitsparks"):AlignToTarget(target, inst, true)
					Sleep(FRAMES)
				end 
			end)
		end 
	end
end 

local function onequip(inst, owner)
    --owner.AnimState:OverrideSymbol("swap_object", "swap_icey_blade2", "swap_icey_blade2")
	--owner.AnimState:OverrideSymbol("swap_object", "swap_bb_blade1", "swap_bb_blade1")
	--owner.AnimState:OverrideSymbol("swap_object", "swap_icey_heavyblade", "swap_icey_heavyblade")
	if inst.ly_level < max_level then 
		owner.AnimState:OverrideSymbol("swap_object", "swap_icey_bluerose", "swap_icey_bluerose")
	else
		owner.AnimState:OverrideSymbol("swap_object", "swap_icey_bluerose_max", "swap_icey_bluerose_max")
	end 
    owner.AnimState:Show("ARM_carry")
    owner.AnimState:Hide("ARM_normal")
	if inst.fire == nil then
        inst.fire = SpawnPrefab("icey_blade_fx")
        inst.fire.entity:AddFollower()
        inst.fire.Follower:FollowSymbol(owner.GUID, "swap_object", 0, -110, 0)
		inst.fire.owner = inst
    end
	
	inst:ListenForEvent("icey_cqc_attack",OnCQCAttack,owner)
end

local function onunequip(inst, owner)
	if inst.fire ~= nil then
        inst.fire:Remove()
        inst.fire = nil
    end
    owner.AnimState:Hide("ARM_carry")
    owner.AnimState:Show("ARM_normal")
	--thief(inst,owner)
	
	inst:RemoveEventCallback("icey_cqc_attack",OnCQCAttack,owner)
end

local function OnLeapFn(doer,startpos,targetpos)
	local weapon = doer.components.combat:GetWeapon()
	if not (weapon and weapon:IsValid()) then 
		return 
	end 
	
	SpawnAt("hammer_mjolnir_crackle",targetpos).AnimState:SetAddColour(0/255, 138/255, 255/255, 0.9)
	SpawnAt("hammer_mjolnir_cracklebase",targetpos).AnimState:SetAddColour(0/255, 138/255, 255/255, 0.9)
	SpawnAt("hammer_mjolnir_cracklehit",targetpos).AnimState:SetAddColour(0/255, 138/255, 255/255, 0.9)
	SpawnAt("cracklehitfx",targetpos).AnimState:SetAddColour(0/255, 138/255, 255/255, 0.9)
	SpawnAt("electricchargedfx",targetpos)
	
	local dmg = ly_preatk + (weapon.ly_level or 0)  + 10
	local radius = 5
	if doer.sky_death == 1 then --死神天降
		dmg = dmg + 10
	end 
	if doer.hit_ground == 1 and math.random(0,100) <= 50 then --大地重击
		local fx1 = SpawnPrefab("groundpoundring_fx")
		local fx2 = SpawnPrefab("groundpound_fx")
		fx1.Transform:SetPosition(targetpos.x,targetpos.y,targetpos.z)
		fx2.Transform:SetPosition(targetpos.x,targetpos.y,targetpos.z)
		ShakeAllCameras(CAMERASHAKE.VERTICAL, .7, .025, 1.25, doer, 40)
		dmg = dmg * 3
		radius = 6
	end 
		
	local ents  = TheSim:FindEntities(targetpos.x,targetpos.y,targetpos.z,radius, {"_combat"},TUNING.ICEY_NO_TAGS)
	for k,v in pairs(ents) do
		local new_dmg = dmg
		if doer.shut_down == 1 and v.components.health and v.components.health:GetPercent() <= 0.15 and not v.components.health:IsDead() then 
			--处决
			new_dmg = v.components.health.currenthealth * 100 + dmg
			
			local gain = v.components.health.maxhealth / 100
			local magicnum = math.min(math.random(1,math.max(gain,1)),40)
			if doer.iron_hitter == 1 then 
				if not doer.components.health:IsDead() then
					doer.components.health:DoDelta(magicnum*5)
					doer.components.sanity:DoDelta(magicnum*5)
					if doer.components.focus then 
						doer.components.focus:DoDelta(magicnum*8)
					end
					if doer.components.stamina then 
						doer.components.stamina:DoDelta(magicnum*20)
					end
				end
			end
		end 

		if canattack(v,doer) then
			v.components.combat:GetAttacked(doer, new_dmg,nil,"electric") 
			--SpawnPrefab("electrichitsparks"):AlignToTarget(v, doer, true)
		end
	end

	--doer:ListenForEvent("animover",onfresh)
		
	doer.SoundEmitter:PlaySound("dontstarve/common/destroy_smoke")
	doer.SoundEmitter:PlaySound("dontstarve/impacts/lava_arena/hammer")
	doer.SoundEmitter:PlaySound("dontstarve/impacts/lava_arena/electric")
	
end 

local function oncastfn(inst, doer,pos)
	if IceyUtil.DefaultCostFn(doer,{stamina = 40,focus = 20}) then 
		inst.components.rechargeable:StartRecharge()
		doer:PushEvent("combat_leap", {targetpos = pos, weapon = inst})
	end 
end

---------------------------------------------------------------------------
local function ShouldAcceptItem(inst,item)
	return  ( (string.find(item.prefab,'gem')) or item.prefab == "icey_blade" )and inst.ly_level < max_level
end 

local function OnGetItemFromPlayer(inst,giver,item)
	local nums = 1
	if string.find(item.prefab,'preciousgem')then 
		nums = 7
	elseif item.prefab == "icey_blade" then 
		nums = item.ly_level or 1
	end 
	for i=1,nums do 
		onlevelup(inst)
	end 
end 

local function OnRefuseItem(inst, giver,item)
	if inst.ly_level == max_level then 
		giver.components.talker:Say("所有能改装的地方都已经改装了")
	else	
		giver.components.talker:Say("只能用宝石或者另一把剑改装呢~")
	end
end
---------------------------------------------------------------------------

local function SetLevel(inst,level)
	inst.ly_level = level or 20
	applyupgrades(inst)
end 

local function OnLeap(inst)
	SpawnPrefab("forginghammer_crackle_fx"):SetTarget(inst)
	inst.components.rechargeable:StartRecharge()
end



local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()
	inst.entity:AddSoundEmitter()
    MakeInventoryPhysics(inst)

    inst.AnimState:SetBank("icey_bluerose")
    inst.AnimState:SetBuild("icey_bluerose")
    inst.AnimState:PlayAnimation("idle")

    inst:AddTag("sharp")
	inst:AddTag("melee")
	inst:AddTag("icey_aoeweapon_leap")
	inst:AddTag("rechargeable")
	inst:AddTag("trader")
	inst:AddTag("tradable")
	inst:AddTag("icey_blade")
	--inst:AddTag("vacuum_sword")
	
	
	inst:AddComponent("aoetargeting")
	inst.components.aoetargeting:SetTargetFX("weaponsparks")
	inst.components.aoetargeting.reticule.reticuleprefab = "reticuleaoe"
	inst.components.aoetargeting.reticule.pingprefab = "reticuleaoeping"
	inst.components.aoetargeting.reticule.targetfn = ReticuleTargetFn
	inst.components.aoetargeting.reticule.validcolour = { 73/255, 240/255, 235/255, 1 }
	inst.components.aoetargeting.reticule.invalidcolour = { 178/255, 100/255, 50/255, 1 }
	inst.components.aoetargeting.reticule.ease = true
	inst.components.aoetargeting.reticule.mouseenabled = true
	inst.components.aoetargeting:SetRange(12)
--[[	
	inst:AddComponent("rechargeable")
	inst.components.rechargeable:SetRechargeTime(15)
	--]]
	
	
	
    inst.entity:SetPristine()	
	
    if not TheWorld.ismastersim then
        return inst
    end	  
	
	inst:AddComponent("named")
	inst.ly_level = 1 
	inst.OnSave = onsave
    inst.OnPreLoad = onpreload
	inst.SetLevel = SetLevel

    inst:AddComponent("weapon")
    inst.components.weapon:SetDamage(ly_preatk)
	--inst.components.weapon:SetOnAttack(onattack)
	--inst.components.weapon:SetElectric()

    inst:AddComponent("inspectable")
	inst.components.inspectable.descriptionfn = function(inst,viewer)
		return inst.ly_level < 20 and "我可以用宝石或者另一把剑改装这武器" or "我们是艾尔的利刃?"
	end
		
	inst:AddComponent("aoespell")
	if TheNet:GetServerGameMode() == "lavaarena" then 
		inst.components.aoespell:SetAOESpell(oncastfn)
	else  
		inst.components.aoespell:SetOnCastFn(oncastfn)
	end 

    inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "icey_bluerose"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/icey_bluerose.xml"


    inst:AddComponent("equippable")
    inst.components.equippable:SetOnEquip(onequip)
    inst.components.equippable:SetOnUnequip(onunequip)
	inst.components.equippable.walkspeedmult = 1.05
	
	inst:AddComponent("tradable")
	
	inst:AddComponent("trader")
    inst.components.trader:SetAcceptTest(ShouldAcceptItem)
    inst.components.trader.onaccept = OnGetItemFromPlayer
    inst.components.trader.onrefuse = OnRefuseItem
	
	inst:AddComponent("chosenicey")
	
	inst:AddComponent("rechargeable")
	inst.components.rechargeable:SetRechargeTime(15)
	
	inst:AddComponent("aoeweapon_leap")
	inst.components.aoeweapon_leap:SetOnLeap(OnLeapFn)
	if TheNet:GetServerGameMode() == "lavaarena"  then 
		inst.components.aoeweapon_leap:SetStimuli("electric")
		inst.components.aoeweapon_leap:SetOnLeapFn(OnLeap)
	end 
	
	inst:ListenForEvent("ondropped",ondrop)
	inst:ListenForEvent("onputininventory",onpick)
	
	applyupgrades(inst)
    MakeHauntableLaunch(inst)

    return inst
end

local function fxfn()
	local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddLight()
    inst.entity:AddNetwork()

    inst:AddTag("FX")

    inst.Light:SetIntensity(0.7)
	inst.Light:SetRadius(1.25)
	inst.Light:SetFalloff(0.5)
	inst.Light:SetColour(0/255,255/255,255/255)
	inst.Light:Enable(true)

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst.persists = false
	inst:DoTaskInTime(0,function()
		if inst.owner == nil then 
			inst:Remove()
		end
	end)
	
    return inst
end

local function cracklefn()
  local inst = CreateEntity()

  inst.entity:AddTransform()
  inst.entity:AddAnimState()
  inst.entity:AddSoundEmitter()
  inst.entity:AddNetwork()

  inst.AnimState:SetBank("lavaarena_hammer_attack_fx")
  inst.AnimState:SetBuild("lavaarena_hammer_attack_fx")
  inst.AnimState:PlayAnimation("crackle_hit")
  inst.AnimState:SetBloomEffectHandle("shaders/anim.ksh")
  inst.AnimState:SetFinalOffset(1)
  inst.AnimState:SetLightOverride(1)


  inst:AddTag("FX")
  inst:AddTag("NOCLICK")

  inst.entity:SetPristine()

  if not TheWorld.ismastersim then
    return inst
  end

inst:ListenForEvent("animover",inst.Remove )

  return inst
end

local function cracklebasefn()
  local inst = CreateEntity()

  inst.entity:AddTransform()
  inst.entity:AddAnimState()
  inst.entity:AddNetwork()

  inst.AnimState:SetBank("lavaarena_hammer_attack_fx")
  inst.AnimState:SetBuild("lavaarena_hammer_attack_fx")
  inst.AnimState:PlayAnimation("crackle_projection")
  inst.AnimState:SetBloomEffectHandle("shaders/anim.ksh")
  inst.AnimState:SetOrientation(ANIM_ORIENTATION.OnGround)
  inst.AnimState:SetLayer(LAYER_BACKGROUND)
  inst.AnimState:SetSortOrder(3)
  inst.AnimState:SetScale(1.5, 1.5)
  inst.AnimState:SetLightOverride(1)

  inst:AddTag("FX")
  inst:AddTag("NOCLICK")


  inst.entity:SetPristine()

  if not TheWorld.ismastersim then
    return inst
  end

inst:ListenForEvent("animover",inst.Remove )

  inst.persists = false

  return inst
end

local function MakeCrackleHit(name, withsound)
  local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    if withsound then
       inst.entity:AddSoundEmitter()
    end
    inst.entity:AddNetwork()

    inst.AnimState:SetBank("lavaarena_hammer_attack_fx")
    inst.AnimState:SetBuild("lavaarena_hammer_attack_fx")
    inst.AnimState:PlayAnimation("crackle_loop")
    inst.AnimState:SetBloomEffectHandle("shaders/anim.ksh")
    inst.AnimState:SetFinalOffset(1)
    inst.AnimState:SetScale(1.5, 1.5)
	inst.AnimState:SetLightOverride(1)

    inst:AddTag("FX")
    inst:AddTag("NOCLICK")
	

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
      return inst
    end
	
	inst:ListenForEvent("animover",inst.Remove )

    return inst
  end

  return Prefab(name, fn, assets_crackle)
end






return Prefab( "icey_blade_fx", fxfn),
	   Prefab( "common/inventory/icey_blade", fn, assets,prefabs),
       Prefab("hammer_mjolnir_crackle", cracklefn, assets_crackle, prefabs_crackle),
       Prefab("hammer_mjolnir_cracklebase", cracklebasefn, assets_crackle),
       MakeCrackleHit("hammer_mjolnir_cracklehit", false),
       MakeCrackleHit("cracklehitfx", true)


