IceyAchievement = Class(function(self,name,current,max,bonus,showtype)
	self.name = name 
	self.current = current or 0
	self.max = max or 1
	self.showtype = showtype
	self.bonus = bonus or 1 
end) 

function IceyAchievement:__tostring()
	local ret = "[IceyAchievement]"
	ret = ret.." Name:"..self.name.." Process:"..self.current.."/"..self.max.." Bonus:"..self.bonus.." Showtype:"..tostring(self.showtype)
	return ret 
end 

function IceyAchievement:IsAchieved()
	return self.current >= self.max
end 

function IceyAchievement:GetPercent()
	return self.current / self.max
end 

function IceyAchievement:GetShowString()
	if not self.showtype or self.showtype == "number" then 
		return tostring("进度:"..self.current.."/"..self.max)
	elseif self.showtype == "percent" then 
		local percent = self:GetPercent()
		percent = math.floor(percent * 100) / 100
		return tostring("进度:"..percent.."%")
	end
end 

function IceyAchievement:SetVal(val)
	self.current = val
	self.current = math.max(self.current,0)
	self.current = math.min(self.current,self.max)
end 

function IceyAchievement:DoDelta(delta)
	self:SetVal(self.current+delta)
end 

function IceyAchievement:OnSave()
	return {
		current = self.current,
	}
end 

function IceyAchievement:OnLoad(data)
	if data then 
		self.current = data.current
	end 
end 

-------------------------------------------------------------------------------------------------------------

local function ApplyToReplica(self,name)
	print("ApplyToReplica !!!")
	if name then 
		local ache = self:Get(name) 
		self.inst.replica.icey_achievement_user:SetVal(name,ache.current)
	else
		for k,v in pairs(self.achievements) do 
			self.inst.replica.icey_achievement_user:SetVal(v.name,v.current)
		end 
	end 
end 

local function ondebugstring(self,debugstring)
	ApplyToReplica(self) 
end 

local IceyAchievementUser = Class(function(self, inst)
	self.inst = inst
	self.achievements = {
		--IceyAchievement("first_eat"),
		--IceyAchievement("first_killother"),
	}
	for k,v in pairs(TUNING.ICEY_ALL_ACHIEVEMENTS_LIST) do 
		table.insert(self.achievements,IceyAchievement(v.name,v.current,v.max,v.bonus))
	end 
	self.all_bonus = 0
	self.debugstring = ""
end,
nil,
{
	debugstring = ondebugstring,
}) 

function IceyAchievementUser:Get(name)
	for k,v in pairs(self.achievements) do 
		if v.name == name then 
			return v
		end
	end
end 

function IceyAchievementUser:IsAchieved(name)
	local ache = self:Get(name) 
	return ache and ache:IsAchieved()
end

function IceyAchievementUser:OnAchieve(name)
	local ache = self:Get(name) 
	local str = name
	for k,v in pairs(TUNING.ICEY_ALL_ACHIEVEMENTS_LIST) do 
		if v.name == name then 
			str = v.title
		end 
	end 
	self.inst.components.talker:Say("达成成就: "..str.." !")
	self.all_bonus = self.all_bonus + ache.bonus
end 

function IceyAchievementUser:SetVal(name,val,ignore_have_achieved)
	local ache = self:Get(name) 
	if ache:IsAchieved() and not ignore_have_achieved then 
		return 
	end 
	ache:SetVal(val) 
	if ache:IsAchieved() then 
		self:OnAchieve(name) 
	end 
	self:UpdateDebugString()
end 

function IceyAchievementUser:DoDelta(name,delta,ignore_have_achieved)
	local ache = self:Get(name) 
	self:SetVal(name,ache.current + delta,ignore_have_achieved)
end 

function IceyAchievementUser:Achieve(name)
	local ache = self:Get(name) 
	ache:SetVal(ache.max)
end 

function IceyAchievementUser:OnSave()
	local data = {}
	for k,v in pairs(self.achievements) do 
		data[v.name] = v:OnSave()
	end 
	data.all_bonus = self.all_bonus
	
	return data
end

function IceyAchievementUser:OnLoad(data)
	if data then 
		for name,v in pairs(data) do 
			local ache = self:Get(name)  
			if ache then 
				ache:OnLoad(v)
			end
		end
		self.all_bonus = data.all_bonus or 0 
	end
	
	self:UpdateDebugString()
end

--ThePlayer.replica.icey_achievement_user:Debug()
--ThePlayer.components.icey_achievement_user:Debug()
--ThePlayer.components.icey_achievement_user:DoDelta("first_eat",3)
function IceyAchievementUser:Debug()	
	print(self:UpdateDebugString())
end

function IceyAchievementUser:UpdateDebugString()
	local start = "[IceyAchievementUser]:Debug\n"
	local middle = ""
	local endline = "AllBonus:"..self.all_bonus.."\n[IceyAchievementUser]:Debug Finished"
	
	for k,v in pairs(self.achievements) do 
		middle = middle..tostring(v).."\n"
	end
	
	local ret = start..middle..endline
	self.debugstring = ret 
	
	return ret
end

return IceyAchievementUser