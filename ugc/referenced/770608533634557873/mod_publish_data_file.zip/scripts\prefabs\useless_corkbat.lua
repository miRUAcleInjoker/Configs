local IceyUtil = require("icey_util")
local IceyWeaponSkillUtil = require("icey_weaponskill_util")

local assets =
{
	Asset("ANIM", "anim/cork_bat.zip"),
	Asset("ANIM", "anim/swap_cork_bat.zip"),
	Asset("IMAGE","images/inventoryimages/useless_corkbat.tex"),
	Asset("ATLAS","images/inventoryimages/useless_corkbat.xml"),
}

--helmsplitter

local function clientfn(inst)
	IceyWeaponSkillUtil.AddAoetargetingClient(inst,"line",{"iceyweaponskill_taunt"},15)
end 

local function onattack(inst, attacker, target)
	local buff = attacker.components.debuffable:GetDebuff("taunt_corkbat")
	if buff and math.random() <= 0.33 then 
		inst.components.helmsplitter.ready = true 
		inst:AddTag("helmsplitter") 
	end 
end 

local function OnHelmSplit(inst,attacker,target)
	--ShakeAllCameras(CAMERASHAKE.VERTICAL, .7, .025, 1.25, inst, 40)
	inst.SoundEmitter:PlaySound("dontstarve_DLC001/creatures/bearger/groundpound")
end 


local function serverfn(inst)
	if not TheWorld.ismastersim then
		return inst
	end	  
	
	inst:AddComponent("helmsplitter")
	inst.components.helmsplitter:SetOnHelmSplitFn(OnHelmSplit)
	
	IceyWeaponSkillUtil.AddAoetargetingServer(inst,function(inst,doer,pos)
		if IceyUtil.DefaultCostFn(doer,{focus = 5}) then 
			inst.components.rechargeable:StartRecharge()
			inst.components.helmsplitter.ready = true 
			inst:AddTag("helmsplitter") 
			doer.components.debuffable:AddDebuff("taunt_corkbat","icey_normal_debuff")
			
			local fx = doer:SpawnChild("battlestandard_buff_fxs")
			fx:Play("attack_fx3")
			local buff = doer.components.debuffable:GetDebuff("taunt_corkbat")
			buff:Init({damage_multi = 1.10,buff_fx = fx,duration = 10})
			
			local battlecryfx = doer:SpawnChild("icey_battlecry_fxs")	
			battlecryfx:DoTaskInTime(2+math.random(),battlecryfx.RemoveBattleCryFX)		
		end 
	end,nil,15)
	
	inst.components.weapon:SetOnAttack(onattack)
	
	inst.components.equippable.walkspeedmult = 0.90
	inst.components.equippable.stamina_consumerate = 1.15
	inst.components.equippable.stamina_recoverrate = 0.85
end

local DATA = {
	prefabname = "useless_corkbat",
	assets = assets,
	tags = {"bat","corkbat","slowattack"},
	bank = "cork_bat",
	build = "cork_bat",
	anim = "idle",
	swapanims = {"swap_cork_bat","swap_cork_bat"},
	damage = 62,
	ranges = 0.2,
	maxuse = 75,
	clientfn = clientfn,
	serverfn = serverfn,
}

--[[return IceyUtil.CreateNormalWeapon("useless_corkbat",assets,{"bat","corkbat","slowattack"},
	"cork_bat",
	"cork_bat",
	"idle",
	{"swap_cork_bat","swap_cork_bat"},
	62,0.2,100,clientfn,serverfn
)--]]
return IceyUtil.CreateNormalWeapon(DATA)