require("stategraphs/commonstates")

local function DoFoleySounds(inst)

	for k,v in pairs(inst.components.inventory.equipslots) do
		if v.components.inventoryitem and v.components.inventoryitem.foleysound then
			inst.SoundEmitter:PlaySound(v.components.inventoryitem.foleysound)
		end
	end

end

local function SpawnBloodFx(inst,symbol)
	local fx = SpawnPrefab("blood_hit_fx_icey")
	local x,y,z = inst:GetPosition():Get()
	fx.Transform:SetPosition(x,y,z)
	fx.AnimState:SetMultColour(196/255,0,0,1)
	fx.Transform:SetScale(0.5,0.5,0.5)
end 

local function OnRemoveCleanupTargetFX(inst)
    if inst.sg.statemem.targetfx.KillFX ~= nil then
        inst.sg.statemem.targetfx:RemoveEventCallback("onremove", OnRemoveCleanupTargetFX, inst)
        inst.sg.statemem.targetfx:KillFX()
    else
        inst.sg.statemem.targetfx:Remove()
    end
end

local function SpawnProjectile(inst,target)
	local projectile = SpawnPrefab("blowdart_pipe")
	local x,y,z = inst:GetPosition():Get()
	projectile.Transform:SetPosition(x,y,z)
	projectile.components.weapon:SetDamage(34)
	projectile.components.projectile:SetHoming(false)
	projectile.components.projectile:SetRange(15)
	projectile.components.projectile:Throw(inst,target,inst)
	
	projectile.AnimState:SetBank("lavaarena_blowdart_attacks")
    projectile.AnimState:SetBuild("lavaarena_blowdart_attacks")
    projectile.AnimState:PlayAnimation("attack_3", true)
    projectile.AnimState:SetOrientation(ANIM_ORIENTATION.OnGround)
    projectile.AnimState:SetAddColour(1, 1, 0, 0)
    projectile.AnimState:SetBloomEffectHandle("shaders/anim.ksh")
	--inst.SoundEmitter:PlaySound("dontstarve/common/lava_arena/blow_dart_spread")
	--projectile.SoundEmitter:PlaySound("dontstarve/common/lava_arena/blow_dart")
end 

local actionhandlers = 
{
	ActionHandler(ACTIONS.EAT, "eat"),
}

   
local events=
{
	CommonHandlers.OnLocomote(true, false),

    EventHandler("attacked", function(inst, data)
		if not inst.sg:HasStateTag("skilling") and not inst.sg:HasStateTag("parrying") 
			and not inst.sg:HasStateTag("busy") and data.damage and data.damage >= 20 then 
			inst.sg:GoToState("hit")
		end 
	end),

    EventHandler("doattack", function(inst)
        if not inst.components.health:IsDead() then
			local percent = inst.components.health:GetPercent()
			inst:CheckWeapons()
			if 0.75 <= percent then 
				inst.sg:GoToState("attack_book")
			elseif 0.50 <= percent then 
				inst.sg:GoToState("attack")
			elseif 0.25 <= percent then 
				inst.sg:GoToState("attack_blowdart")
			end 
        end
    end),
    
    EventHandler("death", function(inst)
		inst.sg:GoToState("death")
    end),
}

local states= 
{
	State{
		name = "taunt",
        tags = {"busy" },

        onenter = function(inst)
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("multithrust_yell")
        end,

        events =
        {
            EventHandler("animover", function(inst)
				inst.sg:GoToState("idle")
            end),
        },
	},
	State{
		name = "taunt_2",
        tags = { "busy" },

        onenter = function(inst)
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("powerup")
        end,

        events =
        {
            EventHandler("animover", function(inst)
				inst.sg:GoToState("idle")
            end),
        },
	},
	State{
        name = "attack_book",
        tags = {"attack", "notalking", "abouttoattack", "busy"},
        
        onenter = function(inst)
			inst.sg.statemem.target = inst.components.combat.target
            inst.components.combat:StartAttack()
			inst.components.locomotor:Stop()
			inst.AnimState:PlayAnimation("attack_book")
			inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_whoosh", nil, nil, true)
			inst.sg:SetTimeout(19 * FRAMES)
		end,
        timeline=
        {	
            TimeEvent(10*FRAMES, function(inst) 
				inst.components.combat:DoAttack(inst.sg.statemem.target) 
				inst.sg:RemoveStateTag("abouttoattack") 
			end),
            TimeEvent(11*FRAMES, function(inst) 
				inst.sg:RemoveStateTag("busy")
				inst.sg:RemoveStateTag("attack")
			end),				
        },
        events=
        {
			EventHandler("animover", function(inst)
				inst.sg:GoToState("idle")
            end),
        },
    },
	State{
        name = "attack",
        tags = {"attack", "notalking", "abouttoattack", "busy"},
        
        onenter = function(inst)
			inst.sg.statemem.target = inst.components.combat.target
            inst.components.combat:StartAttack()
			inst.components.locomotor:Stop()
			inst.AnimState:PlayAnimation("atk_pre")
			inst.AnimState:PushAnimation("atk", false)
			inst.sg:SetTimeout(13 * FRAMES)
		end,
        timeline=
        {	
            TimeEvent(8*FRAMES, function(inst) 
				inst.components.combat:DoAttack(inst.sg.statemem.target) 
				inst.sg:RemoveStateTag("abouttoattack") 
			end),
            TimeEvent(9*FRAMES, function(inst) 
				inst.sg:RemoveStateTag("busy")
				inst.sg:RemoveStateTag("attack")
			end),				
        },
        events=
        {
			EventHandler("animqueueover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("idle")
                end
            end),
        },
    },
	 State{
        name = "attack_blowdart",
        tags = { "attack", "notalking", "abouttoattack", "autopredict" },

        onenter = function(inst)
			local target = inst.components.combat.target
            inst.components.combat:StartAttack()
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("dart_pre")
            inst.AnimState:PushAnimation("dart", false)

            inst.sg:SetTimeout(18)

            if target ~= nil and target:IsValid() then
                inst:ForceFacePoint(target.Transform:GetWorldPosition())
                inst.sg.statemem.attacktarget = target
            end
        end,

        timeline =
        {
            TimeEvent(13 * FRAMES, function(inst)
				local target = inst.sg.statemem.attacktarget
				if target and target:IsValid() then 
					SpawnProjectile(inst,inst.sg.statemem.attacktarget)
				end  
				inst.SoundEmitter:PlaySound("dontstarve/common/lava_arena/blow_dart")
                inst.SoundEmitter:PlaySound("dontstarve/wilson/blowdart_shoot", nil, nil, true)
            end),
        },

        ontimeout = function(inst)
            inst.sg:RemoveStateTag("attack")
            inst.sg:AddStateTag("idle")
        end,

        events =
        {
            EventHandler("animqueueover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("idle")
                end
            end),
        },
    },
	
	State{
        name = "parry",
        tags = { "parrying", "busy", "nomorph" },

        onenter = function(inst)
			inst:EquipHeavyBlade()
			inst:SmallTheWorld(inst)
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("parry_pre")
            inst.AnimState:PushAnimation("parry_loop", true)
            inst.sg:SetTimeout(3)
        end,
		
		onupdate = function(inst)
            --inst.components.locomotor:RunForward()
			local target = inst.components.combat.target
			if target and target:IsValid() then 
				inst:ForceFacePoint(target.Transform:GetWorldPosition())
			end 
        end,

        ontimeout = function(inst)
            inst.AnimState:PlayAnimation("atk")
            inst.sg:GoToState("idle",true)
			inst.SoundEmitter:PlaySound("dontstarve/creatures/together/antlion/sfx/glass_break")
        end,

        onexit = function(inst)
			inst:CheckWeapons()
        end,
    },

	State{
        name = "read_book", 
        tags = { "doing","book","attack","skilling" },

        onenter = function(inst,skill_target)
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("action_uniqueitem_pre")
            inst.AnimState:PushAnimation("book", false)
            inst.AnimState:Show("ARM_normal")
			inst.sg.statemem.skill_target = skill_target

			inst.sg.statemem.isaoe = true 
            inst.sg.statemem.castsound = "dontstarve/common/lava_arena/spell/fossilized"
        end,

        timeline =
        {
            TimeEvent(0, function(inst)
                inst.sg.statemem.book_fx = SpawnPrefab("book_fx")
                inst.sg.statemem.book_fx.entity:SetParent(inst.entity)
                inst.sg.statemem.book_fx.Transform:SetPosition(0, .2, 0)
                inst.sg.statemem.book_fx.Transform:SetRotation(inst.Transform:GetRotation())
            end),
            TimeEvent(25 * FRAMES, function(inst)
                if inst.sg.statemem.isaoe then
                    inst.SoundEmitter:PlaySound(inst.sg.statemem.castsound)
                    --inst:PerformBufferedAction()
					--SpawnFireman(inst,inst.sg.statemem.skill_target)
					--inst:SmallTheWorld(inst)
					inst:SpawnFrogs(inst.sg.statemem.skill_target)
                end
            end),
            TimeEvent(28 * FRAMES, function(inst)
                inst.SoundEmitter:PlaySound("dontstarve/common/use_book_light")
            end),
            TimeEvent(54 * FRAMES, function(inst)
                inst.SoundEmitter:PlaySound("dontstarve/common/use_book_close")
            end),
            TimeEvent(58 * FRAMES, function(inst)
                if inst.sg.statemem.targetfx ~= nil then
                    if inst.sg.statemem.targetfx:IsValid() then
                        OnRemoveCleanupTargetFX(inst)
                    end
                    inst.sg.statemem.targetfx = nil
                end
                inst.sg.statemem.book_fx = nil --Don't cancel anymore
                if not inst.sg.statemem.isaoe then
                    inst.SoundEmitter:PlaySound(inst.sg.statemem.castsound)
                end
            end),
            TimeEvent(65 * FRAMES, function(inst)
                if inst.sg.statemem.isaoe then
                    inst.sg:RemoveStateTag("busy")
                end
            end),
        },

        events =
        {
            EventHandler("animqueueover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("idle")
                end
            end),
        },

        onexit = function(inst)
            local item = inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
            inst.AnimState:Show("ARM_carry")
            inst.AnimState:Hide("ARM_normal")
            if inst.sg.statemem.book_fx ~= nil and inst.sg.statemem.book_fx:IsValid() then
                inst.sg.statemem.book_fx:Remove()
            end
            if inst.sg.statemem.targetfx ~= nil and inst.sg.statemem.targetfx:IsValid() then
                OnRemoveCleanupTargetFX(inst)
            end
        end,
    },
	
    State{
        name = "death",
        tags = {"busy","death"},
        
        onenter = function(inst)
            inst.components.locomotor:Stop()
			inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/grunt")
			inst.AnimState:PlayAnimation("death")
        end,  
		timeline=
        {
            TimeEvent(12*FRAMES, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/grunt")
            end),
			TimeEvent(40*FRAMES, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/grunt")
            end),
        },    
		events=
        {
            EventHandler("animover", function(inst) inst.components.lootdropper:DropLoot(Vector3(inst.Transform:GetWorldPosition())) end),
        },
        
        onexit= function(inst)
            
        end,         
    },

    State{
        name = "idle",
        tags = {"idle", "canrotate"},
        onenter = function(inst, pushanim)   
			inst:CheckWeapons()
            inst.components.locomotor:Stop()
			inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/idle")
            local anims = {"idle_loop"}                            
            if pushanim then
                for k,v in pairs (anims) do
					inst.AnimState:PushAnimation(v, k == #anims)
				end
            else
                inst.AnimState:PlayAnimation(anims[1], #anims == 1)
                for k,v in pairs (anims) do
					if k > 1 then
						inst.AnimState:PushAnimation(v, k == #anims)
					end
				end
            end  
            inst.sg:SetTimeout(math.random()*4+2)
        end,
    },

    State{
        name = "eat",
        tags ={"busy"},
        onenter = function(inst)
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("quick_eat")
        end,

        timeline=
        {
            TimeEvent(12*FRAMES, function(inst) 
                inst:PerformBufferedAction() 
                inst.sg:RemoveStateTag("busy")
            end),
        },        
        
        events=
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end),
        },
        
        onexit= function(inst)
            inst.SoundEmitter:KillSound("eating")    
        end,
    },    
	
------------------------------------------------------------------------------------------------------------------------------------------------------

       
   
    State{
        name = "run_start",
        tags = {"moving", "running", "canrotate"},
        
        onenter = function(inst)
			inst.components.locomotor:RunForward()
            inst.AnimState:PlayAnimation("run_pre")
            inst.sg.mem.foosteps = 0
        end,

        onupdate = function(inst)
            inst.components.locomotor:RunForward()
        end,

        events=
        {   
            EventHandler("animover", function(inst) inst.sg:GoToState("run") end ),        
        },
        
        timeline=
        {
        
            TimeEvent(4*FRAMES, function(inst)
                PlayFootstep(inst)
                DoFoleySounds(inst)
            end),
        },        
        
    },

    State{
        
        name = "run",
        tags = {"moving", "running", "canrotate"},
        
        onenter = function(inst) 
            inst.components.locomotor:RunForward()
            inst.AnimState:PlayAnimation("run_loop",true)
        end,
        
        onupdate = function(inst)
            inst.components.locomotor:RunForward()
        end,

        timeline=
        {
            TimeEvent(7*FRAMES, function(inst)
				inst.sg.mem.foosteps = inst.sg.mem.foosteps + 1
                PlayFootstep(inst, inst.sg.mem.foosteps < 5 and 1 or .6)
                DoFoleySounds(inst)
            end),
            TimeEvent(15*FRAMES, function(inst)
				inst.sg.mem.foosteps = inst.sg.mem.foosteps + 1
                PlayFootstep(inst, inst.sg.mem.foosteps < 5 and 1 or .6)
                DoFoleySounds(inst)
            end),
        },
        
        events=
        {   
            EventHandler("animover", function(inst) inst.sg:GoToState("run") end ),        
        },
        
        
    },
    
    State{
        name = "run_stop",
        tags = {"canrotate", "idle"},
        
        onenter = function(inst) 
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("run_pst")
        end,
        
        events=
        {   
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end ),        
        },       
    },    
	
	State{
        name = "hit",
        tags = { "busy", "pausepredict" },

        onenter = function(inst, frozen)
            inst.components.locomotor:Stop()
            inst:ClearBufferedAction()

            inst.AnimState:PlayAnimation("hit")

            if frozen == "noimpactsound" then
                frozen = nil
            else
                inst.SoundEmitter:PlaySound("dontstarve/wilson/hit")
            end
			inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/hurt")
			
            local stun_frames = frozen and 10 or 6
            inst.sg:SetTimeout(stun_frames * FRAMES)
        end,

        ontimeout = function(inst)
			if inst.components.health:IsDead() then 
				inst.sg:GoToState("death")
			else
				inst.sg:GoToState("idle")
			end 
        end,
    },
}

    
return StateGraph("SGtime_demon", states, events, "idle", actionhandlers)

