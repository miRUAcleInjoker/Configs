require "behaviours/wander"
require "behaviours/faceentity"
require "behaviours/chaseandattack"
require "behaviours/panic"
require "behaviours/follow"
require "behaviours/attackwall"
--require "behaviours/runaway"
--require "behaviours/doaction"


local WANDER_DIST = 20
local START_FACE_DIST = 4

local KEEP_FACE_DIST = 6

local MAX_CHASE_TIME = 15

local MAX_BEAM_ATTACK_RANGE = 9
local MAX_JUMP_ATTACK_RANGE = 9


local function GetFaceTargetFn(inst)
    local target = GetClosestInstWithTag("player", inst, START_FACE_DIST)
    if target and not target:HasTag("notarget") then
        return target
    end
end

local function KeepFaceTargetFn(inst, target)
    return inst:GetDistanceSqToInst(target) <= KEEP_FACE_DIST*KEEP_FACE_DIST and not target:HasTag("notarget")
end


local function shouldbeamattack(inst)

    if inst.components.combat.target and not inst.components.timer:TimerExists("laserbeam_cd") and inst:HasTag("beam_attack") then
        local target = inst.components.combat.target
        local distsq = inst:GetDistanceSqToInst(target)    
        if distsq < MAX_BEAM_ATTACK_RANGE * MAX_BEAM_ATTACK_RANGE then
            return true
        end
    end
    return false
end

local function dobeamattack(inst)
    if inst.components.combat.target then
        local target = inst.components.combat.target
        inst:PushEvent("dobeamattack",{target=inst.components.combat.target})
    end
end

local function deactivate(inst)
    if not inst:HasTag("dormant") then
        inst.components.combat.target = nil
        inst:PushEvent("deactivate") 
    end
end

local AncientRobotBrain = Class(Brain, function(self, inst)
    Brain._ctor(self, inst)
end)

local function shouldjumpattack(inst)
    if not inst:HasTag("jump_attack") then
        return false
    end
    if  inst.sg:HasStateTag("leapattack") then
        return true
    end

    if inst.components.combat.target then
        local target = inst.components.combat.target
        if target then
            if target:IsValid() then
                local combatrange = inst.components.combat:CalcAttackRangeSq(target)
                local distsq = inst:GetDistanceSqToInst(target)
                if distsq < MAX_JUMP_ATTACK_RANGE * MAX_JUMP_ATTACK_RANGE then
                    return true
                end
            else
                print("JUMP TARGET WASN'T THERE ANYMORE?",target.prefab)
                inst.components.combat.target = nil
            end
        end
    end
    return false
end

local function dojumpAttack(inst)
    if inst.components.combat.target and not inst.sg:HasStateTag("leapattack") then
        local target = inst.components.combat.target
        inst:PushEvent("doleapattack", {target=target})

        inst:FacePoint(target.Transform:GetWorldPosition())
    end
end

function AncientRobotBrain:OnStart()
    local root = PriorityNode(
    {
        IfNode( function() return self.inst.wantstodeactivate or self.inst:HasTag("dormant") end, "deactivate test",  
            DoAction(self.inst, function() return deactivate(self.inst) end, "deactivate", true)
            ), 
        WhileNode(function() return not self.inst:HasTag("dormant") end, "activate",
            PriorityNode(
            {            
                WhileNode( function() return shouldbeamattack(self.inst) end, "beamattack",  
                    DoAction(self.inst, function() return dobeamattack(self.inst) end, "beam", true)
                    ),  
                WhileNode( function() return shouldjumpattack(self.inst) end, "jumpattack",  
                    DoAction(self.inst, function() return dojumpAttack(self.inst) end, "jump", true)
                    ),                            
                ChaseAndAttack(self.inst, MAX_CHASE_TIME),
                FaceEntity(self.inst, GetFaceTargetFn, KeepFaceTargetFn),
                Wander(self.inst)
            }, .25)
        )

    }, .25)
    
    self.bt = BT(self.inst, root)
    
end

return AncientRobotBrain