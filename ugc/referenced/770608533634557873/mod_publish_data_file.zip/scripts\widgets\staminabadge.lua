local Badge = require "widgets/badge"
local UIAnim = require "widgets/uianim"
local IceyUtil = require("icey_util")

local StaminaBadge = Class(Badge, function(self, owner)
    --[[Badge._ctor(self, "stamina", owner)
	
	self.anim:GetAnimState():SetBank("health")
    self.anim:GetAnimState():SetBuild("stamina")
    self.anim:GetAnimState():PlayAnimation("anim")

    self.topperanim = self.underNumber:AddChild(UIAnim())
    self.topperanim:GetAnimState():SetBank("effigy_topper")
    self.topperanim:GetAnimState():SetBuild("effigy_topper")
    self.topperanim:GetAnimState():PlayAnimation("anim")
    self.topperanim:SetClickable(false)

    self.staminaarrow = self.underNumber:AddChild(UIAnim())
    self.staminaarrow:GetAnimState():SetBank("sanity_arrow")
    self.staminaarrow:GetAnimState():SetBuild("sanity_arrow")
    self.staminaarrow:GetAnimState():PlayAnimation("neutral")
    self.staminaarrow:SetClickable(false)

    --Hide the original frame since it is now overlapped by the topperanim
    self.anim:GetAnimState():Hide("frame")--]]
	
	Badge._ctor(self, nil, owner, { 49 / 255, 145 / 255, 38 / 255, 1 }, "status_stamina")
	
	self.backing:GetAnimState():SetBank("status_meter")
    self.backing:GetAnimState():SetBuild("status_wet")
    self.backing:GetAnimState():Hide("frame")
    self.backing:GetAnimState():Hide("icon")

    self.staminaarrow = self.underNumber:AddChild(UIAnim())
    self.staminaarrow:GetAnimState():SetBank("sanity_arrow")
    self.staminaarrow:GetAnimState():SetBuild("sanity_arrow")
    self.staminaarrow:GetAnimState():PlayAnimation("neutral")
    self.staminaarrow:SetClickable(false)


    self.val = 100
    self.max = 100
	self.penaltypercent = 0
	
    self:StartUpdating()
	IceyUtil.MakeDragableUI(self) 
end)

function StaminaBadge:SetPercent(val, max,penaltypercent)
    self.val = val
    self.max = max
    Badge.SetPercent(self, self.val, self.max)
	
	self.penaltypercent = penaltypercent or 0
end

local RATE_SCALE_ANIM =
{
    [RATE_SCALE.INCREASE_HIGH] = "arrow_loop_increase_most",
    [RATE_SCALE.INCREASE_MED] = "arrow_loop_increase_more",
    [RATE_SCALE.INCREASE_LOW] = "arrow_loop_increase",
    [RATE_SCALE.DECREASE_HIGH] = "arrow_loop_decrease_most",
    [RATE_SCALE.DECREASE_MED] = "arrow_loop_decrease_more",
    [RATE_SCALE.DECREASE_LOW] = "arrow_loop_decrease",
}

function StaminaBadge:OnUpdate(dt)
    local stamina = self.owner.replica.stamina
	self:SetPercent(stamina:GetPercent(), stamina:GetMax())
end

return StaminaBadge
