AddStategraphActionHandler("wilson", 
    ActionHandler(ACTIONS.ATTACK,
        function(inst, action)
            inst.sg.mem.localchainattack = not action.forced or nil
            if not (inst.sg:HasStateTag("attack") and action.target == inst.sg.statemem.attacktarget or inst.components.health:IsDead()) then
                local weapon = inst.components.combat ~= nil and inst.components.combat:GetWeapon() or nil
                return (weapon == nil and "attack")
                    or (weapon:HasTag("blowdart") and "blowdart")
                    or (weapon:HasTag("thrown") and "throw")
                    or (weapon:HasTag("multithruster") and "multithrust_pre")
					or (weapon:HasTag("gauss_gun_attack") and "gauss_gun_normalattack")
                    or "attack"
            end
        end)
)

AddStategraphActionHandler("wilson_client", 
     ActionHandler(ACTIONS.ATTACK,
        function(inst, action)
            if not (inst.sg:HasStateTag("attack") and action.target == inst.sg.statemem.attacktarget or inst.replica.health:IsDead()) then
                local equip = inst.replica.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
                if equip == nil then
                    return "attack"
                end
                local inventoryitem = equip.replica.inventoryitem
                return (not (inventoryitem ~= nil and inventoryitem:IsWeapon()) and "attack")
                    or (equip:HasTag("blowdart") and "blowdart")
                    or (equip:HasTag("thrown") and "throw")
					or (equip:HasTag("gauss_gun_attack") and "gauss_gun_normalattack")
                    or "attack"
            end
        end)
)

AddStategraphState("wilson", 
 State{
		name = "gauss_gun_normalattack",
        tags = { "attack", "notalking", "abouttoattack", "autopredict" },
		onenter = function(inst)
		print("窝要搞死你啊!")
			local buffaction = inst:GetBufferedAction()
			local target = buffaction ~= nil and buffaction.target or nil
			local equip = inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
			inst.components.locomotor:Stop()
			inst.components.combat:SetTarget(target)
		--	inst.components.combat:StartAttack()
			--inst.components.locomotor:Stop()
			local cooldown = inst.components.combat.min_attack_period + .5 * FRAMES
			--inst.components.combat:SetTarget(target)
			--inst.components.combat:StartAttack()
			--inst.components.combat:DoAttack(target)
		if target ~= nil then 
			local pos = target:GetPosition()
			local my = inst:GetPosition()
			local a = pos.x - my.x
			local c = pos.z - my.z
			local ma = 2.5*a/math.sqrt(a*a+c*c)
			local mc = 2.5*c/math.sqrt(a*a+c*c)
			inst.components.combat:StartAttack()
			inst.AnimState:PlayAnimation("fishing_pst")
			inst:DoTaskInTime(0.1,
			function(inst)
			local sparksa = SpawnPrefab("sparks")
			sparksa.Transform:SetPosition(my.x+ma,0,my.z+mc)
			sparksa.Transform:SetScale(1.3,1.3,1.3)
		
			local gunfire = SpawnPrefab("gunfire")
			gunfire.Transform:SetPosition(my.x+ma,0,my.z+mc)
			gunfire.Transform:SetScale(1.3,1.3,1.3)
			gunfire.AnimState:SetMultColour(44/255,178/255,251/255,1)
			inst.components.combat:DoAttack(target)
			--inst.components.combat:DoAttack(target)
		if target:HasTag("chess")	 then 
			local sparksb = SpawnPrefab("sparks")
			sparksb.Transform:SetPosition(pos.x,pos.y,pos.z)
			sparksb.Transform:SetScale(1.3,1.3,1.3)
		end	
		if not target:HasTag("chess") and not target:HasTag("nightmare") then 
			local blood = SpawnPrefab("gunblood")
			blood.Transform:SetPosition(pos.x,pos.y,pos.z)
			blood.Transform:SetScale(0.4,0.4,0.4)
		end 
			inst.SoundEmitter:PlaySound("dontstarve/rain/thunder_close")
			--target.components.health:DoDelta(-100)
            inst.AnimState:PushAnimation("idle", false)
			end
			)
			
            --inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon", nil, nil, true)
            cooldown = math.max(cooldown, 100 * FRAMES)    
			inst.sg:SetTimeout(cooldown)

			if target ~= nil then
				inst.components.combat:BattleCry()
					if target:IsValid() then
						inst:FacePoint(target:GetPosition())
						inst.sg.statemem.attacktarget = target
					end
			end
		end 
		end,
		    timeline =
    {
        TimeEvent(6 * FRAMES, function(inst)
            if inst.sg.statemem.isbeaver then
                inst:PerformBufferedAction()
                inst.sg:RemoveStateTag("abouttoattack")
            elseif inst.sg.statemem.ischop then
                inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon", nil, nil, true)
            end
        end),
        TimeEvent(8 * FRAMES, function(inst)
            if not (inst.sg.statemem.isbeaver or
                    inst.sg.statemem.iswhip or
                    inst.sg.statemem.isbook) and
                inst.sg.statemem.projectiledelay == nil then
                inst:PerformBufferedAction()
                inst.sg:RemoveStateTag("abouttoattack")
            end
        end),
        TimeEvent(10 * FRAMES, function(inst)
            if inst.sg.statemem.iswhip or inst.sg.statemem.isbook then
                inst:PerformBufferedAction()
                inst.sg:RemoveStateTag("abouttoattack")
            end
        end),
    },

    ontimeout = function(inst)
        inst.sg:RemoveStateTag("attack")
        inst.sg:AddStateTag("idle")
    end,

    events =
    {
        EventHandler("equip", function(inst) inst.sg:GoToState("idle") end),
        EventHandler("unequip", function(inst) inst.sg:GoToState("idle") end),
        EventHandler("animqueueover", function(inst)

            if inst.AnimState:AnimDone() then
                inst.sg:GoToState("idle")
            end
        end),
    },

    onexit = function(inst)
        inst.components.combat:SetTarget(nil)
        if inst.sg:HasStateTag("abouttoattack") then
            inst.components.combat:CancelAttack()
        end
    end,
		
}
)

AddStategraphState("wilson_client",
	State{
	name = "gauss_gun_normalattack",
    tags = { "attack", "notalking", "abouttoattack" },

    onenter = function(inst)
	print("窝要搞死你啊_client!")
        local cooldown = 0
		local buffaction = inst:GetBufferedAction()
        local target = buffaction ~= nil and buffaction.target or nil
        if inst.replica.combat ~= nil then
            inst.replica.combat:StartAttack()
            cooldown = inst.replica.combat:MinAttackPeriod() + .5 * FRAMES
        end
        inst.components.locomotor:Stop()
        local equip = inst.replica.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
	if target ~= nil then
		local pos = target:GetPosition()
			local my = inst:GetPosition()
			local a = pos.x - my.x
			local c = pos.z - my.z
			local ma = 2.5*a/math.sqrt(a*a+c*c)
			local mc = 2.5*c/math.sqrt(a*a+c*c)
			inst.AnimState:PlayAnimation("fishing_pst")
			inst:DoTaskInTime(0.1,
			function(inst)
			local sparksa = SpawnPrefab("sparks")
			sparksa.Transform:SetPosition(my.x+ma,0,my.z+mc)
			sparksa.Transform:SetScale(1.3,1.3,1.3)
			local gunfire = SpawnPrefab("gunfire")
			gunfire.Transform:SetPosition(my.x+ma,0,my.z+mc)
			gunfire.Transform:SetScale(1.3,1.3,1.3)
			--inst.components.combat:DoAttack(target)
		if target:HasTag("chess")	 then 
			local sparksb = SpawnPrefab("sparks")
			sparksb.Transform:SetPosition(pos.x,pos.y,pos.z)
			sparksb.Transform:SetScale(1.3,1.3,1.3)
		end	
		if not target:HasTag("chess") and not target:HasTag("nightmare") then 
			local blood = SpawnPrefab("gunblood")
			blood.Transform:SetPosition(pos.x,pos.y,pos.z)
			blood.Transform:SetScale(0.4,0.4,0.4)
		end 
			
			inst.SoundEmitter:PlaySound("dontstarve/rain/thunder_close")
			--target.components.health:DoDelta(-100)
            inst.AnimState:PushAnimation("idle", false)
			end
			)
			
           -- inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon", nil, nil, true)
     
            if cooldown > 0 then
				cooldown = math.max(cooldown, 100 * FRAMES)                              
            end
			
		local buffaction = inst:GetBufferedAction()
        if buffaction ~= nil then
            inst:PerformPreviewBufferedAction()

            if buffaction.target ~= nil and buffaction.target:IsValid() then
                inst:FacePoint(buffaction.target:GetPosition())
                inst.sg.statemem.attacktarget = buffaction.target
            end
        end

        if cooldown > 0 then
            inst.sg:SetTimeout(cooldown)
        end
	end 
	end,
	    onupdate = function(inst, dt)
        if (inst.sg.statemem.projectiledelay or 0) > 0 then
            inst.sg.statemem.projectiledelay = inst.sg.statemem.projectiledelay - dt
            if inst.sg.statemem.projectiledelay <= FRAMES then
                if inst.sg.statemem.projectilesound ~= nil then
                    inst.SoundEmitter:PlaySound(inst.sg.statemem.projectilesound, nil, nil, true)
                    inst.sg.statemem.projectilesound = nil
                end
                if inst.sg.statemem.projectiledelay <= 0 then
                    inst:ClearBufferedAction()
                    inst.sg:RemoveStateTag("abouttoattack")
                end
            end
        end
    end,

    timeline =
    {
        TimeEvent(6 * FRAMES, function(inst)
            if inst.sg.statemem.isbeaver then
                inst:ClearBufferedAction()
                inst.sg:RemoveStateTag("abouttoattack")
            elseif inst.sg.statemem.ischop then
                inst.SoundEmitter:PlaySound("dontstarve/wilson/attack_weapon", nil, nil, true)
            end
        end),
        TimeEvent(8 * FRAMES, function(inst)
            if not (inst.sg.statemem.isbeaver or
                    inst.sg.statemem.iswhip or
                    inst.sg.statemem.isbook) and
                inst.sg.statemem.projectiledelay == nil then
                inst:ClearBufferedAction()
                inst.sg:RemoveStateTag("abouttoattack")
            end
        end),
        TimeEvent(10 * FRAMES, function(inst)
            if inst.sg.statemem.iswhip or inst.sg.statemem.isbook then
                inst:ClearBufferedAction()
                inst.sg:RemoveStateTag("abouttoattack")
            end
        end),
    },

    ontimeout = function(inst)
        inst.sg:RemoveStateTag("attack")
        inst.sg:AddStateTag("idle")
    end,

    events =
    {
        EventHandler("animqueueover", function(inst)
            if inst.AnimState:AnimDone() then
			
                inst.sg:GoToState("idle")
            end
        end),
    },

    onexit = function(inst)
        if inst.sg:HasStateTag("abouttoattack") and inst.replica.combat ~= nil then
            inst.replica.combat:CancelAttack()
        end
    end,
}
)