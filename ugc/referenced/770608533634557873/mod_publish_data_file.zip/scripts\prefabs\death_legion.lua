local TadalinUtil = require("tadalin_util")

local assets =
{
	Asset("ANIM", "anim/death_legion.zip"),
}

local prefabs =
{
    "froglegs",
    "frogsplash",
}

local brain = require "brains/frogbrain"

--------��������
--[[
idle
walk_pre
walk_loop
walk_pst
hit
atk_chomp
atk_circle
death
--]]

local function PushMusic(inst)
    if ThePlayer == nil then
        inst._playingmusic = false
    elseif ThePlayer:IsNear(inst, inst._playingmusic and 40 or 20) then
        inst._playingmusic = true
        ThePlayer:PushEvent("triggeredevent", { name = "metal_hulk_merge" })
    elseif inst._playingmusic and not ThePlayer:IsNear(inst, 50) then
        inst._playingmusic = false
    end
end


local function ClearRecentlyCharged(inst, other)
    inst.recentlycharged[other] = nil
end

local function onothercollide(inst, other)
    if not other:IsValid() or not TadalinUtil.CanAttack(other) or inst.recentlycharged[other] then
        return
    elseif other:HasTag("smashable") and other.components.health ~= nil then
        --other.Physics:SetCollides(false)
        other.components.health:Kill()
    elseif other.components.workable ~= nil
        and other.components.workable:CanBeWorked()
        and other.components.workable.action ~= ACTIONS.NET then
        SpawnPrefab("collapse_small").Transform:SetPosition(other.Transform:GetWorldPosition())
        other.components.workable:Destroy(inst)
        if other:IsValid() and other.components.workable ~= nil and other.components.workable:CanBeWorked() then
            inst.recentlycharged[other] = true
            inst:DoTaskInTime(3, ClearRecentlyCharged, other)
        end
    elseif other.components.health ~= nil and not other.components.health:IsDead() and other.components.combat and TadalinUtil.CanAttack(other) then
        inst.recentlycharged[other] = true
        inst:DoTaskInTime(3, ClearRecentlyCharged, other)
        inst.SoundEmitter:PlaySound("dontstarve/creatures/rook/explo")
        --inst.components.combat:DoAttack(other, inst.weapon)
		other.components.combat:GetAttacked(inst,math.random(45,70))
    end
end

local function oncollide(inst, other)
    if not (other ~= nil and other:IsValid() and inst:IsValid())
        or inst.recentlycharged[other]
        or other:HasTag("tadalin")
		or not TadalinUtil.CanAttack(other)
        or Vector3(inst.Physics:GetVelocity()):LengthSq() < 42
		or not inst.sg:HasStateTag("moving")
		 then
        return
    end
    ShakeAllCameras(CAMERASHAKE.SIDE, .5, .05, .1, inst, 40)
    inst:DoTaskInTime(2 * FRAMES, onothercollide, other)
end

local function HandAttack(inst,target)
	local hand = inst:SpawnChild("ancient_robot_claw")
	hand.Transform:SetPosition(0.1,math.random() + 1,0)
	hand:DoTaskInTime(0,function()
		hand.sg:GoToState("laserbeam",target)
	end)
	hand.Transform:SetScale(1/2.5,1/2.5,1/2.5)
	hand:DoTaskInTime(3,inst.Remove)
	--hand:ListenForEvent("animover",hand.Remove)
	--hand:ListenForEvent("animover",hand.Remove)
end 


local function onskilluse(inst,data)
	local skillname = data.name
	local skillcd = data.cd
	inst[skillname] = false 
	
	inst.components.timer:StartTimer(skillname,skillcd)
end 

local function ontimerdone(inst,data)
	local skillname = data.name
	inst[skillname] = true 
end 


local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddDynamicShadow()
    inst.entity:AddNetwork()

    MakeGiantCharacterPhysics(inst, 1000, 2.5)

    inst.DynamicShadow:SetSize(6, 3)

    inst.AnimState:SetBank("death_legion")
    inst.AnimState:SetBuild("death_legion")
    inst.AnimState:PlayAnimation("idle",true)
	
	inst.Transform:SetScale(2.5,2.5,2.5)

    inst:AddTag("hostile")
    inst:AddTag("mech")
	inst:AddTag("epic")
	inst:AddTag("noepicmusic")
	
	inst._playingmusic = false
	if not TheNet:IsDedicated() then
        inst:DoPeriodicTask(1, PushMusic,0)
    end

    inst.entity:SetPristine()
    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.HandAttack = HandAttack 
	inst.skill_circleatk = true 
	inst.recentlycharged = {} 
	inst.Physics:SetCollisionCallback(oncollide)

    inst:AddComponent("locomotor") -- locomotor must be constructed before the stategraph
    inst.components.locomotor.walkspeed = 2
    inst.components.locomotor.runspeed = 2

    inst:SetStateGraph("SGdeath_legion")

    inst:SetBrain(brain)

   

    inst:AddComponent("health")
    inst.components.health:SetMaxHealth(8000)
	inst.components.health.destroytime = 5

    inst:AddComponent("combat")
	inst.components.combat.playerdamagepercent = 0.5
    inst.components.combat:SetDefaultDamage(160)
	inst.components.combat:SetAreaDamage(1.5,0.6)
    inst.components.combat:SetAttackPeriod(3)
	inst.components.combat:SetRange(6,6)
	inst.components.combat:SetHurtSound("dontstarve/creatures/together/stalker/born_drop")


    inst:AddComponent("lootdropper")
    --inst.components.lootdropper:SetLoot({"froglegs"})

    inst:AddComponent("knownlocations")
    inst:AddComponent("inspectable")
	inst:AddComponent("timer")
	
	inst:ListenForEvent("use_death_legion_skill",onskilluse)
	inst:ListenForEvent("timerdone",ontimerdone)
	
	TadalinUtil.MakeNormalTadalin(inst)


    return inst
end

return Prefab("death_legion", fn, assets, prefabs)
