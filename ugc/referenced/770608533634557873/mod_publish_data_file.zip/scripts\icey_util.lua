-----这里规定了艾希的一些进攻方式
local cooking = require("cooking")  
local preparedfoods_icey = require("preparedfoods_icey")


local function IsDarkSpirit(target)
	return target and target:IsValid() 
	and target:HasTag("darkspirit") and not target:HasTag("playerghost")
	and target.components.combat and target.components.health and not target.components.health:IsDead() 
end 

local function IsDarkSpiritClient(target)
	return target and target:IsValid() 
	and target:HasTag("darkspirit") and not target:HasTag("playerghost")
end 

local function CanDoDarkSpiritAttack(inst,other)
	return  (IsDarkSpirit(inst) or IsDarkSpirit(other)) and inst ~= other 
	and not inst:HasTag("playerghost") and not other:HasTag("playerghost")
end 

local function CanDoDarkSpiritAttackClient(inst,other)
	return  (IsDarkSpiritClient(inst) or IsDarkSpiritClient(other)) and inst ~= other
	and not inst:HasTag("playerghost") and not other:HasTag("playerghost")
end 

local function CanAttack(v,inst) ------------多重保险：判定目标是否真的可以被攻击，可以被伤害
	if not (v and v:IsValid() and inst and inst:IsValid()) then 
		return false 
	end
	
	for k,tag in pairs(TUNING.ICEY_NO_TAGS) do 
		if v:HasTag(tag) then 
			return false 
		end
	end
	
	if v.sg then 
		for k,tag in pairs(TUNING.ICEY_NO_SGTAGS) do 
			if v.sg:HasStateTag(tag) then 
				return false 
			end
		end
	end 
		
	
	if CanDoDarkSpiritAttack(inst,v) then 
		return true 
	end

	return (v.userid  == nil or v.userid ~= inst.owner_id) and v ~= inst 
	and not v:HasTag("player") and not v:HasTag("playerghost") and not v:HasTag("companion") and not v:HasTag("wall") and --------------求求你别打狗切和格罗姆了
	(v.components.follower == nil or (inst ~= v.components.follower.leader)) and --------------求求你别打自己人了
	v.components.combat and v.components.health and not v.components.health:IsDead() and not v.components.health:IsInvincible()
end  



local function ListenForEventOnce(inst, event, fn, source)
    -- Currently, inst2 is the source, but I don't want to make that assumption.
    local function gn(inst2, data)
        inst:RemoveEventCallback(event, gn, source) --as you can see, it removes the event listener even before firing the function
        return fn(inst2, data)
    end
     
    return inst:ListenForEvent(event, gn, source)
end

local function WatchWorldStateOnce(inst,var,fn)
	local function wn(inst2,...)
        inst:StopWatchingWorldState(var, wn) --as you can see, it removes the event listener even before firing the function
        return fn(inst2,...)
    end
	
	return inst:WatchWorldState(var,wn)
end 

local function IsPassableAtPoint(x,y,z)
	local grounds = TheSim:FindEntities(x,y,z,30,{"FAKEGROUND"})
	for k,v in pairs(grounds) do 
		local v_pos = v:GetPosition()
		local target_pos = Vector3(x,y,z)
		local dist = target_pos:Dist(v_pos)
			
		if v.FAKEGROUND_RADIUS == nil or v.FAKEGROUND_RADIUS >= dist then 
			return true 
		end
	end
	return TheWorld.Map:IsAboveGroundAtPoint(x,y,z) 
end

local function NormalRetarget(inst)
	local playertargets = {}
	local leader = inst.components.follower and inst.components.follower.leader
	
	if not (leader and leader:IsValid()) then 
		return 
	end 
	
	local leader_target = leader.components.combat.target

    return FindEntity(inst, 20,
        function(guy)
            return inst.components.combat:CanTarget(guy)
                and CanAttack(guy,leader)and 
				(guy == leader_target or guy.components.combat.target == leader)
        end,
        { "_combat"}, --see entityreplica.lua
        { "INLIMBO","playerghost"}
    )
end 

local function NormalKeepTarget(inst,target)
	return target ~= nil
        and target:IsValid()
        and target.components.health ~= nil
        and not target.components.health:IsDead()
        and inst:IsNear(target, 20)
		and not target:HasTag("companion")
end 

local function MakeIceyAlly(inst,retargettime)
	retargettime = retargettime or 1
	
	inst.components.combat:SetRetargetFunction(retargettime, NormalRetarget)
	inst.components.combat:SetKeepTargetFunction(NormalKeepTarget)
	
	--------------防止范围攻击误伤中立生物
	local oldDoAreaAttack = inst.components.combat.DoAreaAttack
	inst.components.combat.DoAreaAttack = function(self,target, range, weapon, validfn, stimuli, excludetags)
		local old_validfn = validfn
		local leader = inst.components.follower and inst.components.follower.leader
		validfn = function(enemy)
			return (old_validfn == nil or old_validfn(enemy)) and CanAttack(enemy,leader)
		end
		return oldDoAreaAttack(self,target, range, weapon, validfn, stimuli, excludetags)
	end
end

local function keepTwoDecimalPlaces(decimal)-----------------------四舍五入保留两位小数的代码
    decimal = math.floor((decimal * 100)+0.5)*0.01       
    return  decimal 
end

local function DefaultCostFn(doer,cost,cansay)
	local hunger =  doer.components.hunger and doer.components.hunger.current or -1
	local sanity =  doer.components.sanity and doer.components.sanity.current or -1
	local health =  doer.components.health and doer.components.health.currenthealth or -1
	local stamina = doer.components.stamina and doer.components.stamina.current or -1
	local focus = doer.components.focus and doer.components.focus.current or -1
	
	local delta_hunger = -math.abs(cost.hunger or 0)
	local delta_sanity = -math.abs(cost.sanity or 0) 
	local delta_health = -math.abs(cost.health or 0)
	local delta_stamina = -math.abs(cost.stamina or 0)
	local delta_focus = - math.abs(cost.focus or 0)
	
	local sub_hunger = hunger + delta_hunger
	local sub_sanity = sanity + delta_sanity
	local sub_health = health + delta_health
	local sub_stamina = stamina + delta_stamina
	local sub_focus = focus + delta_focus
	
	if sub_hunger >= 0 and sub_sanity >= 0 and sub_health >= 0 and sub_stamina >= 0 and sub_focus >= 0 then 
		doer.components.hunger:DoDelta(delta_hunger)
		doer.components.sanity:DoDelta(delta_sanity)
		doer.components.health:DoDelta(delta_health)
		doer.components.stamina:DoDelta(delta_stamina)
		doer.components.stamina:Pause(1.5)
		doer.components.focus:DoDelta(delta_focus)
		return true 
	else
		local tips = "我的"
		if sub_hunger < 0 then 
			tips = tips.."饥饿还差"..tostring(-keepTwoDecimalPlaces(sub_hunger)).."点,"
		end 
		if sub_sanity < 0 then 
			tips = tips.."精神还差"..tostring(-keepTwoDecimalPlaces(sub_sanity)).."点,"
		end 
		if sub_health < 0 then 
			tips = tips.."生命还差"..tostring(-keepTwoDecimalPlaces(sub_health)).."点,"
		end 
		if sub_stamina < 0 then 
			tips = tips.."体力还差"..tostring(-keepTwoDecimalPlaces(sub_stamina)).."点,"
		end 
		if sub_focus < 0 then 
			tips = tips.."专注还差"..tostring(-keepTwoDecimalPlaces(sub_focus)).."点,"
		end 
		tips = tips.."条件不足,不能释放。"
		
		if cansay and doer.components.talker then 
			doer.components.talker:Say(tips)
		end
		return false 
	end
end 

local function MakeDragableUI(self)
	local function AddPoint(self,Valid)
		for k,v in pairs(Valid) do
			if Valid[k] ==true then
				self[k].point:Show()
			else
				self[k].point:Hide()
			end
		end
	end	
	function self:OnUIAddPoint(owner,data)
		if data and data.Valid then
			local Valid = data.Valid
			AddPoint(self,Valid)
		end
	end
	self.OnUIAddPointFn = function(owner,data) self:OnUIAddPoint(owner,data) end
	self.owner:ListenForEvent("UIAddPoint", self.OnUIAddPointFn)
	self.OnControl = function (self,control, down)
		self:Passive_OnControl(control, down) 
	end
	
	--self:SetPosition(190,620,0)
	self:MoveToBack()
	--self:StartUpdating()
	
	function self:Passive_OnControl(control, down)
		if control == CONTROL_ACCEPT then
			if down then
				self:StartDrag()
			else
				self:EndDrag()
			end
		end
	end

	function self:SetDragPosition(x, y, z)
		local pos
		if type(x) == "number" then
			pos = Vector3(x, y, z)
		else
			pos = x
		end
		self:SetPosition(pos + self.dragPosDiff)
	end

	function self:StartDrag()
		if not self.followhandler then
			local mousepos = TheInput:GetScreenPosition()
			self.dragPosDiff = self:GetPosition() - mousepos
			self.followhandler = TheInput:AddMoveHandler(function(x,y) self:SetDragPosition(x,y) end)
			self:SetDragPosition(mousepos)
			--print("self:StartDrag()")
		end
	end

	function self:EndDrag()
		if self.followhandler then
			self.followhandler:Remove()
		end
		self.followhandler = nil
		self.dragPosDiff = nil
		self:MoveToBack()
		--print("self:EndDrag()")
	end

	function self:Scale_DoDelta(delta)
		self.scale = math.max(self.scale+delta,0.1)
		self:SetScale(self.scale,self.scale,self.scale)
		self:MoveToBack()
		--print("self:Scale_DoDelta()")
	end
end

local function EnableDrawOverFogOfWar(inst,enable)
	if inst.MiniMapEntity then 
		if enable then 
			if inst.icon == nil and not inst:HasTag("burnt") then
				inst:DoTaskInTime(0,function()
					inst.icon = SpawnPrefab("globalmapicon")
					inst.icon.MiniMapEntity:SetIsFogRevealer(true)
					inst.icon:TrackEntity(inst)
				end) 
			end
		else
			inst.icon:Remove()
			inst.icon = nil 
		end 
	end 
end

local function CreateNormalFx(prefabname,assets,bank,build,anim,not_remove_once,extrafn)
	local function FxFn()
		local inst = CreateEntity()
		inst.entity:AddTransform()
		inst.entity:AddAnimState()
		inst.entity:AddSoundEmitter() 
		inst.entity:AddNetwork()
		
		inst.AnimState:SetBank(bank)
		inst.AnimState:SetBuild(build)
		
		if type(anim) == "string" then 
			inst.AnimState:PlayAnimation(anim)
		elseif type(anim) == "function" then 
			inst.AnimState:PlayAnimation(anim(inst))
		end 
		
		inst.entity:SetPristine()
	
		if not TheWorld.ismastersim then
			return inst
		end
		
		if not not_remove_once then 
			inst.persists = false
			inst:ListenForEvent("animover",inst.Remove)
		end 
		
		if extrafn then 
			extrafn(inst) 
		end
		
		
		return inst
	end

	return Prefab(prefabname,FxFn,assets)
end

---local function CreateNormalWeapon(prefabname,assets,tags,bank,build,anim,swapanims,damage,ranges,maxuse,clientfn,serverfn)
local function CreateNormalWeapon(data)
	local prefabname = data.prefabname
	local assets = data.assets or {
		Asset("ANIM", "anim/"..prefabname..".zip"),
		Asset("ANIM", "anim/swap_"..prefabname..".zip"),
		
		Asset("IMAGE","images/inventoryimages/"..prefabname..".tex"),
		Asset("ATLAS","images/inventoryimages/"..prefabname..".xml"),
	}
	local swapanims = data.swapanims or {"swap_"..prefabname,"swap_"..prefabname}
	local function onequip(inst, owner) 
		owner.AnimState:OverrideSymbol("swap_object", swapanims[1],swapanims[2])
		owner.AnimState:Show("ARM_carry") 
		owner.AnimState:Hide("ARM_normal") 
		
		if data.onequip then 
			data.onequip(inst, owner)
		end
	end

	local function onunequip(inst, owner) 
		owner.AnimState:Hide("ARM_carry") 
		owner.AnimState:Show("ARM_normal") 
		
		if data.onunequip then 
			data.onunequip(inst, owner)
		end
	end
	local function WeaponFn()
		local inst = CreateEntity()
		
		inst.entity:AddTransform()
		inst.entity:AddAnimState()
		inst.entity:AddSoundEmitter() 
		inst.entity:AddNetwork()
		
		MakeInventoryPhysics(inst)
		
		inst.AnimState:SetBank(data.bank)
		inst.AnimState:SetBuild(data.build)
		inst.AnimState:PlayAnimation(data.anim)
		
		if data.tags then
			for k,v in pairs(data.tags) do 
				inst:AddTag(v)
			end
		end  

		if data.clientfn then 
			data.clientfn(inst) 
		end 

		inst.entity:SetPristine()	
		
		if not TheWorld.ismastersim then
			return inst
		end	  

		inst:AddComponent("weapon")
		inst.components.weapon:SetDamage(data.damage)	
		if data.ranges then 
			if type(data.ranges) == "table"	then 
				inst.components.weapon:SetRange(data.ranges[1],data.ranges[2])
			else
				inst.components.weapon:SetRange(data.ranges)
			end 
		end 
		-------
		
		if data.maxuse then 
			inst:AddComponent("finiteuses")
			inst.components.finiteuses:SetMaxUses(data.maxuse)
			inst.components.finiteuses:SetUses(data.maxuse)
			inst.components.finiteuses:SetOnFinished(inst.Remove)
		end 

		inst:AddComponent("inspectable")
		
		inst:AddComponent("inventoryitem")
		inst.components.inventoryitem.imagename = prefabname
		inst.components.inventoryitem.atlasname = "images/inventoryimages/"..prefabname..".xml"
		
		inst:AddComponent("equippable")
		inst.components.equippable:SetOnEquip( onequip )
		inst.components.equippable:SetOnUnequip( onunequip )
		
		--[[if data.
		inst:ListenForEvent("equipped",)--]]
		
		if data.serverfn then
			data.serverfn(inst) 
		end
		
		return inst
	end

	return Prefab(prefabname, WeaponFn, assets) 
end


local function CreateNormalHat(data)
    local prefabname = data.prefabname
	local assets = data.assets or {
		Asset("ANIM", "anim/"..prefabname..".zip"),		
		Asset("IMAGE","images/inventoryimages/"..prefabname..".tex"),
		Asset("ATLAS","images/inventoryimages/"..prefabname..".xml"),
	}
	local swapanims = data.swapanims or {prefabname,"swap_hat"}
	
    local function onequip(inst, owner)
        owner.AnimState:OverrideSymbol("swap_hat", swapanims[1],swapanims[2])
		
		if data.is_top then 
			owner.AnimState:Show("HAT")
			owner.AnimState:Hide("HAIR_HAT")
			owner.AnimState:Show("HAIR_NOHAT")
			owner.AnimState:Show("HAIR")

			owner.AnimState:Show("HEAD")
			owner.AnimState:Hide("HEAD_HAT")
		else
			owner.AnimState:Show("HAT")
			owner.AnimState:Show("HAIR_HAT")
			owner.AnimState:Hide("HAIR_NOHAT")
			owner.AnimState:Hide("HAIR")

			if owner:HasTag("player") then
				owner.AnimState:Hide("HEAD")
				owner.AnimState:Show("HEAD_HAT")
			end
		end 
        

        if data.onequip then 
			data.onequip(inst, owner)
		end
    end

    local function onunequip(inst, owner)
        owner.AnimState:ClearOverrideSymbol("swap_hat")
        owner.AnimState:Hide("HAT")
        owner.AnimState:Hide("HAIR_HAT")
        owner.AnimState:Show("HAIR_NOHAT")
        owner.AnimState:Show("HAIR")

        if owner:HasTag("player") then
            owner.AnimState:Show("HEAD")
            owner.AnimState:Hide("HEAD_HAT")
        end

        if data.onunequip then 
			data.onunequip(inst, owner)
		end
    end

    local function HatFn()
        local inst = CreateEntity()

        inst.entity:AddTransform()
        inst.entity:AddAnimState()
        inst.entity:AddNetwork()
		inst.entity:AddSoundEmitter() 

        MakeInventoryPhysics(inst)

        inst.AnimState:SetBank(data.bank)
		inst.AnimState:SetBuild(data.build)
		inst.AnimState:PlayAnimation(data.anim)

        

        MakeInventoryFloatable(inst)
		
		inst:AddTag("hat")
		if data.tags then
			for k,v in pairs(data.tags) do 
				inst:AddTag(v)
			end
		end  

		if data.clientfn then 
			data.clientfn(inst) 
		end 

        inst.entity:SetPristine()

        if not TheWorld.ismastersim then
            return inst
        end

        inst:AddComponent("inventoryitem")
		inst.components.inventoryitem.imagename = prefabname
		inst.components.inventoryitem.atlasname = "images/inventoryimages/"..prefabname..".xml"

        inst:AddComponent("inspectable")

        inst:AddComponent("tradable")

        inst:AddComponent("equippable")
        inst.components.equippable.equipslot = EQUIPSLOTS.HEAD
        inst.components.equippable:SetOnEquip(onequip)
        inst.components.equippable:SetOnUnequip(onunequip)

        MakeHauntableLaunch(inst)
		
		if data.serverfn then
			data.serverfn(inst) 
		end

        return inst
    end
	
	return Prefab(prefabname, HatFn, assets) 
	
end 

local function ReloadSkin(inst)
	if inst.components.skinner then 
		--[[body = self.clothing.body,
		hand = self.clothing.hand,
		legs = self.clothing.legs,
		feet = self.clothing.feet,--]]
		local skindata = inst.components.skinner:GetClothing()
		inst.components.skinner:SetClothing(skindata.body)
		inst.components.skinner:SetClothing(skindata.hand)
		inst.components.skinner:SetClothing(skindata.legs)
		inst.components.skinner:SetClothing(skindata.feet)
		
	end
end 

--AnimState: bank: wilson build: woodie_victorian anim: idle_loop anim/player_idles.zip:idle_loop Frame: 90.00/66 Facing: 3
local function UnpackDebugString(inst)
	local debug_str = inst.entity:GetDebugString()
	
	if not debug_str or not inst:IsValid() then 
		return 
	end
	local bank_index = string.find(debug_str,"bank: ")
	local bank_over = string.find(debug_str," ",bank_index+6)
	local bank = string.sub(debug_str,bank_index+6,bank_over-1)
	
	local build_index = string.find(debug_str,"build: ")
	local build_over = string.find(debug_str," ",build_index+7)
	local build = string.sub(debug_str,build_index+7,build_over-1)
	
	local anim_index = string.find(debug_str,"anim: ")
	local anim_over = string.find(debug_str," ",anim_index+6)
	local anim = string.sub(debug_str,anim_index+6,anim_over-1)
	
	--local bank,build,anim = string.match(debug_str,"AnimState: bank: %s build: %s anim: %s ")
	return {
		bank = bank,
		build = build,
		anim = anim,
	}
	
end

local function GetCurrentTileAtPoint(ptx,pty,ptz)
    local map = TheWorld.Map
    local tilecenter_x, tilecenter_y, tilecenter_z  = map:GetTileCenterPoint(ptx, 0, ptz)
    local tx, ty = map:GetTileCoordsAtPoint(ptx, 0, ptz)
    local actual_tile = map:GetTile(tx, ty)

    if actual_tile ~= nil and tilecenter_x ~= nil and tilecenter_z ~= nil then
        if actual_tile >= GROUND.UNDERGROUND then
            local xpercent = (tilecenter_x - ptx) / TILE_SCALE + .25
            local ypercent = (tilecenter_z - ptz) / TILE_SCALE + .25

            local x_min = xpercent > .666 and -1 or 0
            local x_max = xpercent < .333 and 1 or 0
            local y_min = ypercent > .666 and -1 or 0
            local y_max = ypercent < .333 and 1 or 0

            local x_off = 0
            local y_off = 0

            for x = x_min, x_max do
                for y = y_min, y_max do
                    local tile = map:GetTile(tx + x, ty + y)
                    if tile > actual_tile then
                        actual_tile = tile
                        x_off = x
                        y_off = y
                    end
                end
            end
        end

        return actual_tile, GetTileInfo(actual_tile)
    end
end 



local function IsOnWaterAtPoint(x,y,z,ignore_boats)
	local boat = TheWorld.Map:GetPlatformAtPoint(x, z)
	if boat and ignore_boats then 
		return false
	end 
	
	local probabily_tiles = {
		GROUND.OCEAN_COASTAL,
		GROUND.OCEAN_COASTAL_SHORE, 
		GROUND.OCEAN_SWELL,
		GROUND.OCEAN_ROUGH, 
		GROUND.OCEAN_REEF, 
		GROUND.OCEAN_REEF_SHORE, 
		GROUND.OCEAN_HAZARDOUS, 
	}
	
	local tile = GetCurrentTileAtPoint(x,y,z)
	for k,v in pairs(probabily_tiles) do 
		if tile == v then 
			return true
		end
	end
end 

local function IsOnWater(inst,ignore_boats)
	if inst and inst:IsValid() then 
		local x,y,z = inst.Transform:GetWorldPosition()
		return IsOnWaterAtPoint(x,y,z,ignore_boats)
	end 

end

local function IsIceyCookingProduct(product)
	for k,v in pairs(preparedfoods_icey) do 
		if v.name == product then 
			return true 
		end
	end
	return false
end 

local function AddNormalDebuff(target,data)
	data = data or {}
	if not target.components.debuffable then 
		target:AddComponent("debuffable")
	end
	
	local buffname = data.buffname
	local percent = data.percent or 1 
	
	local buffprefab = target.components.debuffable:GetDebuff(buffname)
	
	if buffprefab then 
		--Extend debuff 
		buffprefab.percent = math.min(1,buffprefab.percent + percent)
		target.components.debuffable:AddDebuff(buffname,"icey_normal_debuff")
	else
		target.components.debuffable:AddDebuff(buffname,"icey_normal_debuff")
		local now_buffprefab = target.components.debuffable:GetDebuff(buffname)
		now_buffprefab:Init(data)
	end
end 

local function AddNormalPoisonDebuff(target,is_strong_poison,data)
	--[[data = data or {}
	if not target.components.debuffable then 
		target:AddComponent("debuffable")
	end
	local buffname = is_strong_poison and "strong_poison" or "poison"
	local percent = data.percent or 1 
	
	data.buffname = buffname
	data.health_delta_tick = data.health_delta_tick or (is_strong_poison and -0.03) or -0.01
	data.type = is_strong_poison and "strong_poison" or "poison"
	
	local buffprefab = target.components.debuffable:GetDebuff(buffname)
	--local fx = target:SpawnChild("poisonbubble")
	
	if buffprefab then 
		--Extend poison debuff 
		buffprefab.percent = math.min(1,buffprefab.percent + percent)
		target.components.debuffable:AddDebuff(buffname,"icey_normal_debuff")
	else
		target.components.debuffable:AddDebuff(buffname,"icey_normal_debuff")
		local now_buffprefab = target.components.debuffable:GetDebuff(buffname)
		now_buffprefab:Init(data)
	end--]]
	data = data or {}
	data.buffname = is_strong_poison and "strong_poison" or "poison"
	data.health_delta_tick = data.health_delta_tick or (is_strong_poison and -0.03) or -0.01
	data.duration = data.duration or TUNING.TOTAL_DAY_TIME
	data.type = is_strong_poison and "strong_poison" or "poison"
	data.keepondespawn = true
	AddNormalDebuff(target,data)
end

local function AddDarkSoulDebuff(target,data)
	if not target.components.darksouldebuffable then 
		target:AddComponent("darksouldebuffable")
	end
	
	local buffname = data.buffname
	target.components.darksouldebuffable:AddDebuff(buffname,"icey_normal_darksouldebuff",data.percent)
	local now_buffprefab = target.components.darksouldebuffable:GetDebuff(buffname)
	now_buffprefab:Init(data)
end

local function AddDarkSoulPoisonDebuff(target,is_strong_poison,data)
	--[[data = data or {}
	data.buffname = is_strong_poison and "strong_poison" or "poison"
	data.health_delta_tick = data.health_delta_tick or (is_strong_poison and -0.03) or -0.01
	data.keepondespawn = true
	--data.decrease_rate = data.decrease_rate or 0.
	AddDarkSoulDebuff(target,data)--]]
	data = data or {}
	local buffname = is_strong_poison and "strong_poison" or "poison"
	local buffprefab = is_strong_poison and "darksouldebuff_strong_poison" or "darksouldebuff_poison"
	
	if not target.components.darksouldebuffable then 
		target:AddComponent("darksouldebuffable")
	end
	
	target.components.darksouldebuffable:AddDebuff(buffname,buffprefab,data.percent)
end

local function AddDarkSoulBleedsDebuff(target,data)
	--[[data = data or {}
	data.buffname = "bleeds"
	data.health_delta_tick = -20
	data.stamina_delta_tick = -75
	data.decrease_rate_activated = 0.33
	data.keepondespawn = true
	--data.decrease_rate = data.decrease_rate or 0.
	AddDarkSoulDebuff(target,data)--]]
	
	data = data or {}
	if not target.components.darksouldebuffable then 
		target:AddComponent("darksouldebuffable")
	end
	
	target.components.darksouldebuffable:AddDebuff("bleeds","darksouldebuff_bleeds",data.percent)
end

local function AddDarkSoulFreezeDebuff(target,data)
	data = data or {}
	if not target.components.darksouldebuffable then 
		target:AddComponent("darksouldebuffable")
	end
	
	target.components.darksouldebuffable:AddDebuff("freeze","darksouldebuff_freeze",data.percent)
	
end

local function AddDarkSoulCurseDeathDebuff(target,data)
	data = data or {}
	if not target.components.darksouldebuffable then 
		target:AddComponent("darksouldebuffable")
	end
	
	target.components.darksouldebuffable:AddDebuff("curse_death","darksouldebuff_curse_death",data.percent)
end

local function KnockBack(inst,other)
	local REPEL_RADIUS = 5
	local REPEL_RADIUS_SQ = REPEL_RADIUS * REPEL_RADIUS
	local start_inst_pos = inst:GetPosition()
	
	if other.sg and other.sg.sg.events.knockback then
		other:PushEvent("knockback", {knocker = inst, radius = 5})
	else
		--this stuff below is mostly left here for creatures in basegame. For modders that are reading this, use the knockback event above.
		if other ~= nil and not (other:HasTag("epic") or other:HasTag("largecreature")) then
			
			if other:IsValid() and other.entity:IsVisible() and not (other.components.health ~= nil and other.components.health:IsDead()) then
				if other.components.combat ~= nil then
					--other.components.combat:GetAttacked(inst, 10)
					if other.Physics ~= nil then
						local x, y, z = inst.Transform:GetWorldPosition()
						local distsq = other:GetDistanceSqToPoint(x, 0, z)
						--if distsq < REPEL_RADIUS_SQ then
							--[[if distsq > 0 then
								other:ForceFacePoint(x, 0, z)
							end--]]
							local k = .5 * distsq / REPEL_RADIUS_SQ - 1
							other.speed = 60 * k
							other.dspeed = 2
							other:ClearBufferedAction()
							other.Physics:ClearMotorVelOverride()
							other.Physics:Stop()
							
							if other.components.inventory and other.components.inventory:ArmorHasTag("heavyarmor") or other:HasTag("heavybody") then 
								--Leo: Need to change this to check for bodyslot for these tags.
								other.KnockBackTask = other:DoPeriodicTask(0, function(inst) 
									other:ClearBufferedAction()
									other:ForceFacePoint(start_inst_pos:Get())
									other.Physics:SetMotorVel(-2, 0, 0) 
								end)
							else
								other.KnockBackTask =  other:DoPeriodicTask(0, function(inst) 
									other:ClearBufferedAction()
									other:ForceFacePoint(start_inst_pos:Get())
									other.Physics:SetMotorVel(-18, 0, 0) 
								end)
							end
								other:DoTaskInTime(0.4, function(inst) 
								if other.KnockBackTask then 
									other.KnockBackTask:Cancel()
								end
								other.KnockBackTask = nil 
								other:ClearBufferedAction()
								other.Physics:ClearMotorVelOverride()
								other.Physics:Stop()
							end)
						--end
					end
				end
			end
		end
	end
end

return {
	IsDarkSpirit = IsDarkSpirit,
	IsDarkSpiritClient = IsDarkSpiritClient,
	CanDoDarkSpiritAttack = CanDoDarkSpiritAttack,
	CanDoDarkSpiritAttackClient = CanDoDarkSpiritAttackClient,
	CanAttack = CanAttack,
	
	ListenForEventOnce = ListenForEventOnce,
	WatchWorldStateOnce = WatchWorldStateOnce,
	IsPassableAtPoint = IsPassableAtPoint,
	
	MakeIceyAlly = MakeIceyAlly,
	
	DefaultCostFn = DefaultCostFn,
	MakeDragableUI = MakeDragableUI,
	
	EnableDrawOverFogOfWar = EnableDrawOverFogOfWar,
	
	CreateNormalFx = CreateNormalFx,
	CreateNormalWeapon = CreateNormalWeapon,
	CreateNormalHat = CreateNormalHat,
	
	ReloadSkin = ReloadSkin,
	
	UnpackDebugString = UnpackDebugString,
	
	IsOnWater = IsOnWater,
	IsOnWaterAtPoint = IsOnWaterAtPoint,
	
	IsIceyCookingProduct = IsIceyCookingProduct,
	
	AddNormalDebuff = AddNormalDebuff,
	AddNormalPoisonDebuff = AddNormalPoisonDebuff,
	
	AddDarkSoulDebuff = AddDarkSoulDebuff,
	
	AddDarkSoulPoisonDebuff = AddDarkSoulPoisonDebuff,
	AddDarkSoulBleedsDebuff = AddDarkSoulBleedsDebuff,
	AddDarkSoulFreezeDebuff = AddDarkSoulFreezeDebuff,
	AddDarkSoulCurseDeathDebuff = AddDarkSoulCurseDeathDebuff,
	
	KnockBack = KnockBack,
}