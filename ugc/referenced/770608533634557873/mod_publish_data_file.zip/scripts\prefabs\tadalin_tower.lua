local assets =
{
    Asset("ANIM", "anim/tadalin_tower.zip"),--------建筑的贴图文件
}

local prefabs =
{
    "redgem",
  
}

local minions = 
{
	[1] = "spider_haojie",
	[2] = "spider_xianfeng",
	[3] = "spider_chaser",
	[4] = "spider_bomb",
	[5] = "spider_dragoon",
}

SetSharedLootTable( 'tadalin_tower',     --------------建筑被破坏后掉落的东西列表
{
    {'redgem', 1.00},-----------红宝石？太土了吧！
	{'redgem', 0.75},-----------红宝石？太土了吧！
	{'redgem', 0.50},-----------红宝石？太土了吧！
	{'redgem', 0.25},-----------红宝石？太土了吧！
})


local function OnAttacked(inst,attacker)
	
end

local function SpawnSpiders(inst)-------------------正常折跃蜘蛛
	local spider = minions[math.random(1,5)]
	local x,y,z = inst:GetPosition():Get()
	local ents = TheSim:FindEntities(x,y,z,50,{"_combat","tadalin"})
	if #ents > 3 then 
		return
	end 
	repeat
		local offset = 2
		local x1, y1, z1 = 0,0,0
		local arc = math.random(0,360)
		local h = math.random(1,offset)
		x1 = x + math.cos(arc) * h
		z1 = z + math.sin(arc) * h
		if TheWorld.Map:IsPassableAtPoint(x1,y1, z1) then
			local spawn = SpawnPrefab(spider)
			spawn.Transform:SetPosition(x1,y1, z1)
			spawn.sg:GoToState("taunt")
			break
		end
	until TheWorld.Map:IsPassableAtPoint(x1, y1, z1)
	
end 

local function DoLavaFx(x,y,z)
	local fx = SpawnPrefab("tadalin_lava_lightning")
	fx:SetSize("medium",2)
	fx.Transform:SetPosition(x,y,z)
end 

local function SpawnDefenders(inst,attacker)-------------------紧急情况下折跃蜘蛛
	local spider = minions[math.random(1,5)]
	local x,y,z = inst:GetPosition():Get()
	local friends = TheSim:FindEntities(x,y,z,50, {"_combat","tadalin"},TUNING.ICEY_NO_TAGS)
	for k,v  in pairs(friends) do
		if v:IsValid() and v.components.combat and v.components.health and not v.components.health:IsDead() then
			v.components.combat:SetTarget(attacker)
		end
	end
	inst.AnimState:PlayAnimation("hit")
	inst.AnimState:PushAnimation("idle")
	inst.SoundEmitter:PlaySound("dontstarve/wilson/use_pick_rock")
	if math.random(0,100) < 90 or #friends > 8  then 
		return
	end 
	
	repeat
		local offset = 7
		local x1, y1, z1 = 0,0,0
		local arc = math.random(0,360)
		local h = math.random(2,offset)
		x1 = x + math.cos(arc) * h
		z1 = z + math.sin(arc) * h
		if TheWorld.Map:IsPassableAtPoint(x1,y1, z1) then
			if math.random() <= 0.25 and not FindEntity(inst,50,function(guy) return guy.prefab=="spider_monkey" end) then 
				spider = "spider_monkey"
				DoLavaFx(x1,y1,z1)
			end 
			local spawn = SpawnPrefab(spider)
			if spider == "spider_monkey" then 
				inst:DoTaskInTime(0.3,function()
					spawn.Transform:SetPosition(x1,y1, z1)
					spawn.sg:GoToState("taunt")
					TheNet:Announce("一只截图巨兽已经破卵而出了")
				end)
			else
				local fx = SpawnPrefab("red_lightning")
				fx.Transform:SetPosition(x1, y1, z1)
				spawn.Transform:SetPosition(x1,y1, z1)
				spawn.sg:GoToState("taunt")
			end 
			if spawn.components.combat and attacker then 
				spawn.components.combat:SetTarget(attacker)
			end
			break
		end
	until TheWorld.Map:IsPassableAtPoint(x1, y1, z1)

end 

local function OnKilled(inst)----------------------爆炸的一堆特效
	--inst.Transform:SetMultColor()
	local x,y,z = inst:GetPosition():Get()
	local fire = SpawnPrefab("houndfire")
	local bomb = SpawnPrefab("explode_small")
	local crackle = SpawnPrefab("hammer_mjolnir_crackle")
	local cracklebase = SpawnPrefab("hammer_mjolnir_cracklebase")
	local cracklehit = SpawnPrefab("hammer_mjolnir_cracklehit")
	local cracklehitfx = SpawnPrefab("cracklehitfx")
	
	bomb.Transform:SetScale(3,3,3)
	
	fire.Transform:SetPosition(x,y,z)
	bomb.Transform:SetPosition(x,y,z)
	crackle.Transform:SetPosition(x,y,z)
	cracklebase.Transform:SetPosition(x,y,z)
	cracklehit.Transform:SetPosition(x,y,z)
	cracklehitfx.Transform:SetPosition(x,y,z)
	
	crackle.AnimState:SetMultColour(73/255, 240/255, 235/255, 0.9)
	cracklebase.AnimState:SetMultColour(73/255, 240/255, 235/255, 1)
	cracklehit.AnimState:SetMultColour(73/255, 240/255, 235/255, 1)
	cracklehitfx.AnimState:SetMultColour(73/255, 240/255, 235/255, 1)
	
	crackle:ListenForEvent("animover", function(inst) inst:Remove() end )
	cracklebase:ListenForEvent("animover", function(inst) inst:Remove() end )
	cracklehit:ListenForEvent("animover", function(inst) inst:Remove() end )
	cracklehitfx:ListenForEvent("animover", function(inst) inst:Remove() end )
	
	inst.components.lootdropper:DropLoot(inst:GetPosition())
	inst:Hide()-------------------只是隐藏贴图，以免Remove()造成意外的报错(不知为何水晶塔的死亡动画不能被编译)
	
end

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddMiniMapEntity()
    inst.entity:AddNetwork()

    MakeObstaclePhysics(inst, 1) --------------建筑物理碰撞体积
	local minimap = inst.entity:AddMiniMapEntity() -------------设置小地图标志
	minimap:SetIcon("tadalin_tower.tex")
	

    inst.AnimState:SetBank("tadalin_tower")
    inst.AnimState:SetBuild("tadalin_tower")
    inst.AnimState:PlayAnimation("idle") ----------喜闻乐见的动画设置
	inst.Transform:SetScale(3,3,3)-----------------在这里设置建筑的放大缩小
	inst:AddTag("tadalin_tower") -------------------添加一个小标签QwQ
	inst:AddTag("tadalin")
    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

	inst:AddComponent("health")
    inst.components.health:SetMaxHealth(1000)
	
	inst:AddComponent("combat")
	inst.components.combat:SetOnHit(SpawnDefenders)
	
    inst:AddComponent("lootdropper")
	inst.components.lootdropper:SetChanceLootTable('tadalin_tower') -------------设置掉落物组件，和开头的列表对应

    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("鲜血核心.....") ------------设置可检查组件
	
    MakeHauntableWork(inst)--------------被作祟时的函数，这里是空的
    MakeSnowCovered(inst)--------------建筑物积雪时的函数，这里是空的
	
	inst:DoPeriodicTask(10,SpawnSpiders)
	
	inst:ListenForEvent("attacked", OnAttacked)
	inst:ListenForEvent("death", OnKilled)
	
    return inst
end

return Prefab("tadalin_tower", fn, assets, prefabs)