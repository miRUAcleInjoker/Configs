local assets_fx = {
    Asset("ANIM", "anim/lavaarena_lucy.zip"),
}

local function CreateSpinFX()
    local inst = CreateEntity()

    inst:AddTag("FX")
    --[[Non-networked entity]]
    inst.entity:SetCanSleep(false)
    inst.persists = false

    inst.entity:AddTransform()
    inst.entity:AddAnimState()

    inst.AnimState:SetBank("lavaarena_lucy")
    inst.AnimState:SetBuild("lavaarena_lucy")
    inst.AnimState:PlayAnimation("return")
    inst.AnimState:SetMultColour(.2, .2, .2, .2)

    inst.Transform:SetSixFaced()

    inst:DoTaskInTime(13 * FRAMES, inst.Remove)

    return inst
end

local function OnUpdateSpin(fx, inst)
    local parent = fx.owner.entity:GetParent()
    if fx.alpha >= .6 and (parent == nil or not (parent.AnimState:IsCurrentAnimation("catch_pre") or parent.AnimState:IsCurrentAnimation("catch"))) then
        fx.dalpha = -.1
    end
    local x, y, z = inst.Transform:GetWorldPosition()
    local x1, y1, z1 = fx.Transform:GetWorldPosition()
    local dx = x1 - x
    local dz = z1 - z
    local dist = math.sqrt(dx * dx + dz * dz)
    fx.offset = fx.offset * .8 + .2
    fx.vy = fx.vy + fx.ay
    fx.height = fx.height + fx.vy
    fx.Transform:SetPosition(x + dx * fx.offset / dist, fx.height, z + dz * fx.offset / dist)
    if fx.alpha ~= 0 then
        fx.alpha = fx.alpha + fx.dalpha
        if fx.alpha >= 1 then
            fx.dalpha = 0
            fx.alpha = 1
        elseif fx.alpha <= 0 then
            fx:Remove()
        end
        fx.AnimState:SetMultColour(fx.alpha, fx.alpha, fx.alpha, fx.alpha)
    end
end

local function OnOriginDirty(inst)
    local parent = inst.entity:GetParent()
    if parent ~= nil then
        local x, y, z = inst.Transform:GetWorldPosition()
        local dx = inst._originx:value() - x
        local dz = inst._originz:value() - z
        local distsq = dx * dx + dz * dz
        local dist = math.sqrt(distsq)
        local fx = CreateSpinFX()
        fx.owner = inst
        fx.offset = math.min(3, dist)
        fx.height = 2
        fx.vy = .2
        fx.ay = -.05
        fx.alpha = .2
        fx.dalpha = .2
        fx.Transform:SetPosition(x + dx * fx.offset / dist, fx.height, z + dz * fx.offset / dist)
        fx:ForceFacePoint(inst._originx:value(), 0, inst._originz:value())
        fx:ListenForEvent("onremove", function() fx:Remove() end, inst)
        fx:DoPeriodicTask(0, OnUpdateSpin, nil, inst)
    end
end

local function SetOrigin(inst, x, y, z)
    inst._originx:set(x)
    inst._originz:set(z)
    if not TheNet:IsDedicated() then
        OnOriginDirty(inst)
    end
end

local function fxfn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddNetwork()

    inst:AddTag("FX")

    inst._originx = net_float(inst.GUID, "lavaarena_lucy_spin._originx", "origindirty")
    inst._originz = net_float(inst.GUID, "lavaarena_lucy_spin._originz", "origindirty")

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        inst:ListenForEvent("origindirty", OnOriginDirty)

        return inst
    end

    inst.persists = false
    inst.SetOrigin = SetOrigin
    inst:DoTaskInTime(.5, inst.Remove)

    return inst
end

return  Prefab("riledlucyspin_fx", fxfn, assets_fx)