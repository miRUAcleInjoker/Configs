require("stategraphs/commonstates")

local function DoFoleySounds(inst)

	for k,v in pairs(inst.components.inventory.equipslots) do
		if v.components.inventoryitem and v.components.inventoryitem.foleysound then
			inst.SoundEmitter:PlaySound(v.components.inventoryitem.foleysound)
		end
	end

end

local actionhandlers = 
{
	ActionHandler(ACTIONS.EAT, "eat"),
}

   
local events=
{
	CommonHandlers.OnLocomote(true, false),

    EventHandler("attacked", function(inst, data)
		--inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/idle")
		if not inst.sg:HasStateTag("skilling") then 
			inst.sg:GoToState("hit")
		end 
	end),

    EventHandler("doattack", function(inst,data)
		local target = data.target
        if not inst.components.health:IsDead() then
			if inst.skill_fireball then 
				inst.sg:GoToState("skill_fireball",target)
			elseif inst.skill_ice then 
				inst.sg:GoToState("skill_ice",target)
			elseif inst.skill_flowers and inst.components.health:IsHurt() then 
				inst.sg:GoToState("skill_flowers",target)
			elseif inst.skill_fireman then 
				inst.sg:GoToState("skill_fireman",target)
			else
				inst.sg:GoToState("attack")
			end
			
        end
    end),
    
    EventHandler("death", function(inst)
		print("Preper to go to death sg")
        inst.sg:GoToState("death")
    end),
}

local emotes = {
	"emote_angry",
	"emote_annoyed_facepalm",
	"emote_annoyed_palmdown",
	"emote_hands",
	"emote_happycheer",
	"emote_hat",
	"emote_pants",
	"emote_sad",
	"emote_sleepy",
	"emote_strikepose",
	"emote_swoon",
	"emote_yawn",
}

local function PlayRandEmote(inst)
	local emote = emotes[math.random(1,#emotes)]
	inst.AnimState:PlayAnimation(emote)
end 

local function DoEmoteSound(inst, soundoverride, loop)
    --NOTE: loop only applies to soundoverride
    loop = loop and soundoverride ~= nil and "emotesoundloop" or nil
    local soundname = soundoverride or "emote"
    local emotesoundoverride = soundname.."soundoverride"
    inst.SoundEmitter:PlaySound("dontstarve/characters/maxwell/"..soundname, loop)
end

local function OnRemoveCleanupTargetFX(inst)
    if inst.sg.statemem.targetfx.KillFX ~= nil then
        inst.sg.statemem.targetfx:RemoveEventCallback("onremove", OnRemoveCleanupTargetFX, inst)
        inst.sg.statemem.targetfx:KillFX()
    else
        inst.sg.statemem.targetfx:Remove()
    end
end

local function FindAnotherTarget(inst)
	return inst.components.combat.targetfn(inst)
end 

local function CancelQuickAttack(inst)
	if inst.QuickAttackTask then 
		inst.QuickAttackTask:Cancel()
		inst.QuickAttackTask = nil 
	end
end 

local function DoQuickAttack(inst,targetoverride)
	local pos = inst:GetPosition()
	local offset = Vector3(1 - math.random()*2,0,1 - math.random()*2)
	local target = targetoverride or inst.components.combat.target
	
	if not (target and target:IsValid()) then 
		return 
	end 
	local targetpos = target:GetPosition()
	inst.Weapon = inst:GetSuitableAttackWeapon()
	inst.components.locomotor:Stop()
	inst.AnimState:PlayAnimation("atk_pre")
    inst.AnimState:PushAnimation("atk", false)
	inst:ForceFacePoint(targetpos)
	inst.Physics:SetMotorVelOverride(-math.random(),0,math.random(-2,2))
	--inst.components.locomotor:GoToPoint(pos+offset)
	CancelQuickAttack(inst)
	inst.QuickAttackTask = inst:DoTaskInTime(6 * FRAMES,function()
		--inst.components.locomotor:Stop()
		inst.Physics:Stop()
		inst:ForceFacePoint(targetpos)
		inst.SoundEmitter:PlaySound(inst.attacksound, nil, nil, true)
		inst.components.combat:DoAttack(targetoverride,inst.Weapon) 
	end)
end 

local function SpawnIceCircle(inst,skill_target)
	if not skill_target or not skill_target:IsValid() then 
		return 
	end
	local x,y,z = skill_target:GetPosition():Get()
	local spell = SpawnPrefab("deer_ice_circle")
	local burst = SpawnPrefab("deer_ice_fx")
	local stars = SpawnPrefab("deer_ice_flakes")
    spell.Transform:SetPosition(x, 0, z)
	burst.Transform:SetPosition(x, 0, z)
	stars.Transform:SetPosition(x, 0, z)
    spell:DoTaskInTime(6, spell.KillFX)
	burst:DoTaskInTime(6, spell.KillFX)
	stars:DoTaskInTime(6, spell.KillFX)
	inst:PushEvent("use_giaour_skill",{name = "skill_ice",cd = 60})
end 

local function SpawnFireman(inst,skill_target)
	if not skill_target or not skill_target:IsValid() then 
		return 
	end
	local x,y,z = skill_target:GetPosition():Get()
	local pos = Vector3(x,y,z)
	local rad = 3
	local offset = Vector3(3*(1 - math.random()*2),0,3*(1 - math.random()*2))
	
	local fireman = SpawnPrefab("moon_giaour_golem")
	fireman.Transform:SetPosition((pos+offset):Get())
	fireman.components.follower:SetLeader(inst)
	fireman.components.combat:SetTarget(skill_target)
	inst:PushEvent("use_giaour_skill",{name = "skill_fireman",cd = 12})
end 

local function SpawnMeteor(inst,skill_target)
	if not skill_target or not skill_target:IsValid() then 
		return 
	end
	local x,y,z = skill_target:GetPosition():Get()
	local meteor = SpawnPrefab("tadalin_meteor")
	meteor.Transform:SetPosition(x,y,z)
	inst:PushEvent("use_giaour_skill",{name = "skill_fireball",cd = 35})
end 

local function SpawnFlowers(inst,skill_target)
	if not skill_target or not skill_target:IsValid() then 
		return 
	end
	local x,y,z = skill_target:GetPosition():Get()
	local cilcle = SpawnPrefab("icey_healingcircle")
	cilcle.Transform:SetPosition(x,y,z)
	cilcle.buffed = false 
	inst:PushEvent("use_giaour_skill",{name = "skill_flowers",cd = 24})
end 

local states= 
{
	
	State{
        name = "infected",
        tags = {"busy"},
        
        onenter = function(inst)
            inst.components.locomotor:Stop()
			print("In infected SG")
			inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/grunt")
            --inst.AnimState:Hide("swap_arm_carry")
            inst.AnimState:PlayAnimation("transform_merm")
			--inst.AnimState:PushAnimation("idle_merm")
            --inst.components.lootdropper:DropLoot(Vector3(inst.Transform:GetWorldPosition()))  
			
        end,
		timeline=
        {
            TimeEvent(12*FRAMES, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/grunt")
            end),
        },        
        
        events=
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end),
        },
        
        onexit= function(inst)
            
        end,
    },
	
	State{
        name = "emote",
        tags = {"busy"},
        
        onenter = function(inst)
            inst.components.locomotor:Stop()
            PlayRandEmote(inst)
			DoEmoteSound(inst, nil,"minion_emote")
        end,
		timeline=
        {
       
        },        
        
        events=
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end),
        },
        
        onexit= function(inst)
            inst.SoundEmitter:KillSound("minion_emote")
        end,
    },
	
--[[	State{
        name = "taunt",
        tags = {"busy"},
        
        onenter = function(inst)
            inst.components.locomotor:Stop()
            --PlayRandEmote(inst)
			inst.AnimState:PlayAnimation("emote_fistshake")
			inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/howl")
			--DoEmoteSound(inst, nil,"taunt")
        end,
		timeline=
        {
       
        },        
        
        events=
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end),
        },
        
        onexit= function(inst)
            inst.SoundEmitter:KillSound("taunt")
        end,
    },--]]

	

    State{
        name = "death",
        tags = {"busy","death"},
        
        onenter = function(inst)
            inst.components.locomotor:Stop()
			print("In Death SG")
			inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/grunt")
			inst.AnimState:PlayAnimation("death")
            
			
        end,  
		timeline=
        {
            TimeEvent(12*FRAMES, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/grunt")
            end),
			TimeEvent(40*FRAMES, function(inst) 
                inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/grunt")
            end),
        },    
		events=
        {
            EventHandler("animover", function(inst) inst.components.lootdropper:DropLoot(Vector3(inst.Transform:GetWorldPosition())) end),
        },
        
        onexit= function(inst)
            
        end,         
    },

    State{
        name = "idle",
        tags = {"idle", "canrotate"},
        onenter = function(inst, pushanim)     
            inst.components.locomotor:Stop()
			--inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/idle")
            local anims = {}  
			table.insert(anims, "idle_loop")                          
            if pushanim then
                for k,v in pairs (anims) do
					inst.AnimState:PushAnimation(v, k == #anims)
				end
            else
                inst.AnimState:PlayAnimation(anims[1], #anims == 1)
                for k,v in pairs (anims) do
					if k > 1 then
						inst.AnimState:PushAnimation(v, k == #anims)
					end
				end
            end  
            inst.sg:SetTimeout(math.random()*4+2)
        end,
    },

    State{
        name = "eat",
        tags ={"busy"},
        onenter = function(inst)
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("quick_eat")
        end,

        timeline=
        {
            TimeEvent(12*FRAMES, function(inst) 
                inst:PerformBufferedAction() 
                inst.sg:RemoveStateTag("busy")
            end),
        },        
        
        events=
        {
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end),
        },
        
        onexit= function(inst)
            inst.SoundEmitter:KillSound("eating")    
        end,
    },    
	
------------------------------------------------------------------------------------------------------------------------------------------------------
    State{
        name = "attack",
        tags = {"attack", "notalking", "abouttoattack", "busy"},
        
        onenter = function(inst)
			
			inst.sg.statemem.target = inst.components.combat.target
			print(inst.sg.statemem.target)
            inst.components.combat:StartAttack()
            DoQuickAttack(inst)
			inst.sg:SetTimeout((14+math.random()*11)*FRAMES)
        end,
		
		--[[onupdate = function(inst)
			if inst:ShoudlRunAway() then 
				inst:PushEvent("shouldrun")
			end
		end,--]]
		
		ontimeout = function(inst)
			inst.sg:GoToState("idle")
		end,
		
        timeline=
        {	
            TimeEvent(0*FRAMES, function(inst) 
				--inst.components.combat:DoAttack(inst.sg.statemem.target) 
				DoQuickAttack(inst)
			end),
			TimeEvent(7*FRAMES, function(inst) 
				--inst.components.combat:DoAttack(inst.sg.statemem.target) 
				DoQuickAttack(inst,FindAnotherTarget(inst))
			end),
			TimeEvent(14*FRAMES, function(inst) 
				--inst.components.combat:DoAttack(inst.sg.statemem.target) 
				DoQuickAttack(inst)
			end),
			TimeEvent(21*FRAMES, function(inst) 
				--inst.components.combat:DoAttack(inst.sg.statemem.target) 
				DoQuickAttack(inst,FindAnotherTarget(inst))
			end),
			TimeEvent(28*FRAMES, function(inst) 
				--inst.components.combat:DoAttack(inst.sg.statemem.target) 
				DoQuickAttack(inst)
			end),
			TimeEvent(35*FRAMES, function(inst) 
				--inst.components.combat:DoAttack(inst.sg.statemem.target) 
				DoQuickAttack(inst,FindAnotherTarget(inst))
			end),
        },
        
        events=
        {
			EventHandler("shouldrun",function(inst,data)
				inst.sg:GoToState("run_start")
			end),
        },
    },       
	
    State{
        name = "skill_fireball", ----------�ٻ�������
        tags = { "doing", "busy", "canrotate","attack","skilling" },

        onenter = function(inst,skill_target)
			inst.Weapon = inst:EquipFireStaff()
            inst.AnimState:PlayAnimation("staff_pre")
            inst.AnimState:PushAnimation("staff", false)
            inst.components.locomotor:Stop()

            --Spawn an effect on the player's location
            local colour = { 255/255,0/255,0/255 }
			
			inst.sg.statemem.skill_target = skill_target

            inst.sg.statemem.stafffx = SpawnPrefab("staffcastfx")
            inst.sg.statemem.stafffx.entity:SetParent(inst.entity)
            inst.sg.statemem.stafffx.Transform:SetRotation(inst.Transform:GetRotation())
            inst.sg.statemem.stafffx:SetUp(colour)

            inst.sg.statemem.stafflight = SpawnPrefab("staff_castinglight")
            inst.sg.statemem.stafflight.Transform:SetPosition(inst.Transform:GetWorldPosition())
            inst.sg.statemem.stafflight:SetUp(colour, 1.9, .33)

            inst.sg.statemem.castsound = "dontstarve/common/lava_arena/spell/meteor"
        end,

        timeline =
        {
            TimeEvent(13 * FRAMES, function(inst)
                inst.SoundEmitter:PlaySound(inst.sg.statemem.castsound)
            end),
            TimeEvent(53 * FRAMES, function(inst)
                if inst.sg.statemem.targetfx ~= nil then
                    if inst.sg.statemem.targetfx:IsValid() then
                        OnRemoveCleanupTargetFX(inst)
                    end
                    inst.sg.statemem.targetfx = nil
                end
                inst.sg.statemem.stafffx = nil --Can't be cancelled anymore
                inst.sg.statemem.stafflight = nil --Can't be cancelled anymore
                --V2C: NOTE! if we're teleporting ourself, we may be forced to exit state here!
                --inst:PerformBufferedAction()
				SpawnMeteor(inst,inst.sg.statemem.skill_target)
            end),
        },

        events =
        {
            EventHandler("animqueueover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("idle")
                end
            end),
        },

        onexit = function(inst)
			inst.sg.statemem.skill_target = nil 
            if inst.sg.statemem.stafffx ~= nil and inst.sg.statemem.stafffx:IsValid() then
                inst.sg.statemem.stafffx:Remove()
            end
            if inst.sg.statemem.stafflight ~= nil and inst.sg.statemem.stafflight:IsValid() then
                inst.sg.statemem.stafflight:Remove()
            end
            if inst.sg.statemem.targetfx ~= nil and inst.sg.statemem.targetfx:IsValid() then
                OnRemoveCleanupTargetFX(inst)
            end
        end,
    },
	
	State{
        name = "skill_flowers", ----------�ٻ���Ȧ
        tags = { "doing", "busy", "canrotate","skilling" },

        onenter = function(inst,skill_target)
			inst.Weapon = inst:EquipHealthStaff()
            inst.AnimState:PlayAnimation("staff_pre")
            inst.AnimState:PushAnimation("staff", false)
            inst.components.locomotor:Stop()

            --Spawn an effect on the player's location
            local colour = { 0,1,0 }
			
			inst.sg.statemem.skill_target = skill_target

            inst.sg.statemem.stafffx = SpawnPrefab("staffcastfx")
            inst.sg.statemem.stafffx.entity:SetParent(inst.entity)
            inst.sg.statemem.stafffx.Transform:SetRotation(inst.Transform:GetRotation())
            inst.sg.statemem.stafffx:SetUp(colour)

            inst.sg.statemem.stafflight = SpawnPrefab("staff_castinglight")
            inst.sg.statemem.stafflight.Transform:SetPosition(inst.Transform:GetWorldPosition())
            inst.sg.statemem.stafflight:SetUp(colour, 1.9, .33)

            inst.sg.statemem.castsound = "dontstarve/common/lava_arena/spell/meteor"
        end,

        timeline =
        {
            TimeEvent(13 * FRAMES, function(inst)
                inst.SoundEmitter:PlaySound(inst.sg.statemem.castsound)
            end),
            TimeEvent(53 * FRAMES, function(inst)
                if inst.sg.statemem.targetfx ~= nil then
                    if inst.sg.statemem.targetfx:IsValid() then
                        OnRemoveCleanupTargetFX(inst)
                    end
                    inst.sg.statemem.targetfx = nil
                end
                inst.sg.statemem.stafffx = nil --Can't be cancelled anymore
                inst.sg.statemem.stafflight = nil --Can't be cancelled anymore
                --V2C: NOTE! if we're teleporting ourself, we may be forced to exit state here!
                --inst:PerformBufferedAction()
				SpawnFlowers(inst,inst.sg.statemem.skill_target)
            end),
        },

        events =
        {
            EventHandler("animqueueover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("idle")
                end
            end),
        },

        onexit = function(inst)
			inst.sg.statemem.skill_target = nil 
            if inst.sg.statemem.stafffx ~= nil and inst.sg.statemem.stafffx:IsValid() then
                inst.sg.statemem.stafffx:Remove()
            end
            if inst.sg.statemem.stafflight ~= nil and inst.sg.statemem.stafflight:IsValid() then
                inst.sg.statemem.stafflight:Remove()
            end
            if inst.sg.statemem.targetfx ~= nil and inst.sg.statemem.targetfx:IsValid() then
                OnRemoveCleanupTargetFX(inst)
            end
        end,
    },   
	
	State{
        name = "skill_ice", ----------�ٻ�����
        tags = { "doing","book","attack","skilling" },

        onenter = function(inst,skill_target)
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("action_uniqueitem_pre")
            inst.AnimState:PushAnimation("book", false)
			--inst.AnimState:OverrideSymbol("book_closed", "swap_book_fossil", "book_closed")
			
			inst.AnimState:OverrideSymbol("book_open", "swap_book_fossil", "book_open")
            inst.AnimState:OverrideSymbol("book_closed", "swap_book_fossil", "book_closed")
            inst.AnimState:OverrideSymbol("book_open_pages", "swap_book_fossil", "book_open_pages")
            inst.AnimState:Show("ARM_normal")
			inst.sg.statemem.skill_target = skill_target

			inst.sg.statemem.isaoe = true 
            inst.sg.statemem.castsound = "dontstarve/common/lava_arena/spell/fossilized"
        end,

        timeline =
        {
            TimeEvent(0, function(inst)
                inst.sg.statemem.book_fx = SpawnPrefab("book_fx")
                inst.sg.statemem.book_fx.entity:SetParent(inst.entity)
                inst.sg.statemem.book_fx.Transform:SetPosition(0, .2, 0)
                inst.sg.statemem.book_fx.Transform:SetRotation(inst.Transform:GetRotation())
            end),
            TimeEvent(25 * FRAMES, function(inst)
                if inst.sg.statemem.isaoe then
                    inst.SoundEmitter:PlaySound(inst.sg.statemem.castsound)
                    --inst:PerformBufferedAction()
					SpawnIceCircle(inst,inst.sg.statemem.skill_target)
                end
            end),
            TimeEvent(28 * FRAMES, function(inst)
                inst.SoundEmitter:PlaySound("dontstarve/common/use_book_light")
            end),
            TimeEvent(54 * FRAMES, function(inst)
                inst.SoundEmitter:PlaySound("dontstarve/common/use_book_close")
            end),
            TimeEvent(58 * FRAMES, function(inst)
                if inst.sg.statemem.targetfx ~= nil then
                    if inst.sg.statemem.targetfx:IsValid() then
                        OnRemoveCleanupTargetFX(inst)
                    end
                    inst.sg.statemem.targetfx = nil
                end
                inst.sg.statemem.book_fx = nil --Don't cancel anymore
                if not inst.sg.statemem.isaoe then
                    inst.SoundEmitter:PlaySound(inst.sg.statemem.castsound)
                end
            end),
            TimeEvent(65 * FRAMES, function(inst)
                if inst.sg.statemem.isaoe then
                    inst.sg:RemoveStateTag("busy")
                end
            end),
        },

        events =
        {
            EventHandler("animqueueover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("idle")
                end
            end),
        },

        onexit = function(inst)
            local item = inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
            inst.AnimState:Show("ARM_carry")
            inst.AnimState:Hide("ARM_normal")
            if inst.sg.statemem.book_fx ~= nil and inst.sg.statemem.book_fx:IsValid() then
                inst.sg.statemem.book_fx:Remove()
            end
            if inst.sg.statemem.targetfx ~= nil and inst.sg.statemem.targetfx:IsValid() then
                OnRemoveCleanupTargetFX(inst)
            end
        end,
    },
	
	State{
        name = "skill_fireman", ----------�ٻ����ҿ���
        tags = { "doing","book","attack","skilling" },

        onenter = function(inst,skill_target)
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("action_uniqueitem_pre")
            inst.AnimState:PushAnimation("book", false)
			--inst.AnimState:OverrideSymbol("book_closed", "swap_book_elemental", "book_closed")
			inst.AnimState:OverrideSymbol("book_open", "swap_book_elemental", "book_open")
            inst.AnimState:OverrideSymbol("book_closed", "swap_book_elemental", "book_closed")
            inst.AnimState:OverrideSymbol("book_open_pages", "swap_book_elemental", "book_open_pages")
            inst.AnimState:Show("ARM_normal")
			inst.sg.statemem.skill_target = skill_target

			inst.sg.statemem.isaoe = true 
            inst.sg.statemem.castsound = "dontstarve/common/lava_arena/spell/fossilized"
        end,

        timeline =
        {
            TimeEvent(0, function(inst)
                inst.sg.statemem.book_fx = SpawnPrefab("book_fx")
                inst.sg.statemem.book_fx.entity:SetParent(inst.entity)
                inst.sg.statemem.book_fx.Transform:SetPosition(0, .2, 0)
                inst.sg.statemem.book_fx.Transform:SetRotation(inst.Transform:GetRotation())
            end),
            TimeEvent(25 * FRAMES, function(inst)
                if inst.sg.statemem.isaoe then
                    inst.SoundEmitter:PlaySound(inst.sg.statemem.castsound)
                    --inst:PerformBufferedAction()
					SpawnFireman(inst,inst.sg.statemem.skill_target)
                end
            end),
            TimeEvent(28 * FRAMES, function(inst)
                inst.SoundEmitter:PlaySound("dontstarve/common/use_book_light")
            end),
            TimeEvent(54 * FRAMES, function(inst)
                inst.SoundEmitter:PlaySound("dontstarve/common/use_book_close")
            end),
            TimeEvent(58 * FRAMES, function(inst)
                if inst.sg.statemem.targetfx ~= nil then
                    if inst.sg.statemem.targetfx:IsValid() then
                        OnRemoveCleanupTargetFX(inst)
                    end
                    inst.sg.statemem.targetfx = nil
                end
                inst.sg.statemem.book_fx = nil --Don't cancel anymore
                if not inst.sg.statemem.isaoe then
                    inst.SoundEmitter:PlaySound(inst.sg.statemem.castsound)
                end
            end),
            TimeEvent(65 * FRAMES, function(inst)
                if inst.sg.statemem.isaoe then
                    inst.sg:RemoveStateTag("busy")
                end
            end),
        },

        events =
        {
            EventHandler("animqueueover", function(inst)
                if inst.AnimState:AnimDone() then
                    inst.sg:GoToState("idle")
                end
            end),
        },

        onexit = function(inst)
            local item = inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
            inst.AnimState:Show("ARM_carry")
            inst.AnimState:Hide("ARM_normal")
            if inst.sg.statemem.book_fx ~= nil and inst.sg.statemem.book_fx:IsValid() then
                inst.sg.statemem.book_fx:Remove()
            end
            if inst.sg.statemem.targetfx ~= nil and inst.sg.statemem.targetfx:IsValid() then
                OnRemoveCleanupTargetFX(inst)
            end
        end,
    },
   
    State{
        name = "run_start",
        tags = {"moving", "running", "canrotate"},
        
        onenter = function(inst)
			inst.components.locomotor:RunForward()
            inst.AnimState:PlayAnimation("run_pre")
            inst.sg.mem.foosteps = 0
        end,

        onupdate = function(inst)
            inst.components.locomotor:RunForward()
        end,

        events=
        {   
            EventHandler("animover", function(inst) inst.sg:GoToState("run") end ),        
        },
        
        timeline=
        {
        
            TimeEvent(4*FRAMES, function(inst)
                PlayFootstep(inst)
                DoFoleySounds(inst)
            end),
        },        
        
    },

    State{
        
        name = "run",
        tags = {"moving", "running", "canrotate"},
        
        onenter = function(inst) 
            inst.components.locomotor:RunForward()
            inst.AnimState:PlayAnimation("run_loop",true)
        end,
        
        onupdate = function(inst)
            inst.components.locomotor:RunForward()
        end,

        timeline=
        {
            TimeEvent(7*FRAMES, function(inst)
				inst.sg.mem.foosteps = inst.sg.mem.foosteps + 1
                PlayFootstep(inst, inst.sg.mem.foosteps < 5 and 1 or .6)
                DoFoleySounds(inst)
            end),
            TimeEvent(15*FRAMES, function(inst)
				inst.sg.mem.foosteps = inst.sg.mem.foosteps + 1
                PlayFootstep(inst, inst.sg.mem.foosteps < 5 and 1 or .6)
                DoFoleySounds(inst)
            end),
        },
        
        events=
        {   
            EventHandler("animover", function(inst) inst.sg:GoToState("run") end ),        
        },
        
        
    },
    
    State{
        name = "run_stop",
        tags = {"canrotate", "idle"},
        
        onenter = function(inst) 
            inst.components.locomotor:Stop()
            inst.AnimState:PlayAnimation("run_pst")
        end,
        
        events=
        {   
            EventHandler("animover", function(inst) inst.sg:GoToState("idle") end ),        
        },       
    },    
	
	State{
        name = "hit",
        tags = { "busy", "pausepredict" },

        onenter = function(inst, frozen)
            inst.components.locomotor:Stop()
            inst:ClearBufferedAction()

            inst.AnimState:PlayAnimation("hit")

            if frozen == "noimpactsound" then
                frozen = nil
            else
                inst.SoundEmitter:PlaySound("dontstarve/wilson/hit")
            end
			inst.SoundEmitter:PlaySound("dontstarve/creatures/werepig/hurt")
			
            local stun_frames = frozen and 10 or 6
            inst.sg:SetTimeout(stun_frames * FRAMES)
        end,

        ontimeout = function(inst)
			if inst.components.health:IsDead() then 
				inst.sg:GoToState("death")
			else
				inst.sg:GoToState("idle")
			end 
        end,
    },
}

    
return StateGraph("SGmoon_giaour", states, events, "idle", actionhandlers)

