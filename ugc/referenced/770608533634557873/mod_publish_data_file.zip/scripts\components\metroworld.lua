local IceyUtil = require("icey_util")

local function Init(world)
	if not world.components.metroworld.inited then 
		world.components.metroworld:InitSeason() 
	end 
end 

local MetroWorld = Class(function(self, inst)
	self.inst = inst 
	
	self.spring_length = {2,8}
	self.summer_length = {2,4}
	self.autumn_length = {1,8}
	self.winter_length = {55,75}
	
	self.inited = false 
	
	IceyUtil.ListenForEventOnce(inst,"ms_playerjoined",Init)
end)

function MetroWorld:InitSeason()
	self.inst:PushEvent("ms_setseasonlength",{season = "spring",length = math.random(self.spring_length[1],self.spring_length[2])})
	self.inst:PushEvent("ms_setseasonlength",{season = "summer",length = math.random(self.summer_length[1],self.summer_length[2])})
	self.inst:PushEvent("ms_setseasonlength",{season = "autumn",length = math.random(self.autumn_length[1],self.autumn_length[2])})
	self.inst:PushEvent("ms_setseasonlength",{season = "winter",length = math.random(self.winter_length[1],self.winter_length[2])})
	self.inited = true
end

function MetroWorld:SetRain(enable)
	self.inst:PushEvent("ms_forceprecipitation", enable)
end

function MetroWorld:Lightning(pos)
	pos = pos or Vectro3(0,0,0) 
	self.inst:PushEvent("ms_sendlightningstrike", pos:GetPosition())
end

function MetroWorld:OnSave()
	return {
		inited = self.inited 
	}
end

function MetroWorld:OnLoad(data)
	if data then
		self.inited = data.inited
	end
end
--TheWorld.components.metroworld:InitSeason() 
--TheWorld.components.metroworld:SetRain(true) 
--TheWorld.components.metroworld:InitSeason() 

return MetroWorld