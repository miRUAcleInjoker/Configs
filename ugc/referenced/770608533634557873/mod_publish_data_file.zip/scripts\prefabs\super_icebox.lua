
local assets_super_icebox = {
	Asset("ANIM", "anim/ice_box.zip"),
}


---------------------------------------------------------------------

local containers = require("containers")
local widgetsetup_old = containers.widgetsetup

local super_icebox = 
{
 widget =
    {
		slotpos = {	
			Vector3(0,108,0), 
			Vector3(0,36,0),
			Vector3(0,-36,0), 
			Vector3(0,-108,0)
		},
        animbank = "ui_cookpot_1x4",
        animbuild = "ui_cookpot_1x4",
        pos = Vector3(200,0,0),
    },
    acceptsstacks = true,
    type = "chest",
}


function containers.widgetsetup(container, prefab, data, ...)
	if container.inst.prefab == "super_icebox" or prefab == "super_icebox" then
		for k, v in pairs(super_icebox) do
            container[k] = v
        end
        container:SetNumSlots(container.widget.slotpos ~= nil and #container.widget.slotpos or 0)
        return
	end
    return widgetsetup_old(container, prefab, data, ...)
end

function super_icebox.itemtestfn(container, item, slot)
     if item:HasTag("icebox_valid") then
        return true
    end

    --Perishable
    if (item:HasTag("fresh") or item:HasTag("stale") or item:HasTag("spoiled")) then
        return true
    end

    --Edible
    for k, v in pairs(FOODTYPE) do
        if item:HasTag("edible_"..v) then
            return true
        end
    end

    return false
end
------------------------------------------------------------------------------------

local function onopen_super_icebox(inst)
    inst.AnimState:PlayAnimation("open")
    inst.SoundEmitter:PlaySound("dontstarve/common/icebox_open")
end

local function onclose_super_icebox(inst)
    inst.AnimState:PlayAnimation("close")
    inst.SoundEmitter:PlaySound("dontstarve/common/icebox_close")
end


local function turnon_super_icebox(inst)
	inst:AddTag("fridge")
	inst.Light:Enable(true)
	local items = inst.components.container:FindItems(function() return true end)
	for k,v in pairs(items) do 
		if v.components.perishable then 
			v.components.perishable:StopPerishing()
		end
	end 
end 

local function turnoff_super_icebox(inst)
	inst:RemoveTag("fridge")
	inst.Light:Enable(false)
	local items = inst.components.container:FindItems(function() return true end)
	for k,v in pairs(items) do 
		if v.components.perishable then 
			v.components.perishable:StartPerishing()
		end
	end 
end 

local function getitem_super_icebox(inst,data)
	local item = data.item
	print(inst,"Get a item:",item)
	if inst.IsOn and item.components.perishable then 
		item.components.perishable:StopPerishing()
	end
end 

local function loseitem_super_icebox(inst,data)
	local item = data.item
	print(inst,"Lost a item:",item)
	if item.components.perishable then 
		item.components.perishable:StartPerishing()
	end
end 

local function CheckPower_super_icebox(inst,data)
	local power = data.power
	inst.building_power = inst.building_power + power
	inst.building_power = math.max(0,inst.building_power)
	inst.building_power = math.min(inst.max_building_power,inst.building_power)
	if inst.building_power > 0 and not inst.IsOn then 
		print(inst,"Turn on!")
		turnon_super_icebox(inst)
		inst.IsOn = true
	elseif inst.building_power <= 0 and inst.IsOn then
		print(inst,"Turn off!")
		turnoff_super_icebox(inst)
		inst.IsOn = false
	end 
end



local function OnSave_Super_Icebox(inst,data)
	data.building_power = inst.building_power
	--data.IsOn = inst.IsOn
end 

local function OnLoad_Super_Icebox(inst,data)
	if data then 
		if data.building_power then 
			inst.building_power = data.building_power
		end
		--[[if data.IsOn then 
			inst.IsOn = data.IsOn
		end--]]
		CheckPower_super_icebox(inst,{fromer = inst,power = 0})
	end
end 

local function onhit_super_icebox(inst, worker)
    inst.AnimState:PlayAnimation("hit")
    inst.components.container:DropEverything()
    inst.AnimState:PushAnimation("closed", false)
    inst.components.container:Close()
end

local function onhammered_super_icebox(inst)
	inst.components.lootdropper:DropLoot()
	inst.components.container:DropEverything()
    local fx = SpawnPrefab("collapse_small")
    fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
    fx:SetMaterial("metal")
    inst:Remove()
end 

local function onbuilt_super_icebox(inst)
	inst.AnimState:PlayAnimation("place")
    inst.AnimState:PushAnimation("closed", false)
    inst.SoundEmitter:PlaySound("dontstarve/common/icebox_craft")
end

local function super_icebox_fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()
	inst.entity:AddLight()

    MakeObstaclePhysics(inst, .3)

    inst.AnimState:SetBank("icebox")
    inst.AnimState:SetBuild("ice_box")
    inst.AnimState:PlayAnimation("closed")
	
	local minimap = inst.entity:AddMiniMapEntity() -------------设置小地图标志
	minimap:SetIcon("icebox.png")
	
	inst.Light:Enable(false)
    inst.Light:SetRadius(2.5)
    inst.Light:SetFalloff(1)
    inst.Light:SetIntensity(.5)
    inst.Light:SetColour(141/255,224/255,255/255)
	
	inst:AddTag("icey_power_use")
	inst:AddTag("icey_power_building")
	inst:AddTag("fridge")
    inst:AddTag("structure")
	--inst:AddTag("structure")
	--inst:AddTag("companion")

    MakeSnowCoveredPristine(inst)

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end


	inst.IsOn = false
	inst.building_power = 0
	inst.max_building_power = 500
	
	
    inst:AddComponent("inspectable")
	inst.components.inspectable.descriptionfn = function(inst,doer)
		return (inst.IsOn and "停滞在时空中吧~" ) or "它需要充电了!"
	end

	
	inst.OnLoad = OnLoad_Super_Icebox
	inst.OnSave = OnSave_Super_Icebox
	
	inst:AddComponent("lootdropper")
	
	inst:AddComponent("workable")
    inst.components.workable:SetWorkAction(ACTIONS.HAMMER)
    inst.components.workable:SetWorkLeft(2)
	inst.components.workable:SetOnFinishCallback(onhammered_super_icebox)
    inst.components.workable:SetOnWorkCallback(onhit_super_icebox) 
	
	inst:AddComponent("container")
    inst.components.container:WidgetSetup("super_icebox",super_icebox)
	--inst.components.container:WidgetSetup("icebox")
    inst.components.container.onopenfn = onopen_super_icebox
    inst.components.container.onclosefn = onclose_super_icebox
	--------------------------------------------------------------------
	inst.components.container.RemoveItemBySlot = function(self,slot)
		if slot and self.slots[slot] then
			local item = self.slots[slot]
			if item then
				self.slots[slot] = nil
				if item.components.inventoryitem then
					item.components.inventoryitem:OnRemoved()
				end

				self.inst:PushEvent("itemlose", {slot = slot,item = item})
			end
			item.prevcontainer = self
			item.prevslot = slot
			return item
		end
	end
	--------------------------------------------------------------------
	inst.components.container.RemoveItem = function(self,item, wholestack)
		if item == nil then
			return
		end

		local prevslot = self:GetItemSlot(item)

		if not wholestack and item.components.stackable ~= nil and item.components.stackable:IsStack() then
			local dec = item.components.stackable:Get()
			dec.prevslot = prevslot
			dec.prevcontainer = self
			return dec
		end

		for k, v in pairs(self.slots) do
			if v == item then
				self.slots[k] = nil
				self.inst:PushEvent("itemlose", { slot = k ,item = item})
				item.components.inventoryitem:OnRemoved()
				item.prevslot = prevslot
				item.prevcontainer = self
				return item
			end
		end

		return item
	end
	--------------------------------------------------------------------
	inst:DoPeriodicTask(1,function()
		inst:PushEvent("powertrans",{former = inst,power = -10})
	end)
	inst:ListenForEvent("powertrans",CheckPower_super_icebox)
	inst:ListenForEvent("onbuilt", onbuilt_super_icebox)
	inst:ListenForEvent("itemget", getitem_super_icebox)
	inst:ListenForEvent("dropitem", loseitem_super_icebox)
	inst:ListenForEvent("itemlose", loseitem_super_icebox)
    return inst
end

return Prefab("super_icebox", super_icebox_fn, assets_super_icebox),
MakePlacer("super_icebox_placer", "icebox", "ice_box", "closed")
