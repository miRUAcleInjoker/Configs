local IceyGunBullet = Class(function(self, inst)
	self.inst = inst
	
	inst:AddTag("iceygunbullet")
end)

function IceyGunBullet:OnRemoveFromEntity()
	self.inst:RemoveTag("iceygunbullet")
end

return IceyGunBullet