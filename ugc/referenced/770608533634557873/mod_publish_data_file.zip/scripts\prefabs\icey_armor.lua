local assets =
{ 
    Asset("ANIM", "anim/icey_armor.zip"),
    --Asset("ANIM", "anim/icey_armor_swap.zip"), 

    Asset("ATLAS", "images/inventoryimages/icey_armor.xml"),
    Asset("IMAGE", "images/inventoryimages/icey_armor.tex"),
}

local function OnShieldChange(owner,data)
	local max = owner.components.icey_shield:GetMax()
	local inst = owner.components.inventory:GetEquippedItem(EQUIPSLOTS.BODY)
	local current = data.current
	if owner:HasTag("playerghost") then 
		return
	end 
	if not inst then 
		return 
	end 
	
	if owner.components.temperature and owner.components.burnable and owner.components.health then 
		if ( owner.components.temperature:IsOverheating() or 
		owner.components.burnable:IsBurning() or 
		owner.components.health.takingfiredamage or 
		owner.components.temperature:IsFreezing() 
		) then 
			return
		end 
	end 	
	if owner and owner.components.inventory and owner.components.inventory:Has("icey_battery",1)
	and max - current >= 25 and owner.components.eater
	then 
		local battery = owner.components.inventory:FindItem(function(item) 
			return item.prefab and item.prefab == "icey_battery" 
		end)
		if battery and battery:IsValid() then
			if  battery.components.stackable then 
				battery = battery.components.stackable:Get() 
			end 
			if GetTime() - inst.LastEatTime >= 0.33 then 
				--owner.components.eater:Eat(battery)
				inst.LastEatTime = GetTime() 
			end 
		end 
	end 
end 

local function OnGreatMiss(owner,data)
	local eny = data.eny
	if owner and owner:IsValid() then 
		local armor = owner.components.inventory:GetEquippedItem(EQUIPSLOTS.BODY)
		if armor and armor:IsValid() and armor.prefab == "icey_armor" and armor.components.armor then 
			armor.components.armor:SetAbsorption(1.0)
			if armor.ToNormalArmorTask then 
				armor.ToNormalArmorTask:Cancel()
				armor.ToNormalArmorTask = nil 
			end 
			armor.ToNormalArmorTask = armor:DoTaskInTime(1.5,function()
				armor.components.armor:SetAbsorption(0.65)
				armor.ToNormalArmorTask = nil 
			end)
		end
	end
end 

local function OnEquip(inst, owner) 
	if owner:HasTag("icey") then 
		--inst:ListenForEvent("icey_shield_change",OnShieldChange,owner)
		inst:ListenForEvent("icey_greatmiss",OnGreatMiss,owner)
	end 
end

local function OnUnequip(inst, owner) 
	if owner:HasTag("icey") then 
		--inst:RemoveEventCallback("icey_shield_change",OnShieldChange,owner)
		inst:RemoveEventCallback("icey_greatmiss",OnGreatMiss,owner)
	end 
end

local function fn()

    local inst = CreateEntity()
    local trans = inst.entity:AddTransform()
	
    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()  --这个联机也必须加 
	
    MakeInventoryPhysics(inst)
	inst.entity:AddMiniMapEntity()
	
    inst:AddTag("armor")
	inst:AddTag("hide_percentage")
	--inst:AddTag("anti_radiation")
	
	inst.AnimState:SetBank("icey_armor")
    inst.AnimState:SetBuild("icey_armor")
    inst.AnimState:PlayAnimation("idle")
	
	inst.LastEatTime = 0
	
	----------------------上面的东西 对主副机都有效
	
	inst.entity:SetPristine()   --这四句话 放到这里 也就是bank build 和tag之类的后面-。-
	if not TheWorld.ismastersim then
        return inst
    end
	
	----------------------下面的只对主机执行
	inst:AddComponent("chosenicey")
	
    inst:AddComponent("inspectable")
	inst.components.inspectable:SetDescription("最好的艾希都用护盾发生器")
	
	inst:AddComponent("waterproofer")
	inst.components.waterproofer:SetEffectiveness(TUNING.WATERPROOFNESS_SMALL)


    inst:AddComponent("inventoryitem")
    inst.components.inventoryitem.imagename = "icey_armor"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/icey_armor.xml"
	--inst.components.inventoryitem:SetRadiationAbsorb(1)
	
	inst:AddComponent("armor")
    inst.components.armor:InitCondition(1000, 0.65)
	
    inst:AddComponent("equippable")
    inst.components.equippable.equipslot = EQUIPSLOTS.BODY
    inst.components.equippable:SetOnEquip(OnEquip)
    inst.components.equippable:SetOnUnequip(OnUnequip)
	
	MakeHauntableLaunch(inst)  --这个放后面就好了
	inst:ListenForEvent("armordamaged",function()
		if inst.components.armor then 
			inst.components.armor:SetPercent(1.0)
		end
	end)
    return inst
end

return  Prefab("common/inventory/icey_armor", fn, assets, prefabs)